#pragma once

#include "targetver.h"

#include <CppUnitTest.h>

#include <string>
#include <utility>
#include <iterator>
#include <iostream>
#include <amp.h>