#define MIPS_BSD43

#include "tm-mips.h"
