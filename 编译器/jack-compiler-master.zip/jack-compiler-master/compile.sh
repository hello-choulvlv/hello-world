#!/bin/sh

g++ -o jackc.exe jackc/*.cpp -std=c++11
g++ -o jack.exe jack/*.cpp -std=c++11

