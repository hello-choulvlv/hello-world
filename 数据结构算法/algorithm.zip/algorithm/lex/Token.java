/*
  *�ִ�
  *2016-1-7 16:38:50
  */
  public     class    Token
 {
              public      final     int      tag;
//����
              public      Token(int  _tok)
             {
                            this.tag=_tok;
              }
              public        String      toString()
             {
                           return   ""+(char)tag;
              }
  }