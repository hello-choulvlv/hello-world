 extern "C"
{
     bool ASMFindArray(int searchVal,int *array,int count);
     bool CFindArray(int searchVal,int *array,int count);
     void printArray(int *array,int count);
}