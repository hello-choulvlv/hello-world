#include<windows.h>
#include<stdio.h>
int index=0;
int ii=0;
int main()
{
	WinMain(GetModuleHandle(NULL),0,0,0);
	printf("+++++++++++++++++++++");
	return 0;
}
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE prevInstance,PSTR str,int icm)
{
	printf("PPPPPPPPPPPPPPPPPPPP");
	return 0;
}