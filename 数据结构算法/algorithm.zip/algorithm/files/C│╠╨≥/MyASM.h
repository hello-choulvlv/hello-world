  extern "C"
{
    void showArray(int *p,int count);
    void WriteMesg();
}
   