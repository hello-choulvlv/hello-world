#version 120

uniform sampler2D HeightMapTexture;

void main()
{
	float Height = texture2D(HeightMapTexture, gl_TexCoord[0].st).y;

	if(Height >= 0.0)
	{
		discard;
	}

	gl_FragColor = gl_Color;
}
