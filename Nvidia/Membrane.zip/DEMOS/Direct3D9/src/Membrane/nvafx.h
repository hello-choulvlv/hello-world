// PreCompiled Header

#include <shared/dxstdafx.h>
#include <TCHAR.H>
#include "resource.h"

#include <d3d9.h>
#include <d3dx9.h>
#include "NV_D3DCommon\NV_D3DCommon.h"
