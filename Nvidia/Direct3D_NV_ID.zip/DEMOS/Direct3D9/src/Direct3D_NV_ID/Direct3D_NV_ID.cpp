
#include <stdio.h>
#include <conio.h>
#include "Direct3D_NV_ID.h"

/*******************************************************************************

    Main

	Example code to identify NVIDIA's product families.
	It is not a complete list of NVIDIA's product families, but you get the point.

*******************************************************************************/

int main(int argc, char* argv[])
{
	char * D3DDeviceID = isNVIDIA();

	if (D3DDeviceID != NULL && D3DDeviceID != DIRECT3DCREATE9_ERROR) 
	{
        printf("Direct3D_NV_ID - NVIDIA ");
		printf(D3DDeviceID);
		printf("\n");
    }
	else if (D3DDeviceID == NULL)
	{
		printf("Direct3D_NV_ID - Not a NVIDIA device\n");
	} 
	else 
	{
		printf("Direct3D_NV_ID - ");
		printf(D3DDeviceID);
		printf("\n");
	}

	printf("- Hit any key to end - \n");
    getch();
	
	return 0;
}

char * isNVIDIA()
{
    D3DADAPTER_IDENTIFIER9 did;

	LPDIRECT3D9 g_pD3D = NULL;

    if( NULL == (g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)))
        return DIRECT3DCREATE9_ERROR;

	g_pD3D->GetAdapterIdentifier(D3DADAPTER_DEFAULT, 0, &did);

	// The products listed is an example of how to obtain the device id. 
	// For a more complete list of NVIDIA device ids, refer to Device_IDs.txt
     
	if(did.VendorId == 0x12D2)
    {
		switch(did.DeviceId)
        {
			case 0x18:
			case 0x19:
				return "RIVA 128";
        }
		return NULL;
    }
    else if(did.VendorId == DT_NVIDIA_VENDOR_ID)        
    {
		unsigned long D3DDeviceId = did.DeviceId;
		for (int i = 0; i<NVIDIA_DEVICE_TOTAL;i++) {
			if (NVIDIA_DEVICE_INFO[i].deviceID == D3DDeviceId)
			{
				return NVIDIA_DEVICE_INFO[i].chipIDName;
			}
		}
		return "Unlisted Device";
    } else {
		return NULL;
	}
}