// PreCompiled Header

#include <shared/dxstdafx.h>
#include <windows.h>
#include <TCHAR.H>
#include <d3d9.h>
#include <d3dx9.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <dxerr9.h>

#include "resource.h"
#include "shared\NV_Common.h"
#include "shared\NV_Error.h"
#include "DXUT\DXUT.h"
