/*********************************************************************NVMH3****

Copyright NVIDIA Corporation 2002
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
*AS IS* AND NVIDIA AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA OR ITS SUPPLIERS
BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


Comments:




******************************************************************************/
#if defined(WIN32)
#  include <windows.h>
#  pragma warning (disable : 4786)
#endif

#include <iostream>

#define GLH_EXT_SINGLE_FILE

#include <glh/glh_extensions.h>
#include <glh/glh_obs.h>
#include <glh/glh_glut.h>

#include <nv_dds/nv_dds.h>
#include <shared/data_path.h>
#include <shared/noise.h>
#include <shared/objload.h>
#include <shared/read_text_file.h>
#include <shared/quitapp.h>

using namespace glh;
using namespace nv_dds;

#define USE_GLUT_OBJECT

GLenum errCode;
#define CHECK_ERROR     errCode = glGetError(); \
            if (errCode != GL_NO_ERROR) {   \
                printf("(%s, %d) ERROR: %s\n", __FILE__, __LINE__, gluErrorString(errCode)); \
                assert(false);  \
            }

#define REQUIRED_EXTENSIONS "GL_ARB_multitexture " \
                            "GL_ARB_texture_compression " \
                            "GL_EXT_texture_compression_s3tc "

// key mapping
bool b[256];

data_path   media;
unsigned int fpid = 0;
bool wireframe = false;

GLhandleARB programObject = 0;

GLint vertexModelViewInverse = -1;
GLint vertexLight = -1;
GLint fragmentBallData = -1;
GLint fragmentGlossData = -1;
GLint fragmentAmbiColor = -1;
GLint fragmentDiffColor = -1;
GLint fragmentSpecColor = -1;
GLint fragmentLensColor = -1;
GLint fragmentColorMap = -1;

// geom data from obj file
unsigned int nverts   = 0;
unsigned int nindices = 0;
unsigned int *indices = NULL;
float *vertexdata     = NULL;
float *normaldata     = NULL;
float *tangendata     = NULL;
float *binormdata     = NULL;
float *texcoords      = NULL;

tex_object_2D colorTexture;

glut_callbacks cb;
glut_simple_mouse_interactor camera, object;
glut_perspective_reshaper reshaper;

float spinner = .3;
float theta = 0;

float radius = 1.0;
float irisDepth = 0.6;
float eta = 1.3;
float lensDense = 1.2;

float phongExp = 12.0;
float gloss1 = 0.7;
float gloss2 = 0.75;
float glossDrop = 0.4;

#define BG_GREY (153.0/255.0)
float ambiR = 0.2, ambiG = 0.2, ambiB = 0.2;
float diffR = 0.8, diffG = 0.8, diffB = 0.8;
float specR = 0.5, specG = 0.5, specB = 0.6;
float lensR = BG_GREY*0.8, lensG = BG_GREY*0.8, lensB = BG_GREY;

void display();

void cleanExit(int exitval)
{
    if (programObject)
        glDeleteObjectARB(programObject);

    if(exitval == 0) { exit(0); }
    else { quitapp(exitval); }
}

void printInfoLog(GLhandleARB object)
{
    int maxLength = 0;
    glGetObjectParameterivARB(object, GL_OBJECT_INFO_LOG_LENGTH_ARB, &maxLength);

    char *infoLog = new char[maxLength];
    glGetInfoLogARB(object, maxLength, &maxLength, infoLog);

    printf("%s\n", infoLog);
}

void addShader(GLhandleARB programObject, const GLcharARB *shaderSource, GLenum shaderType)
{
    assert(programObject != 0);
    assert(shaderSource != 0);
    assert(shaderType != 0);

    GLhandleARB object = glCreateShaderObjectARB(shaderType);
    assert(object != 0);

    GLint length = (GLint)strlen(shaderSource);
    glShaderSourceARB(object, 1, &shaderSource, &length);

    // compile vertex shader object
    glCompileShaderARB(object);

    // check if shader compiled
    GLint compiled = 0;
    glGetObjectParameterivARB(object, GL_OBJECT_COMPILE_STATUS_ARB, &compiled);

    if (!compiled)
    {
        printInfoLog(object);
        cleanExit(-1);
    }

    // attach vertex shader to program object
    glAttachObjectARB(programObject, object);

    // delete vertex object, no longer needed
    glDeleteObjectARB(object);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
        cout << "OpenGL error: " << gluErrorString(err) << endl;
}

void init()
{
    glEnable(GL_DEPTH_TEST);

    // Get the entry points for the extension.
	if(!glh_init_extensions("GL_ARB_shader_objects GL_ARB_vertex_shader GL_ARB_fragment_shader GL_ARB_texture_compression GL_EXT_texture_compression_s3tc"))
	{
        cout << "Necessary extensions unsupported: " << glh_get_unsupported_extensions() << endl;
        quitapp(-1);
	}

    programObject = glCreateProgramObjectARB();

    // Set data paths...
    media.path.push_back(".");
    media.path.push_back("../../../MEDIA");
    media.path.push_back("../../../../MEDIA");

    string filename = media.get_file("programs/glsl_eye/eye_vertex.glsl");
    if (filename == "")
    {
        cout << "Unable to load eye_vertex.glsl, exiting..." << endl;
        cleanExit(-1);
    }

    GLcharARB *shaderData = read_text_file(filename.c_str());
    addShader(programObject, shaderData, GL_VERTEX_SHADER_ARB);

    delete [] shaderData;

    filename = media.get_file("programs/glsl_eye/eye_fragment.glsl");
    if (filename == "")
    {
        cout << "Unable to load eye_fragment.glsl, exiting..." << endl;
        cleanExit(-1);
    }

    shaderData = read_text_file(filename.c_str());
    addShader(programObject, shaderData, GL_FRAGMENT_SHADER_ARB);

    delete [] shaderData;

    glLinkProgramARB(programObject);

    GLint linked = false;
    glGetObjectParameterivARB(programObject, GL_OBJECT_LINK_STATUS_ARB, &linked);
    if (!linked)
    {
        printInfoLog(programObject);
        cout << "Shaders failed to link, exiting..." << endl;
        cleanExit(-1);
    }

    glValidateProgramARB(programObject);

    GLint validated = false;
    glGetObjectParameterivARB(programObject, GL_OBJECT_VALIDATE_STATUS_ARB, &validated);
    if (!validated)
    {
        printInfoLog(programObject);
        cout << "Shaders failed to validate, exiting..." << endl;
        cleanExit(-1);
    }

    vertexModelViewInverse = glGetUniformLocationARB(programObject, "ModelViewInverse");
    assert(vertexModelViewInverse >= 0);

    vertexLight = glGetUniformLocationARB(programObject, "LightVec");
    assert(vertexLight >= 0);

    fragmentBallData = glGetUniformLocationARB(programObject, "BallData");
    assert(fragmentBallData >= 0);

    fragmentGlossData = glGetUniformLocationARB(programObject, "GlossData");
    assert(fragmentGlossData >= 0);

    fragmentAmbiColor = glGetUniformLocationARB(programObject, "AmbiColor");
    assert(fragmentAmbiColor >= 0);

    fragmentDiffColor = glGetUniformLocationARB(programObject, "DiffColor");
    assert(fragmentDiffColor >= 0);

    fragmentSpecColor = glGetUniformLocationARB(programObject, "SpecColor");
    assert(fragmentSpecColor >= 0);

    fragmentLensColor = glGetUniformLocationARB(programObject, "LensColor");
    assert(fragmentLensColor >= 0);
    
    filename = media.get_file("textures/2D/iris2b.dds");
    if (filename == "") 
    {
        cout << "Unable to locate iris2b.dds, exiting..." << endl;
        cleanExit(-1);
    }

    colorTexture.bind();
    colorTexture.enable();
    colorTexture.parameter(GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    colorTexture.parameter(GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    colorTexture.parameter(GL_TEXTURE_WRAP_S, GL_CLAMP);
    colorTexture.parameter(GL_TEXTURE_WRAP_T, GL_CLAMP);

    CDDSImage image;
    if (image.load(filename))
        image.upload_texture2D();
    else
    {
        cout << "Unable to load iris2b.dds, exiting..." << endl;
        cleanExit(-1);
    }

    glUseProgramObjectARB(programObject);
}

void keyboard(unsigned char k, int x, int y)
{
    b[k] = !b[k];

    if ( k == 27 || k == 'q' ) {
        cleanExit(0);
    }
    if ( k == 'i' ) {
    irisDepth += 0.05;
        irisDepth = (irisDepth > 0.95) ? 0.95 : irisDepth;
    }
    if ( k == 'I' ) {
    irisDepth -= 0.05;
        irisDepth = (irisDepth < 0.15) ? 0.15 : irisDepth;
    }
    if ( k == 'E' ) {
    eta += 0.05;
        eta = (eta > 2.2) ? 2.2 : eta;
    }
    if ( k == 'e' ) {
    eta -= 0.05;
        eta = (eta < 1.0) ? 1.0 : eta;
    }
    if ( k == 'D' ) {
    lensDense += 0.1;
        lensDense = (lensDense > 4.0) ? 4.0 : lensDense;
    }
    if ( k == 'd' ) {
    lensDense -= 0.1;
        lensDense = (lensDense < 0.0) ? 0.0 : lensDense;
    }
    if ( k == 'w' || k == 'W' ) {
        wireframe = !wireframe;
        glPolygonMode(GL_FRONT_AND_BACK, wireframe ? GL_LINE : GL_FILL);
    }

    glutPostRedisplay();
}

void idle()
{
    object.trackball.increment_rotation();
    
    glutPostRedisplay();
}

void menu(int k)
{
    keyboard((unsigned char)k, 0, 0);
}

void motion(int x, int y)
{
}

void reshape(int w, int h)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective( 60, 4./3., .1, 30);
    glViewport(0,0,w,h);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char* argv[])
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGBA | GLUT_STENCIL | GLUT_ALPHA);
    glutInitWindowSize( 720, 540 );
    glutCreateWindow( "Raytrace Eye GLSL Demo" );

    glut_helpers_initialize();

    cb.keyboard_function = keyboard;
    cb.idle_function = idle;
    camera.configure_buttons(1);
    camera.set_camera_mode(true);
    camera.pan.pan = vec3f( 0.0, 0.0, 6.5 );
    object.configure_buttons(1);
    object.dolly.dolly[2] = -1;

    glut_add_interactor(&cb);
    glut_add_interactor(&object);
    glut_add_interactor(&reshaper);

    glut_idle(1);

    // Do some OpenGL initialization.
    init();

    glutDisplayFunc(display);

    glutCreateMenu(menu);
    glutAddMenuEntry("higher eta [E]", 'E');
    glutAddMenuEntry("lower eta [e]", 'e');
    glutAddMenuEntry("smaller iris [i]", 'i');
    glutAddMenuEntry("larger iris [I]", 'I');
    glutAddMenuEntry("Denser Lens [D]", 'D');
    glutAddMenuEntry("Thinner Lens [d]", 'd');
    glutAddMenuEntry("quit [esc]", 27);

    glutAttachMenu(GLUT_RIGHT_BUTTON);

    // Give control over to glut.
    glutMainLoop();
    
    return 0;
}

void display()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(30, 4.0/3.0, 0.1, 30);
    glMatrixMode(GL_MODELVIEW);

    glLoadIdentity();
    
    glClearColor(BG_GREY, BG_GREY, BG_GREY, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // now then -- main prog
    camera.apply_inverse_transform();
    object.apply_transform();

    vec4f lightVec(0,-0.8,-1,0);

    glUniform4fARB(vertexLight, lightVec[0], lightVec[1], lightVec[2], 0.0f);

    glUniform4fARB(fragmentBallData, radius, irisDepth, eta, lensDense);
    glUniform4fARB(fragmentGlossData, phongExp, gloss1, gloss2, glossDrop);
    glUniform3fARB(fragmentAmbiColor, ambiR, ambiG, ambiB);
    glUniform3fARB(fragmentDiffColor, diffR, diffG, diffB);
    glUniform3fARB(fragmentSpecColor, specR, specG, specB);
    glUniform3fARB(fragmentLensColor, lensR, lensG, lensB);

    glRotatef(20, 1, 0, 0);
    glRotatef(-90.0, 0, 1, 0);

    matrix4f modelView;
    glGetFloatv(GL_MODELVIEW_MATRIX, modelView.m);
    glUniformMatrix4fvARB(vertexModelViewInverse, 1, GL_FALSE, modelView.inverse().m);

    glutSolidSphere(1.0, 40, 20);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
        cout << "OpenGL Error: " << gluErrorString(err) << endl;

    glutSwapBuffers();
}
