#include <GL/glut.h>
#include <glh/glh_extensions.h>

#include "cg_helper.h"
#include "brush.h"
#include "canvas.h"

Brush::Brush(Vec2f size, float spacing, Canvas *canvas)
    : m_size(size), m_spacing(spacing), m_activeColor(0), m_canvas(canvas),
      m_mode(PAINT)
{
  LoadPrograms();
}

float smoothstep(float a, float b, float x)
{
    if (x < a)
        return 0;
    if (x >= b)
        return 1;
    x = (x - a)/(b - a);      // normalize to [0:1]
    return (x*x * (3 - 2*x)); // 2x^3 + 3x^2 by Horner's rule
}

void
Brush::CreateCircleTexture(int w, int h, float hardness, bool floatTex)
{
  m_texSize = Vec2i(w, h);
  m_hardness = hardness;

  float *data = new float[w*h*4];

  float cx = w / 2;
  float cy = h / 2;
  float *ptr = data;
  for(int y=0; y<h; y++) {
    for(int x=0; x<w; x++) {
      float dx = x - cx + 0.5;
      float dy = y - cy + 0.5;
      float r = sqrt(dx*dx + dy*dy);
      float i = 1.0 - smoothstep(cx*hardness, cx, r);
      *ptr++ = 1.0;
      *ptr++ = 1.0;
      *ptr++ = 1.0;
      *ptr++ = i;
    }
  }

  glGenTextures(1, &m_tex);
  GLenum target = GL_TEXTURE_RECTANGLE_NV;
//  GLenum target = GL_TEXTURE_2D;
  glBindTexture(target, m_tex);

  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexParameteri(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  if (floatTex) {
    // float texture
    glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(target, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D(target, 0, GL_FLOAT_RGBA_NV, w, h, 0, GL_RGBA, GL_FLOAT, data);
  } else {
    // 8-bit texture
    glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(target, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_FLOAT, data);
  }

  delete [] data;
}

void
Brush::CreateOffsetTexture(int w, int h, float hardness)
{
  m_texSize = Vec2i(w, h);
  m_hardness = hardness;

  float *data = new float[w*h*4];

  float cx = w / 2;
  float cy = h / 2;
  float *ptr = data;
  for(int y=0; y<h; y++) {
    for(int x=0; x<w; x++) {
      float dx = x - cx + 0.5;
      float dy = y - cy + 0.5;
      float r = sqrt(dx*dx + dy*dy);
      float i = 1.0 - smoothstep(cx*hardness, cx, r);
      *ptr++ = dx / cx;
      *ptr++ = dy / cy;
      *ptr++ = 0.0;
      *ptr++ = i;
    }
  }

  glGenTextures(1, &m_tex);
  GLenum target = GL_TEXTURE_RECTANGLE_NV;
//  GLenum target = GL_TEXTURE_2D;
  glBindTexture(target, m_tex);

  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexParameteri(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(target, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexImage2D(target, 0, GL_FLOAT_RGBA_NV, w, h, 0, GL_RGBA, GL_FLOAT, data);

  delete [] data;
}

void
Brush::LoadPrograms()
{
  data_path path;
  path.path.push_back(".");
  path.path.push_back("../../../MEDIA/programs");
  path.path.push_back("../../../../MEDIA/programs");

  m_paint_fprog[0] = LoadCgProgram(CG_PROFILE_FP30, "paint/paint_hdr.cg", path);
  m_color_param = cgGetNamedParameter(m_paint_fprog[0], "color");
  m_paint_fprog[1] = LoadCgProgram(CG_PROFILE_FP30, "paint/paint_clone.cg", path);
  m_paint_fprog[2] = LoadCgProgram(CG_PROFILE_FP30, "paint/paint_add.cg", path);
  m_color_add_param = cgGetNamedParameter(m_paint_fprog[2], "color");
  m_paint_fprog[3] = LoadCgProgram(CG_PROFILE_FP30, "paint/paint_blur.cg", path);
  m_paint_fprog[4] = LoadCgProgram(CG_PROFILE_FP30, "paint/paint_sharpen.cg", path);

  m_copy_fprog = LoadCgProgram(CG_PROFILE_FP30, "paint/copy.cg", path);
}

void
Brush::DrawQuad(Vec2f pos, Vec2f size)
{
  float w2 = size[0] * 0.5;
  float h2 = size[1] * 0.5;

  glBegin(GL_QUADS);
  glTexCoord2f(0.0, 0.0);                   glVertex2f(pos[0]-w2, pos[1]-h2);
  glTexCoord2f(m_texSize[0], 0.0);          glVertex2f(pos[0]+w2, pos[1]-h2);
  glTexCoord2f(m_texSize[0], m_texSize[1]); glVertex2f(pos[0]+w2, pos[1]+h2);
  glTexCoord2f(0.0, m_texSize[1]);          glVertex2f(pos[0]-w2, pos[1]+h2);
  glEnd();
}

void
Brush::DrawQuadClone(Vec2f p, Vec2f c)
{
  float w2 = m_size[0] * 0.5;
  float h2 = m_size[0] * 0.5;
  glBegin(GL_QUADS);
  glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0, 0.0);
  glMultiTexCoord2fARB(GL_TEXTURE1_ARB, c[0]-w2, c[1]-h2);
  glVertex2f(p[0]-w2, p[1]-h2);

  glMultiTexCoord2fARB(GL_TEXTURE0_ARB, m_texSize[0], 0.0);
  glMultiTexCoord2fARB(GL_TEXTURE1_ARB, c[0]+w2, c[1]-h2);
  glVertex2f(p[0]+w2, p[1]-h2);

  glMultiTexCoord2fARB(GL_TEXTURE0_ARB, m_texSize[0], m_texSize[1]);
  glMultiTexCoord2fARB(GL_TEXTURE1_ARB, c[0]+w2, c[1]+h2);
  glVertex2f(p[0]+w2, p[1]+h2);

  glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0.0, m_texSize[1]);
  glMultiTexCoord2fARB(GL_TEXTURE1_ARB, c[0]-w2, c[1]+h2);
  glVertex2f(p[0]-w2, p[1]+h2);
  glEnd();
}

void
Brush::Draw(Vec2f pos)
{  
  if (m_canvas->m_isFloat) {
    DrawFloat(pos);
    return;
  }

  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable(GL_BLEND);

  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_tex);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
  Colorf *c = &m_color[m_activeColor];
  glColor4f(c->r, c->g, c->b, c->a);

  DrawQuad(pos, m_size);
  m_last_draw = pos;

  glDisable(GL_BLEND);
  glDisable(GL_TEXTURE_RECTANGLE_NV);
}

void
Brush::DrawFloat(Vec2f pos)
{
  // copy previous splat
  cgGLBindProgram(m_copy_fprog);
  cgGLEnableProfile(CG_PROFILE_FP30);

  glActiveTextureARB(GL_TEXTURE0_ARB);
  m_canvas->BindTexture(1 - m_canvas->m_current);

  DrawQuad(m_last_draw, m_last_size); // use the previous size in case it has changed

  m_canvas->ReleaseTexture(1 - m_canvas->m_current);  

  cgGLDisableProfile(CG_PROFILE_FP30);
  
  // blend new splat
  cgGLBindProgram(m_paint_fprog[m_mode]);
  cgGLEnableProfile(CG_PROFILE_FP30);

  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_tex);
  glActiveTextureARB(GL_TEXTURE1_ARB);
  m_canvas->BindTexture(1 - m_canvas->m_current);

  Colorf *c = &m_color[m_activeColor];
  glColor4f(c->r, c->g, c->b, c->a);

  switch(m_mode) {
  case PAINT:
    cgGLSetParameter4fv(m_color_param, &c->r);
  case BLUR:
  case SHARPEN:
    DrawQuad(pos, m_size);
    break;
  case CLONE:
    DrawQuadClone(pos, pos + m_clone_offset);
    break;
  case OFFSET:
    Vec2f d = m_prev_pos - pos;
    cgGLSetParameter4f(m_color_add_param, d[0], d[1], 0.0, c->a);
    DrawQuad(pos, m_size);
    break;
  }

  m_canvas->ReleaseTexture(1 - m_canvas->m_current);
  cgGLDisableProfile(CG_PROFILE_FP30);

  m_last_draw = m_prev_pos = pos;
  m_last_size = m_size;
  m_canvas->m_current = 1 - m_canvas->m_current;
}

void
Brush::DrawCircle(float x, float y, float r, int segments)
{
  glBegin(GL_LINE_LOOP);
  for(int i=0; i<segments; i++) {
    float a = M_PI*2.0*i / (float) segments;
    glVertex2f(x+sin(a)*r, y+cos(a)*r);
  }
  glEnd();
}

void
Brush::DrawOutline(Vec2f pos)
{
  glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ZERO); // make sure the cursor is always visible
  glEnable(GL_BLEND);
  glColor3f(1.0, 1.0, 1.0);
  DrawCircle(pos[0], pos[1], m_size[0]/2.0, 100);
  glDisable(GL_BLEND);
}

void
Brush::DrawCursor(Vec2f pos)
{
  float r = m_size[0]/2.0;

  glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ZERO); // make sure the cursor is always visible
  glEnable(GL_BLEND);
  glColor3f(1.0, 1.0, 1.0);

  glBegin(GL_LINES);
    glVertex2f(pos[0] - r, pos[1]);
    glVertex2f(pos[0] + r, pos[1]);

    glVertex2f(pos[0], pos[1] - r);
    glVertex2f(pos[0], pos[1] + r);
  glEnd();

  glDisable(GL_BLEND);
}
