#include <iostream>
#include "cg_helper.h"

#include <shared/quitapp.h>


using namespace std;

CGcontext g_context;

void 
cgErrorCallback(void)
{
  CGerror lastError = cgGetError();
  if(lastError) {
    const char *listing = cgGetLastListing(g_context);
    printf("\n---------------------------------------------------\n");
    printf("%s\n\n", cgGetErrorString(lastError));
    printf("%s\n", listing);
    printf("-----------------------------------------------------\n");
    printf("Cg error, exiting...\n");
    cgDestroyContext(g_context);
  }
}

CGprogram LoadCgProgram(CGprofile profile, char *filename, data_path &path)
{
  std::string pathname = path.get_file(filename);
  if (pathname == "") {
    printf("Unable to load '%s', exiting...\n", filename);
    quitapp(-1);
  }

  CGprogram program = cgCreateProgramFromFile(g_context, CG_SOURCE, pathname.data(),
                                              profile, NULL, NULL);
  cgGLLoadProgram(program);
  return program;
}
