#include "shared/nv_png.h"
#include "shared/array_texture.h"
#include "PNGReader.h"

PNGReader::PNGReader(char *filename) : ImageReader(filename)
{
  m_pixels = new glh::array2<glh::vec3ub>;
  read_png_rgb(filename, *m_pixels);
}

PNGReader::~PNGReader()
{
  delete m_pixels;
}