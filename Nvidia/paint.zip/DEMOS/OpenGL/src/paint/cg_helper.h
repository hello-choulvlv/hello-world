#include <Cg/cgGL.h>
#include "shared/data_path.h"

extern CGcontext g_context;

void cgErrorCallback(void);
CGprogram LoadCgProgram(CGprofile profile, char *filename, data_path &path);