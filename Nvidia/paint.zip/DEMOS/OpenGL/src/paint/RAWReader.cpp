// read 8 and 16-bit PPM format files written by Dave Coffin's dcraw
// http://www.cybercom.net/~dcoffin/dcraw/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "RAWReader.h"

PPMReader::PPMReader(char *filename) : ImageReader(filename), m_format(GL_RGB)
{
  FILE *fp;
  fp = fopen(filename, "rb");
  if (!fp) {
    fprintf(stderr, "Error opening file '%s'\n", filename);
    return;
  }

  // read header
  char text[256];
  fscanf(fp, "%s", text);
  if (strcmp(text, "P6") != 0) {
    fprintf(stderr, "Error - '%s' not PPM format\n", filename);
    return;
  }

  int maxval;
  if (fscanf(fp, "%d %d %d", &m_w, &m_h, &maxval) != 3) {
    fprintf(stderr, "Error parsing header\n");
    return;
  }
  fprintf(stderr, "w: %d h: %d maxval: %d\n", m_w, m_h, maxval);

  int bytes_per_component;
  if (maxval > 255) {
    m_type = GL_UNSIGNED_SHORT;
    bytes_per_component = 2;
  } else {
    m_type = GL_UNSIGNED_BYTE;
    bytes_per_component = 1;
  }

#if 0
  // eat whitespace
  int c;
  do {
    c = fgetc(fp);
  } while(isspace(c));
  ungetc(c, fp);
#endif

  int size = m_w*m_h*3*bytes_per_component;
  m_pixels = new unsigned char [ size ];
  
  if (fread(m_pixels, 1, size, fp) != size) {
    fprintf(stderr, "Error reading image data\n");
  }

#if 0
  if (bytes_per_component == 2) {
    // swap bytes in short data
    unsigned char *ptr = m_pixels;
    for(int i=0; i<m_w*m_h*3; i++) {
      unsigned char temp = ptr[0];
      ptr[0] = ptr[1];
      ptr[1] = temp;
      ptr += 2;
    }
  }
#endif
}

PPMReader::~PPMReader()
{
  delete m_pixels;
}

// interleave data in grayscale PPM image written by dcraw "document" mode into RGBA image
void
PPMReader::ConvertCCD()
{
  int new_w = m_w / 2;
  int new_h = m_h / 2;
  unsigned short *rgba_data = new unsigned short [ new_w*new_h*4 ];
  unsigned short *src, *dest;
  src = (unsigned short *) m_pixels;
  dest = rgba_data;

  for(int y=0; y<new_h; y++) {
    for(int x=0; x<new_w; x++) {
      *dest++ = *src;             // TL
      *dest++ = *(src+3);         // TR
      *dest++ = *(src+m_w*3);     // BL
      *dest++ = *(src+m_w*3+3);   // BR
      src += 6;     // move 2 pixels to right
    }
    src += m_w*3;   // move 1 line down
  }

  m_w = new_w;
  m_h = new_h;
  delete [] m_pixels;
  m_pixels = (unsigned char *) rgba_data;
  m_format = GL_RGBA;
}