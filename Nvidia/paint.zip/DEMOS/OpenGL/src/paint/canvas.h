#ifndef _CANVAS_H
#define CANVAS_H

#include "Cg/Cg.h"
#include "types.h"
#include "shared/pbuffer.h"

class Canvas
{
public:
  Canvas(int width, int height, bool m_isFloat=false);
  ~Canvas();

  void Activate();  // make current for rendering
  void Deactivate();
  void BindTexture(int current = 0);
  void ReleaseTexture(int current = 0);

  void Clear(Colorf c);
  void DrawImage(Vec2i pos, Vec2i size, GLenum format, GLenum type, void *pixels);

  void Render();
  void RenderFloat();

  Colorf ReadPixel(Vec2i pos);

  int GetWidth() { return m_w; }
  int GetHeight() { return m_h; }

  void SetLightDir(Vec3f dir) { m_lightDir = dir; }
  void SetDisplayMode(int mode) { m_displayMode = mode; }

  void ReloadPrograms();

  int m_w, m_h;
  PBuffer *m_pbuffer;
  int m_current;  // destination buffer
  bool m_isFloat;
  GLuint m_tex, m_imageTex;
  GLenum m_target;

  float m_heightScale, m_shininess;
  float m_exposure, m_gamma;
  float m_offsetScale;

protected:
  void InitGL();
  void LoadPrograms();
  GLuint CreateTexture(GLenum target);
  void DrawQuad();
  void DrawFrame();

  CGprogram m_display_fprog[5];
  CGparameter m_tex_param, m_exposure_param, m_gamma_param;
  CGparameter m_lightDir_param, m_heightScale_param, m_shininess_param;
  CGparameter m_offset_scale_param, m_offset_exposure_param, m_offset_gamma_param;
  CGparameter m_raw_exposure_param, m_raw_gamma_param;

  Vec3f m_lightDir;
  int m_displayMode;
};

#endif
