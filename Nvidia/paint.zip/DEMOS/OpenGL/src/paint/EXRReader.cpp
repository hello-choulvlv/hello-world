#include <ImfRgbaFile.h>
#include <ImfStringAttribute.h>
#include <ImfMatrixAttribute.h>
#include <ImfArray.h>
#include <iostream>
#include "EXRReader.h"

using namespace std;
using namespace Imf;
using namespace Imath;

EXRReader::EXRReader(char *filename) : ImageReader(filename)
{
  RgbaInputFile file (filename);

  Box2i dw = file.dataWindow();
  m_w = dw.max.x - dw.min.x + 1;
  m_h = dw.max.y - dw.min.y + 1;
  m_pixels.resizeErase (m_h, m_w);

//    file.setFrameBuffer (&pixels[0][0] - dw.min.x - dw.min.y * width, 1, width);
  file.setFrameBuffer (&m_pixels[m_h-1][0], 1, -m_w);
  file.readPixels (dw.min.y, dw.max.y);
}

EXRReader::~EXRReader()
{
}
