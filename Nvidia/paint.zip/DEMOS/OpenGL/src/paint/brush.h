#ifndef _BRUSH_H
#define _BRUSH_H

#include <GL/glut.h>
#include "Cg/Cg.h"
#include "types.h"

class Canvas;

class Brush {
public:
  Brush(Vec2f size, float spacing, Canvas *canvas);

  enum Mode { PAINT = 0, CLONE, OFFSET, BLUR, SHARPEN };

  void CreateCircleTexture(int w, int h, float hardness, bool floatTex = true);
  void CreateOffsetTexture(int w, int h, float hardness);

  void Draw(Vec2f pos);
  void DrawFloat(Vec2f pos);
  void DrawOutline(Vec2f pos);
  void DrawCursor(Vec2f pos);

  void SetActiveColor(int i) { m_activeColor = i; }
  void SetMode(Mode mode) { m_mode = mode; }

  GLuint m_tex;
  GLenum m_target;
  Vec2i m_texSize;

  Vec2f m_size, m_last_size;
  float m_spacing;
  float m_hardness;

  Colorf m_color[2];  // foreground and background colors
  int m_activeColor;

  Vec2f m_last_draw, m_prev_pos;
  Vec2f m_clone_origin, m_clone_offset;
  float m_airbrush_radius;
  int m_airbrush_no;

  Canvas *m_canvas;
  Mode m_mode;

private:
  void DrawQuad(Vec2f pos, Vec2f size);
  void DrawQuadClone(Vec2f p, Vec2f c);
  void DrawCircle(float x, float y, float r, int segments);
  void LoadPrograms();

  CGprogram m_paint_fprog[5], m_copy_fprog;
  CGparameter m_color_param, m_color_add_param;
};

#endif