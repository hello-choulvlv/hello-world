#ifndef _TYPES_H
#define _TYPES_H

#include "glh/glh_linear.h"

#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795
#endif

typedef glh::vec2f Vec2f;
typedef glh::vec3f Vec3f;

class Vec2i : public glh::vec<2,int>
{
  public:
	
	Vec2i(const int & t = int()) : glh::vec<2,int>(t)
	{}

	Vec2i(int x, int y )
	{ v[0] = x; v[1] = y; }	
};

//typedef glh::vec<2,int> Vec2i;

template <class T>
class Color
{
public:
  Color() : r(0), g(0), b(0), a(1) {};
  Color(T _r, T _g, T _b, T _a = 1) : r(_r), g(_g), b(_b), a(_a) {};
  T r, g, b, a;
};

typedef Color<float> Colorf;

#endif