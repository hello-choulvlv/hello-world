#include "ImageReader.h"
#include "glh/glh_array.h"

class PPMReader : public ImageReader {
public:
  PPMReader(char *filename);
  ~PPMReader();

  void *GetData() { return m_pixels; }
  GLenum GetFormat() { return m_format; }
  GLenum GetType() { return m_type; }

  void ConvertCCD();

private:
  unsigned char *m_pixels;
  GLenum m_format;
  GLenum m_type;
};