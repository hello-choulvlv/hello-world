#include <GL/glut.h>
#include <glh/glh_extensions.h>
#include <Cg/cgGL.h>

#include "canvas.h"
#include "cg_helper.h"

Canvas::Canvas(int width, int height, bool isFloat)
  : m_w(width), m_h(height), m_isFloat(isFloat),
    m_current(0),
    m_displayMode(0),
    m_lightDir(Vec3f(0, 0, 1)), m_heightScale(0.1), m_shininess(40.0),
    m_exposure(1.0), m_gamma(1.0 / 2.0),
    m_offsetScale(1.0)
{
  m_target = GL_TEXTURE_RECTANGLE_NV;
  
  if (isFloat) {
    // use double buffered float pbuffer for blending
	  m_pbuffer = new PBuffer("rgba float=16 textureRECT double");
	  m_pbuffer->Initialize(m_w, m_h, false, true);
    m_tex = CreateTexture(m_target);
    m_pbuffer->Activate();
    InitGL();

  } else {
  	m_pbuffer = new PBuffer("rgba textureRECT");
	  m_pbuffer->Initialize(m_w, m_h, false, true);
    m_tex = CreateTexture(m_target);
    m_pbuffer->Activate();
    InitGL();
  }

  m_pbuffer->Activate();

  cgSetErrorCallback(cgErrorCallback);
  g_context = cgCreateContext();
  LoadPrograms();
}

void
Canvas::InitGL()
{
  glDisable(GL_DEPTH_TEST);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0, m_w, 0, m_h, -1.0, 1.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glViewport(0, 0, m_w, m_h);

  glClearColor(0.0, 0.0, 0.0, 1.0);
  glClear(GL_COLOR_BUFFER_BIT);
}

void
Canvas::LoadPrograms()
{
  data_path path;
  path.path.push_back(".");
  path.path.push_back("../../../MEDIA/programs");
  path.path.push_back("../../../../MEDIA/programs");

  m_display_fprog[0] = LoadCgProgram(CG_PROFILE_FP30, "paint/display_hdr.cg", path);
  m_tex_param = cgGetNamedParameter(m_display_fprog[0], "tex");
  m_gamma_param = cgGetNamedParameter(m_display_fprog[0], "gamma");
  m_exposure_param = cgGetNamedParameter(m_display_fprog[0], "exposure");

  m_display_fprog[1] = LoadCgProgram(CG_PROFILE_FP30, "paint/display_phong.cg", path);
  m_lightDir_param = cgGetNamedParameter(m_display_fprog[1], "L");
  m_heightScale_param = cgGetNamedParameter(m_display_fprog[1], "heightScale");
  m_shininess_param = cgGetNamedParameter(m_display_fprog[1], "shininess");

  m_display_fprog[2] = LoadCgProgram(CG_PROFILE_FP30, "paint/display_offset_hdr.cg", path);
  m_offset_scale_param = cgGetNamedParameter(m_display_fprog[2], "offsetScale");
  m_offset_exposure_param = cgGetNamedParameter(m_display_fprog[2], "exposure");
  m_offset_gamma_param = cgGetNamedParameter(m_display_fprog[2], "gamma");

  m_display_fprog[3] = LoadCgProgram(CG_PROFILE_FP30, "paint/display_raw.cg", path);
  m_raw_exposure_param = cgGetNamedParameter(m_display_fprog[3], "exposure");
  m_raw_gamma_param = cgGetNamedParameter(m_display_fprog[3], "gamma");
}

void
Canvas::ReloadPrograms()
{
  cgDestroyProgram(m_display_fprog[0]);
  cgDestroyProgram(m_display_fprog[1]);
  cgDestroyProgram(m_display_fprog[2]);
  cgDestroyProgram(m_display_fprog[3]);
  LoadPrograms();
}

GLuint
Canvas::CreateTexture(GLenum target)
{
  GLuint tex;
  glGenTextures(1, &tex);
  glBindTexture(target, tex);
  if (m_isFloat) {
    glTexParameteri(target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  } else {
    glTexParameteri(target, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  }
  glTexParameteri(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  return tex;
}

Canvas::~Canvas()
{
  delete m_pbuffer;
  glDeleteTextures(1, &m_tex);
  cgDestroyProgram(m_display_fprog[0]);
  cgDestroyProgram(m_display_fprog[1]);
  cgDestroyProgram(m_display_fprog[2]);
  cgDestroyContext(g_context);
}

void
Canvas::Activate()
{
  m_pbuffer->Activate();
  glDrawBuffer(m_current ? GL_BACK : GL_FRONT);
}

void
Canvas::Deactivate()
{
  m_pbuffer->Deactivate();
}

void
Canvas::BindTexture(int current)
{
  glBindTexture(m_target, m_tex);
  m_pbuffer->Bind(current ? WGL_BACK_LEFT_ARB : WGL_FRONT_LEFT_ARB);
  glEnable(m_target);
}

void
Canvas::ReleaseTexture(int current)
{
  m_pbuffer->Release(current ? WGL_BACK_LEFT_ARB : WGL_FRONT_LEFT_ARB);
  glDisable(m_target);
}

void
Canvas::Clear(Colorf c)
{
  m_pbuffer->Activate();
  glClearColor(c.r, c.g, c.b, c.a);

  glDrawBuffer(GL_FRONT);
  glClear(GL_COLOR_BUFFER_BIT);

  glDrawBuffer(GL_BACK);
  glClear(GL_COLOR_BUFFER_BIT);

  m_pbuffer->Deactivate();
}

void
Canvas::DrawImage(Vec2i pos, Vec2i size, GLenum format, GLenum type, void *pixels)
{
  m_pbuffer->Activate();

  glDrawBuffer(GL_FRONT);
  glRasterPos2f(pos[0], pos[1]);
  glDrawPixels(size[0], size[1], format, type, pixels);

  glDrawBuffer(GL_BACK);
  glRasterPos2f(pos[0], pos[1]);
  glDrawPixels(size[0], size[1], format, type, pixels);

  m_pbuffer->Deactivate();
}

void
Canvas::DrawQuad()
{
  glBegin(GL_QUADS);
	glTexCoord2f(0,   0);	  glVertex2f(0,   0);
	glTexCoord2f(m_w, 0);   glVertex2f(m_w, 0);
	glTexCoord2f(m_w, m_h); glVertex2f(m_w, m_h);
	glTexCoord2f(0,   m_h); glVertex2f(0,   m_h);
  glEnd();
}

void
Canvas::DrawFrame()
{
  glColor3f(0.0, 0.0, 0.0);
  glBegin(GL_LINE_LOOP);
	glVertex2f(0,   0);
	glVertex2f(m_w, 0);
	glVertex2f(m_w, m_h);
	glVertex2f(0,   m_h);
  glEnd();
}

void
Canvas::Render()
{
  if (m_isFloat) {
    RenderFloat();
    return;
  }
  BindTexture();
  glColor3f(1.0, 1.0, 1.0);
  DrawQuad();
  ReleaseTexture();

  DrawFrame();
}

void
Canvas::RenderFloat()
{
  cgGLBindProgram(m_display_fprog[m_displayMode]);
  cgGLEnableProfile(CG_PROFILE_FP30);

  switch(m_displayMode) {
    case 0:
      cgGLSetParameter1f(m_exposure_param, m_exposure);
      cgGLSetParameter1f(m_gamma_param, m_gamma);
      break;
    case 1:
      cgGLSetParameter4fv(m_lightDir_param, m_lightDir.v);
      cgGLSetParameter1f(m_heightScale_param, m_heightScale);
      cgGLSetParameter1f(m_shininess_param, m_shininess);
      break;
    case 2:
      cgGLSetParameter1f(m_offset_scale_param, m_offsetScale);
      cgGLSetParameter1f(m_offset_exposure_param, m_exposure);
      cgGLSetParameter1f(m_offset_gamma_param, m_gamma);
      glActiveTextureARB(GL_TEXTURE1_ARB);
      glBindTexture(GL_TEXTURE_RECTANGLE_NV, m_imageTex);
      break;
    case 3:
      cgGLSetParameter1f(m_raw_exposure_param, m_exposure);
      cgGLSetParameter1f(m_raw_gamma_param, m_gamma);
      break;
  }

  glActiveTextureARB(GL_TEXTURE0_ARB);
  BindTexture(1 - m_current);
  DrawQuad();
  ReleaseTexture(1 - m_current);

  cgGLDisableProfile(CG_PROFILE_FP30);

  DrawFrame();
}

Colorf
Canvas::ReadPixel(Vec2i pos)
{
  Activate();
  Colorf c;
  glReadPixels(pos[0], pos[1], 1, 1, GL_RGB, GL_FLOAT, &c);
  return c;
}
