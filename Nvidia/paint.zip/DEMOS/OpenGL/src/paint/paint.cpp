/*
  Hardware Accelerated HDR Paint Demo
  sgreen 10/2003 

  Copyright NVIDIA Corporation 2003
  TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
  *AS IS* AND NVIDIA AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS
  OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA OR ITS SUPPLIERS
  BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
  WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
  BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
  ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
  BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

  This example demonstrates the use of floating point textures and
  render-to-texture to implement high dynamic range painting.

  It uses Cg shaders to implement several different display and brush modes.

  Floating point blending is emulated by using two FP pbuffers and
  switching between then.

  Controls:
  Left mouse button - paint
  Middle button (or left + shift) - pans canvas
  Left + middle buttons (or left + ctrl) - zoom canvas
  Right button for menus
*/

#include "EXRReader.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>
#include <iostream>

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>

#include <shared/quitapp.h>

#include "shared/pbuffer.h"
#include "paramgl/param.h"
#include "paramgl/paramgl.h"
#include "types.h"
#include "brush.h"
#include "canvas.h"

#include "RAWReader.h"
#include "PNGReader.h"

using namespace std;

bool toggle[256];
int win_w = 1024, win_h = 768;

struct Mouse {
  Vec2f pos;
  Vec2f canvas_pos;
  Vec2f old_pos;
  unsigned int buttonState;
  int modifiers;
};

enum {
  LEFT_BUTTON = 1,
  MIDDLE_BUTTON = 2,
  RIGHT_BUTTON = 4
};

Mouse mouse;
Brush *brush;
Canvas *canvas;
ParamListGL *params;

Vec2f trans;
float zoom = 1.0;
float flip_x = 1.0, flip_y = 1.0;
float rotate = 0.0;
glh::matrix4f view_matrix_inv;

float light_rx = M_PI / 8.0, light_rz = 0.0;

enum ToolMode {
  MODE_PAINT = 0,
  MODE_DROPPER, 
  MODE_AIRBRUSH, 
  MODE_CLONE,
  MODE_BRUSHSIZE
};

ToolMode mode = MODE_PAINT, prev_mode = MODE_PAINT;
float lightness = 0.0;
ImageReader *img = 0;
float exposure_stop = 0.0;

void airbrush_mouse(Vec2f pos);

void checkErrors(char *s)
{
  GLenum error;
  while ((error = glGetError()) != GL_NO_ERROR) {
    fprintf(stderr, "%s: error - %s\n", s, (char *) gluErrorString(error));
  }
}

// build matrix to position canvas on screen
void buildViewMatrix()
{
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(trans[0], trans[1], 0);
  Vec2f c = Vec2f(win_w, win_h)*0.5 - trans; // center
  glTranslatef(c[0], c[1], 0);
  glRotatef(rotate, 0.0, 0.0, 1.0);
  glScalef(zoom*flip_x, zoom*flip_y, 1);
  glTranslatef(-c[0], -c[1], 0);
  glh::matrix4f matrix;
  glGetFloatv(GL_MODELVIEW_MATRIX, (GLfloat *) matrix.get_value());
  view_matrix_inv = matrix.inverse();
}

// map window coords to canvas coords
Vec2f winToCanvas(Vec2f win)
{
  glh::vec4f canvas_pos;
  view_matrix_inv.mult_matrix_vec(glh::vec4f(win[0], win[1], 0.0, 1.0), canvas_pos);
  return Vec2f(canvas_pos[0], canvas_pos[1]);
}

// map vector in window space to canvas coords
Vec2f winVecToCanvas(Vec2f win)
{
  glh::vec4f canvas_vec;
  view_matrix_inv.mult_matrix_vec(glh::vec4f(win[0], win[1], 0.0, 0.0), canvas_vec);
  return Vec2f(canvas_vec[0], canvas_vec[1]);
}

void drawColors()
{
  glPushMatrix();
  glLoadIdentity();
  glTranslatef(0.0, win_h - 256.0, 0.0);

  // red-green
  glBegin(GL_QUADS);
  glColor3f(0.0, 0.0, lightness); glVertex2f(0.0, 0.0);
  glColor3f(0.0, 1.0, lightness); glVertex2f(256.0, 0.0);
  glColor3f(1.0, 1.0, lightness); glVertex2f(256.0, 256.0);
  glColor3f(1.0, 0.0, lightness); glVertex2f(0.0, 256.0);
  glEnd();

  // green-blue
  glTranslatef(256+10.0, 0.0, 0.0);
  glBegin(GL_QUADS);
  glColor3f(lightness, 0.0, 0.0); glVertex2f(0.0, 0.0);
  glColor3f(lightness, 0.0, 1.0); glVertex2f(256.0, 0.0);
  glColor3f(lightness, 1.0, 1.0); glVertex2f(256.0, 256.0);
  glColor3f(lightness, 1.0, 0.0); glVertex2f(0.0, 256.0);
  glEnd();

  // blue-red
  glTranslatef(256+10.0, 0.0, 0.0);
  glBegin(GL_QUADS);
  glColor3f(0.0, lightness, 0.0); glVertex2f(0.0, 0.0);
  glColor3f(1.0, lightness, 0.0); glVertex2f(256.0, 0.0);
  glColor3f(1.0, lightness, 1.0); glVertex2f(256.0, 256.0);
  glColor3f(0.0, lightness, 1.0); glVertex2f(0.0, 256.0);
  glEnd();

  // current color
  glTranslatef(256+10.0, 0.0, 0.0);
  glColor3f(brush->m_color[0].r, brush->m_color[0].g, brush->m_color[0].b);
  glBegin(GL_QUADS);
  glVertex2f(0.0, 0.0);
  glVertex2f(256.0, 0.0);
  glVertex2f(256.0, 256.0);
  glVertex2f(0.0, 256.0);
  glEnd();

  glPopMatrix();
}

// draw a single brush image
void paint(Vec2f p)
{
  canvas->Activate();
  brush->Draw(p);
  canvas->Deactivate();

#if 0
  glColor4f(1.0, 0.0, 0.0, 0.5);
  glBegin(GL_POINTS); glVertex2f(p[0], p[1]); glEnd();
#endif
}

// draw several brush images in a line, with spacing of "spacing" pixels
// skips first element to avoid overdraw
void paint_line(Vec2f a, Vec2f b, float spacing)
{
  Vec2f d = b - a;
  float dist = d.length();
  d *= 1.0 / dist;  // normalize

//  canvas->Activate();
  for(float t=spacing; t<=dist; t+=spacing) {
    Vec2f p = a + t*d;
    paint(p);
  }
}

void clone(Vec2f p, Vec2f offset)
{
  canvas->Activate();
  brush->Draw(p);
  canvas->Deactivate();
}

void airbrush(Vec2f p)
{
  for(int i=0; i<brush->m_airbrush_no; i++) {
    Vec2f r;
    // choose random position within unit circle
    do {
      r[0] = -1.0 + 2.0*(rand() / (float) RAND_MAX);
      r[1] = -1.0 + 2.0*(rand() / (float) RAND_MAX);
    } while(r.length() > 1.0);

    r = p + r*brush->m_airbrush_radius;
    paint(r);
  }
  glutPostRedisplay();
}

void display(void)
{	
  canvas->Deactivate();
  glClear(GL_COLOR_BUFFER_BIT);

  // build view matrix
  buildViewMatrix();

  // draw canvas
  canvas->Render();

  // draw color selector
  if (toggle['c']) {
    drawColors();
  }

  // display brush
  if ( (mouse.buttonState & LEFT_BUTTON) && (mode == MODE_BRUSHSIZE) ){
    brush->DrawOutline(brush->m_clone_origin);
  } else if (toggle['d']) {
    brush->DrawOutline(mouse.canvas_pos);
  }

  if (mode == MODE_CLONE) {
    brush->DrawCursor(mouse.canvas_pos + brush->m_clone_offset);
    brush->DrawOutline(mouse.canvas_pos);
  }

  if (toggle['h']) {
    // sliders
    glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ZERO); // invert color
    glEnable(GL_BLEND);
    params->Render(0, 0);
    glDisable(GL_BLEND);
  } else {
    switch(mode) {
    case MODE_AIRBRUSH:
      if ((mouse.buttonState & LEFT_BUTTON) && !(mouse.buttonState & MIDDLE_BUTTON)) {
        airbrush_mouse(mouse.canvas_pos);
      }
      break;
    }
  }

  checkErrors("display");
  glutSwapBuffers();
}

// tools
void brushTool_mouse(Vec2f pos)
{
  brush->m_prev_pos = pos;
  paint(pos);
  glutPostRedisplay();
}

void brushTool_motion(Vec2f pos)
{
  Vec2f d = pos - brush->m_last_draw;
  float dist = d.length();

  float spacing;
  if (brush->m_spacing==0.0)
    spacing = 1.0;
  else
    spacing = brush->m_size[0]*brush->m_spacing;

  if (dist >= spacing*2.0) {
    paint_line(brush->m_last_draw, pos, spacing);

  } else if (dist >= spacing) {
    float t = spacing / dist;
    Vec2f p = brush->m_last_draw + t*d;
    paint(p);
  }

  glutPostRedisplay();
}

void dropperTool_mouse(Vec2f pos)
{
  brush->m_clone_origin = pos;

  glPixelStorei(GL_PACK_ALIGNMENT, 1);
  if (toggle['c']) {
    // read color from display surface
    canvas->Deactivate();
    glReadPixels(mouse.pos[0], mouse.pos[1], 1, 1, GL_RGB, GL_FLOAT, &brush->m_color);
  } else {
    // read color from canvas
    brush->m_color[brush->m_activeColor] = canvas->ReadPixel(Vec2i(pos[0], pos[1]));
  }
  glutPostRedisplay();
}

void cloneTool_mouse(Vec2f pos)
{
  brush->m_clone_offset = brush->m_clone_origin - pos;
  clone(pos, brush->m_clone_offset);
  glutPostRedisplay();
}

void cloneTool_motion(Vec2f pos)
{
  clone(pos, brush->m_clone_offset);
  glutPostRedisplay();
}

void airbrush_mouse(Vec2f pos)
{
  airbrush(pos);
}

void brushsize_mouse(Vec2f pos)
{
  brush->m_clone_origin = pos;
}

void brushsize_motion(Vec2f pos)
{
  brush->m_size[0] = brush->m_size[1] = (pos - brush->m_clone_origin).length() * 2.0;
  glutPostRedisplay();
}


void setLightDirection()
{
  Vec3f dir;

  // set light direction using spherical coordinates
  dir[0] = cos(light_rz) * sin(light_rx);
  dir[1] = sin(light_rz) * sin(light_rx);
  dir[2] = cos(light_rx);

  canvas->SetLightDir(dir);
}

// called on slider change
void paramChange()
{
    brush->m_size[0] = params->GetParam("brush size")->GetFloatValue();
    brush->m_size[1] = brush->m_size[0] * params->GetParam("brush aspect")->GetFloatValue();
    float h = params->GetParam("brush hardness")->GetFloatValue();
    if (h != brush->m_hardness) {
      brush->m_hardness = h;
      canvas->Activate();
      glDeleteTextures(1, &brush->m_tex);
      brush->CreateCircleTexture(brush->m_texSize[0], brush->m_texSize[1], brush->m_hardness);
    }
    setLightDirection();
    canvas->m_exposure = powf(2.0, exposure_stop);
}


void mouse_func(int button, int state, int x, int y)
{
  mouse.pos = Vec2f(x, win_h - y);
  mouse.old_pos = mouse.pos;
  mouse.canvas_pos = winToCanvas(mouse.pos);
  mouse.modifiers = glutGetModifiers();

  if (state == GLUT_DOWN) {
	  mouse.buttonState |= 1<<button;
    if ((button == GLUT_LEFT_BUTTON) && (mouse.modifiers & GLUT_ACTIVE_ALT) && (mode==MODE_CLONE)) {
      // alt - set clone origin
      brush->m_clone_origin = mouse.canvas_pos;
    }

  } else if (state == GLUT_UP) {
  	mouse.buttonState = 0;
    if (button == GLUT_LEFT_BUTTON) {
      if (mode==MODE_BRUSHSIZE) {
        // stop brush sizing on release of left button
        mode = prev_mode;
      } else if (mode==MODE_DROPPER) {
        // close color picker
        toggle['c'] = false;
        mode = prev_mode;
      }
    }
  }

  if (mouse.modifiers  & GLUT_ACTIVE_SHIFT) {
	  mouse.buttonState = MIDDLE_BUTTON;
  } else if (mouse.modifiers  & GLUT_ACTIVE_CTRL) {
    mouse.buttonState = LEFT_BUTTON | MIDDLE_BUTTON;
  }

#if 0
  if (mouse.modifiers & GLUT_ACTIVE_ALT) {
    brush->SetActiveColor(1);
  } else {
    brush->SetActiveColor(0);
  }
#endif

  if ((toggle['h']) && (mouse.buttonState & LEFT_BUTTON)) {
    // call list mouse function
    if (params->Mouse(x, y, button, state)) {
      paramChange();
      glutPostRedisplay();
      return;
    }
  }

  if ((mouse.buttonState & LEFT_BUTTON) && !(mouse.buttonState & MIDDLE_BUTTON) && !(mouse.modifiers & GLUT_ACTIVE_ALT)) {
    switch(mode) {
    case MODE_PAINT:
      brushTool_mouse(mouse.canvas_pos);
      break;
    case MODE_DROPPER:
      dropperTool_mouse(mouse.canvas_pos);
      break;
   case MODE_CLONE:
      cloneTool_mouse(mouse.canvas_pos);
      break; 
   case MODE_AIRBRUSH:
      airbrush_mouse(mouse.canvas_pos);
      break; 
   case MODE_BRUSHSIZE:
      brushsize_mouse(mouse.canvas_pos);
      break; 
    };
  }
}

void motion(int x, int y)
{
  mouse.pos = Vec2f(x, win_h - y);
  mouse.canvas_pos = winToCanvas(mouse.pos);
  Vec2f delta = mouse.pos - mouse.old_pos;

  if ((toggle['h']) && (mouse.buttonState & LEFT_BUTTON)) {
    // call list motion function
    if (params->Motion(x, y)) {
      paramChange();
      glutPostRedisplay();
      return; 
    };
  }

  // view controls
  if ((mouse.buttonState & LEFT_BUTTON) && (mouse.modifiers & GLUT_ACTIVE_ALT)) {
    rotate += delta[0] / 10.0;
    glutPostRedisplay();
  }

  else if ((mouse.buttonState & LEFT_BUTTON) && (mouse.buttonState & MIDDLE_BUTTON)) {
    zoom -= delta[1] / 500.0;
    if (zoom < 0.1) zoom = 0.1;
    glutPostRedisplay();
  }

  else if (mouse.buttonState & MIDDLE_BUTTON) {
//    trans += delta / zoom;
    trans += winVecToCanvas(delta);
    glutPostRedisplay();
  }

  else if (mouse.buttonState & LEFT_BUTTON) {
    switch(mode) {
    case MODE_PAINT:
      brushTool_motion(mouse.canvas_pos);
      break;
    case MODE_CLONE:
      cloneTool_motion(mouse.canvas_pos);
      break;
    case MODE_BRUSHSIZE:
      brushsize_motion(mouse.canvas_pos);
      break;
    case MODE_DROPPER:
      dropperTool_mouse(mouse.canvas_pos);
      break;
    }
  }

  mouse.old_pos = mouse.pos;
}

void key(unsigned char key, int x, int y)
{
  switch (key) {
  case '\033':
  case 'q':
    delete canvas;
	  exit(0);
	  break;

  case 'r':
    zoom = 1.0;
    rotate = 0.0;
    break;

  case 'c':
    toggle[key] ^= 1;
    if (toggle['c']) {
      prev_mode = mode;
      mode = MODE_DROPPER;
    } else {
      mode = prev_mode;
    }
    break;

  case 's':
    mode = MODE_BRUSHSIZE;
    break;

  case '=':
  case '+':
    zoom *= 2.0;
    break;
  case '-':
    zoom /= 2.0;
    break;

  case ']':
    exposure_stop += 1.0;
    paramChange();
    break;
  case '[':
    exposure_stop -= 1.0;
    paramChange();
    break;

  case '.':
    rotate -= 90.0;
    break;
  case ',':
    rotate += 90.0;
    break;

  // horizontal/vertical flip
  case 'x':
    flip_x *= -1;
    break;
  case 'y':
    flip_y *= -1;
    break;

  case 'C':
    canvas->Clear(brush->m_color[1]);
    break;

  case 'R':
    if (img) {
      canvas->DrawImage(Vec2i(0, 0), Vec2i(img->GetWidth(), img->GetHeight()), img->GetFormat(), img->GetType(), img->GetData());
    }
    break;

  case 'S':
    canvas->ReloadPrograms();
    break;

  case '1':
    mode = MODE_PAINT;
    brush->SetMode(Brush::PAINT);
    break;
  case '2':
    mode = MODE_AIRBRUSH;
    brush->SetMode(Brush::PAINT);
    break;
  case '3':
    mode = MODE_DROPPER;
    break;
  case '4':
    mode = MODE_CLONE;
    brush->SetMode(Brush::CLONE);
    break;
  case '5':
    mode = MODE_PAINT;
    brush->SetMode(Brush::OFFSET);
    brush->m_color[0].a = 1.0f;
    canvas->SetDisplayMode(2);  // liquify
    break;
  case '6':
    mode = MODE_PAINT;
    brush->SetMode(Brush::BLUR);
    break;
  case '7':
    mode = MODE_PAINT;
    brush->SetMode(Brush::SHARPEN);
    break;

  default:
    toggle[key] ^= 1;
    break;
  }
  glutPostRedisplay();
}

void special(int key, int x, int y)
{
  if (toggle['h']) {
    params->Special(key, x, y);
    paramChange();
    return;
  }
  switch(key) {
  case GLUT_KEY_F1:
  case GLUT_KEY_F2:
  case GLUT_KEY_F3:
  case GLUT_KEY_F4:
    canvas->SetDisplayMode(key - GLUT_KEY_F1);
    break;
  case GLUT_KEY_RIGHT:
    trans += winVecToCanvas(Vec2f(-win_w, 0.0)*0.5);
    break;
  case GLUT_KEY_LEFT:
    trans += winVecToCanvas(Vec2f(win_w, 0.0)*0.5);
    break;
  case GLUT_KEY_UP:
    trans += winVecToCanvas(Vec2f(0.0, -win_h)*0.5);
    break;
  case GLUT_KEY_DOWN:
    trans += winVecToCanvas(Vec2f(0.0, win_h)*0.5);
    break;
  }
  glutPostRedisplay();
}

void reshape(int w, int h)
{
  canvas->Deactivate();

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0, w, 0, h, -1.0, 1.0);

  glMatrixMode(GL_MODELVIEW);
  glViewport(0, 0, w, h);

  win_w = w; win_h = h;
}

void initParams()
{
  // create a new parameter list
  params = new ParamListGL("misc");

  params->AddParam(new Param<float>("brush size", 32, 2.0, 1000.0, 1.0));
  params->AddParam(new Param<float>("brush aspect", 1.0, 0.0, 10.0, 0.1));
  params->AddParam(new Param<float>("brush spacing", brush->m_spacing, 0.0, 1.0, 0.01, &brush->m_spacing));
  params->AddParam(new Param<float>("brush hardness", brush->m_hardness, 0.0, 1.0, 0.01));
  params->AddParam(new Param<float>("airbrush radius", brush->m_airbrush_radius, 0.0, 1000.0, 1.0, &brush->m_airbrush_radius));
  params->AddParam(new Param<int>  ("airbrush no", brush->m_airbrush_no, 1, 1000, 1, &brush->m_airbrush_no));
  params->AddParam(new Param<float>("color r", brush->m_color[0].r, 0.0, 1.0, 0.01, &brush->m_color[0].r));
  params->AddParam(new Param<float>("color g", brush->m_color[0].g, 0.0, 1.0, 0.01, &brush->m_color[0].g));
  params->AddParam(new Param<float>("color b", brush->m_color[0].b, 0.0, 1.0, 0.01, &brush->m_color[0].b));
  params->AddParam(new Param<float>("color a", brush->m_color[0].a, 0.0, 1.0, 0.01, &brush->m_color[0].a));
  params->AddParam(new Param<float>("lightness", lightness, 0.0, 1.0, 0.01, &lightness));
  params->AddParam(new Param<float>("light elevation", light_rx, -M_PI/2.0, M_PI/2.0, 0.1, &light_rx));
  params->AddParam(new Param<float>("light angle", light_rz, 0.0, M_PI*2.0, 0.1, &light_rz));
  params->AddParam(new Param<float>("shininess", canvas->m_shininess, 1.0, 256.0, 1.0, &canvas->m_shininess));
  params->AddParam(new Param<float>("bump scale", canvas->m_heightScale, 0.0, 1.0, 0.1, &canvas->m_heightScale));
  params->AddParam(new Param<float>("exposure", exposure_stop, -10.0, 10.0, 1.0, &exposure_stop));
  params->AddParam(new Param<float>("gamma", canvas->m_gamma, 0.0, 10.0, 0.01, &canvas->m_gamma));
  params->AddParam(new Param<float>("liquify scale", canvas->m_offsetScale, -10.0, 10.0, 1.0, &canvas->m_offsetScale));

//  params->SetUnSelectedColor(0.75, 0.75, 0.75);
}

// get extension pointers
void getExts(void)
{
  if(! glh_init_extensions(
                          "GL_ARB_multitexture "
                          "WGL_ARB_pbuffer "
                          "WGL_ARB_pixel_format "
                          "WGL_ARB_render_texture "
                          "GL_SGIS_generate_mipmap "
                          "GL_VERSION_1_2 "
                          "GL_NV_vertex_program "
                          "GL_NV_fragment_program "
                          "GL_NV_float_buffer"
                           )) {
    fprintf(stderr, "Error - required extensions were not supported: %s", glh_get_unsupported_extensions());
	quitapp(-1);
  }
}

void mainMenu(int i)
{
  key((unsigned char) i, 0, 0);
}

void brushMenu(int i)
{
  key((unsigned char) i, 0, 0);
  if (i == 5) {
    canvas->SetDisplayMode(2);
  }
}

void displayMenu(int i)
{
  canvas->SetDisplayMode(i);
  glutPostRedisplay();
}

void initMenus()
{
  int display_menu = glutCreateMenu(displayMenu);
  glutAddMenuEntry("[F1] Normal", 0);
  glutAddMenuEntry("[F2] Phong", 1);
  glutAddMenuEntry("[F3] Liquify", 2);
  glutAddMenuEntry("[F4] Raw", 3);

  int brush_menu = glutCreateMenu(brushMenu);
  glutAddMenuEntry("[1] Paint", '1');
  glutAddMenuEntry("[2] Airbrush", '2');
  glutAddMenuEntry("[3] Color picker", '3');
  glutAddMenuEntry("[4] Clone", '4');
  glutAddMenuEntry("[5] Liquify", '5');
  glutAddMenuEntry("[6] Blur", '6');
  glutAddMenuEntry("[7] Sharpen", '7');

  int nav_menu = glutCreateMenu(mainMenu);
  glutAddMenuEntry("Zoom in [=]", '=');
  glutAddMenuEntry("Zoom out [-]", '-');
  glutAddMenuEntry("Rotate 90 cw [.]", '.');
  glutAddMenuEntry("Rotate 90 ccw [,]", ',');
  glutAddMenuEntry("Flip x [x]", 'x');
  glutAddMenuEntry("Flip y [y]", 'y');

  int main = glutCreateMenu(mainMenu);
  glutAddSubMenu("Display", display_menu);
  glutAddSubMenu("Brush", brush_menu);
  glutAddSubMenu("Navigation", nav_menu);
  glutAddMenuEntry("Toggle sliders [h]", 'h');
  glutAddMenuEntry("Toggle color palette [c]", 'c');
  glutAddMenuEntry("Toggle brush display [d]", 'd');
  glutAddMenuEntry("Size brush [s]", 's');
  glutAddMenuEntry("Clear canvas [C]", 'C');
  glutAddMenuEntry("Reload image [R]", 'R');
  glutAddMenuEntry("Quit [q]", 'q');
  glutAttachMenu(GLUT_RIGHT_BUTTON);
}

GLuint createTexture(GLenum target, GLuint internalformat, int width, int height, GLuint format, GLuint type, void *pixels)
{
  GLuint texture;
  glGenTextures (1, &texture);
  glBindTexture (target, texture);
  glTexParameteri (target, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri (target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri (target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri (target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
  glTexImage2D (target, 0, internalformat, width, height, 0, 
                format, type, pixels);
  return texture;
}

void initGL(char *filename)
{
  glClearColor(0.25, 0.25, 0.25, 1.0);
//  glClearColor(1.0, 1.0, 1.0, 1.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glDisable(GL_DEPTH_TEST);

  int w = 1024, h = 1024;

  if (filename) {
    // load image
    if (strstr(filename, ".exr")) {
      img = new EXRReader(filename);
    } else if (strstr(filename, ".png")) {
      img = new PNGReader(filename);
    } else if (strstr(filename, ".ppm")) {
      img = new PPMReader(filename);
      ((PPMReader *)img)->ConvertCCD();
    } else {
      fprintf(stderr, "Unsupported file format `%s`\n", filename);
      quitapp(0);
    }
    if (img) {
      w = img->GetWidth();
      h = img->GetHeight();
    }
  }

  getExts();

  // create canvas
  canvas = new Canvas(w, h, true);  // float
//  canvas = new Canvas(w, h, false);
  canvas->Clear(Colorf(1.0, 1.0, 1.0, 1.0));

  if (img && (img->GetType() == GL_HALF_FLOAT_NV)) {
    canvas->m_gamma = 1.0 / 2.0;
  } else {
    canvas->m_gamma = 1.0;
  }

  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);  // stupid OpenGL default value
//  glPixelStorei(GL_UNPACK_SWAP_BYTES, GL_TRUE);
  if (img) {
    // draw image
    canvas->DrawImage(Vec2i(0, 0), Vec2i(img->GetWidth(), img->GetHeight()), img->GetFormat(), img->GetType(), img->GetData());
    // create texture for liquify mode
    canvas->m_imageTex = createTexture(GL_TEXTURE_RECTANGLE_NV, GL_FLOAT_RGBA16_NV, img->GetWidth(), img->GetHeight(), img->GetFormat(), img->GetType(), img->GetData());
  }

  brush = new Brush(Vec2f(32.0, 32.0), 0.1, canvas);
  brush->CreateCircleTexture(256, 256, 0.0, true);
//  brush->CreateCircleTexture(256, 256, 0.0, false);
  brush->m_color[0] = Colorf(1, 0, 0, 0.1);
  brush->m_color[1] = Colorf(0, 0, 0, 0);

  brush->m_airbrush_no = 5;
  brush->m_airbrush_radius = 100;

  setLightDirection();

  canvas->Deactivate();

  checkErrors("initGL");
}

int main(int argc, char **argv)
{
  glutInit(&argc, argv);

  glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
  glutInitWindowSize(win_w, win_h);
  (void) glutCreateWindow("nvpaint");

  glutDisplayFunc(display);
  glutKeyboardFunc(key);
  glutSpecialFunc(special);
  glutMouseFunc(mouse_func);
  glutMotionFunc(motion);
  glutReshapeFunc(reshape);
//  glutSetCursor(GLUT_CURSOR_CROSSHAIR);

  char *image_filename = "../../../../media/textures/hdr/StillLife.pt.exr"; // default image
  if (argc > 1) {
    image_filename = argv[1];
  }
  initGL(image_filename);
  initParams();
  initMenus();

  glutMainLoop();
  return 0;
}
