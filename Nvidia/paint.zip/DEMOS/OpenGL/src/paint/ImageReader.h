#ifndef IMAGEREADER_H
#define IMAGEREADER_H
#include <GL/glut.h>

class ImageReader {
public:
  ImageReader(char *filename) {};
  ~ImageReader() {};

  virtual int GetWidth() { return m_w; }
  virtual int GetHeight() { return m_h; }

  virtual void *GetData() = 0;
  virtual GLenum GetFormat() = 0;
  virtual GLenum GetType() = 0;

//  virtual GLuint LoadTexture();
//  virtual void DrawPixels(int x, int y);
protected:
  int m_w, m_h;
};
#endif
