#include <ImfRgbaFile.h>
#include <ImfArray.h>
#include "ImageReader.h"
#include <GL/glext.h>

class EXRReader : public ImageReader {
public:
  EXRReader(char *filename);
  ~EXRReader();

  void *GetData() { return m_pixels[0]; }
  GLenum GetFormat() { return GL_RGBA; }
  GLenum GetType() { return GL_HALF_FLOAT_NV; }

//  GLuint LoadTexture();
//  void DrawPixels(int x, int y);

private:
  Imf::Array2D<Imf::Rgba> m_pixels;
};
