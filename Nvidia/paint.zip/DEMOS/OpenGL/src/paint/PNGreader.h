#include "ImageReader.h"
#include "glh/glh_array.h"

class PNGReader : public ImageReader {
public:
  PNGReader(char *filename);
  ~PNGReader();

  void *GetData() { return m_pixels->get_pointer(); }
  GLenum GetFormat() { return GL_RGB; }
  GLenum GetType() { return GL_UNSIGNED_BYTE; }

  int GetWidth() { return m_pixels->get_width(); }
  int GetHeight() { return m_pixels->get_height(); }

private:
  glh::array2<glh::vec3ub> *m_pixels;
};