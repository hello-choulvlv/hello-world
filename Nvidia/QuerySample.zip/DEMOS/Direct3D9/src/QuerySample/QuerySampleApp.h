#pragma once
//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
enum TIDCTags
{
    IDC_TOGGLEFULLSCREEN = 0,
    IDC_TOGGLEREF,
    IDC_CHANGEDEVICE,
    IDC_RENDERLOAD,
    IDC_RENDERLOADDESC,
    IDC_LAST
};

enum TQueryTypes
{
    QUERYTYPE_VCACHE = 0,
    QUERYTYPE_RESOURCEMGR,
    QUERYTYPE_VERTEXSTATS,
    QUERYTYPE_EVENT,
    QUERYTYPE_OCCLUSION,
    QUERYTYPE_TIMESTAMP,
    QUERYTYPE_TIMESTAMPDISJOINT,
    QUERYTYPE_TIMESTAMPFREQ,
    QUERYTYPE_PIPETIMINGS,
    QUERYTYPE_INTERFACETIMINGS,
    QUERYTYPE_VERTEXTIMINGS,
    QUERYTYPE_PIXELTIMINGS,
    QUERYTYPE_BWTIMINGS,
    QUERYTYPE_CACHEUTIL,
    QUERYTYPE_TOTALNUMBER
};

WCHAR gUIText[QUERYTYPE_TOTALNUMBER][64] = 
{
    L"Vertex Cache Size:  ",
    L"Resource Stats:     ", 
    L"Vertex Stats:       ",       
    L"Event Query Status: ", 
    L"Visible pixels:     ",     
    L"Timestamp:          ",          
    L"Timestamp Disjoint: ", 
    L"Timestamp Frequency:",
    L"Pipeline Timings:   ",   
    L"Interface Timings:  ",  
    L"Vertex Timings:     ",     
    L"Pixel Timings:      ",      
    L"Bandwidth Timings:  ",  
    L"Cache Utilization:  ",  
};
WCHAR gUIResults[QUERYTYPE_TOTALNUMBER][128];

//--------------------------------------------------------------------------------------
// Forward declarations 
//--------------------------------------------------------------------------------------
bool    CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext );
bool    CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext );
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
void    CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
void    CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext );
void    CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
void    CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );
void    CALLBACK OnLostDevice( void* pUserContext );
void    CALLBACK OnDestroyDevice( void* pUserContext );

void    InitApp();
void    RenderText();

//--------------------------------------------------------------------------------------
// Global Variables
//--------------------------------------------------------------------------------------
CModelViewerCamera      g_Camera;               // A model viewing camera
CDXUTDialog             g_HUD;                  // dialog for standard controls
CDXUTDialogResourceManager g_DialogResourceManager; // manager for shared resources of dialogs
CD3DSettingsDlg         g_SettingsDlg;          // Device settings dialog
ID3DXFont*              g_pFont = NULL;         // Font for drawing text
ID3DXFont*              g_pFont2 = NULL;        // Font for drawing result
ID3DXSprite*            g_pTextSprite = NULL;   // Sprite for batching draw text calls
bool					g_bShowHelp = false;
bool					g_bShowUI = true;
int                     g_RenderLoad = 0; 

void TestResourceMgrQuery();
void TestVertexStatsQuery();
void TestEventQuery();
void TestOcclusionQuery();
void TestTimeStampQuery();
void TestTimeStampDisjointQuery();
void TestTimeStampFreqQuery();
//  void ResetTimeStamps();

int const               kNumTriangles   = 32;
UINT64                  gLastFreq       = 0L;
INT64                   gWalltimeDiff   = 0L;
LPDIRECT3DVERTEXBUFFER9 g_pVB;                  // Vextex buffer 

// Queries of various types that this app tests
IDirect3DQuery9     *g_pVCacheQuery             = NULL;
IDirect3DQuery9     *g_pResourceMgrQuery        = NULL;
IDirect3DQuery9     *g_pVertexStatsQuery        = NULL;
IDirect3DQuery9     *g_pEventQuery              = NULL;
IDirect3DQuery9     *g_pOcclusionQuery          = NULL;
IDirect3DQuery9     *g_pTimeStampQuery          = NULL;
IDirect3DQuery9     *g_pTimeStampDisjointQuery  = NULL;
IDirect3DQuery9     *g_pTimeStampFreqQuery      = NULL;
IDirect3DQuery9     *g_pPipeTimingsQuery        = NULL;
IDirect3DQuery9     *g_pInterfaceTimingsQuery   = NULL;
IDirect3DQuery9     *g_pVertexTimingsQuery      = NULL;
IDirect3DQuery9     *g_pPixelTimingsQuery       = NULL;
IDirect3DQuery9     *g_pBWTimingsQuery          = NULL;
IDirect3DQuery9     *g_pCacheUtilQuery          = NULL;

enum TQueryState 
{
    QUERY_UNAVAILABLE  = 0,
    QUERY_BEGIN_ISSUED,
    QUERY_END_ISSUED,
    QUERY_RETURNED,
};

TQueryState         g_QueryState[QUERYTYPE_TOTALNUMBER];


#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_DIFFUSE)
struct CUSTOMVERTEX
{
    D3DXVECTOR3 position;       // vertex position
    D3DCOLOR    color;          // vertex color
};

