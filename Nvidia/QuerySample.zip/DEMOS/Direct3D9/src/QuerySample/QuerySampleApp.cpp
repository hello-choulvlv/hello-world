#define STRICT
#include "nvafx.h"
#include "QuerySampleApp.h"


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Set the callback functions. These functions allow the sample framework to notify
    // the application about device changes, user input, and windows messages.  The 
    // callbacks are optional so you need only set callbacks for events you're interested 
    // in. However, if you don't handle the device reset/lost callbacks then the sample 
    // framework won't be able to reset your device since the application must first 
    // release all device resources before resetting.  Likewise, if you don't handle the 
    // device created/destroyed callbacks then the sample framework won't be able to 
    // recreate your device resources.
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackKeyboard( KeyboardProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Show the cursor and clip it when in full screen
    DXUTSetCursorSettings( true, true );

    InitApp();

    // Initialize the sample framework and create the desired Win32 window and Direct3D 
    // device for the application. Calling each of these functions is optional, but they
    // allow you to set several options which control the behavior of the framework.
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTCreateWindow( L"QuerySample" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, 512, 512, IsDeviceAcceptable, ModifyDeviceSettings );

    // Pass control to the sample framework for handling the message pump and 
    // dispatching render calls. The sample framework will call your FrameMove 
    // and FrameRender callback when there is idle time between handling window messages.
    DXUTMainLoop();

    // Perform any application-level cleanup here. Direct3D device resources are released within the
    // appropriate callback functions and therefore don't require any cleanup code here.

    return DXUTGetExitCode();
}


//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void InitApp()
{
    // Initialize dialogs
    int     y = 10;
    g_SettingsDlg.Init( &g_DialogResourceManager );
    g_HUD.Init( &g_DialogResourceManager );
    g_HUD.SetCallback( OnGUIEvent );
    g_HUD.AddButton( IDC_TOGGLEFULLSCREEN,  L"Toggle full screen",  35, y += 24, 125, 22 );
    g_HUD.AddButton( IDC_TOGGLEREF,         L"Toggle REF (F3)",     35, y += 24, 125, 22, VK_F3 );
    g_HUD.AddButton( IDC_CHANGEDEVICE,      L"Change device (F2)",  35, y += 24, 125, 22, VK_F2 );
    g_HUD.AddStatic( IDC_RENDERLOADDESC,    L"Render Load",         35, y += 28, 125, 22 );
    g_HUD.AddSlider( IDC_RENDERLOAD,                                35, y += 20, 125, 22, 0, 100, g_RenderLoad );
}


//--------------------------------------------------------------------------------------
// Called during device initialization, this code checks the device for some 
// minimum set of capabilities, and rejects those that don't pass by returning false.
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    BOOL bCapsAcceptable = TRUE;

    if (!bCapsAcceptable)
        return false;

    return true;
}


//--------------------------------------------------------------------------------------
// This callback function is called immediately before a device is created to allow the 
// application to modify the device settings. The supplied pDeviceSettings parameter 
// contains the settings that the framework has selected for the new device, and the 
// application can make any desired changes directly to this structure.  Note however that 
// the sample framework will not correct invalid device settings so care must be taken 
// to return valid device settings, otherwise IDirect3D9::CreateDevice() will fail.  
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
    return true;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// created, which will happen during application initialization and windowed/full screen 
// toggles. This is the best location to create D3DPOOL_MANAGED resources since these 
// resources need to be reloaded whenever the device is destroyed. Resources created  
// here should be released in the OnDestroyDevice callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

    V_RETURN( g_DialogResourceManager.OnCreateDevice( pd3dDevice ) );
    V_RETURN( g_SettingsDlg.OnCreateDevice( pd3dDevice ) );

    // Initialize the font
    V_RETURN( D3DXCreateFont( pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                         OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                         L"Arial", &g_pFont ) );
    V_RETURN( D3DXCreateFont( pd3dDevice, 14, 0, 0, 1, FALSE, DEFAULT_CHARSET, 
                         OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                         L"Arial", &g_pFont2 ) );

    // Set up our view matrix. A view matrix can be defined given an eye point and
    // a point to lookat. Here, we set the eye five units back along the z-axis and 
	// up three units and look at the origin.
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3(0.0f, 0.0f, -5.0f);
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	g_Camera.SetViewParams( &vFromPt, &vLookatPt);

	return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// reset, which will happen after a lost device scenario. This is the best location to 
// create D3DPOOL_DEFAULT resources since these resources need to be reloaded whenever 
// the device is lost. Resources created here should be released in the OnLostDevice 
// callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

    V_RETURN( g_DialogResourceManager.OnResetDevice() );
    V_RETURN( g_SettingsDlg.OnResetDevice() );

    if( g_pFont )
        V_RETURN( g_pFont->OnResetDevice() );
    if( g_pFont2 )
        V_RETURN( g_pFont2->OnResetDevice() );

    // Create a sprite to help batch calls when drawing many lines of text
    V_RETURN( D3DXCreateSprite( pd3dDevice, &g_pTextSprite ) );

    // Setup the camera's projection parameters
    float fAspectRatio = pBackBufferSurfaceDesc->Width / (FLOAT)pBackBufferSurfaceDesc->Height;
    g_Camera.SetProjParams( D3DX_PI/4, fAspectRatio, 0.1f, 1000.0f );
    g_Camera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );

    pd3dDevice->SetRenderState(D3DRS_ZENABLE,  TRUE);
    pd3dDevice->SetRenderState(D3DRS_ZFUNC,    D3DCMP_LESS);
    pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

    // Create the vertex buffer
    float const   kPionWheelRadius = 1.f;
    unsigned char vertexColor = 0;

    V_RETURN( pd3dDevice->CreateVertexBuffer(3*kNumTriangles*sizeof(CUSTOMVERTEX),
                                                     D3DUSAGE_WRITEONLY, D3DFVF_CUSTOMVERTEX,
                                                     D3DPOOL_DEFAULT, &g_pVB, 
                                                     NULL));

    // Fill the vertex buffer with 2 triangles
    CUSTOMVERTEX* pVertices;

    V_RETURN(g_pVB->Lock( 0, 0, (VOID**)&pVertices, 0));
    
    for ( int i=0; i<kNumTriangles; i++, pVertices+=3, vertexColor^=0xff )
    {
        float fStartAngle = (float(i) / float(kNumTriangles)) * D3DX_PI * 2.f;
        float fEndAngle   = (float(i+1) / float(kNumTriangles)) * D3DX_PI * 2.f;

        pVertices[0].color    = D3DCOLOR_ARGB(0xff, vertexColor, vertexColor, vertexColor);
        pVertices[1].color    = D3DCOLOR_ARGB(0xff, vertexColor, vertexColor, vertexColor);
        pVertices[2].color    = D3DCOLOR_ARGB(0xff, vertexColor, vertexColor, vertexColor);
        pVertices[0].position = D3DXVECTOR3( 0.f, 0.f, 0.f );
        pVertices[1].position = D3DXVECTOR3( kPionWheelRadius*cosf(fEndAngle), kPionWheelRadius*sinf(fEndAngle), 0.f );
        pVertices[2].position = D3DXVECTOR3( kPionWheelRadius*cosf(fStartAngle), kPionWheelRadius*sinf(fStartAngle), 0.f );
    }
    g_pVB->Unlock();

    // Initialize the whole array to unavavailable...
    for (int i = 0; i < QUERYTYPE_TOTALNUMBER; ++i)
        g_QueryState[i] = QUERY_UNAVAILABLE;

    // Allocate all the various queries    
    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_VCACHE, &g_pVCacheQuery);
    // MMW: not supported in rel75 drivers...
    g_QueryState[QUERYTYPE_VCACHE] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    // The resource manager query is only supported in the D3D Debug runtime.
    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_RESOURCEMANAGER, &g_pResourceMgrQuery);
    g_QueryState[QUERYTYPE_RESOURCEMGR] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    // The vertex Stats query is only supported in the D3D Debug runtime.
    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_VERTEXSTATS, &g_pVertexStatsQuery);
    g_QueryState[QUERYTYPE_VERTEXSTATS] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_EVENT, &g_pEventQuery);
    g_QueryState[QUERYTYPE_EVENT] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_OCCLUSION, &g_pOcclusionQuery);
    g_QueryState[QUERYTYPE_OCCLUSION] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_TIMESTAMP, &g_pTimeStampQuery);
    g_QueryState[QUERYTYPE_TIMESTAMP] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_TIMESTAMPDISJOINT, &g_pTimeStampDisjointQuery);
    g_QueryState[QUERYTYPE_TIMESTAMPDISJOINT] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_TIMESTAMPFREQ, &g_pTimeStampFreqQuery);
    g_QueryState[QUERYTYPE_TIMESTAMPFREQ] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    // MMW: None of the following are supported in rel75 drivers...
    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_PIPELINETIMINGS, &g_pPipeTimingsQuery);
    g_QueryState[QUERYTYPE_PIPETIMINGS] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_INTERFACETIMINGS, &g_pInterfaceTimingsQuery);
    g_QueryState[QUERYTYPE_INTERFACETIMINGS] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_VERTEXTIMINGS, &g_pVertexTimingsQuery);
    g_QueryState[QUERYTYPE_VERTEXTIMINGS] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_PIXELTIMINGS, &g_pPixelTimingsQuery);
    g_QueryState[QUERYTYPE_PIXELTIMINGS] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_BANDWIDTHTIMINGS, &g_pBWTimingsQuery);
    g_QueryState[QUERYTYPE_BWTIMINGS] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    hr = pd3dDevice->CreateQuery( D3DQUERYTYPE_CACHEUTILIZATION, &g_pCacheUtilQuery);
    g_QueryState[QUERYTYPE_CACHEUTIL] = (hr == S_OK) ? QUERY_RETURNED : QUERY_UNAVAILABLE;

    // rearrange the GUI elements depending on which queries are supported
    g_HUD.SetLocation( 0, 0 );
    g_HUD.SetSize( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );

	int iY = 15;
    g_HUD.GetControl( IDC_TOGGLEFULLSCREEN )->SetLocation( pBackBufferSurfaceDesc->Width - 135, iY);
    g_HUD.GetControl( IDC_TOGGLEREF )       ->SetLocation( pBackBufferSurfaceDesc->Width - 135, iY += 24 );
    g_HUD.GetControl( IDC_CHANGEDEVICE )    ->SetLocation( pBackBufferSurfaceDesc->Width - 135, iY += 24 );
    g_HUD.GetControl( IDC_RENDERLOADDESC )  ->SetLocation( pBackBufferSurfaceDesc->Width - 135, iY += 28 );
    g_HUD.GetControl( IDC_RENDERLOAD )      ->SetLocation( pBackBufferSurfaceDesc->Width - 135, iY += 20 );

    for (i = 0, iY += 48; i < QUERYTYPE_TOTALNUMBER; ++i, iY += 24)
    {
        _stprintf(gUIResults[i], TEXT("%s"), (g_QueryState[i] == QUERY_UNAVAILABLE) ? TEXT("Unavailable") : TEXT("Available"));
    }

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called once at the beginning of every frame. This is the
// best location for your application to handle updates to the scene, but is not 
// intended to contain actual rendering calls, which should instead be placed in the 
// OnFrameRender callback.  
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
    g_Camera.FrameMove( fElapsedTime );

    float        time = float(::timeGetTime()) * 0.001f;
    static float lasttime   = time;
    static float fWorldRotZ = 0.0f;


    fWorldRotZ += (time-lasttime)*D3DX_PI*0.03125f;
    if (fWorldRotZ >= D3DX_PI*2.f)
        fWorldRotZ -= D3DX_PI*2.f;

    // Update the world state according to user input
    D3DXMATRIX matWorld;
    D3DXMATRIX matRotZ;

    D3DXMatrixRotationZ(&matWorld, fWorldRotZ);
    pd3dDevice->SetTransform(D3DTS_WORLD, &matWorld);

    lasttime = time;
}


//--------------------------------------------------------------------------------------
// This callback function will be called at the end of every frame to perform all the 
// rendering calls for the scene, and it will also be called if the window needs to be 
// repainted. After this function has returned, the sample framework will call 
// IDirect3DDevice9::Present to display the contents of the next buffer in the swap chain
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
    // If the settings dialog is being shown, then
    // render it instead of rendering the app's scene
    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.OnRender( fElapsedTime );
        return;
    }

    HRESULT hr;

	// Begin the scene
    if (SUCCEEDED(pd3dDevice->BeginScene()))
    {
        // Issue the queries that can issue a Begin
        if (g_QueryState[QUERYTYPE_OCCLUSION] == QUERY_RETURNED)
        {
            hr = g_pOcclusionQuery->Issue(D3DISSUE_BEGIN);
            assert(hr == S_OK);
            g_QueryState[QUERYTYPE_OCCLUSION] = QUERY_BEGIN_ISSUED;
        }
        if (g_QueryState[QUERYTYPE_TIMESTAMPDISJOINT] == QUERY_RETURNED)
        {
            hr = g_pTimeStampDisjointQuery->Issue(D3DISSUE_BEGIN);
            assert(hr == S_OK);
            g_QueryState[QUERYTYPE_TIMESTAMPDISJOINT] = QUERY_BEGIN_ISSUED;
        }

        // Clear the viewport
        pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                            0xff301030, 1.0f, 0L);
        pd3dDevice->SetTransform(D3DTS_PROJECTION, g_Camera.GetProjMatrix());

        D3DXMATRIX matTranslate;
        D3DXMatrixTranslation(&matTranslate, -1.0f, 0.0f, 0.0f);
        D3DXMatrixMultiply(&matTranslate, g_Camera.GetViewMatrix(), &matTranslate);    
        pd3dDevice->SetTransform(D3DTS_VIEW, &matTranslate);
        pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
        pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOMVERTEX));
        pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);

        // Arbtrarily increase render load...
        for (int i = 0; i <= 200*g_RenderLoad; ++i)
        {
            hr = pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, kNumTriangles);
            assert(hr == S_OK);
        }

        // Issue these before drawing the UI: so we get tris and verts of the pinwheel only.
        TestVertexStatsQuery();
        TestOcclusionQuery();

        // Render stats and help text  
        RenderText();
		V( g_HUD.OnRender( fElapsedTime ) );
        V( pd3dDevice->EndScene() );

        TestResourceMgrQuery();
        TestEventQuery();
        TestTimeStampQuery();
        TestTimeStampDisjointQuery();
        TestTimeStampFreqQuery();
    }
}


//--------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//--------------------------------------------------------------------------------------
void RenderText()
{
    // The helper object simply helps keep track of text position, and color
    // and then it calls pFont->DrawText( m_pSprite, strMsg, -1, &rc, DT_NOCLIP, m_clr );
    // If NULL is passed in as the sprite object, then it will work however the 
    // pFont->DrawText() will not be batched together.  Batching calls will improves performance.
    CDXUTTextHelper txtHelper( g_pFont, g_pTextSprite, 15 );
    const D3DSURFACE_DESC* pd3dsdBackBuffer = DXUTGetBackBufferSurfaceDesc();

	// Output statistics
	txtHelper.Begin();
	txtHelper.SetInsertionPos( 5, 15 );
	if( g_bShowUI )
	{
		txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
		txtHelper.DrawTextLine( DXUTGetFrameStats() );
		txtHelper.DrawTextLine( DXUTGetDeviceStats() );

		// Display any additional information text here

		if( !g_bShowHelp )
		{
			txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ));
			txtHelper.DrawTextLine( TEXT("F1      - Toggle help text") );
		}
	}

	if( g_bShowHelp )
	{
		// Display help text here
		txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
		txtHelper.DrawTextLine( TEXT("F1      - Toggle help text") );
		txtHelper.DrawTextLine( TEXT("H       - Toggle UI") );
		txtHelper.DrawTextLine( TEXT("ESC  - Quit") );
	}
    txtHelper.End();

    // Output Query Descriptions
    CDXUTTextHelper txtHelper2( g_pFont2, g_pTextSprite, 15 );
    txtHelper2.Begin();
	txtHelper2.SetInsertionPos( pd3dsdBackBuffer->Width - 250, 159);

    for (int i = 0; i < QUERYTYPE_TOTALNUMBER; ++i)
    {
	    txtHelper2.SetForegroundColor( 
                    (g_QueryState[i] == QUERY_UNAVAILABLE) ? D3DCOLOR_XRGB(0xa0, 0xa0, 0xa0)
                                                           : D3DCOLOR_XRGB(0xff, 0xff, 0xff));    
	    txtHelper2.DrawTextLine( gUIText[i] );
    }

    // Output Query statuses
	txtHelper2.SetInsertionPos( pd3dsdBackBuffer->Width - 140, 159);

    for (int i = 0; i < QUERYTYPE_TOTALNUMBER; ++i)
    {
	    txtHelper2.SetForegroundColor( 
                    (g_QueryState[i] == QUERY_UNAVAILABLE) ? D3DCOLOR_XRGB(0xa0, 0xa0, 0xa0)
                                                           : D3DCOLOR_XRGB(0xff, 0xff, 0xff));    
	    txtHelper2.DrawTextLine( gUIResults[i] );
    }
    txtHelper2.End();
}


//--------------------------------------------------------------------------------------
// Before handling window messages, the sample framework passes incoming windows 
// messages to the application through this callback function. If the application sets 
// *pbNoFurtherProcessing to TRUE, then the sample framework will not process this message.
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext )
{
    // Always allow dialog resource manager calls to handle global messages
    // so GUI state is updated correctly
    g_DialogResourceManager.MsgProc( hWnd, uMsg, wParam, lParam );

    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.MsgProc( hWnd, uMsg, wParam, lParam );
        return 0;
    }

    // Give the dialogs a chance to handle the message first
    *pbNoFurtherProcessing = g_HUD.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    // Pass all remaining windows messages to camera so it can respond to user input
    g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

    return 0;
}


//--------------------------------------------------------------------------------------
// As a convenience, the sample framework inspects the incoming windows messages for
// keystroke messages and decodes the message parameters to pass relevant keyboard
// messages to the application.  The framework does not remove the underlying keystroke 
// messages, which are still passed to the application's MsgProc callback.
//--------------------------------------------------------------------------------------
void CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext )
{
	if( bKeyDown )
	{
		switch( nChar )
		{
		case VK_F1:
			g_bShowHelp = !g_bShowHelp;
			break;

		case 'H':
		case 'h':
			g_bShowUI = !g_bShowUI;
			for( int i = 0; i < IDC_LAST; i++ )
				g_HUD.GetControl(i)->SetVisible( g_bShowUI );
			break;
		}
	}
}

//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext )
{
	switch( nControlID )
    {
        case IDC_TOGGLEFULLSCREEN: DXUTToggleFullScreen(); break;
        case IDC_TOGGLEREF:        DXUTToggleREF(); break;
        case IDC_CHANGEDEVICE:     g_SettingsDlg.SetActive( !g_SettingsDlg.IsActive() ); break;
        case IDC_RENDERLOAD:       g_RenderLoad = g_HUD.GetSlider( IDC_RENDERLOAD )->GetValue(); break;
    }
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// entered a lost state and before IDirect3DDevice9::Reset is called. Resources created
// in the OnResetDevice callback should be released here, which generally includes all 
// D3DPOOL_DEFAULT resources. See the "Lost Devices" section of the documentation for 
// information about lost devices.
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
    g_DialogResourceManager.OnLostDevice();
    g_SettingsDlg.OnLostDevice();

    if( g_pFont )
        g_pFont->OnLostDevice();
    if( g_pFont2 )
        g_pFont2->OnLostDevice();

	SAFE_RELEASE(g_pTextSprite);
    SAFE_RELEASE(g_pVB);

    SAFE_RELEASE(g_pVCacheQuery);
    SAFE_RELEASE(g_pResourceMgrQuery);
    SAFE_RELEASE(g_pVertexStatsQuery);
    SAFE_RELEASE(g_pEventQuery);
    SAFE_RELEASE(g_pOcclusionQuery);
    SAFE_RELEASE(g_pTimeStampQuery);
    SAFE_RELEASE(g_pTimeStampDisjointQuery);
    SAFE_RELEASE(g_pTimeStampFreqQuery);
    SAFE_RELEASE(g_pPipeTimingsQuery);
    SAFE_RELEASE(g_pInterfaceTimingsQuery);
    SAFE_RELEASE(g_pVertexTimingsQuery);
    SAFE_RELEASE(g_pPixelTimingsQuery);
    SAFE_RELEASE(g_pBWTimingsQuery);
    SAFE_RELEASE(g_pCacheUtilQuery);
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// been destroyed, which generally happens as a result of application termination or 
// windowed/full screen toggles. Resources created in the OnCreateDevice callback 
// should be released here, which generally includes all D3DPOOL_MANAGED resources. 
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
    g_DialogResourceManager.OnDestroyDevice();
    g_SettingsDlg.OnDestroyDevice();

    SAFE_RELEASE(g_pFont);
    SAFE_RELEASE(g_pFont2);
}

//--------------------------------------------------------------------------------------
// TestResourceMgrQuery()
// Issues and gets data for the resource manager.  Use a debugger to examine values 
// inside the returned data structure
//--------------------------------------------------------------------------------------
void TestResourceMgrQuery()
{
    HRESULT hr;

    if (g_QueryState[QUERYTYPE_RESOURCEMGR] == QUERY_UNAVAILABLE)
        return;

    if (g_QueryState[QUERYTYPE_RESOURCEMGR] == QUERY_RETURNED)
    {
        hr = g_pResourceMgrQuery->Issue(D3DISSUE_END);
        assert(hr == S_OK);
        g_QueryState[QUERYTYPE_RESOURCEMGR] = QUERY_END_ISSUED;
    }

    D3DDEVINFO_RESOURCEMANAGER  resourceData;

    if (   (g_QueryState[QUERYTYPE_RESOURCEMGR] == QUERY_END_ISSUED) 
        && (g_pResourceMgrQuery->GetData((void *) &resourceData, sizeof(D3DDEVINFO_RESOURCEMANAGER), 0) == S_OK))
    {
        // resourceData has valid entries now: it essentially describes the entire resource 
        // manager state broken down by D3DRESOURCETYPE, see also doc entry for 'D3DDEVINFO_RESOURCEMANAGER'
        _stprintf(gUIResults[QUERYTYPE_RESOURCEMGR], TEXT("%d textures used"), 
            resourceData.stats[D3DRTYPE_TEXTURE].NumUsed);
        g_QueryState[QUERYTYPE_RESOURCEMGR] = QUERY_RETURNED;
    }
    else
    {
        // the query returns immediately
        assert(false);
    }
}

//--------------------------------------------------------------------------------------
// TestVertexStatsQuery()
// Issues and gets data for vertex stats.  Use a debugger to examine values 
// inside the returned data structure
//--------------------------------------------------------------------------------------
void TestVertexStatsQuery() 
{
    HRESULT hr;

    if (g_QueryState[QUERYTYPE_VERTEXSTATS] == QUERY_UNAVAILABLE)
        return;

    if (g_QueryState[QUERYTYPE_VERTEXSTATS] == QUERY_RETURNED)
    {
        hr = g_pVertexStatsQuery->Issue(D3DISSUE_END);
        assert(hr == S_OK);
        g_QueryState[QUERYTYPE_VERTEXSTATS] = QUERY_END_ISSUED;
    }

    D3DDEVINFO_D3DVERTEXSTATS  vertexStatsData;

    if (   (g_QueryState[QUERYTYPE_VERTEXSTATS] == QUERY_END_ISSUED) 
        && (g_pVertexStatsQuery->GetData((void *) &vertexStatsData, sizeof(D3DDEVINFO_D3DVERTEXSTATS), 0) == S_OK))
    {
        // vertexStatsData has valid entries now: it describes how many triangles were rendered and 
        // how many generated from clipping
        _stprintf(gUIResults[QUERYTYPE_VERTEXSTATS], TEXT("%d tris rendered (%d from clip)"), 
            vertexStatsData.NumRenderedTriangles, 
            vertexStatsData.NumExtraClippingTriangles);
        g_QueryState[QUERYTYPE_VERTEXSTATS] = QUERY_RETURNED;
    }
    else
    {
        // the query returns immediately
        assert(false);
    }
}

//--------------------------------------------------------------------------------------
// TestEventQuery()
// Checks return of the event query.
// Event queries are useful to check if the GPU has processed everything up to and 
// including the event query.
//--------------------------------------------------------------------------------------
void TestEventQuery() 
{
    HRESULT hr;

    if (g_QueryState[QUERYTYPE_EVENT] == QUERY_RETURNED)
    {
        hr = g_pEventQuery->Issue(D3DISSUE_END);
        assert(hr == S_OK);
        g_QueryState[QUERYTYPE_EVENT] = QUERY_END_ISSUED;
    }

    BOOL    eventData;
    _stprintf(gUIResults[QUERYTYPE_EVENT], TEXT("Event query issued..."));

    // Event queries are typically delayed, ie not available immediately
    if (   (g_QueryState[QUERYTYPE_EVENT] == QUERY_END_ISSUED) 
        && (g_pEventQuery->GetData((void *) &eventData, sizeof(BOOL), 0) == S_OK))
    {
        // eventData is valid now: it should always be true. 
        assert(eventData);
        g_QueryState[QUERYTYPE_EVENT] = QUERY_RETURNED;
        _stprintf(gUIResults[QUERYTYPE_EVENT], TEXT("Event query consumed!"));
    }
}

//--------------------------------------------------------------------------------------
// TestOcclusionQuery()
// Checks return of the occlusion query.
// Occlusion queries count how many pixels passed the z-test, eg, one can render 
// bounding volumes of objects w/ color and z-write turned off to see if any of 
// the pixels would actually pass the z-test.  If yes, the object is (at least 
// partially) visible.
//--------------------------------------------------------------------------------------
void TestOcclusionQuery() 
{
    HRESULT hr;

    if (g_QueryState[QUERYTYPE_OCCLUSION] == QUERY_BEGIN_ISSUED)
    {
        hr = g_pOcclusionQuery->Issue(D3DISSUE_END);
        assert(hr == S_OK);
        g_QueryState[QUERYTYPE_OCCLUSION] = QUERY_END_ISSUED;
    }

    DWORD   numPixelsVisible;

    // Results of occlusion queries are typically delayed, ie not available immediately
    if (   (g_QueryState[QUERYTYPE_OCCLUSION] == QUERY_END_ISSUED) 
        && (g_pOcclusionQuery->GetData((void *) &numPixelsVisible, sizeof(DWORD), 0) == S_OK))
    {
        // numPixelsVisible is valid now: it contains how many pixels were rendered
        DWORD   pixelsk = static_cast<DWORD>(static_cast<float>(numPixelsVisible)/1024.0f + .5f);
        _stprintf(gUIResults[QUERYTYPE_OCCLUSION], TEXT("%dk pixels visible"), pixelsk);
        g_QueryState[QUERYTYPE_OCCLUSION] = QUERY_RETURNED;
    }
}

//--------------------------------------------------------------------------------------
// TestTimeStampQuery()
// Checks the time stamp query.
// A time stamp query inserts a token into the push buffer: when that token reaches 
// the GPU it becomes signalled and records when it reached the GPU.
//--------------------------------------------------------------------------------------
void TestTimeStampQuery()
{
    HRESULT                 hr;
    static UINT64           lastEvent = 0L;

    if (g_QueryState[QUERYTYPE_TIMESTAMP] == QUERY_RETURNED)
    {
        hr = g_pTimeStampQuery->Issue(D3DISSUE_END);
        assert(hr == S_OK);
        g_QueryState[QUERYTYPE_TIMESTAMP] = QUERY_END_ISSUED;
    }

    UINT64          eventData;
    // Time stamp queries are typically delayed, ie not available immediately
    if (   (g_QueryState[QUERYTYPE_TIMESTAMP] == QUERY_END_ISSUED) 
        && (g_pTimeStampQuery->GetData((void *) &eventData, sizeof(UINT64), 0) == S_OK))
    {
        if (gLastFreq > 0L)
        {
            // eventData is valid now: it contains at what time the event was processed by the GPU.
            UINT64 const     kDiffToPrevious = (eventData-lastEvent)/(gLastFreq/1000);

            _stprintf(gUIResults[QUERYTYPE_TIMESTAMP], TEXT("%ldms to previous"), kDiffToPrevious);
            lastEvent = eventData;
        }
        g_QueryState[QUERYTYPE_TIMESTAMP] = QUERY_RETURNED;
    }
}

//--------------------------------------------------------------------------------------
// TestTimeStampDisjointQuery()
// This query gets signalled when/if the timer frequency changes.  For example, on 
// laptops running in battery mode and dialing processor speed up and down based on
// load.
//--------------------------------------------------------------------------------------
void TestTimeStampDisjointQuery()
{
    HRESULT hr;

    if (g_QueryState[QUERYTYPE_TIMESTAMPDISJOINT] == QUERY_BEGIN_ISSUED)
    {
        hr = g_pTimeStampDisjointQuery->Issue(D3DISSUE_END);
        assert(hr == S_OK);
        g_QueryState[QUERYTYPE_TIMESTAMPDISJOINT] = QUERY_END_ISSUED;
    }

    BOOL    bDisjoint;

    if (   (g_QueryState[QUERYTYPE_TIMESTAMPDISJOINT] == QUERY_END_ISSUED) 
        && (g_pTimeStampDisjointQuery->GetData((void *) &bDisjoint, sizeof(BOOL), 0) == S_OK))
    {
        // bDisjoint is valid now: it contains whether the clock frequency has changed
        if (bDisjoint)
            _stprintf(gUIResults[QUERYTYPE_TIMESTAMPDISJOINT], TEXT("Disjoint Time!"));
        else
            _stprintf(gUIResults[QUERYTYPE_TIMESTAMPDISJOINT], TEXT("Monitoring..."));

        g_QueryState[QUERYTYPE_TIMESTAMPDISJOINT] = QUERY_RETURNED;
    }
}

//--------------------------------------------------------------------------------------
// TestTimeStampFreqQuery()
// Returns false if it cannot guaranteed that the timer frequency is constant 
// between signals TestTimeStampDisjointQuery.
//--------------------------------------------------------------------------------------
void TestTimeStampFreqQuery()
{
    HRESULT         hr;

    if (g_QueryState[QUERYTYPE_TIMESTAMPFREQ] == QUERY_RETURNED)
    {
        hr = g_pTimeStampFreqQuery->Issue(D3DISSUE_END);
        assert(hr == S_OK);
        g_QueryState[QUERYTYPE_TIMESTAMPFREQ] = QUERY_END_ISSUED;
    }

    UINT64          eventData;

    // Time stamp queries are typically delayed, ie not available immediately
    if (   (g_QueryState[QUERYTYPE_TIMESTAMPFREQ] == QUERY_END_ISSUED) 
        && (g_pTimeStampFreqQuery->GetData((void *) &eventData, sizeof(UINT64), 0) == S_OK))
    {
        // eventData is valid now: it contains the time stamp frequency
        _stprintf(gUIResults[QUERYTYPE_TIMESTAMPFREQ], TEXT("%lu"), eventData);
        gLastFreq = eventData;

        g_QueryState[QUERYTYPE_TIMESTAMPFREQ] = QUERY_RETURNED;
    }
}

//--------------------------------------------------------------------------------------
// ResetTimeStamps()
// Initializes the globals gLastFreq and gWalltimeDiff to relate the Timestamp timer 
// to walltime.  The problem unfortunately is that the walltime timer and the timestamp 
// timer drift wrt each other...  So this function is actually not used...
//--------------------------------------------------------------------------------------
/*
void ResetTimeStamps()
{
    // Issue a Timestamp freq and a time stamp query to get a base line how the timestamp counter 
    // relates to wall time.
    HRESULT             hr;
    UINT64              eventData;
    struct __timeb64    walltime;
    int                 counter = 0;

    assert(g_QueryState[QUERYTYPE_TIMESTAMPFREQ] == QUERY_RETURNED);
    assert(g_QueryState[QUERYTYPE_TIMESTAMP]     == QUERY_RETURNED);

    Sleep(1000);    // wait 3 secs to drain the GPU...   
    hr = g_pTimeStampFreqQuery->Issue(D3DISSUE_END);
    assert(hr == S_OK);

    // poll until it becomes available: should be very fast
    while (g_pTimeStampFreqQuery->GetData((void *) &eventData, sizeof(UINT64), D3DGETDATA_FLUSH) == S_FALSE)
        ++counter;
    gLastFreq = eventData;  // eventData is valid now: it contains the time stamp frequency
    assert(gLastFreq > 0L);


    hr = g_pTimeStampQuery->Issue(D3DISSUE_END);
    assert(hr == S_OK);
    _ftime64(&walltime);

    counter = 0;
    while (g_pTimeStampQuery->GetData((void *) &eventData, sizeof(UINT64), D3DGETDATA_FLUSH) == S_FALSE)
        ++counter;

    // eventData is valid now: it contains at what time the event was processed by the GPU.
    INT64 const     kSecs = eventData/gLastFreq;
    gWalltimeDiff  = 1000 * (walltime.time - kSecs);
    gWalltimeDiff += walltime.millitm - ((eventData/(gLastFreq/1000)) - 1000 * kSecs);

    INT64 correct   = (eventData/(gLastFreq/1000) + gWalltimeDiff)/1000;

    WCHAR   text[256];
    _stprintf(text, TEXT("%s %s"), TEXT("wall"),      _wctime64(&walltime.time));
    _stprintf(text, TEXT("%s %s"), TEXT("event"),     _wctime64(&kSecs));
    _stprintf(text, TEXT("%s %s"), TEXT("corrected"), _wctime64(&correct));
}
*/
