// PreCompiled Header
#include <shared/dxstdafx.h>
#include <TCHAR.H>
#include "resource.h"
#include <shared/NVBScene9.h>
