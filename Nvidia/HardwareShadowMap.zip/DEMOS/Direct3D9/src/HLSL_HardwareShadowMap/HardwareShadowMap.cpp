#include "HardwareShadowMap.h"
#include <shared/NVFileDialog.h>
#include <shared/GetFilePath.h>
#pragma warning(disable : 4786)
#include <vector>
#pragma warning(disable : 4786)
#include <assert.h>

static const int TEXDEPTH_HEIGHT = 512;
static const int TEXDEPTH_WIDTH = 512;



HardwareShadowMap::HardwareShadowMap()
{
    m_time = ::timeGetTime()*0.001f;
    m_startTime = m_time;
    m_frame = 0;
    m_fps = 30;
    m_main_menu = 0;
    m_context_menu = 0;
    m_pEffect = NULL;

    m_pAttributes = NULL;
    m_bWireframe = false;
    m_fRadius = 0;
    m_vecCenter = D3DXVECTOR3(0.f, 0.f, 0.f);
    m_pBackBuffer = NULL;
    m_pZBuffer = NULL;
    m_pSMColorTexture = NULL;
    m_pSMDecalTextureGround = NULL;
    m_pSMDecalTextureBot = NULL;
    m_pSMZTexture = NULL;
    m_pSMColorSurface = NULL;
    m_pSMZSurface = NULL;
    m_lightDir = D3DXVECTOR4(0.f, 0.f, 0.f, 0.f);
    m_bitDepth = 24;
    m_Paused = false;
    m_pDeclaration = NULL;
    m_fDepthBias = 0.0002f;
    m_fBiasSlope = 2.0f;
	m_pScene = NULL;
    m_bLameTech = 0;

    D3DXMatrixIdentity(&m_World);
    D3DXMatrixIdentity(&m_View);
    D3DXMatrixIdentity(&m_Projection);
}

HRESULT HardwareShadowMap::ResetDevice( IDirect3DDevice9* m_pd3dDevice, const D3DSURFACE_DESC* m_pBackBufferSurfaceDesc )
{
    HRESULT hr;

    assert(m_pd3dDevice);

    D3DFORMAT zFormat = D3DFMT_D24S8;
    m_bitDepth = 24;

    if(FAILED(CheckResourceFormatSupport(m_pd3dDevice, zFormat, D3DRTYPE_TEXTURE, D3DUSAGE_DEPTHSTENCIL)))
    {
        MessageBox(NULL, _T("Device/driver does not support hardware shadow maps!"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return E_FAIL;
    }

    //setup buffers
    if(FAILED(m_pd3dDevice->GetRenderTarget(0, &m_pBackBuffer)))
        return E_FAIL;
    if(FAILED(m_pd3dDevice->GetDepthStencilSurface(&m_pZBuffer)))
        return E_FAIL;

    if(!m_pBackBuffer || !m_pZBuffer)
        return E_FAIL;

    if(FAILED(D3DXCreateTextureFromFileEx(m_pd3dDevice, 
                                          GetFilePath::GetFilePath(_T("spotlight.tga")).c_str(), 
                                          TEXDEPTH_WIDTH,
                                          TEXDEPTH_HEIGHT,
                                          1,
                                          D3DUSAGE_RENDERTARGET,
                                          D3DFMT_A8R8G8B8,
                                          D3DPOOL_DEFAULT,
                                          D3DX_DEFAULT,
                                          D3DX_DEFAULT,
                                          0,
                                          NULL,
                                          NULL,
                                          &m_pSMDecalTextureGround)))
        return E_FAIL;

       if(FAILED(D3DXCreateTextureFromFileEx(m_pd3dDevice, 
                                          GetFilePath::GetFilePath(_T("Sunlight.tga")).c_str(), 
                                          TEXDEPTH_WIDTH,
                                          TEXDEPTH_HEIGHT,
                                          1,
                                          D3DUSAGE_RENDERTARGET,
                                          D3DFMT_A8R8G8B8,
                                          D3DPOOL_DEFAULT,
                                          D3DX_DEFAULT,
                                          D3DX_DEFAULT,
                                          0,
                                          NULL,
                                          NULL,
                                          &m_pSMDecalTextureBot)))
        return E_FAIL;


    D3DFORMAT colorFormat = D3DFMT_A8R8G8B8;
    if( (zFormat == D3DFMT_D16) ||
        (zFormat == D3DFMT_D15S1) )
        colorFormat = D3DFMT_R5G6B5;

    if(FAILED(m_pd3dDevice->CreateTexture(TEXDEPTH_WIDTH, TEXDEPTH_HEIGHT, 1, D3DUSAGE_RENDERTARGET, colorFormat, 
        D3DPOOL_DEFAULT, &m_pSMColorTexture, NULL)))
        return E_FAIL;
    if(FAILED(m_pd3dDevice->CreateTexture(TEXDEPTH_WIDTH, TEXDEPTH_HEIGHT, 1, D3DUSAGE_DEPTHSTENCIL, zFormat, 
        D3DPOOL_DEFAULT, &m_pSMZTexture, NULL)))
        return E_FAIL;
    if(!m_pSMColorTexture || !m_pSMZTexture || !m_pSMDecalTextureGround || !m_pSMDecalTextureBot)
        return E_FAIL;

    // Retrieve top-level surfaces of our shadow buffer (need these for use with SetRenderTarget)
    if(FAILED(m_pSMColorTexture->GetSurfaceLevel(0, &m_pSMColorSurface)))
        return E_FAIL;
    if(FAILED(m_pSMZTexture->GetSurfaceLevel(0, &m_pSMZSurface)))
        return E_FAIL;
    if(!m_pSMColorSurface || !m_pSMZSurface)
        return E_FAIL;

    // Assign registers to the relevant vertex attributes
    D3DVERTEXELEMENT9 declaration[] =
    {
        { 0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 }, 
        { 0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL, 0 },  
        D3DDECL_END()
    };

    m_pd3dDevice->CreateVertexDeclaration(declaration, &m_pDeclaration);

    const char* profileOpts[] = 
    {
        "-profileopts", "dcls", NULL,
    };

    DWORD tempFVF = D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX0;

    hr = CreateQuad(m_pd3dDevice,&m_smQuad);
    tstring fileName(_T("ClawBOT.nvb"));

    m_pScene = new NVBScene;
    hr = m_pScene->Load(fileName, m_pd3dDevice, GetFilePath::GetFilePath);
    if(FAILED(hr))
        return hr;
    
    if (!m_pScene->m_VertexHasNormal) {
        MessageBox(NULL, _T("Model does not have normals"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return E_FAIL;
    }

    //bigship needs a bit of scale / trans
    m_smBigship.scaleVec = D3DXVECTOR3(0.5f, 0.5f, 0.5f);
    m_smBigship.transVec = D3DXVECTOR3(0.0f, -5.0f, 0.0f);
   
    // Load our Effect file
    // note: path is relative to MEDIA\ dir
    hr = D3DXCreateEffectFromFile(m_pd3dDevice, GetFilePath::GetFilePath(_T("programs\\HLSL_HardwareShadowMap\\HardwareShadowMap.fx")).c_str(),
        NULL, NULL, 0, NULL, &m_pEffect, NULL);
    if (FAILED(hr))
    {
        MessageBox(NULL, _T("Failed to load effect file"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return hr;
    }

    m_lightDir.x = 0.8f;
    m_lightDir.y = 1.0f;
    m_lightDir.z = 0.0f;
    m_lightDir.w = 0.0f;
    D3DXVec4Normalize(&m_lightDir, &m_lightDir);
    
    m_pEffect->SetValue("LightVec", (float*)&m_lightDir, sizeof(float)*3);

    m_lightPos.x = m_pScene->m_Center.x + m_pScene->m_Radius / 0.5f; 
    m_lightPos.y = m_pScene->m_Center.y + m_pScene->m_Radius / 0.5f; 
    m_lightPos.z = 0;

    return S_OK;
}
HRESULT HardwareShadowMap::SetVertexShaderMatrices(const D3DXMATRIX& worldMat, const D3DXMATRIX& viewMat, const D3DXMATRIX& projMat, const D3DXMATRIX& texMat)
{
    D3DXMATRIX worldViewMat = worldMat * viewMat;
    D3DXMATRIX worldViewProjMat = worldMat * viewMat * projMat;

    D3DXMATRIX worldITMat;    
    D3DXMatrixInverse(&worldITMat, NULL, &worldMat);
    D3DXMatrixTranspose(&worldITMat, &worldITMat);
        
    m_pEffect->SetMatrix("WorldViewProj", &worldViewProjMat);
    m_pEffect->SetMatrix("WorldView", &worldViewMat);
    m_pEffect->SetMatrix("WorldIT", &worldITMat);
    m_pEffect->SetMatrix("TexTransform", &texMat);
    
    return S_OK;
}
HRESULT HardwareShadowMap::CreateQuad(IDirect3DDevice9* m_pd3dDevice, SMMeshInfo* mesh)
{    
    HRESULT hr = S_OK;

    hr = m_pd3dDevice->CreateVertexBuffer(4 * sizeof(SMVertex), D3DUSAGE_WRITEONLY, 0, D3DPOOL_DEFAULT, &(mesh->pVB), NULL);
    if(FAILED(hr))
        return hr;

    SMVertex* pVData;
    hr = mesh->pVB->Lock(0, 0, (void**)&pVData, 0);
    if(FAILED(hr))
        return hr;
    float value = 200.0f;
    pVData[0].x  = -value; pVData[0].y  = -10.0f; pVData[0].z  = value;
    pVData[0].nx = 0.0f;  pVData[0].ny = 1.0f; pVData[0].nz = 0.0f;
    pVData[1].x  = value;  pVData[1].y  = -10.0f; pVData[1].z  = value;
    pVData[1].nx = 0.0f;  pVData[1].ny = 1.0f; pVData[1].nz = 0.0f;
    pVData[2].x  = -value; pVData[2].y  = -10.0f; pVData[2].z  = -value;
    pVData[2].nx = 0.0f;  pVData[2].ny = 1.0f; pVData[2].nz = 0.0f;
    pVData[3].x  = value;  pVData[3].y  = -10.0f; pVData[3].z  = -value;
    pVData[3].nx = 0.0f;  pVData[3].ny = 1.0f; pVData[3].nz = 0.0f;
    hr = mesh->pVB->Unlock();
    if(FAILED(hr))
        return hr;

    hr = m_pd3dDevice->CreateIndexBuffer(4 * sizeof(WORD), D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &(mesh->pIB), NULL);
    if(FAILED(hr))
        return hr;

    WORD* pIData;
    hr = mesh->pIB->Lock(0, 0, (void**)&pIData, 0);
    if(FAILED(hr))
        return hr;
    //it's a strip
    pIData[0] = 0;
    pIData[1] = 2;
    pIData[2] = 1;
    pIData[3] = 3;
    hr = mesh->pIB->Unlock();

    mesh->dwNumFaces = 2;
    mesh->dwNumVerts = 4;
    mesh->primType = D3DPT_TRIANGLESTRIP;

    //quad doesn't get scaled / translated
    mesh->scaleVec = D3DXVECTOR3(1.0f, 1.0f, 1.0f);
    mesh->transVec = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

    return S_OK;
}
HRESULT HardwareShadowMap::CheckResourceFormatSupport(IDirect3DDevice9* m_pd3dDevice, D3DFORMAT fmt, D3DRESOURCETYPE resType, DWORD dwUsage)
{
    HRESULT hr = S_OK;
    IDirect3D9* tempD3D = NULL;
    m_pd3dDevice->GetDirect3D(&tempD3D);
    D3DCAPS9 devCaps;
    m_pd3dDevice->GetDeviceCaps(&devCaps);

	D3DDISPLAYMODE displayMode;
    tempD3D->GetAdapterDisplayMode(devCaps.AdapterOrdinal, &displayMode);
    
    hr = tempD3D->CheckDeviceFormat(devCaps.AdapterOrdinal, devCaps.DeviceType, displayMode.Format, dwUsage, resType, fmt);
    
    tempD3D->Release(), tempD3D = NULL;
    
    return hr;
}

HRESULT HardwareShadowMap::RenderShadowMap(IDirect3DDevice9* m_pd3dDevice)
{
    //setup matrices for shadowmap
    D3DXVECTOR3 eye, lookAt, up;
    
    lookAt.x = m_lightPos.x - (m_lightDir.x); 
    lookAt.y = m_lightPos.y - (m_lightDir.y);
    lookAt.z = m_lightPos.z - (m_lightDir.z);
    
    up.x     = 0.0f;          up.y     = 1.0f;          up.z     = 0.0f;
    
    D3DXMATRIX lightView, lightProj;
    D3DXMatrixLookAtLH(&lightView, &m_lightPos, &lookAt, &up);
    
    D3DXMatrixPerspectiveFovLH(&lightProj, D3DXToRadian(60.0f), 1.0f, 50.0f, 500.0f);

    m_LightViewProj = lightView * lightProj;
    
    //set render target to shadow map surfaces
    if(FAILED(m_pd3dDevice->SetRenderTarget(0, m_pSMColorSurface)))
        return E_FAIL;

    //set depth stencil
    if(FAILED(m_pd3dDevice->SetDepthStencilSurface(m_pSMZSurface)))
        return E_FAIL;


    //save old viewport
    D3DVIEWPORT9 oldViewport;
    m_pd3dDevice->GetViewport(&oldViewport);

    //set new, funky viewport
    D3DVIEWPORT9 newViewport;
    newViewport.X = 0;
    newViewport.Y = 0;
    newViewport.Width  = TEXDEPTH_WIDTH;
    newViewport.Height = TEXDEPTH_HEIGHT;
    newViewport.MinZ = 0.0f;
    newViewport.MaxZ = 1.0f;
    m_pd3dDevice->SetViewport(&newViewport);

    //use technique that will draw plain black pixels
    if (FAILED(m_pEffect->SetTechnique("GenHardwareShadowMap")))
    {
        MessageBox(NULL, _T("Failed to set 'GenHardwareShadowMap' technique in effect file"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return E_FAIL;
    }

    //depth bias
    m_pd3dDevice->SetRenderState(D3DRS_DEPTHBIAS, *(DWORD*)&m_fDepthBias);
    m_pd3dDevice->SetRenderState(D3DRS_SLOPESCALEDEPTHBIAS, *(DWORD*)&m_fBiasSlope);

    m_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00FFFFFF, 1.0f, 0L);

    D3DXMATRIX tempIdentity;
    D3DXMatrixIdentity(&tempIdentity);

    for (unsigned int i = 0; i < m_pScene->m_NumMeshes; ++i) 
    {
        const NVBScene::Mesh& mesh = m_pScene->m_Meshes[i];

        D3DXMATRIX worldMat = mesh.m_Transform * m_World;
        SetVertexShaderMatrices(worldMat, lightView, lightProj, tempIdentity);
        m_pd3dDevice->SetVertexDeclaration(m_pDeclaration);

        // render mesh using GenHardwareShadowMap technique
        UINT uPasses;
        if (D3D_OK == m_pEffect->Begin(&uPasses, 0)) {  // The 0 specifies that ID3DXEffect::Begin and ID3DXEffect::End will save and restore all state modified by the effect.
            for (UINT uPass = 0; uPass < uPasses; uPass++) {
                // Set the state for a particular pass in a technique.
                m_pEffect->BeginPass(uPass);

                // Draw it 
                if (FAILED(mesh.Draw()))
                    return E_FAIL;
				m_pEffect->EndPass();
            }
            m_pEffect->End();
        }
    }

    D3DXMATRIX tempScaleMat;
    D3DXMatrixScaling(&tempScaleMat, m_smQuad.scaleVec.x, m_smQuad.scaleVec.y, m_smQuad.scaleVec.z);
    
    SetVertexShaderMatrices(tempScaleMat, lightView, lightProj, tempIdentity);

    //set vb
    HRESULT hr = m_pd3dDevice->SetStreamSource(0, m_smQuad.pVB, 0, sizeof(SMVertex));
    if (FAILED(hr))
        return hr;
    
    //set index buffer
    hr = m_pd3dDevice->SetIndices(m_smQuad.pIB);
    if(FAILED(hr))
        return hr;

    //render quad
    UINT uPasses;
    if (D3D_OK == m_pEffect->Begin(&uPasses, 0)) {  // The 0 specifies that ID3DXEffect::Begin and ID3DXEffect::End will save and restore all state modified by the effect.
        for (UINT uPass = 0; uPass < uPasses; uPass++) {
            m_pEffect->BeginPass(uPass);     // Set the state for a particular pass in a technique.
            m_pd3dDevice->DrawIndexedPrimitive(m_smQuad.primType, 0, 0, m_smQuad.dwNumVerts, 0, m_smQuad.dwNumFaces);
			m_pEffect->EndPass();
        }
        m_pEffect->End();
    }
    
    m_pd3dDevice->SetViewport(&oldViewport);

    //depth bias
    float fTemp = 0.0f;
    m_pd3dDevice->SetRenderState(D3DRS_DEPTHBIAS, *(DWORD*)&fTemp);
    m_pd3dDevice->SetRenderState(D3DRS_SLOPESCALEDEPTHBIAS, *(DWORD*)&fTemp);

    return S_OK;
}
void HardwareShadowMap::LostDevice()
{
    SAFE_RELEASE(m_smBigship.pVB);
    SAFE_RELEASE(m_smBigship.pIB);
    SAFE_RELEASE(m_smQuad.pVB);
    SAFE_RELEASE(m_smQuad.pIB);

    SAFE_RELEASE(m_pSMColorTexture);
    SAFE_RELEASE(m_pSMDecalTextureGround);
    SAFE_RELEASE(m_pSMDecalTextureBot);
    SAFE_RELEASE(m_pSMZTexture);
    SAFE_RELEASE(m_pSMColorSurface);
    SAFE_RELEASE(m_pSMZSurface);

    SAFE_RELEASE(m_pBackBuffer);
    SAFE_RELEASE(m_pZBuffer);

    SAFE_RELEASE(m_pDeclaration);

    SAFE_DELETE_ARRAY(m_pAttributes);

    SAFE_DELETE(m_pScene);
    SAFE_RELEASE(m_pEffect);
}
HRESULT HardwareShadowMap::Render( IDirect3DDevice9* m_pd3dDevice, double fTime, float fElapsedTime, 
								  const D3DXMATRIX* cworldMat, const D3DXMATRIX* cviewMat, const D3DXMATRIX* cprojMat)
{
    HRESULT hr;
    D3DXHANDLE hTechnique = NULL;

    // update time
    m_time = ::timeGetTime()*0.001f;
    if (m_frame == 0)
        m_startTime = m_time;
    else if (m_time > m_startTime)
        m_fps = (float)m_frame / (m_time - m_startTime);

    // Update view matrix
    m_View = *cviewMat;//m_UICamera->GetRotationMatrix() * m_UICamera->GetTranslationMatrix();
    //m_UIScene->SetControlOrientationMatrix(m_View);

    // Update scene position
    m_World = *cworldMat;//m_UIScene->GetRotationMatrix() * m_UIScene->GetTranslationMatrix();
    static float time = 0.0f;
    static bool forward = true;
    if (!m_Paused)
    {
        if (forward)
            time += 30 / m_fps;
        else
            time -= 30 / m_fps;
    }
    if (time > m_pScene->m_NumMeshKeys - 1)
    {
        forward = false;
        time = (float)m_pScene->m_NumMeshKeys - 2.0f;
    }
    if (time < 1)
        forward = true;

    if (true)//m_pd3dDevice->BeginScene() == D3D_OK)
    {
        m_pScene->Update(time, &m_World);

        m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, (m_bWireframe ? D3DFILL_WIREFRAME : D3DFILL_SOLID));

        //render into shadow map
        if(FAILED(RenderShadowMap(m_pd3dDevice)))
            return E_FAIL;

        const D3DXHANDLE techs[4] = { "UseHardwareShadowMap", "UseHardwareShadowMapLame", "UseHardwareShadowMapGoodNoRot", "UseHardwareShadowMapGoodRot" };
        if (FAILED(m_pEffect->SetTechnique(techs[m_bLameTech])))
        {
            MessageBox(NULL, _T("Failed to set 'UseHardwareShadowMap' technique in effect file"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
            return E_FAIL;
        }

        //set render target back to normal back buffer / depth buffer
        if(FAILED(m_pd3dDevice->SetRenderTarget(0, m_pBackBuffer)))
            return E_FAIL;

        if(FAILED(m_pd3dDevice->SetDepthStencilSurface(m_pZBuffer)))
            return E_FAIL;

        m_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 60, 60, 60), 1.0f, 0L);

        //set depth map as texture
        if(FAILED(m_pEffect->SetTexture("ShadowMap", m_pSMZTexture)))
            return E_FAIL;
        
        //set spotlight texture for Bot
        if(FAILED(m_pEffect->SetTexture("SpotLight", m_pSMDecalTextureBot)))
            return E_FAIL;

        //set special texture matrix for shadow mapping
        float fOffsetX = 0.5f + (0.5f / (float)TEXDEPTH_WIDTH);
        float fOffsetY = 0.5f + (0.5f / (float)TEXDEPTH_HEIGHT);
        unsigned int range = 1;            //note different scale in DX9!
        //float fBias    = -0.001f * (float)range;
        float fBias    = 0.0f;
        D3DXMATRIX texScaleBiasMat( 0.5f,     0.0f,     0.0f,         0.0f,
                                    0.0f,    -0.5f,     0.0f,         0.0f,
                                    0.0f,     0.0f,     (float)range, 0.0f,
                                    fOffsetX, fOffsetY, fBias,        1.0f );
        
        for (unsigned int i = 0; i < m_pScene->m_NumMeshes; ++i) 
        {
            const NVBScene::Mesh& mesh = m_pScene->m_Meshes[i];

            D3DXMATRIX worldMat = mesh.m_Transform * m_World;
            SetVertexShaderMatrices(worldMat, m_View, m_Projection, worldMat * m_LightViewProj * texScaleBiasMat);

            // render mesh using HardwareShadowMapTechnique
            UINT uPasses;
            if (D3D_OK == m_pEffect->Begin(&uPasses, 0)) {  // The 0 specifies that ID3DXEffect::Begin and ID3DXEffect::End will save and restore all state modified by the effect.
                for (UINT uPass = 0; uPass < uPasses; uPass++) {
                    // Set the state for a particular pass in a technique.
                    m_pEffect->BeginPass(uPass);

                    // Draw it 
                    if (FAILED(hr = mesh.Draw()))
                        return hr;
					m_pEffect->EndPass();
                }
                m_pEffect->End();
            }
        }

           //set spotlight texture for Ground
        if(FAILED(m_pEffect->SetTexture("SpotLight", m_pSMDecalTextureGround)))
            return E_FAIL;

        D3DXMATRIX tempScaleMat;
        D3DXMatrixScaling(&tempScaleMat, m_smQuad.scaleVec.x, m_smQuad.scaleVec.y, m_smQuad.scaleVec.z);
        SetVertexShaderMatrices(tempScaleMat, m_View, m_Projection, tempScaleMat * m_LightViewProj * texScaleBiasMat);

        //set vb
        hr = m_pd3dDevice->SetStreamSource(0, m_smQuad.pVB, 0, sizeof(SMVertex));
        if (FAILED(hr))
            return hr;

        //set index buffer
        hr = m_pd3dDevice->SetIndices(m_smQuad.pIB);
        if(FAILED(hr))
            return hr;

        //render quad using HardwareShadowMapTechnique
        UINT uPasses;
        if (D3D_OK == m_pEffect->Begin(&uPasses, 0)) {  // The 0 specifies that ID3DXEffect::Begin and ID3DXEffect::End will save and restore all state modified by the effect.
            for (UINT uPass = 0; uPass < uPasses; uPass++) {
                // Set the state for a particular pass in a technique.
                m_pEffect->BeginPass(uPass);

                // Draw it 
                if(FAILED(m_pd3dDevice->DrawIndexedPrimitive(m_smQuad.primType, 0, 0, m_smQuad.dwNumVerts, 0, m_smQuad.dwNumFaces)))
                    return E_FAIL;
				m_pEffect->EndPass();
            }
            m_pEffect->End();
        }

//        m_pd3dDevice->EndScene();
    }

    m_frame++;

    return S_OK;
}