// PreCompiled Header

#include <shared/dxstdafx.h>
#include <TCHAR.H>
#include "resource.h"

#include "shared\NV_Common.h"
#include "shared\NV_Error.h"
#include "NV_D3DCommon\NV_D3DCommon.h"
#include "NV_D3DMesh\NV_D3DMesh.h"

#include "NV_D3DCommon\Plot.h"

