/*

   This demo is a simple illustration of ARB_shadow and ARB_depth_texture.

  Cass Everitt
  12-11-00

*/  

#if defined(WIN32)
#  include <windows.h>
#  pragma warning(disable:4244)   // No warnings on precision truncation
#  pragma warning(disable:4305)   // No warnings on precision truncation
#  pragma warning(disable:4786)   // stupid symbol size limitation
#elif defined(UNIX)
#  include <GL/glx.h>
#endif

#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>

#define GLH_EXT_SINGLE_FILE

#if defined(WIN32)
#define REQUIRED_EXTENSIONS "GL_ARB_multitexture " \
                            "GL_ARB_depth_texture " \
                            "GL_ARB_shadow " \
                            "WGL_ARB_pbuffer " \
                            "WGL_ARB_pixel_format " 
#elif defined(UNIX)
#define REQUIRED_EXTENSIONS "GL_ARB_multitexture " \
                            "GL_ARB_depth_texture " \
                            "GL_ARB_shadow " \
                            "GLX_SGIX_pbuffer " \
                            "GLX_SGIX_fbconfig "
#elif defined(MACOS)
#define REQUIRED_EXTENSIONS "GL_ARB_multitexture " \
                            "GL_ARB_depth_texture " \
                            "GL_ARB_shadow "
#endif

#include <glh/glh_extensions.h>
#include <glh/glh_obs.h>
#include <glh/glh_glut.h>

#include <shared/pbuffer.h>
#include <shared/array_texture.h>
#include <shared/nv_png.h>

using namespace std;
using namespace glh;

#define TEX_SIZE 1024

glut_callbacks cb;
glut_perspective_reshaper reshaper, lightshaper;
glut_simple_mouse_interactor camera, object, spotlight, *current_interactor;

tex_object_2D light_image, decal, light_view_depth;

display_list quad, wirecube, geometry;
display_list combiner_config;


PBuffer pbuffer("rgb depth=24");

vec4f light_intensity(1,1,1,1);

GLuint frameBufferObject = 0;

int master_light_view_version = 0;
int light_view_version = -1;

bool b[256];

void render_scene_from_camera_view();
void render_scene_from_camera_view__shadowed();
void render_scene_from_light_view();

int current_display_func = 0;
vector<void (*)()> display_funcs;

GLenum depth_format;


struct tweak
{
    string name;
    float val;
    float incr;
};

map<string, tweak> tweaks;
map<string, tweak>::iterator curr_tweak;

// glut callbacks
void key(unsigned char k, int x, int y);
void display();
void menu(int entry);
void motion(int x, int y); // watch for light view update
void idle();

void init_opengl();

void createFrameBufferObject();
void deleteFrameBufferObject();

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(512, 512);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_DEPTH|GLUT_RGB);
    glutCreateWindow("ARB_shadow Shadows");

    atexit(deleteFrameBufferObject);

    init_opengl();  
    
    glut_helpers_initialize();
    cb.keyboard_function = key;
    cb.motion_function = motion;
    cb.display_function = display;

    camera.configure_buttons(1);
    object.configure_buttons(1);
    spotlight.configure_buttons(1);

    object.dolly.dolly[2] = -3; // push plane forward
    object.trackball.r = rotationf(vec3f(1,0,0), to_radians(30));
    spotlight.pan.pan[0] = -.25;
    spotlight.pan.pan[1] = 1.5;
    spotlight.dolly.dolly[2] = -2.; // push spotlight forward
    spotlight.trackball.r =  rotationf(vec3f(1.f, 0.f, 0.f), to_radians(-60.f));

    camera.set_camera_mode(true);
    spotlight.set_camera_mode(false);
    spotlight.trackball.invert_increment = true;

    camera.set_parent_rotation( & camera.trackball.r);
    object.set_parent_rotation( & camera.trackball.r);
    spotlight.set_parent_rotation( & camera.trackball.r);

    lightshaper.fovy  = 60.f;
    lightshaper.zNear = .5f;
    lightshaper.zFar  = 5.f;
    lightshaper.width = TEX_SIZE;
    lightshaper.height = TEX_SIZE;


    camera.disable();
    spotlight.disable();
    lightshaper.disable();
    // attach interactors to the event multiplexor
    glut_add_interactor(& cb);
    glut_add_interactor(& reshaper);
    glut_add_interactor(& object);
    glut_add_interactor(& camera);
    glut_add_interactor(& spotlight);

    display_funcs.push_back( & render_scene_from_camera_view__shadowed);
    display_funcs.push_back( & render_scene_from_camera_view);
    display_funcs.push_back( & render_scene_from_light_view);

    float bias = 1/(pow(2.0,16.0)-1);

    tweak t;

    t.name = "r coordinate scale";
    t.val = .5;
    t.incr = bias;
    tweaks[t.name] = t;

    t.name = "r coordinate bias";
    t.val = .5;
    t.incr = bias;
    tweaks[t.name] = t;

    t.name = "polygon offset scale";
    t.val = 2.5;
    t.incr = .5;
    tweaks[t.name] = t;

    t.name = "polygon offset bias";
    t.val = 10;
    t.incr = 1;
    tweaks[t.name] = t;

    curr_tweak = tweaks.begin();


    int tweakables = glutCreateMenu(menu);
    glutAddMenuEntry("increase light field-of-view [v]", 'v');
    glutAddMenuEntry("decrease light field-of-view [V]", 'V');
    glutAddMenuEntry("next tweakable [n]", 'n');
    glutAddMenuEntry("increase current tweakable [+]", '+');
    glutAddMenuEntry("decrease current tweakable [-]", '-');

    int copyrights = glutCreateMenu(menu);
    glutAddMenuEntry("hw_shadowmaps_simple (c) 2001 NVIDIA Corporation", 0);
    glutAddMenuEntry("GLH -- Copyright (c) 2001 NVIDIA Corporation", 0);
    glutAddMenuEntry("GLH -- Copyright (c) 2000 Cass Everitt", 0);
    glutAddMenuEntry("libpng -- Copyright (c) 1998, 1999, 2000 Glenn Randers-Pehrson", 0);

    glutCreateMenu(menu);

    glutAddMenuEntry("cycle through display options [ ]", ' ');
    glutAddMenuEntry("move camera [1]", '1');
    glutAddMenuEntry("move object [2]", '2');
    glutAddMenuEntry("move light  [3]", '3');
    glutAddSubMenu("tweakables", tweakables);
    glutAddSubMenu("copyright info", copyrights);
    glutAddMenuEntry("quit [q]", 'q');

    glutAttachMenu(GLUT_RIGHT_BUTTON);

    glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}

void motion(int x, int y)
{
    if( current_interactor == & spotlight ||
        current_interactor == & object )
         master_light_view_version++;
}

void menu(int entry)
{
    key(entry, 0, 0);
}

void set_light_view_texture_parameters()
{
    light_view_depth.bind();
    light_view_depth.parameter(GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    light_view_depth.parameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    light_view_depth.parameter(GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    light_view_depth.parameter(GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    light_view_depth.parameter(GL_TEXTURE_COMPARE_MODE_ARB, GL_COMPARE_R_TO_TEXTURE_ARB);
    light_view_depth.parameter(GL_TEXTURE_COMPARE_FUNC_ARB, GL_LEQUAL);
}

void CHECK_FRAMEBUFFER_STATUS()                            
 {                                                            
        GLenum status;                                             
        status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);  
        switch(status) {                                          
          case GL_FRAMEBUFFER_COMPLETE_EXT: 
              cout << "FBO complete" << endl;
            break;                                                
          case GL_FRAMEBUFFER_UNSUPPORTED_EXT:                   
              cout << "FBO format unsupported" << endl;
            /* choose different formats */                        
            break;                                                
          default:  cout << "Unknown FBO error"   << endl;                                       
        }
   }

void deleteFrameBufferObject()
{
  if(!frameBufferObject)
    return;

  //Activate the frame buffer objcet
  glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, frameBufferObject);
  //Detach our depth texture from the frame buffer object
  glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT,
                            GL_DEPTH_ATTACHMENT_EXT,
                            GL_TEXTURE_2D, 
                            0,
                            0);
  //DeActivate the frame buffer objcet
  glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
  //Delete the frame buffer object
  glDeleteFramebuffersEXT(1, &frameBufferObject);
  frameBufferObject = 0;

}

void createFrameBufferObject()
{
  if(frameBufferObject)
    return;

  if(!glh_init_extensions("GL_EXT_framebuffer_object "))
  {
    cerr << "GL_EXT_framebuffer_object not supported!" << endl;
    return;
  }

  //Generate the frame buffer object
  glGenFramebuffersEXT(1, &frameBufferObject);
  //Activate the frame buffer object
  glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, frameBufferObject);
  //Attach our depth texture to the frame buffer object
  glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT,
                            GL_DEPTH_ATTACHMENT_EXT,
                            GL_TEXTURE_2D, 
                            light_view_depth.texture,
                            0);

  //You must set DrawBuffer and ReadBuffer to none since we're rendering to depth only
  glDrawBuffer(GL_NONE);
  glReadBuffer(GL_NONE); 

  //Check the completeness of our frame buffer object, with depth textures, there is no need for stencil
  //and depth attachment for a FBO to be considered as complete
  CHECK_FRAMEBUFFER_STATUS();

  //Turn off our frame buffer object
  glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
}

void init_opengl()
{
    if(! glh_init_extensions(REQUIRED_EXTENSIONS))
    {
        cerr << "Necessary extensions were not supported:" << endl
             << glh_get_unsupported_extensions() << endl << endl
             << "Press <enter> to quit." << endl << endl;
        cerr << "Extensions: " << glGetString(GL_EXTENSIONS) << endl << endl;
        cerr << "Renderer: " << glGetString(GL_RENDERER) << endl << endl;
        char buff[10];
        cin.getline(buff, 10);
        exit(0);
    }
 
    glClearColor(.5f, .5f, .5f, .5f);

    array2<vec3ub> img;

    decal.bind();
    read_png_rgb("decal_image.png", img);
    make_rgb_texture(img, true);
    decal.parameter(GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    decal.parameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    light_image.bind();
    read_png_rgb("nvlogo_spot.png", img);
    make_rgb_texture(img, true);
    light_image.parameter(GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    light_image.parameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    light_image.parameter(GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    light_image.parameter(GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);


    quad.new_list(GL_COMPILE);
    glPushMatrix();
    glRotatef(-90, 1, 0, 0);
    glScalef(4,4,4);
    glBegin(GL_QUADS);
    glNormal3f(0, 0, 1);
    glVertex2f(-1, -1);
    glVertex2f(-1,  1);
    glVertex2f( 1,  1);
    glVertex2f( 1, -1);
    glEnd();
    glPopMatrix();
    quad.end_list();

    wirecube.new_list(GL_COMPILE);
    glutWireCube(2); 
    wirecube.end_list();
    
    geometry.new_list(GL_COMPILE);
    glPushMatrix();
    glTranslatef(0, .4f, 0);
    glutSolidTeapot(.5f);
    glPopMatrix();
    geometry.end_list();

    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_AMBIENT, & vec4f(0,0,0,0)[0]);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, &light_intensity[0]);
    glLightfv(GL_LIGHT0, GL_SPECULAR, &light_intensity[0]);

    glEnable(GL_DEPTH_TEST);

    // init pbuffer
    pbuffer.Initialize(TEX_SIZE, TEX_SIZE, false, true);
    pbuffer.Activate();
    glEnable(GL_DEPTH_TEST);

    {
        GLint depth_bits;
        glGetIntegerv(GL_DEPTH_BITS, & depth_bits);
        
        if(depth_bits == 16)  depth_format = GL_DEPTH_COMPONENT16_ARB;
        else                  depth_format = GL_DEPTH_COMPONENT24_ARB;
    }
    pbuffer.Deactivate();

    light_view_depth.bind();    
    glTexImage2D(GL_TEXTURE_2D, 0, depth_format, TEX_SIZE, TEX_SIZE, 0, 
                 GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, 0);
    set_light_view_texture_parameters();

    //Create our frame buffer object and attach the depth texture to it
    createFrameBufferObject();

}
void key(unsigned char k, int x, int y)
{
    b[k] = !b[k];
    if(k==27) 
      exit(0);
    if(k=='1' || k == '2' || k == '3')
    {
        object.disable();
        camera.disable();
        spotlight.disable();

        if     (k=='1') camera.enable();
        else if(k=='2') object.enable();
        else            spotlight.enable();

    }
    if(k=='v')
    {
        lightshaper.fovy += 5.f;
        master_light_view_version++;
        cerr << "spot fovy == " << lightshaper.fovy << endl;
    }
    if(k=='V')
    {
        lightshaper.fovy -= 5.f;
        master_light_view_version++;
        cerr << "spot fovy == " << lightshaper.fovy << endl;
    }
    if(k==' ')
    {
        current_display_func++;
        current_display_func %= display_funcs.size();
        if(display_funcs[current_display_func] == & render_scene_from_light_view)
        {
            object.set_parent_rotation(& spotlight.trackball.r);
            spotlight.set_parent_rotation(& spotlight.trackball.r);
        }
        else
        {
            object.set_parent_rotation(& camera.trackball.r);
            spotlight.set_parent_rotation(& camera.trackball.r);
        }
    }

    if(k=='i')
    {
        light_intensity += .05f;
        glLightfv(GL_LIGHT0, GL_DIFFUSE, &light_intensity[0]);
        glLightfv(GL_LIGHT0, GL_SPECULAR, &light_intensity[0]);
    }
    if(k=='I')
    {
        light_intensity -= .05f;
        glLightfv(GL_LIGHT0, GL_DIFFUSE, &light_intensity[0]);
        glLightfv(GL_LIGHT0, GL_SPECULAR, &light_intensity[0]);
    }

    if(k=='n')
    {
        curr_tweak++;
        if(curr_tweak == tweaks.end()) curr_tweak = tweaks.begin();
        cerr << "The current tweak is: " << (*curr_tweak).second.name << endl;
    }
    if(k=='=' || k=='+')
    {
        tweak & t = (*curr_tweak).second;
        t.val += t.incr;
        cerr << t.name << "  = " << t.val << endl;
    }
    if(k=='-')
    {
        tweak & t = (*curr_tweak).second;
        t.val -= t.incr;
        cerr << t.name << "  = " << t.val << endl;
    }

    master_light_view_version++; // key press always invalidates the shadow map
    glutPostRedisplay();
}

void eye_linear_texgen()
{
    matrix4f m;

    set_texgen_planes(GL_EYE_PLANE, m);
    glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
    glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
    glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
    glTexGeni(GL_Q, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
}

void obj_linear_texgen()
{
    matrix4f m;

    set_texgen_planes(GL_OBJECT_PLANE, m);
    glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGeni(GL_Q, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
}

void texgen(bool enable)
{
    if(enable)
    {
        glEnable(GL_TEXTURE_GEN_S);
        glEnable(GL_TEXTURE_GEN_T);
        glEnable(GL_TEXTURE_GEN_R);
        glEnable(GL_TEXTURE_GEN_Q);
    }
    else
    {
        glDisable(GL_TEXTURE_GEN_S);
        glDisable(GL_TEXTURE_GEN_T);
        glDisable(GL_TEXTURE_GEN_R);
        glDisable(GL_TEXTURE_GEN_Q);
    }
}



void render_light_frustum()
{
    glPushMatrix();
    camera.apply_inverse_transform();
    spotlight.apply_transform();
    glMultMatrixf(&perspective_inverse(lightshaper.fovy, 1, lightshaper.zNear, lightshaper.zFar)(0,0));
    glDisable(GL_LIGHTING);
    glColor3f(1,1,0);
    wirecube.call_list();
    glColor3f(1,1,1);
    glEnable(GL_LIGHTING);
    glPopMatrix();
}

void render_quad()
{
    glActiveTextureARB(GL_TEXTURE0_ARB);
    obj_linear_texgen();
    texgen(true);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(4,4,1);
    glMatrixMode(GL_MODELVIEW);

    glDisable(GL_LIGHTING);
    decal.bind();
    decal.enable();
    quad.call_list();
    decal.disable();
    glEnable(GL_LIGHTING);

    texgen(false);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
}

void render_scene(glut_simple_mouse_interactor & view)
{
    glColor3f(1,1,1);
    glPushMatrix();
    view.apply_inverse_transform();

    glPushMatrix();
    object.apply_transform();

    render_quad();

    glEnable(GL_LIGHTING);
    geometry.call_list();
    glDisable(GL_LIGHTING);

    glPopMatrix();
    glPopMatrix();
}

void update_light_view()
{
  int viewport[4];
  glGetIntegerv(GL_VIEWPORT, viewport);
    if(light_view_version == master_light_view_version) return;

    if(!frameBufferObject)
      pbuffer.Activate();
    else
    {
      glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, frameBufferObject);
      glViewport(0, 0, TEX_SIZE, TEX_SIZE);
    }
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPolygonOffset(tweaks["polygon offset scale"].val,
                    tweaks["polygon offset bias"].val);
    glEnable(GL_POLYGON_OFFSET_FILL);


    render_scene_from_light_view();

    glDisable(GL_POLYGON_OFFSET_FILL);
    

    if(!frameBufferObject)
    {
      light_view_depth.bind();

      // trying different ways of getting the depth info over
      glCopyTexSubImage2D(GL_TEXTURE_2D, 0,   0, 0,   0, 0,  lightshaper.width, lightshaper.height);
      pbuffer.Deactivate();
    }
    else
    {
      glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
      glViewport(viewport[0], viewport[1], viewport[2], viewport[3]);
    }
}

void render_scene_from_camera_view()
{
    // place light
    glPushMatrix();
    glLoadIdentity();
    camera.apply_inverse_transform();
    spotlight.apply_transform();
    glLightfv(GL_LIGHT0, GL_POSITION, & vec4f(0,0,0,1)[0]);
    glPopMatrix();

    // spot image
    glActiveTextureARB(GL_TEXTURE1_ARB);

    glPushMatrix();
    camera.apply_inverse_transform();
    eye_linear_texgen();    
    texgen(true);
    glPopMatrix();

    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glTranslatef(.5f, .5f, .5f);
    glScalef(.5f, .5f, .5f);
    gluPerspective(lightshaper.fovy, 1, lightshaper.zNear, lightshaper.zFar);
    spotlight.apply_inverse_transform();
    glMatrixMode(GL_MODELVIEW);

    light_image.bind();
    light_image.enable();
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

    glActiveTextureARB(GL_TEXTURE0_ARB);
    reshaper.apply();
    render_scene(camera);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    light_image.disable();
    glActiveTextureARB(GL_TEXTURE0_ARB);

    render_light_frustum();
}

void render_scene_from_camera_view__shadowed()
{
    update_light_view();

    // place light
    glPushMatrix();
    glLoadIdentity();
    camera.apply_inverse_transform();
    spotlight.apply_transform();
    glLightfv(GL_LIGHT0, GL_POSITION, & vec4f(0,0,0,1)[0]);
    glPopMatrix();

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // spot image
    glActiveTextureARB(GL_TEXTURE1_ARB);

    glPushMatrix();
    camera.apply_inverse_transform();
    eye_linear_texgen();    
    texgen(true);
    glPopMatrix();

    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glTranslatef(.5f, .5f, .5f);
    glScalef(.5f, .5f, .5f);
    gluPerspective(lightshaper.fovy, 1, lightshaper.zNear, lightshaper.zFar);
    spotlight.apply_inverse_transform();
    glMatrixMode(GL_MODELVIEW);

    light_image.bind();
    light_image.enable();
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

    // depth compare
    glActiveTextureARB(GL_TEXTURE2_ARB);

    glPushMatrix();
    camera.apply_inverse_transform();
    eye_linear_texgen();    
    texgen(true);
    glPopMatrix();

    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glTranslatef(.5f, .5f, tweaks["r coordinate scale"].val);
    glScalef(.5f, .5f, tweaks["r coordinate bias"].val);
    gluPerspective(lightshaper.fovy, 1, lightshaper.zNear, lightshaper.zFar);
    spotlight.apply_inverse_transform();
    glMatrixMode(GL_MODELVIEW);

    light_view_depth.bind();
    light_view_depth.enable();
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    glActiveTextureARB(GL_TEXTURE0_ARB);

    reshaper.apply();
    render_scene(camera);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    light_image.disable();
    glActiveTextureARB(GL_TEXTURE2_ARB);
    light_view_depth.disable();
    glActiveTextureARB(GL_TEXTURE0_ARB);

    render_light_frustum();
}

void largest_square_power_of_two_viewport()
{
    GLfloat min = reshaper.width < reshaper.height ? reshaper.width : reshaper.height;
    GLfloat log2min = log(min) / log(2.0);
    GLfloat pow2 = floor(log2min);
    GLuint size = 1 << int(pow2);
    glViewport(0,0, size, size);
}

void render_scene_from_light_view()
{
    // place light
    glPushMatrix();
    glLoadIdentity();
    glLightfv(GL_LIGHT0, GL_POSITION, & vec4f(0,0,0,1)[0]);
    glPopMatrix();

    // spot image
    glActiveTextureARB(GL_TEXTURE1_ARB);

    glPushMatrix();
    eye_linear_texgen();    
    texgen(true);
    glPopMatrix();

    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glTranslatef(.5f, .5f, .5f);
    glScalef(.5f, .5f, .5f);
    gluPerspective(lightshaper.fovy, 1, lightshaper.zNear, lightshaper.zFar);
    glMatrixMode(GL_MODELVIEW);

    light_image.bind();
    light_image.enable();
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

    glActiveTextureARB(GL_TEXTURE0_ARB);

    lightshaper.apply();
    if(display_funcs[current_display_func] == render_scene_from_light_view)
        largest_square_power_of_two_viewport();
    render_scene(spotlight);

    glActiveTextureARB(GL_TEXTURE1_ARB);
    light_image.disable();
    glActiveTextureARB(GL_TEXTURE0_ARB);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    display_funcs[current_display_func]();
    glutSwapBuffers();
}

void idle()
{
    glutPostRedisplay();
}
