#if defined(WIN32)
#  include <windows.h>
#elif defined(UNIX)
#  include <GL/glx.h>
#endif

#include <stdio.h>

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>
#include <glh/glh_obs.h>
#include <glh/glh_glut.h>
#include <nvparse/nvparse.h>
#include <shared/quitapp.h>

using namespace glh;
using namespace std;

glut_callbacks cb;
glut_simple_mouse_interactor camera, object;
glut_perspective_reshaper reshaper;

static GLfloat texmatrix[16] = { 1.0, 0.0, 0.0, 0.0,
                                 0.0, 1.0, 0.0, 0.0,
                                 0.0, 0.0, 0.0, 0.0,
                                 1.5, 1.5, 0.0, 1.0 };

display_list ts_cullfragment;

void CheckParseErrors()
{
	for (char * const * errors = nvparse_get_errors(); *errors; errors++)
		fprintf(stderr, *errors);
}

void display()
{
    // Clear all pixels.
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    // Setup the viewing transformation
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
	camera.apply_inverse_transform();
	object.apply_transform();

    // Set the matrix which has the clipping planes.
    glActiveTextureARB( GL_TEXTURE0_ARB );
	glMatrixMode( GL_TEXTURE );
    glLoadMatrixf( texmatrix );

    glColor3f( 0, 0, 1.0 );
    glutWireCube( 3.0 );

    // Turn on the texture shader for fragment culling.
    glEnable( GL_TEXTURE_SHADER_NV );

	// Set the texture shader state.
	ts_cullfragment.call_list();

    // Draw a polygon with corners at
    // (0.25, 0.25, 0.0) and (0.75, 0.75, 0.0)
    // Use the texture shader GL_PASS_THROUGH_NV to determine the polygon's color.
    // (R,G,B,A) are given by the texture coordinates (s,t,r,q).
    glBegin( GL_POLYGON );
        glColor3f( 0, 0, 0 );
        glTexCoord2f( -1.0, -1.0 );
        glVertex3f( -0.75, -0.75, 0.0 );
        glColor3f( 1, 0, 0 );
        glTexCoord2f( 1.0, -1.0 );
        glVertex3f( 0.75, -0.75, 0.0 );
        glColor3f( 1, 1, 0 );
        glTexCoord2f( 1.0, 1.0 );
        glVertex3f( 0.75, 0.75, 0.0 );
        glColor3f( 0, 1, 0 );
        glTexCoord2f( -1.0, 1.0 );
        glVertex3f( -0.75, 0.75, 0.0 );
    glEnd();

    // Draw a sphere too.
    glColor3f( 0, 1, 1 );
    glEnable( GL_LIGHTING );
    glutSolidSphere( 0.65, 25, 25 );
    glDisable( GL_LIGHTING );

    // Turn off the texture shader.
    glDisable( GL_TEXTURE_SHADER_NV );

    // Draw the clip-planes.

    // Draw the x = -D clip plane.
    glColor3f( 0.5, 0.2, 0.5 );
    glBegin( GL_POLYGON );
        glVertex3f( -texmatrix[12], 1.5, 1.5 );
        glVertex3f( -texmatrix[12], -1.5, 1.5 );
        glVertex3f( -texmatrix[12], -1.5, -1.5 );
        glVertex3f( -texmatrix[12], 1.5, -1.5 );
    glEnd();

    // Draw the y = -D clip plane.
    glColor3f( 0.2, 0.5, 0.5 );
    glBegin( GL_POLYGON );
        glVertex3f( 1.5, -texmatrix[13], 1.5 );
        glVertex3f( 1.5, -texmatrix[13], -1.5 );
        glVertex3f( -1.5, -texmatrix[13], -1.5 );
        glVertex3f( -1.5, -texmatrix[13], 1.5 );
    glEnd();

    glutSwapBuffers();
}

void idle()
{
    static float delta1 = 0.003;
    static float delta2 = 0.001;
    static int dir1 = 1;
    static int dir2 = 1;

    // Update texture matrix to reflect current clip plane positions.
    texmatrix[13] = texmatrix[13] + dir1 * delta1;
    texmatrix[12] = texmatrix[12] + dir2 * delta2;
    if ( dir1 == 1 && texmatrix[13] > 1.5)
        {
        texmatrix[13] = 1.5;
        dir1 = -1;
        }
    else if ( dir1 == -1 && texmatrix[13] < -1.5)
        {
        texmatrix[13] = -1.5;
        dir1 = 1;
        }
    if ( dir2 == 1 && texmatrix[12] > 1.5)
        {
        texmatrix[12] = 1.5;
        dir2 = -1;
        }
    else if ( dir2 == -1 && texmatrix[12] < -1.5)
        {
        texmatrix[12] = -1.5;
        dir2 = 1;
        }

	object.trackball.increment_rotation();
	glutPostRedisplay();
}

void key( unsigned char k, int x, int y )
{
    if ( k == 27 || k == 'q' ) exit( 0 );
}

void init()
{
    // Initialize texture shading extension.
    if (!glh_init_extensions( "GL_NV_texture_shader" ) )
        {
        fprintf( stderr, "Could not find extensions string: GL_NV_texture_shader\n" );
        quitapp( 0 );
        }

    // Initialize multitexture extension.
    if (!glh_init_extensions( "GL_ARB_multitexture" ) )
        {
        fprintf( stderr, "Could not find extensions string: GL_ARB_multitexture\n" );
        quitapp( 0 );
        }

    glEnable( GL_DEPTH_TEST );

    // Initialize the clear color.
    glClearColor( 0.5, 0.5, 0.5, 0.0 );


    // Initialize texture shading.

    // Setup the shading operation to be Cull-Fragment
	ts_cullfragment.new_list( GL_COMPILE );
	nvparse(
		"!!TS1.0\n"
		"cull_fragment( GEQUAL_TO_ZERO, GEQUAL_TO_ZERO, GEQUAL_TO_ZERO, GEQUAL_TO_ZERO );\n"
		"nop();\n"
		"nop();\n"
		"nop();\n"
	);
	CheckParseErrors();
	ts_cullfragment.end_list();

    // Turn on object space texture coordinate generation.
    double sPlane[4] = { 1.0, 0.0, 0.0, 0.0 };
    double tPlane[4] = { 0.0, 1.0, 0.0, 0.0 };
    double rPlane[4] = { 0.0, 0.0, 1.0, 0.0 };

    glActiveTextureARB( GL_TEXTURE0_ARB );
	glEnable( GL_TEXTURE_GEN_S );
    glEnable( GL_TEXTURE_GEN_T );
    glEnable( GL_TEXTURE_GEN_R );

    glTexGeni( GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR );
    glTexGeni( GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR );
    glTexGeni( GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR );

    glTexGendv( GL_S, GL_OBJECT_PLANE, sPlane );
    glTexGendv( GL_T, GL_OBJECT_PLANE, tPlane );
    glTexGendv( GL_R, GL_OBJECT_PLANE, rPlane );

    // Setup the blending so that the diffuse color is displayed since the RGBA
    // generated by the Cull-Fragment shader is always (0,0,0,0).
    // Setting the combine mode to blend computes:  C = Cf
    nvparse(
		"!!RC1.0                                                            \n"
		"out.rgb = col0;                                                    \n"
	);
	CheckParseErrors();
	glEnable( GL_REGISTER_COMBINERS_NV );

    // Initialize the lighting.
    glEnable( GL_LIGHT0 );
    glEnable( GL_COLOR_MATERIAL );
    glColorMaterial( GL_FRONT, GL_DIFFUSE );
    GLfloat zero[4] = { 0.0, 0.0, 0.0, 0.0 };
    glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT, zero );
    glLightModeli( GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE );
    glEnable( GL_NORMALIZE );

    GLfloat pos[4] = { 0.0, 0.0, 5.0, 1.0 };
   	glLightfv( GL_LIGHT0, GL_POSITION, pos );
}


int main( int argc, char **argv )
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB );
    glutInitWindowSize( 512, 512 );
    glutCreateWindow( "Texture-Shader: GL_CULL_FRAGMENT_NV" );

    // Do some OpenGL initialization.
	init();

	glut_helpers_initialize();

	cb.keyboard_function = key;
	cb.idle_function = idle;
	camera.configure_buttons(1);
	camera.set_camera_mode(true);
	camera.pan.pan = vec3f( 0.0, 0.0, 5.0 );
	object.configure_buttons(1);
	object.dolly.dolly[2] = -1;

	glut_add_interactor(&cb);
	glut_add_interactor(&object);
	glut_add_interactor(&reshaper);

    glut_idle(1);

    glutDisplayFunc( display );
	glutMainLoop();
	return 0;
}
