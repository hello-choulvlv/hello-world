void initVertexNoiseConstants(int table_size);
