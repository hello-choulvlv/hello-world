#ifndef IMAGEFBO_H
#define IMAGEFBO_H
// ------------------------------------------------------------------
//
// Description:
//      Image FBO is a proxy class for FBO Buffers. 
//          Its sole purpose is to reference count FBO Buffers and 
//      provide infrastructure for efficient resource handling (i.e.
//      freelist).
//
// Author:
//      Eric Young (2003)
//
// ------------------------------------------------------------------


//
// Pragmas
//

#pragma warning(disable:4786) // stupid STL truncation warning


//
// Includes
//

#ifdef _WIN32
    #include <windows.h>
#endif

#include <gl/gl.h>

#include <map>


//
// Forward declarations
//
class FBOBuffer;

// -----------------------------------------------------------------------------
// ImageFBO class
//
class ImageFBO
{
public:
    //
    // Public static data
    //

    static int gnNumberOfBuffers;

public:
    //
    // Construction and destruction
    //

            // Default constructor
            //
    ImageFBO();

            // Constructor
            //
    ImageFBO(int nWidth, int nHeight);

            // Copy constructor
            //
    ImageFBO(const ImageFBO & rImage);

            // Destructor
            //
   ~ImageFBO();


    // 
    // Public methods
    //

            // width
            //
            // Description:
            //      Get the image's width.
            //
            // Parameters:
            //      None
            //
            // Returns:
            //      ImageFBO width.
            //
            int
    width()
            const;

            // height
            //
            // Description:
            //      Get the image's height.
            //
            // Parameters:
            //      None
            //
            // Returns:
            //      ImageFBO height.
            //
            int
    height()
            const;

            // setSize
            //
            // Description:
            //      Set a new image size.
            //          The method resizes the internal buffer in
            //      which the image is stored by deleting the current
            //      buffer and creating a new one in the desired size.
            //      All image data is lost.
            //
            // Parameters:
            //      nWidth  - new image width.
            //      nHeight - new image height.
            //
            // Returns:
            //      None
            //
            // Note:
            //      If either width or height is zero the size is
            //      set to width = height = 0.
            //
            void
    setSize(int nWidth, int nHeight);

            // texture
            //
            // Description:
            //      Get the GL texture handle to the image's
            //      texture.
            //
            // Parameters:
            //      None
            //
            // Returns:
            //      A GLuint with the texture id.
            //
            GLuint
    textureID()
            const;

            // Assitnment operator
            //
            // Description:
            //      Copy one image to an other.
            //
            // Parameters
            //      rImage - the image to be copied.
            //
            // Returns:
            //      A reference to it self.
            //
            ImageFBO &
    operator=(const ImageFBO & rImage);

            // renderBegin
            //
            // Description:
            //      Makes this buffer the target for rendering.
            //          Instead of rendering to the frame buffer
            //      OpenGL commands render to this buffer if
            //      issued after the renderBegin() command.
            //
            // Parameters:
            //      None
            //
            // Returns:
            //      None
            //
            void
    renderBegin();

            // renderEnd
            //
            // Description:
            //      Resets rendering to the previous state.
            //          After this command was issued this buffer may
            //      be used as a texture (textureID command).
            //
            // Parameters:
            //      None
            //
            // Returns:
            //      None
            //
            void
    renderEnd();


protected:
    //
    // Protected typedefs
    //

    struct tSize
    {
        tSize(int nWidth, int nHeight): _nWidth(nWidth), _nHeight(nHeight)
        { /* empty */  };
        
        int _nWidth;
        int _nHeight;

        bool operator<(const tSize & rSize) const
        {
            if (_nWidth == rSize._nWidth)
            {
                if (_nHeight < rSize._nHeight)
                    return true;
                else
                    return false;
            }
            if (_nWidth < rSize._nWidth)
                return true;
            else 
                return false;
        };
    };
    
    typedef std::multimap<tSize, FBOBuffer *>	tFBOBufferMap;
   
    //
    // Protected static methods
    //

            static 
            FBOBuffer * 
    GetBuffer(int nWidth, int nHeight);

            static
            void
    ReturnBuffer(FBOBuffer * pBuffer);

    // 
    // Protected static data
    //

    static tFBOBufferMap	_goBuffers;

private:
    //
    // Private data
    //

	FBOBuffer	* _pFBOBuffer;
};

#endif // IMAGE_H
