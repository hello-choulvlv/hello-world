void init_FFT ( int n );
void stable_solve ( int n, float * u, float * v, float * u0, float * v0, float visc, float dt );
