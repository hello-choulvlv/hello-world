// ----------------------------------------------------------------------------
// 
// Content:
//      ImagePusherPBO class
//
// Description:
//      A class managing OpenEXR images via OpenGL pixel buffer objects (PBO).
//
// Author: Frank Jargstorff (03/10/04)
//
// Note:
//      Copyright (C) 2004 by NVIDIA Croporation. All rights reserved.
//
// ----------------------------------------------------------------------------


//
// Includes
//

#include "ImagePusherPBO.h"

#include "OpenEXRLoader.h"

#include <assert.h>

#include <glh/glh_extensions.h>


//
// Macros
//

#define BUFFER_OFFSET(i) ((char *)NULL + (i))


// ----------------------------------------------------------------------------
// ImagePBO class
//

    //
    // Public data
    //
    
const char * ImagePusherPBO::ClassName = "ImagePusherPBO";
const char * ImagePusherPBO::ClassDescription = "PBO";

    //
    // Construction and destruction
    //

        // Default constructor
        //
ImagePusherPBO::ImagePusherPBO(): ImagePusher()
                                , _hPixelBuffer(0)
{
                                // Initialize the PBO extension. 
    if (!glh_init_extensions("GL_ARB_vertex_buffer_object "
                             "GL_EXT_pixel_buffer_object ")) 
    {
        std::cerr << "Error - required extensions were not supported: " << glh_get_unsupported_extensions()
                  << std::endl;
        exit(-1);
    }

    glGenBuffersARB(1, &_hPixelBuffer);
}

        // Destructor
        //
ImagePusherPBO::~ImagePusherPBO()
{
    unbind();
    glDeleteBuffersARB(1, &_hPixelBuffer);
}


    //
    // Public methods
    //

        // setImage
        //
        // Description:
        //      Specify a new image.
        //
        // Parameters:
        //      rImage - const reference to iamge object.
        //
        // Returns:
        //      None
        //
        void
ImagePusherPBO::setImage(const Image & rImage)
{
                                // create texture object and local image copy
    ImagePusher::setImage(rImage);
                                // bind pixel-buffer object
    glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_NV, _hPixelBuffer);
                                // create pixel-buffer data container
    glBufferDataARB(GL_PIXEL_UNPACK_BUFFER_EXT, _oImage.imageDataSize(), NULL, GL_STREAM_DRAW_ARB);
    unsigned char * pPixelsPBO = static_cast<unsigned char *>(glMapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, GL_WRITE_ONLY));
                                // copy image data into the buffer
    memcpy(pPixelsPBO, _oImage.data(), _oImage.imageDataSize());
    
    if (!glUnmapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT))
    {
        std::cerr << "Couldn't unmap pixel buffer. Exiting\n";
        assert(false);
    }
                                // unbind pixel-buffer object
    glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_NV, 0);
}


        

        // pushNewFrame
        //
        // Description:
        //      Pushes a new frame up to the graphics board.
        //          This specific image pusher imprints a time stamp
        //      bit-pattern in the left-bottom corner of the image.
        //
        // Parameters:
        //      nFrameStamp - the frame number to imprint.
        //
        // Returns:
        //      The number of bytes actually pushed across the bus
        //      to the graphics card.
        //
        unsigned int
ImagePusherPBO::pushNewFrame()
{
    glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_NV, _hPixelBuffer);
    
    void * pPixelData = glMapBufferARB(GL_PIXEL_UNPACK_BUFFER_NV, GL_WRITE_ONLY);
    
    imprintPixelData(pPixelData, _nFrameCounter);
    
    if (!glUnmapBufferARB(GL_PIXEL_UNPACK_BUFFER_NV))
    {
        std::cerr << "Couldn't unmap pixel buffer. Exiting\n";
        assert(false);
    }
                                // bind the texture object
    bind();                   
                                // copy buffer contents into the texture
    glTexSubImage2D(GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, _oImage.width(), _oImage.height(), 
                    _oImage.glTextureFormat(), _oImage.glTextureType(), BUFFER_OFFSET(0));

    glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_NV, 0);

    _nFrameCounter++;
    
    return _oImage.imageDataSize();
}
        
