!!TS1.0
texture_2d(); // intermediate texture
dependent_gb(tex0);
nop();
nop();