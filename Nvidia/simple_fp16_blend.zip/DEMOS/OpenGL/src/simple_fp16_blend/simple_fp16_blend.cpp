/*
    Simple 16-bit floating point blending example

    This example renders an image repeatedly into a
    fp16 pbuffer using additive blending, and then displays
    the result as a textured quad with a fragment program
    that multiplies the texture color by an exposure value.

    requires:
    GL_ARB_texture_non_power_of_two
    GL_ATI_texture_float
    WGL_ATI_pixel_format_float

    sgreen 3/17/2004
*/

#if defined(WIN32)
#  include <windows.h>
#endif

#include <ImfRgbaFile.h>
#include <ImfStringAttribute.h>
#include <ImfMatrixAttribute.h>
#include <ImfArray.h>
#include <iostream>

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>
#include <glh/glh_glut.h>
#include <shared/pbuffer.h>
#include <shared/data_path.h>
#include <shared/quitapp.h>

#define USE_FP16 1

using namespace glh;
using namespace Imf;
using namespace Imath;

bool b[256];
glut_simple_mouse_interactor object;

int win_w = 512, win_h = 512;
PBuffer *pbuffer;
GLuint pbuffer_tex;
GLuint display_fprog, render_fprog;
float exposure = 4.0;
float alpha = 0.1;
float alpha2 = 0.01;
GLuint image_tex;
GLenum img_target = GL_TEXTURE_2D;
int blendmode = 0;
//GLenum img_target = GL_TEXTURE_RECTANGLE_NV;

// display fragment program
const char *display_code =
"!!ARBfp1.0\n"
"PARAM exposure = program.local[0];\n"
"TEMP tex0;\n"
"TEX tex0, fragment.texcoord, texture[0], 2D;\n"  // lookup in texture
"MUL result.color, tex0, exposure.x;\n"           // multiply by exposure
"END\n";

const char *render_code =
"!!ARBfp1.0\n"
"TEMP tex0;\n"
"TEX tex0, fragment.texcoord, texture[0], 2D;\n"  // lookup texture
"MUL result.color, tex0, fragment.color.a;\n"     // multiply by fragment alpha (modulate texenv)
"END\n";

GLuint create_texture(GLenum target, GLenum internalformat, int width, int height, GLenum format, GLenum type);
GLuint load_program(GLenum program_type, const char *code);
void resize(int w, int h);

// load an OpenEXR format image from disk
Array2D<Rgba> *
load_OpenEXR(char *filename, int &width, int &height)
{
  RgbaInputFile file (filename);
  Array2D<Rgba> *pixels = new Array2D<Rgba>;

  Box2i dw = file.dataWindow();
  width = dw.max.x - dw.min.x + 1;
  height = dw.max.y - dw.min.y + 1;
  pixels->resizeErase (height, width);

  file.setFrameBuffer (&(*pixels)[height-1][0], 1, -width);  // flip image vertically
  file.readPixels (dw.min.y, dw.max.y);
  return pixels;
}

void init_opengl()
{
    if (!glh_init_extensions(
		"GL_ARB_vertex_program "
		"GL_ARB_fragment_program "
        "WGL_ARB_extensions_string "
        "WGL_ARB_pbuffer "
        "WGL_ARB_pixel_format "
        "WGL_ARB_render_texture "
        "GL_ATI_texture_float "
        "WGL_ATI_pixel_format_float "
        "GL_ARB_texture_non_power_of_two"
		))
    {
        printf("Unable to load the following extension(s): %s\n\nExiting...\n", 
               glh_get_unsupported_extensions());
        quitapp(-1);
    }

    printf("GL Extensions: %s\n", glGetString(GL_EXTENSIONS));
    printf("WGL Extensions: %s\n", wglGetExtensionsStringARB(GetDC(0)));

    glClearColor(0.2, 0.2, 0.2, 1.0);
    glDisable(GL_DEPTH_TEST);
    resize(win_w, win_h);

    // create 16-bit float p-buffer
#if USE_FP16
    pbuffer = new PBuffer("ati_float=16 rgba depth");
#else
    pbuffer = new PBuffer("rgba depth");
#endif
    pbuffer->Initialize(win_w, win_h, false, true);
    pbuffer->Activate();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glDisable(GL_DEPTH_TEST);
    // create texture
#if USE_FP16
    pbuffer_tex = create_texture(GL_TEXTURE_2D, GL_RGBA_FLOAT16_ATI, win_w, win_h, GL_RGBA, GL_FLOAT);
#else
    pbuffer_tex = create_texture(GL_TEXTURE_2D, GL_RGBA, win_w, win_h, GL_RGBA, GL_FLOAT);
#endif
    resize(win_w, win_h);

	  display_fprog = load_program(GL_FRAGMENT_PROGRAM_ARB, display_code);
	  render_fprog = load_program(GL_FRAGMENT_PROGRAM_ARB, render_code);

    // load image
    data_path media;
    media.path.push_back(".");
    media.path.push_back("../../../../MEDIA/textures/2D/");

    glGenTextures(1, &image_tex);
    glBindTexture(img_target, image_tex);
    glTexParameteri(img_target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(img_target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(img_target, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(img_target, GL_TEXTURE_WRAP_T, GL_CLAMP);

    int w, h;
    Array2D<Imf::Rgba> *pixels;
    pixels = load_OpenEXR("../../../../MEDIA/textures/hdr/StillLife.pt.exr", w, h);
    glTexImage2D(img_target, 0, GL_RGBA_FLOAT16_ATI, w, h, 0, GL_RGBA, GL_HALF_FLOAT_NV, (*pixels)[0]);
    delete pixels;
}

GLuint create_texture(GLenum target, GLenum internalformat, int width, int height, GLenum format, GLenum type)
{
  GLuint tex;
  glGenTextures(1, &tex);
  glBindTexture(target, tex);
  glTexParameteri(target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexImage2D(target, 0, internalformat, width, height, 0, format, type, 0);
  return tex;
}

// load a vertex or fragment program from a string
GLuint load_program(GLenum program_type, const char *code)
{
	GLuint program_id;
	glGenProgramsARB(1, &program_id);
	glBindProgramARB(program_type, program_id);
	glProgramStringARB(program_type, GL_PROGRAM_FORMAT_ASCII_ARB, (GLsizei) strlen(code), (GLubyte *) code);

	GLint error_pos;
	glGetIntegerv(GL_PROGRAM_ERROR_POSITION_ARB, &error_pos);
	if (error_pos != -1) {
		const GLubyte *error_string;
		error_string = glGetString(GL_PROGRAM_ERROR_STRING_ARB);
		fprintf(stderr, "Program error at position: %d\n%s\n", error_pos, error_string);
	}
	return program_id;
}

void draw_quad()
{
  glBegin(GL_QUADS);
  glTexCoord2f(0, 0); glVertex2f(-1, -1);
  glTexCoord2f(1, 0); glVertex2f(1, -1);
  glTexCoord2f(1, 1); glVertex2f(1, 1);
  glTexCoord2f(0, 1); glVertex2f(-1, 1);
  glEnd();
}

void draw_quad_rect(int w, int h)
{
  glBegin(GL_QUADS);
  glTexCoord2f(0, 0); glVertex2f(-1, -1);
  glTexCoord2f(w, 0); glVertex2f(1, -1);
  glTexCoord2f(w, h); glVertex2f(1, 1);
  glTexCoord2f(0, h); glVertex2f(-1, 1);
  glEnd();
}

// darken whole screen by blending full-window quad
void draw_blended_quad()
{
  if (b['b']) {
    switch(blendmode) {
      case 0:
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        break;
      case 1:
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        break;
    }
    glEnable(GL_BLEND);
  } else {
    glDisable(GL_BLEND);
  }
  glColor4f(1.0, 1.0, 1.0, alpha);
  glBindTexture(img_target, image_tex);
  glBindProgramARB(GL_FRAGMENT_PROGRAM_ARB, render_fprog);
  glEnable(GL_FRAGMENT_PROGRAM_ARB);
  draw_quad();
  glDisable(GL_FRAGMENT_PROGRAM_ARB);
  glDisable(GL_BLEND);
}

// darken screen by blending a full-screen quad
void darken_screen()
{
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glColor4f(0.0, 0.0, 0.0, alpha2);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  draw_quad();
  glPopMatrix();
  glDisable(GL_BLEND);
}

// display pbuffer by copying to texture and drawing a textured quad
void display_pbuffer()
{
  // copy frame buffer to texture
  glBindTexture(GL_TEXTURE_2D, pbuffer_tex);
  glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, win_w, win_h);

  // display pbuffer contents by drawing a textured quad to window
  pbuffer->Deactivate();
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();

  glEnable(GL_FRAGMENT_PROGRAM_ARB);
  glBindProgramARB(GL_FRAGMENT_PROGRAM_ARB, display_fprog);
	glProgramLocalParameter4fARB(GL_FRAGMENT_PROGRAM_ARB, 0, exposure, 0, 0, 0);

  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
  draw_quad();
  glDisable(GL_FRAGMENT_PROGRAM_ARB);

  glPopMatrix();
}

void display()
{
  // render to pbuffer
  pbuffer->Activate();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  object.apply_transform();

  draw_blended_quad();
  if (b['d']) {
    darken_screen();
  }

  // display
  display_pbuffer();

  glutSwapBuffers();
  glutReportErrors();
}

void idle()
{
  if (b[' ']) {
    object.trackball.increment_rotation();
    glutPostRedisplay();
  }
}

void key(unsigned char k, int x, int y)
{
	b[k] = ! b[k];
  switch(k) {
    case 27:
    case 'q':
      exit(0);
      break;

    case 'c':
      pbuffer->Activate();
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      break;

    case '=':
    case '+':
      exposure *= 2.0;
      break;

    case '-':
      exposure *= 0.5;
      break;

    case '1':
    case '2':
      blendmode = k - '1';
      break;

    case ']':
      if (alpha < 1.0) alpha += 0.01;
      break;
    case '[':
      if (alpha > 0.0) alpha -= 0.01;
      break;
    case '}':
      if (alpha2 < 1.0) alpha2 += 0.01;
      break;
    case '{':
      if (alpha2 > 0.0) alpha2 -= 0.01;
      break;
  }
  printf("exposure = %f, alpha = %f  alpha2 = %f\n", exposure, alpha, alpha2);
  object.keyboard(k, x, y);
	glutPostRedisplay();
}

void resize(int w, int h)
{
    if (h == 0) h = 1;

    glViewport(0, 0, w, h);
    
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    gluPerspective(60.0, (GLfloat)w/(GLfloat)h, 0.1, 100.0);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    object.reshape(w, h);
}

void mouse(int button, int state, int x, int y)
{
    object.mouse(button, state, x, y);
}

void motion(int x, int y)
{
    object.motion(x, y);
}

void main_menu(int i)
{
  key((unsigned char) i, 0, 0);
}

void init_menus()
{
  glutCreateMenu(main_menu);
  glutAddMenuEntry("Clear [c]", 'c');
  glutAddMenuEntry("Toggle animation [ ]", ' ');
  glutAddMenuEntry("Toggle darkening [d]", 'd');
  glutAddMenuEntry("Toggle blending [b]", 'b');
  glutAddMenuEntry("Blend mode: additive [1]", '1');
  glutAddMenuEntry("Blend mode: over [2]", '2');
  glutAddMenuEntry("Increase exposure [+]", '+');
  glutAddMenuEntry("Decrease exposure [-]", '-');
  glutAddMenuEntry("Quit (esc)", '\033');
  glutAttachMenu(GLUT_RIGHT_BUTTON);
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitWindowSize(win_w, win_h);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB);
	glutCreateWindow("simple_fp16_blend");

	init_opengl();
  init_menus();

  object.configure_buttons(1);
  object.dolly.dolly[2] = -2;
  object.trackball.incr = rotationf(vec3f(0.0, 1.0, 0.0), 0.01);

	glutDisplayFunc(display);
  glutMouseFunc(mouse);
  glutMotionFunc(motion);
  glutIdleFunc(idle);
  glutKeyboardFunc(key);
  glutReshapeFunc(resize);

  b[' '] = true;
  b['d'] = true;
  b['b'] = true;

	glutMainLoop();

	return 0;
}