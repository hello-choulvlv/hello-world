#ifdef WIN32
#  include <windows.h>
#endif

#ifdef MACOS
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

#include <stdio.h>
#include <math.h>
#include <iostream>

#include <shared/data_path.h>
#include "md2.h"

#include <map>


using namespace std;
using namespace md2;

namespace
{

	// normal table lifted from Mark Kilgard's md2bump demo
  float normal_table[][3]= 
  {
	  {-0.525731f, 0.000000f, 0.850651f}, 
	  {-0.442863f, 0.238856f, 0.864188f}, 
	  {-0.295242f, 0.000000f, 0.955423f}, 
	  {-0.309017f, 0.500000f, 0.809017f}, 
	  {-0.162460f, 0.262866f, 0.951056f}, 
	  {0.000000f, 0.000000f, 1.000000f}, 
	  {0.000000f, 0.850651f, 0.525731f}, 
	  {-0.147621f, 0.716567f, 0.681718f}, 
	  {0.147621f, 0.716567f, 0.681718f}, 
	  {0.000000f, 0.525731f, 0.850651f}, 
	  {0.309017f, 0.500000f, 0.809017f}, 
	  {0.525731f, 0.000000f, 0.850651f}, 
	  {0.295242f, 0.000000f, 0.955423f}, 
	  {0.442863f, 0.238856f, 0.864188f}, 
	  {0.162460f, 0.262866f, 0.951056f}, 
	  {-0.681718f, 0.147621f, 0.716567f}, 
	  {-0.809017f, 0.309017f, 0.500000f}, 
	  {-0.587785f, 0.425325f, 0.688191f}, 
	  {-0.850651f, 0.525731f, 0.000000f}, 
	  {-0.864188f, 0.442863f, 0.238856f}, 
	  {-0.716567f, 0.681718f, 0.147621f}, 
	  {-0.688191f, 0.587785f, 0.425325f}, 
	  {-0.500000f, 0.809017f, 0.309017f}, 
	  {-0.238856f, 0.864188f, 0.442863f}, 
	  {-0.425325f, 0.688191f, 0.587785f}, 
	  {-0.716567f, 0.681718f, -0.147621f}, 
	  {-0.500000f, 0.809017f, -0.309017f}, 
	  {-0.525731f, 0.850651f, 0.000000f}, 
	  {0.000000f, 0.850651f, -0.525731f}, 
	  {-0.238856f, 0.864188f, -0.442863f}, 
	  {0.000000f, 0.955423f, -0.295242f}, 
	  {-0.262866f, 0.951056f, -0.162460f}, 
	  {0.000000f, 1.000000f, 0.000000f}, 
	  {0.000000f, 0.955423f, 0.295242f}, 
	  {-0.262866f, 0.951056f, 0.162460f}, 
	  {0.238856f, 0.864188f, 0.442863f}, 
	  {0.262866f, 0.951056f, 0.162460f}, 
	  {0.500000f, 0.809017f, 0.309017f}, 
	  {0.238856f, 0.864188f, -0.442863f}, 
	  {0.262866f, 0.951056f, -0.162460f}, 
	  {0.500000f, 0.809017f, -0.309017f}, 
	  {0.850651f, 0.525731f, 0.000000f}, 
	  {0.716567f, 0.681718f, 0.147621f}, 
	  {0.716567f, 0.681718f, -0.147621f}, 
	  {0.525731f, 0.850651f, 0.000000f}, 
	  {0.425325f, 0.688191f, 0.587785f}, 
	  {0.864188f, 0.442863f, 0.238856f}, 
	  {0.688191f, 0.587785f, 0.425325f}, 
	  {0.809017f, 0.309017f, 0.500000f}, 
	  {0.681718f, 0.147621f, 0.716567f}, 
	  {0.587785f, 0.425325f, 0.688191f}, 
	  {0.955423f, 0.295242f, 0.000000f}, 
	  {1.000000f, 0.000000f, 0.000000f}, 
	  {0.951056f, 0.162460f, 0.262866f}, 
	  {0.850651f, -0.525731f, 0.000000f}, 
	  {0.955423f, -0.295242f, 0.000000f}, 
	  {0.864188f, -0.442863f, 0.238856f}, 
	  {0.951056f, -0.162460f, 0.262866f}, 
	  {0.809017f, -0.309017f, 0.500000f}, 
	  {0.681718f, -0.147621f, 0.716567f}, 
	  {0.850651f, 0.000000f, 0.525731f}, 
	  {0.864188f, 0.442863f, -0.238856f}, 
	  {0.809017f, 0.309017f, -0.500000f}, 
	  {0.951056f, 0.162460f, -0.262866f}, 
	  {0.525731f, 0.000000f, -0.850651f}, 
	  {0.681718f, 0.147621f, -0.716567f}, 
	  {0.681718f, -0.147621f, -0.716567f}, 
	  {0.850651f, 0.000000f, -0.525731f}, 
	  {0.809017f, -0.309017f, -0.500000f}, 
	  {0.864188f, -0.442863f, -0.238856f}, 
	  {0.951056f, -0.162460f, -0.262866f}, 
	  {0.147621f, 0.716567f, -0.681718f}, 
	  {0.309017f, 0.500000f, -0.809017f}, 
	  {0.425325f, 0.688191f, -0.587785f}, 
	  {0.442863f, 0.238856f, -0.864188f}, 
	  {0.587785f, 0.425325f, -0.688191f}, 
	  {0.688191f, 0.587785f, -0.425325f}, 
	  {-0.147621f, 0.716567f, -0.681718f}, 
	  {-0.309017f, 0.500000f, -0.809017f}, 
	  {0.000000f, 0.525731f, -0.850651f}, 
	  {-0.525731f, 0.000000f, -0.850651f}, 
	  {-0.442863f, 0.238856f, -0.864188f}, 
	  {-0.295242f, 0.000000f, -0.955423f}, 
	  {-0.162460f, 0.262866f, -0.951056f}, 
	  {0.000000f, 0.000000f, -1.000000f}, 
	  {0.295242f, 0.000000f, -0.955423f}, 
	  {0.162460f, 0.262866f, -0.951056f}, 
	  {-0.442863f, -0.238856f, -0.864188f}, 
	  {-0.309017f, -0.500000f, -0.809017f}, 
	  {-0.162460f, -0.262866f, -0.951056f}, 
	  {0.000000f, -0.850651f, -0.525731f}, 
	  {-0.147621f, -0.716567f, -0.681718f}, 
	  {0.147621f, -0.716567f, -0.681718f}, 
	  {0.000000f, -0.525731f, -0.850651f}, 
	  {0.309017f, -0.500000f, -0.809017f}, 
	  {0.442863f, -0.238856f, -0.864188f}, 
	  {0.162460f, -0.262866f, -0.951056f}, 
	  {0.238856f, -0.864188f, -0.442863f}, 
	  {0.500000f, -0.809017f, -0.309017f}, 
	  {0.425325f, -0.688191f, -0.587785f}, 
	  {0.716567f, -0.681718f, -0.147621f}, 
	  {0.688191f, -0.587785f, -0.425325f}, 
	  {0.587785f, -0.425325f, -0.688191f}, 
	  {0.000000f, -0.955423f, -0.295242f}, 
	  {0.000000f, -1.000000f, 0.000000f}, 
	  {0.262866f, -0.951056f, -0.162460f}, 
	  {0.000000f, -0.850651f, 0.525731f}, 
	  {0.000000f, -0.955423f, 0.295242f}, 
	  {0.238856f, -0.864188f, 0.442863f}, 
	  {0.262866f, -0.951056f, 0.162460f}, 
	  {0.500000f, -0.809017f, 0.309017f}, 
	  {0.716567f, -0.681718f, 0.147621f}, 
	  {0.525731f, -0.850651f, 0.000000f}, 
	  {-0.238856f, -0.864188f, -0.442863f}, 
	  {-0.500000f, -0.809017f, -0.309017f}, 
	  {-0.262866f, -0.951056f, -0.162460f}, 
	  {-0.850651f, -0.525731f, 0.000000f}, 
	  {-0.716567f, -0.681718f, -0.147621f}, 
	  {-0.716567f, -0.681718f, 0.147621f}, 
	  {-0.525731f, -0.850651f, 0.000000f}, 
	  {-0.500000f, -0.809017f, 0.309017f}, 
	  {-0.238856f, -0.864188f, 0.442863f}, 
	  {-0.262866f, -0.951056f, 0.162460f}, 
	  {-0.864188f, -0.442863f, 0.238856f}, 
	  {-0.809017f, -0.309017f, 0.500000f}, 
	  {-0.688191f, -0.587785f, 0.425325f}, 
	  {-0.681718f, -0.147621f, 0.716567f}, 
	  {-0.442863f, -0.238856f, 0.864188f}, 
	  {-0.587785f, -0.425325f, 0.688191f}, 
	  {-0.309017f, -0.500000f, 0.809017f}, 
	  {-0.147621f, -0.716567f, 0.681718f}, 
	  {-0.425325f, -0.688191f, 0.587785f}, 
	  {-0.162460f, -0.262866f, 0.951056f}, 
	  {0.442863f, -0.238856f, 0.864188f}, 
	  {0.162460f, -0.262866f, 0.951056f}, 
	  {0.309017f, -0.500000f, 0.809017f}, 
	  {0.147621f, -0.716567f, 0.681718f}, 
	  {0.000000f, -0.525731f, 0.850651f}, 
	  {0.425325f, -0.688191f, 0.587785f}, 
	  {0.587785f, -0.425325f, 0.688191f}, 
	  {0.688191f, -0.587785f, 0.425325f}, 
	  {-0.955423f, 0.295242f, 0.000000f}, 
	  {-0.951056f, 0.162460f, 0.262866f}, 
	  {-1.000000f, 0.000000f, 0.000000f}, 
	  {-0.850651f, 0.000000f, 0.525731f}, 
	  {-0.955423f, -0.295242f, 0.000000f}, 
	  {-0.951056f, -0.162460f, 0.262866f}, 
	  {-0.864188f, 0.442863f, -0.238856f}, 
	  {-0.951056f, 0.162460f, -0.262866f}, 
	  {-0.809017f, 0.309017f, -0.500000f}, 
	  {-0.864188f, -0.442863f, -0.238856f}, 
	  {-0.951056f, -0.162460f, -0.262866f}, 
	  {-0.809017f, -0.309017f, -0.500000f}, 
	  {-0.681718f, 0.147621f, -0.716567f}, 
	  {-0.681718f, -0.147621f, -0.716567f}, 
	  {-0.850651f, 0.000000f, -0.525731f}, 
	  {-0.688191f, 0.587785f, -0.425325f}, 
	  {-0.587785f, 0.425325f, -0.688191f}, 
	  {-0.425325f, 0.688191f, -0.587785f}, 
	  {-0.425325f, -0.688191f, -0.587785f}, 
	  {-0.587785f, -0.425325f, -0.688191f}, 
	  {-0.688191f, -0.587785f, -0.425325f}
};

    inline void swap_endian(void *val)
    {
#ifdef MACOS
        unsigned int *ival = (unsigned int *)val;
        
        *ival = ((*ival >> 24) & 0x000000ff) |
                ((*ival >>  8) & 0x0000ff00) |
                ((*ival <<  8) & 0x00ff0000) |
                ((*ival << 24) & 0xff000000);
#endif
    }

    data_path path;
}

/***************************
Load a MD2 into md2_t struct
***************************/
int md2::load_md2_file(const char * filename, f_model * md2p)
{
    FILE * fp;
    f_header md2header;

    md2p->open = false;


    static int init = 0;
    if(init == 1) // never do this (for now)
    {
        int sz = sizeof(normal_table)/(sizeof(float)*3);
        init = 1;
        for(int i=0; i < sz; i++)
        {
            normal_table[i][0] *= -1;
            normal_table[i][1] *= -1;
            normal_table[i][2] *= -1;
        }
    }

    // search path for models...
    if(path.path.size() < 1)
    {
        path.path.push_back(".");
        path.path.push_back("../../../MEDIA/models");
        path.path.push_back("../../../../MEDIA/models");
        path.path.push_back("../../../../../../../MEDIA/models");
    }

    //Open md2 file
    if ((fp = path.fopen(filename, "rb")) == 0 )
    {
        fprintf(stderr, "Unable to load %s\n", filename);
        return 0;
    }

    //read-in md2 header
    fread(&md2header, sizeof(f_header), 1, fp);

    swap_endian(&md2header.ident);
    swap_endian(&md2header.version);
    swap_endian(&md2header.skinwidth);
    swap_endian(&md2header.skinheight);
    swap_endian(&md2header.framesize);
    swap_endian(&md2header.num_skins);
    swap_endian(&md2header.num_xyz);
    swap_endian(&md2header.num_st);
    swap_endian(&md2header.num_tris);
    swap_endian(&md2header.num_glcmds);
    swap_endian(&md2header.num_frames);
    swap_endian(&md2header.ofs_skins);
    swap_endian(&md2header.ofs_st);
    swap_endian(&md2header.ofs_tris);
    swap_endian(&md2header.ofs_frames);
    swap_endian(&md2header.ofs_glcmds);
    swap_endian(&md2header.ofs_end);

    //alloc space and read-in frame info
    md2p->frames = new char [md2header.framesize * md2header.num_frames];

    if (md2p->frames == 0) return 0;
    fseek(fp, md2header.ofs_frames, SEEK_SET);

    unsigned int i = 0;
    f_frame *tmp_frame = (f_frame *)md2p->frames;

    for (i = 0; i < md2header.num_frames; i++)
    {
        fread(tmp_frame, md2header.framesize, 1, fp);
        swap_endian(&tmp_frame->scale[0]);
        swap_endian(&tmp_frame->scale[1]);
        swap_endian(&tmp_frame->scale[2]);

        swap_endian(&tmp_frame->translate[0]);
        swap_endian(&tmp_frame->translate[1]);
        swap_endian(&tmp_frame->translate[2]);

        tmp_frame = (f_frame*)((char *) tmp_frame + md2header.framesize);
    }

    //alloc space and read-in GL commands
    md2p->glcmds = new long [md2header.num_glcmds];
    if (md2p->glcmds == 0) { delete [] md2p->frames; return 0;}
    fseek(fp, md2header.ofs_glcmds, SEEK_SET);

    for (i = 0; i < md2header.num_glcmds; i++)
    {
        fread(&md2p->glcmds[i], 1, sizeof(unsigned long), fp);
        swap_endian(&md2p->glcmds[i]);
    }

    //move important info from header into md2 struct
    md2p->numframes = md2header.num_frames;
    md2p->numglcmds = md2header.num_glcmds;
    md2p->framesize = md2header.framesize;

    fclose(fp);	

    md2p->open = true;
    
return 1;
}

namespace
{
	vertex extract_vertex(long * & command)
	{
		vertex v;
		v.tc.s = *((float*)command); command++;
		v.tc.t = *((float*)command); command++;
		v.pn_index = *command; command++;
		return v;
	}
	
#define NUM_VERTS(b) (((b)>>2) - 10)
	
	struct iframe
	{
		std::vector<position_normal> pn;
		std::vector<triangle> tri;
	};
	
	
	int load_frames(const char * filename, vector<iframe> * md2p)
	{
		
		f_model mf;

		if( ! load_md2_file(filename, & mf) )
            return 0;

		vector<iframe> & m = * md2p;
		
		int i;
		for(i=0; i < mf.numframes; i++)
		{
			m.push_back(iframe());
			iframe & f = m.back();
			f_frame * curframe = (f_frame *) ((char *)mf.frames + i * mf.framesize);
			int num_verts = NUM_VERTS(mf.framesize);
			for(int j=0; j < num_verts; j++)
			{
				position_normal pn;
				
				pn.x = ((curframe->verts[j].v[0] * curframe->scale[0]) + curframe->translate[0]) * .025;
				pn.y = ((curframe->verts[j].v[1] * curframe->scale[1]) + curframe->translate[1]) * .025;
				pn.z = ((curframe->verts[j].v[2] * curframe->scale[2]) + curframe->translate[2]) * .025;
				int normal_index = curframe->verts[j].lightnormalindex;
				pn.nx = normal_table[normal_index][0];
				pn.ny = normal_table[normal_index][1];
				pn.nz = normal_table[normal_index][2];
				
				f.pn.push_back(pn);
			}
			
			long * command = mf.glcmds;
			while (*command != 0)
			{
				int vertnum;
				int is_strip;
				if (*command > 0)
				{vertnum = *command; command++; is_strip = true;}//triangle strip
				else
				{vertnum = - *command; command++; is_strip = false;}//triangle fan
				
				
				if (vertnum<0) vertnum = -vertnum; // shouldn't have to do this...
				
				
				if(is_strip)
				{
					vertex prev[2];
					prev[0] = extract_vertex(command);
					prev[1] = extract_vertex(command);
					for(int j=2; j < vertnum; j++)
					{
						triangle tri;
						if(j%2 == 0)
						{
							tri.v[0] = prev[0];
							tri.v[1] = prev[1];
							tri.v[2] = extract_vertex(command);
							prev[0] = tri.v[2];
						}
						else
						{
							tri.v[0] = prev[1];
							tri.v[1] = extract_vertex(command);
							tri.v[2] = prev[0];
							prev[1] = tri.v[1];
						}
						// swap v[1] and v[2] to fix triangle winding
						vertex hold = tri.v[1];
						tri.v[1] = tri.v[2];
						tri.v[2] = hold;
						f.tri.push_back(tri);
					}
				}
				else // is fan
				{
					vertex ctr = extract_vertex(command);
					vertex prev = extract_vertex(command);
					for(int j=2; j < vertnum; j++)
					{
						triangle tri;
						tri.v[0] = ctr;
						tri.v[1] = prev;
						tri.v[2] = extract_vertex(command);
						prev = tri.v[2];
						// swap v[1] and v[2] to fix triangle winding
						vertex hold = tri.v[1];
						tri.v[1] = tri.v[2];
						tri.v[2] = hold;
						f.tri.push_back(tri);
					}
				}
			}
			
		}
		
		return 1;
	}
	
	
	bool compare_frames(vector<iframe> & m)
	{
		iframe & f0 = m[0];
		bool same_topology = true;
		bool same_texcoords = true;
		
		for(unsigned int i=1; i < m.size(); i++)
		{
			iframe & f = m[i];
			if(f.pn.size() != f0.pn.size())
			{
				fprintf(stderr, "pn size different for iframe %d :  %d != %d\n", i, (int)f0.pn.size(), (int)f.pn.size());
				same_topology = false;
			}
			if(f.tri.size() != f0.tri.size())
			{
				fprintf(stderr, "tri size different for iframe %d :  %d != %d\n", i, (int)f0.tri.size(), (int)f.tri.size());
				same_topology = false;
			}
			if(same_topology)
			{
				for(unsigned int j=0; j < f.tri.size(); j++)
				{
					triangle & t0 = f0.tri[j];
					triangle & t = f.tri[j];
					for(int k=0; k < 3; k++)
					{
						if(t0.v[k].pn_index != t.v[k].pn_index)
						{
							fprintf(stderr, "tri %d triangle pn_index %d different!\n", j, k);
							same_topology = false;
						}
						if(t0.v[k].tc.s != t.v[k].tc.s || t0.v[k].tc.t != t.v[k].tc.t)
						{
							fprintf(stderr, "tri %d triangle tc %d different!\n", j, k);
							same_texcoords = false;
						}
					}
				}
			}
		}
		
		return same_topology && same_texcoords;
	}

	plane compute_plane(position_normal & a, position_normal & b, position_normal & c)
	{
		plane p;
		float v0[3];
		v0[0] = b.x - a.x;
		v0[1] = b.y - a.y;
		v0[2] = b.z - a.z;
		float v1[3];
		v1[0] = c.x - a.x;
		v1[1] = c.y - a.y;
		v1[2] = c.z - a.z;
		float cr[3];
		cr[0] = v0[1] * v1[2] - v0[2] * v1[1];
		cr[1] = v0[2] * v1[0] - v0[0] * v1[2];
		cr[2] = v0[0] * v1[1] - v0[1] * v1[0];
		float l = sqrt(cr[0] * cr[0] + cr[1] * cr[1] + cr[2] * cr[2]);
		if(l == 0) // degenerate triangle
		{
			p.a = p.b = p.c = p.d = 0;
			return p;
		}
		p.a = cr[0] / l;
		p.b = cr[1] / l;
		p.c = cr[2] / l;

		p.d = -(p.a * a.x + p.b * a.y + p.c * a.z);  // signed distance of a point on the plane from the origin
		return p;
	}

	/*
	  Compute the plane equations for each polygon of a frame.
	*/
	void compute_frame_planes(vector<triangle> & tri, frame & f)
	{
		for(unsigned int i=0; i < tri.size(); i++)
		{
			triangle & t = tri[i];
			int ia = t.v[0].pn_index;
			int ib = t.v[1].pn_index;
			int ic = t.v[2].pn_index;
			/* plane p = compute_plane(f.pn[ia], f.pn[ib], f.pn[ic]);
			if((p.a * f.pn[ia].nx + p.b * f.pn[ia].ny + p.c * f.pn[ia].nz) < 0)
			{
				t.v[1].pn_index = ic;
				t.v[2].pn_index = ib;
			}
			*/
			f.triplane.push_back(compute_plane(f.pn[ia], f.pn[ib], f.pn[ic]));
		}
	}

	/*
	  add_edge will look to see if the current edge is already in the list.
	  If it is not, it will add it.  If it is, it will replace the w[1] in
	  the existing table with w[0] from the edge being added.
	*/
	void add_edge(vector<winged_edge> & edge, winged_edge we)
	{
		int esize = edge.size();
		for(int i=0; i < esize; i++)
		{
			winged_edge & we0 = edge[i];
			if(we0.e[0] == we.e[0]  && we0.e[1] == we.e[1])
			{
				fprintf(stderr, "facingness different between polys on edge!\n");
			}
			if(we0.e[0] == we.e[1]  && we0.e[1] == we.e[0])
			{
				if(we0.w[1] != -1)
				{
					fprintf(stderr, "triple edge! bad...\n");
				}
				we0.w[1] = we.w[0]; // pair the edge and return
				return;
			}
		}
		edge.push_back(we);  // otherwise, add the new edge
	}

	int compute_winged_edges(vector<triangle> & tri, vector<winged_edge> & edge)
	{
		unsigned int i;
		// for each triangle, try to add each edge to the winged_edge vector,
		// but check first to see if it's already there
		unsigned int tsize = tri.size();
		for(i=0; i < tsize; i++)
		{
			triangle & t = tri[i];
			for(int j=0; j < 3; j++)
			{
				winged_edge we;
				we.e[0] = t.v[   j   ].pn_index;
				we.e[1] = t.v[(j+1)%3].pn_index;
				we.w[0] = i;
				we.w[1] = -1;  // subsequent attempt to add this edge will replace w[1] 
				add_edge(edge, we);
			}
		}
		int open_edge = 0;
		for(i=0; i < edge.size(); i++)
		{
			if(edge[i].w[1] == -1)
				open_edge++;
		}
		//fprintf(stderr, "out of % edges, there were %d open edges\n", edge.size(), open_edge);
		return open_edge;
	}

}
	
int md2::load_md2(const char * filename, model * md2p)
{
	vector<iframe> ifr;

	if( ! load_frames(filename, & ifr) )
        return 0;

	if(! compare_frames(ifr) )
	{
		fprintf(stderr, "unsuitable model -- frames aren't same\n");
		return 0;
	}
	model & m = * md2p;
	m.tri = ifr[0].tri;
	for(unsigned int i=0; i < ifr.size(); i++)
	{
		m.f.push_back(frame());
		m.f.back().pn = ifr[i].pn;
		compute_frame_planes(m.tri, m.f.back());
	}
	compute_winged_edges(m.tri, m.edge);
	return 1;
}

namespace
{


	int load_dumb_model(const char * filename, vector<iframe> * md2p, std::vector< winged_edge > & edge, float scale)
	{
		
		FILE * fp;
		
		//Open file
		if ((fp = path.fopen(filename, "rb")) == 0 ) 
        {
            fprintf(stderr, "Unable to open %s\n", filename);
			return 0;
        }
		
		//read-in header
		int nfaces;
		int nverts;
		fread(& nfaces, 4, 1, fp);
		fread(& nverts, 4, 1, fp);
		
		int * face = new int[3 * nfaces];
		int * adjacent = new int [3 * nfaces];
		fread( adjacent, 3*nfaces, 4, fp);
		fread( face, 3 * nfaces, 4, fp);
		position_normal * pn = new position_normal[nverts];
		fread( pn, sizeof(position_normal), nverts, fp);
		
		vector<iframe> & m = * md2p;
		
		int j;
		float min[3], max[3];
		min[0] = max[0] = pn[0].x;
		min[1] = max[1] = pn[0].y;
		min[2] = max[2] = pn[0].z;
		for(j=1; j < nverts; j++)
		{
			if(pn[j].x < min[0])
				min[0] = pn[j].x;
			if(pn[j].x > max[0])
				max[0] = pn[j].x;
			if(pn[j].y < min[1])
				min[1] = pn[j].y;
			if(pn[j].y > max[1])
				max[1] = pn[j].y;
			if(pn[j].z < min[2])
				min[2] = pn[j].z;
			if(pn[j].z > max[2])
				max[2] = pn[j].z;
		}

		float uscale = max[0] - min[0];
		if(max[1] - min[1] > uscale)
			uscale = max[1] - min[1];
		if(max[2] - min[2] > uscale)
			uscale = max[2] - min[2];

		m.push_back(iframe());
		iframe & f = m.back();
		for(j=0; j < nverts; j++)
		{
			pn[j].x = (pn[j].x - (max[0] + min[0])/2) * (scale/uscale);
			pn[j].y = (pn[j].y - (max[1] + min[1])/2) * (scale/uscale);
			pn[j].z = (pn[j].z - (max[2] + min[2])/2) * (scale/uscale);
			f.pn.push_back(pn[j]);
		}

		int num_bad_triangles = 0;
		int num_bad_windings = 0;
		int k;
		for(k=0; k < nfaces; k++)
		{
			triangle tri;
			tri.v[0].pn_index = face[k*3  ];
			tri.v[1].pn_index = face[k*3+1];
			tri.v[2].pn_index = face[k*3+2];
			int i;
			for(i=0; i < 3; i++)
				if(adjacent[k*3+i] == -1)
					tri.kill = true;
			if(tri.kill == true)
				num_bad_triangles++;

			for(i=0; i < 3; i++)
			{
				int adj = adjacent[k*3+i];
				if(adj < k)
					continue;
				winged_edge we;
				we.e[0] = face[k*3+i];
				we.e[1] = face[k*3+(i+1)%3];
				we.w[0] = k;
				we.w[1] = adj;
				bool consistent_winding = false;
				for(int r=0; r < 3; r++)
				{
					if( face[adj*3+r]       == we.e[1] &&
						face[adj*3+(r+1)%3] == we.e[0]    )
						consistent_winding = true;
				}
				if(consistent_winding == false)
				{
					num_bad_windings++;
				}
				edge.push_back(we);
			}
			f.tri.push_back(tri);
		}

		fprintf(stderr, "number of open faces: %d\n", num_bad_triangles);
		fprintf(stderr, "number of bad windings: %d\n", num_bad_windings);

		for(k=0; k < nfaces; k++)
		{
			int * adj = adjacent + 3 * k;
			if(f.tri[k].kill)
			{
				for(int i=0; i < 3; i++)
				{
					if(adj[i] > -1)
						f.tri[adj[i]].kill = true;
				}
			}
		}
		for(k=nfaces-1; k >= 0; k--)
		{
			int * adj = adjacent + 3 * k;
			if(f.tri[k].kill)
			{
				for(int i=0; i < 3; i++)
				{
					if(adj[i] > -1)
						f.tri[adj[i]].kill = true;
				}
			}
		}


		int open_edge = 0;
        unsigned int i;
		for(i=0; i < edge.size(); i++)
		{
			if(edge[i].w[0] != -1  &&  f.tri[edge[i].w[0]].kill == false &&
			   edge[i].w[1] != -1  &&  f.tri[edge[i].w[1]].kill == false)
			{
					;
			}
			else
			{
				open_edge++;
			}
		}
		fprintf(stderr, "out of %d edges, there were %d open edges\n", (int)edge.size(), open_edge);

		int num_closed_faces = 0;
		for(k=0; k < nfaces; k++)
		{
			if(f.tri[k].kill == false)
				num_closed_faces++;
		}

		fprintf(stderr, "num faces in the closed model: %d\n", num_closed_faces);


		num_bad_windings = 0;
		for(k=0; k < nfaces; k++)
		{
			for(i=0; i < 3; i++)
			{
				int adj = adjacent[k*3+i];
				if(adj < k)
					continue;
				winged_edge we;
				we.e[0] = face[k*3+i];
				we.e[1] = face[k*3+(i+1)%3];
				bool consistent_winding = false;

                for(int r=0; r < 3; r++)
				{
					if( face[adj*3+r]       == we.e[1] &&
						face[adj*3+(r+1)%3] == we.e[0]    )
						consistent_winding = true;
				}
				if(consistent_winding == false && f.tri[k].kill == false)
				{
					num_bad_windings++;
				}
			}
		}
		fprintf(stderr, "number of bad windings after cull: %d\n", num_bad_windings);

	
		delete [] face;
		delete [] pn;
		
		return open_edge;
	}
	
}

/*
 
   This was just a thrown-together file format for reading
   .x files without having to link with d3dx8.lib.

                                                Cass
*/
int md2::load_dumb(const char * filename, model * md2p, float scale) 
{
	vector<iframe> ifr;

	model & m = * md2p;

	m.is_open = 0 != load_dumb_model(filename, & ifr, m.edge, scale);

    if(! m.is_open)
        return 0;

	m.tri = ifr[0].tri;
	for(unsigned int i=0; i < ifr.size(); i++)
	{
		m.f.push_back(frame());
		m.f.back().pn = ifr[i].pn;
		compute_frame_planes(m.tri, m.f.back());
	}
	return 1;
}
