/*

  Infinite shadow volumes are described in the paper 
  "Practical and Robust Stenciled Shadow Volumes for
   Hardware-Accelerated Rendering" which can be found
   online at:
   
 http://developer.nvidia.com/view.asp?IO=robust_shadow_volumes


  This code is intended to illustrate the technique.  It
  is not optimized for performance.

  Cass Everitt
  04-04-2002
*/

#if defined(WIN32)
#  include <windows.h>
#  pragma warning(disable:4244)   // No warnings on precision truncation
#  pragma warning(disable:4305)   // No warnings on precision truncation
#  pragma warning(disable:4786)   // stupid symbol size limitation
#endif

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>
#include <glh/glh_obs.h>
#include <glh/glh_glut2.h>
#include <glh/glh_glut_text.h>

#include "timer.h"

#ifndef GL_DEPTH_CLAMP_NV
# define GL_DEPTH_CLAMP_NV                   0x864F
#endif

#include <vector>
#include <algorithm>

#include "md2.h"

using namespace glh;
using namespace std;

timer t;

struct model
{
	model()
	{
		frame_num = 0;
		frame_incr = 0.25;
		draw = true;
		ambient = vec4f(0.1, 0.1, 0.1, 1);
		diffuse = vec4f(0.8,0,0,1);
		specular = vec4f(0.6, 0.6, 0.6, 1);
		shininess = 64;
	}

	md2::model mod;
	md2::frame interp_frame;
	float frame_num;
	float frame_incr;

	vec4f ambient;
	vec4f diffuse;
	vec4f specular;
	float shininess;
	bool draw;
};


// You can load multiple models and 
// position them independently.  If they're
// quake2 models you can animate them as well.  

#define MAX_MODELS 4
model m[MAX_MODELS];
int curr_model = 0;
int num_models = 0;

// selector for what the mouse is currently manipulating
int curr_manip = 2; // manip model

// selector for the current view mode
int curr_view = 0;  // camera view


glut_callbacks cb;
glut_simple_mouse_interactor camera, object[MAX_MODELS], light, room, scenecam, clipcam;
glut_perspective_reshaper reshaper;
display_list face;
tex_object_2D wall;

bool b[256];

vec4f light_position(0,0,0,1);
float light_object_scale = 1;
float volume_alpha = .1;
float room_ambient = .3;

// glut-ish callbacks
void display();
void key(unsigned char k, int x, int y);
void menu(int entry) { key((unsigned char)entry, 0, 0); }
void idle();

// my functions
void init_opengl();
void init_model();
void interpolate_frame();


int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayString("stencil depth>16 double rgb samples=0");
    glutInitWindowSize(512, 512);
	glutCreateWindow("Infinite Stenciled Shadow Volumes");

	init_opengl();
	init_model();

	b['S'] = true; // no silhouette outlines
	b['v'] = true; // no volume drawing
	b['I'] = true; // use infinite far plane
	b['L'] = true; // use local light for shadowing

	glut_helpers_initialize();

	cb.keyboard_function = key;
	camera.configure_buttons(1);
	camera.set_camera_mode(true);

    // individual manipulators for each model
	for(int i=0; i < num_models; i++)
	{
		object[i].configure_buttons(1);
		object[i].translator.t[2] = -2;
		object[i].translator.scale *= .1f;
		object[i].trackball.r = rotationf(vec3f(1,0,0), to_radians(-90));
		object[i].set_parent_rotation( & camera.trackball.r);
		glut_add_interactor(&object[i]);
		object[i].disable();
	}

	light.configure_buttons(1);
	light.translator.t = vec3f(.5, .5, -1);
	room.configure_buttons(1);
	reshaper.zNear = 1;
	reshaper.zFar = 100;
	clipcam.configure_buttons(1);
	clipcam.set_camera_mode(true);
	scenecam.configure_buttons(1);
	scenecam.set_camera_mode(true);

	camera.set_parent_rotation( & camera.trackball.r);
	light.set_parent_rotation( & camera.trackball.r);
	room.set_parent_rotation( & camera.trackball.r);
	clipcam.set_parent_rotation( & clipcam.trackball.r);
	scenecam.set_parent_rotation( & scenecam.trackball.r);

	object[0].enable();
	light.disable();
	room.disable();
	camera.disable();
	clipcam.disable();
	scenecam.disable();

    // make sure all interactors get glut events
	glut_add_interactor(&cb);
	glut_add_interactor(&camera);
	glut_add_interactor(&reshaper);
	glut_add_interactor(&light);
	glut_add_interactor(&room);
	glut_add_interactor(&clipcam);
	glut_add_interactor(&scenecam);

	glutCreateMenu(menu);
	glutAddMenuEntry("mouse controls view [1]", '1');
	glutAddMenuEntry("mouse controls model  [2]", '2');
	glutAddMenuEntry("mouse controls light  [3]", '3');
	glutAddMenuEntry("mouse controls room   [4]", '4');
	glutAddMenuEntry("enable depth clamp [!]", '!');
	glutAddMenuEntry("disable depth clamp [~]", '~');
	glutAddMenuEntry("start animation [ ]", ' ');
	glutAddMenuEntry("step animation forward [a]", 'a');
	glutAddMenuEntry("step animation backward [b]", 'b');
	glutAddMenuEntry("toggle drawing silhouette [S]", 'S');
	glutAddMenuEntry("toggle drawing shadow  [s]", 's');
	glutAddMenuEntry("toggle drawing visible shadow volume [v]", 'v');
	glutAddMenuEntry("toggle drawing model geometry[m]", 'm');
    
    glutAddMenuEntry("increase shadow volume alpha [;]", ';');
    glutAddMenuEntry("decrease shadow volume alpha [:]", ':');

    glutAddMenuEntry("next model [,]", ',');
    glutAddMenuEntry("hide current model [.]", '.');

    glutAddMenuEntry("toggle view frustum clip planes [X]", 'X');

    glutAddMenuEntry("camera view [5]", '5');
    glutAddMenuEntry("scene view [6]", '6');
    glutAddMenuEntry("clipspace view [7]", '7');

	glutAddMenuEntry("enable depth clamp [!]", '!');
	glutAddMenuEntry("disable depth clamp [~]", '~');

	glutAddMenuEntry("increase light size [n]", 'n');
	glutAddMenuEntry("decrease light size [N]", 'N');

	glutAddMenuEntry("move near plane in [[]", '[');
	glutAddMenuEntry("move near plane out []]", ']');
	glutAddMenuEntry("move far plane in [{]", '[');
	glutAddMenuEntry("move far plane out [}]", ']');

	glutAddMenuEntry("toggle local/infinite light [L]", 'L');

	glutAddMenuEntry("hide room [R]", 'R');
	glutAddMenuEntry("toggle nonpopping self-shadowing [g]", 'g');

	//glutAddMenuEntry("", '');


	glutAddMenuEntry("quit [<esc>]", 27);
	glutAttachMenu(GLUT_RIGHT_BUTTON);

    glutIdleFunc(idle);
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}

void draw_mesh(float size, int tess);

void init_opengl()
{
	glClearStencil(128);
	//glEnable(GL_DEPTH_CLAMP_NV);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glEnable(GL_NORMALIZE);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);
	GLfloat ambient[] = {0.3, 0.3, 0.3, 1};
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
	face.new_list(GL_COMPILE);
	draw_mesh(20, 40);
	face.end_list();

	wall.bind();
	glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	GLfloat * tex = new GLfloat[32*32];
	{
		for(int i=0; i < 32; i++)
		{
			for(int j=0; j < 32; j++)
			{
				if(i>>4 ^ j>>4)
					tex[i+j*32] = 1;
				else
					tex[i+j*32] = .9;
			}
		}
	}
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 32, 32, 0, GL_LUMINANCE, GL_FLOAT, tex);
	delete [] tex;
}

void init_model()
{
	int i=0;
	//skin.bind();
	//md2::load_md2("knight.md2", & m[i].mod);
	//m[i].interp_frame = m[i].mod.f[0];
	//m[i].ambient *= m[i].diffuse;
	//i++;

	if(md2::load_md2("knight.md2", & m[i].mod))
    {
        t.max_frames = (int)(m[i].mod.f.size() / m[i].frame_incr);
        m[i].interp_frame = m[i].mod.f[0];
        m[i].ambient *= m[i].diffuse;
        i++;
    }


	if( 0 && md2::load_dumb("crate_01.dumb", & m[i].mod, 1))
    {
        m[i].interp_frame = m[i].mod.f[0];
        m[i].diffuse = vec4f(.4,.4,1,1);
        m[i].ambient *= m[i].diffuse;
        i++;
    }

    if( 0 && md2::load_dumb("loop_object.dumb", & m[i].mod, .4))
    {
        m[i].interp_frame = m[i].mod.f[0];
        m[i].diffuse = vec4f(.3,.8,.3,1);
        m[i].ambient *= m[i].diffuse;
        i++;
    }
	num_models = i;
}

void idle()
{
    if (b[' '])
	    key('a', 0, 0);

	glutPostRedisplay();
}

void key(unsigned char k, int x, int y)
{
	b[k] = ! b[k];
	if(k==27 || k=='q') exit(0);

	if(';' == k)
	{
		volume_alpha *= 1.1;
	}
	if(':' == k)
	{
		volume_alpha /= 1.1;
	}

	if('\'' == k)
	{
		room_ambient += .025;
	}
	if('"' == k)
	{
		room_ambient -= .025;
	}

	if(',' == k)
	{
		curr_model++;
		curr_model %= num_models;
		key('2',0,0);
	}
	if('.' == k)
	{
		m[curr_model].draw = ! m[curr_model].draw;
	}
	if('w' == k)
	{
		if(b[k])
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		else
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
	if('1' == k)
	{
        curr_manip = 1;
		camera.disable();
		clipcam.disable();
		scenecam.disable();
        if(curr_view == 0)
		    camera.enable();
        else if(curr_view == 1)
            scenecam.enable();
        else
            clipcam.enable();
		for(int i=0; i < num_models; i++)
			object[i].disable();
		light.disable();
		room.disable();
	}
	if('2' == k)
	{
        curr_manip = 2;
		camera.disable();
		clipcam.disable();
		scenecam.disable();
		light.disable();
		for(int i=0; i < num_models; i++)
			object[i].disable();
		object[curr_model].enable();
		room.disable();
	}
	if('3' == k)
	{
        curr_manip = 3;
		camera.disable();
		clipcam.disable();
		scenecam.disable();
		light.enable();
		for(int i=0; i < num_models; i++)
			object[i].disable();
		room.disable();
	}
	if('4' == k)
	{
        curr_manip = 4;
		camera.disable();
		clipcam.disable();
		scenecam.disable();
		light.disable();
		for(int i=0; i < num_models; i++)
			object[i].disable();
		room.enable();
	}

    if('5' == k)
    {
        curr_view = 0;
        if(curr_manip == 1)
            key('1',0,0);
    }

    if('6' == k)
    {
        curr_view = 1;
        if(curr_manip == 1)
            key('1',0,0);
    }

    if('7' == k)
    {
        curr_view = 2;
        if(curr_manip == 1)
            key('1',0,0);
    }


	if('[' == k)
	{
		reshaper.zNear /= 2;
	}
	if(']' == k)
	{
		reshaper.zNear *= 2;
	}

	if('{' == k)
	{
		reshaper.zFar /= 2;
	}
	if('}' == k)
	{
		reshaper.zFar *= 2;
	}

	if('!' == k)
	{
		glEnable(GL_DEPTH_CLAMP_NV);
	}
	if('~' == k)
	{
		glDisable(GL_DEPTH_CLAMP_NV);
	}

	if('a' == k)
	{
		model &mm = m[curr_model];
		mm.frame_num += mm.frame_incr;
		if(mm.frame_num >= (mm.mod.f.size()))
			mm.frame_num = 0;
		interpolate_frame();
	}

	if('b' == k)
	{
		model &mm = m[curr_model];
		mm.frame_num -= mm.frame_incr;
		if(mm.frame_num < 0)
			mm.frame_num += mm.mod.f.size();
		interpolate_frame();
	}

	if('.' == k)
	{
		face.new_list(GL_COMPILE);
		draw_mesh(20, 40);
		face.end_list();
	}

	if('n' == k)
	{
		light_object_scale *= 1.1;
	}
	if('N' == k)
	{
		light_object_scale /= 1.1;
	}

	if('L' == k)
	{
		if(b[k])
			light_position = vec4f(0,0,0,1);
		else
			light_position = vec4f(0.25, 0.25, 1, 0);
	}


	glutPostRedisplay();
}


// compute the plane equation of a triangle
md2::plane compute_plane(md2::position_normal & a, md2::position_normal & b, md2::position_normal & c)
{
	md2::plane p;
	float v0[3];
	v0[0] = b.x - a.x;
	v0[1] = b.y - a.y;
	v0[2] = b.z - a.z;
	float v1[3];
	v1[0] = c.x - a.x;
	v1[1] = c.y - a.y;
	v1[2] = c.z - a.z;
	float cr[3];
	cr[0] = v0[1] * v1[2] - v0[2] * v1[1];
	cr[1] = v0[2] * v1[0] - v0[0] * v1[2];
	cr[2] = v0[0] * v1[1] - v0[1] * v1[0];
	float l = sqrt(cr[0] * cr[0] + cr[1] * cr[1] + cr[2] * cr[2]);
	if(l == 0) // degenerate triangle
	{
		p.a = p.b = p.c = p.d = 0;
		return p;
	}
	p.a = cr[0] / l;
	p.b = cr[1] / l;
	p.c = cr[2] / l;
	
	p.d = -(p.a * a.x + p.b * a.y + p.c * a.z);  // signed distance of a point on the plane from the origin
	return p;
}

// interpolate between keyframes
void interpolate_frame()
{
	float frac =  m[curr_model].frame_num - floor(m[curr_model].frame_num);
	int f0_index = int(floor(m[curr_model].frame_num));
	int f1_index = int(ceil(m[curr_model].frame_num)) % m[curr_model].mod.f.size();
	md2::frame & f0 = m[curr_model].mod.f[f0_index];
	md2::frame & f1 = m[curr_model].mod.f[f1_index];

	unsigned int i;
	for(i = 0; i < f0.pn.size(); i++)
	{
		md2::position_normal & pn  = m[curr_model].interp_frame.pn[i];
		md2::position_normal & pn0 = f0.pn[i];
		md2::position_normal & pn1 = f1.pn[i];

		pn.x = (1-frac) * pn0.x + frac * pn1.x;
		pn.y = (1-frac) * pn0.y + frac * pn1.y;
		pn.z = (1-frac) * pn0.z + frac * pn1.z;
		pn.nx = (1-frac) * pn0.nx + frac * pn1.nx;
		pn.ny = (1-frac) * pn0.ny + frac * pn1.ny;
		pn.nz = (1-frac) * pn0.nz + frac * pn1.nz;
	}
	
	for(i=0; i < f0.triplane.size(); i++)
	{
		md2::plane & p  = m[curr_model].interp_frame.triplane[i];
		//md2::plane & p0 = f0.triplane[i];
		//md2::plane & p1 = f1.triplane[i];

		p = compute_plane(m[curr_model].interp_frame.pn[m[curr_model].mod.tri[i].v[0].pn_index], 
						  m[curr_model].interp_frame.pn[m[curr_model].mod.tri[i].v[1].pn_index],
						  m[curr_model].interp_frame.pn[m[curr_model].mod.tri[i].v[2].pn_index]); 
	}
}

// This routine draws the end caps (both local and infinite) for an
// occluder.  These caps are required for the zfail approach to work.

void draw_shadow_volume_end_caps(int mindex)
{
	vec4f olight;

	matrix4f ml = object[mindex].get_inverse_transform() * light.get_transform();
	ml.mult_matrix_vec(light_position, olight);

	vector<md2::position_normal> & vpn = m[mindex].interp_frame.pn;

	glPushMatrix();
	object[mindex].apply_transform();
	glBegin(GL_TRIANGLES);
	for(unsigned int i=0; i < m[mindex].mod.tri.size(); i++)
	{
		if(m[mindex].mod.tri[i].kill)
			continue;
		md2::plane & p = m[mindex].interp_frame.triplane[i];

		bool facing_light  = (( p.a * olight[0] + 
							    p.b * olight[1] +
							    p.c * olight[2] +
							    p.d * olight[3] ) >= 0 );

		

		int j;
		for(j=0; j < 3; j++)
		{
			md2::position_normal & pn = vpn[m[mindex].mod.tri[i].v[j].pn_index];
			if(facing_light)  // draw locally
				glVertex4f(pn.x, pn.y, pn.z, 1);
			else              // draw at infinity
				glVertex4f(pn.x*olight[3] - olight[0],
				           pn.y*olight[3] - olight[1],
						   pn.z*olight[3] - olight[2],
						   0);
		}
	}
	glEnd();
	glPopMatrix();
}



void draw_model( int mindex, bool do_diffuse)
{
	vec4f olight;
	matrix4f ml = object[mindex].get_inverse_transform() * light.get_transform();
	ml.mult_matrix_vec(light_position, olight);
	md2::frame & f = m[mindex].interp_frame;

	vector<md2::position_normal> & vpn = m[mindex].interp_frame.pn;

	float zero[] = {0,0,0,0};
	float dim[] = {.2,.2,.2,.2};
	float diffuse[4];
	float specular[4];
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, m[mindex].ambient.v);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, m[mindex].diffuse.v);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, m[mindex].specular.v);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, m[mindex].shininess);
	if(! do_diffuse )
	{
		glGetLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, dim);
		glGetLightfv(GL_LIGHT0, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT0, GL_SPECULAR, zero);
	}
	else
	{
		glBlendFunc(GL_ONE, GL_ONE);
		glEnable(GL_BLEND);
		glStencilFunc(GL_EQUAL, 128, ~0);
		glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
		glEnable(GL_STENCIL_TEST);
		glDepthFunc(GL_EQUAL);
	}
	glPushMatrix();
	object[mindex].apply_transform();
	glEnable(GL_LIGHTING);

	glPolygonOffset(0,-2);
	//glEnable(GL_POLYGON_OFFSET_FILL);

	if( ! ( do_diffuse && b['g'] ) )
	{
		glBegin(GL_TRIANGLES);
		{
			for(unsigned int i=0; i < m[mindex].mod.tri.size(); i++)
			{
				for(int j=0; j < 3; j++)
				{
					md2::position_normal & pn = vpn[m[mindex].mod.tri[i].v[j].pn_index];
					glNormal3f(pn.nx, pn.ny, pn.nz);
					glVertex4f(pn.x, pn.y, pn.z, 1);
				}
				
			}
		}
		glEnd();
	}
	else
	{
		// to do non-popping self-shadowing,
		// we render triangles that face toward the light
		// like normal...
		glBegin(GL_TRIANGLES);
		{
			for(unsigned int i=0; i < m[mindex].mod.tri.size(); i++)
			{
				md2::plane & p = f.triplane[i];
				bool facing =  0 < ( p.a * olight[0] + 
					                 p.b * olight[1] +
					                 p.c * olight[2] +
					                 p.d * olight[3] );

				if( ! facing )
					continue;
				for(int j=0; j < 3; j++)
				{
					md2::position_normal & pn = vpn[m[mindex].mod.tri[i].v[j].pn_index];
					glNormal3f(pn.nx, pn.ny, pn.nz);
					glVertex4f(pn.x, pn.y, pn.z, 1);
				}
				
			}
		}
		glEnd();
		// but for polygons that are back-facing the light,
		// we only shadow the fragments that are in two or
		// more shadow volumes.  For fragments that are in
		// only one shadow volume (their own), we let the
		// shading equation darken them... --cass
		glStencilFunc(GL_GEQUAL, 129, ~0); // don't shadow polys that backface the light and are only in one shadow volume
		glBegin(GL_TRIANGLES);
		{
			for(unsigned int i=0; i < m[mindex].mod.tri.size(); i++)
			{
				md2::plane & p = f.triplane[i];
				bool facing =  0 < ( p.a * olight[0] + 
					                 p.b * olight[1] +
					                 p.c * olight[2] +
					                 p.d * olight[3] );

				if( facing )
					continue;
				for(int j=0; j < 3; j++)
				{
					md2::position_normal & pn = vpn[m[mindex].mod.tri[i].v[j].pn_index];
					glNormal3f(pn.nx, pn.ny, pn.nz);
					glVertex4f(pn.x, pn.y, pn.z, 1);
				}
				
			}
		}
		glEnd();
	}

	glDisable(GL_POLYGON_OFFSET_FILL);

	glDisable(GL_LIGHTING);
	glPopMatrix();
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, vec4f(0.8, .8, .8, 1).v);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, vec4f(0.3, 0.3, 0.3, 1).v);

	if(! do_diffuse)
	{
		glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	}
	else
	{
		glDisable(GL_BLEND);
		//glDisable(GL_STENCIL_TEST);
		glStencilFunc(GL_ALWAYS, 128, ~0);
		glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

		glDepthFunc(GL_LESS);
	}
}

// This is for drawing the walls of the room.

void draw_mesh(float size, int tess)
{
	float hsize = size/2;
	float delta = size/(tess-1);


	glPushMatrix();
	glTranslatef(-hsize, -hsize, hsize);
	
	glNormal3f(0,0,-1);

	float x = 0;
	for(int i=0; i < tess-1; i++)
	{
		float y = 0;
		glBegin(GL_QUAD_STRIP);
		for(int j=0; j < tess; j++)
		{
			glTexCoord2f(    x, y);
			glVertex2f(      x, y);
			glTexCoord2f(x+delta, y);
			glVertex2f(x+delta, y);
			y += delta;
		}
		glEnd();
		x += delta;
	}
	glPopMatrix();
}


void draw_cube()
{
	wall.bind();
	wall.enable();
	glPushMatrix();
	room.apply_transform();
	face.call_list();
	glRotatef(90, 1, 0, 0);
	face.call_list();
	glRotatef(90, 1, 0, 0);
	face.call_list();
	glRotatef(90, 1, 0, 0);
	face.call_list();
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	face.call_list();
	glRotatef(180, 0, 1, 0);
	face.call_list();
	glPopMatrix();
	wall.disable();
}

void draw_room(bool do_diffuse)
{
	float zero[] = {0,0,0,0};
	float a[4];
	a[0] = room_ambient;
	a[1] = room_ambient;
	a[2] = room_ambient;
	a[3] = 1;

	float d1[] = {.1,.1,.1,.1};
	float d2[] = {.7,.7,.7,.7};
	float s[] = {.7,.7,.7,.7};
	float emission[4];
	float ambient[4];
	float diffuse[4];
	float specular[4];

	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, a);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, vec4f(0.8, 0.8, 0.8, 1).v);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, vec4f(0.4, 0.4, 0.4, 1).v);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 64.f);

	if(! do_diffuse)
	{
		glGetLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, d1);
		glGetLightfv(GL_LIGHT0, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT0, GL_SPECULAR, zero);
		glStencilFunc(GL_ALWAYS, 128, ~0);
	}
	else
	{
        glGetMaterialfv(GL_FRONT, GL_EMISSION, emission);
        glMaterialfv(GL_FRONT, GL_EMISSION, zero);
		glGetLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT0, GL_AMBIENT, zero);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, d2);
		glLightfv(GL_LIGHT0, GL_SPECULAR, s);

		glBlendFunc(GL_ONE, GL_ONE);
		glEnable(GL_BLEND);
		glStencilFunc(GL_EQUAL, 128, ~0);
		glDepthFunc(GL_EQUAL);
	}
	glPushMatrix();
	glTranslatef(0,9,0);
	glEnable(GL_LIGHTING);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);

	draw_cube();

	glStencilFunc(GL_ALWAYS, 128, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

	glDisable(GL_LIGHTING);
	glPopMatrix();
	
	if(! do_diffuse)
	{
		glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	}
	else
	{
        glMaterialfv(GL_FRONT, GL_EMISSION, emission);
		glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);

		glDisable(GL_BLEND);
		glDepthFunc(GL_LESS);
	}

}

// This routine draws the extruded "possible silhouette" edge.  The
// edge is extruded to infinity.

// The paper describes identifying silhouette edge loops.  The approach
// in this demo is to visit each edge, determine if it's a "possible silhouette"
// or not, and if it is, draw the extruded edge.   This approach is not
// as efficient, but it has the benefit of being extremely simple.

// This routine also doubles as the routine for drawing the local and ininite
// silhouette edges (when prim == GL_LINES).

void draw_shadow_volume_edges(int mindex, GLenum prim = GL_QUADS, bool local = true, bool infinity = true)
{
	vec4f olight;

	matrix4f ml = object[mindex].get_inverse_transform() * light.get_transform();
	ml.mult_matrix_vec(light_position, olight);


	glPushMatrix();
	object[mindex].apply_transform();

	md2::frame & f = m[mindex].interp_frame;

	glBegin(prim);
	for(unsigned int i=0; i < m[mindex].mod.edge.size(); i++)
	{
		md2::winged_edge & we = m[mindex].mod.edge[i];
		if(we.w[0] == -1 || m[mindex].mod.tri[we.w[0]].kill ||
		   we.w[1] == -1 || m[mindex].mod.tri[we.w[1]].kill )
		   continue;

		md2::plane & p0 = f.triplane[we.w[0]];
		float f0 = ( p0.a * olight[0] + 
					 p0.b * olight[1] +
					 p0.c * olight[2] +
					 p0.d * olight[3] );
			
		float f1 = -f0;
		if(we.w[1] != -1)
		{
			md2::plane & p1 = f.triplane[we.w[1]];

			f1 = ( p1.a * olight[0] + 
				   p1.b * olight[1] +
				   p1.c * olight[2] +
				   p1.d * olight[3] );
		}


		int edge[2];

		if(f0 >= 0 && f1 < 0)
		{
			edge[0] = we.e[1];
			edge[1] = we.e[0];
		}
		else if(f1 >= 0 && f0 < 0)
		{
			edge[0] = we.e[0];
			edge[1] = we.e[1];
		}
		else
		{
			continue;
		}
		
		md2::position_normal & pn0 = f.pn[edge[0]];
		md2::position_normal & pn1 = f.pn[edge[1]];

		if(prim == GL_QUADS || local)
		{
			// local segment
			glVertex4f(pn0.x, pn0.y, pn0.z, 1);
			glVertex4f(pn1.x, pn1.y, pn1.z, 1);
		}
		if(prim == GL_QUADS || infinity)
		{
			// segment projected to infinity
			glVertex4f(pn1.x*olight[3] - olight[0],
				pn1.y*olight[3] - olight[1],
				pn1.z*olight[3] - olight[2],
				0);
			glVertex4f(pn0.x*olight[3] - olight[0],
				pn0.y*olight[3] - olight[1],
				pn0.z*olight[3] - olight[2],
				0);
		}
	}
	glEnd();
	glPopMatrix();
}

void draw_shadow_volume_extruded_edges(int mindex)
{
  draw_shadow_volume_edges(mindex);
}

void draw_possible_silhouette(int mindex)
{
    glDepthFunc(GL_LEQUAL);
    glDepthMask(0);
	glLineWidth(3);
	glColor3f(1,1,1);
	draw_shadow_volume_edges(mindex, GL_LINES, true, !b['-']);
	glLineWidth(1);
    glDepthFunc(GL_LESS);
    glDepthMask(1);
}


// Draw the shadow volume into the stencil buffer.

void draw_shadow_volume_to_stencil(int mindex)
{
	if(!b['r'])
		glDepthFunc(GL_LESS);
	else
		glDepthFunc(GL_GEQUAL);
	glDepthMask(0);

	glStencilFunc(GL_ALWAYS, 128, ~0);
	glEnable(GL_STENCIL_TEST);

	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
	if(!b['r'])
		glStencilOp(GL_KEEP, GL_INCR, GL_KEEP);
	else
		glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);
	glColorMask(0,0,0,0);

	draw_shadow_volume_extruded_edges(mindex);
	draw_shadow_volume_end_caps(mindex);

	glCullFace(GL_BACK);
	if(!b['r'])
		glStencilOp(GL_KEEP, GL_DECR, GL_KEEP);
	else
		glStencilOp(GL_KEEP, GL_KEEP, GL_DECR);


	draw_shadow_volume_extruded_edges(mindex);
	draw_shadow_volume_end_caps(mindex);

	glColorMask(1,1,1,1);
	glDisable(GL_CULL_FACE);

	glStencilFunc(GL_ALWAYS, 128, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

	glDepthMask(1);
	glDepthFunc(GL_LESS);

}

// Draw the shadow volume into the color buffer.

void draw_shadow_volume_to_color(int mindex)
{
	glDepthFunc(GL_LEQUAL);
	glDepthMask(0);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glColor4f(1,1,1,.7 * volume_alpha);
	draw_shadow_volume_end_caps(mindex);
	glColor4f(1,1,.7,.15 * volume_alpha);
	draw_shadow_volume_extruded_edges(mindex);

	glDepthMask(1);
	glDepthFunc(GL_LESS);
	glDisable(GL_BLEND);

}

// Draw an icon to show where the local light is
// or in what direction the infinite light is pointing. 

void draw_light()
{
	glColor3f(1,1,0);
	glPushMatrix();
	light.apply_transform();
	glScalef(light_object_scale, light_object_scale, light_object_scale);
	if(b['L'])
		glutSolidSphere(.01, 20, 10);
	else
	{
		vec3f ldir;
		ldir[0] = light_position[0];
		ldir[1] = light_position[1];
		ldir[2] = light_position[2];
		rotationf r(vec3f(0,0,1), ldir);
		matrix4f m;
		r.get_value(m);
		m *= perspective_inverse(30, 1, 0.001, 0.04);
		glRotatef(180, 1, 0, 0);
		glTranslatef(0,0,-0.02);
		glMultMatrixf(m.m);
		glutSolidCube(2);
	}
	glPopMatrix();
}


// The infinite frustum set-up code.

matrix4f infinite_frustum(float left, float right,
						  float bottom, float top,
						  float zNear)
{
	matrix4f m;
	m.make_identity();
	
	m(0,0) = (2*zNear) / (right - left);
	m(0,2) = (right + left) / (right - left);
	
	m(1,1) = (2*zNear) / (top - bottom);
	m(1,2) = (top + bottom) / (top - bottom);
	
    float nudge = 1.0;
    
    if(b['j'])    // nudge infinity in some in case of lsb slop
        nudge = 0.999;


	m(2,2) = -1  * nudge;
	m(2,3) = -2*zNear * nudge;
	
	m(3,2) = -1;
	m(3,3) = 0;
	
	return m;
}

inline matrix4f infinite_frustum_inverse(float left, float right,
								float bottom, float top,
								float zNear)
{
	matrix4f m;
	m.make_identity();
	
	m(0,0) = (right - left) / (2 * zNear);
	m(0,3) = (right + left) / (2 * zNear);
	
	m(1,1) = (top - bottom) / (2 * zNear);
	m(1,3) = (top + bottom) / (2 * zNear);
	
	m(2,2) = 0;
	m(2,3) = -1;
	
	m(3,2) = -1 / (2 * zNear);
	m(3,3) = 1 / (2 * zNear);
	
	return m;
}

matrix4f infinite_perspective(float fovy, float aspect, float zNear)
{
	double tangent = tan(to_radians(fovy/2.0));
	float y = tangent * zNear;
	float x = aspect * y;
	return infinite_frustum(-x, x, -y, y, zNear);
}

inline matrix4f infinite_perspective_inverse(float fovy, float aspect, float zNear)
{
	double tangent = tan(to_radians(fovy/2.0));
	float y = tangent * zNear;
	float x = aspect * y;
	return infinite_frustum_inverse(-x, x, -y, y, zNear);
}

void apply_infinite_perspective(glut_perspective_reshaper & r)
{
	r.aspect = r.aspect_factor * float(r.width)/float(r.height);
	if ( r.aspect < 1 )
	{
		// fovy is a misnomer.. we really mean the fov applies to the
		// smaller dimension
		float fovx = r.fovy; 
		float real_fov = to_degrees(2 * atan(tan(to_radians(fovx/2))/r.aspect));
		glMultMatrixf(infinite_perspective(real_fov, r.aspect, r.zNear).m);
	}
	else
		glMultMatrixf(infinite_perspective(r.fovy, r.aspect, r.zNear).m);
}

void apply_infinite_perspective_inverse(glut_perspective_reshaper & r)
{
	r.aspect = r.aspect_factor * float(r.width)/float(r.height);
	if ( r.aspect < 1 )
	{
		// fovy is a misnomer.. we really mean the fov applies to the
		// smaller dimension
		float fovx = r.fovy; 
		float real_fov = to_degrees(2 * atan(tan(to_radians(fovx/2))/r.aspect));
		glMultMatrixf(infinite_perspective_inverse(real_fov, r.aspect, r.zNear).m);
	}
	else
		glMultMatrixf(infinite_perspective_inverse(r.fovy, r.aspect, r.zNear).m);
}

#define CAMERA_VIEW 0
#define SCENE_VIEW  1
#define CLIP_VIEW   2

void display()
{

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();


	if(b['I'])  // push far plane to infinity
	{
        switch (curr_view)
        {
        case CAMERA_VIEW:
			apply_infinite_perspective(reshaper);
            break;

        case SCENE_VIEW:
			apply_infinite_perspective(reshaper);
			scenecam.apply_inverse_transform();
            break;

        case CLIP_VIEW:
			apply_infinite_perspective(reshaper);
    		clipcam.apply_inverse_transform();
	    	glScalef(10,10,-10);
			apply_infinite_perspective(reshaper);
            break;

        default:
            break;
        }

	}
	else
	{
        switch (curr_view)
        {
        case CAMERA_VIEW:
			reshaper.apply_projection();
            break;

        case SCENE_VIEW:
			apply_infinite_perspective(reshaper);
			scenecam.apply_inverse_transform();
            break;

        case CLIP_VIEW:
			apply_infinite_perspective(reshaper);
			clipcam.apply_inverse_transform();
			glScalef(10,10,-10);
			reshaper.apply_projection();
            break;

        default:
            break;
        }
	}


	glMatrixMode(GL_MODELVIEW);

	if(b['X'])
	{
		glLoadIdentity();
		if(b['I'])
		{
			apply_infinite_perspective_inverse(reshaper);
		}
		else
		{
			reshaper.apply_projection_inverse();
		}
		double pos_x[] = {-1, 0, 0, 1};
		double neg_x[] = { 1, 0, 0, 1};
		double pos_y[] = { 0,-1, 0, 1};
		double neg_y[] = { 0, 1, 0, 1};
		double pos_z[] = { 0, 0,-1, 1};
		double neg_z[] = { 0, 0, 1, 1};
		glClipPlane(GL_CLIP_PLANE0, pos_x);
		glClipPlane(GL_CLIP_PLANE1, neg_x);
		glClipPlane(GL_CLIP_PLANE2, pos_y);
		glClipPlane(GL_CLIP_PLANE3, neg_y);
		glClipPlane(GL_CLIP_PLANE4, pos_z);
		glClipPlane(GL_CLIP_PLANE5, neg_z);
		glEnable(GL_CLIP_PLANE0);
		glEnable(GL_CLIP_PLANE1);
		glEnable(GL_CLIP_PLANE2);
		glEnable(GL_CLIP_PLANE3);
		glEnable(GL_CLIP_PLANE4);
		glEnable(GL_CLIP_PLANE5);
		glLoadIdentity();
	}

	glPushMatrix();
	light.apply_transform();
	glLightfv(GL_LIGHT0, GL_POSITION, light_position.v);
	glPopMatrix();
	glEnable(GL_LIGHT0);


	glPushMatrix();
	camera.apply_inverse_transform();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	if(!b['R'])
		draw_room(false);

	int i;

	if(!b['m'])
		for(i=0; i < num_models; i++)
			if(m[i].draw)
				draw_model(i, false);


	if(b['X'])
	{
		glDisable(GL_CLIP_PLANE0);
		glDisable(GL_CLIP_PLANE1);
		glDisable(GL_CLIP_PLANE2);
		glDisable(GL_CLIP_PLANE3);
		glDisable(GL_CLIP_PLANE4);
		glDisable(GL_CLIP_PLANE5);
	}

	if(!b['s'])
	{
		for(i=0; i < num_models; i++)
			if(m[i].draw)
				draw_shadow_volume_to_stencil(i);
	}

    // Be aware that this can cause some multipass artifacts
    // due to invariance issues.
	if(b['X'])
	{
		glEnable(GL_CLIP_PLANE0);
		glEnable(GL_CLIP_PLANE1);
		glEnable(GL_CLIP_PLANE2);
		glEnable(GL_CLIP_PLANE3);
		glEnable(GL_CLIP_PLANE4);
		glEnable(GL_CLIP_PLANE5);
	}
	if(!b['d'])
	{
		if(!b['R'])
			draw_room(true);
		if(!b['m'])
			for(i=0; i < num_models; i++)
				if(m[i].draw)
					draw_model(i, true);

	}


	if(!b['S'])
		for(i=0; i < num_models; i++)
			if(m[i].draw)
				draw_possible_silhouette(i);

	if(!b['v'])
		for(i=0; i < num_models; i++)
			if(m[i].draw)
				draw_shadow_volume_to_color(i);

    // Be aware that this can cause some multipass artifacts
    // due to invariance issues.
    if(b['X'])
	{
		glDisable(GL_CLIP_PLANE0);
		glDisable(GL_CLIP_PLANE1);
		glDisable(GL_CLIP_PLANE2);
		glDisable(GL_CLIP_PLANE3);
		glDisable(GL_CLIP_PLANE4);
		glDisable(GL_CLIP_PLANE5);
	}

	draw_light();

	glPopMatrix();


    // In an "external" viewing mode, show the camera's view volume
    // as a yellow wireframe cube or frustum.
	if(curr_view != CAMERA_VIEW)
	{

		glPushMatrix();
		if(b['I'])
		{
			apply_infinite_perspective_inverse(reshaper);
		}
		else
		{
			reshaper.apply_projection_inverse();
		}
		glColor3f(.75,.75,0);
		glLineWidth(3);
		glutWireCube(2);
		glLineWidth(1);
		glPopMatrix();
	}
	
	glutSwapBuffers();
    t.frame(b['t']);
}



