#ifndef MD2_H
#define MD2_H


#ifdef _WIN32
#  pragma warning(disable:4244)   // No warnings on precision truncation
#  pragma warning(disable:4305)   // No warnings on precision truncation
#  pragma warning(disable:4786)   // stupid symbol size limitation
#endif

#include <vector>

namespace md2
{
  struct f_header
  {
    unsigned long ident;
    unsigned long version;
    unsigned long skinwidth;
    unsigned long skinheight;
    unsigned long framesize;    // byte size of each frame
    unsigned long num_skins;
    unsigned long num_xyz;
    unsigned long num_st;       //greater than num_xyz for seams
    unsigned long num_tris;
    unsigned long num_glcmds;   //dwords in strip/fan command list
    unsigned long num_frames;
    unsigned long ofs_skins;    //each skin is a MAX_SKINNAME string
    unsigned long ofs_st;       //byte offset from start for stverts
    unsigned long ofs_tris; //offset for dtriangles
    unsigned long ofs_frames;   //offset for first frame
    unsigned long ofs_glcmds;
    unsigned long ofs_end;  //end of file
  };
  
  struct f_compressed_vertex
  {
	unsigned char v[3]; // scaled byte to fit in frame mins/maxs
	unsigned char lightnormalindex;
  };
  
  struct f_frame
  {
	float scale[3]; // multiply byte verts by this
	float translate[3]; // then add this
	char name[16]; // frame name from grabbing
	f_compressed_vertex verts[1]; // variable sized
  };
  
  struct f_model
  {
	bool open;
	char skinfilename[256];
	int skinopen;
	
	int numglcmds;
	long *glcmds;
	
	int framesize;
	int numframes;
	char *frames;
  };

  int load_md2_file(const char *filename,  f_model * md2_modelp);

  struct position_normal
  {
	  float x, y, z;
	  float nx, ny, nz;
  };

  struct tex_coord
  {
	  float s,t;
  };

  struct vertex
  {
	int pn_index;
	tex_coord tc;
  };

  struct triangle
  {
	  triangle() : kill(false) {}
	  vertex v[3];
	  bool kill;
  };

  struct winged_edge
  {
	  int e[2];  // vertex index
	  int w[2];  // triangle index: for "open" models, w[1] == -1 on open edges
  };

  struct plane
  {
	  float a,b,c,d;
  };

  struct frame
  {
	  std::vector < position_normal >  pn;  // [pn_index]
	  std::vector < plane > triplane;       // [tri_num]
  };

  struct model
  {
	  bool is_open;
	  std::vector< frame > f;
	  std::vector< triangle > tri;                   // [tri_num]
	  std::vector< winged_edge > edge;				// [edge_num]
  };


  int load_md2(const char *filename,  model * md2_modelp);

  int load_dumb(const char * filename, model * md2_modelp, float scale = 1);

}




#endif

