#ifdef _WIN32
#include <windows.h>
#endif

#ifdef MACOS
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/gl.h>
#include <GL/glu.h>
#endif

#include <stdio.h>
#include <shared/data_path.h>
#include <shared/objload.h>
#include <shared/quitapp.h>
#include <iostream>

#include <string>
using namespace std;

GLuint GenModelObjectList( char *name )
{
    unsigned int nverts   = 0;
    unsigned int nindices = 0;
    unsigned int *indices = NULL;
    float *vertexdata     = NULL;
    float *normaldata     = NULL;
    float *tangendata     = NULL;
    float *binormdata     = NULL;
    float *texcoords      = NULL;
    

    data_path path;

    path.path.push_back(".");
    path.path.push_back("../../../MEDIA/models");
    path.path.push_back("../../../../MEDIA/models");
    path.path.push_back("../../../../../../../MEDIA/models");

    // Load the geometry.
    string filename = path.get_file(name);
    fprintf( stderr, "Loading model...\n" );
    if ( !LoadObjModel( filename.data(), nverts, nindices, indices, vertexdata, normaldata, tangendata, binormdata, texcoords ) )
    {
        fprintf( stderr, "Error loading: %s\nExiting.\n", filename.data() );
        quitapp( -1 );
    }
    fprintf( stderr, "\n" );


    GLint lid=glGenLists(1);
    glNewList(lid, GL_COMPILE);

    glVertexPointer( 3, GL_FLOAT, 0, vertexdata );
    glNormalPointer( GL_FLOAT, 0, normaldata );
    glEnableClientState( GL_VERTEX_ARRAY );
    glEnableClientState( GL_NORMAL_ARRAY );

    glDrawElements( GL_TRIANGLES, nindices, GL_UNSIGNED_INT, indices );
    
    glDisableClientState( GL_VERTEX_ARRAY );
    glDisableClientState( GL_NORMAL_ARRAY );

    glEndList();

    if ( indices ) delete [] indices;
    if ( vertexdata ) delete [] vertexdata;
    if ( normaldata ) delete [] normaldata;
    if ( tangendata ) delete [] tangendata;
    if ( binormdata ) delete [] binormdata;
    if ( texcoords ) delete [] texcoords;

    return lid;
}
