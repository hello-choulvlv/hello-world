#if defined(WIN32)
#include <windows.h>
#elif defined(UNIX)
#include <GL/glx.h>
#endif

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>
#include <glh/glh_glut.h>
#include <glh/glh_obs.h>

#include <shared/read_text_file.h>
#include <shared/data_path.h>
#include <shared/timer.h>
#include <shared/ValueGraph.h>
#include <shared/quitapp.h>

#include <nv_dds/nv_dds.h>

using namespace glh;
using namespace nv_dds;

glut_callbacks cb;
glut_simple_mouse_interactor camera, object;
glut_perspective_reshaper reshaper(60, 0.1, 10.0);

GLhandleARB programObject;

GLint eyePosParam, displaceParam, viewInverseParam;
GLint etaParam, fresnelParam;
GLint environmentMap;

// environment map
tex_object_cube_map cubemap;

float eta = 1.1, eta_delta = -0.02; // ratio of indices of refraction

GLuint bunny_dl, sphere_dl, model_dl[4];
GLuint dispersion_combiners;

bool b[256];
int currObj = 0;
float anim = 0.0f;

void init_opengl();
void keyboard(unsigned char k, int x, int y);
void display();
void menu(int entry);
void idle();
extern GLuint Gen3DObjectList(void);
extern GLuint GenModelObjectList( char *name );

timer fpsTimer(2);
CValueGraph fpsGraph;

int main( int argc, char **argv )
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB );
    glutInitWindowSize( 512, 512 );
    glutCreateWindow( "Dispersion" );

    init_opengl();

    glut_helpers_initialize();

    cb.keyboard_function = keyboard;
    cb.idle_function = idle;

    camera.configure_buttons(1);
    camera.set_camera_mode(false);
    camera.dolly.dolly[2] = -1.5;

    object.configure_buttons(1);
    object.dolly.dolly[2] = 0.0;

    object.disable();
    camera.enable();

    glut_add_interactor(&cb);
    glut_add_interactor(&camera);
    glut_add_interactor(&object);
    glut_add_interactor(&reshaper);

    glut_idle(1);

    glutCreateMenu( menu );
    glutAddMenuEntry( "Increase refraction index [+]", '+');
    glutAddMenuEntry( "Decrease refraction index [-]", '-');
    glutAddMenuEntry( "Increase dispersion []]", ']');
    glutAddMenuEntry( "Decrease dispersion [[]", '[');
    glutAddMenuEntry( "Move object [o]", 'o');
    glutAddMenuEntry( "Move camera [c]", 'c');
    glutAddMenuEntry( "Toggle wireframe [w]", 'w' );
    glutAddMenuEntry( "Toggle deformation [d]", 'd' );
    glutAddMenuEntry( "Toggle camera spin [space]", ' ' );
    glutAddMenuEntry( "Toggle fps display [f]", 'f' );
    glutAddMenuEntry( "Reset [r]", 'r' );
    glutAddMenuEntry( "Quit [esc]", 27 );
    glutAttachMenu( GLUT_RIGHT_BUTTON) ;

    b[' '] = true;

    glutDisplayFunc( display );
    glutMainLoop();

    return 0;
}

void cleanExit(int exitval)
{
    if (programObject) 
        glDeleteObjectARB(programObject);

    if(exitval == 0) { exit(0); }
    else { exit(exitval); }
}

void printInfoLog(GLhandleARB object)
{
    int maxLength = 0;
    glGetObjectParameterivARB(object, GL_OBJECT_INFO_LOG_LENGTH_ARB, &maxLength);

    char *infoLog = new char[maxLength];
    glGetInfoLogARB(object, maxLength, &maxLength, infoLog);

    cout << infoLog << endl;
}

void addShader(GLhandleARB programObject, const GLcharARB *shaderSource, GLenum shaderType)
{
    assert(programObject != 0);
    assert(shaderSource != 0);
    assert(shaderType != 0);

    GLhandleARB object = glCreateShaderObjectARB(shaderType);
    GLint length = (GLint)strlen(shaderSource);
    glShaderSourceARB(object, 1, &shaderSource, &length);

    // compile vertex shader object
    glCompileShaderARB(object);

    // check if shader compiled
    GLint compiled = 0;
    glGetObjectParameterivARB(object, GL_OBJECT_COMPILE_STATUS_ARB, &compiled);

    if (!compiled)
    {
        printInfoLog(object);
        cleanExit(-1);
    }

    // attach vertex shader to program object
    glAttachObjectARB(programObject, object);

    // delete vertex object, no longer needed
    glDeleteObjectARB(object);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
        cout << "OpenGL error: " << gluErrorString(err) << endl;
}

void init_opengl()
{
    if(!glh_init_extensions("GL_ARB_shader_objects GL_ARB_vertex_shader GL_ARB_fragment_shader"))
    {
        cout << "Necessary extensions unsupported: " <<  glh_get_unsupported_extensions() << endl;
        quitapp(-1);
    }

    glClearColor(0.2, 0.2, 0.2, 1.0);
    glEnable(GL_DEPTH_TEST);

    data_path media;
    media.path.push_back(".");
    media.path.push_back("../../../MEDIA");
    media.path.push_back("../../../../MEDIA");

    string filename = media.get_file("programs/glsl_dispersion/dispersion_vertex.glsl");
    if (filename == "")
    {
        cout << "Unable to load dispersion_vertex.glsl, exiting..." << endl;
        cleanExit(-1);
    }

    programObject = glCreateProgramObjectARB();

    GLcharARB *shaderData = read_text_file(filename.c_str());
    addShader(programObject, shaderData, GL_VERTEX_SHADER_ARB);

    delete [] shaderData;

    filename = media.get_file("programs/glsl_dispersion/dispersion_fragment.glsl");
    if (filename == "")
    {
        cout << "Unable to load dispersion_fragment.glsl, exiting..." << endl;
        cleanExit(-1);
    }

    shaderData = read_text_file(filename.c_str());
    addShader(programObject, shaderData, GL_FRAGMENT_SHADER_ARB);

    delete [] shaderData;

    glLinkProgramARB(programObject);

    GLint linked = false;
    glGetObjectParameterivARB(programObject, GL_OBJECT_LINK_STATUS_ARB, &linked);
    if (!linked)
    {
        printInfoLog(programObject);
        cout << "Shaders failed to link, exiting..." << endl;
        cleanExit(-1);
    }

    glValidateProgramARB(programObject);

    GLint validated = false;
    glGetObjectParameterivARB(programObject, GL_OBJECT_VALIDATE_STATUS_ARB, &validated);
    if (!validated)
    {
        printInfoLog(programObject);
        cout << "Shaders failed to validate, exiting..." << endl;
        cleanExit(-1);
    }

    eyePosParam = glGetUniformLocationARB(programObject, "eyePos");
    displaceParam = glGetUniformLocationARB(programObject, "displace");
    viewInverseParam = glGetUniformLocationARB(programObject, "viewInverse");
    etaParam = glGetUniformLocationARB(programObject, "etaValues");
    fresnelParam = glGetUniformLocationARB(programObject, "fresnelValues");
    environmentMap = glGetUniformLocationARB(programObject, "environmentMap");

    if ((eyePosParam < 0) || (displaceParam < 0) || (etaParam < 0) || 
        (fresnelParam < 0) || (environmentMap < 0) || (viewInverseParam < 0))
    {
        cout << "Unable to locate uniform parameters, exiting..." << endl;
        cleanExit(-1);
    }

    // Load the cube map
    cubemap.bind();
    cubemap.parameter(GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    cubemap.parameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    cubemap.parameter(GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    cubemap.parameter(GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    cubemap.parameter(GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);

    filename = media.get_file("textures/cubemaps/nvlobby_new_cube_mipmap.dds");
    if (filename.empty())
    {
        cout << "Unable to locate nvlobby_new_cube_mipmap.dds, exiting..." << endl;
        quitapp(-1);
    }

    CDDSImage image;
    if (image.load(filename, false))
        image.upload_textureCubemap();
    
    // use program object in order to set some uniform parameters
    glUseProgramObjectARB(programObject);

    glUniform3fARB(fresnelParam, 2.0, 2.0, 0.1);
    glUniform4fARB(displaceParam, 5.0, 0.0, 0.02, 0.0);

    // set environmentMap sampler to fetch from texunit 0
    glUniform1iARB(environmentMap, 0);

    // back to fixed function
    glUseProgramObjectARB(0);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
        cout << "OpenGL error: " << gluErrorString(err) << endl;

    bunny_dl = Gen3DObjectList();

    sphere_dl = glGenLists(1);
    glNewList(sphere_dl, GL_COMPILE);
    glutSolidSphere(0.5, 64, 64);
    glEndList();

    fpsGraph.SetDescription("Framerate");
    fpsGraph.SetUnitName("FPS");
    fpsGraph.SetHeight(100);
}

// draw cubemap background
void drawSkyBox(void)
{
    glDisable(GL_DEPTH_TEST);

    cubemap.bind();
    cubemap.enable();

    // initialize object linear texgen
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    GLfloat s_plane[] = { 1.0, 0.0, 0.0, 0.0 };
    GLfloat t_plane[] = { 0.0, 1.0, 0.0, 0.0 };
    GLfloat r_plane[] = { 0.0, 0.0, 1.0, 0.0 };
    glTexGenfv(GL_S, GL_OBJECT_PLANE, s_plane);
    glTexGenfv(GL_T, GL_OBJECT_PLANE, t_plane);
    glTexGenfv(GL_R, GL_OBJECT_PLANE, r_plane);
    glPopMatrix();
    glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);
    glEnable(GL_TEXTURE_GEN_R);

    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glMatrixMode(GL_TEXTURE);
    glPushMatrix();
    glLoadIdentity();
    camera.trackball.apply_inverse_transform();
   
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glScalef(10.0, 10.0, 10.0);
    glutSolidCube(1.0);
    glPopMatrix();

    glMatrixMode(GL_TEXTURE);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_GEN_T);
    glDisable(GL_TEXTURE_GEN_R);

    cubemap.disable();

    glEnable(GL_DEPTH_TEST);
}

void draw_obj(int obj)
{
    switch(obj) {
    case 0:
        glCallList(bunny_dl);
        break;

    case 1:
        glCallList(model_dl[0]);
        break;

    case 2:
        glCallList(model_dl[1]);
        break;

    case 3:
        glCallList(model_dl[2]);
        break;

    case 4:
        glCallList(model_dl[3]);
        break;
    
    case 5:
        glCallList(sphere_dl);
        break;

    case 6:
        glutSolidTorus(0.25, 0.5, 64, 64);
        break;
    }
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // draw background
    drawSkyBox();

    // concatenate view matrix with existing projection matrix
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    camera.apply_transform();
    glMatrixMode(GL_MODELVIEW);

    object.apply_transform();

    glUseProgramObjectARB(programObject);

    // set uniform parameters
    
    glUniformMatrix4fvARB(viewInverseParam, 1, GL_FALSE, camera.get_inverse_transform().m);
    glUniform4fARB(eyePosParam, 0.0, 0.0, 0.0, 1.0);
    glUniform3fARB(etaParam, eta, eta + eta_delta, eta + (eta_delta*2.0));

    if (b['d'])
        glUniform4fARB(displaceParam, 20.0, anim, 0.02, 0.0);
    else
        glUniform4fARB(displaceParam, 0.0, 0.0, 0.0, 0.0);

    // bind environment cubemap
    cubemap.bind();

    // draw object
    draw_obj(currObj);

    cubemap.disable();
    glUseProgramObjectARB(0);

    // restore projection matrix
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    if (b['f']) fpsGraph.Render();

    glutSwapBuffers();

    fpsTimer.frame();
    fpsGraph.PushValue((int)fpsTimer.get_fps());
}

void keyboard( unsigned char k, int x, int y )
{
    b[k] = ! b[k];

    switch(k) {
    case 27:
    case 'q':
      cleanExit(0);
      break;

    case 'w':
        if (b['w'])
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        else
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        break;

    case 'o':
        object.enable();
        camera.disable();
        break;

    case 'c':
        camera.enable();
        object.disable();
        break;

    case '=':
    case '+':
        eta += 0.01;
        break;
    case '-':
        eta -= 0.01;
        break;

    case ']':
        eta_delta += 0.001;
        break;
    case '[':
        eta_delta -= 0.001;
        break;

    case 'r':
      eta = 1.0;
      eta_delta = 0.0;
      break;

    case '1':
      currObj = k - '1';
      break;
    case '2':
        if (model_dl[0] == 0)
            model_dl[0] = GenModelObjectList( "HateAlien/HateAlien-POSE.OBJ" );
        currObj = k - '1';
        break;
    case '3':
        if (model_dl[1] == 0)
            model_dl[1] = GenModelObjectList( "Rayguns/Raygun_01.OBJ" );
        currObj = k - '1';
        break;
    case '4':
        if (model_dl[2] == 0)
            model_dl[2] = GenModelObjectList( "Rayguns/Raygun_02.OBJ" );
        currObj = k - '1';
        break;
    case '5':
        if (model_dl[3] == 0)
            model_dl[3] = GenModelObjectList( "UFOS-ALL/UFO-01.OBJ" );
        currObj = k - '1';
        break;
    case '6':
    case '7':
      currObj = k - '1';
      break;

    case 'm':
      currObj = (currObj+1) % 7;
      break;
    }
}

void idle()
{
    if (b[' ']) {
      rotationf increment;
      increment.set_value(vec3f(0.0, 1.0, 0), 0.02);
      camera.trackball.r *= increment;
    }

    if (b['d']) {
      anim += 0.1f;
    }

    glutPostRedisplay();
}

void menu( int entry )
{
    keyboard((unsigned char)entry, 0, 0);
}

