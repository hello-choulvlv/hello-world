#if defined(WIN32)
#include <windows.h>
#endif

#if defined(MACOS)
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

#include <assert.h>
#include <stdio.h>
#include <shared/ValueGraph.h>

#ifndef min
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

CValueGraph::CValueGraph()
{
    SetWidth(160);
    m_iHeight = 120;
    m_iOriginX = 2;
    m_iOriginY = 2;
    m_strDescription = "Description";
    m_strUnitName = "Unit";
    m_iMaxValue = 100;
    m_iValueIdx = 0;
}

CValueGraph::~CValueGraph()
{
}

class vec4f
{
    public:
        vec4f() {}
        vec4f(float x, float y, float z, float w)
        { v[0] = x; v[1] = y; v[2] = z; v[3] = w; }
        
        float v[4];
};

bool CValueGraph::Render()
{
    //////////////////////////////////////////////////////////////////////
    // Draw the value graph at the specified position
    //////////////////////////////////////////////////////////////////////

    GLuint iDiagramX, iDiagramY, iDiagramSX, iDiagramSY;
    unsigned int i;
    float fScaledVal;
    char szBuffer[512];
    vec4f *pLineBuf = NULL;
    GLuint iCurLineBufPos = 0;

    glPushAttrib(GL_DEPTH_BUFFER_BIT);
    glDisable(GL_DEPTH_TEST);

    beginWinCoords();

    glPushAttrib(GL_BLEND | GL_POLYGON_BIT);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Draw the black quad
    glColor4f(0.0, 0.0, 0.0, 0.5);
    glBegin(GL_QUADS);
    glVertex3f(m_iOriginX, m_iOriginY, 0.0f);
    glVertex3f(m_iOriginX, m_iOriginY + m_iHeight, 0.0f);
    glVertex3f(m_iOriginX + m_iWidth, m_iOriginY + m_iHeight, 0.0f);
    glVertex3f(m_iOriginX + m_iWidth, m_iOriginY, 0.0f);
    glEnd();

    glPopAttrib();

    pLineBuf = new vec4f[LINE_BUFFER_MAX_VERT];

    // border
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + 1, m_iOriginY + 1, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + m_iWidth - 1, m_iOriginY + 1, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + m_iWidth - 1, m_iOriginY + 1, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + m_iWidth - 1, m_iOriginY + m_iHeight - 1, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + m_iWidth - 1, m_iOriginY + m_iHeight - 1.01, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + 1, m_iOriginY + m_iHeight - 1.01, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + 1.01, m_iOriginY + m_iHeight - 1, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + 1.01, m_iOriginY + 1, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + 1, m_iOriginY + 1 + 15, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(m_iOriginX + m_iWidth - 1, m_iOriginY + 1 + 15, 0.0f, 1.0f);
    
    // Calculate diagram dimensions
    iDiagramX = m_iOriginX + 5;
    iDiagramY = m_iOriginY + 18;
    iDiagramSX = GetDiagramWidth(); 
    iDiagramSY = m_iHeight - 22;

    // Calculate current sample position indicators
    pLineBuf[iCurLineBufPos++] = vec4f(iDiagramX + m_iValueIdx, iDiagramY, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(iDiagramX + m_iValueIdx, iDiagramY + 5, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(iDiagramX + m_iValueIdx, iDiagramY + iDiagramSY, 0.0f, 1.0f);
    pLineBuf[iCurLineBufPos++] = vec4f(iDiagramX + m_iValueIdx, iDiagramY + iDiagramSY - 5, 0.0f, 1.0f);
    
    // Make sure we got enough space left
    assert(iCurLineBufPos + GetDiagramWidth() * 2 < LINE_BUFFER_MAX_VERT);
    
    // Calculate first bar
    fScaledVal = 1.0f - ((float) min(m_vValues[m_vValues.size() - 1], m_iMaxValue) / (float) m_iMaxValue);
    fScaledVal *= iDiagramSY;
    pLineBuf[iCurLineBufPos++] = vec4f(iDiagramX + 0, iDiagramY + fScaledVal, 0.0f, 1.0f);
    fScaledVal = 1.0f - ((float) min(m_vValues[0], m_iMaxValue) / (float) m_iMaxValue);
    fScaledVal *= iDiagramSY;
    pLineBuf[iCurLineBufPos++] = vec4f(iDiagramX + 1, iDiagramY + fScaledVal, 0.0f, 1.0f);
    
    // Calculate remaining bars
    for (i = 2; i < GetDiagramWidth() * 2; i += 2)
    {
        // Height
        fScaledVal = 1.0f - ((float) min(m_vValues[i / 2], m_iMaxValue) / (float) m_iMaxValue);
        fScaledVal *= iDiagramSY;

        // Connect last and this height
        pLineBuf[iCurLineBufPos] = pLineBuf[iCurLineBufPos - 1];
        iCurLineBufPos++;
        pLineBuf[iCurLineBufPos] = vec4f(iDiagramX + (i / 2), iDiagramY + fScaledVal,
                                         0.0f, 1.0f);
        iCurLineBufPos++;
    }

    // Render white lines
    glColor3f(1.0, 1.0, 1.0);
    glTranslatef(-0.01, 0.01, 0.0);
    
    // Render lines
#if defined(MACOS)
    // draw using immediate mode since vertex arrays don't seem to work here
    glBegin(GL_LINES);
    for (i = 0; i < iCurLineBufPos; i++)
        glVertex3fv(pLineBuf[i].v);
    glEnd();
#else
    glEnable(GL_VERTEX_ARRAY);
    glVertexPointer(4, GL_FLOAT, 0, pLineBuf[0].v);
    glDrawArrays(GL_LINES, 0, iCurLineBufPos);
    glDisable(GL_VERTEX_ARRAY);
#endif

    delete [] pLineBuf;
    
    // Write indicators
    for (i = 0; i < 10; i++)
    {
        sprintf(szBuffer, "%i", (int) ((m_iMaxValue) - ((float) i * 
            ((float) (m_iMaxValue + 10) / 10.0f))));
        glPrint(iDiagramX + iDiagramSX + 3, 
            (int)((iDiagramY + (float) i * (iDiagramSY / 10.0f)) + 9),
            szBuffer, GLUT_BITMAP_HELVETICA_10);
    }

    // Render description and current sample value
    sprintf(szBuffer, "%s (%i %s)", m_strDescription.c_str(), (int)m_vValues[m_iValueIdx - 1], m_strUnitName.c_str());
    glPrint(m_iOriginX + 5, m_iOriginY + 12, szBuffer, GLUT_BITMAP_HELVETICA_10);

    endWinCoords();
    
    glPopAttrib();
    
    return true;
}

void CValueGraph::beginWinCoords()
{
    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);
    int w = viewport[2];
    int h = viewport[3];

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glTranslatef(0.0, h - 1, 0.0);
    glScalef(1.0, -1.0, 1.0);
    
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0, w, 0, h, -1, 1);
    
    glMatrixMode(GL_MODELVIEW);
}

void CValueGraph::endWinCoords(void)
{
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}

void CValueGraph::glPrint(int x, int y, const char *s, void *font)
{
    int i, len;
    
    glRasterPos2f(x, y);
    len = (int) strlen(s);
    for (i = 0; i < len; i++) 
        glutBitmapCharacter(font, s[i]);
}
