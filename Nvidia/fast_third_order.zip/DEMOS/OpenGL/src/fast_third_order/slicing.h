#pragma once

void draw_slices(const float* _dir, float _n);
void draw_cube();
