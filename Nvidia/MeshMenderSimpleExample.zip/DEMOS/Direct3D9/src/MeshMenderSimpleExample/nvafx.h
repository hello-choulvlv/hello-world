// PreCompiled Header

#include <shared/dxstdafx.h>
#include <TCHAR.H>
#include "resource.h"