#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>

#if defined(WIN32)
#  include <windows.h>
#  include <GL/glu.h>
#  include <GL/glut.h>
#elif defined(MACOS)
#  include <OpenGL/glu.h>
#  include <GLUT/glut.h>
#elif defined(UNIX)
#  include <GL/glu.h>
#  include <GL/glut.h>
#endif

#define GLH_EXT_SINGLE_FILE
#include <glh/glh_extensions.h>
#include <glh/glh_linear.h>

#include <shared/read_text_file.h>
#include <shared/quitapp.h>

#include <string>
#include <iostream>

using namespace glh;
using namespace std;

bool keys[256];

data_path media;

GLhandleARB programObject = 0;

GLint hour;
GLint minute;
GLint second;

int initialWidth = 448;
int initialHeight = 153;

void cleanExit(int exitval)
{
    if (programObject) 
        glDeleteObjectARB(programObject);

    if(exitval == 0) { exit(0); }
    else { quitapp(exitval); }
}

void printInfoLog(GLhandleARB object)
{
    int maxLength = 0;
    glGetObjectParameterivARB(object, GL_OBJECT_INFO_LOG_LENGTH_ARB, &maxLength);

    char *infoLog = new char[maxLength];
    glGetInfoLogARB(object, maxLength, &maxLength, infoLog);

    cout << infoLog << endl;
}

void addShader(GLhandleARB programObject, string filename, GLenum shaderType, string header)
{
    assert(programObject != 0);
    assert(!filename.empty());
    assert(shaderType != 0);

    GLhandleARB object = glCreateShaderObjectARB(shaderType);
    assert(object != 0);

    if (!header.empty())
    {
        const GLcharARB *shaderSource[] = { read_text_file(header.c_str()),
                                            read_text_file(filename.c_str()) };
        assert(shaderSource != 0);

        glShaderSourceARB(object, 2, shaderSource, NULL);

        delete [] shaderSource[0];
        delete [] shaderSource[1];
    }
    else
    {
        const GLcharARB *shaderSource = read_text_file(filename.c_str());
        assert(shaderSource != 0);

        glShaderSourceARB(object, 1, &shaderSource, NULL);
        delete [] shaderSource;
    }

    // compile vertex shader object
    glCompileShaderARB(object);

    // check if shader compiled
    GLint compiled = 0;
    glGetObjectParameterivARB(object, GL_OBJECT_COMPILE_STATUS_ARB, &compiled);

    if (!compiled)
    {
        printInfoLog(object);
        cleanExit(-1);
    }

    // attach vertex shader to program object
    glAttachObjectARB(programObject, object);

    // delete vertex object, no longer needed
    glDeleteObjectARB(object);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
        cout << "OpenGL error: " << gluErrorString(err) << endl;
}

void addShader(GLhandleARB programObject, string filename, GLenum shaderType)
{
    addShader(programObject, filename, shaderType, "");
}

void init_opengl()
{
    // check if required extensions are supported
    if (!glh_init_extensions("GL_ARB_shader_objects GL_ARB_vertex_shader GL_ARB_fragment_shader"))
    {
        cout << "Necessary extensions not supported:" << endl 
             << endl << glh_get_unsupported_extensions() << endl;
        quitapp(-1);
    }

    media.path.push_back(".");
    media.path.push_back("../../../MEDIA");
    media.path.push_back("../../../../MEDIA");

    programObject = glCreateProgramObjectARB();

    // vertex shader
    addShader(programObject, media.get_file("programs/glsl_digital_clock/vertex.glsl"), GL_VERTEX_SHADER_ARB);

    // fragment shader
    addShader(programObject, media.get_file("programs/glsl_digital_clock/digit.glsl"), GL_FRAGMENT_SHADER_ARB, media.get_file("programs/glsl_digital_clock/types.h"));
    addShader(programObject, media.get_file("programs/glsl_digital_clock/inside.glsl"), GL_FRAGMENT_SHADER_ARB, media.get_file("programs/glsl_digital_clock/types.h"));
    addShader(programObject, media.get_file("programs/glsl_digital_clock/clock.glsl"), GL_FRAGMENT_SHADER_ARB, media.get_file("programs/glsl_digital_clock/types.h"));

    glLinkProgramARB(programObject);

    GLint linked = false;
    glGetObjectParameterivARB(programObject, GL_OBJECT_LINK_STATUS_ARB, &linked);
    if (!linked)
    {
        printInfoLog(programObject);
        cout << "Shaders failed to link, exiting..." << endl;
        cleanExit(-1);
    }

    hour = glGetUniformLocationARB(programObject, "hour");
    assert(hour >= 0);

    minute = glGetUniformLocationARB(programObject, "minute");
    assert(minute >= 0);

    second = glGetUniformLocationARB(programObject, "second");
    assert(second >= 0);

    glUseProgramObjectARB(programObject);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
        cout << "OpenGL error: " << gluErrorString(err) << endl;

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

struct tm *getTime()
{
    time_t curtime;
    time(&curtime);
    return localtime(&curtime);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    struct tm *curtime = getTime();

    if (curtime->tm_hour > 12)
        curtime->tm_hour -= 12;
    if (curtime->tm_hour == 0)
        curtime->tm_hour = 12;

    glUniform1fARB(hour, curtime->tm_hour);
    glUniform1fARB(minute, curtime->tm_min);
    glUniform1fARB(second, curtime->tm_sec);

    glBegin(GL_QUADS);
    glVertex2f(0.0, 0.0);
    glVertex2f(3.5, 0.0);
    glVertex2f(3.5, 1.2);
    glVertex2f(0.0, 1.2);
    glEnd();

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
        cout << "OpenGL error: " << gluErrorString(err) << endl;

    glutSwapBuffers();
}

// generic GLUT code
void idle()
{
    glutPostRedisplay();
}

void key(unsigned char k, int x, int y)
{
    keys[k] = ! keys[k];

    switch(k)
    {
        case 27:
        case 'q':
            cleanExit(0);
    	    break;
        case '1':
            glutReshapeWindow(initialWidth, initialHeight);
            break;
        case '2':
            glutReshapeWindow(initialWidth*2, initialHeight*2);
            break;
        case '3':
            glutReshapeWindow(initialWidth*3, initialHeight*3);
            break;
    }

    glutPostRedisplay();
}

void resize(int w, int h)
{
    if (h == 0) h = 1;

    glViewport(0, 0, w, h);
    
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    glOrtho(0.0, 3.5, 0.0, 1.2, -1.0, 1.0);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(initialWidth, initialHeight);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB);
    glutCreateWindow("Digital Clock Shader");

    init_opengl();

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(key);
    glutReshapeFunc(resize);

    glutMainLoop();

    return 0;
}
