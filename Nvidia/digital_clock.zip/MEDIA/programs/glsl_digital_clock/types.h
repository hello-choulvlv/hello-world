struct Plane
{
    vec2 normal;
    vec2 point;
};

struct Segment
{
    // four planes that define a segment in the LED
    Plane p0;
    Plane p1;
    Plane p2;
    Plane p3;
};

struct Digit
{
    vec4 bottom;
    vec4 top;
};
