// PreCompiled Header

#include <shared/dxstdafx.h>
#include <TCHAR.H>
#include "resource.h"
#include "NV_D3DCommon\NV_D3DCommon.h"
#include "NV_D3DMesh\NV_D3DMesh.h"