/*********************************************************************NVMH4****
Path:  SDK\DEMOS\Direct3D9\src\HLSL_OcclusionQueryDemo
File:  OcclusionCulledObject.h

Copyright NVIDIA Corporation 2002
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
*AS IS* AND NVIDIA AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA OR ITS SUPPLIERS
BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

Bryan Dudash

Comments:

This is a around SimpleVBObject that optionally skips drawing the mesh based
on its visibility level.  It uses the Occlusion Query to make that determination.

Note: It always renders an invisible occlusion hull and uses a delayed feedback
mechanism.  Thus, it is possible to have a few frames delay between when an
object SHOULD be visible and when an object is actually drawn.

******************************************************************************/

#ifndef __OcclusionCulledObject__H
#define __OcclusionCulledObject__H

#include "NV_D3DMesh\NV_D3DMeshDX9.h"

class Mesh;
class LatentOcclusionQueryBank;

class OcclusionCulledObject : public MeshVB
{
    
public:

    enum DetailMode
    {
        DM_SIMPLE=0,
        DM_COMPLEX=1,
    };

    OcclusionCulledObject();
    ~OcclusionCulledObject();

    virtual HRESULT Draw();
    virtual HRESULT Free();

    HRESULT GenerateHullFromSimpleObject( Mesh * pMesh );

    void SetEffect(LPD3DXEFFECT pEffect);

    virtual HRESULT CreateFromSimpleObject( Mesh * pMesh,
        IDirect3DDevice9 *  pD3DDev,
		MeshVB::VBUsage dynamic_or_static = MeshVB::STATIC );

protected:

    MeshVB *					m_pHullObject;
    LatentOcclusionQueryBank*	m_OcclusionQueries;
    DetailMode					m_detailMode;

    LPD3DXEFFECT                m_pEffect;

    HRESULT FindAndSetTechnique(char* szTechniqueName);
};

#endif // __OcclusionCulledObject__H