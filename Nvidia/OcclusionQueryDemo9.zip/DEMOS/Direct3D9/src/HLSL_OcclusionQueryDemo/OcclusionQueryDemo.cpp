#define STRICT

//#include <commctrl.h>
#include <shared/GetFilePath.h>
#pragma warning(disable : 4786)
#include <vector>
#pragma warning(disable : 4786)
#include <assert.h>

#include "OcclusionQueryDemo.h"
#include "NV_D3DCommon\NV_D3DCommonDX9.h"
#include "NV_D3DMesh\NV_D3DMesh.h"

//-----------------------------------------------------------------------------
// Name: Effect_OcclusionQueryDemo()
// Desc: Application constructor. Sets attributes for the app.
//-----------------------------------------------------------------------------
Effect_OcclusionQueryDemo::Effect_OcclusionQueryDemo()
{
    m_pEffect = NULL;

    m_pOcclusionCulledObject = NULL;
    m_pOccluder = NULL;
}

//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT Effect_OcclusionQueryDemo::ConfirmDevice( D3DCAPS9* pCaps,
                                          D3DFORMAT adapterFormat, D3DFORMAT backBufferFormat )
{
    static int nErrors = 0;     // use this to only show the very first error messagebox
    int nPrevErrors = nErrors;

    // check vertex shading support
    if(pCaps->VertexShaderVersion < D3DVS_VERSION(1,1))
        if (!nErrors++) 
            MessageBox(NULL, _T("Device does not support 1.1 vertex shaders!"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);

    // check pixel shader support
    if(pCaps->PixelShaderVersion < D3DPS_VERSION(1,1))
        if (!nErrors++) 
            MessageBox(NULL, _T("Device does not support 1.1 pixel shaders!"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);

    return (nErrors > nPrevErrors) ? E_FAIL : S_OK;
}

//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Initialize scene objects.
//  The device exists, but was just lost or reset, and is now being restored.  
//  Resources in D3DPOOL_DEFAULT and any other device state that persists during 
//  rendering should be set here.  Render states, matrices, textures, etc., that 
//  don't change during rendering can be set once here to avoid redundant state 
//  setting during Render(). 
//-----------------------------------------------------------------------------
HRESULT Effect_OcclusionQueryDemo::RestoreDeviceObjects(IDirect3DDevice9* pd3dDevice)
{
    HRESULT hr;

    assert(pd3dDevice);

    //////////////////////////////////////////////////////
    // Try a clear with stencil to determine flags for
    //  future clears
    m_dwDepthClearFlags = D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL;
    hr = pd3dDevice->Clear( 0, NULL, m_dwDepthClearFlags, 0x00000000, 1.0, 0 );
    if( FAILED(hr) )
    {
        m_dwDepthClearFlags = D3DCLEAR_ZBUFFER;
        hr = pd3dDevice->Clear(0, NULL, m_dwDepthClearFlags, 0x00000000, 1.0, 0 );

        if( FAILED(hr) )
        {
            MessageBox(NULL, _T("Can't do a successfull clear!"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
            return E_FAIL;
        }
    }

    // load our main effect file
    // note: path is relative to MEDIA\ dir
    hr = D3DXCreateEffectFromFile(pd3dDevice, GetFilePath::GetFilePath(_T("programs\\HLSL_OcclusionQueryDemo\\OcclusionQueryDemo.fx")).c_str(),
        NULL, NULL, 0, NULL, &m_pEffect, NULL);
    if (FAILED(hr))
    {
        MessageBox(NULL, _T("Failed to load effect file"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return hr;
    }

    // The culled object is at the origin
    D3DXMatrixIdentity(&m_OcclusionCulledWorldTrans);

    // The culler object is slightly in front of the culled object
    D3DXMatrixTranslation(&m_OccluderWorldTrans,0.0f,0,-0.5f);

    /////////////////////////////////////
    // The object to be occluded is a highly tesselated torus.  
    // $$$$$ Need something better.
	Mesh * pMesh = new Mesh;
	MeshGeoCreator gc;
	gc.InitTorus( pMesh, D3DXVECTOR3( 1.0f, 0.0f, 0.0f ), 0.36f, 1000, 0.11f, 500 );

	unsigned int numv = pMesh->GetNumVertices();
	for( unsigned int i=0; i < numv; i++ )
    {
        float fr, fg, fb;
        fr = ( i % 512 ) / 512.0f;
        fg = ( i % 64 ) / 64.0f;
		fb = ( i * 3 % numv ) / ((float)numv);

        BYTE r,g,b;
        r = (BYTE) (fr * 256);
        g = (BYTE) (fg * 256);
        b = (BYTE) (fb * 256);

		pMesh->GetVertexPtr(i)->SetColor( r | g<<8 | b<<16 );
    }

    m_pOcclusionCulledObject = new OcclusionCulledObject;

    m_pOcclusionCulledObject->CreateFromSimpleObject( pMesh, pd3dDevice );
    m_pOcclusionCulledObject->SetEffect(m_pEffect);

    /////////////////////////////////////
    // Make a slightly bigger object
    float xmin,ymin,zmin,xmax,ymax,zmax;
	MeshProcessor mp;
	mp.FindPositionMinMax( pMesh, &xmin, &ymin, &zmin, &xmax, &ymax, &zmax );

    Mesh * pHullMesh = new Mesh;
	gc.InitBlock( pHullMesh, D3DXVECTOR3( xmin, ymin, zmin ), D3DXVECTOR3( xmax, ymax, zmax ) );
	mp.SetColorFromVertexNormal( pHullMesh );

    // make the SimpleVBObject for drawing
    m_pOccluder = new MeshVB();
	m_pOccluder->CreateFromMesh( pHullMesh, pd3dDevice, MeshVB::STATIC );
    
    //SAFE_DELETE(pHullMesh);

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc:
//  The device exists, but is about to be Reset(), so we should release some things. 
//  Resources in D3DPOOL_DEFAULT and any other device state that persists during 
//  rendering should be set here. Render states, matrices, textures, etc., that 
//  don't change during rendering can be set once here to avoid redundant state 
//  setting during Render(). 
//-----------------------------------------------------------------------------
HRESULT Effect_OcclusionQueryDemo::InvalidateDeviceObjects()
{
    SAFE_DELETE(m_pOccluder);
    SAFE_DELETE(m_pOcclusionCulledObject);
    
    SAFE_RELEASE(m_pEffect);

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT Effect_OcclusionQueryDemo::Render(IDirect3DDevice9* pd3dDevice, D3DXMATRIX *worldMat)
{
    HRESULT hr = S_OK;
    D3DXHANDLE hTechnique = NULL;

    // clear the screen/z-buffer/stencil buffer
    pd3dDevice->Clear(    0, NULL,
                        D3DCLEAR_TARGET | m_dwDepthClearFlags,
                        0xA0A0A0,     // ARGB clear color
                        1.0f,         // far Z depth
                        0    );       // stencil

    // Set Flexible Vertex Format flags
    pd3dDevice->SetFVF( MESHVERTEX_FVF );

    D3DXMATRIX matWorldViewProj;
    D3DXMatrixMultiply(&matWorldViewProj,worldMat,&m_OccluderWorldTrans);
    D3DXMatrixMultiply(&matWorldViewProj,&matWorldViewProj,m_ViewTrans);
    D3DXMatrixMultiply(&matWorldViewProj,&matWorldViewProj,m_ProjTrans);

    m_pEffect->SetValue("WorldViewProj", matWorldViewProj, sizeof(D3DXMATRIX));

    // Draw the front object which may be occluding our complex object
    
    // select a technique from our .fx file
    if (FAILED(m_pEffect->SetTechnique("Simple")))
    {
        MessageBox(NULL, _T("Failed to set 'Simple' technique in effect file"), _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return E_FAIL;
    }

    // Render objects using the effect
    UINT uPasses;
    if (D3D_OK == m_pEffect->Begin(&uPasses, 0))  // The 0 specifies that ID3DXEffect::Begin and ID3DXEffect::End will save and restore all state modified by the effect.
    {
        for (UINT uPass = 0; uPass < uPasses; uPass++)
        {
            // Set the state for a particular pass in a technique.
            m_pEffect->BeginPass(uPass);

            // Draw 
            m_pOccluder->Draw();

			m_pEffect->EndPass();
        }
        m_pEffect->End();
    }

    // Draw the occlusion culled object, which may not draw the complex
    //    object based upon it's visibility
    D3DXMatrixMultiply(&matWorldViewProj,&m_OcclusionCulledWorldTrans,m_ViewTrans);
    D3DXMatrixMultiply(&matWorldViewProj,&matWorldViewProj,m_ProjTrans);
    m_pEffect->SetValue("WorldViewProj", &matWorldViewProj, sizeof(D3DXMATRIX));

    // (note: this object has a pointer to the effect, and calls begin/pass/end as it needs to)
    m_pOcclusionCulledObject->Draw();

    return S_OK;
}