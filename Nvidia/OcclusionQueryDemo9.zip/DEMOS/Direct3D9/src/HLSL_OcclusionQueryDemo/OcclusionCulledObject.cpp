/*********************************************************************NVMH4****
Path:  SDK\DEMOS\Direct3D9\src\HLSL_OcclusionQueryDemo
File:  OcclusionCulledObject.cpp

Copyright NVIDIA Corporation 2002
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
*AS IS* AND NVIDIA AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA OR ITS SUPPLIERS
BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

Bryan Dudash

Comments:

Things to remember about occlusion queries:

- The occlusion query does it's testing at that point in the render.  
    I.e.  If you haven't rendered objects that will be in front of it yet, 
    then it will return non-occluded.  Remember this, and sort accordingly.

- Since the query is queued up, you have to either wait on the render, or support
    a rolling queue of queries.  That is, the normal rendering pipeline on the
    hardware can be a handful of frames (3 by default) behind the CPU processing.  
    This example uses the class LatentOcclusionQueryBank to implement a queue of
    queries.

******************************************************************************/


#include "shared/NV_Common.h"

#include "NV_D3DCommon\NV_D3DCommonDX9.h"
#include "NV_D3DMesh\NV_D3DMeshDX9.h"

#include <math.h>
#include "LatentOcclusionQueryBank.h"
#include "OcclusionCulledObject.h"
#include <TCHAR.H>

OcclusionCulledObject::OcclusionCulledObject()
{
    m_pHullObject = new MeshVB();
    m_detailMode = DM_COMPLEX;
    m_OcclusionQueries = NULL;
    m_pEffect = NULL;
}

OcclusionCulledObject::~OcclusionCulledObject()
{
    Free();
}

//////////////////////////////////////////////////////////////////////////
// This method conditionally draw a complex object based on it's occlusion from
// the last frame.  It also issues another occlusion query.  
HRESULT OcclusionCulledObject::Draw()
{
    // Poll our occlusion from last frame
    HRESULT hr;
    DWORD count = 0;

    if(!m_OcclusionQueries) return S_FALSE;

    // grab any occlusion test results
    hr = m_OcclusionQueries->GetLatestResults(&count);

    // S_OK means there were new results to consider, so maybe change detail mode
    if(hr == S_OK)
    {
        // non zero count means not occluded
        if(count != 0)
        {
#ifdef _DEBUG
            if(m_detailMode != DM_COMPLEX)     FDebug(_T("Switching to Complex Object. (%d)\n"),count);
#endif
            m_detailMode = DM_COMPLEX;
        }
        // fully occluded, only render the simple shape
        else 
        {
#ifdef _DEBUG
            if(m_detailMode != DM_SIMPLE) FDebug(_T("Switching to Simple Object.\n"));
#endif
            m_detailMode = DM_SIMPLE;
        }
    }

    // begin the occlusion query.  All geo drawn will be considered.
    m_OcclusionQueries->BeginNextQuery();

    hr = S_OK;

    //////////////////////////////////////////////////////////////////////////
    // Always try to draw the simple hull, so we don't have jitter when if the
    //     simple hull is visible and the complex on is not.

    // Set the simple shader, but use the version that doesn't write out color or Z values.
    FindAndSetTechnique("SimpleNoZorColorWrite");

    // draw our hull object for testing
    UINT uPasses;
    if (D3D_OK == m_pEffect->Begin(&uPasses, 0))  // The 0 specifies that ID3DXEffect::Begin and ID3DXEffect::End will save and restore all state modified by the effect.
    {
        for (UINT uPass = 0; uPass < uPasses; uPass++)
        {
            m_pEffect->BeginPass(uPass);         // Set the state for a particular pass in a technique.
            hr = m_pHullObject->Draw();     // Draw 

			m_pEffect->EndPass();
        }
        m_pEffect->End();
    }

    //////////////////////////////////////////////////////////////////////////
    // If we are in detail mode, then write the complex model too...
    if(m_detailMode == DM_COMPLEX)
    {
        // Set the complex shaders
        FindAndSetTechnique("Complex");

        // draw ourselves in all our full glory
        if (D3D_OK == m_pEffect->Begin(&uPasses, 0))  // The 0 specifies that ID3DXEffect::Begin and ID3DXEffect::End will save and restore all state modified by the effect.
        {
            for (UINT uPass = 0; uPass < uPasses; uPass++)
            {
                m_pEffect->BeginPass(uPass);             // Set the state for a particular pass in a technique.
				hr = MeshVB::Draw();		        // Draw 
				m_pEffect->EndPass();
            }
            m_pEffect->End();
        }

    }

    // End the occlusion query.  No more draws are considered
    m_OcclusionQueries->EndNextQuery();

    return hr;
}

void OcclusionCulledObject::SetEffect(LPD3DXEFFECT pEffect)
{
    m_pEffect = pEffect;
}

HRESULT OcclusionCulledObject::CreateFromSimpleObject( Mesh * pMesh,
                                               IDirect3DDevice9 *  pD3DDev,
											   MeshVB::VBUsage dynamic_or_static )
{
    HRESULT hr = S_OK;

    // Then do the rest of the stuff.
	hr = MeshVB::CreateFromMesh( pMesh, pD3DDev, dynamic_or_static);
    BREAK_AND_RET_VAL_IF_FAILED(hr);

    // Create our bank of rolling occlusion queries
    m_OcclusionQueries = new LatentOcclusionQueryBank(pD3DDev);

    // First generate our little occlusion hull from the simple obj
    hr = GenerateHullFromSimpleObject( pMesh );
    BREAK_AND_RET_VAL_IF_FAILED(hr);

    return hr;
}

//////////////////////////////////////////////////////////////////////////
// Given our "complex" simpleobject generate a AABB for it and save as a hull
HRESULT OcclusionCulledObject::GenerateHullFromSimpleObject( Mesh * pInputMesh )
{
	FAIL_IF_NULL( pInputMesh );
    float xmin,ymin,zmin,xmax,ymax,zmax;	
	MeshProcessor mp;
	mp.FindPositionMinMax( pInputMesh, &xmin, &ymin, &zmin, &xmax, &ymax, &zmax );

	Mesh * pMesh = new Mesh;
	MeshGeoCreator gc;
	gc.InitBlock( pMesh, D3DXVECTOR3( xmin, ymin, zmin ), D3DXVECTOR3( xmax, ymax, zmax ) );

    // make the SimpleVBObject for drawing
    m_pHullObject = new MeshVB();
    m_pHullObject->CreateFromMesh( pMesh, m_pD3DDev, VBUsage::STATIC);

    return( S_OK );
}

HRESULT OcclusionCulledObject::Free()
{
    if(m_pHullObject)
    {
        m_pHullObject->Free();
        delete m_pHullObject;
        m_pHullObject = NULL;
    }

    if(m_OcclusionQueries)
    {
        m_OcclusionQueries->Free();
        delete m_OcclusionQueries;
        m_OcclusionQueries = NULL;

    }

	return( MeshVB::Free() );
}

HRESULT OcclusionCulledObject::FindAndSetTechnique(char* szTechniqueName)
{
    // finds the requested technique in our main effect (m_pEffect)
    // and activates it.

    D3DXHANDLE hTechnique = m_pEffect->GetTechniqueByName(szTechniqueName);
    if (!hTechnique)
    {
        TCHAR buf[1024];
        _stprintf(buf, _T("Could not find '%s' technique in effect file"), szTechniqueName);
        MessageBox(NULL, buf, _T("ERROR"), MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return E_FAIL;
    }
    
    m_pEffect->SetTechnique(hTechnique);
    return D3D_OK;
}
