/*********************************************************************NVMH4****
Path:  SDK\DEMOS\Direct3D9\src\HLSL_OcclusionQueryDemo
File:  LatentOcclusionQueryBank.h

Copyright NVIDIA Corporation 2003
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
*AS IS* AND NVIDIA AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA OR ITS SUPPLIERS
BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

Bryan Dudash

Comments:

This is a bank of occlusion queries.  It is meant to allow multiple occlusion
queries to be used in conjunction with a rendering strategy that culls based
on the results.  All calls into this class return immediately, so, it is possible
for the call to GetLatestResults to return S_FALSE, indicating that there are
no new results.

(Background: An occlusion query returns the number of pixels that pass 
 z-testing; if greater than zero, you know an object is visible.  For more 
 information, look up D3DQUERYTYPE or D3DQUERYTYPE_OCCLUSION in MSDN.)

Usage:

Use just like a regular D3DQuery, replacing the following calls:

LPDIRECT3DQUERY9        -> LatentOcclusionQueryBank
GetData()                -> GetLatestResults()
Issue(D3DISSUE_BEGIN)    -> BeginNextQuery()
Issue(D3DISSUE_BEGIN)    -> EndNextQuery()
Release()                -> Free()

Remember to call Free()!

******************************************************************************/

#ifndef LatentOcclusionQueryBank__H
#define LatentOcclusionQueryBank__H

#include <vector>

// Little struct used to store queries and their outstanding state
struct LatentQueryElement
{
    LPDIRECT3DQUERY9 query;
    enum 
    {
        UNUSED = 0,
        ISSUEDBEGIN = 1,
        ISSUEDEND = 2,
    } state;
};

typedef std::vector<LatentQueryElement> QueryVector;

class LatentOcclusionQueryBank
{
public:
    static const int MAX_QUERIES = 30;    // Max of 30 queries in flight at once

public:
    LatentOcclusionQueryBank() {assert(false);}
    LatentOcclusionQueryBank( IDirect3DDevice9 *  pD3DDev);
    HRESULT GetLatestResults(DWORD *count);
    HRESULT BeginNextQuery();
    HRESULT EndNextQuery();

    unsigned int GetNumActiveQueries();

    void Free();

protected:

    QueryVector m_Queries;
    int m_head;
};

LatentOcclusionQueryBank::LatentOcclusionQueryBank( IDirect3DDevice9 *  pD3DDev)
{
    m_Queries.reserve(MAX_QUERIES);
    m_Queries.resize(MAX_QUERIES);

    for(int i=0;i<MAX_QUERIES;i++)
    {
        LPDIRECT3DQUERY9 query = NULL;
        HRESULT hr = pD3DDev->CreateQuery(D3DQUERYTYPE_OCCLUSION, &query);
        assert(hr == S_OK);
        m_Queries[i].query = query;
        m_Queries[i].state = LatentQueryElement::UNUSED;
    }

    // init our head pointer to the first element.  head is always the oldest query in use
    m_head = 0;
}

//////////////////////////////////////////////////////////////////////////
// Returns the most recent results of outstanding queries.  Once results have
// been encountered the query becomes unsued again.  If multiple queries
// finished since the last call, then only the most recent results will be returned.
HRESULT LatentOcclusionQueryBank::GetLatestResults(DWORD *count)
{
    // loop from head to end, and then from beginning to head
    int i = m_head;
    HRESULT rhr = S_FALSE;
    do 
    {
        // only go till we haven't issued yet or we've wrapped around to the head
        if(    m_Queries[i].state != LatentQueryElement::ISSUEDEND || 
            (i!=m_head && (i%MAX_QUERIES) == m_head))
            break;

        // Test the oldest queries first
        DWORD tempCount = 0;
        HRESULT hr = m_Queries[i].query->GetData(&tempCount,sizeof(DWORD),0);

        // if we have a result, then record it and keep testing
        if(hr == S_OK)
        {
            *count = tempCount;
            rhr = S_OK;
            m_Queries[i].state = LatentQueryElement::UNUSED;
        }
        else
            break;

        i++;
    } while(1);

    return rhr;
}

//////////////////////////////////////////////////////////////////////////
// Issue a new begin occlusion query into the pushbuffer.
HRESULT LatentOcclusionQueryBank::BeginNextQuery()
{
    int i = m_head;
    do 
    {
        // only go till we've wrapped around to the head
        if(    (i!=m_head && (i%MAX_QUERIES) == m_head))
            break;

        // first unused query gets begin'd
        if(m_Queries[i].state == LatentQueryElement::UNUSED)
        {
            m_Queries[i].state = LatentQueryElement::ISSUEDBEGIN;
            m_Queries[i].query->Issue(D3DISSUE_BEGIN);
            return S_OK;
        }
        i++;
    }
    while(1);
    return S_FALSE;
}

//////////////////////////////////////////////////////////////////////////
// Issue a new end occlusion query into the pushbuffer
HRESULT LatentOcclusionQueryBank::EndNextQuery()
{
    int i = m_head;
    do 
    {
        // only go till we've wrapped around to the head
        if(    (i!=m_head && (i%MAX_QUERIES) == m_head))
            break;

        // first begin'd query gets end'd
        if(m_Queries[i].state == LatentQueryElement::ISSUEDBEGIN)
        {
            m_Queries[i].state = LatentQueryElement::ISSUEDEND;
            m_Queries[i].query->Issue(D3DISSUE_END);
            return S_OK;
        }
        i++;
    }
    while(1);
    return S_FALSE;
}

void LatentOcclusionQueryBank::Free()
{
    for(unsigned int i=0;i<m_Queries.size();i++)
    {
        SAFE_RELEASE(m_Queries[i].query);
    }
    m_Queries.empty();
}

unsigned int LatentOcclusionQueryBank::GetNumActiveQueries()
{
    unsigned int count = 0;
    for(unsigned int i=0;i<m_Queries.size();i++)
    {
        if(m_Queries[i].state != LatentQueryElement::UNUSED)
            ++count;
    }
    return count;
}

#endif