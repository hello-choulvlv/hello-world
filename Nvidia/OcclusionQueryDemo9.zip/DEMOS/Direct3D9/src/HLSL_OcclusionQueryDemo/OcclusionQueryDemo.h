#ifndef OCCLUSIONQUERYDEMO_H
#define OCCLUSIONQUERYDEMO_H
#include "nvafx.h"
#include "OcclusionCulledObject.h"

class MeshVB;
class OcclusionCulledObject;

class Effect_OcclusionQueryDemo
{
private: 
    
    // data members
    LPD3DXEFFECT m_pEffect;
    
    DWORD    m_dwDepthClearFlags;

    OcclusionCulledObject * m_pOcclusionCulledObject;
    MeshVB *				m_pOccluder;

    D3DXMATRIX            m_OcclusionCulledWorldTrans;
	D3DXMATRIX            m_OccluderWorldTrans;

public: 
    Effect_OcclusionQueryDemo();

    D3DXMATRIX            *m_ViewTrans;
    D3DXMATRIX            *m_ProjTrans;

	// implemented virtual functions:
    HRESULT InvalidateDeviceObjects(); // called just before device is Reset
    HRESULT RestoreDeviceObjects(IDirect3DDevice9* pd3dDevice);    // called when device is restored
    HRESULT Render(IDirect3DDevice9* pd3dDevice, D3DXMATRIX *worldMat);
    HRESULT ConfirmDevice( D3DCAPS9* pCaps, D3DFORMAT adapterFormat, D3DFORMAT backbufferFormat );
};
#endif OCCLUSIONQUERYDEMO_H