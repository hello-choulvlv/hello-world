//--------------------------------------------------------------------------------------
// File: AssemblyInfo.cs
//
// Assembly information for all managed samples
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

using System;
using System.Security;
using System.Security.Permissions;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;

// Set assembly information
[assembly: AssemblyTitle("NVIDIA Dxsas")]
[assembly: AssemblyDescription("A Dxsas Sample implementation")]
[assembly: AssemblyCompany("NVIDIA")]
[assembly: AssemblyProduct("NVIDIA SDK")]
[assembly: AssemblyCopyright("Copyright (c) NVIDIA Corporation. All rights reserved.")]
// Update version
[assembly: AssemblyVersion("9.0.2902")]

// We will use UInt which isn't CLS compliant, possible unsafe code as well
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]

// Security information
[assembly: SecurityPermissionAttribute(SecurityAction.RequestMinimum, UnmanagedCode=true)]
[assembly: SecurityPermissionAttribute(SecurityAction.RequestMinimum, Execution=true)]

// We want to be able to read the registry key
[assembly: RegistryPermissionAttribute(SecurityAction.RequestMinimum,Read="HKEY_LOCAL_MACHINE\\Software\\NVIDIA Corporation\\Dxsas")]

