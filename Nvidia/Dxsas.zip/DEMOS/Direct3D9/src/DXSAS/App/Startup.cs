using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DXSAS.App
{
	/// <summary>
	/// Summary description for Startup.
	/// </summary>
	public class Startup : System.Windows.Forms.Form
	{
		public System.Windows.Forms.Label sceneEffects;
		public System.Windows.Forms.Label modelEffects;
		public System.Windows.Forms.Label foundEffect;
		public System.Windows.Forms.ProgressBar progressBar1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Startup()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Startup));
			this.sceneEffects = new System.Windows.Forms.Label();
			this.modelEffects = new System.Windows.Forms.Label();
			this.foundEffect = new System.Windows.Forms.Label();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			this.SuspendLayout();
			// 
			// sceneEffects
			// 
			this.sceneEffects.Location = new System.Drawing.Point(16, 48);
			this.sceneEffects.Name = "sceneEffects";
			this.sceneEffects.Size = new System.Drawing.Size(280, 23);
			this.sceneEffects.TabIndex = 0;
			this.sceneEffects.Text = "Scene Effects: ";
			// 
			// modelEffects
			// 
			this.modelEffects.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.modelEffects.Location = new System.Drawing.Point(16, 72);
			this.modelEffects.Name = "modelEffects";
			this.modelEffects.Size = new System.Drawing.Size(280, 23);
			this.modelEffects.TabIndex = 1;
			this.modelEffects.Text = "Model Effects: ";
			// 
			// foundEffect
			// 
			this.foundEffect.Location = new System.Drawing.Point(16, 16);
			this.foundEffect.Name = "foundEffect";
			this.foundEffect.Size = new System.Drawing.Size(248, 23);
			this.foundEffect.TabIndex = 2;
			this.foundEffect.Text = "Found Effect: ";
			// 
			// progressBar1
			// 
			this.progressBar1.Location = new System.Drawing.Point(16, 104);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(288, 16);
			this.progressBar1.Step = 1;
			this.progressBar1.TabIndex = 3;
			this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
			// 
			// Startup
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(318, 132);
			this.Controls.Add(this.progressBar1);
			this.Controls.Add(this.foundEffect);
			this.Controls.Add(this.modelEffects);
			this.Controls.Add(this.sceneEffects);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimizeBox = false;
			this.Name = "Startup";
			this.ShowInTaskbar = false;
			this.Text = "DXSAS Sample Starting...";
			this.TopMost = true;
			this.ResumeLayout(false);

		}
		#endregion

		private void progressBar1_Click(object sender, System.EventArgs e)
		{
		
		}
	}
}
