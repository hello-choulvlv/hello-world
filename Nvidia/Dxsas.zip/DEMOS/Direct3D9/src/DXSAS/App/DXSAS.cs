//-----------------------------------------------------------------------------
// File: Dxsas.cs
//
// Starting point for new Direct3D applications
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------


//#define DEBUG_VS   // Uncomment this line to debug vertex shaders 
//#define DEBUG_PS   // Uncomment this line to debug pixel shaders 

using System;
using System.IO;
using System.Diagnostics;
using System.Collections;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Microsoft.Samples.DirectX.UtilityToolkit;

namespace Dxsas
{
    /// <summary>Class for creating the Dxsas example</summary>
    public class App : IFrameworkCallback, IDeviceCreation
    {
        #region Creation
        /// <summary>Create a new instance of the class</summary>
        public App(Framework f) 
        { 
            // Store framework
            sampleFramework = f; 
            // Create dialogs
            hud = new Dialog(sampleFramework); 
			ui = new Dialog(sampleFramework);
        }
        #endregion
        // Variables
        private Framework sampleFramework = null; // Framework for samples
        private Font statsFont = null; // Font for drawing text
        private Sprite textSprite = null; // Sprite for batching text calls
		private Engine.SasCamera camera = new Engine.SasCamera(); // A model viewing camera
        private bool isHelpShowing = false; // If true, renders the UI help text
		private bool isControlShowing = true; // if true, renders the control panel
        private bool isUsingPreshader; // If false, the NoPreshader flag is used when compiling the shader
        private Dialog hud; // dialog for standard controls
		private Dialog ui; // dialog for app controls
		public static Engine.SasRenderer renderEngine = null;
		private Engine.SasScene scene = null;
		private SurfaceDescription backbufferDesc;
		private Engine.SasMaterial mat = null;
		private Engine.SasMesh mesh = null;
		private string sceneEffect = null;
		private string modelEffect = null;
		public static ListBox outputBox;
		private ListBox modelEffectBox;
		private ListBox sceneEffectBox;
		private StaticText modelEffectName;

       
		public System.Windows.Forms.MainMenu mnuMain = null;
		public System.Windows.Forms.MenuItem File = null;
		public System.Windows.Forms.MenuItem Exit = null;

        // HUD Ui Control constants
        private const int ToggleFullscreen = 1;
        private const int ToggleReference = 3;
        private const int ChangeDevice = 4;
		private const int ChangeEffects = 5;
		private const int MessagesControl = 6;
		private const int SceneBoxControl = 7;
		private const int ModelBoxControl = 8;
		private const int ComboBoxControl = 9;
		private const int ModelText = 10;
		private const int SceneText = 11;
		private const int ModelEffectText = 12;
        /// <summary>
        /// Called during device initialization, this code checks the device for some 
        /// minimum set of capabilities, and rejects those that don't pass by returning false.
        /// </summary>
        public bool IsDeviceAcceptable(Caps caps, Format adapterFormat, Format backBufferFormat, bool windowed)
        {
            // No fallback defined by this app, so reject any device that 
            // doesn't support at least ps1.1
            if (caps.PixelShaderVersion < new Version(1,1))
                return false;

            // Skip back buffer formats that don't support alpha blending
            if (!Manager.CheckDeviceFormat(caps.AdapterOrdinal, caps.DeviceType, adapterFormat, 
                Usage.QueryPostPixelShaderBlending, ResourceType.Textures, backBufferFormat))
                return false;

			
            return true;
        }

		public static void ReportError(string error)
		{
			outputBox.AddItem(error, -1);
		}

        /// <summary>
        /// This callback function is called immediately before a device is created to allow the 
        /// application to modify the device settings. The supplied settings parameter 
        /// contains the settings that the framework has selected for the new device, and the 
        /// application can make any desired changes directly to this structure.  Note however that 
        /// the sample framework will not correct invalid device settings so care must be taken 
        /// to return valid device settings, otherwise creating the Device will fail.  
        /// </summary>
        public void ModifyDeviceSettings(DeviceSettings settings, Caps caps)
        {
			// If device doesn't support HW T&L or doesn't support 1.1 vertex shaders in HW 
            // then switch to SWVP.
            if ( (!caps.DeviceCaps.SupportsHardwareTransformAndLight) ||
                (caps.VertexShaderVersion < new Version(1,1)) )
            {
                settings.BehaviorFlags = CreateFlags.SoftwareVertexProcessing;
            }
            else
            {
                settings.BehaviorFlags = CreateFlags.HardwareVertexProcessing;
            }

            // This application is designed to work on a pure device by not using 
            // any get methods, so create a pure device if supported and using HWVP.
            if ( (caps.DeviceCaps.SupportsPureDevice) && 
                ((settings.BehaviorFlags & CreateFlags.HardwareVertexProcessing) != 0 ) )
                settings.BehaviorFlags |= CreateFlags.PureDevice;

            // Debugging vertex shaders requires either REF or software vertex processing 
            // and debugging pixel shaders requires REF.  
#if(DEBUG_VS)
            if (settings.DeviceType != DeviceType.Reference )
            {
                settings.BehaviorFlags &= ~CreateFlags.HardwareVertexProcessing;
                settings.BehaviorFlags |= CreateFlags.SoftwareVertexProcessing;
            }
#endif
#if(DEBUG_PS)
            settings.DeviceType = DeviceType.Reference;
#endif

        }

		private void FindEffects(Device device)
		{
			DXSAS.App.Startup frm = new DXSAS.App.Startup();
			frm.Show();
						
			System.Reflection.Assembly executingAssembly = System.Reflection.Assembly.GetExecutingAssembly();
			string exeFolder = System.IO.Path.GetDirectoryName(executingAssembly.Location);
			
			string newFolder = exeFolder + "\\Media\\HLSL";
			DirectoryInfo dir = new DirectoryInfo(newFolder);
			if (!dir.Exists)
			{
				newFolder = exeFolder + "\\..\\..\\Media\\HLSL";
				dir = new DirectoryInfo(newFolder);
			}
			if (!dir.Exists)
			{
				newFolder = exeFolder + "\\..\\..\\src\\DXSAS\\Media\\HLSL";
				dir = new DirectoryInfo(newFolder);
			}

			if (dir.Exists)
			{
				int scene = 0;
				int model = 0;
				FileInfo[] files = dir.GetFiles("*.fx");

				frm.progressBar1.Minimum = 0;
				frm.progressBar1.Maximum = files.Length;
				frm.progressBar1.Value = 0;
				foreach(FileInfo file in files)
				{
					frm.foundEffect.Text = "Found Effect: " + file.Name;
					frm.Update();
					frm.progressBar1.Value++;

					mat = new Engine.SasMaterial();
					if (mat.Load(device, file.FullName, false))
					{
						if (mat.ScriptType == Engine.SasMaterial.ScriptEffectType.Scene)
						{
							scene++;
							sceneEffectBox.AddItem(file.Name, -1);
							frm.sceneEffects.Text = "Scene Effects: " + scene.ToString();
						}
						else
						{
							model++;
							modelEffectBox.AddItem(file.Name, -1);
							frm.modelEffects.Text = "Model Effects: " + model.ToString();
						}
						frm.Update();
					}
					mat.Dispose();
/*#if DEBUG
					if (frm.progressBar1.Value > 40)
						break;
#endif
*/
				}
			}
			
			frm.Close();
		}

        /// <summary>
        /// This event will be fired immediately after the Direct3D device has been 
        /// created, which will happen during application initialization and windowed/full screen 
        /// toggles. This is the best location to create Pool.Managed resources since these 
        /// resources need to be reloaded whenever the device is destroyed. Resources created  
        /// here should be released in the Disposing event. 
        /// </summary>
        private void OnCreateDevice(object sender, DeviceEventArgs e)
        {
			if (scene != null)
			{
				scene.Dispose();
				scene = null;
				renderEngine = null;				
			}

			// Create the scene and the render engine
			// Rendering engine implements the script drawing commands
			renderEngine = new Engine.SasRenderer();

			// Scene to hold the current draw set
			scene = new Engine.SasScene();

			// Give scene a camera
			scene.Camera = camera;

			// Start
			renderEngine.OnCreateDevice(e);

			// Load the mesh, before we apply effects
			mesh = new Engine.SasMesh();
			mesh.Load(e.Device, "bigship1.x");
			scene.AddMesh(mesh);

			// Only build on first device create.  Need the device to load the materials
			if (sceneEffectBox.NumberItems == 0 &&
				modelEffectBox.NumberItems == 0)
			{
				FindEffects(e.Device);

				// Default effects.
				sceneEffect = "post_corona.fx";
				modelEffect = "goochy_HLSL.fx";

				// Select the effects, which will apply them to the scene
				int i;
				if (modelEffectBox.NumberItems > 0)
				{
					// Select in the dialog
					for(i = 0; i < modelEffectBox.NumberItems; i++)
					{
						ListBoxItem item = modelEffectBox[i];
						if (string.Compare(item.ItemText, modelEffect, true) == 0)
						{
							modelEffectBox.SelectItem(i);
							break;
						}
					}
					if (i == modelEffectBox.NumberItems)
					{
						modelEffectBox.SelectItem(0);
					}
				}
				else
				{
					modelEffect = "";
				}

				if (sceneEffectBox.NumberItems > 0)
				{
					for(i = 0; i < sceneEffectBox.NumberItems; i++)
					{
						ListBoxItem item = sceneEffectBox[i];
						if (string.Compare(item.ItemText, sceneEffect, true) == 0)
						{
							sceneEffectBox.SelectItem(i);
							break;
						}
					}
					if (i == sceneEffectBox.NumberItems)
					{
						sceneEffectBox.SelectItem(0);
					}
				}
				else
				{
					sceneEffect = "";
				}

			}
			else
			{
				modelEffectBox.SelectItem(modelEffectBox.GetSelectedIndex(-1));
				sceneEffectBox.SelectItem(sceneEffectBox.GetSelectedIndex(-1));
			}
		
			Vector3 viewer = scene.SceneCenter + new Vector3(0.0f, 0.0f, -scene.SceneRadius * 2.0f);
			camera.DefaultPosition = viewer;
			camera.DefaultDirection = new Vector3(0.0f, 0.0f, 1.0f);
			camera.FocalLength = (scene.SceneRadius * 2.0f);
			camera.Reset();
			renderEngine.OnCreateDevice(e);

            // Initialize the stats font
            statsFont = ResourceCache.GetGlobalInstance().CreateFont(e.Device, 15, 0, FontWeight.Bold, 1, false, CharacterSet.Default,
                Precision.Default, FontQuality.Default, PitchAndFamily.FamilyDoNotCare | PitchAndFamily.DefaultPitch
                , "Arial");


            // Define DEBUG_VS and/or DEBUG_PS to debug vertex and/or pixel shaders with the 
            // shader debugger. Debugging vertex shaders requires either REF or software vertex 
            // processing, and debugging pixel shaders requires REF.  The 
            // ShaderFlags.Force*SoftwareNoOptimizations flag improves the debug experience in the 
            // shader debugger.  It enables source level debugging, prevents instruction 
            // reordering, prevents dead code elimination, and forces the compiler to compile 
            // against the next higher available software target, which ensures that the 
            // unoptimized shaders do not exceed the shader model limitations.  Setting these 
            // flags will cause slower rendering since the shaders will be unoptimized and 
            // forced into software.  See the DirectX documentation for more information about 
            // using the shader debugger.
            ShaderFlags shaderFlags = ShaderFlags.None;
#if(DEBUG_VS)
            shaderFlags |= ShaderFlags.ForceVertexShaderSoftwareNoOptimizations;
#endif
#if(DEBUG_PS)
            shaderFlags |= ShaderFlags.ForcePixelShaderSoftwareNoOptimizations;
#endif
            // Preshaders are parts of the shader that the effect system pulls out of the 
            // shader and runs on the host CPU. They should be used if you are GPU limited. 
            // The ShaderFlags.NoPreShader flag disables preshaders.
            if (!isUsingPreshader)
                shaderFlags |= ShaderFlags.NoPreShader;
        }
        
        /// <summary>
        /// This event will be fired immediately after the Direct3D device has been 
        /// reset, which will happen after a lost device scenario. This is the best location to 
        /// create Pool.Default resources since these resources need to be reloaded whenever 
        /// the device is lost. Resources created here should be released in the OnLostDevice 
        /// event. 
        /// </summary>
        private void OnResetDevice(object sender, DeviceEventArgs e)
        {
			renderEngine.OnResetDevice(e);
			scene.OnResetDevice(e);
            
            backbufferDesc = e.BackBufferDescription;

            // Create a sprite to help batch calls when drawing many lines of text
            textSprite = new Sprite(e.Device);

			camera.FieldOfView = (float)Math.PI / 4.0f;
			camera.SetWindow(e.BackBufferDescription.Width, e.BackBufferDescription.Height);
			

            // Setup UI locations
			hud.SetLocation(backbufferDesc.Width-155, 0);
			hud.SetSize(155,backbufferDesc.Height);
			hud.SetBackgroundColors(new ColorValue(0.5f, 0.5f, 1.0f, .5f));

			outputBox.SetLocation(0, e.BackBufferDescription.Height - 80);
			outputBox.SetSize(e.BackBufferDescription.Width, 80);
			outputBox.IsVisible = false;


        }

        /// <summary>
        /// This event function will be called fired after the Direct3D device has 
        /// entered a lost state and before Device.Reset() is called. Resources created
        /// in the OnResetDevice callback should be released here, which generally includes all 
        /// Pool.Default resources. See the "Lost Devices" section of the documentation for 
        /// information about lost devices.
        /// </summary>
        private void OnLostDevice(object sender, EventArgs e)
        {
			if (renderEngine != null)
			{
				renderEngine.OnLostDevice();
			}
			if (scene != null)
			{
				scene.OnLostDevice();
			}

            if (textSprite != null)
            {
                textSprite.Dispose();
                textSprite = null;
            }
        }

        /// <summary>
        /// This event will be fired immediately after the Direct3D device has 
        /// been destroyed, which generally happens as a result of application termination or 
        /// windowed/full screen toggles. Resources created in the OnCreateDevice event 
        /// should be released here, which generally includes all Pool.Managed resources. 
        /// </summary>
        private void OnDestroyDevice(object sender, EventArgs e)
        {
			if (scene != null)
			{
				scene.Dispose();
				renderEngine.OnDestroyDevice();

				scene = null;
				renderEngine = null;
			}
        }

        /// <summary>
        /// This callback function will be called once at the beginning of every frame. This is the
        /// best location for your application to handle updates to the scene, but is not 
        /// intended to contain actual rendering calls, which should instead be placed in the 
        /// OnFrameRender callback.  
        /// </summary>
        public void OnFrameMove(Device device, double appTime, float elapsedTime)
        {
            // Update the camera's position based on user input 
            camera.Update(scene, elapsedTime);
        }

        /// <summary>
        /// This callback function will be called at the end of every frame to perform all the 
        /// rendering calls for the scene, and it will also be called if the window needs to be 
        /// repainted. After this function has returned, the sample framework will call 
        /// Device.Present to display the contents of the next buffer in the swap chain
        /// </summary>
        public unsafe void OnFrameRender(Device device, double appTime, float elapsedTime)
        {
            bool beginSceneCalled = false;

            try
            {
				if (!device.Disposed)
				{
					device.BeginScene();

					// Some effect rely on this, so we're doing it here as a hack.
					//device.Clear(ClearFlags.ZBuffer | ClearFlags.Target, 0, 1.0f, 0);

					beginSceneCalled = true;

					if (renderEngine != null && scene != null)
					{
						renderEngine.SetTime((float)appTime);
						renderEngine.SetElapsedTime(elapsedTime);

						bool sceneUsedModel;
						renderEngine.Execute(scene, out sceneUsedModel);
						modelEffectBox.IsVisible = sceneUsedModel;
						modelEffectName.IsVisible = sceneUsedModel;
					}
				}
					
                // Show frame rate and help, etc
                RenderText(appTime);

				if (isControlShowing)
				{
					// Show UI
					hud.OnRender(elapsedTime);
				}
                
            }
            finally
            {
                if (beginSceneCalled)
                    device.EndScene();
            }
        }

        /// <summary>
        /// Render the help and statistics text. This function uses the Font object for 
        /// efficient text rendering.
        /// </summary>
        private void RenderText(double appTime)
        {
			TextHelper txtHelper = new TextHelper(statsFont, textSprite, 15);

			// Output statistics
			txtHelper.Begin();

			if (isHelpShowing)
			{

				txtHelper.SetInsertionPoint(2,20);
				txtHelper.SetForegroundColor(unchecked((int)0xffffff00));
				txtHelper.DrawTextLine(sampleFramework.FrameStats);
				txtHelper.DrawTextLine(sampleFramework.DeviceStats);

				txtHelper.SetForegroundColor(unchecked((int)0xffffffff));

				// Draw help
				//txtHelper.SetInsertionPoint(10, sampleFramework.BackBufferSurfaceDescription.Height-15*4);
				//txtHelper.SetForegroundColor(System.Drawing.Color.DarkOrange);
				txtHelper.DrawTextLine("Scene Effect: " + sceneEffect);
				txtHelper.DrawTextLine("Model Effect: " + modelEffect);
				txtHelper.DrawTextLine("Left button + mouse to rotate the scene");
				txtHelper.DrawTextLine("Click to change scene & model effects");
				txtHelper.DrawTextLine("CTRL + click to add multiple scene effects");
				txtHelper.DrawTextLine("Show/Hide Panel: H");
				txtHelper.DrawTextLine("Hide help: F1");
				txtHelper.DrawTextLine("Quit: Esc");
            }
            else
            {
				txtHelper.SetInsertionPoint(2,20);
				txtHelper.SetForegroundColor(unchecked((int)0xffffff00));
				txtHelper.DrawTextLine(sampleFramework.FPS.ToString());
				txtHelper.DrawTextLine("Show help: F1");
            }
			txtHelper.End();
        }

        /// <summary>
        /// As a convenience, the sample framework inspects the incoming windows messages for
        /// keystroke messages and decodes the message parameters to pass relevant keyboard
        /// messages to the application.  The framework does not remove the underlying keystroke 
        /// messages, which are still passed to the application's MsgProc callback.
        /// </summary>
        private void OnKeyEvent(System.Windows.Forms.Keys key, bool isKeyDown, bool isKeyUp)
        {
            if (isKeyDown)
            {
                switch(key)
                {
                    case System.Windows.Forms.Keys.F1:
                        isHelpShowing = !isHelpShowing;
                        break;
					case System.Windows.Forms.Keys.H:
						isControlShowing = !isControlShowing;
						break;
                }
            }
        }

        /// <summary>
        /// Before handling window messages, the sample framework passes incoming windows 
        /// messages to the application through this callback function. If the application sets 
        /// noFurtherProcessing to true, the sample framework will not process the message
        /// </summary>
        public IntPtr OnMsgProc(IntPtr hWnd, NativeMethods.WindowMessage msg, IntPtr wParam, IntPtr lParam, ref bool noFurtherProcessing)
        {
            // Give the dialog a chance to handle the message first
            noFurtherProcessing = hud.MessageProc(hWnd, msg, wParam, lParam);
            if (noFurtherProcessing)
                return IntPtr.Zero;

            // Pass all remaining windows messages to camera so it can respond to user input
            camera.HandleMessages(hWnd, msg, wParam, lParam);

			if (renderEngine != null && ((msg >= NativeMethods.WindowMessage.MouseFirst) && 
				(msg <= NativeMethods.WindowMessage.MouseLast) )
				|| ((msg == NativeMethods.WindowMessage.MouseMove)))
			{
				int xPos = NativeMethods.LoWord((uint)lParam.ToInt32());
				int yPos = NativeMethods.HiWord((uint)lParam.ToInt32());

				if (msg == NativeMethods.WindowMessage.MouseWheel)
				{
					// NativeMethods.WindowMessage.MouseWheel passes
					// screen mouse coords, so convert them to client coords
					System.Drawing.Point pt = new System.Drawing.Point(xPos, yPos);
					NativeMethods.ScreenToClient(hWnd, ref pt);
					xPos = pt.X; yPos = pt.Y;
				}
				switch (msg)
				{
					case NativeMethods.WindowMessage.LeftButtonDown:
						renderEngine.OnMouseLeftDown(true);
						break;
					case NativeMethods.WindowMessage.LeftButtonUp:
						renderEngine.OnMouseLeftDown(false);
						break;
					case NativeMethods.WindowMessage.MouseMove:
						renderEngine.OnMouseMove(xPos, yPos);
						break;
				}
			}

            return IntPtr.Zero;
        }

        /// <summary>Initializes the application</summary>
        public void InitializeApplication()
        {
            isUsingPreshader = false;

			
            int y = 10;
            // Initialize the dialogs
            Button fullScreen = hud.AddButton(ToggleFullscreen,"Toggle full screen", 5, y, 150,22);
            Button toggleRef = hud.AddButton(ToggleReference,"Toggle reference (F3)", 5, y += 24, 150,22);
            Button changeDevice = hud.AddButton(ChangeDevice,"Change Device (F2)", 5, y += 24, 150,22);

			// List boxes
			StaticText sceneEffectName = hud.AddStatic(ModelText, "Scene Effect", 0, y+=24 + 5, 150, 20, true);
			sceneEffectBox = hud.AddListBox(SceneBoxControl, 5, y+=25, 150, 100, ListBoxStyle.Multiselection);
			modelEffectName = hud.AddStatic(ModelText, "Model Effect", 0, y+=105, 150, 20, true);
			modelEffectBox = hud.AddListBox(ModelBoxControl, 5, y+=25, 150, 100, ListBoxStyle.SingleSelection);
			StaticText modelName = hud.AddStatic(ModelText, "Model", 0, y+=105, 150, 20, true);

			// Combo box
			ComboBox combo = hud.AddComboBox(ComboBoxControl, 5, y+=25, 150, 22);
			if (combo != null)
			{
				// Add some items
				combo.SetDropHeight(50);
				combo.AddItem("bigship1.x", 0);
				combo.AddItem("sphere.x", 1);
				combo.AddItem("head_sad.x", 2);
			}

			outputBox = hud.AddListBox(MessagesControl, 0, 0, 20, 20, ListBoxStyle.SingleSelection);

			// Hook the button events for when these items are clicked
            fullScreen.Click += new EventHandler(OnFullscreenClicked);
            toggleRef.Click += new EventHandler(OnRefClicked);
            changeDevice.Click += new EventHandler(OnChangeDevicClicked);
			combo.Changed += new EventHandler(OnModelChanged);

			modelEffectBox.Selection += new EventHandler(OnSelection);
			sceneEffectBox.Selection += new EventHandler(OnMultiSelection);
        }

		/// <summary>Called when the a selection is made on the multi listbox</summary>
		private void OnMultiSelection(object sender, EventArgs e)
		{
			ListBox lb = sender as ListBox;
			int selectedIndex = -1;

			ArrayList effects = new ArrayList();
			while ((selectedIndex = lb.GetSelectedIndex(selectedIndex)) != -1)
			{
				effects.Add(lb[selectedIndex].ItemText);
			}
			ChangeSceneEffects(effects);
		}


		private void OnSelection(object sender, EventArgs e)
		{
			ListBox lb = sender as ListBox;
			ListBoxItem lbi = lb[lb.GetSelectedIndex(-1)];

			ChangeModelEffect(lbi.ItemText);
		}

		private void OnModelChanged(object sender, EventArgs e)
		{
			ComboBox cb = sender as ComboBox;
			ComboBoxItem item = cb.GetSelectedItem();
			
			mesh = new Engine.SasMesh();
			mesh.Load(sampleFramework.Device, item.ItemText);
			mesh.ApplyEffect(Utility.FindMediaFile(modelEffect));

			scene.RemoveAllMeshes();
			scene.AddMesh(mesh);

			Vector3 viewer = scene.SceneCenter + new Vector3(0.0f, 0.0f, -scene.SceneRadius * 2.0f);
			camera.DefaultPosition = viewer;
			camera.DefaultDirection = new Vector3(0.0f, 0.0f, 1.0f);
			camera.FocalLength = (scene.SceneRadius * 2.0f);
			camera.Reset();

		}

		
        /// <summary>Called when the change device button is clicked</summary>
        private void OnChangeDevicClicked(object sender, EventArgs e)
        {
            sampleFramework.ShowSettingsDialog(!sampleFramework.IsD3DSettingsDialogShowing);
        }

		/// <summary>Called when the user wants to change the current effect
		private void ChangeModelEffect(string Effect)
		{
			string path = Utility.FindMediaFile(Effect);
			if (path == null || path.Length == 0)
				return;

			// Create a material
			mat = new Engine.SasMaterial();
			if (mat.Load(sampleFramework.Device, path))
			{
				mesh.ApplyEffect(path);

				modelEffect = System.IO.Path.GetFileName(path);
				if (mat.MaterialEffect == null)
				{
					modelEffect += " (Load FAILED)";
				}

				// Don't need this any more, since the mesh will build it's own list of materials.
				mat.Dispose();
			}
	
			// Reset pulse to cause effects to restart after load
			renderEngine.ResetPulse = true;
		}


		private void ChangeSceneEffects(ArrayList Effects)
		{
			scene.RemoveAllMaterials();
			sceneEffect = "";

			foreach(string effect in Effects)
			{
				string path = Utility.FindMediaFile(effect);
				if (path == null || path.Length == 0)
					return;

				// Create a material
				mat = new Engine.SasMaterial();
				if (mat.Load(sampleFramework.Device, path))
				{
					scene.AddMaterial(mat);
					if (sceneEffect.Length != 0)
					{
						sceneEffect += ", ";
					}
					sceneEffect += System.IO.Path.GetFileName(path);
					if (mat.MaterialEffect == null)
					{
						sceneEffect += " (Load FAILED)";
					}
				}
			}
	
			// Reset pulse to cause effects to restart after load
			renderEngine.ResetPulse = true;
		}


        /// <summary>Called when the full screen button is clicked</summary>
        private void OnFullscreenClicked(object sender, EventArgs e)
        {
            sampleFramework.ToggleFullscreen();
        }

        /// <summary>Called when the ref button is clicked</summary>
        private void OnRefClicked(object sender, EventArgs e)
        {
            sampleFramework.ToggleReference();
        }

        /// <summary>
        /// Entry point to the program. Initializes everything and goes into a message processing 
        /// loop. Idle time is used to render the scene.
        /// </summary>
        static int Main() 
        {
			
	

            using(Framework sampleFramework = new Framework())
            {
                App sample = new App(sampleFramework);
                // Set the callback functions. These functions allow the sample framework to notify
                // the application about device changes, user input, and windows messages.  The 
                // callbacks are optional so you need only set callbacks for events you're interested 
                // in. However, if you don't handle the device reset/lost callbacks then the sample 
                // framework won't be able to reset your device since the application must first 
                // release all device resources before resetting.  Likewise, if you don't handle the 
                // device created/destroyed callbacks then the sample framework won't be able to 
                // recreate your device resources.
                sampleFramework.Disposing += new EventHandler(sample.OnDestroyDevice);
                sampleFramework.DeviceLost += new EventHandler(sample.OnLostDevice);
                sampleFramework.DeviceCreated += new DeviceEventHandler(sample.OnCreateDevice);
                sampleFramework.DeviceReset += new DeviceEventHandler(sample.OnResetDevice);

                sampleFramework.SetKeyboardCallback(new KeyboardCallback(sample.OnKeyEvent));
				sampleFramework.SetWndProcCallback(new WndProcCallback(sample.OnMsgProc));

			    sampleFramework.SetCallbackInterface(sample);
                try
                {

                    // Show the cursor and clip it when in full screen
                    sampleFramework.SetCursorSettings(true, true);

                    // Initialize
                    sample.InitializeApplication();

		
                    // Initialize the sample framework and create the desired window and Direct3D 
                    // device for the application. Calling each of these functions is optional, but they
                    // allow you to set several options which control the behavior of the sampleFramework.
                    sampleFramework.Initialize( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
                    sampleFramework.CreateWindow("Dxsas");
                    sampleFramework.CreateDevice( 0, true, Framework.DefaultSizeWidth, Framework.DefaultSizeHeight, 
                        sample);


                    // Pass control to the sample framework for handling the message pump and 
                    // dispatching render calls. The sample framework will call your FrameMove 
                    // and FrameRender callback when there is idle time between handling window messages.
                    sampleFramework.MainLoop();

                }
#if(DEBUG)
                catch (Exception e)
                {
                    // In debug mode show this error (maybe - depending on settings)
                    sampleFramework.DisplayErrorMessage(e);
#else
            catch
            {
                // In release mode fail silently
#endif
                    // Ignore any exceptions here, they would have been handled by other areas
                    return (sampleFramework.ExitCode == 0) ? 1 : sampleFramework.ExitCode; // Return an error code here
                }

                // Perform any application-level cleanup here. Direct3D device resources are released within the
                // appropriate callback functions and therefore don't require any cleanup code here.
                return sampleFramework.ExitCode;
            }
        }
    }
}

