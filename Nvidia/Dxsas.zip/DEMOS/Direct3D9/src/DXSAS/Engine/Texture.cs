using System;
using System.Diagnostics;
using System.IO;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX;
using Microsoft.Samples.DirectX.UtilityToolkit;

namespace Dxsas.Engine
{
	/// <summary>
	/// Summary description for Texture.
	/// </summary>
	public class SasTexture : IDisposable
	{
		#region Members
		private bool isDisposed = false;
		private EffectHandle effectHandle;
		private Effect effect;
		private float width = 0;
		private float height = 0;
		private float levels = 0;
		private float depth = 0;
		private bool isDepth = false;
		private bool isTarget = false;
		private bool isViewportRatio = false;
		private Vector2 viewportRatio = new Vector2(1.0f, 1.0f);
		private Microsoft.DirectX.Direct3D.Format format = Format.A8R8G8B8;
		private DepthFormat depthFormat = DepthFormat.D24S8;
		private ParameterDescription paramDesc;
		private ParameterType textureType;
		private string resourceName = null;
		private string resourcePath = null;
		private string functionName = null;
		private BaseTexture texture = null;
		private Surface depthTarget = null;
		private string effectPath = null;
		#endregion


		#region Texture methods
		public ParameterDescription ParameterDescription { get { return paramDesc; } }
		public bool TextureFromEffectParam(Effect effect, EffectHandle parameterHandle, string effectPath)
		{
			try
			{
				effectHandle = parameterHandle;
				this.effect = effect;
				this.effectPath = effectPath;

				paramDesc = effect.GetParameterDescription(parameterHandle);
			
				// First get the desired format
				string formatText = null;
				if (SasEffectUtils.FindAnnotationString(effect, parameterHandle, "format", ref formatText))
				{
					format = new Format();
					try
					{
						format = ((Microsoft.DirectX.Direct3D.Format)Enum.Parse(typeof(Microsoft.DirectX.Direct3D.Format), formatText, true));
					}
					catch
					{
						App.ReportError("Didn't recognize format in texture annotation for: " + paramDesc.Name);
						format = Format.A8R8G8B8;
					}
				}

				textureType = paramDesc.Type;

				// Need more specifics on the texture type (2d, 3d, etc)
				if (paramDesc.Type == ParameterType.Texture)
				{
					string resourceType = null;
					if (!SasEffectUtils.FindAnnotationString(effect, parameterHandle, "resourcetype", ref resourceType))
					{
						SasEffectUtils.FindAnnotationString(effect, parameterHandle, "texturetype", ref resourceType);
					}

					if (resourceType != null)
					{
						if ( (string.Compare(resourceType, "3d", true) ==  0) ||
							(string.Compare(resourceType, "volume", true)== 0) )
						{
							textureType = ParameterType.Texture3D;
						}
						else if (string.Compare(resourceType, "cube", true) == 0)
						{
							textureType = ParameterType.TextureCube;
						}
						else if (string.Compare(resourceType, "1d", true) == 0)
						{
							textureType = ParameterType.Texture1D;
						}
						else if (string.Compare(resourceType, "2d", true) == 0)
						{
							textureType = ParameterType.Texture2D;
						}
					}
				}

				if (string.Compare(paramDesc.Semantic, "rendercolortarget", true) == 0)
				{
					isTarget = true;
				}
				if (string.Compare(paramDesc.Semantic, "renderdepthstenciltarget", true) == 0)
				{
					isDepth = true;

					// Check on the depth format.
					switch(format)
					{
						case Format.D16Lockable:
							depthFormat = DepthFormat.D16Lockable;
							break;
						case Format.D32:
							depthFormat = DepthFormat.D32;
							break;
						case Format.D15S1:
							depthFormat = DepthFormat.D15S1;
							break;
						case Format.D24X8:
							depthFormat = DepthFormat.D24X8;
							break;
						case Format.D24X4S4:
							depthFormat = DepthFormat.D24X4S4;
							break;
						case Format.D16:
							depthFormat = DepthFormat.D16;
							break;
						case Format.D32SingleLockable:
							depthFormat = DepthFormat.D32SingleLockable;
							break;
						case Format.D24S8:
							depthFormat = DepthFormat.D24S8;
							break;
						default:
						{
							format = Format.D24S8;
							depthFormat = DepthFormat.D24S8;
						}
							break;
					}
				}

				if (SasEffectUtils.FindAnnotationString(effect, parameterHandle, "resourcename", ref resourceName))
				{
					try
					{
						resourcePath = Utility.FindMediaFile(resourceName);
					}
					catch (Exception e)
					{
						if (!(e is MediaNotFoundException))
							throw;

						Debug.Write("Failed to find texture: " + resourceName);
					}
				}

				SasEffectUtils.FindAnnotationString(effect, parameterHandle, "function", ref functionName);
				SasEffectUtils.FindAnnotationValue(effect, parameterHandle, "width", ref width);
				SasEffectUtils.FindAnnotationValue(effect, parameterHandle, "height", ref height);
				if (!SasEffectUtils.FindAnnotationValue(effect, parameterHandle, "levels", ref levels))
				{
					SasEffectUtils.FindAnnotationValue(effect, parameterHandle, "miplevels", ref levels);
				}
				SasEffectUtils.FindAnnotationValue(effect, parameterHandle, "depth", ref depth);

				Vector4 dim = new Vector4();
				if (SasEffectUtils.FindAnnotationValue(effect, parameterHandle, "dimensions", ref dim))
				{
					width = dim.X;
					height = dim.Y;
					depth = dim.Z;
				}

				Vector4 ratio = new Vector4(1.0f, 1.0f, 0.0f, 0.0f);
				if (SasEffectUtils.FindAnnotationValue(effect, parameterHandle, "viewportratio", ref ratio))
				{
					viewportRatio.X = ratio.X;
					viewportRatio.Y = ratio.Y;

					isViewportRatio = true;
					if (viewportRatio.X <= 0.0f)
						viewportRatio.X = 1.0f;
					if (viewportRatio.Y <= 0.0f)
						viewportRatio.Y = 1.0f;
				}

				// Did we get a format we can handle?
				Usage usage = new Usage();
				usage = Usage.None;
				if (isTarget)
				{
					usage = Usage.RenderTarget;
				}

				bool bDefault = false;
				int result;
				if (textureType == ParameterType.TextureCube)
				{
					if (!Manager.CheckDeviceFormat(0, DeviceType.Hardware, Format.X8R8G8B8, usage, ResourceType.CubeTexture, format, out result))
					{
						Debug.Write("Defaulting to A8R8G8, due to missing texture format support\n");
						bDefault = true;
					}
				}
				else if (textureType == ParameterType.Texture2D ||
					textureType == ParameterType.Texture1D ||
					textureType == ParameterType.Texture)
				{
					if (!Manager.CheckDeviceFormat(0, DeviceType.Hardware, Format.X8R8G8B8, usage, ResourceType.Textures, format, out result))
					{
						Debug.Write("Defaulting to A8R8G8, due to missing texture format support\n");
						bDefault = true;
					}
				}
				else if (textureType == ParameterType.Texture3D)
				{
					if (!Manager.CheckDeviceFormat(0, DeviceType.Hardware, Format.X8R8G8B8, usage, ResourceType.VolumeTexture, format, out result))
					{
						Debug.Write("Defaulting to A8R8G8, due to missing texture format support\n");
						bDefault = true;
					}
				}

				// sensible defaults
				if (bDefault)
				{
					if (isDepth)
					{
						depthFormat = DepthFormat.D24S8;
					}
					else
					{
						format = Format.A8R8G8B8;
					}
				}

				// Force a reload of the surfaces
				LoadTargets(effect.Device, true);
			}
			catch
			{
				// Problem buildling the texture.
				App.ReportError("Problem building a texture");
				return false;
			}

			return true;
		}

		public bool OnResetDevice(DeviceEventArgs e)
		{
			LoadTargets(e.Device, false);
			return true;
		}

		public bool OnLostDevice()
		{
			if (isDepth && (depthTarget != null))
			{
				depthTarget.Dispose();
				depthTarget = null;
			}
			if (isTarget && (texture != null))
			{
				texture.Dispose();
				texture = null;
			}
			return true;
		}

		public bool LoadTargets(Device device, bool bForce)
		{
			if (!bForce && !isTarget && !isDepth && !isViewportRatio)		
			{
				if (texture == null && depthTarget == null)
					App.ReportError("Texture not created");
				return true;
			}


			// Make sure we dispose old ones
			if (texture != null)
			{
				texture.Dispose();
				texture = null;
			}
			if (depthTarget != null)
			{
				depthTarget.Dispose();
				depthTarget = null;
			}
			
			int targetWidth = (int)width;
			int targetHeight = (int)height;
			if (isViewportRatio)
			{
				targetWidth = (int)(viewportRatio.X * App.renderEngine.Viewport.X);
				targetHeight = (int)(viewportRatio.Y * App.renderEngine.Viewport.Y);
			}

			if (resourcePath != null)
			{
				if (textureType == ParameterType.TextureCube)
				{
					texture = ResourceCache.GetGlobalInstance().CreateCubeTextureFromFileEx(effect.Device, resourcePath, targetWidth, (int)levels, Usage.None, format, Pool.Managed, (Filter)D3DX.Default, (Filter)D3DX.Default, 0);
				}
				else if (textureType == ParameterType.Texture2D ||
					textureType == ParameterType.Texture1D ||
					textureType == ParameterType.Texture)
				{
					texture = ResourceCache.GetGlobalInstance().CreateTextureFromFileEx(effect.Device, resourcePath, targetWidth, targetHeight, (int)levels, Usage.None, format, Pool.Managed, (Filter)D3DX.Default,(Filter) D3DX.Default, 0);
				}
				else if (textureType == ParameterType.Texture3D)
				{
					texture = ResourceCache.GetGlobalInstance().CreateVolumeTextureFromFileEx(effect.Device, resourcePath, targetWidth, targetHeight, (int)depth, (int)levels, Usage.None, format, Pool.Managed, (Filter)D3DX.Default, (Filter)D3DX.Default, 0);
				}
				else
				{
					if (texture == null)
					{
						App.ReportError("Couldn't find texture: " + resourcePath);
					}
				}
				

			}
			else if (functionName != null)
			{
				string errors;
				ConstantTable constants;

				// We may be here for the first creation of the function texture, or we may be here
				// because the function texture is associated with the viewport size, and it needs to be rebuilt.
				FileStream stream = new FileStream(effectPath, FileMode.Open, FileAccess.Read);
				StreamReader streamReader = new StreamReader(stream);
				string effecttext = streamReader.ReadToEnd();
				streamReader.Close();

				GraphicsStream functionStream = ShaderLoader.CompileShader(effecttext, functionName, null, new SasIncluder(), "tx_1_0", 0, out errors, out constants);
				if (functionStream == null)
				{
					App.ReportError("Couldn't find texture function: " + functionName);
					return false;
				}

				TextureShader shader = new TextureShader(functionStream);
				if (shader == null)
				{
					App.ReportError("Couldn't create texture shader from function stream for: " + functionName);
					return false;
				}

				if (textureType == ParameterType.TextureCube)
				{
					CubeTexture cubeTexture = new CubeTexture(effect.Device, (int)targetWidth, (int)levels, 0, format, Pool.Managed);

					TextureLoader.FillTexture(cubeTexture, shader);
					texture = cubeTexture;
				}
				else if (textureType == ParameterType.Texture2D ||
					textureType == ParameterType.Texture1D ||
					textureType == ParameterType.Texture)
				{
					Texture newTex = new Texture(effect.Device, (int)targetWidth, (int)targetHeight, (int)levels, 0, format, Pool.Managed);
					TextureLoader.FillTexture(newTex, shader);
					texture = newTex;
				}
				else if (textureType == ParameterType.Texture3D)
				{
					VolumeTexture volumeTexture = new VolumeTexture(effect.Device, (int)targetWidth, (int)targetHeight, (int)depth, (int)levels, 0, format, Pool.Managed);
					TextureLoader.FillTexture(volumeTexture, shader);
					texture = volumeTexture;
				}
				else
				{
					App.ReportError("Unknown texture type in function shading");
				}					
			}
			else
			{
				if (isDepth)
				{
					depthTarget = device.CreateDepthStencilSurface(targetWidth, targetHeight, depthFormat, MultiSampleType.None, 0, false);
				}
				else if (isTarget)
				{
					// Just allocate, probably a rendertarget
					if (textureType == ParameterType.TextureCube)
					{
						CubeTexture cubeTexture = new CubeTexture(device, targetWidth, (int)levels, Usage.RenderTarget, format, Pool.Default);					
						texture = cubeTexture;
					}
					else if (textureType == ParameterType.Texture2D ||
						textureType == ParameterType.Texture1D ||
						textureType == ParameterType.Texture)
					{
						Texture newTex = new Texture(device, targetWidth, targetHeight, (int)levels, Usage.RenderTarget, format, Pool.Default);
						texture = newTex;
					}
					else if (textureType == ParameterType.Texture3D)
					{
						VolumeTexture volumeTexture = new VolumeTexture(device, targetWidth, targetHeight, (int)depth, (int)levels, Usage.RenderTarget, format, Pool.Default);					
						texture = volumeTexture;
					}
				}
			}

			// Setup the new value.
			effect.SetValue(effectHandle, texture);
			return true;
		}

		public BaseTexture DeviceTexture
		{
			get { return texture; }
		}

		public Surface DepthSurface
		{
			get { return depthTarget; }
		}

		public EffectHandle GetHandle()
		{
			return effectHandle;
		}

		public void SetTexture(BaseTexture tex)
		{
			texture = tex;
			effect.SetValue(effectHandle, texture);
		}

		#endregion

		#region IDisposable Members

		public void Dispose()
		{
			GC.SuppressFinalize(this);

			if (!isDisposed)
			{
				if (depthTarget != null)
					depthTarget.Dispose();

				if (texture != null)
					texture.Dispose();

				depthTarget = null;
				texture = null;

				isDisposed = true;
			}

		}

		~SasTexture()
		{
			Dispose();
		}
		#endregion
	}
}
