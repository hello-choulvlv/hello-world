using System;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Collections;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using System.Windows.Forms;
using Microsoft.Samples.DirectX.UtilityToolkit;

namespace Dxsas.Engine
{

	/// <summary>
	/// Summary description for Material.
	/// </summary>
	public class SasMaterial : IDisposable
	{
		public enum ScriptEffectType
		{
			Scene,
			Object
		};

		public enum SemanticID
		{
			unknown,
			position,
			direction,
			diffuse,
			specular,
			ambient,
			emissive,
			specularpower,
			refraction,
			opacity,
			environment,
			environmentnormal,
			normal,
			height,
			attenuation,
			rendercolortarget,
			renderdepthstenciltarget,
			viewportpixelsize,
			cameraposition,
			time,
			elapsedtime,
			animationtime,
			animationtick,
			mouseposition,
			leftmousedown,
			resetpulse,
			world,
			view,
			projection,
			worldtranspose,
			viewtranspose,
			projectiontranspose,
			worldview,
			worldviewprojection,
			worldinverse,
			viewinverse,
			projectioninverse,
			worldinversetranspose,
			viewinversetranspose,
			projectioninversetranspose,
			worldviewinverse,
			worldviewtranspose,
			worldviewinversetranspose,
			worldviewprojectioninverse,
			worldviewprojectiontranspose,
			worldviewprojectioninversetranspose,
			viewprojection,
			viewprojectiontranspose,
			viewprojectioninverse,
			viewprojectioninversetranspose,
			fxcomposer_resetpulse
		}

		public struct ParameterInfo
		{
			public SemanticID semanticID;
			public EffectHandle handle;
		};

		private ScriptEffectType scriptType;
		private string effectPath = null;
		private bool isDisposed = false;
		private Effect effect = null;
		private ArrayList textures = new ArrayList();
		private ArrayList globalScript = new ArrayList();
		private Hashtable techniques = new Hashtable();
		private Hashtable passes = new Hashtable();
		private ArrayList parameterInfo = new ArrayList();

		public string EffectPath { get { return effectPath; } }
		public ParameterInfo GetParameterInfo(int index)
		{
			Debug.Assert(index < parameterInfo.Count, "GetParameterInfo out of bounds");
			return (ParameterInfo)parameterInfo[index];
		}
		public ScriptEffectType ScriptType
		{
			get { return scriptType; }
		}
		public Effect MaterialEffect
		{
			get { return effect; }
		}

		public bool Load(Device device, string path)
		{
			return Load(device, path, true);
		}
		public bool Load(Device device, string path, bool loadTextures)
		{
			effectPath = path;
			string errors;
			effect = Effect.FromFile(device, path, null, new SasIncluder(), string.Empty, ShaderFlags.NoPreShader, null, out errors);

			if (effect == null)
				return false;

			EffectHandle handleTech = effect.FindNextValidTechnique(null);
			if (handleTech == null)
			{
				effect.Dispose();
				effect = null;
				return false;
			}

			if (!LoadParameters())
			{
				effect.Dispose();
				effect = null;
				return false;
			}

			if (!LoadScript())
			{
				effect.Dispose();
				effect = null;
				return false;
			}

			if (loadTextures)
				LoadTextures();

			

			return true;
		}
		
		public SasTexture GetTexture(EffectHandle Handle)
		{
			foreach(SasTexture tex in textures)
			{
				if (tex.GetHandle() == Handle)
					return tex;
			}
			return null;
		}

		public bool OnLostDevice()
		{
			if (effect != null && !effect.Disposed)
			{
				effect.OnLostDevice();
			}
			foreach(SasTexture tex in textures)
			{
				tex.OnLostDevice();
			}

			return true;
		}
		
		public bool OnResetDevice(DeviceEventArgs e)
		{
			if (effect != null && !effect.Disposed)
			{
				effect.OnResetDevice();
			}
			// Potentially reload textures
			foreach(SasTexture tex in textures)
			{
				tex.OnResetDevice(e);
			}

			return true;
		}

		private bool LoadTextures()
		{
			for(int i = 0; i < effect.Description.Parameters; i++)
			{
				EffectHandle handleParam = effect.GetParameter(null, i);
				ParameterDescription desc = effect.GetParameterDescription(handleParam);
				if (desc.Type == ParameterType.Texture ||
					desc.Type == ParameterType.Texture1D ||
					desc.Type == ParameterType.Texture2D ||
					desc.Type == ParameterType.Texture3D ||
					desc.Type == ParameterType.TextureCube)
				{
					SasTexture tex = new SasTexture();
					if (tex.TextureFromEffectParam(effect, handleParam,effectPath))
					{
						textures.Add(tex);
					}
				}
			}

			return true;
		}

		private bool LoadParameters()
		{
			parameterInfo.Clear();
			for(int i = 0; i < effect.Description.Parameters; i++)
			{
				EffectHandle handleParam = effect.GetParameter(null, i);
				ParameterDescription desc = effect.GetParameterDescription(handleParam);
				ParameterInfo info = new ParameterInfo();
				if ((desc.Semantic != null) && desc.Semantic.Length > 0)
				{
					try
					{
						info.semanticID = ((SemanticID)Enum.Parse(typeof(SemanticID), desc.Semantic, true));
					}
					catch
					{
						info.semanticID = SemanticID.unknown;
					}
				}
				else
				{
					info.semanticID = SemanticID.unknown;
				}
				info.handle = handleParam;
				parameterInfo.Add(info);
			}

			return true;
		}
		private bool LoadScript()
		{
			for(int i = 0; i < effect.Description.Parameters; i++)
			{
				EffectHandle handleParam = effect.GetParameter(null, i);
				ParameterDescription desc = effect.GetParameterDescription(handleParam);
				if (desc.Type == ParameterType.Float &&
					string.Compare(desc.Semantic, "STANDARDSGLOBAL", true) == 0)
				{
					string script = null;
					SasEffectUtils.FindAnnotationString(effect, handleParam, "script", ref script);
					globalScript = ReadScript(script, null);

					// Default
					scriptType = ScriptEffectType.Object;
					string scriptClass = null;
					SasEffectUtils.FindAnnotationString(effect, handleParam, "ScriptClass", ref scriptClass);
					if (scriptClass != null)
					{
						if (string.Compare(scriptClass, "scene", true) == 0)
							scriptType = ScriptEffectType.Scene;
					}
				}
			}

			if (globalScript.Count == 0)
			{
				App.ReportError("Couldn't find standardsglobal entry point");
				return false;
			}

			for (int technique = 0; technique < effect.Description.Techniques; technique++)
			{
				EffectHandle handleTech = effect.GetTechnique(technique);
				string script = null;
				SasEffectUtils.FindTechniqueAnnotationString(effect, handleTech, "script", ref script);
				ArrayList list = ReadScript(script, null);
				if (list == null || list.Count == 0)
				{
					App.ReportError("Couldn't find technique script");
					return false;
				}
				techniques.Add(handleTech, list);

				TechniqueDescription techDesc = effect.GetTechniqueDescription(handleTech);
				for (int pass = 0; pass < techDesc.Passes; pass++)
				{
					EffectHandle handlePass = effect.GetPass(handleTech, pass);
					string passScript = null;
					SasEffectUtils.FindPassAnnotationString(effect, handlePass, "script", ref passScript);

					ArrayList passList = ReadScript(passScript, handleTech);
					if (passList == null || passList.Count == 0)
					{
						App.ReportError("Couldn't find pass script");
						return false;
					}

					passes.Add(handlePass, passList);
				}
			}

			return true;
		}

		public void DirtyCommands()
		{
			foreach(object command in globalScript)
			{
				((SasScriptCommand)command).IsDirty = true;
			}
			IDictionaryEnumerator myEnumerator = passes.GetEnumerator();
			while ( myEnumerator.MoveNext() )
			{
				ArrayList commands = (ArrayList)myEnumerator.Value;
				foreach(SasScriptCommand command in commands)
				{
					command.IsDirty = true;
				}
			}
			myEnumerator = techniques.GetEnumerator();
			while ( myEnumerator.MoveNext() )
			{
				ArrayList commands = (ArrayList)myEnumerator.Value;
				foreach(SasScriptCommand command in commands)
				{
					command.IsDirty = true;
				}
			}
		}

		private ArrayList ReadScript(string script, EffectHandle handleTech)
		{
			if (script == null || script.Length == 0)
				return null;
			// Make it low case for easier comparisons

			ArrayList commandList = new ArrayList();
			script.ToLower();

			script = Regex.Replace(script, @"[ \t]", "");

			Regex RE = new Regex(@";");
			string [] commands = RE.Split(script);

			foreach (string command in commands)
			{
				if ((command == null) || (command.Length == 0))
					continue;

				// Get the lhs=rhs split
				Regex CommandValue = new Regex(@"=");
				string [] instructionPair = CommandValue.Split(command);

				// Need a valid command
				if (instructionPair.Length == 0)
					continue;

				int commandIndex = 0;
				SasScriptCommand.CommandType scriptCommand;
				try
				{
					// Handle indexed stuff, such as rendercolortarget#
					string testCommand = instructionPair[0];

					Regex DigitFind = new Regex(@"[0123456789]");
					Match match = DigitFind.Match(testCommand);
					if (match.Success)
					{
						commandIndex = Int32.Parse(testCommand.Substring(match.Index, testCommand.Length - match.Index));
						testCommand = testCommand.Substring(0, match.Index);
					}
						
					// Get the command ID
					scriptCommand = (SasScriptCommand.CommandType)Enum.Parse(typeof(SasScriptCommand.CommandType), testCommand, true);
				}
				catch
				{
					App.ReportError("Error parsing scriptcommands");
					continue;
				}

				// Options are the choices on the right of the =
				ArrayList optionStrings = new ArrayList();

				// Selector is the thing that makes the choice
				string selectorString = null;

				// Anything on the right of the =?
				if (instructionPair.Length > 1)
				{
					// Parse the choices (we can do stuff like clearsetcolor=ChoiceParam?Color1Param : Color2Param)
					Regex optionsParse = new Regex(@"\?");
					string [] options = optionsParse.Split(instructionPair[1]);

					if (options.Length == 1)
					{
						// No selector, just an option
						optionStrings.Add(options[0]);
						selectorString = null;
					}
					else if (options.Length > 1)
					{
						// More than one, so the first one is definately the selection
						selectorString = options[0];

						// Get the options.
						Regex optionsSplit = new Regex(@":");
						string [] optionList = optionsSplit.Split(options[1]);
						for (int opt = 0; opt < optionList.Length; opt++)
						{
							optionStrings.Add(optionList[opt]);
                        }

						// No options, which must be a bug.
						if (optionStrings.Count == 0)
						{
							// bad
							break;
						}
					}
				}
	
				SasScriptCommand commandHandler;
				switch(scriptCommand)
				{
					case SasScriptCommand.CommandType.Clear:
						commandHandler = new SasScript_Clear(effect);
						break;
					case SasScriptCommand.CommandType.LoopByType:
						commandHandler = new SasScript_LoopByType(effect);
						break;
					case SasScriptCommand.CommandType.LoopByCount:
						commandHandler = new SasScript_LoopByCount(effect);
						break;
					case SasScriptCommand.CommandType.LoopGetCount:
						commandHandler = new SasScript_LoopGetCount(effect);
						break;
					case SasScriptCommand.CommandType.LoopGetIndex:
						commandHandler = new SasScript_LoopGetIndex(effect);
						break;
					case SasScriptCommand.CommandType.LoopUpdate:
						commandHandler = new SasScript_LoopUpdate(effect);
						break;
					case SasScriptCommand.CommandType.LoopEnd:
						commandHandler = new SasScript_LoopEnd(effect);
						break;
					case SasScriptCommand.CommandType.RenderColorTarget:
						commandHandler = new SasScript_RenderColorTarget(effect);
						break;
					case SasScriptCommand.CommandType.RenderDepthStencilTarget:
						commandHandler = new SasScript_RenderDepthStencilTarget(effect);
						break;
					case SasScriptCommand.CommandType.Technique:
						commandHandler = new SasScript_Technique(effect);
						break;
					case SasScriptCommand.CommandType.Pass:
						commandHandler = new SasScript_Pass(effect);
						break;
					case SasScriptCommand.CommandType.Draw:
						commandHandler = new SasScript_Draw(effect);
						break;
					case SasScriptCommand.CommandType.ScriptSignature:
						commandHandler = new SasScript_ScriptSignature(effect);
						break;
					case SasScriptCommand.CommandType.ScriptExternal:
						commandHandler = new SasScript_ScriptExternal(effect);
						break;
					case SasScriptCommand.CommandType.ClearSetColor:
						commandHandler = new SasScript_ClearSetColor(effect);
						break;
					case SasScriptCommand.CommandType.ClearSetDepth:
						commandHandler = new SasScript_ClearSetDepth(effect);
						break;
					case SasScriptCommand.CommandType.ClearSetStencil:
						commandHandler = new SasScript_ClearSetStencil(effect);
						break;
					case SasScriptCommand.CommandType.GeometryList:
						commandHandler = new SasScript_GeometryList(effect);
						break;
					case SasScriptCommand.CommandType.Hint:
						commandHandler = new SasScript_Hint(effect);
						break;
					default:
						App.ReportError("Unrecognized script command");
						continue;
				}

				commandHandler.Selector = selectorString;
				commandHandler.Options = optionStrings;
				commandHandler.Index = commandIndex;
				
				// One time setup of the command
				commandHandler.Setup();

				// Every time params change, update the dirty state
				// so choices can be evaluated and converted to handles during execution
				commandHandler.IsDirty = true;

				commandList.Add(commandHandler);

			}
			return commandList;
		}

		public ArrayList EntryPoint
		{
			get { return globalScript; }
		}
		public ArrayList GetTechniqueScript(EffectHandle handle)
		{
			return (ArrayList)techniques[handle];
		}
		public ArrayList GetPassScript(EffectHandle handle)
		{
			return (ArrayList)passes[handle];
		}


		#region IDisposable Members

		public void Dispose()
		{
			GC.SuppressFinalize(this);
			
			if (!isDisposed)
			{

				if (textures != null)
				{
					// Dispose all our textures
					foreach(SasTexture tex in textures)
					{
						tex.Dispose();
					}		

					textures.Clear();
				}
				if (globalScript != null)
					globalScript.Clear();
				if (techniques != null)
                    techniques.Clear();
				if (passes != null)
					passes.Clear();
				if (effect != null && !effect.Disposed)
				{
					effect.Dispose();
					effect = null;
				}
			}
            
			// The object has now been disposed
			isDisposed = true;
		}

		~SasMaterial()
		{
			Dispose();
		}
		#endregion
	}
}
