using System;
using System.Text.RegularExpressions;
using System.Diagnostics;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX;
using System.Collections;

namespace Dxsas.Engine
{
	public class SasScriptCommand
	{

		public enum CommandType
		{
			LoopByType,
			LoopByCount,
			LoopGetCount,
			LoopGetIndex,
			LoopUpdate,
			LoopEnd,
			RenderColorTarget,
			RenderDepthStencilTarget,
			Technique,
			Pass,
			Draw,
			ScriptSignature,
			ScriptExternal,
			Clear,
			ClearSetColor,
			ClearSetDepth,
			ClearSetStencil,
			GeometryList,
			Hint
		};

		private int index;
		private CommandType commandType;
		private ArrayList optionStrings;
		private string selector;
		protected bool isDirty;
		protected Effect effect;

		public bool IsDirty
		{
			set { isDirty = value; }
			get { return isDirty; }
		}
		public virtual bool Setup()
		{

			return true;
		}

		public virtual bool Update()
		{

			return true;
		}

		protected string EvaluateChoice()
		{
			int index = -1;
			return EvaluateChoice(ref index);
		}
		protected string EvaluateChoice(ref int index)
		{
			string ret = null;
			if (selector == null ||
				selector.Length == 0)
			{
				ret = (string)optionStrings[0];
			}
			else
			{
				EffectHandle parameterHandle = effect.GetParameter(null, selector);
				if (parameterHandle == null)
				{
					// bad - maybe they wanted a UI string, but this is probably not valid in the current spec.
					// (selector should always be a valid parameter).
					// We'll just return the first option.
					ret = (string)optionStrings[0];
				}
				else
				{
					ParameterDescription desc = effect.GetParameterDescription(parameterHandle);
					switch(desc.Type)
					{
						case ParameterType.Boolean:
						{
							bool bValue = effect.GetValueBoolean(parameterHandle);
							if (optionStrings.Count != 2)
							{
								App.ReportError("bool selector must have 2 arguments");
								ret = "";
							}
							else
							{
								ret = (bValue ? (string)optionStrings[0] : (string)optionStrings[1]);
							}
						}
						break;
						case ParameterType.Integer:
						{
							int iValue = effect.GetValueInteger(parameterHandle);
							if (optionStrings.Count <= iValue)
							{
								App.ReportError("integer selector too large");
								ret = "";
							}
							else
							{
								ret = (string)optionStrings[iValue];
							}
						}
						break;
						case ParameterType.Float:
						{
							int iValue = (int)effect.GetValueFloat(parameterHandle);
							if (optionStrings.Count <= iValue)
							{
								App.ReportError("float selector too large");
							}
							ret = (string)optionStrings[iValue];
						}
						break;
						default:
						{
							App.ReportError("Invalid choice selector");
						}
						break;
					}
				}
			}
			if (ret != null)
			{
				// Check for end index e.g. clear=color0, clear=color1, etc.
				if (index != -1)
				{
					Regex DigitFind = new Regex(@"[0123456789]");
					Match match = DigitFind.Match(ret);
					if (match.Success)
					{
						index = Int32.Parse(ret.Substring(match.Index, ret.Length - match.Index));
						ret = ret.Substring(0, match.Index);
					}
					else
					{
						index = 0;
					}
				}
				return ret;
			}

			return null;

		}
		public SasScriptCommand(CommandType type, Effect effect)
		{
			commandType = type;
			this.effect = effect;
		}

		public CommandType Command
		{
			get { return commandType; }
		}

		public string Selector
		{
			get { return selector; }
			set { selector = value; }
		}

		public ArrayList Options
		{
			get { return optionStrings; }
			set { optionStrings = value; }
		}

		public int Index
		{
			get { return index; }
			set { index = value; }
		}


	}

	public class SasScript_LoopByType : SasScriptCommand
	{
		public SasScript_LoopByType(Effect effect)
			: base(SasScriptCommand.CommandType.LoopByType, effect)
		{
		}


	}

	public class SasScript_LoopByCount : SasScriptCommand
	{
		private int count;
		public int Count { get { return count; } }

		public SasScript_LoopByCount(Effect effect)
			: base(SasScriptCommand.CommandType.LoopByCount, effect)
		{
		}

		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				count = 0;

				if (selection != null && selection.Length != 0)
				{
					EffectHandle paramHandle = effect.GetParameter(null, selection);
					
					if (paramHandle == null)
					{
						App.ReportError("Couldn't get loopbycount parameter");
					}
					else
					{
						count = SasEffectUtils.GetIntegerFromParam(effect, paramHandle);
					}
				}

				isDirty = false;
			}
			return true;
		}
	}

	public class SasScript_LoopGetCount : SasScriptCommand
	{
		private EffectHandle paramHandle;
		public EffectHandle DestinationParameter { get { return paramHandle; } } 

		public SasScript_LoopGetCount(Effect effect)
			: base(SasScriptCommand.CommandType.LoopGetCount, effect)
		{
		}


		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();

				if (selection != null && selection.Length != 0)
				{
					paramHandle = effect.GetParameter(null, selection);
					if (paramHandle == null)
					{
						App.ReportError("Couldn't get loopgetcount parameter");
					}
				}

				isDirty = false;
			}
			return true;
		}
	}

	public class SasScript_LoopGetIndex : SasScriptCommand
	{
		private EffectHandle paramHandle;
		
		public EffectHandle DestinationParameter { get { return paramHandle; } } 

		public SasScript_LoopGetIndex(Effect effect)
			: base(SasScriptCommand.CommandType.LoopGetIndex, effect)
		{
		}

		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				if (selection != null && selection.Length != 0)
				{
					paramHandle = effect.GetParameter(null, selection);
					if (paramHandle == null)
					{
						App.ReportError("Couldn't get loopgetindex parameter");
					}
				}

				isDirty = false;
			}
			return true;
		}
	}

	public class SasScript_LoopUpdate : SasScriptCommand
	{
		public SasScript_LoopUpdate(Effect effect)
			: base(SasScriptCommand.CommandType.LoopUpdate, effect)
		{
		}


	}

	public class SasScript_LoopEnd : SasScriptCommand
	{
		public SasScript_LoopEnd(Effect effect)
			: base(SasScriptCommand.CommandType.LoopEnd, effect)
		{
		}


	}

	public class SasScript_RenderColorTarget : SasScriptCommand
	{
		EffectHandle textureHandle;
		public EffectHandle TextureHandle
		{
			get { return textureHandle; }
		}

		public SasScript_RenderColorTarget(Effect effect)
			: base(SasScriptCommand.CommandType.RenderColorTarget, effect)
		{
		}

		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				if (selection == null || selection.Length == 0)
				{
					textureHandle = null;
				}
				else
				{
					EffectHandle paramHandle = effect.GetParameter(null, selection);
					if (paramHandle == null)
					{
						App.ReportError("Couldn't get color target parameter");
						textureHandle = null;
					}
					else
					{
						textureHandle = paramHandle;
					}
				}

				isDirty = false;
			}
			return true;
		}


	}

	public class SasScript_RenderDepthStencilTarget : SasScriptCommand
	{
		EffectHandle textureHandle;
		public EffectHandle TextureHandle
		{
			get { return textureHandle; }
		}

		public SasScript_RenderDepthStencilTarget(Effect effect)
			: base(SasScriptCommand.CommandType.RenderDepthStencilTarget, effect)
		{
		}

		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				if (selection == null || selection.Length == 0)
				{
					textureHandle = null;
				}
				else
				{
					EffectHandle paramHandle = effect.GetParameter(null, selection);

					if (paramHandle == null)
					{
						App.ReportError("Couldn't get depth target parameter");
						textureHandle = null;
					}
					else
					{
						textureHandle = paramHandle;
					}
				}

				isDirty = false;
			}
			return true;
		}


	}

	public class SasScript_Technique : SasScriptCommand
	{
		public SasScript_Technique(Effect effect)
			: base(SasScriptCommand.CommandType.Technique, effect)
		{
		}

		private EffectHandle techniqueHandle;

		public EffectHandle Handle
		{
			get { return techniqueHandle; }
		}

		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				techniqueHandle = null;
				for (int tech = 0; tech < effect.Description.Techniques; tech++)
				{
					EffectHandle thisTechHandle = effect.GetTechnique(tech);
					if (string.Compare(effect.GetTechniqueDescription(thisTechHandle).Name, selection, true) == 0)
					{
						techniqueHandle = thisTechHandle;
						break;
					}
				}
				if (techniqueHandle == null)
				{
					App.ReportError("Couldn't find technique");
				}
				isDirty = false;
			}
			return true;
		}
	}

	public class SasScript_Pass : SasScriptCommand
	{
		public SasScript_Pass(Effect effect)
			: base(SasScriptCommand.CommandType.Pass, effect)
		{
		}

		private int passNum;

		public int PassNum
		{
			get { return passNum; }
		}

		public override bool Update()
		{
			if (true /*isDirty*/)
			{
				string selection = EvaluateChoice();
				passNum = 0;
				int pass;
				for (pass = 0; pass < effect.GetTechniqueDescription(effect.Technique).Passes; pass++)
				{
					EffectHandle thisPassHandle = effect.GetPass(effect.Technique, pass);
					if (string.Compare(effect.GetPassDescription(thisPassHandle).Name, selection, true) == 0)
					{
						passNum = pass;
						break;
					}
				}
				if (pass == effect.GetTechniqueDescription(effect.Technique).Passes)
				{
					App.ReportError("Couldn't find pass!");
					pass = 0;
				}
				
				isDirty = false;
			}
			return true;
		}

	}

	public class SasScript_Draw : SasScriptCommand
	{
		public enum DrawType
		{
			Scene,
			Geometry,
			Buffer,
			Hint
		}
		private DrawType drawType;

		public DrawType DrawOption
		{
			get { return drawType; }
		}

		public SasScript_Draw(Effect effect)
			: base(SasScriptCommand.CommandType.Draw, effect)
		{

		}
		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				if (string.Compare(selection, "scene", true) == 0)
				{
					drawType = DrawType.Scene;
				}
				else if (string.Compare(selection, "geometry", true) == 0)
				{
					drawType = DrawType.Geometry;
				}
				else if (string.Compare(selection, "buffer", true) == 0)
				{
					drawType = DrawType.Buffer;
				}
				else
				{
					drawType = DrawType.Hint;
				}
				isDirty = false;
			}
				
			return true;
		}


	}

	public class SasScript_ScriptSignature : SasScriptCommand
	{
		public SasScript_ScriptSignature(Effect effect)
			: base(SasScriptCommand.CommandType.ScriptSignature, effect)
		{
		}
	}

	public class SasScript_ScriptExternal : SasScriptCommand
	{
		public SasScript_ScriptExternal(Effect effect)
			: base(SasScriptCommand.CommandType.ScriptExternal, effect)
		{
		}

	}

	public class SasScript_Clear : SasScriptCommand
	{
		public SasScript_Clear(Effect effect)
			: base(SasScriptCommand.CommandType.Clear, effect)
		{
		}

		public enum ClearType
		{
			Color,
			Depth,
			Stencil
		}
        private ClearType clearType = ClearType.Color;
		private int clearIndex = 0;
		public ClearType ClearOption
		{
			get { return clearType; }
		}
		public int ClearIndex
		{
			get { return clearIndex; }
		}

		public override bool Update()
		{
			if (isDirty)
			{
				int index = 0;
				string selection = EvaluateChoice(ref index);
				if (string.Compare(selection, "color", true) == 0)
				{
					clearType = ClearType.Color;
				}
				else if (string.Compare(selection, "depth", true) == 0)
				{
					clearType = ClearType.Depth;
				}
				else if (string.Compare(selection, "stencil", true) == 0)
				{
					clearType = ClearType.Stencil;
				}
				else
				{
					App.ReportError("unrecognized clear command");
				}
				isDirty = false;
			}
			return true;
		}
	}

	public class SasScript_ClearSetColor : SasScriptCommand
	{
		private Vector4 clearColor;
		public Vector4 Color 
		{
			get { return clearColor; }
		}


		public SasScript_ClearSetColor(Effect effect)
			: base(SasScriptCommand.CommandType.ClearSetColor, effect)
		{
		}

		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				EffectHandle paramHandle = effect.GetParameter(null, selection);
				
				if (paramHandle != null)
				{
					clearColor = SasEffectUtils.GetVector4FromParam(effect, paramHandle);
				}
				else
				{
					App.ReportError("Couldn't get clear color parameter");
				}
				isDirty = false;
			}
			return true;
		}

	}

	public class SasScript_ClearSetDepth : SasScriptCommand
	{
		private float clearDepth;
		public float Depth 
		{
			get { return clearDepth; }
		}

		public SasScript_ClearSetDepth(Effect effect)
			: base(SasScriptCommand.CommandType.ClearSetDepth, effect)
		{
		}

		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				EffectHandle paramHandle = effect.GetParameter(null, selection);
				if (paramHandle != null)
				{
					clearDepth = SasEffectUtils.GetFloatFromParam(effect, paramHandle);
				}
				else
				{
					App.ReportError("Couldn't get clear depth parameter");
				}
				isDirty = false;
			}
			return true;
		}
	}

	public class SasScript_ClearSetStencil : SasScriptCommand
	{
		private int clearStencil;
		public int Stencil
		{
			get { return clearStencil; }
		}

		public SasScript_ClearSetStencil(Effect effect)
			: base(SasScriptCommand.CommandType.ClearSetStencil, effect)
		{
		}
		public override bool Update()
		{
			if (isDirty)
			{
				string selection = EvaluateChoice();
				EffectHandle paramHandle = effect.GetParameter(null, selection);
				if (paramHandle != null)
				{
					clearStencil = SasEffectUtils.GetIntegerFromParam(effect, paramHandle);
				}
				else
				{
					App.ReportError("Couldn't get clear stencil parameter");
				}
				isDirty = false;
			}
			return true;
		}
	}

	public class SasScript_GeometryList : SasScriptCommand
	{
		public SasScript_GeometryList(Effect effect)
			: base(SasScriptCommand.CommandType.GeometryList, effect)
		{
		}
	}

	public class SasScript_Hint : SasScriptCommand
	{
		public SasScript_Hint(Effect effect)
			: base(SasScriptCommand.CommandType.Hint, effect)
		{
		}
	}
	
}
