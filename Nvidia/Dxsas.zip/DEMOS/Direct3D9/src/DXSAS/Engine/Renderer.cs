using System;
using System.Collections;
using System.Diagnostics;
using System.Drawing;
using Microsoft.Samples.DirectX.UtilityToolkit;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace Dxsas.Engine
{
	/// <summary>
	/// Summary description for Renderer.
	/// </summary>
	public class SasRenderer
	{
		#region Members
		VertexBuffer vertexBuffer = null;
		DeviceEventArgs deviceArgs;
		VertexDeclaration decl = null;
		private bool resetFlag = true;
		float currentTime;
		float elapsedTime;
		
		Surface backBuffer;
		Surface depthBuffer;
		private struct MousePos
		{
			public Vector2 pos;
			public double moveTime;
		}
		private struct MouseLeft
		{
			public bool down;
			public Vector2 pos;
			public double downTime;
		}
		public Microsoft.DirectX.Direct3D.Device Device
		{
			get { return deviceArgs.Device; }
		}
		public bool ResetPulse { set { resetFlag = value; } }
		MousePos mousePos;
		MouseLeft mouseLeft;

		Vector2 viewport = new Vector2();
		Vector2 targetSize = new Vector2();
		SasScriptEngine scriptEngine = new SasScriptEngine();

		public struct PositionTextureVertex
		{
			public Vector3 Position;
			public Vector3 Texture;
		};
		private class RenderTargets
		{
			public ArrayList textureTargets = new ArrayList();
			public Surface depthTarget = null;
		}
		public Vector2 CurrentTargetSize
		{
			get { return targetSize; }
		}
		private ArrayList targets = new ArrayList();

		#endregion

		#region Private Methods

		private RenderTargets CurrentRenderTargets 
		{
			get 
			{
				Debug.Assert(targets.Count != 0, "No render targets");
				return (RenderTargets)targets[targets.Count - 1]; 
			}
		}

		public unsafe bool PreEffectRender(SasScene scene, SasMaterial mat)
		{
			SasCamera cam = scene.Camera;
			Matrix Proj = cam.ProjectionMatrix;
			Matrix View =  cam.ViewMatrix;
			Matrix World = Matrix.Identity;

			Effect effect = mat.MaterialEffect;

			for(int i = 0; i < effect.Description.Parameters; i++)
			{
				EffectHandle handleParam = effect.GetParameter(null, i);
				ParameterDescription desc = effect.GetParameterDescription(handleParam);

				SasMaterial.ParameterInfo info = mat.GetParameterInfo(i);

				Matrix Ret;
				if (BuildMatrix(info, World, View, Proj, out Ret))
				{
					effect.SetValue(handleParam, Ret);
				}
				else
				{
					if (info.semanticID == SasMaterial.SemanticID.viewportpixelsize)
					{
						if (desc.Type == ParameterType.Float && desc.Columns == 2)
						{
							Vector2 pixelSize = targetSize;
							effect.SetValue(handleParam, &pixelSize, sizeof(float) * 2);
						}
					}
					else if (info.semanticID == SasMaterial.SemanticID.cameraposition)
					{
						Matrix inverseView = View;
						inverseView.Invert();
						Vector3 camPos = Vector3.TransformCoordinate(new Vector3(0.0f, 0.0f, 0.0f), inverseView);
						effect.SetValue(handleParam, &camPos, sizeof(float) * 3);
					}
					else if (info.semanticID == SasMaterial.SemanticID.time)
					{
						effect.SetValue(handleParam, (float)Microsoft.Samples.DirectX.UtilityToolkit.FrameworkTimer.GetTime());
					}
					else if (info.semanticID == SasMaterial.SemanticID.elapsedtime)
					{
						effect.SetValue(handleParam, (float)Microsoft.Samples.DirectX.UtilityToolkit.FrameworkTimer.GetElapsedTime());
					}
					else if (info.semanticID == SasMaterial.SemanticID.animationtime)
					{
						// Not currently keeping a tick count
						effect.SetValue(handleParam, 0.0f);
					}
					else if (info.semanticID == SasMaterial.SemanticID.animationtick)
					{
						// Not currently keeping a tick count
						effect.SetValue(handleParam, 0.0f);
					}
					else if (info.semanticID == SasMaterial.SemanticID.mouseposition)
					{
						Vector3 cursorData = new Vector3(mousePos.pos.X, 
							mousePos.pos.Y, (float)mousePos.moveTime);
						cursorData.X /= deviceArgs.BackBufferDescription.Width;
						cursorData.Y /= deviceArgs.BackBufferDescription.Height;
						effect.SetValue(handleParam, &cursorData, sizeof(float) * 3);
					}

					else if (info.semanticID == SasMaterial.SemanticID.leftmousedown)
					{
						Vector4 cursorData = new Vector4(mouseLeft.pos.X, 
							mouseLeft.pos.Y, mouseLeft.down ? 1.0f : 0.0f, (float)mouseLeft.downTime);
						cursorData.X /= deviceArgs.BackBufferDescription.Width;
						cursorData.Y /= deviceArgs.BackBufferDescription.Height;
						effect.SetValue(handleParam, &cursorData, sizeof(float) * 4);
					}
					else if (info.semanticID == SasMaterial.SemanticID.fxcomposer_resetpulse)
					{
						effect.SetValue(handleParam, resetFlag);

						// Dirty the commands so they update themselves with the reset pulse
						// (it may be causing code branches to change)
						mat.DirtyCommands();
					}
					else
					{
						//Debug.Write("unknown semantic: ", desc.Semantic + "\n");
					}

				}
			}

			return true;
		}

		private bool BuildMatrix(SasMaterial.ParameterInfo info, Matrix world, Matrix view, Matrix projection, out Matrix ret)
		{
			ret = new Matrix();

			if (info.semanticID == SasMaterial.SemanticID.unknown)
				return false;

			//Matrix builtMatrix;
			if (info.semanticID == SasMaterial.SemanticID.world)
			{
				ret = world;
				
			}
			else if (info.semanticID == SasMaterial.SemanticID.view)
			{
				ret = view;
				
			}
			else if (info.semanticID == SasMaterial.SemanticID.projection)
			{
				ret = projection;
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldtranspose)
			{
				ret = world;
				ret.Transpose(ret);
				
			}
			else if (info.semanticID == SasMaterial.SemanticID.viewtranspose)
			{
				ret = view;
				ret.Transpose(ret);				
			}
			else if (info.semanticID == SasMaterial.SemanticID.projectiontranspose)
			{
				ret = projection;
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldview)
			{
				ret = world * view;
				
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldviewprojection)
			{
				ret = world * view * projection;
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldinverse)
			{
				ret = world;
				ret.Invert();
			}
			else if (info.semanticID == SasMaterial.SemanticID.viewinverse)
			{
				ret = view;
				ret.Invert();
			}
			else if (info.semanticID == SasMaterial.SemanticID.projectioninverse)
			{
				ret = projection;
				ret.Invert();
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldinversetranspose)
			{
				ret = world;
				ret.Invert();
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.viewinversetranspose)
			{
				ret = view;
				ret.Invert();
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.projectioninversetranspose)
			{
				ret = projection;
				ret.Invert();
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldviewinverse)
			{
				ret = world * view;
				ret.Invert();
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldviewtranspose)
			{
				ret = world * view;
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldviewinversetranspose)
			{
				ret = world * view;
				ret.Invert();
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldviewprojectioninverse)
			{
				ret = world * view * projection;
				ret.Invert();
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldviewprojectiontranspose)
			{
				ret = world * view * projection;
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.worldviewprojectioninversetranspose)
			{
				ret = world * view * projection;
				ret.Invert();
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.viewprojection)
			{
				ret = view * projection;
			}
			else if (info.semanticID == SasMaterial.SemanticID.viewprojectiontranspose)
			{
				ret = view * projection;
				ret.Transpose(ret);
			}
			else if (info.semanticID == SasMaterial.SemanticID.viewprojectioninverse)
			{
				ret = view * projection;
				ret.Invert();
			}
			else if (info.semanticID == SasMaterial.SemanticID.viewprojectioninversetranspose)
			{
				ret = view * projection;
				ret.Invert();
				ret.Transpose(ret);
			}
			else
			{
				
				return false;
			}
			return true;
		}
		#endregion
		#region Renderer Members

		public Vector2 Viewport
		{
			get
			{
				return viewport;
			}
			set
			{
				viewport = value;
			}
		}

		public void SetTime(float Time)
		{
			currentTime = Time;
		}
		public void SetElapsedTime(float Elapsed)
		{
			elapsedTime = Elapsed;
		}
		public void OnMouseLeftDown(bool Down)
		{
			mouseLeft.down = Down;
			mouseLeft.pos = mousePos.pos;
			mouseLeft.downTime = Microsoft.Samples.DirectX.UtilityToolkit.FrameworkTimer.GetTime();
		}
		public void OnMouseMove(float x, float y)
		{
			mousePos.pos = new Vector2(x, y);
			mousePos.moveTime = Microsoft.Samples.DirectX.UtilityToolkit.FrameworkTimer.GetTime();
		}

		public bool OnDestroyDevice()
		{
			OnLostDevice();
			return false;
		}

		public bool OnCreateDevice(DeviceEventArgs e)
		{
			deviceArgs = e;
			viewport = new Vector2(e.BackBufferDescription.Width, e.BackBufferDescription.Height);
			targetSize = new Vector2(viewport.X, viewport.Y);

			VertexElement[] elements = new VertexElement[]
			{	
				new VertexElement(0, 0, DeclarationType.Float3,
				DeclarationMethod.Default,
				DeclarationUsage.Position, 0),
			                            
				new VertexElement(0, 12, DeclarationType.Float3,
				DeclarationMethod.Default,
				DeclarationUsage.TextureCoordinate, 0),
			                            
            
				VertexElement.VertexDeclarationEnd 
			};

			// Use the vertex element array to create a vertex declaration.
			decl = new VertexDeclaration(e.Device, elements);
		
			return false;
		}

		public void PushTargets()
		{
			targets.Add(new RenderTargets());
		
			CurrentRenderTargets.textureTargets = (ArrayList)((RenderTargets)targets[targets.Count - 2]).textureTargets.Clone();
			CurrentRenderTargets.depthTarget = ((RenderTargets)targets[targets.Count - 2]).depthTarget;
			
		}
		public void PopTargets()
		{
			if (targets.Count > 1)
			{
				targets.RemoveAt(targets.Count - 1);
				for(int i = 0; i < CurrentRenderTargets.textureTargets.Count; i++)
				{
					SetColorTarget(i, (SasTexture)(CurrentRenderTargets.textureTargets[i]));
				}
				SetDepthTarget(CurrentRenderTargets.depthTarget);
			}
			else
			{
				Debug.Assert(false, "popped targets, but no targets to pop");
			}
		}
		public bool OnResetDevice(DeviceEventArgs e)
		{
			deviceArgs = e;
			viewport = new Vector2(e.BackBufferDescription.Width, e.BackBufferDescription.Height);
			targetSize = new Vector2(viewport.X, viewport.Y);

			backBuffer = e.Device.GetBackBuffer(0, 0, BackBufferType.Mono);
			depthBuffer = e.Device.DepthStencilSurface;

			targets.Add(new RenderTargets());
			for (int i = 0; i < e.Device.DeviceCaps.NumberSimultaneousRts; i++)
			{
				CurrentRenderTargets.textureTargets.Add(null);
			}

			// Create a VB for the vertices we'll draw.
			vertexBuffer = new VertexBuffer(typeof(PositionTextureVertex), 10, e.Device, Usage.WriteOnly, CustomVertex.PositionTextured.Format, Pool.Default);

			resetFlag = true;
			return false;
		}

		public bool OnLostDevice()
		{
			// Make sure we're in the default state - don't want to be
			// referencing textures that are being disposed
            ResetTargets();

			if (backBuffer != null)
			{
				backBuffer.Dispose();
				backBuffer = null;
			}
			
			if (depthBuffer != null)
			{
				depthBuffer.Dispose();
				depthBuffer = null;
			}
			if (vertexBuffer != null)
			{
				vertexBuffer.Dispose();
				vertexBuffer = null;
			}
			
			return false;
		}

		public bool ClearColor(Vector4 colorVec)
		{
			ColorValue val = new ColorValue(colorVec.X, colorVec.Y, colorVec.Z, colorVec.W);
			deviceArgs.Device.Clear(ClearFlags.Target, val.ToArgb(), 0.0f, 0);
			return true;
		}
		public bool ClearDepth(float depth)
		{
			if (CurrentRenderTargets.depthTarget != null || depthBuffer != null)
			{
				deviceArgs.Device.Clear(ClearFlags.ZBuffer, 0, depth, 0);
			}
			else
			{
				App.ReportError("No depth!");
			}
			return true;
		}
		public bool ClearStencil(int stencil)
		{
			deviceArgs.Device.Clear(ClearFlags.Stencil, 0, 0.0f, stencil);
			return true;
		}

		public bool ResetTargets()
		{
			// If there's no back/z, then we're not in a good state.
			if (backBuffer == null ||
				depthBuffer == null)
				return true;

			// Reset the targets for the new scene
			CurrentRenderTargets.depthTarget = null;
			for(int i = 0; i < CurrentRenderTargets.textureTargets.Count; i++)
			{
				CurrentRenderTargets.textureTargets[i] = null;
				if (i != 0)
				{
					deviceArgs.Device.SetRenderTarget(i, null);
				}
			}

            deviceArgs.Device.SetRenderTarget(0, backBuffer);
            deviceArgs.Device.DepthStencilSurface = depthBuffer;

			return true;

		}

		public bool SetColorTarget(int index, SasTexture texture)
		{
			if (index >= CurrentRenderTargets.textureTargets.Count)
			{
				App.ReportError("Invalid rendertarget index for this device");
				return false;
			}

			if (texture == null)
			{
				if (targets.Count > 1)
				{
					for (int i = targets.Count - 2; i >= 0; i--)
					{
						if (((RenderTargets)targets[i]).textureTargets[index] != null)
						{
							texture = (SasTexture)(((RenderTargets)targets[i]).textureTargets[index]);
							break;
						}
					}
				}
			}

			if (texture == null)
			{
				if (index == 0)
				{
					Debug.Assert(backBuffer != null);
					deviceArgs.Device.SetRenderTarget(index, backBuffer);
					targetSize.X = backBuffer.Description.Width;
					targetSize.Y = backBuffer.Description.Height;
					CurrentRenderTargets.textureTargets[index] = null;
				}
				else
				{
					deviceArgs.Device.SetRenderTarget(index, null);
					CurrentRenderTargets.textureTargets[index] = null;
				}
			}
			else
			{
				using (Surface surf = ((Texture)texture.DeviceTexture).GetSurfaceLevel(0))
				{
					deviceArgs.Device.SetRenderTarget(index, surf);
					if (index == 0)
					{
						targetSize.X = surf.Description.Width;
						targetSize.Y = surf.Description.Height;
					}
				}
				CurrentRenderTargets.textureTargets[index] = texture;
			}
			
			return true;
		}

		public bool PreScene()
		{
			return true;
		}

		public bool PostScene()
		{
			resetFlag = false;
			return true;
		}
		public bool SetDepthTarget(Surface depth)
		{
			if (depth == null)
			{
				if (targets.Count > 1)
				{
					for (int i = targets.Count - 2; i >= 0; i--)
					{
						if (((RenderTargets)targets[i]).depthTarget != null)
						{
							depth = ((RenderTargets)targets[i]).depthTarget;
							break;
						}
					}
				}
			}

			if (depth == null)
			{
				// Not found, set default
				deviceArgs.Device.DepthStencilSurface = depthBuffer;
				CurrentRenderTargets.depthTarget = null;
			}
			else
			{
				deviceArgs.Device.DepthStencilSurface = depth;
				CurrentRenderTargets.depthTarget = depth;
			}

			return true;
		}
	
		public bool Execute(SasScene scene, out bool SceneUsedModel)
		{
			// Fixed function - could be cleverer about when this needs calling.
			deviceArgs.Device.SetTransform(TransformType.World, Matrix.Identity);// scene.GetCamera().WorldMatrix);
			deviceArgs.Device.SetTransform(TransformType.View, scene.Camera.ViewMatrix);
			deviceArgs.Device.SetTransform(TransformType.Projection, scene.Camera.ProjectionMatrix);

			scriptEngine.Run(scene, this);

			SceneUsedModel = scriptEngine.ModelDrawn;
			
				
			return true;
		}

		public bool DrawQuad()
		{
			return DrawQuad(new System.Drawing.Rectangle(0, 0, (int)targetSize.X, (int)targetSize.Y),
				new System.Drawing.Rectangle(0, 0, 1, 1));
		}

		public bool DrawQuad(System.Drawing.Rectangle rect, System.Drawing.Rectangle tex)
		{
			PositionTextureVertex[] verts = new PositionTextureVertex[6];

			// 2 Tri's, to form a quad.
			verts[0].Position = new Vector3(rect.X, rect.Y, 0.9f);
			verts[0].Texture = new Vector3(tex.X, tex.Y, 1.0f);

			verts[1].Position = new Vector3(rect.Width, rect.Height, 0.9f);
			verts[1].Texture = new Vector3(tex.Width, tex.Height, 1.0f);

			verts[2].Position = new Vector3(rect.X, rect.Height, 0.9f);
			verts[2].Texture = new Vector3(tex.X, tex.Height, 0.9f);

			verts[3].Position = new Vector3(rect.X, rect.Y, 0.9f);
			verts[3].Texture = new Vector3(tex.X, tex.Y, 1.0f);

			verts[4].Position = new Vector3(rect.Width, rect.Y, 0.9f);
			verts[4].Texture = new Vector3(tex.Width, tex.Y, 1.0f);

			verts[5].Position = new Vector3(rect.Width, rect.Height, 0.9f);
			verts[5].Texture = new Vector3(tex.Width, tex.Height, 1.0f);

		
			// Copy the vertices to the VB, and convert them to screenspace, since the ScriptExecute command
			// Draw=buffer expects them that way.
			PositionTextureVertex[] bufferVerts = (PositionTextureVertex[])vertexBuffer.Lock(0,0);
			for (int num = 0; num < 6; num++)
			{
				verts[num].Position.X /= targetSize.X;
				verts[num].Position.Y /= targetSize.Y;
				verts[num].Position.Y = 1.0f - verts[num].Position.Y;
				verts[num].Position.X -= .5f;
				verts[num].Position.Y -= .5f;
				verts[num].Position.X *= 2.0f;
				verts[num].Position.Y *= 2.0f;

				bufferVerts[num] = verts[num];
			}
			vertexBuffer.Unlock();

			deviceArgs.Device.SetStreamSource(0, vertexBuffer, 0);
			deviceArgs.Device.VertexDeclaration = decl;
			deviceArgs.Device.DrawPrimitives(PrimitiveType.TriangleList, 0, 2);
	
			return true;
		}

		#endregion

		

	}
}
