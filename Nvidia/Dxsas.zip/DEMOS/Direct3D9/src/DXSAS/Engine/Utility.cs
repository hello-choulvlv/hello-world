using System;
using System.Diagnostics;
using Microsoft.Samples.DirectX.UtilityToolkit;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX;

namespace Dxsas.Engine
{
	/// <summary>
	/// Summary description for Utility.
	/// </summary>
	public class SasEffectUtils
	{
		public static bool FindAnnotationString(Effect effect, EffectHandle parameterHandle, string name, ref string ret)
		{
			ParameterDescription paramDesc = effect.GetParameterDescription(parameterHandle);
			for(int i = 0; i < paramDesc.Annotations; i++)
			{
				EffectHandle annotationHandle = effect.GetAnnotation(parameterHandle, i);
				if (annotationHandle != null)
				{
					ParameterDescription annotationDesc = effect.GetParameterDescription(annotationHandle);
					if (annotationDesc.Type == ParameterType.String &&
						string.Compare(annotationDesc.Name, name, true) == 0)
					{
						ret = effect.GetValueString(annotationHandle);
						return true;
					}
				}
			}
			return false;
		}
		public static bool FindTechniqueAnnotationString(Effect effect, EffectHandle parameterHandle, string name, ref string ret)
		{
			TechniqueDescription paramDesc = effect.GetTechniqueDescription(parameterHandle);
			for(int i = 0; i < paramDesc.Annotations; i++)
			{
				EffectHandle annotationHandle = effect.GetAnnotation(parameterHandle, i);
				if (annotationHandle != null)
				{
					ParameterDescription annotationDesc = effect.GetParameterDescription(annotationHandle);
					if (annotationDesc.Type == ParameterType.String &&
						string.Compare(annotationDesc.Name, name, true) == 0)
					{
						ret = effect.GetValueString(annotationHandle);
						return true;
					}
				}
			}
			return false;
		}
		public static bool FindPassAnnotationString(Effect effect, EffectHandle parameterHandle, string name, ref string ret)
		{
			PassDescription paramDesc = effect.GetPassDescription(parameterHandle);
			for(int i = 0; i < paramDesc.Annotations; i++)
			{
				EffectHandle annotationHandle = effect.GetAnnotation(parameterHandle, i);
				if (annotationHandle != null)
				{
					ParameterDescription annotationDesc = effect.GetParameterDescription(annotationHandle);
					if (annotationDesc.Type == ParameterType.String &&
						string.Compare(annotationDesc.Name, name, true) == 0)
					{
						ret = effect.GetValueString(annotationHandle);
						return true;
					}
				}
			}
			return false;
		}

		public static bool FindAnnotationValue(Effect effect, EffectHandle parameterHandle, string name, ref float ret)
		{
			ParameterDescription paramDesc = effect.GetParameterDescription(parameterHandle);
			for(int i = 0; i < paramDesc.Annotations; i++)
			{
				EffectHandle annotationHandle = effect.GetAnnotation(parameterHandle, i);
				if (annotationHandle != null)
				{
					ParameterDescription annotationDesc = effect.GetParameterDescription(annotationHandle);
					if (string.Compare(annotationDesc.Name, name, true) == 0)
					{
						try
						{
							switch(annotationDesc.Type)
							{
								case ParameterType.String:
								{
									ret = float.Parse(effect.GetValueString(annotationHandle));
									return true;
								}
								
								case ParameterType.Integer:
								{
									ret = effect.GetValueInteger(annotationHandle);
									return true;
								}
								
								case ParameterType.Float:
								{
									ret = effect.GetValueFloat(annotationHandle);
									return true;
								}
								
								case ParameterType.Boolean:
								{
									ret = effect.GetValueBoolean(annotationHandle) ? 1.0f : 0.0f;
									return true;
								}
								
								default:
								{
									return false;
								}
							}
						}
						catch
						{
							ret = 0.0f;
							return false;
						}
						
					}
				}
			}
			ret = 0.0f;
			return false;
		}

		public static bool FindAnnotationValue(Effect effect, EffectHandle parameterHandle, string name, ref Vector4 ret)
		{
			ParameterDescription paramDesc = effect.GetParameterDescription(parameterHandle);
			for(int i = 0; i < paramDesc.Annotations; i++)
			{
				EffectHandle annotationHandle = effect.GetAnnotation(parameterHandle, i);
				if (annotationHandle != null)
				{
					ParameterDescription annotationDesc = effect.GetParameterDescription(annotationHandle);
					if (string.Compare(annotationDesc.Name, name, true) == 0)
					{
						try
						{
							switch(annotationDesc.Type)
							{
								case ParameterType.Float:
								{
									ret.W = ret.X = ret.Y = ret.Z = 0.0f;
									float[] value = effect.GetValueFloatArray(annotationHandle, annotationDesc.Columns);
									switch(annotationDesc.Columns)
									{
										default:
											break;
										case 1:
											ret.X = ret.Y = ret.Z = ret.W = value[0];
											break;
										case 2:
											ret.X = value[0];
											ret.Y = value[1];
											break;
										case 3:
											ret.X = value[0];
											ret.Y = value[1];
											ret.Z = value[2];
											break;
										case 4:
											ret.X = value[0];
											ret.Y = value[1];
											ret.Z = value[2];
											ret.W = value[3];
											break;
									}


								
									return true;
								}
								
								default:
								{
									return false;
								}
							}
						}
						catch
						{
							ret = new Vector4(0.0f, 0.0f, 0.0f, 0.0f);
							return false;
						}
						
					}
				}
			}
			ret = new Vector4(0.0f, 0.0f, 0.0f, 0.0f);
			return false;
		}

		public static int GetIntegerFromParam(Effect effect, EffectHandle handle)
		{
			ParameterDescription desc = effect.GetParameterDescription(handle);
			switch(desc.Type)
			{
				case ParameterType.Boolean:
				{
					bool bValue = effect.GetValueBoolean(handle);
					return (bValue ? 1 : 0);
				}
				case ParameterType.Integer:
				{
					return effect.GetValueInteger(handle);
				}
				case ParameterType.Float:
				{
					return (int)effect.GetValueFloat(handle);
				}
				default:
				{
					App.ReportError("Can't convert value to integer: " + desc.Name);
				}
				break;
			}
			return 0;
		}
		public static void SetIntegerParam(Effect effect, EffectHandle handle, int Value)
		{
			ParameterDescription desc = effect.GetParameterDescription(handle);
			switch(desc.Type)
			{
				case ParameterType.Boolean:
				{
					effect.SetValue(handle, (Value != 0) ? true : false);
				}
				break;
				case ParameterType.Integer:
				{
					effect.SetValue(handle, Value);
				}
				break;
				case ParameterType.Float:
				{
					effect.SetValue(handle, (float)Value);
				}
				break;
				default:
				{
					App.ReportError("Can't convert value to integer: " + desc.Name);
				}
				break;
			}
		}
		public static float GetFloatFromParam(Effect effect, EffectHandle handle)
		{
			ParameterDescription desc = effect.GetParameterDescription(handle);
			switch(desc.Type)
			{
				case ParameterType.Boolean:
				{
					bool bValue = effect.GetValueBoolean(handle);
					return (bValue ? 1.0f : 0.0f);
				}
				case ParameterType.Integer:
				{
					return (float)effect.GetValueInteger(handle);
				}
				case ParameterType.Float:
				{
					return effect.GetValueFloat(handle);
				}
				default:
				{
					App.ReportError("Can't convert value to float: " + desc.Name);
				}
				break;
			}
			return 0.0f;
		}
		public static Vector4 GetVector4FromParam(Effect effect, EffectHandle handle)
		{
			Vector4 ret = new Vector4(0.0f, 0.0f, 0.0f, 0.0f);
			ParameterDescription desc = effect.GetParameterDescription(handle);
			switch(desc.Type)
			{
				case ParameterType.Boolean:
				{
					bool bValue = effect.GetValueBoolean(handle);
					ret.X = ret.Y = ret.Z = ret.W = (bValue ? 1.0f : 0.0f);
				}
				break;
				case ParameterType.Integer:
				{
					float fValue = (float)effect.GetValueInteger(handle);
					ret.X = ret.Y = ret.Z = ret.W = fValue;
				}
				break;
				case ParameterType.Float:
				{
					float[] value = effect.GetValueFloatArray(handle, desc.Columns);
					switch(desc.Columns)
					{
						default:
							break;
						case 1:
							ret.X = ret.Y = ret.Z = ret.W = value[0];
							break;
						case 2:
							ret.X = value[0];
							ret.Y = value[1];
							break;
						case 3:
							ret.X = value[0];
							ret.Y = value[1];
							ret.Z = value[2];
							break;
						case 4:
							ret.X = value[0];
							ret.Y = value[1];
							ret.Z = value[2];
							ret.W = value[3];
							break;
					}
				}
				break;
				default:
				{
					App.ReportError("Can't convert value to vector4: " + desc.Name);
				}
				break;
			}
			return ret;
		}
	}

    public class SasIncluder : Microsoft.DirectX.Direct3D.Include
	{
		public override System.IO.Stream Open(IncludeType includeType, string filename)
		{
			string foundPath = Utility.FindMediaFile(System.IO.Path.GetFileName(filename));
			if (foundPath == null || foundPath.Length == 0)
				return null;

			System.IO.FileStream stream = new System.IO.FileStream(foundPath, System.IO.FileMode.Open, System.IO.FileAccess.Read);
			return stream;
		}
	}

}
