using System;
using System.Diagnostics;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX;
using Microsoft.Samples.DirectX.UtilityToolkit;


namespace Dxsas.Engine
{
	/// <summary>
	/// Summary description for Camera.
	/// </summary>
	public class SasCamera
	{
		public enum Mode
		{
			Rotate,
			Dolly,
			Pan
		}

		/// <summary>
		/// Used to map keys to the camera
		/// </summary>
		public enum CameraKeys : byte
		{
			StrafeLeft,
			StrafeRight,
			MoveForward,
			MoveBackward,
			MoveUp,
			MoveDown,
			Reset,
			ControlDown,
			MaxKeys,
			Unknown=0xff
		}

		/// <summary>
		/// Mouse button mask values
		/// </summary>
		[Flags]
		public enum MouseButtonMask : byte
		{
			None = 0,
			Left = 0x01,
			Middle = 0x02,
			Right = 0x04,
			Wheel = 0x08,
		}



		private int width = 0;
		private int height = 0;
		protected Vector3 defaultPosition = new Vector3(0.0f, 0.0f, -1.0f);		// Default camera eye position
		protected Vector3 defaultLookDirection = new Vector3(0.0f, 0.0f, 1.0f);	// Default Look direction
		private Vector3 position;
		private Vector3 upDirection = new Vector3(0.0f, 1.0f, 0.0f);
		private Vector3 lookDirection;
		private Vector2 depthRange = new Vector2(0.0f, 1.0f);
		protected float aspectRatio = 1.0f;
		private float focalLength = 1.0f;
		private float fov = 80.0f;
		
		private Quaternion rotation = new Quaternion();
		private Mode mode = Mode.Rotate;
        
		public Vector3 Position { get { return position; } }
		public Vector3 DefaultPosition { set { defaultPosition = value; } get { return defaultPosition; }}
		public Vector3 DefaultDirection { set { defaultLookDirection = value; } get { return defaultLookDirection; }}
		public Mode CameraMode { get { return mode; } set { mode = value; } }
		public Matrix ViewMatrix { get { return viewMatrix; } }
		public Matrix ProjectionMatrix { get { return projMatrix; } }
		public float FieldOfView { get { return fov; } set { fov = value; } }
		public float FocalLength { get { return focalLength; } set { focalLength = value; } }
		public Vector2 DepthRange { get { return depthRange; } set { depthRange = value; } } 

		#region Instance Data
		protected Matrix viewMatrix; // View Matrix
		protected Matrix projMatrix; // Projection matrix

		protected System.Drawing.Point lastMousePosition;  // Last absolute position of mouse cursor
		protected bool isMouseLButtonDown;    // True if left button is down 
		protected bool isMouseMButtonDown;    // True if middle button is down 
		protected bool isMouseRButtonDown;    // True if right button is down 
		protected int currentButtonMask;   // mask of which buttons are down
		protected Vector2 mouseDelta;          // Mouse relative delta smoothed over a few frames
		protected float framesToSmoothMouseData; // Number of frames to smooth mouse data over


		protected Vector3 velocity;            // Velocity of camera
		protected bool isMovementDrag;        // If true, then camera movement will slow to a stop otherwise movement is instant
		protected Vector3 velocityDrag;        // Velocity drag force
		protected float dragTimer;           // Countdown timer to apply drag
		protected float totalDragTimeToZero; // Time it takes for velocity to go from full to 0
		protected Vector2 rotationVelocity;         // Velocity of camera

		protected float rotationScaler;      // Scaler for rotation
		protected float moveScaler;          // Scaler for movement

		// State of the input
		protected bool[] keys;
		public static readonly Vector3 UpDirection = new Vector3(0,1,0);
		#endregion

		public SasCamera()
		{
			// Create the keys
			keys = new bool[(int)CameraKeys.MaxKeys];

			// Store mouse information
			lastMousePosition = System.Windows.Forms.Cursor.Position;
			isMouseLButtonDown = false;
			isMouseRButtonDown = false;
			isMouseMButtonDown = false;

			velocity = Vector3.Empty;
			isMovementDrag = false;
			velocityDrag = Vector3.Empty;
			dragTimer = 0.0f;
			totalDragTimeToZero = 0.25f;
			rotationVelocity = Vector2.Empty;
			rotationScaler = 0.5f;
			moveScaler = 5.0f;
			mouseDelta = Vector2.Empty;
			framesToSmoothMouseData = 2.0f;
			Reset();
		}

		protected static CameraKeys MapKey(IntPtr param)
		{
			System.Windows.Forms.Keys key = (System.Windows.Forms.Keys)param.ToInt32();
			switch(key)
			{
				case System.Windows.Forms.Keys.ControlKey: return CameraKeys.ControlDown;
				case System.Windows.Forms.Keys.Left: return CameraKeys.StrafeLeft;
				case System.Windows.Forms.Keys.Right: return CameraKeys.StrafeRight;
				case System.Windows.Forms.Keys.Up: return CameraKeys.MoveForward;
				case System.Windows.Forms.Keys.Down: return CameraKeys.MoveBackward;
				case System.Windows.Forms.Keys.Prior: return CameraKeys.MoveUp; // pgup
				case System.Windows.Forms.Keys.Next: return CameraKeys.MoveDown; // pgdn

				case System.Windows.Forms.Keys.A: return CameraKeys.StrafeLeft;
				case System.Windows.Forms.Keys.D: return CameraKeys.StrafeRight;
				case System.Windows.Forms.Keys.W: return CameraKeys.MoveForward;
				case System.Windows.Forms.Keys.S: return CameraKeys.MoveBackward;
				case System.Windows.Forms.Keys.Q: return CameraKeys.MoveUp; 
				case System.Windows.Forms.Keys.E: return CameraKeys.MoveDown; 

				case System.Windows.Forms.Keys.NumPad4: return CameraKeys.StrafeLeft;
				case System.Windows.Forms.Keys.NumPad6: return CameraKeys.StrafeRight;
				case System.Windows.Forms.Keys.NumPad8: return CameraKeys.MoveForward;
				case System.Windows.Forms.Keys.NumPad2: return CameraKeys.MoveBackward;
				case System.Windows.Forms.Keys.NumPad9: return CameraKeys.MoveUp; 
				case System.Windows.Forms.Keys.NumPad3: return CameraKeys.MoveDown; 

				case System.Windows.Forms.Keys.Home: return CameraKeys.Reset; 
			}
			// No idea
			return (CameraKeys)byte.MaxValue;
		}

		public void SetWindow(int width, int height)
		{
			this.width = width;
			this.height = height;

		}
		/// <summary>
		/// Update the view matrix based on user input & elapsed time
		/// </summary>
		public void Update(SasScene scene, float elapsedTime)
		{
			Vector3 lookAt = position + (focalLength * lookDirection);
			
			// Work out mouse changes.
			if (currentButtonMask != 0)
			{
				UpdateMouseDelta(elapsedTime);
			}

			// Get amount of velocity based on the keyboard input and drag (if any)
			UpdateVelocity(elapsedTime);

			// Simple euler method to calculate position delta
			Vector3 posDelta = velocity * elapsedTime;

			if (mouseDelta.LengthSq() != 0.0f)
			{
				if (isMouseLButtonDown)
				{
					// Move camera to origin of look point.
					Vector3 origin = position - lookAt;

					// Here we are rotating the camera about the focal point.
					Quaternion qtRotate = Quaternion.RotationAxis(new Vector3(0.0f, 1.0f, 0.0f), mouseDelta.X * .01f);
					Matrix rotateCamera = new Matrix();
					rotateCamera.RotateQuaternion(rotation);

					Vector3 vectorAxis = new Vector3(1.0f, 0.0f, 0.0f);
					vectorAxis.TransformNormal(rotateCamera);

					Quaternion qtRotateX = Quaternion.RotationAxis(vectorAxis, mouseDelta.Y * .01f);
					qtRotate = qtRotateX * qtRotate;
					qtRotate.Normalize();
					
					rotateCamera.RotateQuaternion(qtRotate);

					origin.TransformCoordinate(rotateCamera);

					// translate back to original position
					origin += lookAt;

					position = origin;

					rotation = rotation * qtRotate;
					rotation.Normalize();
					
					lookDirection.TransformNormal(rotateCamera);
					upDirection.TransformNormal(rotateCamera);

					// Recalculate
					lookAt = position + (focalLength * lookDirection);
				}
				else
				{
					// Move camera to origin of look point.
					Vector3 oldPosition = position;
					float oldFocal = focalLength;

					position -= (lookDirection * (mouseDelta.Y * scene.SceneRadius * .1f));
					Vector3 Focal = position - lookAt;
					focalLength = Focal.Length();

					// Don't let us go through 0.
					if (Focal.Z >= 0.0f)
					{
						focalLength = oldFocal;
						position = oldPosition;
					}
					
					
					/*
					Vector3 origin = position - lookAt;

					// Here we are rotating the camera about the focal point.
					Quaternion qtRotate = Quaternion.RotationAxis(new Vector3(0.0f, 1.0f, 0.0f), mouseDelta.X * .01f);
					Matrix rotateCamera = new Matrix();
					rotateCamera.RotateQuaternion(rotation);

					Vector3 vectorAxis = new Vector3(1.0f, 0.0f, 0.0f);
					vectorAxis.TransformNormal(rotateCamera);

					Quaternion qtRotateX = Quaternion.RotationAxis(vectorAxis, mouseDelta.Y * .01f);
					qtRotate = qtRotateX * qtRotate;
					qtRotate.Normalize();
					
					rotateCamera.RotateQuaternion(qtRotate);

					origin.TransformCoordinate(rotateCamera);

					// translate back to original position
					origin += lookAt;

					position = origin;

					rotation = rotation * qtRotate;
					rotation.Normalize();
					
					lookDirection.TransformNormal(rotateCamera);
					upDirection.TransformNormal(rotateCamera);

					// Recalculate
					lookAt = position + (focalLength * lookDirection);
					*/

				}
			}

			ComputeDepthRange(scene.SceneCenter, scene.SceneRadius );

			viewMatrix = Matrix.LookAtLH(position, lookAt, upDirection);
			projMatrix = Matrix.PerspectiveFovLH(fov, (float)width / (float)height, depthRange.X, depthRange.Y);
			mouseDelta.X = 0.0f;
			mouseDelta.Y = 0.0f;

		}

		public void Reset()
		{
			position = defaultPosition;
			lookDirection = defaultLookDirection;
			rotation = Quaternion.Identity;
			upDirection = new Vector3(0.0f, 1.0f, 0.0f);
		}

		/// <summary>
		/// Call this from your message proc so this class can handle window messages
		/// </summary>
		public bool HandleMessages(IntPtr hWnd, NativeMethods.WindowMessage msg, IntPtr wParam, IntPtr lParam)
		{
			switch(msg)
			{
					// Handle the keyboard
				case NativeMethods.WindowMessage.KeyDown:
					CameraKeys mappedKeyDown = MapKey(wParam);
					if (mappedKeyDown != (CameraKeys)byte.MaxValue)
					{
						// Valid key was pressed, mark it as 'down'
						keys[(int)mappedKeyDown] = true;
					}
					break;
				case NativeMethods.WindowMessage.KeyUp:
					CameraKeys mappedKeyUp = MapKey(wParam);
					if (mappedKeyUp != (CameraKeys)byte.MaxValue)
					{
						// Valid key was let go, mark it as 'up'
						keys[(int)mappedKeyUp] = false;
					}
					break;

					// Handle the mouse
				case NativeMethods.WindowMessage.LeftButtonDoubleClick:
				case NativeMethods.WindowMessage.LeftButtonDown:
				case NativeMethods.WindowMessage.RightButtonDoubleClick:
				case NativeMethods.WindowMessage.RightButtonDown:
				case NativeMethods.WindowMessage.MiddleButtonDoubleClick:
				case NativeMethods.WindowMessage.MiddleButtonDown:
				{
					// Compute the drag rectangle in screen coord.
					System.Drawing.Point cursor = new System.Drawing.Point(
						NativeMethods.LoWord((uint)lParam.ToInt32()),
						NativeMethods.HiWord((uint)lParam.ToInt32()));

					// Update the variable state
					if ( ((msg == NativeMethods.WindowMessage.LeftButtonDown) ||
						(msg == NativeMethods.WindowMessage.LeftButtonDoubleClick) )
						)
					{
						isMouseLButtonDown = true; currentButtonMask |= (int)MouseButtonMask.Left;
					}
					if ( ((msg == NativeMethods.WindowMessage.MiddleButtonDown) ||
						(msg == NativeMethods.WindowMessage.MiddleButtonDoubleClick) )
						)
					{
						isMouseMButtonDown = true; currentButtonMask |= (int)MouseButtonMask.Middle;
					}
					if ( ((msg == NativeMethods.WindowMessage.RightButtonDown) ||
						(msg == NativeMethods.WindowMessage.RightButtonDoubleClick) )
						)
					{
						isMouseRButtonDown = true; currentButtonMask |= (int)MouseButtonMask.Right;
					}

					// Capture the mouse, so if the mouse button is 
					// released outside the window, we'll get the button up messages
					NativeMethods.SetCapture(hWnd);

					lastMousePosition = System.Windows.Forms.Cursor.Position;
					return true;
				}
				case NativeMethods.WindowMessage.LeftButtonUp:
				case NativeMethods.WindowMessage.RightButtonUp:
				case NativeMethods.WindowMessage.MiddleButtonUp:
				{
					// Update member var state
					if (msg == NativeMethods.WindowMessage.LeftButtonUp) { isMouseLButtonDown = false; currentButtonMask &= ~(int)MouseButtonMask.Left; }
					if (msg == NativeMethods.WindowMessage.RightButtonUp) { isMouseRButtonDown = false; currentButtonMask &= ~(int)MouseButtonMask.Right; }
					if (msg == NativeMethods.WindowMessage.MiddleButtonUp) { isMouseMButtonDown = false; currentButtonMask &= ~(int)MouseButtonMask.Middle; }

					// Release the capture if no mouse buttons are down
					if (!isMouseLButtonDown && !isMouseMButtonDown && !isMouseRButtonDown)
					{
						NativeMethods.ReleaseCapture();
					}
				}
				break;
			}
			return true;
		}

		/// <summary>
		/// Figure out the velocity based on keyboard input & drag if any
		/// </summary>
		protected void UpdateVelocity(float elapsedTime)
		{
			Vector3 accel = Vector3.Empty;

			// Update acceleration vector based on keyboard state
			if (keys[(int)CameraKeys.MoveForward])
				accel.Z += 1.0f;
			if (keys[(int)CameraKeys.MoveBackward])
				accel.Z -= 1.0f;
			if (keys[(int)CameraKeys.MoveUp])
				accel.Y += 1.0f;
			if (keys[(int)CameraKeys.MoveDown])
				accel.Y -= 1.0f;

			if (keys[(int)CameraKeys.StrafeRight])
				accel.X += 1.0f;
			if (keys[(int)CameraKeys.StrafeLeft])
				accel.X -= 1.0f;
			// Normalize vector so if moving 2 dirs (left & forward), 
			// the camera doesn't move faster than if moving in 1 dir
			accel.Normalize();
			// Scale the acceleration vector
			accel *= moveScaler;

			if (isMovementDrag)
			{
				// Is there any acceleration this frame?
				if (accel.LengthSq() > 0)
				{
					// If so, then this means the user has pressed a movement key
					// so change the velocity immediately to acceleration 
					// upon keyboard input.  This isn't normal physics
					// but it will give a quick response to keyboard input
					velocity = accel;
					dragTimer = totalDragTimeToZero;
					velocityDrag = accel * (1 / dragTimer);
				}
				else
				{
					// If no key being pressed, then slowly decrease velocity to 0
					if (dragTimer > 0)
					{
						velocity -= (velocityDrag * elapsedTime);
						dragTimer -= elapsedTime;
					}
					else
					{
						// Zero velocity
						velocity = Vector3.Empty;
					}
				}
			}
			else
			{
				// No drag, so immediately change the velocity
				velocity = accel;
			}
		}



		/// <summary>
		/// Figure out the mouse delta based on mouse movement
		/// </summary>
		protected void UpdateMouseDelta(float elapsedTime)
		{
			// Get the current mouse position
			System.Drawing.Point current = System.Windows.Forms.Cursor.Position;

			// Calculate how far it's moved since the last frame
			System.Drawing.Point delta = new System.Drawing.Point(current.X - lastMousePosition.X,
				current.Y - lastMousePosition.Y);

			// Record the current position for next time
			lastMousePosition = current;

			// Smooth the relative mouse data over a few frames so it isn't 
			// jerky when moving slowly at low frame rates.
			float percentOfNew = 1.0f / framesToSmoothMouseData;
			float percentOfOld = 1.0f - percentOfNew;
			mouseDelta.X = mouseDelta.X*percentOfNew + delta.X*percentOfNew;
			mouseDelta.Y = mouseDelta.Y*percentOfNew + delta.Y*percentOfNew;

			rotationVelocity = mouseDelta * rotationScaler;
		}

		private void ComputeDepthRange(Vector3 center, float radius )
		{
			float farDist;
			float nearDist;

			//  NOTE: this ratio needs to depend on the z-buffer depth (24bits or more?)
			//        with a ratio of 16384 we have 10 bits of precision on a 24 bit z-buffer, giving good results in most cases...
			float cFarToNearRatio = 256.0f;

			farDist  = cFarToNearRatio;
			nearDist = 1.0f;

			// calculate the far clipping plane
			Vector3 v   = center + radius * lookDirection - position;

			// scene is behind us ?
			Vector3 dummy = v;
			dummy.Normalize();
			if (Vector3.Dot(lookDirection, dummy) > 0)
			{
				farDist = (Vector3.Dot(lookDirection,v) * lookDirection).Length();

				// calculate the near clipping plane
				v = center - radius * lookDirection - position;

				// parts of the scene is behind us ?
				dummy = v;
				dummy.Normalize();
				if (Vector3.Dot(lookDirection,dummy) > 0)
				{
					nearDist = (Vector3.Dot(lookDirection, v) * lookDirection).Length();
				}
				else
				{
					nearDist = farDist / cFarToNearRatio;
				}
				
			}	
			depthRange.X = nearDist;
			depthRange.Y = farDist;
		}
	}
}
			
			/*
					
void NVCamera::UpdateManipulator()
{
	// The default camera can't be animated.
	unsigned int Time = GetSYSInterface()->GetTime();

	INVTransformLinkPtr pTransCamera;
	GetTransformLink(&pTransCamera);
	if (m_bDrag) 
	{ 
		switch(m_CurrentMode)
		{
			// recompute m_qNow
			case NVCAMERA_ROTATE:
			{
				if (pTransCamera)
				{
					RotateCamera(vec3(0.0f, 1.0f, 0.0f), m_vDown.x - m_vCur.x, m_vCur.y - m_vDown.y);
				}
			}
			break;
			case NVCAMERA_DOLLY:
			{
				if (pTransCamera)
				{
					m_bUpdating = true;
					vec3 Direction = NVPARAM_GETVEC3(m_pLookDirection);
					vec2 ZScale = NVPARAM_GETVEC2(m_pDepthRange);
                    
					float Increment = (m_vDown.y - m_vCur.y) * (m_fRadius);
					float fNewFocal = NVPARAM_GETFLOAT(m_pFocalLength) - Increment;

					vec3 Trans;
					pTransCamera->GetTranslation(GetSYSInterface()->GetTime(), (NVFloat3*)Trans.vec_array);
					Trans = Trans + (Increment * Direction);

					pTransCamera->SetTranslation(Time, (NVFloat3*)Trans.vec_array);

					m_pFocalLength->Set(NVTYPE(fNewFocal));
					m_bUpdating = false;
				}
			}
			break;
			case NVCAMERA_PAN:
			{	
				if (pTransCamera)
				{
					m_bUpdating = true;
					DECLARE_SCENE(pScene);
					vec3 Trans;
					pTransCamera->GetTranslation(GetSYSInterface()->GetTime(), (NVFloat3*)Trans.vec_array);
			
					// Get the eye position in camera space.
					INVConnectionParameterPtr pViewParam;
					pScene->GetViewParam(&pViewParam);
					mat4 camera = NVPARAM_GETMAT4_RET(pViewParam);
					vec3 Direction = NVPARAM_GETVEC3(m_pLookDirection);
					vec2 ZScale = NVPARAM_GETVEC2(m_pDepthRange);

                    mat4 matCamera = NVPARAM_GETMAT4_RET(m_pLookAtMatrix);

					INVConnectionParameterPtr pFOV;
					INVCameraPtr pCurrentCam;
					pScene->GetCurrentCamera(&pCurrentCam);
					pCurrentCam->GetFOVParam(&pFOV);
					vec3 eye_obj_pos(0, 0, (ZScale.y + ZScale.x) / 2.0f);
					nv_scalar fov2 = (nv_scalar)(-tan(nv_zero_5 * nv_to_rad * NVPARAM_GETFLOAT(pFOV) ) * eye_obj_pos.z);

					vec3 Delta = m_vCur - m_vDown;
					Delta.y = -Delta.y;
					vec3 Increment = fov2 * Delta;
					Increment.z = 0.0f;

					vec3 vecAxisSide, vecAxisUp;
					mult_dir(vecAxisSide, vec3(1.0f, 0.0f, 0.0f), matCamera);
					mult_dir(vecAxisUp,  vec3(0.0f, 1.0f, 0.0f), matCamera);
					vecAxisSide.normalize();
					vecAxisUp.normalize();
			
					Trans += (Increment.x * -vecAxisSide);
					Trans += (Increment.y * vecAxisUp);

					pTransCamera->SetTranslation(Time, (NVFloat3*)Trans.vec_array);
					m_bUpdating = false;
				}
			}
			break;
			default:
				break;
		}
	}
}
*/

