using System;
using System.Collections;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX;
using Microsoft.Samples.DirectX.UtilityToolkit;

namespace Dxsas.Engine
{
	/// <summary>
	/// Summary description for Mesh.
	/// </summary>
	public class SasMesh : IDisposable
	{

		public SasMesh()
		{

		}

		~SasMesh()
		{
			Dispose();
		}
		public struct MeshVertex
		{
			public Vector3 Position;
			public Vector3 Texture;
			public Vector3 Tangent;
			public Vector3 Binormal;
			public Vector3 Color;
		};

		public bool Load(Device device, string filename)
		{
			mesh = new FrameworkMesh(device, filename);
			if (mesh == null)
				return false;

			mesh.IsUsingMaterials = false;
			VertexElement[] elements = new VertexElement[]
			{	
				new VertexElement(0, 0, DeclarationType.Float3,
				DeclarationMethod.Default,
				DeclarationUsage.Position, 0),

				new VertexElement(0, 12, DeclarationType.Float3,
				DeclarationMethod.Default,
				DeclarationUsage.Normal, 0),
                        
				new VertexElement(0, 24, DeclarationType.Float3,
				DeclarationMethod.Default,
				DeclarationUsage.TextureCoordinate, 0),
			    
				new VertexElement(0, 36, DeclarationType.Float3,
				DeclarationMethod.Default,
				DeclarationUsage.Tangent, 0),

				new VertexElement(0, 48, DeclarationType.Float3,
				DeclarationMethod.Default,
				DeclarationUsage.BiNormal, 0),
				
				new VertexElement(0, 60, DeclarationType.Color,
				DeclarationMethod.Default,
				DeclarationUsage.Color, 0),
				
				           
				VertexElement.VertexDeclarationEnd 
			};

			VertexFormats oldFormat = mesh.SystemMesh.VertexFormat;
	
			decl = new VertexDeclaration(device, elements);

			// Use the vertex element array to create a vertex declaration.
			mesh.SetVertexDeclaration(device, elements);

			if ((oldFormat & VertexFormats.Normal) == 0)
			{
				mesh.SystemMesh.ComputeNormals();
				mesh.LocalMesh.ComputeNormals();
			}

			mesh.SystemMesh.ComputeTangent(0, 0, 0, 1);
			mesh.LocalMesh.ComputeTangent(0, 0, 0, 1);

			return true;
		}

		public unsafe float ComputeBoundingSphere(out Vector3 Center)
		{
			float radius;

			//This time, lock the entire VertexBuffer
			using(VertexBuffer vb = mesh.SystemMesh.VertexBuffer)
			{
				using (GraphicsStream stm = vb.Lock(0, 0, LockFlags.None))
				{
					try
					{
						Vector3 MinPos = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
						Vector3 MaxPos = new Vector3(float.MinValue, float.MinValue, float.MinValue);

						MeshVertex* vbArray = (MeshVertex*) stm.InternalDataPointer;
						for (int Vertex = 0; Vertex < mesh.SystemMesh.NumberVertices; Vertex++)
						{
							if (vbArray[Vertex].Position.X < MinPos.X)
								MinPos.X = vbArray[Vertex].Position.X;
							if (vbArray[Vertex].Position.Y < MinPos.Y)
								MinPos.Y = vbArray[Vertex].Position.Y;
							if (vbArray[Vertex].Position.Z < MinPos.Z)
								MinPos.Z = vbArray[Vertex].Position.Z;

							if (vbArray[Vertex].Position.X > MaxPos.X)
								MaxPos.X = vbArray[Vertex].Position.X;
							if (vbArray[Vertex].Position.Y > MaxPos.Y)
								MaxPos.Y = vbArray[Vertex].Position.Y;
							if (vbArray[Vertex].Position.Z > MaxPos.Z)
								MaxPos.Z = vbArray[Vertex].Position.Z;

							
						}

						Center = new Vector3((MaxPos.X + MinPos.X) / 2.0f,(MaxPos.Y + MinPos.Y) / 2.0f,(MaxPos.Z + MinPos.Z) / 2.0f);
						Vector3 RadiusVec = MaxPos - Center;
						radius = RadiusVec.Length();
					}
					finally
					{
						vb.Unlock();
					}
				}
			}
			return radius;
		}

		public bool Draw(Device dev, int subSet)
		{
			mesh.LocalMesh.DrawSubset(subSet);
			return true;
		}

		public VertexDeclaration GetVertexDeclaration()
		{
			return decl;
		}

		public unsafe bool ApplyEffect(String path)
		{
			if (mesh.LocalMesh == null)
				return false;

			foreach(SasMaterial mat in mats)
			{
				mat.Dispose();
			}
			mats.Clear();
			for (int i = 0; i < mesh.NumberMaterials; i++)
			{
				Engine.SasMaterial mat = new Engine.SasMaterial();
				mat.Load(mesh.LocalMesh.Device, path);

				if (mat.MaterialEffect != null)
				{
					EffectHandle hTech = mat.MaterialEffect.FindNextValidTechnique(null);
					if (hTech != null)
					{
						mat.MaterialEffect.Technique = hTech;
					}

					// Replace the diffuse texture in the effect with the model texture, if we have one.
					for(int param = 0; param < mat.MaterialEffect.Description.Parameters; param++)
					{
						EffectHandle handleParam = mat.MaterialEffect.GetParameter(null, param);
						ParameterDescription desc = mat.MaterialEffect.GetParameterDescription(handleParam);

						if (string.Compare(desc.Semantic, "POSITION", true) == 0)
						{
							if (desc.Type == ParameterType.Float && 
								desc.Columns == 4)
							{
								Vector3 center;
								float radius = ComputeBoundingSphere(out center);
								
								Vector4 vec = new Vector4(radius * 2.0f, radius * 2.0f, -radius * 2.0f, 1.0f);
								vec.X += center.X;
								vec.Y += center.Y;
								vec.Z += center.Z;
								mat.MaterialEffect.SetValue(handleParam, &vec, sizeof(float) * 4);
							}
						}
						else if (string.Compare(desc.Semantic, "DIRECTION", true) == 0)
						{
							if (desc.Type == ParameterType.Float && 
								desc.Columns == 3)
							{
								Vector3 vec = new Vector3(0.0f, 0.0f, 1.0f);
								mat.MaterialEffect.SetValue(handleParam, &vec, sizeof(float) * 3);
							}
						}
						else if (string.Compare(desc.Semantic, "DIFFUSE", true) == 0)
						{
							/*
							SasTexture tex = mat.GetTexture(handleParam);
							BaseTexture replace = mesh.GetTexture(i);
							if (tex != null && replace != null)
							{
								//tex.SetTexture(replace);
							}
							*/
						}
					}
				}

				mats.Add(mat);
			}
			return true;
		}

		public ArrayList GetMaterials()
		{
			return mats;
		}

		public FrameworkMesh GetFrameworkMesh()
		{
			return mesh;
		}
		public bool RemoveAllMaterials()
		{
			foreach(SasMaterial mat in mats)
			{
				mat.Dispose();
			}
			mats.Clear();
			return true;
		}

		private FrameworkMesh mesh;
		private ArrayList mats = new ArrayList();
		private VertexDeclaration decl = null;
		private bool isDisposed = false;
		#region IDisposable Members

		public void Dispose()
		{
			GC.SuppressFinalize(this);
			if (!isDisposed)
			{
				RemoveAllMaterials();

				// Framework mesh is monitoring device events, don't dispose it.
				//mesh.Dispose();
			}
			isDisposed = true;
		}

		#endregion
	}


}
