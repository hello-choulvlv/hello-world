using System;
using System.Collections;
using Dxsas.Engine;
using Microsoft.DirectX;
using Microsoft.Samples.DirectX.UtilityToolkit;

namespace Dxsas.Engine
{
	/// <summary>
	/// Summary description for Scene.
	/// </summary>
	public class SasScene : IDisposable
	{
		#region Scene

		private ArrayList meshes = new ArrayList();
		private ArrayList materials = new ArrayList();
		private SasCamera camera = null;
		private float sceneRadius = 0.0f;
		private Vector3 sceneCenter = new Vector3(0.0f, 0.0f, 0.0f);
		private bool isDisposed = false;

		public Vector3 SceneCenter { get { return sceneCenter; } }
		public float SceneRadius { get { return sceneRadius; } }

		~SasScene()
		{
			Dispose();
		}
		public bool AddMaterial(SasMaterial mat)
		{
			materials.Add(mat);
			return false;
		}

		public bool RemoveMaterial(SasMaterial mat)
		{
			// Reset, so the resources are freed.
			mat.OnLostDevice();

			materials.Remove(mat);
			return false;
		}

		public bool RemoveAllMaterials()
		{
			foreach(SasMaterial mat in materials)
			{
				mat.Dispose();
			}
			materials.Clear();
			return true;
		}
		
		public bool RemoveAllMeshes()
		{
			foreach(SasMesh mesh in meshes)
			{
				mesh.Dispose();
			}
			meshes.Clear();
			return true;
		}

		public bool ComputeBounds()
		{
			// Fixme, only for 1 mesh
			if (meshes.Count == 0)
			{
				sceneCenter = new Vector3(0.0f, 0.0f, 0.0f);
				sceneRadius = 0.0f;
				return true;
			}

			sceneRadius = ((SasMesh)meshes[0]).ComputeBoundingSphere(out sceneCenter);
			return true;
		}

		public bool AddMesh(SasMesh mesh)
		{
			meshes.Add(mesh);

			ComputeBounds();
			return false;
		}

		public bool RemoveMesh(SasMesh mesh)
		{
			meshes.Remove(mesh);
			return false;
		}

		public SasCamera Camera
		{
			get { return camera; }
			set { camera = value; }
		}

		public ArrayList GetMeshes()
		{
			return meshes;
		}
		
		public ArrayList GetMaterials()
		{
			return materials;
		}

		public bool OnLostDevice()
		{
			// Pass the reset to all the meshes and the materials.
			foreach(SasMesh mesh in meshes)
			{
				foreach(SasMaterial mat in mesh.GetMaterials())
				{
					mat.OnLostDevice();
				}
			}

			foreach(SasMaterial mat in materials)
			{
				mat.OnLostDevice();
			}

			return true;
		}
		public bool OnResetDevice(DeviceEventArgs e)
		{
			// Pass the reset to all the meshes and the materials.
			foreach(SasMesh mesh in meshes)
			{
				foreach(SasMaterial mat in mesh.GetMaterials())
				{
					mat.OnResetDevice(e);
				}
			}

			foreach(SasMaterial mat in materials)
			{
				mat.OnResetDevice(e);
			}
			return true;
		}
		public bool OnDestroyDevice()
		{
			// Pass the reset to all the meshes and the materials.
			return true;
		}



		#endregion

		#region IDisposable Members

		public void Dispose()
		{
			GC.SuppressFinalize(this);
			if (!isDisposed)
			{
				RemoveAllMaterials();
				RemoveAllMeshes();
			}
			isDisposed = true;
		}

		#endregion
	}
}
