using System;
using System.Diagnostics;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX;
using System.Collections;

namespace Dxsas.Engine
{
	/// <summary>
	/// Summary description for ScriptEngine.
	/// </summary>
	public class SasScriptEngine
	{
		class InstructionPointer
		{
			public int materialStackPos = 0;
			public int currentInstruction = 0;
			public ArrayList commands = new ArrayList();
			public SasMesh geometryMesh = null;
			public int geometryAttribute = 0;
			public int loopCount = 0;
			public int loopStartCount = 0;
			public int loopReturnInstruction = -1;
			public int passNum = 0;
		}
		
		private Vector4 clearColor = new Vector4(0.0f, 0.0f, 0.0f, 1.0f);
		private float clearDepth = 1.0f;
		private int clearStencil = 0;
		private bool isDrawObjects = true;

		public bool ModelDrawn { get { return isDrawObjects; } }

		ArrayList materialStack = new ArrayList();
		Stack callStack = new Stack();

		public SasScriptEngine()
		{
		}

		public bool Run(SasScene scene, SasRenderer renderer)
		{
			isDrawObjects = false;

			if (scene.GetMaterials().Count == 0)
				return true;

			renderer.PreScene();

			materialStack.Clear();
			foreach(SasMaterial mat in scene.GetMaterials())
			{
				if (mat.MaterialEffect != null)
				{
					materialStack.Add(mat);
				}
			}

			if (materialStack.Count == 0)
				return true;

			SasMaterial firstMat = (SasMaterial)materialStack[materialStack.Count - 1];
			Effect effect = firstMat.MaterialEffect;
			if (effect == null || effect.Disposed)
			{
				// fail
				return false;
			}

			// Reset to default
			renderer.ResetTargets();

			renderer.PreEffectRender(scene, firstMat);

			// Make sure we start with an empty stack
			callStack.Clear();

			InstructionPointer ip = new InstructionPointer();
			ip.materialStackPos = materialStack.Count - 1;
			ip.currentInstruction = 0;
			ip.commands = firstMat.EntryPoint;
			callStack.Push(ip);

			// Make the first call.
			Execute(scene, renderer);

			renderer.ResetTargets();

			renderer.PostScene();

			return true;
		}

		public unsafe bool Execute(SasScene scene, SasRenderer renderer)
		{
			InstructionPointer ip = ((InstructionPointer)callStack.Peek());
			SasMaterial mat = (SasMaterial)materialStack[ip.materialStackPos];

			Effect effect = mat.MaterialEffect;
			while (ip.currentInstruction != ip.commands.Count)
			{
				SasScriptCommand commandObject = (SasScriptCommand)ip.commands[ip.currentInstruction];
				ip.currentInstruction++;

				// Update if dirty.
				commandObject.Update();

				// If we entered a loop count of 0, skip all the instructions except the end.
				if (ip.loopReturnInstruction != -1 &&
					ip.loopCount == 0 && 
					commandObject.Command != SasScriptCommand.CommandType.LoopEnd)
				{
					continue;
				}

				switch(commandObject.Command)
				{
					case SasScriptCommand.CommandType.Clear:
					{
						SasScript_Clear clear = (SasScript_Clear)commandObject;
						switch(clear.ClearOption)
						{
							case SasScript_Clear.ClearType.Color:
								renderer.ClearColor(clearColor);
								break;
							case SasScript_Clear.ClearType.Depth:
								renderer.ClearDepth(clearDepth);
								break;
							case SasScript_Clear.ClearType.Stencil:
								renderer.ClearStencil(clearStencil);
								break;
							default:
								break;
						}
					}
					break;

					case SasScriptCommand.CommandType.RenderColorTarget:
					{
						SasScript_RenderColorTarget renderColorTarget = (SasScript_RenderColorTarget)commandObject;
						renderer.SetColorTarget(renderColorTarget.Index, mat.GetTexture(renderColorTarget.TextureHandle));

						// We may need to update the effect parameters if the rendertarget has changed
						// since this may effect viewportpixelsize...
						// Can optimize this, but for now, just blast through them...
						for(int i = 0; i < effect.Description.Parameters; i++)
						{
							SasMaterial.ParameterInfo info = mat.GetParameterInfo(i);
							if (info.semanticID == SasMaterial.SemanticID.viewportpixelsize &&
								(effect.GetParameterDescription(info.handle).Columns == 2))
							{
								Vector2 size = renderer.CurrentTargetSize;
								effect.SetValue(info.handle, &size, sizeof(float) * 2);
							}
						}
					}
					break;

					case SasScriptCommand.CommandType.RenderDepthStencilTarget:
					{
						SasScript_RenderDepthStencilTarget renderDepthTarget = (SasScript_RenderDepthStencilTarget)commandObject;
						SasTexture tex = mat.GetTexture(renderDepthTarget.TextureHandle);
						if (tex != null)
							renderer.SetDepthTarget(tex.DepthSurface);
						else
							renderer.SetDepthTarget(null);
					}
					break;
					
					case SasScriptCommand.CommandType.ClearSetColor:
					{
						SasScript_ClearSetColor clearSetColor = (SasScript_ClearSetColor)commandObject;
						clearColor = clearSetColor.Color;
					}
					break;
					
					case SasScriptCommand.CommandType.ClearSetDepth:
					{
						SasScript_ClearSetDepth clearSetDepth = (SasScript_ClearSetDepth)commandObject;
						clearDepth = clearSetDepth.Depth;
					}
					break;

					case SasScriptCommand.CommandType.ClearSetStencil:
					{
						SasScript_ClearSetStencil clearSetStencil = (SasScript_ClearSetStencil)commandObject;
						clearStencil = clearSetStencil.Stencil;
					}
					break;

					case SasScriptCommand.CommandType.Pass:
					{
						SasScript_Pass pass = (SasScript_Pass)commandObject;
						ip.passNum = pass.PassNum;

						InstructionPointer ipNew = new InstructionPointer();
						ipNew.commands = mat.GetPassScript(effect.GetPass(effect.Technique, pass.PassNum));
						ipNew.currentInstruction = 0;
						ipNew.materialStackPos = ip.materialStackPos;
						ipNew.geometryMesh = ip.geometryMesh;
						ipNew.geometryAttribute = ip.geometryAttribute;
						ipNew.passNum = ip.passNum;
						callStack.Push(ipNew);

						Execute(scene, renderer);
					}
					break;

					case SasScriptCommand.CommandType.LoopByCount:
					{
						// Record the return address for this loop & the loop count
						SasScript_LoopByCount byCount = (SasScript_LoopByCount)commandObject;
						ip.loopCount = byCount.Count;
						ip.loopStartCount = byCount.Count;
						
						// We already advanced the count, so the current is the next one on.
						ip.loopReturnInstruction = ip.currentInstruction;
					}
					break;

					case SasScriptCommand.CommandType.LoopGetIndex:
					{
						SasScript_LoopGetIndex getIndex = (SasScript_LoopGetIndex)commandObject;
						if (getIndex.DestinationParameter != null)
						{
							SasEffectUtils.SetIntegerParam(effect, getIndex.DestinationParameter, ip.loopCount);
							mat.DirtyCommands();
						}
					}
					break;

					case SasScriptCommand.CommandType.LoopGetCount:
					{
						SasScript_LoopGetCount getCount = (SasScript_LoopGetCount)commandObject;
						if (getCount.DestinationParameter != null)
						{
							SasEffectUtils.SetIntegerParam(effect, getCount.DestinationParameter, ip.loopStartCount);
							mat.DirtyCommands();
						}
					}
					break;

					case SasScriptCommand.CommandType.LoopEnd:
					{
						SasScript_LoopEnd end = (SasScript_LoopEnd)commandObject;
						
						if (ip.loopReturnInstruction != -1)
						{
							ip.loopCount--;
							if (ip.loopCount > 0)
							{
								ip.currentInstruction = ip.loopReturnInstruction;
							}
							else
							{
								ip.loopReturnInstruction = -1;
								ip.loopCount = 0; // could be -1 for a 0 entry loop
							}
						}
						else
						{
							App.ReportError("loop end with no begin!");
						}
					}
					break;

					case SasScriptCommand.CommandType.Draw:
					{
						SasScript_Draw draw = (SasScript_Draw)commandObject;

						// Pass number not established, can't go on.
						if (ip.passNum == -1)
							break;
						
						effect.Begin(0);
						effect.BeginPass(ip.passNum);
						effect.CommitChanges();

						switch(draw.DrawOption)
						{
							case SasScript_Draw.DrawType.Buffer:
								renderer.DrawQuad();
								break;

								// The same thing for now.
							case SasScript_Draw.DrawType.Geometry:
							{
								isDrawObjects = true;
								if (ip.geometryMesh == null)
								{
									// Draw the whole scene using this overridden material
									foreach(SasMesh mesh in scene.GetMeshes())
									{
										renderer.Device.VertexDeclaration = mesh.GetVertexDeclaration();
										for (int count = 0; count < mesh.GetMaterials().Count; count++)
										{
											mesh.Draw(renderer.Device, count);
										}
									}
								}
								else
								{
									renderer.Device.VertexDeclaration = ip.geometryMesh.GetVertexDeclaration();
									ip.geometryMesh.Draw(renderer.Device, ip.geometryAttribute);
								}
							}
							break;

							case SasScript_Draw.DrawType.Scene:
							{
								isDrawObjects = true;
								// Draw the whole scene using this overridden material
								foreach(SasMesh mesh in scene.GetMeshes())
								{
									renderer.Device.VertexDeclaration = mesh.GetVertexDeclaration();
									for (int count = 0; count < mesh.GetMaterials().Count; count++)
									{
										mesh.Draw(renderer.Device, count);
									}
								}
							}
							break;

							default:
								break;				
						}
						effect.EndPass();
						effect.End();
					}
					break;

					case SasScriptCommand.CommandType.Technique:
					{
						SasScript_Technique tech = (SasScript_Technique)commandObject;
						effect.Technique = tech.Handle;


						InstructionPointer ipNew = new InstructionPointer();
						ipNew.commands = mat.GetTechniqueScript(tech.Handle);
						ipNew.currentInstruction = 0;
						ipNew.materialStackPos = ip.materialStackPos;
						ipNew.geometryAttribute = ip.geometryAttribute;
						ipNew.geometryMesh = ip.geometryMesh;
						ipNew.passNum = ip.passNum;
						callStack.Push(ipNew);

						Execute(scene, renderer);
					}
					break;

					case SasScriptCommand.CommandType.ScriptExternal:
					{
						SasScript_ScriptExternal scriptExternal = (SasScript_ScriptExternal)commandObject;
						if (ip.materialStackPos == 0)
						{
							// At the top of the stack.  Walk the scene and draw it using the materials
							// in the scene.
							isDrawObjects = true;

							foreach(SasMesh mesh in scene.GetMeshes())
							{
								renderer.Device.VertexDeclaration = mesh.GetVertexDeclaration();

								int subSet = 0;
								foreach(SasMaterial matCurrent in mesh.GetMaterials())
								{
									Effect newEffect = matCurrent.MaterialEffect;
									if (newEffect == null || newEffect.Disposed)
									{
										subSet++;
										continue;
									}

									// Prepare the effect parameters
									renderer.PreEffectRender(scene, matCurrent);

									// Add this material to the stack
									materialStack.Add(matCurrent);
								
									InstructionPointer ipNew = new InstructionPointer();
									ipNew.materialStackPos = materialStack.Count - 1;
									ipNew.currentInstruction = 0;
									ipNew.commands = matCurrent.EntryPoint;
									ipNew.geometryMesh = mesh;
									ipNew.geometryAttribute = subSet;
									callStack.Push(ipNew);

									subSet++;

									// Draw this section
									Execute(scene, renderer);
								}

							}
						}
						else
						{
							
							InstructionPointer ipNew = new InstructionPointer();
							ipNew.materialStackPos = ip.materialStackPos-1;
							SasMaterial newMat = (SasMaterial)materialStack[ipNew.materialStackPos];
							ipNew.commands = newMat.EntryPoint;
							ipNew.currentInstruction = 0;
							callStack.Push(ipNew);

							renderer.PushTargets();

							// New mat, so set the variables
							renderer.PreEffectRender(scene, newMat);

							Execute(scene, renderer);

							renderer.PopTargets();
						}
					}
					break;

					default:
						break;
				}
			}

			
			callStack.Pop();
			return true;
		}

				
	}
}
