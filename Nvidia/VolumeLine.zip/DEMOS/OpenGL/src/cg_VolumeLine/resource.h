//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDR_PNG1                        101
#define IDR_PNG2                        102
#define IDR_PNG3                        103
#define IDR_PNG4                        104
#define IDR_PNG5                        105
#define IDR_PNG6                        106
#define IDR_PNG7                        107
#define IDR_PNG8                        108
#define IDR_PNG9                        109

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
