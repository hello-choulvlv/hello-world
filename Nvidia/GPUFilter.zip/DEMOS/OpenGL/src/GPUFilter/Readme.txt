GPUFilter Framework for Adobe Photoshop(tm)

    This code example implements a Photoshop(tm) filter plugin
    that performs its key pixel operations using OpenGL GLSL
    shaders.  Docs are included to guide developers who desire to
    use GLSL in Photoshop on their own.

    The sample is packages as a Microsoft Visual Studio.NET
    solution with associated files, in the same directory with
    this README file. This code sample requires
    the use of Adobe's Photoshop CS API toolkit, which is
    available to registered developers directly from Adobe
    Systems (http://www.adobe.com/). You will need to change the
    various include paths to aim at your own installation of
    Adobe's API -- the path used in the original build at NVIDIA
    used "$(BUILD_TOOLS_DIR)\sdk\PhotoshopCSAPI\" so for quick
    customization to your own system, you can replace that string
    with your own path in the "GPUFilter.vcproj" file, using any
    text editor.

    If you just want to try the filter without compiling the
    source, move the enclosed "GPUFilter.8bf" file to your local
    Photoshop "..\Plugins\Filters" folder before starting
    Photoshop.

    This plugin makes use of GLSL shaders also found in the
    directory, though it is self-contained as well. To over-ride
    the behavior of the filter using your own shaders, copy them
    in a directory named "C:\GPUFilter" on your local system, and
    edit the copies (the filter's default behavior is to use its
    internal shader code, unless shaders with the appropriate
    names are found in C:\GPUFilter).

    For further explanation of the design of this filter framework, see
    the enclosed PDF doc.

    $Date: 2005/06/23 $

    "Photoshop" is a trademark of Adobe Systems.
