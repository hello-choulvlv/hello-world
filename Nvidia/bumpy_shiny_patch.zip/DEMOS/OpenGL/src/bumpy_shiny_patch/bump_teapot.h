#ifndef BUMP_TEAPOT
#define BUMP_TEAPOT

void render_teapot();

#endif
