#ifndef CUBEMAP_BORDERS_H
#define CUBEMAP_BORDERS_H

// assuming a non-bordered cubemap is bound and loaded,
// get the images, compute borders and reload bordered
// face images
//
// Cass Everitt
// 1-9-02

void cubemap_borders();

#endif
