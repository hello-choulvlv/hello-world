This SDK samples demonstrates water simulation and rendering on the GPU.
The sample uses the Shader Model 3.0 hardware capability of texture
fetch in the vertex shader. It also uses fp16 blending and fp16
texture filtering (new features on the GeForce 6 series).