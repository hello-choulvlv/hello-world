/*--------------------------------------------------------------------- NVMH5 -|----------------------
Path:  Sdk\Demos\Direct3D9\src\AntiAliasingWithPostProcessing\
File:  AAPPDemo.cpp

Copyright NVIDIA Corporation 2003
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED *AS IS* AND NVIDIA AND
AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA
OR ITS SUPPLIERS BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER
INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF
BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THIS
SOFTWARE, EVEN IF NVIDIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


Comments:


-------------------------------------------------------------------------------|--------------------*/

#include <d3d9.h>
#include <d3dx9.h>
#include "AAPPDemo.h"
#include "NV_D3DCommon\NV_D3DCommon.h"
#include "NV_D3DMesh\NV_D3DMesh.h"
#include "shared\NV_Common.h"
#include "shared\NV_Error.h"

#include "AAPPScene.h"


AAPPDemo::AAPPDemo()
{
	SetAllNull();
}
AAPPDemo::~AAPPDemo()
{
	Free();
}

HRESULT AAPPDemo::Free()
{
	SAFE_DELETE( m_pRenderTargetFactory );
	SAFE_DELETE( m_pTextureDisplay );
	SAFE_DELETE( m_pScene );
	SAFE_RELEASE( m_pD3DDev );
	return( S_OK );
}

LRESULT AAPPDemo::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	switch( uMsg )
	{
	case WM_KEYUP :
		switch( wParam )
		{
		case VK_SPACE:
			m_bCopyBackbufferAndPostProcess = !m_bCopyBackbufferAndPostProcess;
			FMsg("m_bCopyBackbufferAndPostProcess = %s\n", m_bCopyBackbufferAndPostProcess ? "TRUE" : "FALSE" );
			break;
		}
		break;		// WM_KEYUP
	}
	return( 0 );
}

HRESULT AAPPDemo::Initialize( IDirect3DDevice9 * pDev )
{
	HRESULT hr = S_OK;
	Free();
	FAIL_IF_NULL( pDev );
	m_pD3DDev = pDev;
	m_pD3DDev->AddRef();

	m_pRenderTargetFactory = new RenderTargetFactory;
	FAIL_IF_NULL( m_pRenderTargetFactory );
	hr = m_pRenderTargetFactory->Initialize( GetFilePath::GetFilePath );
	MSG_AND_RET_VAL_IF( FAILED(hr), "RenderTargetFactory->Initialize() failed\n", hr );

	m_pTextureDisplay = new TextureDisplay2;
	FAIL_IF_NULL( m_pTextureDisplay );
	hr = m_pTextureDisplay->Initialize( m_pD3DDev );
		
	m_pScene = new AAPPScene;
	FAIL_IF_NULL( m_pScene );
	hr = m_pScene->Initialize( m_pD3DDev );

	m_pDefaultBuffers = new RenderTargetSet;
	FAIL_IF_NULL( m_pDefaultBuffers );

	int width, height;
	D3DVIEWPORT9 viewport;
	m_pD3DDev->GetViewport( &viewport );
	width = viewport.Width;
	height = viewport.Height;
	// StretchRect from backbuffer to half-sized RTT works with linear filtering!
	// This may not be reliable
	m_ppRTTBackbufferCopy = m_pRenderTargetFactory->CreateRenderTarget( m_pD3DDev, width/2, height/2, D3DFMT_A8R8G8B8 );
//	m_ppRTTBackbufferCopy = m_pRenderTargetFactory->CreateRenderTarget( m_pD3DDev, width, height, D3DFMT_A8R8G8B8 );
	MSG_AND_RET_VAL_IF( m_ppRTTBackbufferCopy == NULL, "couldn't create RTT for copy of backbuffer\n", E_FAIL );

	int rtt2w, rtt2h;
	rtt2w = width / 4;
	rtt2h = height / 4;
	m_ppRTTHalfSize = m_pRenderTargetFactory->CreateRenderTarget( m_pD3DDev, rtt2w, rtt2h, D3DFMT_A8R8G8B8 );
	MSG_AND_RET_VAL_IF( m_ppRTTHalfSize == NULL, "couldn't create half-sized RTT\n", E_FAIL );

	int rtt3w, rtt3h;
	rtt3w = width / 8;
	rtt3h = height / 8;
	m_ppRTT3 = m_pRenderTargetFactory->CreateRenderTarget( m_pD3DDev, rtt3w, rtt3h, D3DFMT_A8R8G8B8 );
	MSG_AND_RET_VAL_IF( m_ppRTT3 == NULL, "couldn't create RTT3\n", E_FAIL );

	// 4th render target for acumulating the blur
	m_ppRTT4 = m_pRenderTargetFactory->CreateRenderTarget( m_pD3DDev, rtt3w, rtt3h, D3DFMT_A8R8G8B8 );
	MSG_AND_RET_VAL_IF( m_ppRTT4 == NULL, "couldn't create RTT4\n", E_FAIL );

	m_pTextureDisplay->AddTexture( & m_TD_BackbufferCopy, (*m_ppRTTBackbufferCopy)->m_ppRTTTexture, 
									FRECT( 0.1f, 0.8f, 0.2f, 0.9f ) );
	m_pTextureDisplay->AddTexture( & m_TD_BackBufferCopyToFullScreen, (*m_ppRTTBackbufferCopy)->m_ppRTTTexture, 
									FRECT( 0.0f, 0.0f, 1.0f, 1.0f ) );

	// Apply half-texel size offset so we sample from texel centers
	float hfac, wfac;
	hfac = 0.5f / rtt2h;
	wfac = 0.5f / rtt2w;
	m_pTextureDisplay->AddTexture( & m_TD_HalfSizeToFullScreen, (*m_ppRTTHalfSize)->m_ppRTTTexture, 
									FRECT( 0.0f-wfac, 0.0f-hfac, 1.0f-wfac, 1.0f-hfac ) );
	hfac = 0.5f / rtt3h;
	wfac = 0.5f / rtt3w;
	m_pTextureDisplay->AddTexture( & m_TD_RTT3ToFullScreen, (*m_ppRTT3)->m_ppRTTTexture, 
									FRECT( 0.0f-wfac, 0.0f-hfac, 1.0f-wfac, 1.0f-hfac ) );

	m_pTextureDisplay->AddTexture( & m_TD_RTT3_1, (*m_ppRTT3)->m_ppRTTTexture, 
									FRECT( 0.0f-wfac - wfac*3, 0.0f-hfac - hfac*3, 1.0f-wfac - wfac*3, 1.0f-hfac - hfac*3 ) );
	m_pTextureDisplay->AddTexture( & m_TD_RTT3_2, (*m_ppRTT3)->m_ppRTTTexture, 
									FRECT( 0.0f-wfac + wfac*3, 0.0f-hfac + hfac*3, 1.0f-wfac + wfac*3, 1.0f-hfac + hfac*3 ) );
	m_pTextureDisplay->AddTexture( & m_TD_RTT3_3, (*m_ppRTT3)->m_ppRTTTexture, 
									FRECT( 0.0f-wfac + wfac*3, 0.0f-hfac - hfac*3, 1.0f-wfac + wfac*3, 1.0f-hfac - hfac*3 ) );
	m_pTextureDisplay->AddTexture( & m_TD_RTT3_4, (*m_ppRTT3)->m_ppRTTTexture, 
									FRECT( 0.0f-wfac - wfac*3, 0.0f-hfac + hfac*3, 1.0f-wfac - wfac*3, 1.0f-hfac + hfac*3 ) );

	m_pTextureDisplay->AddTexture( & m_TD_RTT4ToFullScreen, (*m_ppRTT4)->m_ppRTTTexture, 
									FRECT( 0.0f-wfac, 0.0f-hfac, 1.0f-wfac, 1.0f-hfac ) );

	*m_pDefaultBuffers = m_pRenderTargetFactory->GetCurrentTargets( m_pD3DDev );
	return( hr );
}

HRESULT AAPPDemo::Render()
{
	HRESULT hr = S_OK;
	FAIL_IF_NULL( m_pD3DDev );
	FAIL_IF_NULL( m_pScene );
	FAIL_IF_NULL( m_pDefaultBuffers );
	FAIL_IF_NULL( m_pDefaultBuffers->m_ppColorTarget );

	m_pD3DDev->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0x00 );

    // Set matrices
	D3DXMATRIX matIdentity;
	D3DXMATRIX matView;
	D3DXMatrixIdentity( &matIdentity );	
    m_pD3DDev->SetTransform( D3DTS_PROJECTION,	&matIdentity );
	D3DXMatrixTranslation( &matView, 0.0f, -0.1f, 0.0f );
	m_pD3DDev->SetTransform( D3DTS_VIEW,		&matView );

	m_pD3DDev->SetPixelShader( NULL );
	m_pD3DDev->SetVertexShader( NULL );
	m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLOROP,		D3DTOP_SELECTARG1 );
	m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLORARG1,	D3DTA_TFACTOR );
	m_pD3DDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,		D3DTOP_SELECTARG1 );
	m_pD3DDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1,	D3DTA_TFACTOR );

	m_pD3DDev->SetTextureStageState( 1, D3DTSS_COLOROP,		D3DTOP_DISABLE );
	m_pD3DDev->SetTextureStageState( 1, D3DTSS_ALPHAOP,		D3DTOP_DISABLE );

	m_pD3DDev->SetRenderState( D3DRS_CULLMODE,			D3DCULL_NONE );
	m_pD3DDev->SetRenderState( D3DRS_LIGHTING,			false );
	m_pD3DDev->SetRenderState( D3DRS_FOGENABLE,			false );
	m_pD3DDev->SetRenderState( D3DRS_ZENABLE,			true );
	m_pD3DDev->SetRenderState( D3DRS_ZWRITEENABLE,		true );
	m_pD3DDev->SetRenderState( D3DRS_FILLMODE,			D3DFILL_SOLID );
	m_pD3DDev->SetRenderState( D3DRS_ALPHABLENDENABLE,	false );

	m_pD3DDev->SetRenderState( D3DRS_TEXTUREFACTOR,		0xFF00FFFF );		// ARGB

	m_pD3DDev->SetTransform( D3DTS_WORLD,		&m_pScene->m_matInnerRing );

	m_pScene->m_CenterPinwheel.Draw();

	m_pD3DDev->SetRenderState( D3DRS_TEXTUREFACTOR,		0xFFFFFF00 );		// ARGB

	m_pD3DDev->SetTransform( D3DTS_WORLD,		&matIdentity );
	m_pScene->m_OuterRing.Draw();

	if( m_bCopyBackbufferAndPostProcess )
	{
		IDirect3DSurface9 * pBackBuffer;
		m_pD3DDev->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pBackBuffer );
		hr = m_pD3DDev->StretchRect( pBackBuffer, NULL, (*m_ppRTTBackbufferCopy)->GetSurfaceP(), NULL, D3DTEXF_LINEAR );
		MSG_AND_RET_VAL_IF( FAILED(hr), "Couldn't copy from backbuffer to RTT texture!\n", hr );
		SAFE_RELEASE( pBackBuffer );

		// Render the RTTBackBufferCopy into a smaller render target texture
		m_pD3DDev->SetDepthStencilSurface( NULL );
		m_pD3DDev->SetRenderTarget( 0, (*m_ppRTTHalfSize)->GetSurfaceP() );
		m_pD3DDev->SetRenderState( D3DRS_ZENABLE,		false );
		m_pD3DDev->SetRenderState( D3DRS_ZWRITEENABLE,	false );

		m_pD3DDev->SetTexture( 0, m_pTextureDisplay->GetTextureP( m_TD_BackBufferCopyToFullScreen ) );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLOROP,		D3DTOP_MODULATE );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLORARG1,	D3DTA_TEXTURE );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLORARG2,	D3DTA_TFACTOR );
		m_pD3DDev->SetSamplerState( 0, D3DSAMP_MAGFILTER,		D3DTEXF_LINEAR );
		m_pD3DDev->SetRenderState( D3DRS_TEXTUREFACTOR,			0x0000FF00 );		// ARGB 
		// false to not set pixel state
		m_pTextureDisplay->Render( m_TD_BackBufferCopyToFullScreen, false );

		// Render RTT2 into RTT3
		m_pD3DDev->SetRenderTarget( 0, (*m_ppRTT3)->GetSurfaceP() );

		m_pD3DDev->SetTexture( 0, m_pTextureDisplay->GetTextureP( m_TD_HalfSizeToFullScreen ) );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLOROP,		D3DTOP_SELECTARG1 );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLORARG1,	D3DTA_TEXTURE );
		m_pD3DDev->SetSamplerState( 0, D3DSAMP_MAGFILTER,		D3DTEXF_LINEAR );
		// false so it doesn't set the pixel state
		m_pTextureDisplay->Render( m_TD_HalfSizeToFullScreen, false );

		// Render RTT3 into RTT4
		m_pD3DDev->SetRenderTarget( 0, (*m_ppRTT4)->GetSurfaceP() );
		m_pD3DDev->Clear( 0, NULL, D3DCLEAR_TARGET, 0x00, 0.0, 0x00 );
		m_pD3DDev->SetTexture( 0, m_pTextureDisplay->GetTextureP( m_TD_RTT3_1 ) );

		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLOROP,		D3DTOP_MODULATE );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLORARG1,	D3DTA_TEXTURE );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLORARG2,	D3DTA_TFACTOR );
		m_pD3DDev->SetSamplerState( 0, D3DSAMP_MAGFILTER,		D3DTEXF_LINEAR );
		m_pD3DDev->SetRenderState( D3DRS_TEXTUREFACTOR,			0x00006000 );		// ARGB 
		m_pD3DDev->SetRenderState( D3DRS_ALPHABLENDENABLE,		true );
		m_pD3DDev->SetRenderState( D3DRS_SRCBLEND,				D3DBLEND_ONE );
		m_pD3DDev->SetRenderState( D3DRS_DESTBLEND,				D3DBLEND_ONE );
		m_pTextureDisplay->Render( m_TD_RTT3_1, false );
		m_pTextureDisplay->Render( m_TD_RTT3_2, false );
		m_pTextureDisplay->Render( m_TD_RTT3_3, false );
		m_pTextureDisplay->Render( m_TD_RTT3_4, false );

		//---------------------------------------------
		// Render RTT4 to the flip chain backbuffer
		// Switch back to the flip chain backbuffer
		m_pDefaultBuffers->SetAsCurrent();

		m_pD3DDev->SetTexture( 0, m_pTextureDisplay->GetTextureP( m_TD_RTT4ToFullScreen ) );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLOROP,		D3DTOP_SELECTARG1 );
		m_pD3DDev->SetTextureStageState( 0, D3DTSS_COLORARG1,	D3DTA_TEXTURE );
		m_pD3DDev->SetSamplerState( 0, D3DSAMP_MAGFILTER,		D3DTEXF_LINEAR );

		// Render the half-size render target texture to the screen
		m_pD3DDev->SetRenderState( D3DRS_ALPHABLENDENABLE,		true );
		m_pD3DDev->SetRenderState( D3DRS_SRCBLEND,				D3DBLEND_ONE );
		m_pD3DDev->SetRenderState( D3DRS_DESTBLEND,				D3DBLEND_ONE );

		m_pTextureDisplay->Render( m_TD_RTT4ToFullScreen, false );
	}

	return( hr );
}


