/*--------------------------------------------------------------------- NVMH5 -|----------------------
Path:  Sdk\Demos\Direct3D9\src\AntiAliasingWithPostProcessing\
File:  AAPPDemo.h

Copyright NVIDIA Corporation 2003
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED *AS IS* AND NVIDIA AND
AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA
OR ITS SUPPLIERS BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER
INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF
BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THIS
SOFTWARE, EVEN IF NVIDIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


Comments:


-------------------------------------------------------------------------------|--------------------*/

#ifndef H_AAPPDemo_H
#define H_AAPPDemo_H

#include "NV_D3DCommon\NV_D3DCommonTypes.h"
struct IDirect3DDevice9;
class  AAPPScene;
class  RenderTargetSet;

class AAPPDemo
{
public:
	IDirect3DDevice9 *		m_pD3DDev;
	RenderTargetFactory *	m_pRenderTargetFactory;
	ITextureDisplay *		m_pTextureDisplay;

	AAPPScene *				m_pScene;
	RenderTargetSet	*		m_pDefaultBuffers;
	RenderTargetDesc **		m_ppRTTBackbufferCopy;
	RenderTargetDesc **		m_ppRTTHalfSize;
	RenderTargetDesc **		m_ppRTT3;
	RenderTargetDesc **		m_ppRTT4;
	TD_TEXID				m_TD_BackbufferCopy;
	TD_TEXID				m_TD_BackBufferCopyToFullScreen;
	TD_TEXID				m_TD_HalfSizeToFullScreen;
	TD_TEXID				m_TD_RTT3ToFullScreen;

	TD_TEXID				m_TD_RTT3_1;
	TD_TEXID				m_TD_RTT3_2;
	TD_TEXID				m_TD_RTT3_3;
	TD_TEXID				m_TD_RTT3_4;
	TD_TEXID				m_TD_RTT4ToFullScreen;

	bool	m_bCopyBackbufferAndPostProcess;

	HRESULT Free();
	HRESULT Initialize( IDirect3DDevice9 * pDev );
	LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
	HRESULT Render();

	AAPPDemo();
	~AAPPDemo();
	void SetAllNull()
	{
		m_pD3DDev					= NULL;
		m_pRenderTargetFactory		= NULL;
		m_pTextureDisplay			= NULL;
		m_pScene					= NULL;
		m_pDefaultBuffers			= NULL;
		m_ppRTTBackbufferCopy		= NULL;
		m_ppRTTHalfSize				= NULL;

		m_bCopyBackbufferAndPostProcess = true;
	}
};

#endif
