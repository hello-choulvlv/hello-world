/*--------------------------------------------------------------------- NVMH5 -|----------------------
Path:  Sdk\Demos\Direct3D9\src\AntiAliasingWithPostProcessing\
File:  AAPPScene.cpp

Copyright NVIDIA Corporation 2003
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED *AS IS* AND NVIDIA AND
AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL NVIDIA
OR ITS SUPPLIERS BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER
INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF
BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THIS
SOFTWARE, EVEN IF NVIDIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


Comments:


-------------------------------------------------------------------------------|--------------------*/

#include "NV_D3DCommon\NV_D3DCommon.h"
#include "NV_D3DMesh\NV_D3DMesh.h"
#include "AAPPScene.h"
#include "shared\NV_Common.h"
#include "shared\NV_Error.h"


AAPPScene::AAPPScene()
{
	SetAllNull();
}

AAPPScene::~AAPPScene()
{
	Free();
}

HRESULT	AAPPScene::Free()
{
	SAFE_RELEASE( m_pD3DDev );
	return( S_OK );
}

HRESULT	AAPPScene::Initialize( IDirect3DDevice9 * pDev )
{
	HRESULT hr = S_OK;
	FAIL_IF_NULL( pDev );
	Free();
	m_pD3DDev = pDev;
	m_pD3DDev->AddRef();

	CreatePinwheel( &m_CenterPinwheel,
						5,					// number of spokes
						0.35f,				// inner radius
						0.50f );			// outer radius
	CreateOuterRing( &m_OuterRing, 
						49,				// number of segments 
						0.5f,			// ratio of object size / gap size
						0.55f, 0.87f );	// inner & outer radii

	D3DXMatrixIdentity( &m_matInnerRing );
	return( hr );
}

HRESULT	AAPPScene::CreatePinwheel( MeshVB * pMeshVB, int num_fins, float inner_radius, float radius )
{
	HRESULT hr = S_OK;
	FAIL_IF_NULL( pMeshVB );
	FAIL_IF_NULL( m_pD3DDev );
	DBG_ONLY( MSG_AND_RET_VAL_IF( radius <= 0.0f, "CreatePinwheel() radius must be > 0\n", E_FAIL ));

	Mesh msh;
	MeshGeoCreator gc;
	gc.InitDisc( &msh, D3DXVECTOR3( 0.0f, 0.0f, 0.0f ), D3DXVECTOR3( 0.0, 0.0f, 1.0f ),
					radius, num_fins * 4 );
	// Depends on vertex 0 being at the center and outer ring of vertex going CCW around the edge
	// Indent notches around the perimeter
	UINT i;
	for( i=1; i < msh.GetNumVertices(); i++ )
	{
		if( i%4 == 1 || i%4 == 2 )
			msh.m_pVertices[i].pos = msh.m_pVertices[i].pos * inner_radius / radius; 
	}
	pMeshVB->CreateFromMesh( &msh, m_pD3DDev );
	return( hr );
}

//---------------------------------------------------------------------------------------
// Function name   : AAPPScene::CreateOuterRing
// Description     : Creates a ring of quad pie wedges
// Return type     :
// Argument        : int num_segments - The number of trapezoids to array in a circle
// Argument        : float frac_gap - Ratio of trapezoid size to the size of the gap between trapezoids
// Argument        : float inner_radius - Radius of the inner parts of the trapezoids
// Argument        : float outer_radius - Radius of the outer part of the trapezoids
//---------------------------------------------------------------------------------------
HRESULT	AAPPScene::CreateOuterRing( MeshVB * pMeshVB, int num_segments, float frac_gap, float inner_radius, float outer_radius )
{
	HRESULT hr = S_OK;
	FAIL_IF_NULL( pMeshVB );
	FAIL_IF_NULL( m_pD3DDev );

	float seg_start_ang, seg_end_ang;
	float ang_increment;
	ang_increment = 3.14159f * 2.0f / ((float)num_segments);
	seg_start_ang = 0.0f;
	seg_end_ang = seg_start_ang + ang_increment * frac_gap;
	// start the first one spaced evenly across 0.0f;
	seg_start_ang -= seg_end_ang / 2.0f;
	seg_end_ang   -= seg_end_ang / 2.0f;
	
	// Create space for a quad;
	MeshGeoCreator gc;
	Mesh msh;
	msh.Allocate( 4, 6 );
	msh.m_PrimType = D3DPT_TRIANGLELIST;
	// CCW winding order
	msh.m_pVertices[0].pos = D3DXVECTOR3( inner_radius * (float)cos( seg_start_ang ), inner_radius * (float)sin( seg_start_ang ), 0.5f );
	msh.m_pVertices[1].pos = D3DXVECTOR3( inner_radius * (float)cos( seg_end_ang ), inner_radius * (float)sin( seg_end_ang ), 0.5f );
	msh.m_pVertices[2].pos = D3DXVECTOR3( outer_radius * (float)cos( seg_end_ang ), outer_radius * (float)sin( seg_end_ang ), 0.5f );
	msh.m_pVertices[3].pos = D3DXVECTOR3( outer_radius * (float)cos( seg_start_ang ), outer_radius * (float)sin( seg_start_ang ), 0.5f );
	msh.m_pIndices[0] = 0;
	msh.m_pIndices[1] = 1;
	msh.m_pIndices[2] = 2;
	msh.m_pIndices[3] = 0;
	msh.m_pIndices[4] = 2;
	msh.m_pIndices[5] = 3;

	D3DXMATRIX matRotation;
	D3DXMatrixRotationZ( &matRotation, ang_increment );
	Mesh msha;
	hr = gc.InitArray( &msha, &msh, num_segments, matRotation );
	MSG_AND_RET_VAL_IF( FAILED(hr), "InitArray failed\n", hr );
	hr = pMeshVB->CreateFromMesh( &msha, m_pD3DDev );
	MSG_AND_RET_VAL_IF( FAILED(hr), "CreateFromMesh failed\n", hr );
	return( hr );
}

void AAPPScene::Animate( float fCurrentTimeInSeconds )
{
	D3DXMatrixRotationZ( &m_matInnerRing, fCurrentTimeInSeconds * 3.14159f * 0.05f );
}



