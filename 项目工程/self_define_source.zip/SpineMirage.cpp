//
//  SpineMirage.cpp
//  cocos2d_lua_bindings
//
//  Created by xiaoxiong2 on 2017/12/31.
//

#include <spine/spine.h>
#include <spine/SkeletonRenderer.h>
#include <spine/extension.h>
#include <spine/SkeletonBatch.h>
#include <spine/AttachmentVertices.h>
#include <spine/Cocos2dAttachmentLoader.h>

#include "SpineEntity.hpp"
#include "SpineMirage.hpp"
#include "SpineEntityManager.hpp"

using namespace cocos2d;

SpineMirage::SpineMirage()
{
    setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR_NO_MVP));
}

SpineMirage::~SpineMirage()
{
    changeActivateState(false);
    SpineEntityManager::getInstance()->destroyMirage(this);
    __entity = nullptr;
}

void SpineMirage::onEnter()
{
    Node::onEnter();
    changeActivateState(true);
}

void SpineMirage::onExit()
{
    Node::onExit();
    changeActivateState(false);
}

void SpineMirage::setVisible(bool visible)
{
    Node::setVisible(visible);
    changeActivateState(visible);
}

void SpineMirage::changeActivateState(bool activated)
{
    if(activated != __activated)
    {
        __activated = activated;
        SpineEntityManager::getInstance()->onActivateStateChanged(this);
    }
}

void SpineMirage::draw(cocos2d::Renderer* renderer, const cocos2d::Mat4& transform, uint32_t transformFlags)
{
    if(__entity == nullptr)
    {
        return;
    }

    spine::AttachmentVertices* attachmentVertices = nullptr;
    for (int i = 0, n = __entity->_skeleton->slotsCount; i < n; ++i) {
        spSlot* slot = __entity->_skeleton->drawOrder[i];
        if (!slot->attachment) continue;

        switch (slot->attachment->type) {
            case SP_ATTACHMENT_REGION: {
                spRegionAttachment* attachment = (spRegionAttachment*)slot->attachment;
                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
                break;
            }
            case SP_ATTACHMENT_MESH: {
                spMeshAttachment* attachment = (spMeshAttachment*)slot->attachment;
                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
                break;
            }
            default:
                continue;
        }

        BlendFunc blendFunc;
        switch (slot->data->blendMode) {
            case SP_BLEND_MODE_ADDITIVE:
                blendFunc.src = GL_ONE;
                blendFunc.dst = GL_ONE;
                break;
            case SP_BLEND_MODE_MULTIPLY:
                blendFunc.src = GL_DST_COLOR;
                blendFunc.dst = GL_ONE_MINUS_SRC_ALPHA;
                break;
            case SP_BLEND_MODE_SCREEN:
                blendFunc.src = GL_ONE;
                blendFunc.dst = GL_ONE_MINUS_SRC_COLOR;
                break;
            default:
                blendFunc.src = GL_ONE;
                blendFunc.dst = GL_ONE_MINUS_SRC_ALPHA;
        }
        
//        blendFunc.src = GL_ONE;
//        blendFunc.dst = GL_ONE_MINUS_SRC_ALPHA;

        SpineEntityManager::getInstance()->addCommand(renderer, _globalZOrder, attachmentVertices->_texture->getName(), _glProgramState, blendFunc,
                          *attachmentVertices->_triangles, transform, transformFlags);
    }
    
//    SpineEntityManager::getInstance()->addCommand(__entity, const_cast<cocos2d::Mat4*>(&transform));
}

void SpineMirage::initGLProgram()
{
    setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR_NO_MVP));
}
