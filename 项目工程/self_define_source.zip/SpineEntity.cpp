//
//  SpineEntity.cpp
//  cocos2d_lua_bindings
//
//  Created by xiaoxiong2 on 2017/12/31.
//

#include <spine/spine.h>
#include <spine/SkeletonRenderer.h>
#include <spine/extension.h>
#include <spine/SkeletonBatch.h>
#include <spine/AttachmentVertices.h>
#include <spine/Cocos2dAttachmentLoader.h>

#include "cocos2d.h"

#include "SpineEntityManager.hpp"
#include "SpineEntity.hpp"
#include "SpineMirage.hpp"

int spRegionAttachment_computeAttachmentVertices(spRegionAttachment* self, spBone* bone, cocos2d::V3F_C4B_T2F* vertices, int vertexOffset) {
    const float* offset = self->offset;
    float x = bone->skeleton->x + bone->worldX, y = bone->skeleton->y + bone->worldY;
    vertices[vertexOffset].vertices.x = offset[SP_VERTEX_X1] * bone->a + offset[SP_VERTEX_Y1] * bone->b + x;
    vertices[vertexOffset].vertices.y = offset[SP_VERTEX_X1] * bone->c + offset[SP_VERTEX_Y1] * bone->d + y;
    vertices[vertexOffset + 1].vertices.x = offset[SP_VERTEX_X2] * bone->a + offset[SP_VERTEX_Y2] * bone->b + x;
    vertices[vertexOffset + 1].vertices.y = offset[SP_VERTEX_X2] * bone->c + offset[SP_VERTEX_Y2] * bone->d + y;
    vertices[vertexOffset + 2].vertices.x = offset[SP_VERTEX_X3] * bone->a + offset[SP_VERTEX_Y3] * bone->b + x;
    vertices[vertexOffset + 2].vertices.y = offset[SP_VERTEX_X3] * bone->c + offset[SP_VERTEX_Y3] * bone->d + y;
    vertices[vertexOffset + 3].vertices.x = offset[SP_VERTEX_X4] * bone->a + offset[SP_VERTEX_Y4] * bone->b + x;
    vertices[vertexOffset + 3].vertices.y = offset[SP_VERTEX_X4] * bone->c + offset[SP_VERTEX_Y4] * bone->d + y;
    
    return 4;
}

int spVertexAttachment_computeAttachmentVertices(spVertexAttachment* self, int start, int count, spSlot* slot, cocos2d::V3F_C4B_T2F* attachmentVerts, int offset) {
    spSkeleton* skeleton;
    float x, y;
    int deformLength;
    float* deform;
    float* vertices;
    int* bones;
    
//    count += offset;
    skeleton = slot->bone->skeleton;
    x = skeleton->x;
    y = skeleton->y;
    deformLength = slot->attachmentVerticesCount;
    deform = slot->attachmentVertices;
    vertices = self->vertices;
    bones = self->bones;
    if (!bones) {
        spBone* bone;
        int v, w;
        if (deformLength > 0) vertices = deform;
        bone = slot->bone;
        x += bone->worldX;
        y += bone->worldY;
        for (v = start, w = 0; w < count / 2; v += 2, w += 1) {
            float vx = vertices[v], vy = vertices[v + 1];
            attachmentVerts[w + offset].vertices.x = vx * bone->a + vy * bone->b + x;
            attachmentVerts[w + offset].vertices.y = vx * bone->c + vy * bone->d + y;
        }
        return w;
    } else {
        int v = 0, skip = 0, i;
        spBone** skeletonBones;
        for (i = 0; i < start; i += 2) {
            int n = bones[v];
            v += n + 1;
            skip += n;
        }
        skeletonBones = skeleton->bones;
        if (deformLength == 0) {
            int w, b;
            for (w = 0, b = skip * 3; w < count / 2; w += 1) {
                float wx = x, wy = y;
                int n = bones[v++];
                n += v;
                for (; v < n; v++, b += 3) {
                    spBone* bone = skeletonBones[bones[v]];
                    float vx = vertices[b], vy = vertices[b + 1], weight = vertices[b + 2];
                    wx += (vx * bone->a + vy * bone->b + bone->worldX) * weight;
                    wy += (vx * bone->c + vy * bone->d + bone->worldY) * weight;
                }
                attachmentVerts[w + offset].vertices.x = wx;
                attachmentVerts[w + offset].vertices.y = wy;
            }
            return w;
        } else {
            int w, b, f;
            for (w = 0, b = skip * 3, f = skip << 1; w < count / 2; w += 1) {
                float wx = x, wy = y;
                int n = bones[v++];
                n += v;
                for (; v < n; v++, b += 3, f += 2) {
                    spBone* bone = skeletonBones[bones[v]];
                    float vx = vertices[b] + deform[f], vy = vertices[b + 1] + deform[f + 1], weight = vertices[b + 2];
                    wx += (vx * bone->a + vy * bone->b + bone->worldX) * weight;
                    wy += (vx * bone->c + vy * bone->d + bone->worldY) * weight;
                }
                attachmentVerts[w + offset].vertices.x = wx;
                attachmentVerts[w + offset].vertices.y = wy;
            }
            return w;
        }
    }
}

SpineEntity::SpineEntity()
{
    _textureName = 0;
    _vertexVBO = 0;
    _indexVBO = 0;
}

SpineEntity::~SpineEntity()
{
    spAnimationStateData_dispose(_state->data);
    spAnimationState_dispose(_state);
    spSkeletonData_dispose(_skeleton->data);
    spSkeleton_dispose(_skeleton);
    spAtlas_dispose(_atlas);
    spAttachmentLoader_dispose(_attachmentLoader);
}

void SpineEntity::setAnimation (int trackIndex, const std::string& name, bool loop) {
    spAnimation* animation = spSkeletonData_findAnimation(_skeleton->data, name.c_str());
    CCASSERT(animation, "[SpineEntity] No animation Found!!");
    spAnimationState_setAnimation(_state, trackIndex, animation, loop);
}

void SpineEntity::generateVertices()
{
    _vertexNumber = 0;
    _indexNumber = 0;
    
    for (int i = 0, n = _skeleton->slotsCount; i < n; ++i) {
        
        spSlot* slot = _skeleton->drawOrder[i];
        if (!slot->attachment) continue;
        
        cocos2d::Color4B color;
        color.a = slot->a * 255;
        color.r = slot->r * color.a;
        color.g = slot->g * color.a;
        color.b = slot->b * color.a;
        
        spine::AttachmentVertices* attachmentVertices = nullptr;
        
        switch (slot->attachment->type) {
            case SP_ATTACHMENT_REGION: {
                spRegionAttachment* attachment = (spRegionAttachment*)slot->attachment;
                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
                expendVertices(attachmentVertices, color);
                expendIndices(attachmentVertices, color);
                
                break;
            }
            case SP_ATTACHMENT_MESH: {
                
                spMeshAttachment* attachment = (spMeshAttachment*)slot->attachment;
                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
                expendVertices(attachmentVertices, color);
                expendIndices(attachmentVertices, color);
                
                break;
            }
            default:
                continue;
        }
        
        _textureName = attachmentVertices->_texture->getName();
    }
    
    if(_vertexNumber > 0)
    {
        _vertices = &_verticesContainer[0];
        
        glGenBuffers(1, &_vertexVBO);
        glBindBuffer(GL_ARRAY_BUFFER, _vertexVBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(cocos2d::V3F_C4B_T2F) * _vertexNumber, _vertices, GL_DYNAMIC_DRAW);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
    }
    
    if(_indexNumber > 0)
    {
        _indices = &_indicesContainer[0];
        
        glGenBuffers(1, &_indexVBO);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexVBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLushort) * _indexNumber, _indices, GL_STATIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    }
}

void SpineEntity::expendVertices(spine::AttachmentVertices* attachment, cocos2d::Color4B color)
{
    int count = attachment->_triangles->vertCount;
    _verticesContainer.resize(_vertexNumber + count);
    
    for(int index = _vertexNumber; index < _vertexNumber + count; index++)
    {
        attachment->_triangles->verts[index - _vertexNumber].colors = color;
        _verticesContainer[index] = attachment->_triangles->verts[index - _vertexNumber];
    }
    
    _vertexNumber = _vertexNumber + count;
}

void SpineEntity::expendIndices(spine::AttachmentVertices* attachment, cocos2d::Color4B color)
{
    int count = attachment->_triangles->indexCount;
    _indicesContainer.resize(_indexNumber + count);
    
    for(int index = _indexNumber; index < _indexNumber + count; index++)
    {
        _indicesContainer[index] = attachment->_triangles->indices[index - _indexNumber];
    }
    
    _indexNumber = _indexNumber + count;
}

void SpineEntity::update(float dt)
{
    spSkeleton_update(_skeleton, dt);
    spAnimationState_update(_state, dt);
    spAnimationState_apply(_state, _skeleton);
    spSkeleton_updateWorldTransform(_skeleton);
    
//    int vertexCount = 0;
//
//    for (int i = 0, n = _skeleton->slotsCount; i < n; ++i) {
//
//        spSlot* slot = _skeleton->drawOrder[i];
//        if (!slot->attachment) continue;
//
//        spine::AttachmentVertices* attachmentVertices = nullptr;
//
//        switch (slot->attachment->type) {
//            case SP_ATTACHMENT_REGION: {
//                spRegionAttachment* attachment = (spRegionAttachment*)slot->attachment;
//                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
//                vertexCount += spRegionAttachment_computeAttachmentVertices(attachment, slot->bone, _vertices, vertexCount);
//
//                break;
//            }
//            case SP_ATTACHMENT_MESH: {
//                spMeshAttachment* attachment = (spMeshAttachment*)slot->attachment;
//                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
//                vertexCount += spVertexAttachment_computeAttachmentVertices(SUPER(attachment), 0, SUPER(attachment)->worldVerticesLength, slot, _vertices, vertexCount);
//
//                break;
//            }
//            default:
//                continue;
//        }
//    }
    
    for (int i = 0, n = _skeleton->slotsCount; i < n; ++i) {
        
        spSlot* slot = _skeleton->drawOrder[i];
        if (!slot->attachment) continue;
        
        spine::AttachmentVertices* attachmentVertices = nullptr;
        
        switch (slot->attachment->type) {
            case SP_ATTACHMENT_REGION: {
                spRegionAttachment* attachment = (spRegionAttachment*)slot->attachment;
                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
                spRegionAttachment_computeAttachmentVertices(attachment, slot->bone, attachmentVertices->_triangles->verts, 0);
                
                break;
            }
            case SP_ATTACHMENT_MESH: {
                spMeshAttachment* attachment = (spMeshAttachment*)slot->attachment;
                attachmentVertices = (spine::AttachmentVertices*)attachment->rendererObject;
                spVertexAttachment_computeAttachmentVertices(SUPER(attachment), 0, SUPER(attachment)->worldVerticesLength, slot, attachmentVertices->_triangles->verts, 0);
                
                break;
            }
            default:
                continue;
        }
        
        cocos2d::Color4B color;
        color.a = slot->a * 255;
        color.r = slot->r * color.a;
        color.g = slot->g * color.a;
        color.b = slot->b * color.a;

        for (int v = 0, w = 0, vn = attachmentVertices->_triangles->vertCount; v < vn; ++v, w += 2) {
            cocos2d::V3F_C4B_T2F* vertex = attachmentVertices->_triangles->verts + v;
            vertex->colors.r = (GLubyte)color.r;
            vertex->colors.g = (GLubyte)color.g;
            vertex->colors.b = (GLubyte)color.b;
            vertex->colors.a = (GLubyte)color.a;
        }
    }
}

std::string& SpineEntity::getName()
{
    return _name;
}
