//
//  PathMath.hpp
//  swtest
//
//  Created by charlie on 2017/5/30.
//
//

#ifndef PathMath_hpp
#define PathMath_hpp

#include <stdio.h>

class lua_State;

void register_all_path_math(lua_State* L);

#endif /* PathMath_hpp */
