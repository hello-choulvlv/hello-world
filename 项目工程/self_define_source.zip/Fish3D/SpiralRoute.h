/*
  *螺旋曲线
  *@date:2017-07-15
  *@Author:xiaoxiong
 */
#ifndef __SPIRAL_ROUTE_H__
#define __SPIRAL_ROUTE_H__
#include "cocos2d.h"
/*
  *SpriralRoute对应着螺旋曲线路径,其采用的算法与编辑器中的算法完全一致
  *为了简化所有的旋转与平移运算,与编辑器中的算法一样,该算法使用了四阶矩阵
 */
class SpiralRoute
{
	//模型矩阵
	cocos2d::Mat4 _trMatrix;//平移旋转矩阵
	//旋转轴
	cocos2d::Vec3  _rotateAxis;
	//中心坐标
	cocos2d::Vec3  _centerLocation;
	//
	//导程
	float                   _spiralHeight;
	//匝数
	float                   _windCount;
	//下半径
	float                   _radius0;
	//上半径
	float                  _radius1;
	//曲线的旋转方向,默认为逆时针(1.0f)
	float                 _clockwise;
	//螺旋曲线的长度
	float                  _length;
	//总高度
	float                 _height;
	//
	std::vector<cocos2d::Vec3 >   _pathPointVec;
	std::vector<cocos2d::Vec3>    _anglePointVec;
private:
	void                  init(const std::vector<cocos2d::Vec3> &controlPoints);
	//计算曲线的长度
	float                 getSpiralLengthPrivate();
public:
	SpiralRoute();
	//传入控制点
	static SpiralRoute *create(const std::vector<cocos2d::Vec3> &controlPoints);
	//获取曲线的长度
	inline float      getSpiralLength()const { return _length; };
	//对于任意给定的已经行走的路程,计算实际的坐标,切线
	//distance表示已经走过的路径
	void   getPositionAndTangent(float distance,cocos2d::Vec3 &position,cocos2d::Vec3 &tangent);
	//以时间比率来计算需要行走的坐标,切线
	void  getPositionAndTangentByRate(float rate, cocos2d::Vec3 &position, cocos2d::Vec3 &tangent);
	/*
	  *将曲线的各个点进行预计算,并进行存储
	 */
	void  precalculate();
	/*
	  *提取数据
	 */
	void  extract(float distance,cocos2d::Vec3  &position,cocos2d::Vec3 &tangent)const;
};
/*
  *为黑洞旋涡特效而设计的空间螺旋线运动
  *选我运动的中心轴为+Z轴,并且是向心运动
  *此螺旋线的本质为阿基米德螺旋线
 */
class ActionVortex :public cocos2d::ActionInterval
{
private:
	cocos2d::Vec3 _originPosition;
	cocos2d::Vec3 _centerPosition;
	//顺时针还是逆时针,如果逆时针为1,顺时针为-1
	float                  _clockWind;
	//终止半径
	float					_terminalRadius;
	//一种需要持续的周期,单位为弧度
	float                _totalAngle;
	//当前需要行走过的XOY平面的距离
	float               _xoyDistance;
	//物体的起始角度
	float               _startAngle;
private:
	ActionVortex();
	void    initWithVortex(float duration, float angleSpeed, float windClock, const cocos2d::Vec3 &location, const cocos2d::Vec3 &center, float  finalRadius);
public:
	static ActionVortex  *create(float duration, float angleSpeed, float windClock, const cocos2d::Vec3 &location, const cocos2d::Vec3 &center, float  finalRadius);
	/*
	*计算位置与切线
	*/
	virtual void update(float time);
};

#endif