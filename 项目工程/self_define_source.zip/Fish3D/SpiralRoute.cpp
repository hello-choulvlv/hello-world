/*
  *螺旋曲线实现
  *2017-07-15
  *@Author:xiaoxiong
 */
#include "SpiralRoute.h"

SpiralRoute::SpiralRoute() :
	_length ( 0.0f)
	, _windCount(0.0f)
	, _radius0(0.0f)
	, _radius1(0.0f)
	, _clockwise(1.0f)
	, _spiralHeight(0.0f)
	, _height(0.0f)
{

}

void SpiralRoute::init(const std::vector<cocos2d::Vec3> &controlPoints)
{
	//旋转轴
	_rotateAxis = controlPoints[0];
	_centerLocation = controlPoints[1];
	auto &point = controlPoints[2];
	_radius0 = point.x;
	_radius1 = point.y;
	_spiralHeight = point.z;
	_windCount = controlPoints[3].x;
	_clockwise = controlPoints[3].y;
	//变换矩阵
	const cocos2d::Vec3 upVec(0.0f, 1.0f, 0.0f);
	cocos2d::Vec3 axis;
	cocos2d::Mat4 translateM, rotateM;
	cocos2d::Vec3::cross(upVec, _rotateAxis, &axis);
	//////////////////////////////////////////
	cocos2d::Mat4::createTranslation(_centerLocation, &translateM);
	const float dotValue = cocos2d::Vec3::dot(_rotateAxis, upVec);
	float   angle = acosf(dotValue);
	cocos2d::Mat4::createRotation(axis, angle, &rotateM);
	_trMatrix = translateM * rotateM;
	//计算曲线的长度
	_length = getSpiralLengthPrivate();
	_height = _spiralHeight * _windCount;
}

SpiralRoute *SpiralRoute::create(const std::vector<cocos2d::Vec3> &controlPoints)
{
	SpiralRoute *rout = new SpiralRoute();
	rout->init(controlPoints);
	return rout;
}

float SpiralRoute::getSpiralLengthPrivate()
{
	//计算曲线的长度
	const int integrity = (int)_windCount;//完整的周期
	const float frag = _windCount - integrity;//剩余的不足一个的周期
	float length = 0.0f;
	const float realRadius = _radius0 + (_radius1 - _radius0) / _windCount * integrity;
	for (int k = 1; k <= integrity; ++k)
	{
		float lastRadius = _radius0 + 1.0f *(k - 1) / integrity * (realRadius - _radius0);
		float nowRadius = _radius0 + 1.0f *k / integrity * (realRadius - _radius0);
		float tmp = (lastRadius + nowRadius)*M_PI;
		length += sqrtf(tmp * tmp + _spiralHeight * _spiralHeight);
	}
	//累计上剩余的尾巴
	float tmp = M_PI *(realRadius + realRadius + 1.0f / integrity *(realRadius - _radius0));
	length += frag * sqrtf(tmp * tmp + _spiralHeight * _spiralHeight);
	return length;
}

//计算坐标,切线
void SpiralRoute::getPositionAndTangent(float distance, cocos2d::Vec3 &position, cocos2d::Vec3 &tangent)
{
	const float rate = distance / _length;
	const float height = _spiralHeight *_windCount;
	const float halfHeight = height *0.5f;
	const float paix2 = 2.0f *M_PI * _clockwise;
	const float totalAngle = paix2 * _windCount;
	float  angle = rate * totalAngle;
	float  radius = _radius0 + (_radius1 - _radius0)*angle / totalAngle;
	float  y = _spiralHeight * angle / paix2 - halfHeight;
	float  sinValue = sinf(angle);
	float  cosValue = cosf(angle);
	float  x = radius * sinValue;
	float  z = radius * cosValue;
	//变换坐标系
	cocos2d::Vec4 newPoint = _trMatrix * cocos2d::Vec4(x, y, z, 1.0f);
	position = cocos2d::Vec3(newPoint.x, newPoint.y, newPoint.z);
	//计算切线
	const float c = paix2 * _windCount;
	const float dx = radius * cosValue * c;
	const float dy = _spiralHeight / paix2 * c;
	const float dz = -radius * sinValue * c;
	tangent = _trMatrix * cocos2d::Vec3(dx, dy, dz);
}

void SpiralRoute::getPositionAndTangentByRate(float rate, cocos2d::Vec3 &position, cocos2d::Vec3 &tangent)
{
	const float height = _spiralHeight *_windCount;
	const float halfHeight = height *0.5f;
	const float paix2 = 2.0f *M_PI * _clockwise;
	const float totalAngle = paix2 * _windCount;
	float  angle = rate * totalAngle;
	float  radius = _radius0 + (_radius1 - _radius0)*angle / totalAngle;
	float  y = _spiralHeight * angle / paix2 - halfHeight;
	float  sinValue = sinf(angle);
	float  cosValue = cosf(angle);
	float  x = radius * sinValue;
	float  z = radius * cosValue;
	//变换坐标系
	cocos2d::Vec4 newPoint = _trMatrix * cocos2d::Vec4(x, y, z, 1.0f);
	position = cocos2d::Vec3(newPoint.x, newPoint.y, newPoint.z);
	//计算切线
	const float c = paix2 * _windCount;
	const float dx = radius * cosValue * c;
	const float dy = _spiralHeight / paix2 * c;
	const float dz = -radius * sinValue * c;
	tangent = _trMatrix * cocos2d::Vec3(dx, dy, dz);
}

void SpiralRoute::precalculate()
{
	_pathPointVec.reserve(_length+1);
	_anglePointVec.reserve(_length + 1);
	//
	cocos2d::Vec3 position, angle;
	int     distance = (int)(_length+1);
	for (int k = 0; k < distance; ++k)
	{
		getPositionAndTangentByRate(k / _length,position,angle);
		_pathPointVec.push_back(position);
		_anglePointVec.push_back(angle);
	}
	getPositionAndTangentByRate(1.0f, position, angle);
	_pathPointVec.push_back(position);
	_anglePointVec.push_back(angle);
}

void SpiralRoute::extract(float distance,cocos2d::Vec3 &position, cocos2d::Vec3 &tangent)const
{
	position = _pathPointVec[distance];
	tangent = _anglePointVec[distance];
}


/*
*空间阿基米德螺旋线实现
*2017-9-23 17:33:50
*@Author:xiaohuaxiong
*/
ActionVortex::ActionVortex() :
	_clockWind(1),
	_terminalRadius(0),
	_totalAngle(0),
	_startAngle(0)
{

}

ActionVortex *ActionVortex::create(float duration, float angleSpeed, float windClock, const cocos2d::Vec3 &location, const cocos2d::Vec3 &center, float finalRadius)
{
	ActionVortex *action = new ActionVortex();
	action->initWithVortex(duration, angleSpeed, windClock, location, center, finalRadius);
	action->autorelease();
	return action;
}

void ActionVortex::initWithVortex(float duration, float angleSpeed, float windClock, const cocos2d::Vec3 &location, const cocos2d::Vec3 &center, float finalRadius)
{
	cocos2d::ActionInterval::initWithDuration(duration);
	/*
	*计算所有的程序需要的数据
	*/
	float dx = location.x - center.x;
	float dy = location.y - center.y;
	//需要走过的XOY平面的路程
	_xoyDistance = sqrtf(dx*dx + dy*dy) - finalRadius;
	_terminalRadius = finalRadius;
	//原始位置与中心坐标
	_originPosition = location;
	_centerPosition = center;
	_clockWind = windClock;
	//计算需要经过的周期数
	_totalAngle = angleSpeed * duration;
	//计算起始角度
	_startAngle = atan2f(dy, dx);
}

void ActionVortex::update(float time)
{
	//计算XOY平面的坐标
	float currentAngle = _clockWind * time * _totalAngle + _startAngle;
	float one_t = 1.0 - time;
	float currentDistance = _xoyDistance * one_t + _terminalRadius;
	float x = _centerPosition.x + currentDistance * cosf(currentAngle);
	float y = _centerPosition.y + currentDistance * sinf(currentAngle);;
	//计算Z值
	float z = _originPosition.z + (_centerPosition.z - _originPosition.z) * time;
	_target->setPosition3D(cocos2d::Vec3(x, y, z));
	//计算XOY平面的旋转角度
	_target->setRotation(-_clockWind * time * _totalAngle * 180 / M_PI * 3.0);
}
