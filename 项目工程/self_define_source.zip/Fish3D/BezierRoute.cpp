//
//  BezierRoute.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/10.
//
//

#include "BezierRoute.hpp"
#define vec_fast_push_back(vec,s){if(vec.size() >= vec.capacity())vec.reserve(vec.size() * 2);vec.push_back(s);}
using namespace cocos2d;

BezierRoute::BezierRoute() :
//_points(std::vector<PointInfo>()),
_position(0),
//_valueCache(Vec3(0, 0, 0)),
//_tangentCache(Vec3(0, 0, 0)),
_precision(1.0),
_ended(false),
_distance(0)
{}

void BezierRoute::addPoints(std::vector<PointInfo>& points)
{
    clear();
    _points.insert(_points.end(), points.begin(), points.end());
    buildParameters();
}

//cocos2d::Vec3 BezierRoute::getDirection(float t)
//{
//    return caculateValue(t);
//}

//cocos2d::Vec3 BezierRoute::getLocation(float t)
//{
//    return caculateTangent(t);
//}

const cocos2d::Vec3& BezierRoute::getCurrentDirection()const
{
    return _tangentCache;
}

const cocos2d::Vec3& BezierRoute::getCurrentLocation()const
{
    return _valueCache;
}

void BezierRoute::advanceTo(float t)
{
	//t = fminf(1.0f,fmaxf(0.0f,t));// t < 0 ? 0 : t;
	//t = fminf(t,1.0f); t > 1 ? 1 : t;
    
	_position = fminf(1.0f, fmaxf(0.0f, t));// t;
    
    //_valueCache = caculateValue(_position);
	//_tangentCache = caculateTangent(_position);
	caculateValue(_position, _valueCache);
    caculateTangent(_position, _tangentCache);
}

void BezierRoute::advanceBy(float deltaDist)
{
    advanceTo(getPositionByDeltaDistance(deltaDist));
}


bool BezierRoute::isEnded()
{
    return _ended;
}

CubicBezierRoute::CubicBezierRoute() :BezierRoute(),
//_controlPoints(std::vector<cocos2d::Vec3>()),
//_caculatedParameters(std::vector<CaculatedParameter>()),
_currentStartIndex(1),
_weight(0.5){}

CubicBezierRoute* CubicBezierRoute::create()
{
    CubicBezierRoute* pRet = new CubicBezierRoute();
   // pRet->init();
   // pRet->autorelease();
    return pRet;
}

void CubicBezierRoute::setWeight(float weight)
{
    _weight = weight;
}

//std::vector<CubicBezierRoute::CaculatedParameter>& CubicBezierRoute::getParameters()
//{
//    return _caculatedParameters;
//}

void CubicBezierRoute::buildParameters()
{
    size_t pointNumber = _points.size();
    
    if(pointNumber == 0)
    {
        return;
    }
    
	_controlPoints.reserve(pointNumber * 2);
    for(size_t i = 0; i < pointNumber; i++)
    {
#if 0
		size_t index_back = (pointNumber + i - 1) % pointNumber;
		size_t index_forward = (i + 1) % pointNumber;
		Vec3 mid_back = (_points[index_back].position + _points[i].position) / 2;
		Vec3 mid_forward = (_points[index_forward].position + _points[i].position) / 2;
		float dist_back = _points[index_back].position.distance(_points[i].position);
		float dist_forward = _points[index_forward].position.distance(_points[i].position);
		Vec3 control_point_back = (mid_back - mid_forward) * dist_back * _weight / (dist_back + dist_forward) + _points[i].position;
		Vec3 control_point_forward = (mid_forward - mid_back) * dist_forward * _weight / (dist_back + dist_forward) + _points[i].position;

		_controlPoints.push_back(control_point_back);
		_controlPoints.push_back(control_point_forward);
#endif

        size_t index_back = (pointNumber + i - 1) % pointNumber;
		size_t index_forward = (i + 1) % pointNumber;

		auto &back_point = _points[index_back];
		auto &forward_point = _points[index_forward];
		auto &now_point = _points[i];

        Vec3 mid_back = (back_point.position + now_point.position) * 0.5f;
        Vec3 mid_forward = (forward_point.position + now_point.position) * 0.5f;

        float dist_back = back_point.position.distance(now_point.position);
        float dist_forward = forward_point.position.distance(now_point.position);

		const Vec3 t_vec = _weight / (dist_back + dist_forward) * (mid_back - mid_forward);

        const Vec3 control_point_back = dist_back * t_vec + now_point.position;
        const Vec3 control_point_forward = -dist_forward  * t_vec + now_point.position;

		//Vec3 control_point_back = (mid_back - mid_forward) * dist_back * _weight / (dist_back + dist_forward) + _points[i].position;
		//Vec3 control_point_forward = (mid_forward - mid_back) * dist_forward * _weight / (dist_back + dist_forward) + _points[i].position;
        
        //_controlPoints.push_back(control_point_back);
        //_controlPoints.push_back(control_point_forward);

		vec_fast_push_back(_controlPoints, control_point_back);
		vec_fast_push_back(_controlPoints, control_point_forward);
    }
    
	CaculatedParameter param;
	int a_3 = pointNumber * 2;

	_caculatedParameters.reserve(pointNumber);
    for(size_t i = 0; i < pointNumber; i ++)
    {
		int i2 = i * 2 + 1;

        const Vec3& p0 = _points[i].position;
        const Vec3& p1 = _controlPoints[i2% a_3];
        const Vec3& p2 = _controlPoints[(i2 + 1) % a_3];
        const Vec3& p3 = _points[(i + 1) % pointNumber].position;
        
        //CaculatedParameter param;
		const Vec3 p1_3 = 3.0f * p1;
		const Vec3 p0_3 = 3.0f * p0;

        param.a = -1.0f * p0 + p1_3 - 3.0f * p2 + p3;
        param.b = p0_3 - 6.0f * p1 + 3.0f * p2;
        param.c = -p0_3 + p1_3;
        param.d =      p0;
        
        param.da = -p0_3 +  9.0f * p1 - 9.0f * p2 + 3.0f * p3;
        param.db =  6.0f * p0 - 12.0f * p1 + 6.0f * p2;
        param.dc = -p0_3 + p1_3;
        
        //_caculatedParameters.push_back(param);
		vec_fast_push_back(_caculatedParameters, param);
    }
    
    _points[0].segmentDistance = 0;
    _points[pointNumber - 1].segmentDistance = 0;
    
    if(pointNumber < 4)
    {
        _distance = 0;
        //_cachedPosition.push_back(getCurrentLocation());
        //_cachedDirection.push_back(getCurrentDirection());

		vec_fast_push_back(_cachedPosition, getCurrentLocation());
		vec_fast_push_back(_cachedDirection, getCurrentDirection());
        
        for(int i = 1; i < pointNumber - 1; i++)
        {
            _points[i].segmentDistance = 0;
        }
        
        return;
    }
    else
    {
        int index = 1;
        float t = 0;
        const CaculatedParameter &p = _caculatedParameters[index];

		_cachedPosition.reserve(1624);
		_cachedDirection.reserve(1624);

		float t2 = t * t;
        Vec3 position = t2 * t * p.a + t2 * p.b + t * p.c + p.d;
        Vec3 direction = t2 * p.da + t * p.db + p.dc;
        _distance = 0;
        _points[index].segmentDistance = _distance;

		vec_fast_push_back(_cachedPosition,position);
		vec_fast_push_back(_cachedDirection, direction);
        //_cachedPosition.push_back(position);
        //_cachedDirection.push_back(direction);
        
		const CaculatedParameter *param_ptr = &p;
        do
        {
            float base = direction.length();
            //t = t + 1.0f / base;
			t += 1.0f / base;

            _distance++;
            
            if(t > 1)
            {
                index++;
                _points[index].segmentDistance = _distance;
                t = 0;
                //p = _caculatedParameters[index];
				param_ptr = _caculatedParameters.data() + index;
            }
            
			float t2 = t * t;
			float t3 = t * t2;
			position.x = param_ptr->d.x;
			position.y = param_ptr->d.y;
			position.z = param_ptr->d.z;

			direction.x = param_ptr->dc.x;
			direction.y = param_ptr->dc.y;
			direction.z = param_ptr->dc.z;

			//position = t2 * t * param_ptr->a + t2 * param_ptr->b + t * param_ptr->c;// +param_ptr->d;
			//direction = t2 * param_ptr->da + t * param_ptr->db;// +param_ptr->dc;

			position.x += param_ptr->a.x * t3 + param_ptr->b.x * t2 + param_ptr->c.x * t;
			position.y += param_ptr->a.y * t3 + param_ptr->b.y * t2 + param_ptr->c.y * t;
			position.z += param_ptr->a.z * t3 + param_ptr->b.z * t2 + param_ptr->c.z * t;

			direction.x += param_ptr->da.x * t2 + param_ptr->db.x * t;
			direction.y += param_ptr->da.y * t2 + param_ptr->db.y * t;
			direction.z += param_ptr->da.z * t2 + param_ptr->db.z * t;
            
            //_cachedPosition.push_back(position);
            //_cachedDirection.push_back(direction);
			vec_fast_push_back(_cachedPosition, position);
			vec_fast_push_back(_cachedDirection, direction);
        }
        while(index < pointNumber - 2);
    }
    
    //for(int i = 0; i < pointNumber; i++)
    {
//        printf("%d\n", _points[i].segmentDistance);
    }
    
    if(pointNumber < 4)
    {
        //_cachedSpeedCoef.push_back(_points[0].speedCoef);
		vec_fast_push_back(_cachedSpeedCoef, _points[0].speedCoef);
    }
    else
    {
        int index = 2;
        int distance = 0;
        //_cachedSpeedCoef.push_back(_points[0].speedCoef);
		_cachedSpeedCoef.reserve(1024);
		vec_fast_push_back(_cachedSpeedCoef, _points[0].speedCoef);
        
        do
        {
            distance = distance + 1;
            
            if(distance >= _points[index].segmentDistance)
            {
                //_cachedSpeedCoef.push_back(_points[index].speedCoef);
				vec_fast_push_back(_cachedSpeedCoef, _points[index].speedCoef);
                index++;
            }
            else
            {
                float prevCoef = _points[index - 1].speedCoef;
                float nextCoef = _points[index].speedCoef;
                float prevDistance = _points[index - 1].segmentDistance;
                float nextDistance = _points[index].segmentDistance;
                float offsetDistance = distance - prevDistance;
                float t = offsetDistance / (nextDistance - prevDistance);
                
                //_cachedSpeedCoef.push_back(prevCoef * (1 - t) + nextCoef * t);
				vec_fast_push_back(_cachedSpeedCoef, prevCoef * (1 - t) + nextCoef * t);
            }
        }
        while(index < pointNumber - 1);
    }
    
    return;
}

void CubicBezierRoute::caculateTangent(float position,cocos2d::Vec3 &new_tangent)
{
    if(_points.size() > 3)
    {
        CaculatedParameter& param = _caculatedParameters[_currentStartIndex];
        
		new_tangent.x = param.dc.x;
		new_tangent.y = param.dc.y;
		new_tangent.z = param.dc.z;

		new_tangent += _position * _position * param.da + _position * param.db;

        //return _position * _position * param.da + _position * param.db + param.dc;
    }
    else
    {
        //return Vec3(0, 0, 0);
		new_tangent.x = 0.0f;
		new_tangent.y = 0.0f;
		new_tangent.z = 0.0f;
    }
}

void CubicBezierRoute::caculateValue(float position,cocos2d::Vec3 &new_position)
{
    if(_points.size() > 3)
    {
        const CaculatedParameter& param = _caculatedParameters[_currentStartIndex];
        
		float t2 = _position * _position;
		new_position.x = param.d.x;
		new_position.y = param.d.y;
		new_position.z = param.d.z;

		new_position += t2 * _position * param.a + t2 * param.b + _position * param.c;

        //return t2 * _position * param.a + t2 * param.b + _position * param.c + param.d;
    }
    else
    {
        //return Vec3(0, 0, 0);
		new_position.x = 0.0f;
		new_position.y = 0.0f;
		new_position.z = 0.0f;
    }
}

float CubicBezierRoute::getPositionByDeltaDistance(float deltaDistance)
{
    if(_points.size() < 4)
    {
        _ended = true;
        return 0;
    }
    
    float newPosition = _position;
    
    while ((!_ended) && deltaDistance > 0) {
        
        float delta = deltaDistance < _precision ? deltaDistance : _precision;
        float length = getCurrentDirection().length();
        length = length > 0 ? length : 0.0001f;
        
        newPosition = newPosition + delta / length;
        
        if(newPosition >= 1)
        {
            newPosition = 0;
            _currentStartIndex = _currentStartIndex + 1;
        }
        
        deltaDistance = deltaDistance - delta;
        
        if(_currentStartIndex == _points.size() - 2)
        {
            _ended = true;
        }
    }
    
    return newPosition;
}

void CubicBezierRoute::reset()
{
    _position = 0;
    _currentStartIndex = 1;
    //_valueCache = caculateValue(_position);
    //_tangentCache = caculateValue(_position);

	caculateValue(_position, _valueCache);
	_tangentCache = _valueCache;

    _ended = false;
}

void CubicBezierRoute::clear()
{
    _points.clear();
    _controlPoints.clear();
    _caculatedParameters.clear();
    _cachedPosition.clear();
    _cachedSpeedCoef.clear();
    _distance = 0;
    
    reset();
}

void CubicBezierRoute::calculateDistance()
{
    float counter = 0;
    
    if(_points.size() < 4)
    {
        _distance = 0;
       // _cachedPosition.push_back(getCurrentLocation());
        //_cachedDirection.push_back(getCurrentDirection());

		vec_fast_push_back(_cachedPosition, getCurrentLocation());
		vec_fast_push_back(_cachedDirection, getCurrentDirection());
        return;
    }
    
    advanceBy(0);
    //_cachedPosition.push_back(getCurrentLocation());
    //_cachedDirection.push_back(getCurrentDirection());
	vec_fast_push_back(_cachedPosition, getCurrentLocation());
	vec_fast_push_back(_cachedDirection, getCurrentDirection());
    
    do
    {
        advanceBy(_precision);
        //_cachedPosition.push_back(getCurrentLocation());
        //_cachedDirection.push_back(getCurrentDirection());
		vec_fast_push_back(_cachedPosition, getCurrentLocation());
		vec_fast_push_back(_cachedDirection, getCurrentDirection());
        counter++;
    }
    while(!_ended);
        
    _distance = counter * _precision;
}

float CubicBezierRoute::getDistance()
{
    return _distance;
}

void CubicBezierRoute::relativeAdvance(int index, float& t, float& deltaDistance, Vec3& currentPosition, Vec3& currentDirection)
{
    CaculatedParameter& p = _caculatedParameters[index];
    currentDirection = (t * t) * p.da + (t) * p.db + p.dc;
    
    while(t < 1 && deltaDistance > 0)
    {
        float tPrevious = t;
        float pace = deltaDistance < _precision ? deltaDistance : _precision;
        float length = currentDirection.length();
        
        length = length > 0 ? length : 0.0001f;
        
        t = tPrevious + pace / length;
        
        if(t >= 1)
        {
            t = 1.0;
            pace = (1.0 - tPrevious) * length;
        }
        
        deltaDistance = deltaDistance - pace;
        currentDirection = (t * t) * p.da + (t) * p.db + p.dc;
    }
    
	float t2 = t * t;
    currentPosition = t2 * t * p.a + t2 * p.b + t * p.c + p.d;
}

void CubicBezierRoute::retrieveState(cocos2d::Vec3& position, cocos2d::Vec3& direction, float& speedCoef, float& overflow, float distance)
{
    if(distance == 0)
    {
        position = _cachedPosition[0];
        direction = _cachedDirection[0];
        speedCoef = _cachedSpeedCoef[0];
        overflow = 0;
    }
    else if(distance > _distance)
    {
        position = _cachedPosition[_distance];
        direction = _cachedDirection[_distance];
        speedCoef = _cachedSpeedCoef[_distance];
        overflow = distance - _distance;
    }
    else
    {
        int index = distance;
        position = _cachedPosition[index];
        direction = _cachedDirection[index];
        speedCoef = _cachedSpeedCoef[index];
        overflow = 0;
    }
}
