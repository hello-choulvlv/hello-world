//
//  GameDebugger.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/5.
//
//

#ifndef GameDebugger_hpp
#define GameDebugger_hpp

#include "cocos2d.h"

class GameDebugger
{
private:
    static GameDebugger* __sInstance;
    
public:
    static GameDebugger* getInstance();
    void debugCollisionManager();
    void initWithScene(cocos2d::Scene* scene);
    void update(float dt);
    
private:
    cocos2d::DrawNode* __drawNode;
    cocos2d::Scene* __scene;
};

#endif /* GameDebugger_hpp */
