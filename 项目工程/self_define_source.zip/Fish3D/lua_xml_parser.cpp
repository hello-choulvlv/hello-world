//
//  lua_xml_parser.cpp
//  simulator
//
//  Created by charlie on 2017/6/2.
//
//

#include "lua_xml_parser.hpp"
#include "XMLParser.h"
#include "SpiralRoute.h"
#include "cocos/scripting/lua-bindings/manual/tolua_fix.h"
#include "cocos/scripting/lua-bindings/manual/LuaBasicConversions.h"
#include "cocos/scripting/lua-bindings/manual/swgadget/Fish3D/effect/WaterSimulate.h"
#include "cocos/scripting/lua-bindings/manual/swgadget/Fish3D/effect/ShaderNode.h"

int lua_custom_net_XMLParser_init(lua_State* tolua_S)
{
    int argc = 0;
    custom::XMLParser* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"custom.XMLParser",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (custom::XMLParser*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_custom_net_XMLParser_init'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_custom_net_XMLParser_init'", nullptr);
            return 0;
        }
        bool ret = cobj->init();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "custom.XMLParser:init",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_custom_net_XMLParser_init'.",&tolua_err);
#endif
    
    return 0;
}
int lua_custom_net_XMLParser_parseXML(lua_State* tolua_S)
{
    int argc = 0;
    custom::XMLParser* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"custom.XMLParser",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (custom::XMLParser*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_custom_net_XMLParser_parseXML'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        std::string arg0;
        
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "custom.XMLParser:parseXML");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_custom_net_XMLParser_parseXML'", nullptr);
            return 0;
        }
        cocos2d::ValueMap ret = cobj->parseXML(arg0);
        ccvaluemap_to_luaval(tolua_S, ret);
        return 1;
    }
    if (argc == 2)
    {
        std::string arg0;
        std::string arg1;
        
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "custom.XMLParser:parseXML");
        
        ok &= luaval_to_std_string(tolua_S, 3,&arg1, "custom.XMLParser:parseXML");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_custom_net_XMLParser_parseXML'", nullptr);
            return 0;
        }
        cocos2d::ValueMap ret = cobj->parseXML(arg0, arg1);
        ccvaluemap_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "custom.XMLParser:parseXML",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_custom_net_XMLParser_parseXML'.",&tolua_err);
#endif
    
    return 0;
}
int lua_custom_net_XMLParser_create(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"custom.XMLParser",0,&tolua_err)) goto tolua_lerror;
#endif
    
    argc = lua_gettop(tolua_S) - 1;
    
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_custom_net_XMLParser_create'", nullptr);
            return 0;
        }
        custom::XMLParser* ret = custom::XMLParser::create();
        object_to_luaval<custom::XMLParser>(tolua_S, "custom.XMLParser",(custom::XMLParser*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "custom.XMLParser:create",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_custom_net_XMLParser_create'.",&tolua_err);
#endif
    return 0;
}
int lua_custom_net_XMLParser_updateArmatureGLProgram(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"custom.XMLParser",0,&tolua_err)) goto tolua_lerror;
#endif
    
    argc = lua_gettop(tolua_S) - 1;
    
    if (argc == 2)
    {
        cocostudio::Armature* arg0;
        cocos2d::GLProgram* arg1;
        ok &= luaval_to_object<cocostudio::Armature>(tolua_S, 2, "ccs.Armature",&arg0);
        ok &= luaval_to_object<cocos2d::GLProgram>(tolua_S, 3, "cc.GLProgram",&arg1);
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_custom_net_XMLParser_updateArmatureGLProgram'", nullptr);
            return 0;
        }
        custom::XMLParser::updateArmatureGLProgram(arg0, arg1);
        return 0;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "custom.XMLParser:updateArmatureGLProgram",argc, 2);
    return 0;
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_custom_net_XMLParser_updateArmatureGLProgram'.",&tolua_err);
#endif
    return 0;
}
int lua_custom_net_XMLParser_constructor(lua_State* tolua_S)
{
    int argc = 0;
    custom::XMLParser* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_custom_net_XMLParser_constructor'", nullptr);
            return 0;
        }
        cobj = new custom::XMLParser();
        cobj->autorelease();
        int ID =  (int)cobj->_ID ;
        int* luaID =  &cobj->_luaID ;
        toluafix_pushusertype_ccobject(tolua_S, ID, luaID, (void*)cobj,"custom.XMLParser");
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "custom.XMLParser:XMLParser",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
    tolua_error(tolua_S,"#ferror in function 'lua_custom_net_XMLParser_constructor'.",&tolua_err);
#endif
    
    return 0;
}

static int lua_custom_net_XMLParser_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (XMLParser)");
    return 0;
}

int lua_register_custom_net_XMLParser(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"custom.XMLParser");
    tolua_cclass(tolua_S,"XMLParser","custom.XMLParser","cc.Ref",nullptr);
    
    tolua_beginmodule(tolua_S,"XMLParser");
    tolua_function(tolua_S,"new",lua_custom_net_XMLParser_constructor);
    tolua_function(tolua_S,"init",lua_custom_net_XMLParser_init);
    tolua_function(tolua_S,"parseXML",lua_custom_net_XMLParser_parseXML);
    tolua_function(tolua_S,"create", lua_custom_net_XMLParser_create);
    tolua_function(tolua_S,"updateArmatureGLProgram", lua_custom_net_XMLParser_updateArmatureGLProgram);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(custom::XMLParser).name();
    g_luaType[typeName] = "custom.XMLParser";
    g_typeCast["XMLParser"] = "custom.XMLParser";
    return 1;
}

//Water Effect Node
int lua_register_fishgame_WaterSimulate_create(lua_State* tolua_S)
{
	int argc = 0;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertable(tolua_S, 1, "custom.WaterSimulate", 0, &tolua_err)) goto tolua_lerror;
#endif

	argc = lua_gettop(tolua_S) - 1;

	if (argc == 0)
	{
		WaterSimulate	*water = WaterSimulate::create();
		object_to_luaval<WaterSimulate >(tolua_S, "custom.WaterSimulate", (WaterSimulate*)water);
		return 1;
	}
	else if (argc == 2)
	{
		int   width, height;
		ok &= luaval_to_int32(tolua_S, 2, &width, "custom.WaterSimulate:create");
		ok &= luaval_to_int32(tolua_S,3,&height,"custom.WaterSimulate:create");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_register_custom_WaterSimulate_create'", nullptr);
			return 0;
		}
		WaterSimulate	*water = WaterSimulate::create();
		object_to_luaval<WaterSimulate >(tolua_S, "custom.WaterSimulate", (WaterSimulate*)water);
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "custom.WaterSimulate:create", argc, 0);
	return 1;
#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_register_custom_WaterSimulate_create'.", &tolua_err);
#endif
				return 0;
}

int lua_register_fishgame_WaterSimulate_isMachineSupport(lua_State* tolua_S)
{
	int argc = 0;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertable(tolua_S, 1, "custom.WaterSimulate", 0, &tolua_err)) goto tolua_lerror;
#endif

	argc = lua_gettop(tolua_S) - 1;

	if (argc == 0)
	{
		lua_pushboolean(tolua_S, WaterSimulate::isMachineSupport());
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "custom.WaterSimulate:isMachineSupport", argc, 0);
	return 1;
#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_register_fishgame_WaterSimulate_isMachineSupport'.", &tolua_err);
#endif
				return 0;
}

int lua_register_fishgame_WaterSimulate_getVersion(lua_State* tolua_S)
{
	int argc = 0;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertable(tolua_S, 1, "custom.WaterSimulate", 0, &tolua_err)) goto tolua_lerror;
#endif

	argc = lua_gettop(tolua_S) - 1;

	if (argc == 0)
	{
		lua_pushinteger(tolua_S, WaterSimulate::getVersion());
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "custom.WaterSimulate:getVersion", argc, 0);
	return 1;
#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_register_fishgame_WaterSimulate_getVersion'.", &tolua_err);
#endif
				return 0;
}

int   lua_fishgame_WaterSimulate_setTouchPoint(lua_State* tolua_S)
{
	int argc = 0;
	WaterSimulate* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "custom.WaterSimulate", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (WaterSimulate*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_custom_WaterSimulate_setTouchPoint'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 2)
	{
		double   x, y;

		ok &= luaval_to_number(tolua_S, 2, &x, "custom.WaterSimulate:setTouchPoint");
		ok &= luaval_to_number(tolua_S, 3, &y, "custom.WaterSimulate:setTouchPoint");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_custom_WaterSimulate_setTouchPoint'", nullptr);
			return 0;
		}
		cocos2d::Vec2 location = cocos2d::Vec2(x, y);
		cobj->setTouchPoint(location);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "custom.WaterSimulate:setTouchPoint", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_custom_WaterSimulate_setTouchPoint'.", &tolua_err);
#endif
				return 0;
}

int lua_register_fishgame_WaterSimulate(lua_State* tolua_S)
{
	tolua_usertype(tolua_S, "custom.WaterSimulate");
	tolua_cclass(tolua_S, "WaterSimulate", "custom.WaterSimulate", "cc.Node", nullptr);

	tolua_beginmodule(tolua_S, "WaterSimulate");
	tolua_function(tolua_S, "setTouchPoint", lua_fishgame_WaterSimulate_setTouchPoint);
	tolua_function(tolua_S, "create", lua_register_fishgame_WaterSimulate_create);
	tolua_function(tolua_S,"isMachineSupport",lua_register_fishgame_WaterSimulate_isMachineSupport);
	tolua_function(tolua_S,"getVersion",lua_register_fishgame_WaterSimulate_getVersion);
	tolua_endmodule(tolua_S);
	std::string typeName = typeid(WaterSimulate).name();
	g_luaType[typeName] = "custom.WaterSimulate";
	g_typeCast["WaterSimulate"] = "custom.WaterSimulate";
	return 1;
}

int lua_register_fishgame_ActionVortex_create(lua_State *tolua_S)
{
	int argc = 0;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertable(tolua_S, 1, "custom.ActionVortex", 0, &tolua_err)) goto tolua_lerror;
#endif

	argc = lua_gettop(tolua_S) - 1;

	if (argc == 6)
	{
		double	duration,angleSpeed,windClock,finalRadius;
		cocos2d::Vec3 originPosition, centerPosition;
		ok &=luaval_to_number(tolua_S, 2, &duration, "custom.ActionVortex:create");
		ok &= luaval_to_number(tolua_S,3,&angleSpeed, "custom.ActionVortex:create");
		ok &= luaval_to_number(tolua_S,4,&windClock, "custom.ActionVortex:create");
		ok &= luaval_to_vec3(tolua_S, 5, &originPosition, "custom.ActionVortex:create");
		ok &= luaval_to_vec3(tolua_S, 6, &centerPosition, "custom.ActionVortex:create");
		ok &= luaval_to_number(tolua_S, 7, &finalRadius, "custom.ActionVortex:create");
		ActionVortex *action = ActionVortex::create(duration,angleSpeed,windClock,originPosition,centerPosition,finalRadius);
		object_to_luaval<ActionVortex>(tolua_S, "custom.ActionVortex", action);
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "custom.ActionVortex:create", argc, 0);
	return 1;
#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_register_fishgame_ActionVortex_create'.", &tolua_err);
#endif
				return 0;
}

int lua_register_fishgame_ActionVortex(lua_State* tolua_S)
{
	tolua_usertype(tolua_S, "custom.ActionVortex");
	tolua_cclass(tolua_S, "ActionVortex", "custom.ActionVortex", "cc.ActionInterval", nullptr);

	tolua_beginmodule(tolua_S, "ActionVortex");
	tolua_function(tolua_S, "create", lua_register_fishgame_ActionVortex_create);
	tolua_endmodule(tolua_S);
	std::string typeName = typeid(ActionVortex).name();
	g_luaType[typeName] = "custom.ActionVortex";
	g_typeCast["ActionVortex"] = "custom.ActionVortex";
	return 1;
}

int lua_register_fishgame_ShaderNode_create(lua_State *tolua_S)
{
	int argc = 0;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertable(tolua_S, 1, "custom.ShaderNode", 0, &tolua_err)) goto tolua_lerror;
#endif

	argc = lua_gettop(tolua_S) - 1;

	if (argc == 4)
	{
		std::string vertFilename, fragFilename;
		std::string  imageFilename;
		double        xgrid;
		ShaderNode *node = nullptr;
		ok &= luaval_to_std_string(tolua_S, 2, &vertFilename, "custom.ShaderNode:create");
		ok &= luaval_to_std_string(tolua_S, 3, &fragFilename, "custom.ShaderNode:create");
		ok &= luaval_to_number(tolua_S, 4, &xgrid, "custom.ShaderNode:create");
		bool b = luaval_to_std_string(tolua_S, 5, &imageFilename, "custom.ShaderNode:create");
		if (ok && b)
			node = ShaderNode::create(vertFilename.c_str(),fragFilename.c_str(),xgrid,imageFilename);
		else
		{
			cocos2d::Size frameSize;
			b = luaval_to_size(tolua_S, 5, &frameSize,"custom.ShaderNode:create");
			if (ok && b)
				node = ShaderNode::create(vertFilename.c_str(),fragFilename.c_str(),xgrid,frameSize);
		}
		if (node != nullptr)
		{
			object_to_luaval<ShaderNode>(tolua_S, "custom.ShaderNode", node);
			return 1;
		}
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "custom.ShaderNode:create", argc, 0);
	return 1;
#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_register_fishgame_ShaderNode_create'.", &tolua_err);
#endif
				return 0;
}

int lua_register_fishgame_ShaderNode(lua_State* tolua_S)
{
	tolua_usertype(tolua_S, "custom.ShaderNode");
	tolua_cclass(tolua_S, "ShaderNode", "custom.ShaderNode", "cc.Node", nullptr);

	tolua_beginmodule(tolua_S, "ShaderNode");
	tolua_function(tolua_S, "create", lua_register_fishgame_ShaderNode_create);
	tolua_endmodule(tolua_S);
	std::string typeName = typeid(ShaderNode).name();
	g_luaType[typeName] = "custom.ShaderNode";
	g_typeCast["ShaderNode"] = "custom.ShaderNode";
	return 1;
}

TOLUA_API int register_all_custom_net(lua_State* tolua_S)
{
	lua_getglobal(tolua_S, "_G");
	if (lua_istable(tolua_S,-1))//stack:...,_G,
	{
		tolua_open(tolua_S);

		tolua_module(tolua_S, "custom", 0);
		tolua_beginmodule(tolua_S, "custom");

		lua_register_custom_net_XMLParser(tolua_S);
		lua_register_fishgame_WaterSimulate(tolua_S);
		lua_register_fishgame_ActionVortex(tolua_S);
		lua_register_fishgame_ShaderNode(tolua_S);

		tolua_endmodule(tolua_S);
	}
	lua_pop(tolua_S, 1);
    return 1;
}
