//
//  lua_register_all_time_api.cpp
//  swtest
//
//  Created by charlie on 2017/6/12.
//
//
#include "cocos2d.h"
#include "lua_register_all_time_api.hpp"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#ifdef _WIN32
#include "platform/win32/CCStdC-win32.h"
#endif

int get_time(lua_State* L)
{
    long retVal = cocos2d::Director::getInstance()->getCurrentTime();
    lua_pushnumber(L, retVal);
    return 1;
}
int get_system_time(lua_State* L)
{
    timeval time;
#ifdef _WIN32
	cocos2d::gettimeofday(&time, nullptr);
#else
    gettimeofday(&time, nullptr);
#endif
    lua_pushnumber(L, time.tv_sec * 1000 + time.tv_usec / 1000);
    return 1;
}

int get_current_frame_delta(lua_State* L)
{
    float retVal = cocos2d::Director::getInstance()->getCurrentFrameDelta();
    lua_pushnumber(L, retVal);
    return 1;
}


void register_all_lua_time_api(lua_State* L)
{
    luaL_Reg mathlib[] = {
        {"getTime", get_time},
        {"getCurrentFrameDelta", get_current_frame_delta},
        {"getSystemTime", get_system_time},
        {nullptr, nullptr}
    };
    
    
    luaL_openlib(L, "TimeApi", mathlib, 0);
}
