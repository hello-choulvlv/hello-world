//   ShaderNode.h  
/*
  *场景扭曲,扭曲的方式与波浪相似
  *为了针对IOS,安卓平台出现的扭曲动画随着时间的流逝出现的机械抖动情况而设定的解决方案
  *注意,因为实现和使用上的简洁,最终导致了该类的对象在全局中只能有一个处于活动状态,如果有两个共存,则可能会导致黑屏
  *@Author:xiaohuaxiong
  *@date:2017-10-28 10:59:42
 */
#ifndef __SHADER_NODE_H__
#define __SHADER_NODE_H__
#include "cocos2d.h"
#include "RenderFramebuffer.h"
//选择基准点的方式
enum MeshType
{
	MeshType_Center = 0,//以屏幕中心为基准点
	MeshType_LeftBottom = 1,//屏幕左下角
	MeshType_LeftTop = 2,//左上角
	MeshType_RightBottom =3,//右下角
	MeshType_RightTop=4,//右上角
	MeshType_Count=5,
};
/*
  *平面场网格划分,划分的方式有多种,可以以屏幕中心为基准点/或者以左下角等
 */
class MeshPartition :public cocos2d::Ref
{
private:
	unsigned		_vertexBufferId;//Vertex Buffer id of OpenGL Vertex
	unsigned		_normalBufferId;//Vertex normal id
	unsigned		_indexBufferId;
	int				_countOfIndex;//record  count of index
	int				_countOfVertex;//record count of vertex
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	int               _xgrid, _ygrid;
	cocos2d::Size _frameSize;
	MeshType   _meshType;
	bool             _isYReverse;
#endif
	MeshPartition();
	void          initWithMeshSquare(const cocos2d::Size &frameSize, int xgrid, int ygrid, bool isYReverse,MeshType meshType);
public:
	~MeshPartition();
	unsigned getNormal()const { return _normalBufferId; };
	unsigned getVertex()const { return _vertexBufferId; };
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	inline int   getMeshGridX()const { return _xgrid; };
	inline int   getMeshGridY()const { return _ygrid; };
#endif
	/*
	*@param:width means width of square
	*@param:height means height of square
	*@param:xgrid means number of grid in row
	*@param:ygrid means number of grid in column
	*@param:fragCoord means max frag coord,if it greater than 1.0, texture will be repeated
	*@note: format of png picture is y mirror
	*/
	static MeshPartition *createMeshSquare(const cocos2d::Size &frameSize, int xgrid, int ygrid, bool isYReverse,MeshType meshType =MeshType::MeshType_Center);
	/*
	*@param:posLoc means position of position
	*@param:normalLoc means position of normal
	*@param:fragLoc means position of frag
	*/
	void    drawMeshSquare(int posLoc, int fragCoordLoc);
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	/*
	*recreate on platform Android
	*/
	void    recreate();
#endif
};
/*
  *创建ShaderNode对象的方式有两种,一种用指定的图片路径名字,另一种是直接指定帧缓冲区对象
  *考虑到ShaderNode的用途,这两种方式目前都是受支持的
 */
class ShaderNode : public cocos2d::Node  
{  
public:  
    ShaderNode();  
	~ShaderNode();
    bool initWithTexture(const char *vert, const char *frag,int xgrid,const std::string &filename);
	bool initWithFramebuffer(const char *vert,const char *frag, int xgrid, const cocos2d::Size &frameSize);
    void loadShaderVertex(const char *vert, const char *frag);
    //virtual void update(float delta);  
    virtual void setContentSize(const cocos2d::Size& var);  
    virtual void setColor(const cocos2d::Color4F &newColor);  
	virtual void draw(cocos2d::Renderer *renderer, const cocos2d::Mat4& transform, uint32_t flags);
    virtual void drawWater(const cocos2d::Mat4 &parentToNodeTransform,uint32_t flag);
	/*
	  *以背景纹理为参数创建扭曲纹理动画
	  *xgrid为横向网格划分的数目,纵向网格划分的计算方式为ceil(xgrid * winSize.width/winSize.height)
	 */
    static ShaderNode *create(const char *vert,  const char *frag,int xgrid,const std::string &filename);
  /*
    *以帧缓冲区对象为渲染目标创建扭曲动画
	*xgrid参数的意义参见另一个重载的函数create
    */
	static ShaderNode *create(const char *vert,const char *frag, int xgrid, const cocos2d::Size &frameSize);
	//安卓平台下,重新加载
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	void             recreate(cocos2d::EventCustom *recreateEvent);
#endif
private:
	RenderFramebuffer               *_framebuffer;
	cocos2d::GLProgram			*_glProgram;
	MeshPartition                        *_meshWater;
	cocos2d::CustomCommand   _drawWaterCommand;
    GLuint									_attributeFragCoord, _attributePosition;
	int                                           _resolutionLoc, _colorLoc;
	cocos2d::Texture2D			   *_texture;
    cocos2d::Vec4						_color;

	bool                                      _useFramebuffer,_useTexture;
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	std::string                             _vertFilename;
	std::string                            _fragFilename;
	cocos2d::EventListenerCustom *_backToForegroundListener;
#endif
};  
#endif