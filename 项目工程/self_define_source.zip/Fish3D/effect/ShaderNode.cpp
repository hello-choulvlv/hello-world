//   ShaderNode.cpp  
#include "ShaderNode.h"  
USING_NS_CC;
const int  VertexAttribFloatCount = 4;//每个顶点的浮点数的数目
static struct
{
	float fx, fy;
}  _staicMeshTypeFactor[5] = { 
	{-0.5f,-0.5f},//屏幕中心
	{0.0f,0.0f},//左下角
	{0.0f,-1.0f},//左上角
	{-1.0f,0.0f},//右下角
	{-1.0f,-1.0f},//右上角
};
//
MeshPartition::MeshPartition()
{
	_vertexBufferId = 0;
	_normalBufferId = 0;
	_indexBufferId = 0;
	_countOfIndex = 0;
	_countOfVertex = 0;
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_meshType = MeshType_Center;
#endif
}

MeshPartition::~MeshPartition()
{
	glDeleteBuffers(1, &_vertexBufferId);
	glDeleteBuffers(1, &_normalBufferId);
	glDeleteBuffers(1, &_indexBufferId);
	_vertexBufferId = 0;
	_normalBufferId = 0;
	_indexBufferId = 0;
}

void MeshPartition::initWithMeshSquare(const cocos2d::Size &frameSize, int xgrid, int ygrid, bool isYReverse,MeshType meshType)
{
	assert(xgrid > 0 && ygrid > 0 && meshType>= MeshType_Center &&meshType <MeshType_Count);
	const float  offsetX = _staicMeshTypeFactor[meshType].fx * frameSize.width;
	const float  offsetY = _staicMeshTypeFactor[meshType].fy * frameSize.height;
	const float  fragCoordOffset = isYReverse ? 1.0f : 0.0f;
	const float  signCoord = isYReverse ? -1.0f: 1.0f;
	_countOfVertex = (xgrid + 1)*(ygrid + 1);
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_frameSize = frameSize;
	_xgrid = xgrid;
	_ygrid = ygrid;
	_isYReverse = isYReverse;
	_meshType = meshType;
#endif
	float *Vertex = new float[_countOfVertex*VertexAttribFloatCount];
	for (int j = 0; j < ygrid + 1; ++j)
	{
		const float factor = 1.0f * j / ygrid;
		const float y = frameSize.height*factor +offsetY;
		float  *nowVertex = Vertex + j*(xgrid + 1)*VertexAttribFloatCount;
		for (int i = 0; i < xgrid + 1; ++i)
		{
			const int index = i * VertexAttribFloatCount;
			nowVertex[index] = frameSize.width*i /xgrid +offsetX;
			nowVertex[index + 1] = y;
			//除非VertexAttribFloatCount>=5才能开启下面的属性
			nowVertex[index + 2] = 1.0f * i / xgrid;
			nowVertex[index + 3] = signCoord* j / ygrid + fragCoordOffset;
		}
	}
	//generate index data
	_countOfIndex = 2 * (xgrid +1)*ygrid;
	short *indexVertex = new short[_countOfIndex];
	const int xgrid_plus_one = xgrid + 1;
	bool  counter_clock = true;
	for (int j = 0,vertex_index=0; j < ygrid; ++j)
	{
		int  y_row_index = j * xgrid_plus_one;
		int  y_row_m1 = y_row_index + xgrid_plus_one;
		if (counter_clock)
		{
			for (int i = 0; i <= xgrid; ++i)
			{
				indexVertex[vertex_index] = y_row_m1 + i;
				indexVertex[vertex_index + 1] = y_row_index + i;
				vertex_index += 2;
			}
		}
		else
		{
			for (int i = xgrid; i >= 0; --i)
			{
				indexVertex[vertex_index] = y_row_index + i;
				indexVertex[vertex_index + 1] = y_row_m1 + i;
				vertex_index += 2;
			}
		}
		counter_clock = !counter_clock;
	}
	//int _defaultVertexId, _defaultIndexId;
	//glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &_defaultVertexId);
	//glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &_defaultIndexId);
	//generate vertex and frag coord
	glGenBuffers(1, &_vertexBufferId);
	glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferId);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float)*_countOfVertex * VertexAttribFloatCount, Vertex, GL_STATIC_DRAW);
	//generate index 
	glGenBuffers(1, &_indexBufferId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBufferId);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(short)*_countOfIndex, indexVertex, GL_STATIC_DRAW);

	delete[] indexVertex;
	delete[] Vertex;
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

void MeshPartition::drawMeshSquare(int posLoc, int fragCoordLoc)
{
	//bind vertex buffer
	glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferId);
	glEnableVertexAttribArray(posLoc);
	glVertexAttribPointer(posLoc, 2, GL_FLOAT, GL_FALSE, sizeof(float)*VertexAttribFloatCount, NULL);
	glEnableVertexAttribArray(fragCoordLoc);
	glVertexAttribPointer(fragCoordLoc, 2, GL_FLOAT, GL_FALSE, sizeof(float)*VertexAttribFloatCount, (void*)(sizeof(float) * 2));

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBufferId);
	glDrawElements(GL_TRIANGLE_STRIP, _countOfIndex, GL_UNSIGNED_SHORT, nullptr);
}
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
void  MeshPartition::recreate()
{
	initWithMeshSquare(_frameSize, _xgrid, _ygrid, _isYReverse,_meshType);
}
#endif
MeshPartition *MeshPartition::createMeshSquare(const cocos2d::Size &frameSize, int xgrid, int ygrid, bool isYReverse,MeshType meshType)
{
	MeshPartition *_meshSquare = new MeshPartition();
	_meshSquare->initWithMeshSquare(frameSize, xgrid, ygrid, isYReverse, meshType);
	return _meshSquare;
}
////////////////////////////////////////////////////////

ShaderNode::ShaderNode():
	_framebuffer(nullptr)
	,_glProgram(nullptr)
	, _meshWater(nullptr)
	,_texture(nullptr)
	, _color(1,1,1,1)
	,_useFramebuffer(false)
	,_useTexture(false)
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	,_backToForegroundListener(nullptr)
#endif
{  
      
}  

ShaderNode::~ShaderNode()
{
	if (_framebuffer)
		_framebuffer->release();
	_glProgram->release();
	_glProgram = nullptr;
	if(_texture)
		_texture->release();
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	if (_backToForegroundListener)
	{
		Director::getInstance()->getEventDispatcher()->removeEventListener(_backToForegroundListener);
		_backToForegroundListener = nullptr;
	}
#endif
}
  
ShaderNode* ShaderNode::create(const char *vert, const char *frag,int xgrid,const std::string &filename)  
{  
    ShaderNode* shader = new ShaderNode();
    if(shader && shader->initWithTexture(vert,frag,xgrid,filename))
    {  
        shader->autorelease();  
        return shader;  
    }
    CC_SAFE_DELETE(shader);
    return NULL;
}

ShaderNode *ShaderNode::create(const char *vert, const char *frag, int xgrid, const cocos2d::Size &frameSize)
{
	ShaderNode *shader = new ShaderNode();
	if (shader->initWithFramebuffer(vert, frag, xgrid,frameSize))
	{
		shader->autorelease();
		return shader;
	}
	delete shader;
	shader = nullptr;
	return shader;
}
  
void ShaderNode::loadShaderVertex(const char *vert, const char *frag)  
{  
	_glProgram = GLProgram::createWithFilenames(vert, frag);
	_glProgram->retain();
      
    //获取attribute变量标识  
    _attributeFragCoord = _glProgram->getAttribLocation("a_texCoord");
    _attributePosition =   _glProgram->getAttribLocation( "a_position");
	_resolutionLoc = _glProgram->getUniformLocation("resolution");
	_colorLoc = _glProgram->getUniformLocation("u_color");
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_vertFilename = vert;
	_fragFilename = frag;
#endif
}  
  
void ShaderNode::setColor(const cocos2d::Color4F &newColor)  
{  
    _color.x = newColor.r;  
    _color.y = newColor.g;  
    _color.z= newColor.b;  
    _color.w = newColor.a;  
}  
  
bool ShaderNode::initWithTexture(const char *vert, const char *frag, int xgrid, const std::string &filename)
{  
	Node::init();
//    获取shader程序
    loadShaderVertex(vert,frag);  
//
	_texture = TextureCache::getInstance()->addImage(filename);
	_texture->retain();
      
    setContentSize(_texture->getContentSize());
    //scheduleUpdate();
	auto &winSize = Director::getInstance()->getWinSize();
	_meshWater = MeshPartition::createMeshSquare(_contentSize, 0.5f + xgrid * winSize.width/winSize.height, true, MeshType_Center);
	//setColor(Color4F(1,1,1,1));
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_backToForegroundListener = EventListenerCustom::create(EVENT_RENDERER_RECREATED, CC_CALLBACK_1(ShaderNode::recreate,this));
	Director::getInstance()->getEventDispatcher()->addEventListenerWithFixedPriority(_backToForegroundListener, -1);
#endif
	_useTexture = true;
    return true;
}

bool ShaderNode::initWithFramebuffer(const char *vert, const char *frag, int xgrid, const cocos2d::Size &frameSize)
{
	Node::init();
	loadShaderVertex(vert, frag);
#if (CC_TARGET_PLATFORM == CC_PLATFORM_MAC) || (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32) || (CC_TARGET_PLATFORM == CC_PLATFORM_LINUX)
    const cocos2d::Size pcFrameSize = frameSize * Director::getInstance()->getOpenGLView()->getFrameZoomFactor() * Director::getInstance()->getOpenGLView()->getRetinaFactor();
    _framebuffer = RenderFramebuffer::create(pcFrameSize);
#else
	_framebuffer = RenderFramebuffer::create(frameSize);
#endif
	auto &winSize = Director::getInstance()->getWinSize();
	setContentSize(winSize);
	_meshWater = MeshPartition::createMeshSquare(winSize,xgrid,0.5f+xgrid*winSize.height/ winSize.width,false,MeshType::MeshType_Center);
	//setColor(Color4F(1,1,1,1));

#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_backToForegroundListener = EventListenerCustom::create(EVENT_RENDERER_RECREATED, CC_CALLBACK_1(ShaderNode::recreate, this));
	Director::getInstance()->getEventDispatcher()->addEventListenerWithFixedPriority(_backToForegroundListener, -1);
#endif
	_useFramebuffer = true;
	return true;
}
  
void ShaderNode::setContentSize(const Size& var)  
{  
    Node::setContentSize(var);  
} 

void ShaderNode::draw(cocos2d::Renderer *renderer, const cocos2d::Mat4& transform, uint32_t flags)
{
	//为了程序的健壮,需要加上这个判断,在某些安卓平台上,创建帧缓冲去对象可能会失败
	//虽然目前跟美术那边的约定是安卓平台不开启这个功能,但是不能保证他们一定会遵照约定
	if (_useFramebuffer && _framebuffer || _useTexture && _texture)
	{
		_drawWaterCommand.init(_globalZOrder);
		_drawWaterCommand.func = CC_CALLBACK_0(ShaderNode::drawWater, this, transform, flags);
		renderer->addCommand(&_drawWaterCommand);
		//在此处判断是否启用帧缓冲区对象
		if (_framebuffer)
			_framebuffer->save();
	}
}
  
void ShaderNode::drawWater( const cocos2d::Mat4& transform, uint32_t flags)
{  
	GL::bindVAO(0);
	int  textureName = 0;
	//判断是否渲染到纹理
	if (_framebuffer)
	{
		_framebuffer->restore();
		textureName = _framebuffer->getColorBuffer();
	}
	else
		textureName = _texture->getName();
	//optimalize performance
	int cullFace = GL::isCullFace();
	int cullFaceMode = GL::queryCullFaceMode();
	GL::setCullFace(true);
	GL::setCullFaceMode(GL_BACK);
	//
	GL::bindVAO(0);
	_glProgram->use();
	_glProgram->setUniformsForBuiltins(transform);
    GL::bindTexture2D(textureName);               //绑定纹理到单元
	glUniform2f(_resolutionLoc, _contentSize.width, _contentSize.height);
	glUniform4fv(_colorLoc, 1, &_color.x);
	_meshWater->drawMeshSquare(_attributePosition,_attributeFragCoord);
	//restore gl state
	GL::setCullFace(cullFace);
	GL::setCullFaceMode(cullFaceMode);
	glBindBuffer(GL_ARRAY_BUFFER,0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,0);
}
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
void ShaderNode::recreate(cocos2d::EventCustom *recreateEvent)
{
	_glProgram->reset();
	_glProgram->initWithFilenames(_vertFilename, _fragFilename);
	_meshWater->recreate();
}
#endif
