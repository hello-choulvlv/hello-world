/*
 *Transition Vortex realization
 *2017/2/27/15:44
 *@Author:xiaoxiong
 */
#include"TransitionVortex.h"
USING_NS_CC;
#define __MAX_RADIUS__  1.5f
#define __MAX_ANGLE__		1.5f
TransitionVortex::TransitionVortex()
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	:_backToForegroundListener(nullptr)
#endif
{
	_radius = 0.0f;
	_angle = 0.0f;
	_time = 0.0f;
	_timeInc = true;
	//
	_mvpMatrixLoc = 0;
	_radiusLoc = 0;
	_angleLoc = 0;
	_positionLoc = 0;
	_fragCoordLoc = 0;
	//
	_vertexBufferId = 0;
//	_unpackBufferId = 0;
	_backColorBuffer = NULL;
	_finalVortex = false;
}

TransitionVortex::~TransitionVortex()
{
	_glProgram->release();
	glDeleteBuffers(1, &_vertexBufferId);
	glDeleteTextures(1, &_textureId);
	_vertexBufferId = 0;
	_textureId = 0;
	delete _backColorBuffer;
	_backColorBuffer = NULL;
	_glProgram = NULL;
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	if (_backToForegroundListener)
		cocos2d::Director::getInstance()->getEventDispatcher()->removeEventListener(_backToForegroundListener);
#endif
}

TransitionVortex *TransitionVortex::create(float duration, cocos2d::Scene *targetScene)
{
	TransitionVortex *_Vortex = new TransitionVortex();
	_Vortex->initWithDuration(duration, targetScene);
	_Vortex->autorelease();
	return _Vortex;
}

bool TransitionVortex::initWithDuration(float duration, cocos2d::Scene *targetScene)
{
	TransitionScene::initWithDuration(duration, targetScene);
	_glProgram = GLProgram::createWithFilenames("shader/Vortex.vsh", "shader/Vortex.fsh");
	_glProgram->retain();
	//Vextex Buffer
	float VertexData[16] = {
		-1.0f, 1.0f, 0.0f,1.0f,
		-1.0f,-1.0f, 0.0f,0.0f,
		1.0f,1.0f, 1.0f,1.0f,
		1.0f,-1.0f,	1.0f,0.0f,
	};
	int _defaultVertexId,_defaultTextureId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &_defaultVertexId);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &_defaultTextureId);
	glGenBuffers(1, &_vertexBufferId);
	glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferId);
	glBufferData(GL_ARRAY_BUFFER, sizeof(VertexData), VertexData, GL_STATIC_DRAW);

	_mvpMatrixLoc = _glProgram->getUniformLocation("CC_MVPMatrix");
	_radiusLoc = _glProgram->getUniformLocation("u_radius");
	_angleLoc = _glProgram->getUniformLocation("u_angle");
	_textureLoc = _glProgram->getUniformLocation("u_texture");

	_positionLoc = _glProgram->getAttribLocation("a_position");
	_fragCoordLoc = _glProgram->getAttribLocation("a_texCoord");
	const cocos2d::Size _size = Director::getInstance()->getOpenGLView()->getFrameSize();
	glGenTextures(1, &_textureId);
	glBindTexture(GL_TEXTURE_2D, _textureId);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, _size.width, _size.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	_backColorBuffer = new char[(int)(_size.width*_size.height*sizeof(char)*4)];

	glBindTexture(GL_TEXTURE_2D, _defaultTextureId);
	glBindBuffer(GL_ARRAY_BUFFER, _defaultVertexId);

	gettimeofday(&_timeStamp, NULL);
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	//register event
	_backToForegroundListener = cocos2d::EventListenerCustom::create(EVENT_RENDERER_RECREATED,CC_CALLBACK_1(TransitionVortex::recreate,this));
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(_backToForegroundListener, this);
#endif
	return true;
}

void TransitionVortex::onEnter()
{
	TransitionScene::onEnter();
	//create function call
	Sequence	*action = Sequence::create(
		DelayTime::create(_duration / 2.0f),
		CallFunc::create(CC_CALLBACK_0(TransitionVortex::afterVortex,this)),
		DelayTime::create(_duration/2.0f),
		CallFunc::create(CC_CALLBACK_0(TransitionVortex::finishVortex,this)),
		CallFunc::create(CC_CALLBACK_0(TransitionVortex::finish,this)),
		NULL
		);
	_inScene->runAction(action);
}
//after first scene change complete
void TransitionVortex::afterVortex()
{
	//time decrease
	_timeInc = false;
	gettimeofday(&_timeStamp,NULL);
}

void TransitionVortex::finishVortex()
{
	_finalVortex = true;
//	this->finish();
}
void TransitionVortex::visit(cocos2d::Renderer *renderer, const cocos2d::Mat4& parentTransform, uint32_t parentFlags)
{
	struct timeval _nowTimeStamp;
	gettimeofday(&_nowTimeStamp, NULL);
	_time += 0.033f;
	const float deltaTime =  (_nowTimeStamp.tv_sec - _timeStamp.tv_sec) + (_nowTimeStamp.tv_usec - _timeStamp.tv_usec) / 1000000.0f;
	//Check if it is time increace
	const float factor = deltaTime*2.0f / _duration;
	const float interpolation = (3.0f - 2.0f*factor)*factor*factor;
	Scene	*_targetScene;
	if (_timeInc)
	{
		_radius = __MAX_ANGLE__ * interpolation;
		_angle = __MAX_RADIUS__*interpolation;
		_targetScene = _outScene;
	}
	else
	{
		_radius = __MAX_ANGLE__*(1.0f - interpolation);
		_angle = __MAX_RADIUS__*(1.0f - interpolation);
		_targetScene = _inScene;
	}
	if (!_visible) return;
	//note draw self function must be called at last
		TransitionScene::visit(renderer, parentTransform, parentFlags);
	if (!_finalVortex)
	{
		_drawVortexCommand.init(_globalZOrder);
		_drawVortexCommand.func = CC_CALLBACK_0(TransitionVortex::drawTransitionVortex, this, renderer, parentTransform, parentFlags);
		renderer->addCommand(&_drawVortexCommand);
	}
}

void TransitionVortex::drawTransitionVortex(cocos2d::Renderer *, cocos2d::Mat4 &modelView, uint32_t flags)
{
	const cocos2d::Size &_size = Director::getInstance()->getOpenGLView()->getFrameSize();

	int _defaultVertexId, _defaultTextureId,_defaultPackId,_defaultUnpackId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &_defaultVertexId);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &_defaultTextureId);

	_glProgram->use();
//read pixel from back color buffer
	//glReadBuffer(GL_BACK);
	glReadPixels(0, 0, _size.width, _size.height, GL_RGBA, GL_UNSIGNED_BYTE, _backColorBuffer);
	//and read pixel to texture buffer
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, _textureId);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, _size.width, _size.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, _backColorBuffer);
	glUniform1i(_textureLoc,0);
	glUniform1f(_radiusLoc,_radius);
	glUniform1f(_angleLoc,_angle);
	glUniformMatrix4fv(_mvpMatrixLoc,1,GL_FALSE,modelView.m);

	glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferId);
	glEnableVertexAttribArray(_positionLoc);
	glVertexAttribPointer(_positionLoc, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, NULL);
	glEnableVertexAttribArray(_fragCoordLoc);
	glVertexAttribPointer(_fragCoordLoc,2,GL_FLOAT,GL_FALSE,sizeof(float)*4,(void*)(sizeof(float)*2));

	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	//restore buffer binding
	glBindTexture(GL_TEXTURE_2D, _defaultTextureId);
	glBindBuffer(GL_ARRAY_BUFFER, _defaultVertexId);
}
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
void  TransitionVortex::recreate(cocos2d::EventCustom *recreateEvent)
{
	_glProgram->reset();
	_glProgram->initWithFilenames("shader/Vortex.vsh", "shader/Vortex.fsh");
	//Vextex Buffer
	float VertexData[16] = {
		-1.0f, 1.0f, 0.0f,1.0f,
		-1.0f,-1.0f, 0.0f,0.0f,
		1.0f,1.0f, 1.0f,1.0f,
		1.0f,-1.0f,	1.0f,0.0f,
	};
	int _defaultVertexId, _defaultTextureId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &_defaultVertexId);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &_defaultTextureId);
	glGenBuffers(1, &_vertexBufferId);
	glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferId);
	glBufferData(GL_ARRAY_BUFFER, sizeof(VertexData), VertexData, GL_STATIC_DRAW);

	_mvpMatrixLoc = _glProgram->getUniformLocation("CC_MVPMatrix");
	_radiusLoc = _glProgram->getUniformLocation("u_radius");
	_angleLoc = _glProgram->getUniformLocation("u_angle");
	_textureLoc = _glProgram->getUniformLocation("u_texture");

	_positionLoc = _glProgram->getAttribLocation("a_position");
	_fragCoordLoc = _glProgram->getAttribLocation("a_texCoord");
	const cocos2d::Size _size = Director::getInstance()->getOpenGLView()->getFrameSize();
	glGenTextures(1, &_textureId);
	glBindTexture(GL_TEXTURE_2D, _textureId);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, _size.width, _size.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, _defaultTextureId);
	glBindBuffer(GL_ARRAY_BUFFER, _defaultVertexId);

	gettimeofday(&_timeStamp, NULL);
}
#endif
