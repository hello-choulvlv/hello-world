/*
*Scene Transtion with Texture  Vortex
*date:2017/2/27/15:17
*@Author:xiaoxiong
*/
#ifndef __TRANSITION_VORTEX_H__
#define __TRANSITION_VORTEX_H__
#include"cocos2d.h"
class TransitionVortex :public cocos2d::TransitionScene
{
public:
	TransitionVortex();
	~TransitionVortex();
	/*
	*create with time duration,and target scene
	*/
	static TransitionVortex *create(float duration, cocos2d::Scene *targetScene);
	/*
	*Override draw function
	*/
	virtual void visit(cocos2d::Renderer *renderer, const cocos2d::Mat4& parentTransform, uint32_t parentFlags);
	/*
	*init function with duration and scene
	*/
	bool initWithDuration(float duration, cocos2d::Scene *targetScene);
	/*
	*self defined function to draw TransitionVortex
	*/
	void drawTransitionVortex(cocos2d::Renderer *, cocos2d::Mat4 &modelView, uint32_t flags);
	/*
	*Override function,onEnter
	*/
	virtual void onEnter()override;
	/*
	 *Middle function call
	 */
	void	afterVortex();
	/*
	 *final function call
	 */
	void finishVortex();
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	//when recreate activity
	void recreate(cocos2d::EventCustom *recreateEvent);
#endif
private:
	cocos2d::GLProgram *_glProgram;
	cocos2d::CustomCommand	_drawVortexCommand;
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	cocos2d::EventListenerCustom  *_backToForegroundListener;
#endif
	//current vortex radius,value between[0.0-2.0]
	float _radius;
	//current vortex angle,value between[0.0 - 4.0]
	float _angle;
	//current time
	float _time;
	// current sequence is increase ?
	bool _timeInc;
	//uniform location
	int	_mvpMatrixLoc;
	int	_radiusLoc;
	int	_angleLoc;
	int	_textureLoc;
	//attribute location
	int	_positionLoc;
	int	_fragCoordLoc;
	//Vertex Buffer
	unsigned		_vertexBufferId;
	//unpack buffer
	//unsigned		_unpackBufferId;
	//texture buffer
	unsigned		_textureId;
	//time val
	struct timeval		_timeStamp;
	char				*_backColorBuffer;
	int	_finalVortex;
};
#endif