/*
  *帧缓冲区对象
  *2017/3/13
  *@Author:xiaoxiong
 */
#include"RenderFramebuffer.h"
#include<assert.h>
USING_NS_CC;
RenderFramebuffer::RenderFramebuffer()
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	:_backToForegroundListener(nullptr)
#endif
{
	_framebufferId = 0;
	_colorBufferId = 0;
	_depthStencilBufferId = 0;
	_oldFramebufferId = 0;
	_stencilRenderBufffer = 0;
}

RenderFramebuffer::~RenderFramebuffer()
{
	if (_framebufferId)
	{
		glDeleteFramebuffers(1, &_framebufferId);
		_framebufferId = 0;
	}
	if (_depthStencilBufferId)
	{
		glDeleteRenderbuffers(1, &_depthStencilBufferId);
		_depthStencilBufferId = 0;
	}
	if (_stencilRenderBufffer)
	{
		glDeleteRenderbuffers(1, &_stencilRenderBufffer);
		_stencilRenderBufffer = 0;
	}
	if (_colorBufferId)
	{
		glDeleteTextures(1, &_colorBufferId);
		_colorBufferId = 0;
	}
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	if (_backToForegroundListener)
		cocos2d::Director::getInstance()->getEventDispatcher()->removeEventListener(_backToForegroundListener);
#endif
}

RenderFramebuffer *RenderFramebuffer::create(const cocos2d::Size &frameSize)
{
	RenderFramebuffer *_render = new RenderFramebuffer();
	if (!_render->init(frameSize))
	{
		_render->release();
		_render = NULL;
	}
	return _render;
}

bool RenderFramebuffer::init(const cocos2d::Size &frameSize)
{
	//get OpenGL back color buffer size
	//const cocos2d::Size &_OpenGLViewSize = cocos2d::Director::getInstance()->getOpenGLView()->getFrameSize();
	_frameSize = frameSize;
	//save 
	int defaultFramebuffer = 0;
	int defaultColorBuffer = 0;
	int defaultRenderBuffer = 0;
	glGetIntegerv(GL_FRAMEBUFFER_BINDING, &defaultFramebuffer);
	glGetIntegerv(GL_RENDERBUFFER_BINDING, &defaultRenderBuffer);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &defaultColorBuffer);
	//generate draw frame buffer
	glGenFramebuffers(1, &_framebufferId);
	glBindFramebuffer(GL_FRAMEBUFFER, _framebufferId);
	//gen color buffer
	glGenTextures(1, &_colorBufferId);
	glBindTexture(GL_TEXTURE_2D, _colorBufferId);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, frameSize.width, frameSize.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	//generate render buffer
	glGenRenderbuffers(1, &_depthStencilBufferId);
	glBindRenderbuffer(GL_RENDERBUFFER, _depthStencilBufferId);
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	if (Configuration::getInstance()->supportsOESPackedDepthStencil())
	{
		glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, frameSize.width, frameSize.height);
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, _depthStencilBufferId);
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_STENCIL_ATTACHMENT, GL_RENDERBUFFER, _depthStencilBufferId);
	}
	else
	{
		if (Configuration::getInstance()->supportsOESDepth24())
		{
			glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24_OES, frameSize.width, frameSize.height);
		}
		else
		{
			glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, frameSize.width, frameSize.height);
		}
		glGenRenderbuffers(1, &_stencilRenderBufffer);
		glBindRenderbuffer(GL_RENDERBUFFER, _stencilRenderBufffer);
		glRenderbufferStorage(GL_RENDERBUFFER, GL_STENCIL_INDEX8, frameSize.width, frameSize.height);

		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, _depthStencilBufferId);
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_STENCIL_ATTACHMENT, GL_RENDERBUFFER, _stencilRenderBufffer);
	}
#else
	glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, frameSize.width, frameSize.height);
	glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, _depthStencilBufferId);
	glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_STENCIL_ATTACHMENT, GL_RENDERBUFFER, _depthStencilBufferId);
#endif
	//attachment
	glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,_colorBufferId,0);
	//check draw framebuffer
	const bool _initFlag=glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
	//CCASSERT(_initFlag,"Create Framebuffer Failed.");
	if (!_initFlag)//if failed
	{
		glDeleteFramebuffers(1,&_framebufferId);
		glDeleteTextures(1,&_colorBufferId);
		glDeleteRenderbuffers(1,&_depthStencilBufferId);
		glDeleteRenderbuffers(1,&_stencilRenderBufffer);
		_framebufferId = 0;
		_colorBufferId = 0;
		_depthStencilBufferId = 0;
		_stencilRenderBufffer = 0;
	}
	//restore
	glBindTexture(GL_TEXTURE_2D, defaultColorBuffer);
	glBindRenderbuffer(GL_RENDERBUFFER, defaultRenderBuffer);
	glBindFramebuffer(GL_FRAMEBUFFER, defaultFramebuffer);
	//
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	if (!_backToForegroundListener)
	{
		_backToForegroundListener = cocos2d::EventListenerCustom::create(EVENT_RENDERER_RECREATED, CC_CALLBACK_1(RenderFramebuffer::recreate, this));
		cocos2d::Director::getInstance()->getEventDispatcher()->addEventListenerWithFixedPriority(_backToForegroundListener, -1);
	}
#endif
	return _initFlag;
}

void RenderFramebuffer::save()
{
	glGetIntegerv(GL_FRAMEBUFFER_BINDING,(int *)&_oldFramebufferId);
	glBindFramebuffer(GL_FRAMEBUFFER,_framebufferId);
    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
}

void RenderFramebuffer::restore()
{
	glBindFramebuffer(GL_FRAMEBUFFER,_oldFramebufferId);
}

unsigned RenderFramebuffer::getColorBuffer()
{
	return _colorBufferId;
}
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
void    RenderFramebuffer::recreate(cocos2d::EventCustom *recreateEvent)
{
	init(_frameSize);
}
#endif