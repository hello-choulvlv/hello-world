/*
	*@date:2017-03-13 
    *帧缓冲区对象
	*@Author:xiaoxiong
 */
#ifndef __RENDER_FRAME_BUFFER_H__
#define __RENDER_FRAME_BUFFER_H__
#include"cocos2d.h"
/*
  *注意,RenderFramebuffer的作用比较特殊,作为一个全屏的framebuffer使用
  *不同于cocos2d::RendererTexture,RenderFramebuffer在安卓机器上失败的可能性非常低
 */
class RenderFramebuffer :public cocos2d::Ref
{
private:
	//帧缓冲区对象
	unsigned _framebufferId;
	//颜色缓冲区对象
	unsigned _colorBufferId;
	//深度模板缓冲区对象
	unsigned _depthStencilBufferId;
	unsigned  _stencilRenderBufffer;
	//旧的帧缓冲区对象
	int           _oldFramebufferId;
	cocos2d::Size  _frameSize;
	//for platform Android
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	cocos2d::EventListenerCustom     *_backToForegroundListener;
#endif
private:
	RenderFramebuffer();
	bool      init(const cocos2d::Size &frameSize);
public:
	~RenderFramebuffer();
	static RenderFramebuffer  *create(const cocos2d::Size &frameSize);
	//保存现场,在场景渲染的开始的时候调用
	void   save();//
	//在场景渲染结束的时候调用
	void   restore();
	//获取颜色缓冲区对象
	unsigned getColorBuffer();
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	//安卓平台的函数,当Activity重新被创建的时候该函数会被调用
	void      recreate(cocos2d::EventCustom *recreateEvent);
	//将事件监听加入到队列中
	/*void      addAndroidActivityListener();*/
#endif
};
#endif
