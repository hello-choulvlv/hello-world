//
//  lua_register_all_time_api.hpp
//  swtest
//
//  Created by charlie on 2017/6/12.
//
//

#ifndef lua_register_all_time_api_hpp
#define lua_register_all_time_api_hpp

class lua_State;

void register_all_lua_time_api(lua_State* L);

#endif /* lua_register_all_time_api_hpp */
