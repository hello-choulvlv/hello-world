//
//  PathMath.cpp
//  swtest
//
//  Created by charlie on 2017/5/30.
//
//
#include "cocos2d.h"
#include "PathMath.hpp"
#include "scripting/lua-bindings/manual/LuaBasicConversions.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "spine/SkeletonAnimation.h"
#include "BezierRoute.hpp"
#include "SpiralRoute.h"

using namespace cocos2d;

void convertControlPoints(lua_State* L, std::vector<Vec3>& v)
{
	size_t number = lua_objlen(L, 1);

	v.resize(number);

	for (int i = 0; i < number; i++)
	{
		lua_pushnumber(L, i + 1);
		lua_gettable(L, 1);

		lua_getfield(L, -1, "x");
		lua_getfield(L, -2, "y");
		lua_getfield(L, -3, "z");
		v[i].x = lua_tonumber(L, -3);
		v[i].y = lua_tonumber(L, -2);
		v[i].z = lua_tonumber(L, -1);
		lua_pop(L, 4);
	}
}

void convertPointInfo(lua_State* L, std::vector<CubicBezierRoute::PointInfo>& v)
{
	size_t number = lua_objlen(L, 1);

	v.resize(number);

	for (int i = 0; i < number; i++)
	{
		lua_pushnumber(L, i + 1);
		lua_gettable(L, 1);

		lua_getfield(L, -1, "x");
		lua_getfield(L, -2, "y");
		lua_getfield(L, -3, "z");
		lua_getfield(L, -4, "speedCoef");
		v[i].speedCoef = lua_tonumber(L, -1);
		v[i].position.x = lua_tonumber(L, -4);
		v[i].position.y = lua_tonumber(L, -3);
		v[i].position.z = lua_tonumber(L, -2);
		lua_pop(L, 5);
	}
}

int calculate_line(lua_State* L)
{
	std::vector<Vec3> controlPoints;
	convertControlPoints(L, controlPoints);

	float percentage = lua_tonumber(L, 2);

	Vec3 currentPosition;
	Vec3 currentDirection;

	currentDirection = controlPoints[1] - controlPoints[0];
	currentPosition = controlPoints[0] + currentDirection * percentage;

	vec3_to_luaval(L, currentPosition);
	vec3_to_luaval(L, currentDirection);
	lua_pushnumber(L, M_PI_2);

	return 3;
}

int calculate_line3D(lua_State* L)
{
	cocos2d::Vec3 currentPosition;
	cocos2d::Vec3 currentDirection;

	luaval_to_vec3(L, 1, &currentPosition);
	luaval_to_vec3(L, 2, &currentDirection);
	float step = lua_tonumber(L, 3);

	currentPosition = currentPosition + currentDirection * step;

	vec3_to_luaval(L, currentPosition);

	return 1;
}

int calculate_line3D_noTbl(lua_State* L)
{
	cocos2d::Vec3 currentPosition;
	cocos2d::Vec3 currentDirection;

	luaval_to_vec3(L, 1, &currentPosition);
	luaval_to_vec3(L, 2, &currentDirection);
	float step = lua_tonumber(L, 3);

	currentPosition = currentPosition + currentDirection * step;

	vec3_to_luaval(L, currentPosition);

	return 1;
}


int calculate_circle(lua_State* L)
{
	std::vector<Vec3> controlPoints;
	convertControlPoints(L, controlPoints);

	float percentage = lua_tonumber(L, 2);

	Vec3 currentPosition;
	Vec3 currentDirection;

	float centerX = controlPoints[0].x;
	float centerY = controlPoints[0].y;
	float radius = controlPoints[1].x;
	float begin = controlPoints[2].x;
	float fAngle = controlPoints[2].y;
	float fAdd = controlPoints[1].y;
	float absFAngle = fabs(fAngle);
	float _radius = radius * (1 + fAdd * percentage * absFAngle);
	float angle = begin + percentage * absFAngle;
	float offsetX = _radius * cosf(angle);
	float offsetY = _radius * sinf(angle);

	currentPosition = Vec3(centerX + offsetX, centerY + offsetY, 0);
	currentDirection = Vec3(offsetX, -offsetY, 0);

	vec3_to_luaval(L, currentPosition);
	vec3_to_luaval(L, currentDirection);
	lua_pushnumber(L, M_PI_2);

	return 3;
}


float clampAngle(float angle)
{
	float _2PI = M_PI * 2;

	if (angle < 0)
	{
		angle = angle + _2PI;
	}

	if (angle > 0 && angle > _2PI)
	{
		angle = angle - _2PI * (int)(angle / _2PI);
	}

	return angle;
}

int calculate_direction(lua_State* L)
{
	float minX = lua_tonumber(L, 1);
	float minY = lua_tonumber(L, 2);
	float maxX = lua_tonumber(L, 3);
	float maxY = lua_tonumber(L, 4);
	float rotation = lua_tonumber(L, 5);
	float deltaDistance = lua_tonumber(L, 6);
	Vec3 currentPosition;
	luaval_to_vec3(L, 7, &currentPosition);

	Vec3 targetPosition;

	while (deltaDistance > 0)
	{
		float offsetX = deltaDistance * cos(rotation);
		float offsetY = deltaDistance * sin(rotation);
		targetPosition.x = currentPosition.x + offsetX;
		targetPosition.y = currentPosition.y + offsetY;

		if ((targetPosition.x > maxX ||
			targetPosition.x < minX ||
			targetPosition.y > maxY ||
			targetPosition.y < minY))
		{
			if (fabs(rotation - M_2_PI) < 0.0001)
			{
				deltaDistance = targetPosition.y - maxY;
				rotation = M_2_PI * 3;
			}
			else if (fabs(rotation - M_2_PI * 3) < 0.0001)
			{
				deltaDistance = minY - targetPosition.y;
				rotation = M_2_PI;
			}
			else
			{
				float a = offsetY / offsetX;
				float b = currentPosition.y - a * currentPosition.x;

				if (targetPosition.x > maxX)
				{
					float pY = a * maxX + b < minY;

					if (pY > maxY)
					{
						currentPosition.x = (maxY - b) / a;
						currentPosition.y = maxY;

						rotation = M_PI * 2 - rotation;
					}
					else if (pY < minY)
					{
						currentPosition.x = (minY - b) / a;
						currentPosition.y = minY;

						rotation = M_PI * 2 - rotation;
					}
					else
					{
						currentPosition.x = maxX;
						currentPosition.y = a * maxX + b;

						rotation = M_PI - rotation;

						if (rotation < 0)
						{
							rotation = rotation + M_PI * 2;
						}
					}

					float _offsetX = targetPosition.x - currentPosition.x;
					float _offsetY = targetPosition.y - currentPosition.y;

					deltaDistance = sqrtf(_offsetX * _offsetX + _offsetY * _offsetY);
				}
				else if (targetPosition.x < minX)
				{
					float pY = a * minX + b < minY;

					if (pY > maxY)
					{
						currentPosition.x = (maxY - b) / a;
						currentPosition.y = minY;

						rotation = M_PI * 2 - rotation;
					}
					else if (pY < minY)
					{
						currentPosition.x = (minY - b) / a;
						currentPosition.y = minY;

						rotation = M_PI * 2 - rotation;
					}
					else
					{
						currentPosition.x = minX;
						currentPosition.y = a * minX + b;

						rotation = M_PI - rotation;

						if (rotation < 0)
						{
							rotation = rotation + M_PI * 2;
						}
					}

					float _offsetX = targetPosition.x - currentPosition.x;
					float _offsetY = targetPosition.y - currentPosition.y;

					deltaDistance = sqrtf(_offsetX * _offsetX + _offsetY * _offsetY);
				}
				else
				{
					if (targetPosition.y > maxY)
					{
						currentPosition.x = (maxY - b) / a;
						currentPosition.y = maxY;
					}
					else if (targetPosition.y < minY)
					{
						currentPosition.x = (minY - b) / a;
						currentPosition.y = minY;
					}

					float _offsetX = targetPosition.x - currentPosition.x;
					float _offsetY = targetPosition.y - currentPosition.y;

					deltaDistance = sqrtf(_offsetX * _offsetX + _offsetY * _offsetY);
					rotation = M_PI * 2 - rotation;
				}
			}
		}
		else
		{
			currentPosition = targetPosition;
			deltaDistance = 0;
		}
	}

	vec3_to_luaval(L, currentPosition);
	lua_pushnumber(L, rotation);

	return 2;
}

int calculate_direction_noTbl(lua_State *L)
{
	float minX = lua_tonumber(L, 1);
	float minY = lua_tonumber(L, 2);
	float maxX = lua_tonumber(L, 3);
	float maxY = lua_tonumber(L, 4);
	float rotation = lua_tonumber(L, 5);
	float deltaDistance = lua_tonumber(L, 6);
	Vec3 currentPosition;
	luaval_to_vec3(L, 7, &currentPosition);
	bool bounce = lua_toboolean(L, 8);

	Vec3 targetPosition = currentPosition;

	if (bounce)
	{
		while (deltaDistance > 0)
		{
			float offsetX = deltaDistance * cos(rotation);
			float offsetY = deltaDistance * sin(rotation);
			targetPosition.x = currentPosition.x + offsetX;
			targetPosition.y = currentPosition.y + offsetY;

			if ((targetPosition.x > maxX ||
				targetPosition.x < minX ||
				targetPosition.y > maxY ||
				targetPosition.y < minY))
			{
				if (fabs(rotation - M_2_PI) < 0.0001)
				{
					deltaDistance = targetPosition.y - maxY;
					rotation = M_2_PI * 3;
				}
				else if (fabs(rotation - M_2_PI * 3) < 0.0001)
				{
					deltaDistance = minY - targetPosition.y;
					rotation = M_2_PI;
				}
				else
				{
					float a = offsetY / offsetX;
					float b = currentPosition.y - a * currentPosition.x;

					if (targetPosition.x > maxX)
					{
						float pY = a * maxX + b < minY;

						if (pY > maxY)
						{
							currentPosition.x = (maxY - b) / a;
							currentPosition.y = maxY;

							rotation = M_PI * 2 - rotation;
						}
						else if (pY < minY)
						{
							currentPosition.x = (minY - b) / a;
							currentPosition.y = minY;

							rotation = M_PI * 2 - rotation;
						}
						else
						{
							currentPosition.x = maxX;
							currentPosition.y = a * maxX + b;

							rotation = M_PI - rotation;

							if (rotation < 0)
							{
								rotation = rotation + M_PI * 2;
							}
						}

						float _offsetX = targetPosition.x - currentPosition.x;
						float _offsetY = targetPosition.y - currentPosition.y;

						deltaDistance = sqrtf(_offsetX * _offsetX + _offsetY * _offsetY);
					}
					else if (targetPosition.x < minX)
					{
						float pY = a * minX + b < minY;

						if (pY > maxY)
						{
							currentPosition.x = (maxY - b) / a;
							currentPosition.y = minY;

							rotation = M_PI * 2 - rotation;
						}
						else if (pY < minY)
						{
							currentPosition.x = (minY - b) / a;
							currentPosition.y = minY;

							rotation = M_PI * 2 - rotation;
						}
						else
						{
							currentPosition.x = minX;
							currentPosition.y = a * minX + b;

							rotation = M_PI - rotation;

							if (rotation < 0)
							{
								rotation = rotation + M_PI * 2;
							}
						}

						float _offsetX = targetPosition.x - currentPosition.x;
						float _offsetY = targetPosition.y - currentPosition.y;

						deltaDistance = sqrtf(_offsetX * _offsetX + _offsetY * _offsetY);
					}
					else
					{
						if (targetPosition.y > maxY)
						{
							currentPosition.x = (maxY - b) / a;
							currentPosition.y = maxY;
						}
						else if (targetPosition.y < minY)
						{
							currentPosition.x = (minY - b) / a;
							currentPosition.y = minY;
						}

						float _offsetX = targetPosition.x - currentPosition.x;
						float _offsetY = targetPosition.y - currentPosition.y;

						deltaDistance = sqrtf(_offsetX * _offsetX + _offsetY * _offsetY);
						rotation = M_PI * 2 - rotation;
					}
				}
			}
			else
			{
				currentPosition = targetPosition;
				deltaDistance = 0;
			}
		}

		lua_pushstring(L, "x");
		lua_pushnumber(L, targetPosition.x);
		lua_rawset(L, 7);

		lua_pushstring(L, "y");
		lua_pushnumber(L, targetPosition.y);
		lua_rawset(L, 7);

		lua_pushstring(L, "r");
		lua_pushnumber(L, rotation);
		lua_rawset(L, 7);

	}
	else
	{
		float offsetX = deltaDistance * cos(rotation);
		float offsetY = deltaDistance * sin(rotation);
		targetPosition.x = currentPosition.x + offsetX;
		targetPosition.y = currentPosition.y + offsetY;

		lua_pushstring(L, "x");
		lua_pushnumber(L, targetPosition.x);
		lua_rawset(L, 7);

		lua_pushstring(L, "y");
		lua_pushnumber(L, targetPosition.y);
		lua_rawset(L, 7);

		lua_pushstring(L, "r");
		lua_pushnumber(L, rotation);
		lua_rawset(L, 7);
	}
	lua_settop(L, 0);
	return 0;
}

int project_to_view_plane(lua_State* L)
{
	Vec3 position3D;
	luaval_to_vec3(L, 1, &position3D);

	Vec2 position2D = Director::getInstance()->getRunningScene()->getCameras()[0]->projectGL(position3D);
	Vec3 ret = Vec3(position2D.x, position2D.y, 0);
	vec3_to_luaval(L, ret);

	return 1;
}

int create_bezier_route(lua_State* L)
{
	std::vector<CubicBezierRoute::PointInfo> controlPoints;
	convertPointInfo(L, controlPoints);
	float weight = lua_tonumber(L, 2);

	CubicBezierRoute* route = new CubicBezierRoute();
	route->setWeight(weight);
	route->addPoints(controlPoints);

	lua_pushlightuserdata(L, (void*)route);
	return 1;
}

int release_bezier_route(lua_State* L)
{
	CubicBezierRoute* route = (CubicBezierRoute*)lua_touserdata(L, 1);
	delete route;
	return 0;
}

int retrieve_bezier_route_state(lua_State* L)
{
	CubicBezierRoute* route = (CubicBezierRoute*)lua_touserdata(L, 1);
	float distance = lua_tonumber(L, 2);
	Vec3 offset;
	luaval_to_vec3(L, 3, &offset);

	Vec3 currentPosition;
	Vec3 currentDirection;
	float overflow;
	float speedCoef;

	route->retrieveState(currentPosition, currentDirection, speedCoef, overflow, distance);

	//    printf("Position: %.2f, %.2f, %.2f\n", currentPosition.x, currentPosition.y, currentPosition.z);

	lua_pushnumber(L, speedCoef);
	lua_pushnumber(L, overflow);
	vec3_to_luaval(L, currentPosition + offset);
	vec3_to_luaval(L, currentDirection);

	return 4;
}

int get_bezier_route_position(lua_State *L)
{
	CubicBezierRoute* route = (CubicBezierRoute*)lua_touserdata(L, 1);
	float distance = lua_tonumber(L, 2);
	float timeStep = lua_tonumber(L, 3);
	float deltaTime = lua_tonumber(L, 4);
	float speed = lua_tonumber(L, 5);

	Vec3 retPosition;
	Vec3 retDirection;
	float overflow;
	float speedCoef;

	route->retrieveState(retPosition, retDirection, speedCoef, overflow, distance);

	while (deltaTime > timeStep && overflow == 0)
	{
		route->retrieveState(retPosition, retDirection, speedCoef, overflow, distance);
		distance = distance + speed * speedCoef * timeStep;
		deltaTime = deltaTime - timeStep;
	}

	lua_pushstring(L, "x");
	lua_pushnumber(L, retPosition.x);
	lua_rawset(L, 6);

	lua_pushstring(L, "y");
	lua_pushnumber(L, retPosition.y);
	lua_rawset(L, 6);

	lua_pushstring(L, "z");
	lua_pushnumber(L, retPosition.z);
	lua_rawset(L, 6);

	lua_pushstring(L, "x");
	lua_pushnumber(L, retDirection.x);
	lua_rawset(L, 7);

	lua_pushstring(L, "y");
	lua_pushnumber(L, retDirection.y);
	lua_rawset(L, 7);

	lua_pushstring(L, "z");
	lua_pushnumber(L, retDirection.z);
	lua_rawset(L, 7);

	lua_pushnumber(L, distance);
	lua_pushnumber(L, deltaTime);
	lua_pushnumber(L, overflow);

	return 3;
}

//创建螺旋曲线
int create_spiral_route(lua_State *L)
{
	std::vector<Vec3> controlPoint;
	convertControlPoints(L, controlPoint);
	SpiralRoute *route = SpiralRoute::create(controlPoint);
	route->precalculate();

	lua_pushlightuserdata(L, route);
	return 1;
}

int retrieve_spiral_route_state(lua_State *L)
{
	SpiralRoute* route = (SpiralRoute*)lua_touserdata(L, 1);
	float distance = lua_tonumber(L, 2);

	Vec3 currentPosition;
	Vec3 currentDirection;
	int overflow = distance >  route->getSpiralLength();
	float speedCoef = 1.0f;

	//route->retrieveState(currentPosition, currentDirection, speedCoef, overflow, distance);
	//route->getPositionAndTangent(distance, currentPosition, currentDirection);
	route->extract(overflow ? route->getSpiralLength() : distance, currentPosition, currentDirection);
	lua_pushnumber(L, speedCoef);
	lua_pushnumber(L, overflow);
	vec3_to_luaval(L, currentPosition);
	vec3_to_luaval(L, currentDirection);

	return 4;
}

int get_spiral_route_position(lua_State *L)
{
	SpiralRoute* route = (SpiralRoute*)lua_touserdata(L, 1);
	float distance = lua_tonumber(L, 2);
	float timeStep = lua_tonumber(L, 3);
	float deltaTime = lua_tonumber(L, 4);
	float speed = lua_tonumber(L, 5);

	float length = route->getSpiralLength();
	Vec3 retPosition;
	Vec3 retDirection;
	float overflow = distance - length;
	float fixDistance = clampf(distance, 0, length);
	//route->getPositionAndTangent(distance, retPosition, retDirection);
	route->extract(fixDistance, retPosition, retDirection);

	while (deltaTime > timeStep && overflow <= 0)
	{
		float fixDistance = clampf(distance, 0, length);
		route->extract(fixDistance, retPosition, retDirection);
		//route->getPositionAndTangent(distance, retPosition, retDirection);
		distance = distance + speed * timeStep;
		deltaTime = deltaTime - timeStep;
		overflow = distance - length;
	}

	lua_pushstring(L, "x");
	lua_pushnumber(L, retPosition.x);
	lua_rawset(L, 6);

	lua_pushstring(L, "y");
	lua_pushnumber(L, retPosition.y);
	lua_rawset(L, 6);

	lua_pushstring(L, "z");
	lua_pushnumber(L, retPosition.z);
	lua_rawset(L, 6);

	lua_pushstring(L, "x");
	lua_pushnumber(L, retDirection.x);
	lua_rawset(L, 7);

	lua_pushstring(L, "y");
	lua_pushnumber(L, retDirection.y);
	lua_rawset(L, 7);

	lua_pushstring(L, "z");
	lua_pushnumber(L, retDirection.z);
	lua_rawset(L, 7);

	lua_pushnumber(L, distance);
	lua_pushnumber(L, deltaTime);
	lua_pushnumber(L, overflow);

	return 3;
}

int release_spiral_route(lua_State *L)
{
	SpiralRoute * r = (SpiralRoute *)lua_touserdata(L, 1);
	delete r;
	return 0;
}

int get_translation_matrix(lua_State* L)
{
	Vec3 translation;
	luaval_to_vec3(L, 1, &translation);

	Mat4 ret = Mat4::IDENTITY;
	ret.translate(translation);

	mat4_to_luaval(L, ret);

	return 1;
}

int direction_to_quaternion(lua_State* L)
{
	Vec3 direction;
	luaval_to_vec3(L, 1, &direction);
	float roll = lua_tonumber(L, 2);
	bool mirrored = lua_toboolean(L, 3);

	float rotY = 0;
	float rotZ = 0;
	float rotX = roll * M_PI / 180;

	if (direction.z == 0 && direction.x == 0)
	{
		rotY = 0;

		if (direction.y == 0)
		{
			rotZ = 0;
		}
		else if (direction.y > 0)
		{
			rotZ = M_PI / 2;
		}
		else if (direction.y < 0)
		{
			rotZ = -M_PI / 2;
		}

	}
	else
	{
		float length = sqrtf(direction.x * direction.x + direction.z * direction.z);

		rotY = atan2f(-direction.z, direction.x);;
		rotZ = atanf(direction.y / length);
	}

	if (mirrored)
	{
		rotY = -rotY;
		rotZ = rotZ + M_PI;
		rotX = -rotX + M_PI;
	}

	Quaternion quatX = Quaternion(Vec3(1, 0, 0), rotX);
	Quaternion quatY = Quaternion(Vec3(0, 1, 0), rotY);
	Quaternion quatZ = Quaternion(Vec3(0, 0, 1), rotZ);
	Quaternion ret = quatY * quatZ * quatX;

	quaternion_to_luaval(L, ret);

	return 1;
}

int set_orientation(lua_State* L)
{
	cocos2d::Node *target = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &target, "updateSprite3DWithBone");

	if (target)
	{
		Vec3 direction;
		luaval_to_vec3(L, 2, &direction);
		float roll = lua_tonumber(L, 3);
		bool mirrored = lua_toboolean(L, 4);

		float rotY = 0;
		float rotZ = 0;
		float rotX = roll * M_PI / 180;

		if (direction.z == 0 && direction.x == 0)
		{
			rotY = 0;

			if (direction.y == 0)
			{
				rotZ = 0;
			}
			else if (direction.y > 0)
			{
				rotZ = M_PI / 2;
			}
			else if (direction.y < 0)
			{
				rotZ = -M_PI / 2;
			}

		}
		else
		{
			float length = sqrtf(direction.x * direction.x + direction.z * direction.z);

			rotY = atan2f(-direction.z, direction.x);;
			rotZ = atanf(direction.y / length);
		}

		if (mirrored)
		{
			rotY = -rotY;
			rotZ = rotZ + M_PI;
			rotX = -rotX + M_PI;
		}

		Quaternion quatX = Quaternion(Vec3(1, 0, 0), rotX);
		Quaternion quatY = Quaternion(Vec3(0, 1, 0), rotY);
		Quaternion quatZ = Quaternion(Vec3(0, 0, 1), rotZ);

		target->setRotationQuat(quatY * quatZ * quatX);
	}
	lua_settop(L, 0);
	return 0;
}

int transform_position(lua_State* L)
{
	Mat4 transform;
	luaval_to_mat4(L, 1, &transform);

	Vec3 position;
	luaval_to_vec3(L, 2, &position);

	transform.transformPoint(&position);

	vec3_to_luaval(L, position);

	return 1;
}

int transform_direction(lua_State* L)
{
	Mat4 transform;
	luaval_to_mat4(L, 1, &transform);

	Vec3 direction;
	luaval_to_vec3(L, 2, &direction);

	transform.transformVector(&direction);

	vec3_to_luaval(L, direction);

	return 1;
}

int transform_position_ex(lua_State* L)
{
	cocos2d::Node* cachedNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &cachedNode, "updateSpineNode");

	if (cachedNode != nullptr)
	{
		Vec3 position;
		luaval_to_vec3(L, 2, &position);

		cachedNode->getNodeToParentTransform().transformPoint(&position);

		lua_pushstring(L, "x");
		lua_pushnumber(L, position.x);
		lua_rawset(L, 2);

		lua_pushstring(L, "y");
		lua_pushnumber(L, position.y);
		lua_rawset(L, 2);

		lua_pushstring(L, "z");
		lua_pushnumber(L, position.z);
		lua_rawset(L, 2);
	}
	lua_settop(L, 0);
	return 0;
}

int transform_direction_ex(lua_State* L)
{
	cocos2d::Node* cachedNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &cachedNode, "updateSpineNode");

	if (cachedNode != nullptr)
	{
		Vec3 direction;
		luaval_to_vec3(L, 2, &direction);

		cachedNode->getNodeToParentTransform().transformVector(&direction);

		lua_pushstring(L, "x");
		lua_pushnumber(L, direction.x);
		lua_rawset(L, 2);

		lua_pushstring(L, "y");
		lua_pushnumber(L, direction.y);
		lua_rawset(L, 2);

		lua_pushstring(L, "z");
		lua_pushnumber(L, direction.z);
		lua_rawset(L, 2);
	}
	lua_settop(L, 0);
	return 0;
}

int transform_mat(lua_State* L)
{
	Mat4 transform;
	luaval_to_mat4(L, 2, &transform);

	Mat4 mat;
	luaval_to_mat4(L, 1, &mat);

	mat = transform * mat;

	mat4_to_luaval(L, mat);
	lua_settop(L, 1);
	return 1;
}


int generate_transform(lua_State* L)
{
	Vec3 translation;
	luaval_to_vec3(L, 1, &translation);

	Vec3 direction;
	luaval_to_vec3(L, 2, &direction);

	float roll = lua_tonumber(L, 3);

	float scale = lua_tonumber(L, 4);

	float rotY = 0;
	float rotZ = 0;
	float rotX = roll * M_PI / 180;

	if (direction.z == 0 && direction.x == 0)
	{
		rotY = 0;

		if (direction.y == 0)
		{
			rotZ = 0;
		}
		else if (direction.y > 0)
		{
			rotZ = M_PI / 2;
		}
		else if (direction.y < 0)
		{
			rotZ = -M_PI / 2;
		}

	}
	else
	{
		float length = sqrtf(direction.x * direction.x + direction.z * direction.z);

		rotY = atan2f(-direction.z, direction.x);;
		rotZ = atanf(direction.y / length);
	}

	Quaternion quatX = Quaternion(Vec3(1, 0, 0), rotX);
	Quaternion quatY = Quaternion(Vec3(0, 1, 0), rotY);
	Quaternion quatZ = Quaternion(Vec3(0, 0, 1), rotZ);
	Quaternion quatFinal = quatY * quatZ * quatX;

	Mat4 ret;
	ret.translate(translation);
	ret.rotate(quatFinal);
	ret.scale(scale);

	mat4_to_luaval(L, ret);

	return 1;
}

static int calculate_bullet_angle(lua_State *L)
{
	Vec3 bulletPosition;
	Vec3 fishPosition;
	float bulletAngle;
	float dt;

	luaval_to_vec3(L, 1, &bulletPosition);
	luaval_to_vec3(L, 2, &fishPosition);
	//    bulletAngle = lua_tonumber(L, 3);
	//    dt = lua_tonumber(L, 4);

	Vec2 fishPosition2D = Vec2(fishPosition.x, fishPosition.y);
	Vec2 bulletPosition2D = Vec2(bulletPosition.x, bulletPosition.y);

	Vec2 direction = fishPosition2D - bulletPosition2D;
	float targetAngle = atan2(direction.y, direction.x);
	//    targetAngle = targetAngle > 0 ? targetAngle : (targetAngle + 6.2831852);
	//    float angleOffset = targetAngle - bulletAngle;
	//
	//    if(angleOffset > M_PI)
	//    {
	//        angleOffset -= - 6.2831852;
	//    }
	//    else if(angleOffset < -M_PI)
	//    {
	//        angleOffset += 6.2831852;
	//    }
	//
	//    float retAngle = bulletAngle + angleOffset * dt;
	//    retAngle = retAngle > 0 ? retAngle : retAngle + 6.2831852;
	//
	//    if(fabsf(targetAngle - retAngle) < 0.001 ||
	//       ((angleOffset < 0) && (retAngle < targetAngle)) ||
	//       ((angleOffset > 0) && (retAngle > targetAngle)))
	//    {
	//        retAngle = targetAngle;
	//    }

	lua_pushnumber(L, targetAngle);

	return 1;
}

/*
*Sprite3D嵌套Sprite3D,并且子Sprite3D随着父Sprite3D的动画运动而运动
*因此,下面的函数需要实时调用,通常在update周期回调函数里面
*对函数体本身的矩阵运算做了相关的优化,比起在lua里面直接计算或者直接使用矩阵乘法要快很多
*此函数同样可以用到Node上
*/
int  updateSprite3DWithBone(lua_State *L)
{
	cocos2d::Node *other = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &other, "updateSprite3DWithBone");
	cocos2d::Sprite3D *parentNode = (cocos2d::Sprite3D*)other->getParent();
	const char *boneName = lua_tostring(L, 2);
	Bone3D *bone = parentNode->getSkeleton()->getBoneByName(boneName);//getRootBone(0);//
	if (bone)
	{
		float  array[4][4];
		float scale = other->getScale();

		const cocos2d::Mat4 &parentTransform = bone->getWorldMat();
		const Vec3  V = other->getPosition3D();

		array[0][0] = parentTransform.m[0] * scale;
		array[0][1] = parentTransform.m[1] * scale;
		array[0][2] = parentTransform.m[2] * scale;
		array[0][3] = parentTransform.m[3] * scale;

		array[1][0] = parentTransform.m[4] * scale;
		array[1][1] = parentTransform.m[5] * scale;
		array[1][2] = parentTransform.m[6] * scale;
		array[1][3] = parentTransform.m[7] * scale;

		array[2][0] = parentTransform.m[8] * scale;
		array[2][1] = parentTransform.m[9] * scale;
		array[2][2] = parentTransform.m[10] * scale;
		array[2][3] = parentTransform.m[11] * scale;

		array[3][0] = parentTransform.m[0] * V.x + parentTransform.m[4] * V.y + parentTransform.m[8] * V.z + parentTransform.m[12];
		array[3][1] = parentTransform.m[1] * V.x + parentTransform.m[5] * V.y + parentTransform.m[9] * V.z + parentTransform.m[13];
		array[3][2] = parentTransform.m[2] * V.x + parentTransform.m[6] * V.y + parentTransform.m[10] * V.z + parentTransform.m[14];
		array[3][3] = parentTransform.m[3] * V.x + parentTransform.m[7] * V.y + parentTransform.m[11] * V.z + parentTransform.m[15];
		other->setNodeToParentTransform(*(cocos2d::Mat4*)array);
	}
	lua_settop(L, 0);
	return 0;
}

int  updateSprite3DWithBoneEx(lua_State *L)
{
	cocos2d::Node *other = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &other, "updateSprite3DWithBone");
	cocos2d::Sprite3D *parentNode = nullptr;
	luaval_to_object<cocos2d::Sprite3D>(L, 2, "cc.Node", &parentNode, "updateSprite3DWithBone");
	const char *boneName = lua_tostring(L, 3);
	bool onlyPosition = lua_toboolean(L, 4);

	Bone3D *bone = parentNode->getSkeleton()->getBoneByName(boneName);
	if (bone)
	{
		const Mat4& boneTransform = bone->getWorldMat();
		const Mat4& parentTransform = parentNode->getNodeToParentTransform();
		float pArray[16];
		Mat4 &bindingTransform = *(Mat4*)pArray;
		//Mat4 bindingTransform = parentTransform * boneTransform;
		Mat4::multiply(parentTransform, boneTransform, &bindingTransform);
		Vec3 originalPosition = other->getPosition3D();
		Quaternion rotation = other->getRotationQuat();
		float originalScale = other->getScale();
		float parentScale = parentNode->getScale();

		if (onlyPosition)
		{
			Vec3 position = originalPosition;
			bindingTransform.transformPoint(&position);
			//注意Cococs2dx引擎对矩阵乘法的运算顺序做了重定义,因此以下代码的实际计算顺序为先缩放再旋转,再平移
			Mat4 finalTransform;
			finalTransform.translate(position);
			finalTransform.rotate(rotation);
			//依据计算的顺序,矩阵的最后四个分量不用参与运算
			const float cascadeScale = originalScale * parentScale;
			for (int i = 0; i < 12; ++i)
				finalTransform.m[i] *= cascadeScale;
			other->setNodeToParentTransform(finalTransform);//(translateMatrix * rotateMatrix * scaleMatrix);
		}
		else
		{
			//调整了矩阵运算的顺序
			Mat4 finalTransform;
			finalTransform.translate(originalPosition);
			finalTransform.rotate(rotation);
			for (int i = 0; i < 12; i++)
				finalTransform.m[i] *= originalScale;
			//  finalTransform = bindingTransform * finalTransform;
			other->setNodeToParentTransform(bindingTransform * finalTransform);
		}
	}
	lua_settop(L, 0);
	return 0;
}

int  updateNodeWithBone(lua_State *L)
{
	cocos2d::Node *other = nullptr;
	cocos2d::Sprite3D *targetNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &other, "updateSprite3DWithBone");
	luaval_to_object<cocos2d::Sprite3D>(L, 2, "cc.Node", &targetNode, "updateNodeWithBone");
	const char *boneName = lua_tostring(L, 3);
	Bone3D *bone = targetNode->getSkeleton()->getBoneByName(boneName);//getRootBone(0);//
	if (bone)
	{
		float  array[4][4];
		float scale = other->getScale();

		const cocos2d::Mat4 &parentTransform = bone->getWorldMat();
		const Vec3  V = other->getPosition3D();

		array[0][0] = parentTransform.m[0] * scale;
		array[0][1] = parentTransform.m[1] * scale;
		array[0][2] = parentTransform.m[2] * scale;
		array[0][3] = parentTransform.m[3] * scale;

		array[1][0] = parentTransform.m[4] * scale;
		array[1][1] = parentTransform.m[5] * scale;
		array[1][2] = parentTransform.m[6] * scale;
		array[1][3] = parentTransform.m[7] * scale;

		array[2][0] = parentTransform.m[8] * scale;
		array[2][1] = parentTransform.m[9] * scale;
		array[2][2] = parentTransform.m[10] * scale;
		array[2][3] = parentTransform.m[11] * scale;

		array[3][0] = parentTransform.m[0] * V.x + parentTransform.m[4] * V.y + parentTransform.m[8] * V.z + parentTransform.m[12];
		array[3][1] = parentTransform.m[1] * V.x + parentTransform.m[5] * V.y + parentTransform.m[9] * V.z + parentTransform.m[13];
		array[3][2] = parentTransform.m[2] * V.x + parentTransform.m[6] * V.y + parentTransform.m[10] * V.z + parentTransform.m[14];
		array[3][3] = parentTransform.m[3] * V.x + parentTransform.m[7] * V.y + parentTransform.m[11] * V.z + parentTransform.m[15];
		other->setNodeToParentTransform(*(cocos2d::Mat4*)array);
	}
	lua_settop(L, 0);
	return 0;
}
/*
*将Node与Sprite3D的某一个骨骼绑定到一起,但是并不随着Sprite3D的旋转而旋转
*函数的主要作用就是,将Node随着Sprite3D自身动画的跳动而跳动,但是不随着Sprite3D
*的旋转而旋转
*/
static int _static_updateNodeWithoutRotate(lua_State *L)
{
	cocos2d::Node			*node = nullptr;
	cocos2d::Sprite3D    *targetSprite3D = nullptr;
	std::string                  boneName;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &node, "updateNodeWithoutRotate");
	luaval_to_object<cocos2d::Sprite3D>(L, 2, "cc.Sprite3D", &targetSprite3D, "updateNodeWithoutRotate");
	luaval_to_std_string(L, 3, &boneName, "updateNodeWithoutRotate");
	Bone3D *bone = targetSprite3D->getSkeleton()->getBoneByName(boneName);
	if (bone)
	{
		const Mat4			&worldMat4 = bone->getWorldMat();
		//计算缩放,平移矩阵
		const float			*M = worldMat4.m;
		//const Vec3           translateV3(M[12], M[13], M[14]);
		//Vec3        scaleV3(Vec3(M[0], M[1], M[2]).length(),Vec3(M[4], M[5], M[6]).length(),Vec3(M[8],M[9],M[10]).length() );
		const float sprite3DScale = targetSprite3D->getScale();
		const Vec3			scaleV3(sprite3DScale, sprite3DScale, sprite3DScale);
		//再次计算矩阵乘法
		float    scale = node->getScale();
		Vec3   V = node->getPosition3D();
		float    array[4][4];
		//先局部矩阵(实际上是一个偏置矩阵),再上层矩阵(只使用平移与缩放部分)
		array[0][0] = scale;// *scaleV3.x;
		array[0][1] = 0;
		array[0][2] = 0;
		array[0][3] = 0;

		array[1][0] = 0;
		array[1][1] = scale;// *scaleV3.y;
		array[1][2] = 0;
		array[1][3] = 0;

		array[2][0] = 0;
		array[2][1] = 0;
		array[2][2] = scale;// *scaleV3.z;
		array[2][3] = 0.0f;

		array[3][0] = V.x /** scaleV3.x*/ + M[12] * scaleV3.x;
		array[3][1] = V.y /** scaleV3.y*/ + M[13] * scaleV3.y;
		array[3][2] = V.z/* * scaleV3.z*/ + M[14] * scaleV3.z;
		array[3][3] = 1.0f;

		node->setNodeToParentTransform(*(cocos2d::Mat4*)array);
	}
	lua_settop(L, 0);
	return 0;
}
/*
*将一个3d坐标A转换成在视觉上显示在相同位置的另一个3d坐标B,
*B的深度可大可小
*/

static int  projectSameNDC(lua_State *L)
{
	cocos2d::Vec3 point;
	double				zDepth;
	luaval_to_vec3(L, 1, &point, "projectSameNDC");
	luaval_to_number(L, 2, &zDepth, "projectSameNDC");
	cocos2d::Camera *camera = cocos2d::Camera::getDefaultCamera();
	cocos2d::Vec4       clipPoint;
	const cocos2d::Mat4 &viewProjMatrix = camera->getViewProjectionMatrix();
	viewProjMatrix.transformVector(cocos2d::Vec4(point.x, point.y, point.z, 1.0f), &clipPoint);
	//convert to NDC
	clipPoint.x /= clipPoint.w;
	clipPoint.y /= clipPoint.w;
	clipPoint.z /= clipPoint.w;
	//求目标点的深度
	cocos2d::Vec4   clipPoint2;
	viewProjMatrix.transformVector(cocos2d::Vec4(point.x, point.y, point.z + zDepth, 1.0f), &clipPoint2);
	//求目标点
	cocos2d::Vec4  targetPoint;
	const cocos2d::Mat4 viewProjInverse = viewProjMatrix.getInversed();//camera->getViewProjectionMatrixInverse();
	viewProjInverse.transformVector(cocos2d::Vec4(clipPoint.x, clipPoint.y, clipPoint2.z / clipPoint2.w, 1.0f), &targetPoint);
	vec3_to_luaval(L, cocos2d::Vec3(targetPoint.x / targetPoint.w, targetPoint.y / targetPoint.w, targetPoint.z / targetPoint.w));
	return 1;
}

static int updateSpineNode(lua_State *L)
{
	cocos2d::Node *child;
	std::string        boneName;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &child, "updateSpineNode");
	luaval_to_std_string(L, 2, &boneName, "updateSpineNode");
	spine::SkeletonAnimation *skeleton = (spine::SkeletonAnimation*)child->getParent();
	//Bone Name
	spBone *bone = skeleton->findBone(boneName);
	if (bone)
	{
		float x = bone->worldX;
		float y = bone->worldY;
		float angle = bone->rotation;
		float scaleX = spBone_getWorldScaleX(bone);
		float scaleY = spBone_getWorldScaleY(bone);
		//
		child->setPosition(Vec2(x, y));
		child->setRotation(angle);
		child->setScaleX(scaleX);
		child->setScaleY(scaleY);
	}
	lua_settop(L, 0);
	return 0;
}

static int set_node_transform(lua_State *L)
{
	cocos2d::Node* node;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &node, "updateSpineNode");

	Vec3 translation;
	luaval_to_vec3(L, 2, &translation);

	Vec3 direction;
	luaval_to_vec3(L, 3, &direction);

	float roll = lua_tonumber(L, 4);

	float scale = lua_tonumber(L, 5);

	float rotY = 0;
	float rotZ = 0;
	float rotX = roll * M_PI / 180;

	if (direction.z == 0 && direction.x == 0)
	{
		rotY = 0;

		if (direction.y == 0)
		{
			rotZ = 0;
		}
		else if (direction.y > 0)
		{
			rotZ = M_PI / 2;
		}
		else if (direction.y < 0)
		{
			rotZ = -M_PI / 2;
		}

	}
	else
	{
		float length = sqrtf(direction.x * direction.x + direction.z * direction.z);

		rotY = atan2f(-direction.z, direction.x);;
		rotZ = atanf(direction.y / length);
	}

	Quaternion quatX = Quaternion(Vec3(1, 0, 0), rotX);
	Quaternion quatY = Quaternion(Vec3(0, 1, 0), rotY);
	Quaternion quatZ = Quaternion(Vec3(0, 0, 1), rotZ);
	Quaternion quatFinal = quatY * quatZ * quatX;

	node->setPosition3D(translation);
	node->setRotationQuat(quatFinal);
	node->setScale(scale);

	//const Mat4 &transform = node->getNodeToParentTransform();
	lua_settop(L, 0);
	return 0;
}

static int combine_transform(lua_State *L)
{
	cocos2d::Node* cachedNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &cachedNode, "updateSpineNode");

	cocos2d::Node* parentNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 2, "cc.Node", &parentNode, "updateSpineNode");

	cocos2d::Node* transformNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 3, "cc.Node", &transformNode, "updateSpineNode");

	cocos2d::Node* motionNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 4, "cc.Node", &motionNode, "updateSpineNode");

	if (parentNode != nullptr)
	{
		cachedNode->setNodeToParentTransform(parentNode->getNodeToParentTransform() * transformNode->getNodeToParentTransform() * motionNode->getNodeToParentTransform());
	}
	else
	{
		cachedNode->setNodeToParentTransform(transformNode->getNodeToParentTransform() * motionNode->getNodeToParentTransform());
	}
	lua_settop(L, 0);
	return 0;
}

static int copy_transform(lua_State *L)
{
	cocos2d::Node* srcNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 1, "cc.Node", &srcNode, "updateSpineNode");

	cocos2d::Node* targetNode = nullptr;
	luaval_to_object<cocos2d::Node>(L, 2, "cc.Node", &targetNode, "updateSpineNode");

	if (srcNode != nullptr && targetNode != nullptr)
	{
		targetNode->setNodeToParentTransform(srcNode->getNodeToParentTransform());
	}
	lua_settop(L, 0);
	return 0;
}

static int get_bone_position(lua_State *L)
{
	cocos2d::Sprite3D* node = nullptr;
	luaval_to_object<cocos2d::Sprite3D>(L, 1, "cc.Sprite3D", &node, "updateSpineNode");

	const char *boneName = lua_tostring(L, 2);

	if (node != nullptr)
	{
		cocos2d::Skeleton3D* skeleton = node->getSkeleton();
		cocos2d::Bone3D* bone = nullptr;

		if (boneName != nullptr)
		{
			bone = skeleton->getBoneByName(boneName);
		}
		else
		{
			bone = skeleton->getRootBone(0);
		}

		if (bone != nullptr)
		{
			//Mat4 transform = node->getNodeToWorldTransform() * bone->getWorldMat();
			//
			float  pArray[16];
			Mat4  &transform = *(Mat4*)pArray;
			//
			Mat4::multiply(node->getNodeToWorldTransform(), bone->getWorldMat(), &transform);
			Vec3 position = Vec3(0, 0, 0);
			transform.transformPoint(&position);

			lua_pushstring(L, "x");
			lua_pushnumber(L, position.x);
			lua_rawset(L, 3);

			lua_pushstring(L, "y");
			lua_pushnumber(L, position.y);
			lua_rawset(L, 3);

			lua_pushstring(L, "z");
			lua_pushnumber(L, position.z);
			lua_rawset(L, 3);
		}
	}
	lua_settop(L, 0);
	return 0;
}

int    register_fishtd_version(lua_State *L)
{
	//版本1,用来跟是否修复了安卓-iOS平台鱼广播动画的bug做区分
	//版本2是否对原来的C++函数做了改进,比如将原来鱼潮计算放到了C++,鱼位置按照骨骼点来计算.
	//版本3将原来的lua调C++函数无返回值的地方统一做了lua堆栈清理,并且将TextureCache文件中的异步加载纹理的方式中的bug做了修正.
	lua_pushinteger(L, 4);
	return 1;
}

void register_all_path_math(lua_State* L)
{
	luaL_Reg mathlib[] = {
		{ "calculateLine",   calculate_line },
		{ "calculateCircle",   calculate_circle },
		{ "calculateBulletAngle",   calculate_bullet_angle },
		{ "calculateDirection3D",   calculate_line3D },
		{ "calculateDirection",   calculate_direction },
		{ "calculateDirectionNoTbl",   calculate_direction_noTbl },
		{ "projectToViewPlane", project_to_view_plane },
		//
		{ "createBezierRoute", create_bezier_route },
		{ "releaseBezierRoute", release_bezier_route },
		{ "retrieveBezierRouteState", retrieve_bezier_route_state },
		{ "getBezierRoutePosition", get_bezier_route_position },
		//
		{ "createSpiralRoute",create_spiral_route },
		{ "releaseSpiralRoute",release_spiral_route },
		{ "retrieveSpiralRouteState",retrieve_spiral_route_state },
		{ "getSpiralRoutePosition", get_spiral_route_position },
		//
		{ "getTranslationMatrix", get_translation_matrix },
		{ "directionToQuat", direction_to_quaternion },
		{ "setOrientation", set_orientation },
		{ "transformPosition", transform_position },
		{ "transformDirection", transform_direction },
		{ "transformPositionEx", transform_position_ex },
		{ "transformDirectionEx", transform_direction_ex },
		{ "transformMat", transform_mat },
		{ "generateTransform", generate_transform },
		{ "updateSprite3DWithBoneEx",updateSprite3DWithBoneEx },
		{ "updateSprite3DWithBone",updateSprite3DWithBone },
		{ "updateNodeWithBone",updateNodeWithBone },
		{ "updateNodeWithoutRotate",_static_updateNodeWithoutRotate },
		{ "projectSameNDC",projectSameNDC },
		{ "updateSpineNode",updateSpineNode },
		{ "setNodeTransform",set_node_transform },
		{ "combineTransform",combine_transform },

		{ "copyTransform", copy_transform },
		{ "getBonePosition", get_bone_position },
		{ "getVersion",register_fishtd_version },
		{ NULL, NULL }
	};

	luaL_openlib(L, "PathMath", mathlib, 0);
}
