//
//  lua_collision_manager.hpp
//  swtest
//
//  Created by charlie on 2017/6/2.
//
//

#ifndef lua_collision_manager_hpp
#define lua_collision_manager_hpp

class lua_State;

void register_all_lua_collision_manager(lua_State* L);

#endif /* lua_collision_manager_hpp */
