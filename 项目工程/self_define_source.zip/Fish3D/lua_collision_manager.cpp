//
//  lua_collision_manager.cpp
//  swtest
//
//  Created by charlie on 2017/6/2.
//
//
#include "cocos2d.h"
#include "lua_collision_manager.hpp"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "scripting/lua-bindings/manual/LuaBasicConversions.h"
#include "scripting/lua-bindings/manual/lua_module_register.h"
#include "CollisionManagerRev.hpp"
#include "GameDebugger.hpp"
#include "PathMath.hpp"


using namespace cocos2d;
using namespace Rev;



int claim_collision_area(lua_State* L)
{
    const char* configName = lua_tostring(L, 1);
    CollisionManager::CollisionArea* area = CollisionManager::getInstance()->claimCollisionArea(configName);
    if(area)
    {
        lua_pushlightuserdata(L, (void*)area);
        return 1;
    }
    else
    {
        return 0;
    }
}

int reclaim_collision_area(lua_State* L)
{
    CollisionManager::CollisionArea* area = (CollisionManager::CollisionArea*)lua_touserdata(L, 1);
    CollisionManager::getInstance()->reclaimCollisionArea(area);
	lua_settop(L,0);
    return 0;
}

int register_collision_area(lua_State* L)
{
    CollisionManager::CollisionArea* area = (CollisionManager::CollisionArea*)lua_touserdata(L, 1);
    CollisionManager::getInstance()->registerArea(area);
	lua_settop(L, 0);
    return 0;
}

int unregister_collision_area(lua_State* L)
{
    CollisionManager::CollisionArea* area = (CollisionManager::CollisionArea*)lua_touserdata(L, 1);
    CollisionManager::getInstance()->unregisterArea(area);
	lua_settop(L,0);
    return 0;
}

int update_collision_area(lua_State* L)
{
    CollisionManager::CollisionArea* area = (CollisionManager::CollisionArea*)lua_touserdata(L, 1);
    Mat4 transform = Mat4::IDENTITY;
    luaval_to_mat4(L, 2, &transform);
    Skeleton3D* skeleton = nullptr;
    luaval_to_object<cocos2d::Skeleton3D>(L, 3, "cc.Skeleton3D", &skeleton, "cc.Node:addChild");
    if(area)
    {
        area->bind(skeleton, transform);
    }
	lua_settop(L,0);
    return 0;
}

int update_collision_area_ex(lua_State* L)
{
    CollisionManager::CollisionArea* area = (CollisionManager::CollisionArea*)lua_touserdata(L, 1);
    cocos2d::Node* node = nullptr;
    luaval_to_object<cocos2d::Node>(L, 2, "cc.Node", &node, "updateSprite3DWithBone");
    
    if(area != nullptr && node != nullptr)
    {
        cocos2d::Sprite3D* sprite = dynamic_cast<cocos2d::Sprite3D*>(node);
        
        if(sprite != nullptr)
        {
            area->bind(sprite->getSkeleton(), sprite->getNodeToWorldTransform());
        }
        else
        {
            area->bind(nullptr, node->getNodeToWorldTransform());
        }
    }
	lua_settop(L, 0);
    return 0;
}

int disable_collision_area(lua_State* L)
{
    CollisionManager::CollisionArea* area = (CollisionManager::CollisionArea*)lua_touserdata(L, 1);
    bool willEnable = !lua_toboolean(L, 2);
	if(area)
		area->setEnabled(willEnable);
	lua_settop(L, 0);
    return 0;
}

int set_collision_mask(lua_State* L)
{
    CollisionManager::CollisionArea* area = (CollisionManager::CollisionArea*)lua_touserdata(L, 1);
    unsigned int collisionMask = lua_tonumber(L, 2);
    area->setCollisionMask(collisionMask);
	lua_settop(L, 0);
    return 0;
}

int load_config(lua_State* L)
{
    const char* configName = lua_tostring(L, 1);
    const char* configPath = lua_tostring(L, 2);
	const int      type =(int) lua_tonumber(L, 3);
    SimpleCollisionManager::COLLISION_AREA_TYPE configType = (SimpleCollisionManager::COLLISION_AREA_TYPE)type;
    
    SimpleCollisionManager* manager = (SimpleCollisionManager*)CollisionManager::getInstance();
    manager->readConfig(configName, configPath, configType);
	lua_settop(L, 0);
    return 0;
}

int collision_update(lua_State* L)
{
    float dt = lua_tonumber(L, 1);
    CollisionManager::getInstance()->update(dt);
	lua_settop(L, 0);
    return 0;
}

int debug_update(lua_State* L)
{
    float dt = lua_tonumber(L, 1);
    GameDebugger::getInstance()->update(dt);
	lua_settop(L, 0);
    return 0;
}


int init_debug(lua_State* L)
{
    cocos2d::Scene* scene = nullptr;
    luaval_to_object<cocos2d::Scene>(L, 1, "cc.Scene", &scene, "cc.Node:addChild");
    GameDebugger::getInstance()->initWithScene(scene);
	lua_settop(L, 0);
    return 0;
}

void collision_event_handler(lua_State* L, CollisionManager::CollisionArea* targetA, CollisionManager::CollisionArea* targetB)
{
    lua_getglobal(L, "C_CollisionManager");
    lua_getfield(L, -1, "luaEventHandler");
    lua_pushlightuserdata(L, (void*)targetA);
    lua_pushlightuserdata(L, (void*)targetB);
    lua_call(L, 2, 0);
	lua_settop(L, 0);
}



void register_all_lua_collision_manager(lua_State* L)
{
    void (*func)(lua_State* L, CollisionManager::CollisionArea*, CollisionManager::CollisionArea*) = collision_event_handler;
    
    CollisionManager::getInstance()->setCollisionEventCallback([L, func](CollisionManager::CollisionArea* targetA, CollisionManager::CollisionArea* targetB){
        
        func(L, targetA, targetB);
        
    });
    
    luaL_Reg mathlib[] = {
        {"claimCollisionArea",   claim_collision_area},
        {"reclaimCollisionArea",   reclaim_collision_area},
        {"disableCollisionArea",   disable_collision_area},
        {"registerCollisionArea",   register_collision_area},
        {"unregisterCollisionArea",   unregister_collision_area},
        {"updateCollisionArea",   update_collision_area},
        {"updateCollisionAreaEx",   update_collision_area_ex},
        {"setCollisionMask", set_collision_mask},
        {"update", collision_update},
        {"updateDebug", debug_update},
        {"loadConfig", load_config},
        {"initDebug", init_debug},
        {NULL, NULL}
    };
    
    
    luaL_openlib(L, "C_CollisionManager", mathlib, 0);
}
