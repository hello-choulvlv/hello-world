//
//  lua_xml_parser.hpp
//  simulator
//
//  Created by charlie on 2017/6/2.
//
//

#ifndef lua_xml_parser_hpp
#define lua_xml_parser_hpp

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif

int register_all_custom_net(lua_State* tolua_S);


#endif /* lua_xml_parser_hpp */
