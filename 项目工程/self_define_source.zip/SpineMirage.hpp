//
//  SpineMirage.hpp
//  cocos2d_lua_bindings
//
//  Created by xiaoxiong2 on 2017/12/31.
//

#ifndef SpineMirage_hpp
#define SpineMirage_hpp

#include <stdio.h>
#include <cocos2d.h>

class SpineEntity;

class SpineMirage: public cocos2d::Node
{
public:
    ~SpineMirage();
    
private:
    SpineMirage();
    
public:
    virtual void onEnter() override;
    virtual void onExit() override;
    virtual void setVisible(bool visible) override;
    virtual void draw (cocos2d::Renderer* renderer, const cocos2d::Mat4& transform, uint32_t transformFlags) override;
    
private:
    void changeActivateState(bool activated);
    void initGLProgram();
    
private:
    SpineEntity* __entity;
    bool __activated;
    
    friend class SpineEntityManager;
};

#endif /* SpineMirage_hpp */
