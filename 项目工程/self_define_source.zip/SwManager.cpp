//
// Created by sj on 2017/4/14.
//


#include "SwManager.h"
#include "external/unzip/unzip.h"
#include "network/SWHTTPRequest.h"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#include <ifaddrs.h>

#endif

#ifndef _WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <net/if.h>
#include <cares/ares.h>
#else
#include <WinSock2.h>
#include <ws2tcpip.h>
#endif

using namespace cocos2d;

#define IP_LEN 32

typedef struct {
    char host[64];
    char ip[10][IP_LEN];
    int count;
    int family;
    int status;
}IpList;

SwManager *SwManager::_instance = nullptr;

void SwManager::deploy() {
    _stack = cocos2d::LuaEngine::getInstance()->getLuaStack();
    /*_cryptoLoad = new TcpCrypto();
    _cryptoRoom = new TcpCrypto();*/
}

SwManager *SwManager::getInstance() {
    if (_instance == nullptr) {
        _instance = new SwManager();
    }
    return _instance;
}

SwManager::~SwManager() {

}

SwManager::SwManager()
/*  :
  _cryptoLoad(nullptr),
  _cryptoRoom(nullptr)*/
{
}

void SwManager::getaddrinfo(std::string $host, int $luaCallback) {
    std::thread([=]() {
        do {
            struct addrinfo *result = NULL;
            struct addrinfo *ptr = NULL;
            std::string jsonResult = "";
            int dwRetval = ::getaddrinfo($host.c_str(), 0, NULL, &result);
            if (dwRetval == 0) {
                for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {
                    switch (ptr->ai_family) {
                        case AF_INET: {
                            auto sockaddr_ipv4 = (struct sockaddr_in *) ptr->ai_addr;
                            std::string ip = inet_ntoa(sockaddr_ipv4->sin_addr);
                            if (!jsonResult.empty()) {
                                jsonResult += ",";
                            }
                            jsonResult += "{\"family\":\"inet4\",\"addr\":\"" + ip + "\"}";
                            break;
                        }
                        case AF_INET6: {
                            char abuf[INET6_ADDRSTRLEN];
                            auto sockaddr_ipv6 = (struct sockaddr_in6 *) ptr->ai_addr;
                            if (!jsonResult.empty()) {
                                jsonResult += ",";
                            }
                            std::string ip = inet_ntop(AF_INET6, &sockaddr_ipv6->sin6_addr, abuf, 46);
                            jsonResult += "{\"family\":\"inet6\",\"addr\":\"" + ip + "\"}";
                            break;
                        }
                        default:
                            break;
                    }
                }
            }

            if (jsonResult.empty()) {
                char dwRetvalStr[12];
                sprintf(dwRetvalStr, "%d", dwRetval);
                std::string str = dwRetvalStr;
                jsonResult = "{\"errorCode\":" + str + "}";
            } else {
                jsonResult = "[" + jsonResult + "]";
            }

            Director::getInstance()->getScheduler()->performFunctionInCocosThread([=] {
                if ($luaCallback != 0) {
                    _stack->pushString(jsonResult.c_str());
                    _stack->executeFunctionByHandler($luaCallback, 1);
                    _stack->clean();
                }
            });
        } while (0);
    }).detach();
}

void SwManager::uncompressFile(std::string $zipFile, std::string $outputUrl, int $luaSuccessCallback, int $luaErrorCallback) {
    std::thread([=]() {
        do {
            // Uncompress zip file.
            int error = doUncompress($zipFile, $outputUrl);
            if (error != 0) {
                Director::getInstance()->getScheduler()->performFunctionInCocosThread([=] {
                    if ($luaErrorCallback != 0) {
                        _stack->pushInt(error);
                        _stack->executeFunctionByHandler($luaErrorCallback, 1);
                        _stack->clean();
                    }
                });
                break;
            }

            Director::getInstance()->getScheduler()->performFunctionInCocosThread([=] {
                /* 不要删除文件，lua去控制是否删除
                 if (remove($zipFile.c_str()) != 0) {
                    CCLOG("can not remove zip file:%s", $zipFile.c_str());
                }*/
                //解压成功
                if ($luaSuccessCallback != 0) {
                    _stack->executeFunctionByHandler($luaSuccessCallback, 0);
                    _stack->clean();
                }
            });
        } while (0);
    }).detach();
}

int SwManager::doUncompress(std::string $zipFile, std::string $outputUrl) {
    const int BUFFER_SIZE = 8192;
    const int MAX_FILENAME = 512;
    ssize_t size = 0;
    unsigned char *buffer = FileUtils::getInstance()->getFileData(FileUtils::getInstance()->getSuitableFOpen($zipFile).c_str(), "rb", &size);
    if (!buffer || size == 0){
        CCLOG("can not open zip file %s", $zipFile.c_str());
        return 1;
    }
    // Open the zip file
    unzFile zipfile = unzOpenBuffer(buffer, size);
    if (!zipfile) {
        CCLOG("can not open zip file %s", $zipFile.c_str());
        return 1;
    }

    // Get info about the zip file
    unz_global_info global_info;
    if (unzGetGlobalInfo(zipfile, &global_info) != UNZ_OK) {
        CCLOG("can not read file global info of %s", $zipFile.c_str());
        unzClose(zipfile);
        return 2;
    }

    // Buffer to hold data read from the zip file
    char readBuffer[BUFFER_SIZE];

    CCLOG("start uncompressing");

    // Loop to extract all files.
    uLong i;
    for (i = 0; i < global_info.number_entry; ++i) {
        // Get info about current file.
        unz_file_info fileInfo;
        char fileName[MAX_FILENAME];
        if (unzGetCurrentFileInfo(zipfile,
                &fileInfo,
                fileName,
                MAX_FILENAME,
                nullptr,
                0,
                nullptr,
                0) != UNZ_OK) {
            CCLOG("can not read file info");
            unzClose(zipfile);
            return 3;
        }

        const std::string fullPath = $outputUrl + fileName;

        // Check if this entry is a directory or a file.
        const size_t filenameLength = strlen(fileName);
        if (fileName[filenameLength - 1] == '/') {
            // Entry is a directory, so create it.
            // If the directory exists, it will failed silently.
            if (!FileUtils::getInstance()->createDirectory(fullPath)) {
                CCLOG("can not create directory %s", fullPath.c_str());
                unzClose(zipfile);
                return 4;
            }
        } else {
            //There are not directory entry in some case.
            //So we need to test whether the file directory exists when uncompressing file entry
            //, if does not exist then create directory
            const std::string fileNameStr(fileName);

            size_t startIndex = 0;

            size_t index = fileNameStr.find("/", startIndex);

            while (index != std::string::npos) {
                const std::string dir = $outputUrl + fileNameStr.substr(0, index);

                FILE *out = fopen(FileUtils::getInstance()->getSuitableFOpen(dir).c_str(), "r");

                if (!out) {
                    if (!FileUtils::getInstance()->createDirectory(dir)) {
                        CCLOG("can not create directory %s", dir.c_str());
                        unzClose(zipfile);
                        return 4;
                    } else {
                        //CCLOG("create directory %s", dir.c_str());
                    }
                } else {
                    fclose(out);
                }
                startIndex = index + 1;
                index = fileNameStr.find("/", startIndex);
            }
            // Entry is a file, so extract it.
            // Open current file.
            if (unzOpenCurrentFile(zipfile) != UNZ_OK) {
                CCLOG("can not open file %s", fileName);
                unzClose(zipfile);
                return 5;
            }

            // Create a file to store current file.
            FILE *out = fopen(FileUtils::getInstance()->getSuitableFOpen(fullPath).c_str(), "wb");
            if (!out) {
                CCLOG("can not open destination file %s", fullPath.c_str());
                unzCloseCurrentFile(zipfile);
                unzClose(zipfile);
                return 6;
            }

            // Write current file content to destinate file.
            int error = UNZ_OK;
            do {
                error = unzReadCurrentFile(zipfile, readBuffer, BUFFER_SIZE);
                if (error < 0) {
                    CCLOG("can not read zip file %s, error code is %d", fileName, error);
                    unzCloseCurrentFile(zipfile);
                    unzClose(zipfile);
                    return 7;
                }

                if (error > 0) {
                    fwrite(readBuffer, error, 1, out);
                }
            } while (error > 0);

            fclose(out);
        }

        unzCloseCurrentFile(zipfile);

        // Goto next entry listed in the zip file.
        if ((i + 1) < global_info.number_entry) {
            if (unzGoToNextFile(zipfile) != UNZ_OK) {
                CCLOG("can not read next file");
                unzClose(zipfile);
                return 8;
            }
        }
    }
    
    CCLOG("end uncompressing");
    unzClose(zipfile);
    
    if (buffer){
        delete[] buffer;
    }

    return 0;
}

bool SwManager::unMappedBuffer(void *$buffer, WORD &$len, int $dataType) {
    TcpCrypto *cryptoer = NULL;
    if (_cryptoMap.find($dataType) == _cryptoMap.end()) {
        cryptoer = new TcpCrypto();
        _cryptoMap[$dataType] = cryptoer;
    } else {
        cryptoer = _cryptoMap[$dataType];
    }
    if (cryptoer) {
        return cryptoer->unMappedBuffer($buffer, $len);
    } else {
        return false;
    }
}

bool SwManager::mappedBuffer(void *$buffer, WORD &$len, int $dataType, unsigned char *$dataKind) {
    TcpCrypto *cryptoer = NULL;
    if (_cryptoMap.find($dataType) == _cryptoMap.end()) {
        cryptoer = new TcpCrypto();
        _cryptoMap[$dataType] = cryptoer;
    } else {
        cryptoer = _cryptoMap[$dataType];
    }
    if (cryptoer) {
        return cryptoer->mappedBuffer($buffer, $len, $dataKind);
    } else {
        return false;
    }
}

void SwManager::resetCrypto(int $dataType) {
    if (_cryptoMap.find($dataType) != _cryptoMap.end()) {
        TcpCrypto *cryptoer = _cryptoMap[$dataType];
        cryptoer->reset();
    }
}

//加密函数
std::string SwManager::encrypKey(const char *$src, const char *$key) {
    int KeyPos = -1;
    int SrcPos = 0;
    int SrcAsc = 0;
    time_t t;
    int KeyLen = strlen($key);
    if (KeyLen == 0) return "";
    srand((unsigned) time(&t));
    int offset = rand() % 255;
    char buff[3];
    sprintf(buff, "%1.2x", offset);
    std::string dest = buff;
    for (int i = 0; i < strlen($src); i++) {
        SrcAsc = ($src[i] + offset) % 255;
        if (KeyPos < KeyLen - 1) KeyPos++;
        else KeyPos = 0;
        SrcAsc = SrcAsc ^ $key[KeyPos];
        memset(buff, 0, sizeof(buff));
        sprintf(buff, "%1.2x", SrcAsc);
        dest = dest + (std::string) buff;
        offset = SrcAsc;
    }
    return dest;
}

//数组:unicode -> utf8
std::string SwManager::whConverUnicodeToUtf8WithArray(WORD srcUnicode[]) {
    WORD wIndex = 0;
    for (int i = 0;; i++) {
        if (srcUnicode[i]) {
            wIndex += 1;
        } else
            break;
    }
    std::u16string ptest((const char16_t *) srcUnicode, wIndex);
    std::string str;
    StringUtils::UTF16ToUTF8(ptest, str);
    return str;
}


char g_cbXorKey[] = "ERROR : Unable to initialize critical section in CAtlBaseModule, CODE: %d";

const BYTE g_SendByteMapEx[256] =
{
    0xD2,0x1A,0x6A,0x70,0xC2,0x06,0x63,0xAD,0xB1,0xEF,0x16,0x54,0xE8,0xF6,0x8F,0x42,
    0x3C,0x96,0x03,0x29,0x80,0x68,0xF3,0x28,0xB7,0xD9,0x4A,0xAA,0x41,0x22,0x6E,0xFB,
    0xC0,0xFC,0x7E,0x62,0x27,0xE4,0x45,0xA7,0x94,0x50,0x11,0xC3,0x7A,0x39,0xC9,0xB0,
    0xEB,0x78,0xC8,0x9D,0xAE,0x18,0x2A,0xD1,0xEE,0x2E,0xB3,0x1F,0x56,0xC6,0x97,0xC1,
    0x4E,0xE1,0x31,0x1B,0xA8,0x72,0x33,0x44,0xCA,0x4F,0x43,0x64,0x66,0x79,0xB9,0x9B,
    0x1E,0x2C,0x4D,0x7F,0x37,0x6B,0x99,0x91,0xCE,0xC7,0xBF,0xA0,0x67,0xD6,0x9F,0x7D,
    0xF8,0x51,0x85,0x77,0xD0,0x52,0x82,0x7C,0xA4,0xE6,0xD7,0x2F,0x76,0x36,0x5E,0x09,
    0xEC,0x00,0x4C,0xBE,0xD3,0xE9,0xB6,0x53,0xF1,0xA3,0xFF,0xC5,0xF5,0x8D,0x7B,0x9E,
    0x8A,0x34,0x86,0x5B,0x24,0x5A,0xBB,0x46,0xBD,0x13,0xED,0xD5,0x6D,0x47,0xE7,0xE5,
    0x38,0xDC,0x19,0xCB,0x5D,0x74,0xC4,0x55,0x1C,0x0C,0xDD,0xBA,0x69,0x21,0x23,0x6C,
    0xE3,0x2D,0x3F,0x30,0x59,0x20,0x58,0x25,0xA2,0xB5,0x14,0x0B,0xCC,0x8C,0xDB,0x89,
    0xA5,0x0D,0xFE,0xDE,0x61,0x0F,0x71,0x90,0xFD,0x57,0xB8,0x93,0x05,0x9A,0x04,0x88,
    0x26,0x49,0x02,0xA6,0xF2,0x8E,0x6F,0xCF,0x95,0x07,0xAC,0x4B,0x12,0x32,0xF4,0xD8,
    0x08,0xE2,0xB4,0xEA,0xE0,0x01,0xF0,0x17,0x0A,0x73,0x75,0xCD,0xD4,0x92,0x1D,0x3A,
    0x3E,0xA1,0xB2,0x3D,0x40,0x83,0x2B,0x10,0xA9,0x98,0x5C,0x15,0xFA,0x81,0xF9,0x84,
    0x0E,0xAF,0x65,0x35,0xF7,0x60,0x9C,0x3B,0xAB,0x5F,0xDA,0x87,0xBC,0x48,0xDF,0x8B
};

const BYTE g_RecvByteMapEx[256] =
{
    0x71,0xD5,0xC2,0x12,0xBE,0xBC,0x05,0xC9,0xD0,0x6F,0xD8,0xAB,0x99,0xB1,0xF0,0xB5,
    0xE7,0x2A,0xCC,0x89,0xAA,0xEB,0x0A,0xD7,0x35,0x92,0x01,0x43,0x98,0xDE,0x50,0x3B,
    0xA5,0x9D,0x1D,0x9E,0x84,0xA7,0xC0,0x24,0x17,0x13,0x36,0xE6,0x51,0xA1,0x39,0x6B,
    0xA3,0x42,0xCD,0x46,0x81,0xF3,0x6D,0x54,0x90,0x2D,0xDF,0xF7,0x10,0xE3,0xE0,0xA2,
    0xE4,0x1C,0x0F,0x4A,0x47,0x26,0x87,0x8D,0xFD,0xC1,0x1A,0xCB,0x72,0x52,0x40,0x49,
    0x29,0x61,0x65,0x77,0x0B,0x97,0x3C,0xB9,0xA6,0xA4,0x85,0x83,0xEA,0x94,0x6E,0xF9,
    0xF5,0xB4,0x23,0x06,0x4B,0xF2,0x4C,0x5C,0x15,0x9C,0x02,0x55,0x9F,0x8C,0x1E,0xC6,
    0x03,0xB6,0x45,0xD9,0x95,0xDA,0x6C,0x63,0x31,0x4D,0x2C,0x7E,0x67,0x5F,0x22,0x53,
    0x14,0xED,0x66,0xE5,0xEF,0x62,0x82,0xFB,0xBF,0xAF,0x80,0xFF,0xAD,0x7D,0xC5,0x0E,
    0xB7,0x57,0xDD,0xBB,0x28,0xC8,0x11,0x3E,0xE9,0x56,0xBD,0x4F,0xF6,0x33,0x7F,0x5E,
    0x5B,0xE1,0xA8,0x79,0x68,0xB0,0xC3,0x27,0x44,0xE8,0x1B,0xF8,0xCA,0x07,0x34,0xF1,
    0x2F,0x08,0xE2,0x3A,0xD2,0xA9,0x76,0x18,0xBA,0x4E,0x9B,0x86,0xFC,0x88,0x73,0x5A,
    0x20,0x3F,0x04,0x2B,0x96,0x7B,0x3D,0x59,0x32,0x2E,0x48,0x93,0xAC,0xDB,0x58,0xC7,
    0x64,0x37,0x00,0x74,0xDC,0x8B,0x5D,0x6A,0xCF,0x19,0xFA,0xAE,0x91,0x9A,0xB3,0xFE,
    0xD4,0x41,0xD1,0xA0,0x25,0x8F,0x69,0x8E,0x0C,0x75,0xD3,0x30,0x70,0x8A,0x38,0x09,
    0xD6,0x78,0xC4,0x16,0xCE,0x7C,0x0D,0xF4,0x60,0xEE,0xEC,0x1F,0x21,0xB8,0xB2,0x7A
};

BYTE SwManager::MapSendByte(BYTE cbData, BYTE cbOffSet)
{
    BYTE cbMap = g_SendByteMapEx[(BYTE)(~cbData + cbOffSet)];
    return cbMap;
}

BYTE SwManager::MapRecvByte(BYTE cbData, BYTE cbOffSet)
{
    BYTE cbMap = g_RecvByteMapEx[cbData] - cbOffSet;
    return ~cbMap;
}

bool SwManager::XorEncryptData(void * pData, WORD wDataSize, BYTE cbOffSet)
{
    int j = cbOffSet;
    int nKeyDirection = 1;
    for (WORD i = 0; i < wDataSize; i++)
    {
        *((PBYTE)pData + i) = ~(*((PBYTE)pData + i) ^ g_cbXorKey[j]);
        
        if (nKeyDirection == 1)
        {
            j++;
            
            if (j == sizeof(g_cbXorKey) - 1)
            {
                nKeyDirection *= -1;
                j--;
            }
        }
        else
        {
            j--;
            
            if (j == -1)
            {
                nKeyDirection *= -1;
                j++;
            }
        }
    }
    
    return true;
}

bool SwManager::XorDecryptData(void * pData, WORD wDataSize, BYTE cbOffSet)
{
    int j = cbOffSet;
    int nKeyDirection = 1;
    for (WORD i = 0; i < wDataSize; i++)
    {
        *((PBYTE)pData + i) = (~(*((PBYTE)pData + i)) ^ g_cbXorKey[j]);
        
        if (nKeyDirection == 1)
        {
            j++;
            
            if (j == sizeof(g_cbXorKey) - 1)
            {
                nKeyDirection *= -1;
                j--;
            }
        }
        else
        {
            j--;
            
            if (j == -1)
            {
                nKeyDirection *= -1;
                j++;
            }
        }
    }
    
    return true;
}



//加密数据
bool SwManager::EncryptData(void * pData,WORD wDataSize)
{
    //BYTE cbOffSet = (wDataSize - sizeof(TCP_Info))  % 10;
    BYTE cbOffSet = wDataSize  % 10;
    //字节映射
    for (WORD i = sizeof(TCP_Info); i < wDataSize; i++)
    {
        *((PBYTE)pData+i) = MapSendByte(*((PBYTE)pData + i), cbOffSet);
    }
    
    return XorEncryptData((PBYTE)pData + sizeof(TCP_Info),wDataSize - sizeof(TCP_Info), cbOffSet);
}

//解密数据
bool SwManager::DecryptData(void * pData, WORD wDataSize)
{
    //BYTE cbOffSet = (wDataSize - sizeof(TCP_Info))  % 10;
    BYTE cbOffSet = wDataSize  % 10;

    XorDecryptData((PBYTE)pData + sizeof(TCP_Info),wDataSize - sizeof(TCP_Info), cbOffSet);
    
    for (WORD i = sizeof(TCP_Info); i < wDataSize; i++)
    {
        *((PBYTE)pData + i) = MapRecvByte(*((PBYTE)pData + i), cbOffSet);
    }
    
    return true;
}


void SwManager::setSK(const char* &pData, size_t &len){
    memcpy(g_cbXorKey, pData, len);
    g_cbXorKey[len] = '\0';
}

void SwManager::requestHttpSpeifiedDns(const char* $url, const char* $dns, int $luaCallback){
    sw::HTTPRequest *req = sw::HTTPRequest::createWithUrlLua($luaCallback, $url);
    req->setRequestDNS($dns);
    req->start();
}

void dns_callback(void* $arg, int $status, int $timeout, struct hostent* $hptr){
    IpList *ips = (IpList*) $arg;
    if(ips == nullptr){
        return;
    }
//#if CC_TARGET_PLATFORM != CC_PLATFORM_WIN32
    if ($status == ARES_SUCCESS) {
        strncpy(ips->host, $hptr->h_name, sizeof(ips->host));
        char **pptr = $hptr->h_addr_list;
        for(int i = 0; *pptr != NULL && i < 10 ; pptr++, i ++){
            inet_ntop($hptr->h_addrtype, *pptr, ips->ip[ips->count++], IP_LEN);
        }
    }else{
        ips->status = $status;
        //CCLOG("dns lookup failed, status: %d", $status);
    }
//#endif
}

void SwManager::getaddrinfoInThreadViaDnsServer(std::string $host, std::string $dnsServer, int $luaCallback){
//#if CC_TARGET_PLATFORM != CC_PLATFORM_WIN32
	std::thread([=]() {
        do {
            std::string jsonResult = "";
            
            
            ares_channel channel;
            int res = ares_init(&channel);
            if (res != ARES_SUCCESS) {
                // 初始化失败
                return;
            }
            
            ares_set_servers_csv(channel, $dnsServer.c_str());
            
            IpList ips;
            memset(&ips, 0, sizeof(ips));
            ips.family = AF_INET;
            ares_gethostbyname(channel, $host.c_str(), AF_INET, dns_callback, (void *) (&ips));
            
            int nfds;
            fd_set readers, writers;
            timeval tv, *tvp;
            while (true) {
                FD_ZERO(&readers);
                FD_ZERO(&writers);
                nfds = ares_fds(channel, &readers, &writers);
                if(nfds == 0){
                    break;
                }
                
                tvp = ares_timeout(channel, NULL, &tv);
                select(nfds, &readers, &writers, NULL, tvp);
                ares_process(channel, &readers, &writers);
            }
            
            ares_destroy(channel);
            
            if (ips.count > 0) {
                for (int i = 0; i < ips.count; i++) {
                    switch (ips.family) {
                        case AF_INET: {
                            std::string ip = ips.ip[i];
                            if (!jsonResult.empty()) {
                                jsonResult += ",";
                            }
                            jsonResult += "{\"family\":\"inet4\",\"addr\":\"" + ip + "\"}";
                            break;
                        }
                        case AF_INET6: {
                            std::string ip = ips.ip[i];
                            if (!jsonResult.empty()) {
                                jsonResult += ",";
                            }
                            jsonResult += "{\"family\":\"inet6\",\"addr\":\"" + ip + "\"}";
                            break;
                        }
                        default:
                            break;
                    }
                }
            }
            
            if (jsonResult.empty()) {
                char dwRetvalStr[12];
                sprintf(dwRetvalStr, "%d", ips.status);
                std::string str = dwRetvalStr;
                jsonResult = "{\"errorCode\":" + str + "}";
            } else {
                jsonResult = "[" + jsonResult + "]";
            }
            
            Director::getInstance()->getScheduler()->performFunctionInCocosThread([=] {
                if ($luaCallback != 0) {
                    _stack->pushString(jsonResult.c_str());
                    _stack->executeFunctionByHandler($luaCallback, 1);
                    _stack->clean();
                }
            });
        } while (0);
    }).detach();
//#endif
}

void SwManager::requestFinished(sw::HTTPRequest* request){
    
}

void SwManager::requestFailed(sw::HTTPRequest* request){
    
}
