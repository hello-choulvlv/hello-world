//
// Created by mbp on 2017/4/14.
// Copyright (c) 2017 shunwo. All rights reserved.
//

#ifndef LIBSHUNWOCOMMON_CRYPTOSWMANAGER_H
#define LIBSHUNWOCOMMON_CRYPTOSWMANAGER_H

#include "cocos2d.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "scripting/lua-bindings/manual/swgadget/assset/TcpCrypto.h"
#include "network/SWHTTPRequestDelegate.h"

class SwManager : public sw::HTTPRequestDelegate {
public:
    static SwManager *getInstance();
    
    ~SwManager();
    
    void deploy();
    
    /**
     * 注意这个函数中$len cpp代码不是引用类型，但是我感觉应该是引用类型
     * 目前还没有测出有什么问题，因为改变长度的情况还没有执行
     **/
    bool unMappedBuffer(void *$buffer, WORD &$len, int $dataType);
    
    bool mappedBuffer(void *$buffer, WORD &$len, int $dataType, unsigned char *$dataKind);
    
    std::string encrypKey(const char *$src, const char *$key);
    
    void resetCrypto(int $dataType);
    
    void uncompressFile(std::string $zipFile, std::string $outputUrl, int $luaSuccessCallback, int $luaErrorCallback);
    
    std::string whConverUnicodeToUtf8WithArray(WORD *srcUnicode);
    
    /**
     * 通过dns多线程解析域名为ip（包括ipv4和ipv6）
     * */
    void getaddrinfo(std::string $host, int $luaCallback);
    
    bool EncryptData(void * pData,WORD wDataSize);
    
    bool DecryptData(void * pData, WORD wDataSize);
    
    void setSK(const char* &pData, size_t &len);
    
    void requestHttpSpeifiedDns(const char* $url, const char* $dns, int $luaCallback);
    
    void requestFinished(sw::HTTPRequest* request);
    void requestFailed(sw::HTTPRequest* request);
    
    /**
     * 通过指定dns服务器，多线程解析域名为ip（包括ipv4和ipv6）
     * */
    void getaddrinfoInThreadViaDnsServer(std::string $host, std::string $dnsServer, int $luaCallback);
    
private:
    SwManager();
    
    int doUncompress(std::string $zipFile, std::string $outputUrl);
    
    bool XorDecryptData(void * pData, WORD wDataSize, BYTE cbOffSet);
    
    bool XorEncryptData(void * pData, WORD wDataSize, BYTE cbOffSet);
    
    BYTE MapSendByte(BYTE cbData, BYTE cbOffSet);
    
    BYTE MapRecvByte(BYTE cbData, BYTE cbOffSet);
    
    /* TcpCrypto *_cryptoLoad;
     TcpCrypto *_cryptoRoom;*/
    std::map<int, TcpCrypto *> _cryptoMap;
    cocos2d::LuaStack *_stack;
    static SwManager *_instance;
    
};


#endif //LIBSHUNWOCOMMON_CRYPTOSWMANAGER_H

