
#include "FishLayer.h"
#include "FishObjectManager.h"
#include "cocostudio/CCArmature.h"
#include "cocostudio/CCArmatureDataManager.h"
#include "spine/spine.h"
#include "spine/SkeletonAnimation.h"
#include "Fish.h"
#include "Bullet.h"

//const int s_object_status_unknown = 0;
//const int s_object_status_alloc = 1;
//const int s_object_status_inuse = 2;

//j记录对象的当前状况
#define object_cache_status_unkown 0  //未知状态
#define object_cache_status_alloc  0x7c  //处于队列中,可以随时使用
#define object_cache_status_inuse  0x80  //对象处于使用中
#define object_cache_mac_count     75 //最大对象缓存数目

namespace fishgame{
    
NvCacheUnit::NvCacheUnit(link_list_alloc<link_list<cocos2d::Node*>::link_node,cocos2d::Node*> *alloc_ptr):
alloc_count(0)
,node_list(0,alloc_ptr){
//,owner_map_ptr(nullptr)
//,internal_ptr(nullptr){
}

NvCacheUnit::NvCacheUnit(const NvCacheUnit &other){
    this->alloc_count = other.alloc_count;
    this->node_list = other.node_list;
}

FishLayer::FishLayer() :cocos2d::Layer()
,_compare_func([](const std::string &a,const std::string &b)->int{return strcmp(a.c_str(),b.c_str());})
,m_pLayerBullet(nullptr)
,m_pLayerBulletDie(nullptr)
,m_pLayerFish(nullptr)
,m_pManager(nullptr)
#if __debug_fishgame_collision_func
,_drawNodeDebug(nullptr)
#endif
{
    //m_pLayerBullet      = nullptr;
    //m_pLayerBulletDie   = nullptr;
    //m_pLayerFish        = nullptr;
}

FishLayer::~FishLayer()
{
    //遍历d所有的节点,对其中的Node对象进行释放
    for(auto *cache_it = _objectCache.find_minimum();cache_it != nullptr;cache_it = _objectCache.find_next(cache_it)){
        for(auto *link_it = cache_it->tv_value.node_list.head();link_it != nullptr;link_it = cache_it->tv_value.node_list   .next(link_it)){
            link_it->tv_value->release();
            link_it->tv_value = nullptr;
        }
    }
    //遍历鱼+子弹对象的容器Layer
    auto &fish_vec = m_pLayerFish->getChildren();
    for(auto it = fish_vec.begin();it != fish_vec.end();++it){
        cocos2d::Node *object = *it;
        if(object->getTag() == object_cache_status_inuse){
            object->setTag(0);
            object->release();
        }
    }
    //bullet
    auto &bullet_vec = m_pLayerBullet->getChildren();
    for(auto it = bullet_vec.begin();it != bullet_vec.end();++it){
        cocos2d::Node *object = *it;
        if(object->getTag() == object_cache_status_inuse){
            object->setTag(0);
            object->release();
        }
    }
    //bullet die
    auto &bullet_die_vec = m_pLayerBulletDie->getChildren();
    for(auto it = bullet_die_vec.begin();it != bullet_die_vec.end();++it){
        cocos2d::Node *object = *it;
        if(object->getTag() == object_cache_status_inuse){
            object->setTag(0);
            object->release();
        }
    }

}

bool FishLayer::init()
{
    cocos2d::Layer::init();
    //fish layer
    m_pLayerFish = cocos2d::Layer::create();
    m_pLayerFish->setName("m_pLayerFish");
    addChild(m_pLayerFish,1);
    //bullet layer
    m_pLayerBullet = cocos2d::Layer::create();
    m_pLayerBullet->setName("m_pLayerBullet");
    addChild(m_pLayerBullet, 7);
    //bullet die layer
    m_pLayerBulletDie = cocos2d::Layer::create();
    m_pLayerBulletDie->setName("m_pLayerBulletDie");
    addChild(m_pLayerBulletDie, 8);
    
#if __debug_fishgame_collision_func
    _drawNodeDebug = cocos2d::DrawNode::create();
    m_pLayerFish->addChild(_drawNodeDebug,1000);
#endif
    //
    return true;
}
    
    bool FishLayer::AddFish(Fish* pFish, std::list<VisualNode>* result) {
        
        VisualData* pVisualData = nullptr;
        bool bDead;
        switch (pFish->GetState())
        {
                
            case EOS_LIVE:
            case EOS_HIT:
                bDead = false;
                pVisualData = pFish->GetVisualData();
                break;
            case EOS_DEAD:
                bDead = true;
                pVisualData = pFish->GetVisualData();
                break;
            default:
                break;
        }
        if (pVisualData != nullptr){
            
            auto& images = bDead ? pVisualData->ImageInfoDie : pVisualData->ImageInfoLive;
            
            for (auto& image: images)
            {
                VisualNode visualNode;
                visualNode.target = nullptr;
                visualNode.scale = image.Scale;
                visualNode.direction = image.Direction;
                visualNode.offsetX = image.OffestX;
                visualNode.offsetY = image.OffestY;
                
                switch (image.AniType)
                {
                    case VAT_FRAME:
                    {
                        cocostudio::ArmatureDataManager::getInstance()->addArmatureFileInfo(image.ResPath + ".ExportJson");
                        //cocostudio::Armature* pArmature = cocostudio::Armature::create(image.Image);
                        cocostudio::Armature* pArmature = (cocostudio::Armature*)this->getOrCreateObject(image.Image, VAT_FRAME);
                        if (pArmature != nullptr)
                        {
                            if (pArmature->getAnimation() != nullptr)
                            {
                                pArmature->getAnimation()->play(image.Name, -1, bDead ? 0 : -1);
                                if (bDead)
                                {
                                    pArmature->getAnimation()->setMovementEventCallFunc([=](cocostudio::Armature* sender, cocostudio::MovementEventType type, const std::string& id)
                                                                                        {
                                                                                            if (type == cocostudio::MovementEventType::COMPLETE)
                                                                                            {
                                                                                                sender->getAnimation()->stop();
                                                                                                sender->setVisible(false);
                                                                                            }
                                                                                        });
                                }
                            }
                            
                            pArmature->setAnchorPoint(cocos2d::Vec2::ANCHOR_MIDDLE);
                            pArmature->setScale(image.Scale);
                            pArmature->setPosition(image.OffestX,image.OffestY);
                            m_pLayerFish->addChild(pArmature, image.nZOrder);
                            
                            visualNode.target = pArmature;
                            
                            if( pFish->GetSpecialShow() )
                            {
                                visualNode.bSpecialShow = true;
                                pArmature->setColor( pFish->GetSpecialFishColor() );
                            }
                            else
                            {
                                pArmature->setColor( pFish->GetNormalFishColor() );
                            }
                            
                            result->push_back(visualNode);
                            
                        }
                        break;
                    }
                    case VAT_SKELETON:
                    {
                        spine::SkeletonAnimation * pSkeleton = (spine::SkeletonAnimation *)this->getOrCreateObject(image.ResPath, VAT_SKELETON);
                        if (pSkeleton != nullptr)
                        {
                            if( true == bDead )
                            {
                                pSkeleton->setAnimation(0, image.Name, false );
                            }
                            else
                            {
                                pSkeleton->setAnimation(0, image.Name, true);
                            }
                            
                            pSkeleton->setScale(image.Scale);
                            pSkeleton->setAnchorPoint(cocos2d::Vec2::ANCHOR_MIDDLE);
                            pSkeleton->setPosition(image.OffestX,image.OffestY);
                            m_pLayerFish->addChild(pSkeleton,image.nZOrder);
                            
                            visualNode.target = pSkeleton;
                            
                            if(pFish->GetSpecialShow())
                            {
                                visualNode.bSpecialShow = true;
                                pSkeleton->setColor(pFish->GetSpecialFishColor());
                            }
                            else
                            {
                                pSkeleton->setColor(pFish->GetNormalFishColor());
                            }
                            
                            result->push_back(visualNode);
                        }
                        break;
                    }
                    case VAT_SKELETON_BINARY:
                    {
                        spine::SkeletonAnimation * pSkeleton = (spine::SkeletonAnimation *)this->getOrCreateObject(image.ResPath, VAT_SKELETON_BINARY);
                        if (pSkeleton != nullptr)
                        {
                            if( true == bDead )
                            {
                                pSkeleton->setAnimation(0, image.Name, false );
                            }
                            else
                            {
                                pSkeleton->setAnimation(0, image.Name, true);
                            }
                            pSkeleton->setScale(image.Scale);
                            pSkeleton->setAnchorPoint(cocos2d::Vec2::ANCHOR_MIDDLE);
                            pSkeleton->setPosition( image.OffestX, image.OffestY );
                            m_pLayerFish->addChild(pSkeleton, image.nZOrder);
                            
                            if( pFish->GetSpecialShow() )
                            {
                                visualNode.bSpecialShow = true;
                                pSkeleton->setColor(pFish->GetSpecialFishColor());
                            }
                            else
                            {
                                pSkeleton->setColor(pFish->GetNormalFishColor());
                            }
                            
                            result->push_back(visualNode);
                        }
                        break;
                    }
                    case VAT_PARTICLE:
                    {
                        //cocos2d::ParticleSystemQuad *system = cocos2d::ParticleSystemQuad::create(image.ResPath + ".plist");//new cocos2d::ParticleSystemQuad();
                        //system->initWithFile(image.ResPath + ".plist");//plist文件可以通过例子编辑器获得
                        
                        cocos2d::ParticleSystemQuad *system = (cocos2d::ParticleSystemQuad *)this->getOrCreateObject(image.ResPath, VAT_PARTICLE);
                        system->setBlendAdditive(true);//这个调用必不可少
                        system->setScale(image.Scale);
                        m_pLayerFish->addChild(system, image.nZOrder);
                        
                        visualNode.target = system;
                        
                        result->push_back(visualNode);
                        break;
                    }
                }
            }
        }
        return result;
    }
    
    bool FishLayer::AddBullet(Bullet* pBullet, std::list<VisualNode>* result){
        
        bool bDead;
        VisualData* cannon = nullptr;
        switch (pBullet->GetState())
        {
                
            case EOS_LIVE:
            case EOS_HIT:
                bDead = false;
                cannon = pBullet->GetVisualData();
                break;
            case EOS_DEAD:
                bDead = true;
                cannon = pBullet->GetVisualData();
                break;
            default:
                break;
        }
        if (cannon != nullptr)
        {
            auto& images = bDead ? cannon->ImageInfoDie : cannon->ImageInfoLive;
            for (auto& image: images)
            {
                switch (image.AniType)
                {
                    case VAT_FRAME:
                    {
                        VisualNode visualNode;
                        cocostudio::ArmatureDataManager::getInstance()->addArmatureFileInfo(image.ResPath + ".ExportJson");
                        //cocostudio::Armature* hehe = cocostudio::Armature::create(image.Image);
                        cocostudio::Armature* hehe = (cocostudio::Armature*)this->getOrCreateObject(image.Image, VAT_FRAME);
                        if (bDead)
                        {
                            hehe->getAnimation()->play(image.Name,-1,0);
                            m_pLayerBulletDie->addChild(hehe, image.nZOrder);//, cannon->nID);
                            
                        }
                        else
                        {
                            hehe->getAnimation()->play(image.Name,-1,-1);
                            m_pLayerBullet->addChild(hehe, image.nZOrder);//, cannon->nID);
                        }
                        hehe->getAnimation()->setMovementEventCallFunc([=](cocostudio::Armature* sender, cocostudio::MovementEventType type, const std::string& id)
                                                                       {
                                                                           if (type == cocostudio::MovementEventType::COMPLETE)
                                                                           {
                                                                               sender->getAnimation()->stop();
                                                                               sender->setVisible(false);
                                                                           }
                                                                       });
                        
                        /*
                         * Modified : 设置子弹缩放大小
                         * Data     : 2017-09-18 15:09:00
                         * Author   : 66
                         */
                        /*
                         if( nullptr != hehe )
                         {
                         hehe->setScale( image.Scale );
                         }
                         */
                        
                        visualNode.direction    = image.Direction;
                        visualNode.offsetX      = image.OffestX;
                        visualNode.offsetY      = image.OffestY;
                        visualNode.scale        = image.Scale;
                        visualNode.target       = hehe;
                        result->push_back(visualNode);
                        break;
                    }
                    case VAT_SKELETON:
                    {
                        spine::SkeletonAnimation * pSkeleton = (spine::SkeletonAnimation *)this->getOrCreateObject(image.ResPath, VAT_SKELETON);
                        if (pSkeleton != nullptr)
                        {
                            pSkeleton->setScale(image.Scale);
                            pSkeleton->setAnchorPoint(cocos2d::Vec2::ANCHOR_MIDDLE);
                            if (bDead)
                            {
                                pSkeleton->setToSetupPose();
                                pSkeleton->setAnimation(0, image.Name, false);
                                m_pLayerBulletDie->addChild(pSkeleton, image.nZOrder);//, cannon->nID);
                            }
                            else
                            {
                                pSkeleton->setToSetupPose();
                                pSkeleton->setAnimation(0, image.Name, true);
                                m_pLayerBullet->addChild(pSkeleton, image.nZOrder);//, cannon->nID);
                            }
                            
                            VisualNode visualNode;
                            visualNode.direction = image.Direction;
                            visualNode.offsetX = image.OffestX;
                            visualNode.offsetY = image.OffestY;
                            visualNode.scale = image.Scale;
                            visualNode.target = pSkeleton;
                            
                            result->push_back(visualNode);
                        }
                        break;
                    }
                    case VAT_SKELETON_BINARY:
                    {
//                        spine::SkeletonAnimation * pSkeleton = nullptr;
//                        if( true == FishObjectManager::GetInstance()->GetIsUpdateCacheForBullet() )
//                        {
//                            if( false == spine::SkeletonAnimation::isExistSkeletonDataInCache(image.Image + image.Name) )
//                            {
//                                spine::SkeletonAnimation::readSkeletonDataToCacheByBinary(image.Image + image.Name, image.ResPath + ".skel", image.ResPath + ".atlas", 1);
//                            }
//                            pSkeleton = spine::SkeletonAnimation::createFromCache(image.Image + image.Name);
//                        }
//                        else
//                        {
//                            pSkeleton = spine::SkeletonAnimation::createWithBinaryFile(image.ResPath + ".skel", image.ResPath + ".atlas", 1);
//                        }
                        
                        spine::SkeletonAnimation *pSkeleton = (spine::SkeletonAnimation *)this->getOrCreateObject(image.ResPath, VAT_SKELETON_BINARY);
                        if (pSkeleton != nullptr)
                        {
                            pSkeleton->setScale(image.Scale);
                            pSkeleton->setAnchorPoint(cocos2d::Vec2::ANCHOR_MIDDLE);
                            if (bDead)
                            {
                                pSkeleton->setToSetupPose();
                                pSkeleton->setAnimation(0, image.Name, false);
                                m_pLayerBulletDie->addChild(pSkeleton, image.nZOrder);//, cannon->nID);
                            }
                            else
                            {
                                pSkeleton->setToSetupPose();
                                pSkeleton->setAnimation(0, image.Name, true);
                                m_pLayerBullet->addChild(pSkeleton, image.nZOrder);//, cannon->nID);
                            }
                            
                            VisualNode visualNode;
                            visualNode.direction = image.Direction;
                            visualNode.offsetX = image.OffestX;
                            visualNode.offsetY = image.OffestY;
                            visualNode.scale = image.Scale;
                            visualNode.target = pSkeleton;
                            
                            result->push_back(visualNode);
                        }
                        break;
                    }
                    case VAT_PARTICLE:
                    {
                        //cocos2d::ParticleSystemQuad *system = cocos2d::ParticleSystemQuad::create(image.ResPath + ".plist");
                        //system->initWithFile(image.ResPath + ".plist");//plist文件可以通过例子编辑器获得
                        
                        cocos2d::ParticleSystemQuad *system = (cocos2d::ParticleSystemQuad *)this->getOrCreateObject(image.ResPath, VAT_PARTICLE);
                        system->setBlendAdditive(true);//这个调用必不可少
                        system->setScale(image.Scale);
                        if (bDead)
                        {
                            m_pLayerBulletDie->addChild(system, image.nZOrder);//, cannon->nID);
                        }
                        else
                        {
                            m_pLayerBullet->addChild(system, image.nZOrder);//, cannon->nID);
                        }
                        
                        VisualNode visualNode;
                        visualNode.direction = image.Direction;
                        visualNode.offsetX = image.OffestX;
                        visualNode.offsetY = image.OffestY;
                        visualNode.scale = image.Scale;
                        visualNode.target = system;
                        
                        result->push_back(visualNode);
                        break;
                    }
                }
            }
            
        }
        
        return result;
    }
    
    bool FishLayer::AddMyObject(MyObject* pObj, std::list<VisualNode>* result){
        if (pObj == NULL) return false;
        
        int objType = pObj->GetType();
        switch (objType)
        {
            case EOT_FISH:{
                return AddFish((Fish*)pObj, result);
            }
            case EOT_BULLET:{
                return AddBullet((Bullet*)pObj, result);
            }
            default:
                break;
        }
        
        return true;
    }

cocos2d::Node* FishLayer::getOrCreateObject(const std::string &prefix_key, VisualAniType object_type){
    cocos2d::Node *object_ptr = nullptr;
    //查找是否已经有可用的缓存对象
    red_black_tree<std::string, NvCacheUnit>::internal_node *cache_ptr = _objectCache.lookup(prefix_key, _compare_func);
    if(cache_ptr != nullptr){
        //此时需要查找是否有可用的对象
        if(cache_ptr->tv_value.node_list.size() > 0){
            auto *unit_ptr = cache_ptr->tv_value.node_list.head();
            cache_ptr->tv_value.node_list.pop_front();
            
            object_ptr = unit_ptr->tv_value;
            CCASSERT(object_ptr->getTag() == object_cache_status_alloc, "object in queue should be in a status alloc");
            object_ptr->setTag(object_cache_status_inuse);
            object_ptr->setUserData(cache_ptr);
            object_ptr->setRotation(0.0f);
            object_ptr->setScale(1.0f);
            object_ptr->setPosition(0.0f,0.0f);
            ++cache_ptr->tv_value.alloc_count;
            
            return object_ptr;
        }
    }
    else{
        //NvCacheUnit cache_unit(&_object_alloc);
        cache_ptr = _objectCache.insert(prefix_key, NvCacheUnit(&_object_alloc), _compare_func);
    }
    //否则,在下面的公共代码中,需要创建相关的对象
    bool b2_other = m_pManager?m_pManager->GetIsUpdateCacheForFish():false;
    if(object_type == VAT_FRAME)
        object_ptr = cocostudio::Armature::create(prefix_key);
    else if(object_type == VAT_SKELETON){
        if(b2_other){
            if(!spine::SkeletonAnimation::isExistSkeletonDataInCache(prefix_key))
                spine::SkeletonAnimation::readSkeletonDataToCacheByJson(prefix_key, prefix_key + ".json", prefix_key + ".atlas",1.0f);//
            object_ptr = spine::SkeletonAnimation::createFromCache(prefix_key);
        }
        else
            object_ptr = spine::SkeletonAnimation::createWithJsonFile(prefix_key + ".json", prefix_key + ".atlas", 1.0f);
    }
    else if(object_type == VAT_SKELETON_BINARY){
        if(b2_other)
        {
            if(!spine::SkeletonAnimation::isExistSkeletonDataInCache(prefix_key))
                spine::SkeletonAnimation::readSkeletonDataToCacheByBinary(prefix_key, prefix_key + ".skel", prefix_key + ".atlas", 1.0f);
            object_ptr = spine::SkeletonAnimation::createFromCache(prefix_key);
        }
        else
            object_ptr = spine::SkeletonAnimation::createWithBinaryFile(prefix_key + ".skel", prefix_key + ".atlas", 1.0f);
    }
    else if(object_type == VAT_PARTICLE)
        object_ptr = cocos2d::ParticleSystemQuad::create(prefix_key + ".plist");
    
    if(object_ptr != nullptr){
        object_ptr->retain();
        object_ptr->setTag(object_cache_status_inuse);
        object_ptr->setUserData(cache_ptr);
        ++cache_ptr->tv_value.alloc_count;
    }
    
    return object_ptr;
}

void FishLayer::recycleObject(cocos2d::Node *object_ptr){
    int tag = object_ptr->getTag();
    
    red_black_tree<std::string, NvCacheUnit>::internal_node *cache_ptr = (red_black_tree<std::string, NvCacheUnit>::internal_node *)object_ptr->getUserData();
    CCAssert(tag == object_cache_status_inuse,"object should be inuse.it could be recycle");
    
    object_ptr->removeFromParent();
    if(cache_ptr->tv_value.alloc_count + cache_ptr->tv_value.node_list.size() <= object_cache_mac_count){
        --cache_ptr->tv_value.alloc_count;
        object_ptr->setTag(object_cache_status_alloc);
        cache_ptr->tv_value.node_list.push_back(object_ptr);
    }
    else{
        object_ptr->setUserData(nullptr);
        object_ptr->setTag(0);
        object_ptr->release();
    }
}
//--------------------------------------------------------------
}
