////
#ifndef __MOVE_POINT_H__
#define __MOVE_POINT_H__

//#include "Point.h"
//#include "math/Vec2.h"
#include "math/Vec2.h"
#include <vector>

class CMovePoint
{
public:
	CMovePoint();
	CMovePoint(const cocos2d::Vec2 &pos, float dir);

    ~CMovePoint() = default;

public:
	cocos2d::Vec2 m_Position;
	float m_Direction;
};

typedef std::vector<CMovePoint> MovePoints; 


#endif


