/*
  *Fish对象功能分离
  *从FishObjectManager.h/.cpp文件中
  *新增加功能,创建动画时直接调用自身的函数,而不是借助于其他的类
  *@2018年3月3日
  *@Author:xiaoxiong
 */
#ifndef __FISH_H__
#define __FISH_H__
#include "MyObject.h"
_NS_FISHGAME_BEGIN_
class Fish : public MyObject
{
	friend class FishCacheManager;
protected:
	Fish();
public:
	virtual ~Fish();
	static Fish* Create() {
		Fish * ret = new (std::nothrow) Fish();
		if (ret)
		{
			ret->autorelease();
		}
		else
		{
			CC_SAFE_DELETE(ret);
		}
		return ret;
	}

	CC_SYNTHESIZE(unsigned int, m_nRefershID, RefershID);

	void SetPosition(float x, float y);
	const cocos2d::Vec2& GetPosition() { return m_pPosition; }

	//float GetDirection() { return m_fDirection; }
	//void SetDirection(float dir);
	// 填充数据绘制鱼类所需数据
	void SetParticle(const std::string  &p) { m_Particle = p; }
	std::string GetParticle() { return m_Particle; }

	void   setBoundbox(std::vector<BoundingBox> *boundboxVec) { _boundBoxesVec = boundboxVec; };
	void AddBoundingBox(float offsetX, float offsetY, float rad);
	const std::vector<BoundingBox>&  GetBoundingBox();

	int GetMaxRadio() { return m_fMaxRadio; }

	void SetSpecialFishColor(const cocos2d::Color3B  &c) { m_specialFishColor = c; }
	void SetNormalFishColor(const cocos2d::Color3B &c) { m_normalFishColor = c; }
	void SetHitFishColor(const cocos2d::Color3B &c) { m_hitFishColor = c; }

	const cocos2d::Color3B& GetSpecialFishColor() { return m_specialFishColor; }
	const cocos2d::Color3B& GetNormalFishColor() { return m_normalFishColor; }
	const cocos2d::Color3B& GetHitFishColor() { return m_hitFishColor; }

	void RegisterHitFishHandler(int);


	void SetMoveCompent(MoveCompent* p);
	virtual void OnUpdate(float fdt);
	virtual void OnHit();
private:
	std::string m_Particle;
	std::vector<BoundingBox>     *_boundBoxesVec;
	std::vector<BoundingBox>       bbList;
	int m_nRedTime;
	float m_fMaxRadio;
	int m_nHandlerHitFish;
	// 鱼王颜色
	cocos2d::Color3B m_specialFishColor;
	// 鱼原始颜色
	cocos2d::Color3B m_normalFishColor;
	// 鱼受击颜色
	cocos2d::Color3B m_hitFishColor;
};

_NS_FISHGAME_END_

#endif
