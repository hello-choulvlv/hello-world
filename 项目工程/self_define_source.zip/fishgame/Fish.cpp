/*
  *Fish对象分离/FishObjectManager
  *@2018年3月3日
  *@author:xiaoxiong
 */
#include "Fish.h"
#include "MoveCompent.h"
#include "Buff.h"
#include "FishObjectManager.h"
#include"scripting/lua-bindings/manual/CCLuaEngine.h"
#include "spine/SkeletonAnimation.h"
#include "editor-support/cocostudio/CCArmature.h"
USING_NS_CC;
using namespace cocostudio;

_NS_FISHGAME_BEGIN_

Fish::Fish()
	: MyObject()
	, m_nRedTime(0)
	, m_fMaxRadio(0.0f)
	, _boundBoxesVec(nullptr)
	, m_nHandlerHitFish(0)
	, m_specialFishColor(0xFF, 0, 0)
	, m_normalFishColor(0xFF, 0xFF, 0xFF)
	, m_hitFishColor(0xFF, 128, 128)
{
	m_nType = EOT_FISH;
	bbList.clear();
}

Fish::~Fish()
{
}

///////////////////////////End-New_Fish//////////////////////////////////////////
void Fish::SetPosition(float x, float y) {
	if (m_pPosition.x == x && m_pPosition.y == y) {
		return;
	}
	m_pPosition.x = x;
	m_pPosition.y = y;
	m_bDirtyPos = true;

	if (x < -100 || y < -100 || x >(fWidth + 100) || y >(fHeigth + 100)) {
		if (m_bInScreen) {
			OnMoveEnd();
		}
		m_bInScreen = false;
	}
	else {
		m_bInScreen = true;
	}
}

//void  Fish::SetDirection(float dir) {
//	if (m_fDirection == dir) {
//		return;
//	}
//	m_fDirection = dir;
//	m_bDirtyDir = true;
//}

void Fish::AddBoundingBox(float offsetX, float offsetY, float rad)
{
    BoundingBox bbTemp;
    bbTemp.offsetX = offsetX;
    bbTemp.offsetY = offsetY;
    bbTemp.rad = rad;
    bbList.push_back(bbTemp);
    m_fMaxRadio = fmax(m_fMaxRadio, fabs(offsetX) + rad);
    m_fMaxRadio = fmax(m_fMaxRadio, fabs(offsetY) + rad);
}

const std::vector<BoundingBox>& Fish::GetBoundingBox() {
	return bbList;
}

void Fish::OnUpdate(float fdt) {
	MyObject::OnUpdate(fdt);

	if (m_nRedTime > 0) {
		--m_nRedTime;
		if (m_nRedTime == 0) {
			for (auto& v : m_pVisualNodeList) {
				if (v.target && !v.bSpecialShow)
                    v.target->setColor(m_normalFishColor);
			}
		}
	}
}


void Fish::RegisterHitFishHandler(int handler)
{
#if CC_ENABLE_SCRIPT_BINDING
	m_nHandlerHitFish = handler;
#endif
}

void Fish::OnHit() {
	/*
	for (auto& v: m_pVisualNodeList){
	if (v.target && true != v.bSpecialShow ) v.target->setColor(cocos2d::Color3B(0xFF, 0x11, 0));
	}

	m_nRedTime = 5;
	*/

	if (0 == m_nHandlerHitFish)
	{
		for (auto& v : m_pVisualNodeList) {
			if (v.target && !v.bSpecialShow)
                v.target->setColor(m_hitFishColor);
		}

		m_nRedTime = 5;
		return;
	}
	else
	{
#if CC_ENABLE_SCRIPT_BINDING
		cocos2d::LuaStack *_stack = cocos2d::LuaEngine::getInstance()->getLuaStack();

		_stack->executeFunctionByHandler(m_nHandlerHitFish, 0);
		_stack->clean();
#endif

	}
}

void Fish::SetMoveCompent(MoveCompent* p) {
	if (p == NULL) { return; }
	if (m_pMoveCompent != nullptr) {
		m_pMoveCompent->OnDetach();
		m_pMoveCompent->release();
	}

	m_pMoveCompent = p;
	m_pMoveCompent->retain();
	m_pMoveCompent->SetOwner(this);
	m_pMoveCompent->OnAttach();
}

_NS_FISHGAME_END_
