#pragma once

#ifndef _FISH_GAME_SCENE_
#define _FISH_GAME_SCENE_

//#include "2d/CCNode.h"
#include "./common.h"
#include "scripting/lua-bindings/manual/swgadget/balance_tree.h"
#include "scripting/lua-bindings/manual/swgadget/link_list.h"

namespace fishgame {

class MyObject;
class Fish;
class Bullet;
class FishObjectManager;

//template<typename MN,typename TV> class red_black_tree_alloc;
//template<typename TW,TV> class red_black_tree;
//template<typename TW,TV> class red_black_tree<TW>::internal_node;
//template<typename MN, typename TV> class link_list_alloc;
//template<typename KT> class link_list;
/*
 *缓存单元,为了方便管理以及快速的访问,其中会加入一些与Ccocos对象本身无关的数据
 */
struct NvCacheUnit{
    int           alloc_count;//已经分配出去的对象的数目
    //std::string   resource_name;//资源的名字
    link_list<cocos2d::Node*>  node_list;//用于存储对象的队列
    
    //red_black_tree<std::string,NvCacheUnit> *owner_map_ptr;//当前平衡树的指针引用
    //red_black_tree<std::string,NvCacheUnit>::internal_node *internal_ptr;//内部节点引用
    
    NvCacheUnit(link_list_alloc<link_list<cocos2d::Node*>::link_node,cocos2d::Node*> *alloc_ptr);
    NvCacheUnit(const NvCacheUnit &);
};

class FishLayer : public cocos2d::Layer
{
private:
    //缓存队列的内存分配器,，该对象的存在以及使用可以极大降低游戏中频繁的内存分配开销
    link_list_alloc<link_list<cocos2d::Node*>::link_node, cocos2d::Node*>  _object_alloc;
    red_black_tree<std::string,NvCacheUnit>    _objectCache;
    std::function<int(const std::string &,const std::string &)> _compare_func;
public:
    FishLayer();
    ~FishLayer();
    
    virtual  bool init();
    cocos2d::Layer *getFishLayer()const { return m_pLayerFish; };
    cocos2d::Layer *getBulletLayer()const { return m_pLayerBullet; };
    cocos2d::Layer *getBulletDeathLayer()const { return m_pLayerBulletDie;};
#if __debug_fishgame_collision_func
    cocos2d::DrawNode* getDrawNodeDebug(){return _drawNodeDebug;};
#endif
    
    void setFishManager(FishObjectManager *manager_ptr){m_pManager = manager_ptr; };
    //
    bool AddFish(Fish*, std::list<VisualNode>*);
    bool AddBullet(Bullet*, std::list<VisualNode>*);
    
    // 各个Layer暴露给lua中使用
    cocos2d::Layer*        m_pLayerBullet;
    cocos2d::Layer*        m_pLayerBulletDie;
    cocos2d::Layer*        m_pLayerFish;
    //调试碰撞检测系统,查看整个碰撞检测系统过程
#if __debug_fishgame_collision_func
    cocos2d::DrawNode      *_drawNodeDebug;
#endif
    FishObjectManager      *m_pManager;
    
    CREATE_FUNC(FishLayer);
    
    bool AddMyObject(MyObject*, std::list<VisualNode>*);
    
    void recycleObject(cocos2d::Node *object);
    cocos2d::Node *getOrCreateObject(const std::string &prefix_key,VisualAniType object_type);
};
}
#endif // !_FISH_GAME_SCENE_

