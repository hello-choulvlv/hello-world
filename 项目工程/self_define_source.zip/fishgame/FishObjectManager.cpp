
#include "FishObjectManager.h"
#include "MoveCompent.h"
#include "FishLayer.h"
#include "Buff.h"
#include "Bullet.h"
#include "Fish.h"

#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "scripting/lua-bindings/manual/CCLuaStack.h"
#include "spine/SkeletonAnimation.h"
USING_NS_CC;
_NS_FISHGAME_BEGIN_
FishObjectManager* FishObjectManager::m_Instance = nullptr;
// 
FishObjectManager::FishObjectManager(): 
	_fishCache(nullptr)
	,m_nHandlerBulletHitFish(0)
    , m_nHandlerCanClickShot( 0 )
	, m_nServerWidth(0)
	, m_nServerHeight(0)
	, m_nClientWidth(0)
	, m_nClientHeight(0)
	, m_bMorrow(false)
	, m_bLoaded(false)
	, m_bSwitchingScene(false)
    , m_bUpdateCacheForFish(false)
    , m_bUpdateCacheForBullet(false)
{

}

FishObjectManager::~FishObjectManager()
{
}

void FishObjectManager::Init(float a,float b,float c, float d){
	m_nServerWidth = a;
	m_nServerHeight = b;
	m_nClientWidth = c;
	m_nClientHeight = d;
	//
	_scaleX = m_nClientWidth / m_nServerWidth;
	_scaleY = m_nClientHeight / m_nServerHeight;
}

void FishObjectManager::Clear(){}

bool FishObjectManager::AddBullet(Bullet* pBullet){
	if (pBullet == nullptr)
	{
		return false;
	}

	auto itr = m_MapBullet.find(pBullet->GetId());
	if (itr != m_MapBullet.end()){
		return false;
	}

	pBullet->SetManager(this);
    pBullet->setFishLayer(m_pFishLayer);

	m_MapBullet.insert(pBullet->GetId(), pBullet);
	return true;
}

Bullet* FishObjectManager::FindBullet(unsigned long  id){
	auto itr = m_MapBullet.find(id);
	if (itr == m_MapBullet.end()){
		return nullptr;
	}
	return itr->second;
}

bool FishObjectManager::RemoveAllBullets(bool noCleanNode){
	for (auto& v : m_MapBullet)
        v.second->Clear(true, noCleanNode);
	m_MapBullet.clear();
	return true;
}

bool FishObjectManager::AddFish(Fish* pFish){
	if (pFish == nullptr)
	{
		return false;
	}
	auto itr = m_MapFish.find(pFish->GetId());
	if (itr != m_MapFish.end()){
		return false;
	}
    
    pFish->SetState(EOS_LIVE);
	pFish->SetManager(this);
    pFish->setFishLayer(m_pFishLayer);

	m_MapFish.insert(pFish->GetId(),pFish);
    return true;
}

Fish* FishObjectManager::FindFish(unsigned long id){
	auto itr = m_MapFish.find(id);
	if (itr == m_MapFish.end()){
		return nullptr;
	}
	return itr->second;
}
    
Fish* FishObjectManager::FindLockFish(unsigned long id)
{
    auto itr = m_MapFish.find(id);
    if (itr == m_MapFish.end()){
        return nullptr;
    }
    if (itr->second->InSideScreen()) {
        return itr->second;
    }
    return nullptr;
}
    
void  FishObjectManager::GetAllFishes(cocos2d::Vector<Fish*> &fishVec){
	for (auto a : m_MapFish){
		//ret.pushBack( a.second);
		fishVec.pushBack(a.second);
	}
}


bool FishObjectManager::RemoveAllFishes(bool noCleanNode){
	//对于所有的鱼,需要区别对待
	for (auto &v : m_MapFish)
        v.second->Clear(true, noCleanNode);
	m_MapFish.clear();
	return true;
}
    
bool FishObjectManager::OnUpdate(float dt){
	const int X_COUNT = 7;
	const int Y_COUNT = 3;
	//const int X_INTERVAL = m_nServerWidth / X_COUNT;
	//const int Y_INTERVAL = m_nServerHeight / Y_COUNT;
    
    const float one_div_x = X_COUNT/m_nServerWidth;
    const float one_div_y = Y_COUNT/m_nServerHeight;

	std::vector<Fish* > temp[Y_COUNT][X_COUNT];
#if __debug_fishgame_collision_func
    cocos2d::DrawNode *draw_node = m_pFishLayer->getDrawNodeDebug();
    draw_node->clear();
#endif
    
	ObjState state;
	auto i = m_MapFish.begin();
	while (i != m_MapFish.end()){
		//判断是否使用新的函数调用接口
        i->second->OnUpdate(dt);
		state = i->second->GetState();

		if (state < EOS_DEAD){
				
			const cocos2d::Vec2 &pos = i->second->GetPosition();
			float maxRadio = i->second->GetMaxRadio();
            
            int   startX = (pos.x - maxRadio) * one_div_x;/// X_INTERVAL;
            int   finalX = (pos.x + maxRadio) * one_div_x;/// X_INTERVAL;
            int   startY = (pos.y - maxRadio) * one_div_y;/// Y_INTERVAL ;
            int   finalY = (pos.y + maxRadio) * one_div_y;/// Y_INTERVAL;

			finalX = finalX < X_COUNT ? finalX : X_COUNT-1;
			finalY = finalY < Y_COUNT ? finalY : Y_COUNT-1;
            
			int y = startY < 0 ? 0 : startY;
            startX = startX < 0 ? 0 : startX;
            
			for (; y <= finalY; y++){
                std::vector<Fish* > *vec_ptr = temp[y];
				for (int x = startX; x <= finalX; x++){
						vec_ptr[x].push_back(i->second);
				}
			}
            
#if __debug_fishgame_collision_func
            float dirFish = i->second->GetDirection();
            auto &posFish = i->second->GetPosition();
            
            dirFish = ConvertDirection(dirFish);
            float sinDir = sinf(dirFish);
            float cosDir = cosf(dirFish);

            auto &pathData = i->second->GetBoundingBox();
            
            for (auto& v : pathData){
                float xs = v.offsetX * cosDir - v.offsetY * sinDir + posFish.x;
                float ys = v.offsetX * sinDir + v.offsetY * cosDir + posFish.y;
                    
                ConvertCoord(&xs, &ys);
                draw_node->drawCircle(cocos2d::Vec2(xs,ys), v.rad, 360.0f, 2.0f * M_PI *v.rad/8.0f, false, 1.0f, 1.0f, Color4F::GREEN);
            }
#endif
		}
			
		if (state == EOS_DEAD){
            i->second->Clear(false);
			i = m_MapFish.erase(i);
		}
		else if (state == EOS_DESTORY){//由于需要兼容以前的版本,所以该状态在旧版代码中存在,对于新版的C++对象,不会产生该状态
			i->second->Clear(true);
			i = m_MapFish.erase(i);
		}
		else if (state == EOS_REMOVED)
		{
			i = m_MapFish.erase(i);
		}
		else{
			i++;
		}
	}

	auto itrBullet = m_MapBullet.begin();
	while (itrBullet != m_MapBullet.end()){
        itrBullet->second->OnUpdate(dt);
		state = itrBullet->second->GetState();

		if (!m_bSwitchingScene && state < EOS_DEAD){
			if (itrBullet->second->GetTarget() == 0){
				auto &pos = itrBullet->second->GetPosition();
                bool catched = false;
                    
				float maxRadio = itrBullet->second->GetCatchRadio();
                int startX = (pos.x - maxRadio) * one_div_x;/// X_INTERVAL;
                int startY = (pos.y - maxRadio) * one_div_y;/// Y_INTERVAL;
				
				startX = startX < 0 ? 0 : startX;
				startY = startY < 0 ? 0 : startY;

                int finalX = (pos.x + maxRadio) * one_div_x;/// X_INTERVAL;
                int finalY = (pos.y + maxRadio) * one_div_y;/// Y_INTERVAL;

				finalX = finalX < X_COUNT ? finalX : X_COUNT - 1;
				finalY = finalY < Y_COUNT ? finalY : Y_COUNT - 1;

                for (int y = startY; y <= finalY; y++)
				{
                    std::vector<Fish*> *vec_ptr = temp[y];
					for (int x = startX; x <= finalX; x++)
					{
						for (auto fish : vec_ptr[x])
						{
							if (BBulletHitFish(itrBullet->second, fish)) 
							{
								onActionBulletHitFish(itrBullet->second, fish);
								catched = true;
								break;
							}
							else
							{
								if (itrBullet->second->GetId() == 190000)
								{
#if CC_ENABLE_SCRIPT_BINDING
									cocos2d::LuaStack *_stack = cocos2d::LuaEngine::getInstance()->getLuaStack();
									_stack->pushBoolean(true);

									_stack->executeFunctionByHandler(m_nHandlerCanClickShot, 1);
									_stack->clean();
#endif
								}
							}
						}
						if (catched) break;
					}
					if (catched) break;
				}
			}
			else{
				auto itr = m_MapFish.find(itrBullet->second->GetTarget());
				if (m_MapFish.end() == itr){
					itrBullet->second->SetTarget(0);
				}
				else{

					if (BBulletHitFish(itrBullet->second, itr->second)){
						onActionBulletHitFish(itrBullet->second, itr->second);
					}
				}	
			}
		}

		if (state == EOS_DEAD || state == EOS_HIT)//正常情况下,自但是不会有 EOS_HIT状态的,由此状态等同于EOS_DEAD
		{
            itrBullet->second->Clear(false);
			itrBullet = m_MapBullet.erase(itrBullet);
		}
		else if (state == EOS_DESTORY){
			itrBullet->second->Clear(true);
			itrBullet = m_MapBullet.erase(itrBullet);
		}
		else if (state == EOS_REMOVED)
		{
			itrBullet = m_MapBullet.erase(itrBullet);
		}
		else{
			itrBullet++;
		}
	}
	clean();
	return true;
}

void FishObjectManager::clean()
{
}
	
void FishObjectManager::RegisterBulletHitFishHandler(int handler){
#if CC_ENABLE_SCRIPT_BINDING
	m_nHandlerBulletHitFish = handler;
#endif
}
    
void FishObjectManager::RegisterCanClickShotHandler(int handler){
#if CC_ENABLE_SCRIPT_BINDING
    m_nHandlerCanClickShot = handler;
#endif
}

void FishObjectManager::AddFishBuff(int buffType, float buffParam, float buffTime){
	for (auto& fish : m_MapFish){
		fish.second->AddBuff(buffType, buffParam, buffTime);
	}
}

void FishObjectManager::SetMirrowShow(bool b){
	m_bMorrow = b;
}

void FishObjectManager::ConvertMirrorCoord(float* x, float* y){
	*x = m_nServerWidth - *x;
	*y = m_nServerHeight - *y;
}
void FishObjectManager::ConvertCoortToCleientPosition(float* x, float* y){
	*y = m_nServerHeight - *y;
}
void FishObjectManager::ConvertCoortToScreenSize(float* x, float* y){
	*x *= m_nClientWidth / m_nServerWidth;
	*y *= m_nClientHeight / m_nServerHeight;
}

void FishObjectManager::ConvertCoord(float* x, float * y){
	float lx = *x;
	float ly = *y;
	if (m_bMorrow)
		lx = m_nServerWidth - lx;
	else
		ly = m_nServerHeight - ly;
	*x = lx * _scaleX;
	*y = ly * _scaleY;
}

float FishObjectManager::ConvertDirection(float dir){
	if (m_bMorrow)
		return dir + M_PI;
	return dir;
}

bool FishObjectManager::BBulletHitFish(Bullet* pBullet, Fish* pFish){
	int bulletRad = pBullet->GetCatchRadio();
	int maxFishRadio = pFish->GetMaxRadio();
	auto &posBullet = pBullet->GetPosition();
	auto &posFish = pFish->GetPosition();

//	if ((posBullet.x + bulletRad < posFish.x - maxFishRadio && posBullet.y + bulletRad < posFish.y - maxFishRadio)
//		|| (posBullet.x - bulletRad > posFish.x + maxFishRadio && posBullet.y - bulletRad > posFish.y + maxFishRadio)){
//		return false;
//	}
    float d_x = posBullet.x - posFish.x;
    float d_y = posBullet.y - posFish.y;
    float r = bulletRad + maxFishRadio;
    if(d_x * d_x + d_y * d_y > r * r)
        return false;
    
	float dirFish = pFish->GetDirection();
	float sinDir = sinf(dirFish);
	float cosDir = cosf(dirFish);

	auto &pathData = pFish->GetBoundingBox();
    
    for (auto& v : pathData){
        float x = v.offsetX * cosDir - v.offsetY * sinDir + posFish.x;
        float y = v.offsetX * sinDir + v.offsetY * cosDir + posFish.y;
            
        //float rad = v.rad;
        
        float _x = x - posBullet.x;
        float _y = y - posBullet.y;
        float _dis = (v.rad + bulletRad);
        if (_x * _x + _y * _y <= _dis * _dis){
            return true;
        }				
    }

	return false;
}

void FishObjectManager::onActionBulletHitFish(Bullet* pBullet, Fish* pFish){
	pBullet->SetState(EOS_DEAD);
    pFish->OnHit();

#if CC_ENABLE_SCRIPT_BINDING
	cocos2d::LuaStack *_stack = cocos2d::LuaEngine::getInstance()->getLuaStack();
	_stack->pushObject(pBullet, "fishgame.Bullet");
	_stack->pushObject(pFish, "fishgame.Fish");

	_stack->executeFunctionByHandler(m_nHandlerBulletHitFish, 2);
	_stack->clean();
#endif
}
_NS_FISHGAME_END_
