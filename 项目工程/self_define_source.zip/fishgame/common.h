#pragma once

#ifndef _FISH_GAME_COMMON_
#define  _FISH_GAME_COMMON_

//lua_getglobal(tolua_S, "_G");
//if (lua_istable(tolua_S,-1))//stack:...,_G,
//{
//    
//}
//lua_pop(tolua_S, 1);

#include "cocos2d.h"
#define _NS_FISHGAME_BEGIN_ namespace fishgame {
#define _NS_FISHGAME_END_ }

#define _US_NS_FISHGAME_   using namespace fishgame;
//是否开启碰撞检测调试功能
#define __debug_fishgame_collision_func 0

_NS_FISHGAME_BEGIN_

enum ObjType{
    EOT_NONE = 0,
    EOT_FISH,
    EOT_BULLET,
};
    
enum ObjState
{
    EOS_INIT = 0,
    EOS_LIVE = 1,
    EOS_HIT = 2,
    EOS_DEAD = 3,
    EOS_DESTORY = 4,
    EOS_LIGHTING = 5,//对象正处于从死亡到被删除的过渡状态中
	EOS_REMOVED  =6,//被删除状态,此状态下,对象将会被移除掉
};
    
enum ObjAnimationType{
    EOAT_NONE = 0,
    EOAT_FRAME,			//
    EOAT_SKELETON,		//
};
    
struct BoundingBox
{
    float offsetX;
    float offsetY;
    float rad;
};
    
struct BoundingBoxData
{
    int		                                       nId;
    std::vector<BoundingBox> value;
};
    
    
struct ImageInfo
{
	std::string		imageName;
	std::string		aniName;
	int				aniType;
	float			offsetX;
	float			offsetY;
	float			direction;
	float			scale;
};

struct VisualNode
{
	cocos2d::Node*	target;
	float			scale;
	float			direction;
	float			offsetX;
	float			offsetY;
    bool            bSpecialShow; // 鱼王变红

	VisualNode()
		: target(nullptr)
        , bSpecialShow( false )
	{

	}
};
    
struct VisualImage
{
    std::string			Image;
    std::string			Name;
    std::string         ResPath;
    float				Scale;
    float				OffestX;
    float				OffestY;
    float				Direction;
    int					AniType;
    int                 nZOrder;
        
    VisualImage()
    {
        Image = "";
        Name = "";
        ResPath = "";
        Scale = 0;
        OffestX = 0;
        OffestY = 0;
        Direction = 0;
        AniType = 0;
        nZOrder = 0;
    }
};
    
struct VisualData
{
    int		nID;
    int		nTypeID;
    std::list<VisualImage>	ImageInfoLive;
    std::list<VisualImage>	ImageInfoDie;

        
    VisualData(int id, int type)
    {
        nID = id;
        nTypeID = type;

    }
	VisualData() {};
};
//动画的类型
enum VisualAniType
{
    VAT_FRAME = 0,
    VAT_SKELETON = 1,//骨骼动画Json
    VAT_PARTICLE = 2,
    VAT_SKELETON_BINARY= 3,//二进制Spine 
     VAT_ANIMATION = 4,//cocos2d::Animation
	 VAT_SPRITE           =5,//cocos2d::Sprite
};

enum MoveCompentType
{
    EMCT_PATH,
    EMCT_DIRECTION,
    EMCT_TARGET,
};

enum PathMoveType
{
    PMT_LINE=0,
    PMT_BEZIER,
    PMT_CIRCLE,
    PMT_STAY,
};
    
struct PathDataElement
{
    float		x;
    float		y;
    float		dir;
    float		dirDeg;
};
    
struct PathMoveData
{
    int			nType;
    float		xPos[4];
    float		yPos[4];
    int			nPointCount;
    float		fDirction;
    int			nDuration;
    int			nStartTime;
    int			nEndTime;
};
 //创建鱼时需要用到的数据结构
//struct FishStatic
//{
//	VisualAniType     aniType;//动画的类型
//	int                           zOrder;//动画的层序
//	float                       direction;//动画的初始方向
//	std::string             imageName;//图片的名字
//	std::string             armatureName;
//	float                       offsetX;//初始偏移量,一般只有在有多个动画组合时此字段才会有用
//	float                       offsetY;
//	bool                       isShadow;//是否是阴影
//	int                         dieFi;//???
//	//std::string           resPath;
//	std::string           dieName;
//	float                     dieScale;
//	std::string          dieframeFormat;//此字段/dieframeMap只有当动画为VAT_ANIMATION时才会有用,表示动画的格式
//	int                        liveFi;
//	std::string          liveName;
//	float                     liveScale;
//	std::string          liveframeFormat;//与dieframeFormat表示类似,只不过表示的是正常生存时的动画数据
//
//	std::vector<int>    dieframeMap;
//	std::vector<int>    liveframeMap;
//};
//创建子弹时需要用到的数据结构
//struct BulletStatic
//{
//	VisualAniType  aniType;//子弹的动画类型
//	std::string          resource;//资源的路径
//	std::string          aniCreateName;//对于序列帧动画Armature而言需要三个数据,文件名字,动画创建时名字,动画的名字
//	std::string          aniName;//动画的名字,如果是Sprite,则这个字段就不会被使用
//	std::string          deathName;//死亡动画的名字
//	float                    scale;             //缩放比例,目前没有使用,暂时定为1.0f
//};
//播放鱼正常/死亡动画时需要用到的数据结构
//struct AnimationInfo
//{
//	float                        offsetX, offsetY,direction;
//	VisualAniType      aniType;//动画的类型,不同的类型播放动画的方式不同
//	float                        scale;//播放此动画时,对象的缩放比例
//	std::string              aniName;//动画的名字
//	cocos2d::Node      *target;//目标动画
//	cocos2d::Animate  *animate;//序列帧动画,当aniType为VAT_ANIMATION时使用
//};
//缓存对象数据结构Fish
	_NS_FISHGAME_END_
#endif
