/*
  *将FishObjectManager文件分离
  *并将MyObject移动到单独的文件中
  *不修改原来的功能
  *@2018年3月3日
  *Author:xiaoxiong
 */
#ifndef __MY_OBJECT_H__
#define __MY_OBJECT_H__
#include "cocos2d.h"
#include "common.h"
//
_NS_FISHGAME_BEGIN_
class MoveCompent;
class Buff;
class Effect;
class FishObjectManager;
class FishLayer;
//
class MyObject : public cocos2d::Ref
{
	friend class FishCacheManager;
protected:
	MyObject();
public:
	virtual ~MyObject();

public:
	ObjType GetType() { return m_nType; }
	//判断对象是否是调用新接口实现的,此数据不能被外部调用修改，只能从内部修改
	//inline  bool        isCreatedNew()const  {return _isCreatedByNew;};
	//每帧调用,此函数不能与OnUpdate混合使用
	//virtual void       onUpdateNew(float dt);
	//对象添加到场景中时调用
	//virtual void       onEnter();
	//对象从场景中移除调用
	//virtual void       onExit();
	//对象销毁时调用
	//virtual void       onDestroy();
	//对象重置状态时调用
	//virtual  void      changeNormal();
	//设置位置
	//void                    setPosition(const cocos2d::Vec2 &position);
	//inline    int        getVisualID()const {return _visualID;};
	//inline    void     setVisualID(int visualID) { _visualID = visualID; };
	///////////////////////以上几个函数调用时需要格外的注意//////////////////////////

	unsigned long GetId()const { return m_nId; };
	void SetId(unsigned long newId) { m_nId = newId; };

	MyObject* GetOwner() { return m_pOwner; }
	void SetOwner(MyObject* p) { m_pOwner = p; }

	ObjState GetState() { return m_nState; }
	virtual void SetState(ObjState);

	void SetPosition(float x, float y);
	const cocos2d::Vec2& GetPosition() { return m_pPosition; }

	float GetDirection() { return m_fDirection; }
	void SetDirection(float dir);

	void SetManager(FishObjectManager* manager) { m_pManager = manager; }
	FishObjectManager* GetManager() { return m_pManager; }
    
    void setFishLayer(FishLayer *layer){m_pFishLayer = layer;};

	virtual void Clear(bool, bool noCleanNode = false);
	virtual void OnClear(bool);

	virtual void OnUpdate(float fdt);

	bool InSideScreen() {
		return m_pPosition.x > 10 && m_pPosition.x < 1430 &&
			m_pPosition.y > 10 && m_pPosition.y < 890;
	}
	void OnMoveEnd();

	void	SetTarget(int i);
	int		GetTarget();

	bool GetSpecialShow() { return m_bSpecialShow; }
	void SetSpecialShow(bool bValue) { m_bSpecialShow = bValue; }

	MoveCompent* GetMoveCompent() { return m_pMoveCompent; }
	void	SetMoveCompent(MoveCompent*);
	void	AddBuff(int buffType, float buffParam, float buffTime);
	const std::list<Buff*>& 	GetBuffs() { return m_pBuffList; }

	// 填充创建显示节点所需数据
	CC_SYNTHESIZE(unsigned int, m_nChairID, ChairID);
	void SetVisualData(int nId, int nTypeID);
	void AddVisualLiveData(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType);
	void AddVisualDieData(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType);

	// 新增接口 begin
	void AddVisualLiveDataWithZOrder(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType, int nZOrder = 10);
	void AddVisualDieDataWithZOrder(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType, int nZOrder = 11);
	// 新增接口 end

	VisualData* GetVisualData() { return &m_pVisualData; }

	void updateWinSize(float w, float h) { fWidth = w; fHeigth = h; }

	//void              setZOrder(int zorder) { _zOrder = zorder; };
	float fWidth;
	float fHeigth;

protected:
	ObjType                m_nType;
	//对象的主干容器,此容器的类型暂时定为cocos2d::Node,待游戏的后期优化时
	//我们将会对这个数据进行修改
	//cocos2d::Node    *_rootNode;
	unsigned long       m_nId;

	cocos2d::Vec2      m_pPosition;
	float                        m_fDirection;
	bool                        m_bInScreen;

	bool                        m_bDirtyPos;
	bool                        m_bDirtyDir;
	bool                        m_bDirtyInScreen;

	/*
	* 判断🐟是否是鱼王
	*/
	bool                        m_bSpecialShow;

	ObjState               m_nState;
	bool                       m_bDirtyState;
	int                         m_nTargetId;

	std::list<VisualNode>	m_pVisualNodeList;
	std::list<Buff*>		        m_pBuffList;
	//std::list<Effect*>		        m_pEffectList;

	VisualData                       m_pVisualData;

	MyObject                         *m_pOwner;
	FishObjectManager      *m_pManager;
    FishLayer              *m_pFishLayer;
	MoveCompent               *m_pMoveCompent;
	//对象是调用新接口实现的还是调用原来的接口实现的
	//bool                                    _isCreatedByNew;
	//int                                       _visualID;
	//新分配的16 * sizeof(float)内存空间,用来快速计算路径
	//float                                   _extraSpace[16];
	//int                                          _zOrder;
};
_NS_FISHGAME_END_
#endif
