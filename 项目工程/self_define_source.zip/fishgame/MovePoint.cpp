#include "MovePoint.h"

CMovePoint::CMovePoint()
:m_Position(0, 0)
,m_Direction(0.0f)
{
}

CMovePoint::CMovePoint(const cocos2d::Vec2 &pos, float dir)
:m_Position(pos)
,m_Direction(dir)
{
}
