#include "lua_FishGame_auto.hpp"
#include "cocos2d.h"
#include "scripting/lua-bindings/manual/swgadget/fishgame/FishObjectManager.h"
#include "scripting/lua-bindings/manual/swgadget/fishgame/MoveCompent.h"
#include "scripting/lua-bindings/manual/swgadget/fishgame/FishLayer.h"
#include "scripting/lua-bindings/manual/tolua_fix.h"
#include "scripting/lua-bindings/manual/LuaBasicConversions.h"
//#include "FishCacheManager.h"
#include "Bullet.h"
#include "Fish.h"

int lua_fishgame_FishLayer_AddBullet(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishLayer* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishLayer",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishLayer*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishLayer_AddBullet'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        fishgame::Bullet* arg0;
        std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >* arg1;

        ok &= luaval_to_object<fishgame::Bullet>(tolua_S, 2, "fishgame.Bullet",&arg0, "fishgame.FishLayer:AddBullet");

        ok &= luaval_to_object<std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >>(tolua_S, 3, "std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >*",&arg1, "fishgame.FishLayer:AddBullet");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishLayer_AddBullet'", nullptr);
            return 0;
        }
        bool ret = cobj->AddBullet(arg0, arg1);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishLayer:AddBullet",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishLayer_AddBullet'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishLayer_AddMyObject(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishLayer* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishLayer",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishLayer*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishLayer_AddMyObject'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        fishgame::MyObject* arg0;
        std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >* arg1;

        ok &= luaval_to_object<fishgame::MyObject>(tolua_S, 2, "fishgame.MyObject",&arg0, "fishgame.FishLayer:AddMyObject");

        ok &= luaval_to_object<std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >>(tolua_S, 3, "std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >*",&arg1, "fishgame.FishLayer:AddMyObject");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishLayer_AddMyObject'", nullptr);
            return 0;
        }
        bool ret = cobj->AddMyObject(arg0, arg1);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishLayer:AddMyObject",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishLayer_AddMyObject'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishLayer_AddFish(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishLayer* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishLayer",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishLayer*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishLayer_AddFish'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        fishgame::Fish* arg0;
        std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >* arg1;

        ok &= luaval_to_object<fishgame::Fish>(tolua_S, 2, "fishgame.Fish",&arg0, "fishgame.FishLayer:AddFish");

        ok &= luaval_to_object<std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >>(tolua_S, 3, "std::list<fishgame::VisualNode, std::allocator<fishgame::VisualNode> >*",&arg1, "fishgame.FishLayer:AddFish");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishLayer_AddFish'", nullptr);
            return 0;
        }
        bool ret = cobj->AddFish(arg0, arg1);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishLayer:AddFish",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishLayer_AddFish'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishLayer_create(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"fishgame.FishLayer",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishLayer_create'", nullptr);
            return 0;
        }
        fishgame::FishLayer* ret = fishgame::FishLayer::create();
        object_to_luaval<fishgame::FishLayer>(tolua_S, "fishgame.FishLayer",(fishgame::FishLayer*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "fishgame.FishLayer:create",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishLayer_create'.",&tolua_err);
#endif
    return 0;
}
int lua_fishgame_FishLayer_constructor(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishLayer* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif



    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishLayer_constructor'", nullptr);
            return 0;
        }
        cobj = new fishgame::FishLayer();
        cobj->autorelease();
        int ID =  (int)cobj->_ID ;
        int* luaID =  &cobj->_luaID ;
        toluafix_pushusertype_ccobject(tolua_S, ID, luaID, (void*)cobj,"fishgame.FishLayer");
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishLayer:FishLayer",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishLayer_constructor'.",&tolua_err);
#endif

    return 0;
}

static int lua_fishgame_FishLayer_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (FishLayer)");
    return 0;
}

int lua_register_fishgame_FishLayer(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.FishLayer");
    tolua_cclass(tolua_S,"FishLayer","fishgame.FishLayer","cc.Layer",nullptr);

    tolua_beginmodule(tolua_S,"FishLayer");
        tolua_function(tolua_S,"new",lua_fishgame_FishLayer_constructor);
        tolua_function(tolua_S,"AddBullet",lua_fishgame_FishLayer_AddBullet);
        tolua_function(tolua_S,"AddMyObject",lua_fishgame_FishLayer_AddMyObject);
        tolua_function(tolua_S,"AddFish",lua_fishgame_FishLayer_AddFish);
        tolua_function(tolua_S,"create", lua_fishgame_FishLayer_create);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::FishLayer).name();
    g_luaType[typeName] = "fishgame.FishLayer";
    g_typeCast["FishLayer"] = "fishgame.FishLayer";
    return 1;
}

// 新增接口begin
int lua_fishgame_MyObject_AddVisualLiveDataWithZOrder(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_AddVisualLiveDataWithZOrder'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 9)
    {
        std::string arg0;
        std::string arg1;
        std::string arg2;
        double arg3;
        double arg4;
        double arg5;
        double arg6;
        int arg7;
        int arg8;
        
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_std_string(tolua_S, 3,&arg1, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_std_string(tolua_S, 4,&arg2, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 5,&arg3, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 6,&arg4, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 7,&arg5, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 8,&arg6, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_int32(tolua_S, 9,(int *)&arg7, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        
        ok &= luaval_to_int32(tolua_S, 10,(int *)&arg8, "fishgame.MyObject:AddVisualLiveDataWithZOrder");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_AddVisualLiveDataWithZOrder'", nullptr);
            return 0;
        }
        cobj->AddVisualLiveDataWithZOrder(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:AddVisualLiveDataWithZOrder",argc, 9);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_AddVisualLiveDataWithZOrder'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_MyObject_AddVisualDieDataWithZOrder(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_AddVisualDieDataWithZOrder'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 9)
    {
        std::string arg0;
        std::string arg1;
        std::string arg2;
        double arg3;
        double arg4;
        double arg5;
        double arg6;
        int arg7;
        int arg8;
        
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_std_string(tolua_S, 3,&arg1, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_std_string(tolua_S, 4,&arg2, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 5,&arg3, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 6,&arg4, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 7,&arg5, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_number(tolua_S, 8,&arg6, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_int32(tolua_S, 9,(int *)&arg7, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        
        ok &= luaval_to_int32(tolua_S, 10,(int *)&arg8, "fishgame.MyObject:AddVisualDieDataWithZOrder");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_AddVisualDieDataWithZOrder'", nullptr);
            return 0;
        }
        cobj->AddVisualDieDataWithZOrder(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:AddVisualDieDataWithZOrder",argc, 8);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_AddVisualDieDataWithZOrder'.",&tolua_err);
#endif
    
    return 0;
}
// 新增接口end

int lua_fishgame_MyObject_AddVisualLiveData(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_AddVisualLiveData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 8) 
    {
        std::string arg0;
        std::string arg1;
        std::string arg2;
        double arg3;
        double arg4;
        double arg5;
        double arg6;
        int arg7;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "fishgame.MyObject:AddVisualLiveData");

        ok &= luaval_to_std_string(tolua_S, 3,&arg1, "fishgame.MyObject:AddVisualLiveData");

        ok &= luaval_to_std_string(tolua_S, 4,&arg2, "fishgame.MyObject:AddVisualLiveData");

        ok &= luaval_to_number(tolua_S, 5,&arg3, "fishgame.MyObject:AddVisualLiveData");

        ok &= luaval_to_number(tolua_S, 6,&arg4, "fishgame.MyObject:AddVisualLiveData");

        ok &= luaval_to_number(tolua_S, 7,&arg5, "fishgame.MyObject:AddVisualLiveData");

        ok &= luaval_to_number(tolua_S, 8,&arg6, "fishgame.MyObject:AddVisualLiveData");

        ok &= luaval_to_int32(tolua_S, 9,(int *)&arg7, "fishgame.MyObject:AddVisualLiveData");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_AddVisualLiveData'", nullptr);
            return 0;
        }
        cobj->AddVisualLiveData(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:AddVisualLiveData",argc, 8);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_AddVisualLiveData'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetMoveCompent(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetMoveCompent'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::MoveCompent* arg0;

        ok &= luaval_to_object<fishgame::MoveCompent>(tolua_S, 2, "fishgame.MoveCompent",&arg0, "fishgame.MyObject:SetMoveCompent");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetMoveCompent'", nullptr);
            return 0;
        }
        cobj->SetMoveCompent(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetMoveCompent",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetMoveCompent'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_GetOwner(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetOwner'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetOwner'", nullptr);
            return 0;
        }
        fishgame::MyObject* ret = cobj->GetOwner();
        object_to_luaval<fishgame::MyObject>(tolua_S, "fishgame.MyObject",(fishgame::MyObject*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetOwner",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetOwner'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_setChairID(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_setChairID'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        unsigned int arg0;

        ok &= luaval_to_uint32(tolua_S, 2,&arg0, "fishgame.MyObject:setChairID");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_setChairID'", nullptr);
            return 0;
        }
        cobj->setChairID(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:setChairID",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_setChairID'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetOwner(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetOwner'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::MyObject* arg0;

        ok &= luaval_to_object<fishgame::MyObject>(tolua_S, 2, "fishgame.MyObject",&arg0, "fishgame.MyObject:SetOwner");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetOwner'", nullptr);
            return 0;
        }
        cobj->SetOwner(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetOwner",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetOwner'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_OnMoveEnd(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_OnMoveEnd'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_OnMoveEnd'", nullptr);
            return 0;
        }
        cobj->OnMoveEnd();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:OnMoveEnd",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_OnMoveEnd'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_GetMoveCompent(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetMoveCompent'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetMoveCompent'", nullptr);
            return 0;
        }
        fishgame::MoveCompent* ret = cobj->GetMoveCompent();
        object_to_luaval<fishgame::MoveCompent>(tolua_S, "fishgame.MoveCompent",(fishgame::MoveCompent*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetMoveCompent",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetMoveCompent'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetId(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetId'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        unsigned long arg0;

        ok &= luaval_to_ulong(tolua_S, 2, &arg0, "fishgame.MyObject:SetId");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetId'", nullptr);
            return 0;
        }
        cobj->SetId(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetId",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetId'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_updateWinSize(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_updateWinSize'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        double arg0;
        double arg1;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MyObject:updateWinSize");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.MyObject:updateWinSize");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_updateWinSize'", nullptr);
            return 0;
        }
        cobj->updateWinSize(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:updateWinSize",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_updateWinSize'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_OnClear(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_OnClear'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.MyObject:OnClear");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_OnClear'", nullptr);
            return 0;
        }
        cobj->OnClear(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:OnClear",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_OnClear'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetManager(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetManager'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::FishObjectManager* arg0;

        ok &= luaval_to_object<fishgame::FishObjectManager>(tolua_S, 2, "fishgame.FishObjectManager",&arg0, "fishgame.MyObject:SetManager");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetManager'", nullptr);
            return 0;
        }
        cobj->SetManager(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetManager",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetManager'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_AddVisualDieData(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_AddVisualDieData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 8) 
    {
        std::string arg0;
        std::string arg1;
        std::string arg2;
        double arg3;
        double arg4;
        double arg5;
        double arg6;
        int arg7;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "fishgame.MyObject:AddVisualDieData");

        ok &= luaval_to_std_string(tolua_S, 3,&arg1, "fishgame.MyObject:AddVisualDieData");

        ok &= luaval_to_std_string(tolua_S, 4,&arg2, "fishgame.MyObject:AddVisualDieData");

        ok &= luaval_to_number(tolua_S, 5,&arg3, "fishgame.MyObject:AddVisualDieData");

        ok &= luaval_to_number(tolua_S, 6,&arg4, "fishgame.MyObject:AddVisualDieData");

        ok &= luaval_to_number(tolua_S, 7,&arg5, "fishgame.MyObject:AddVisualDieData");

        ok &= luaval_to_number(tolua_S, 8,&arg6, "fishgame.MyObject:AddVisualDieData");

        ok &= luaval_to_int32(tolua_S, 9,(int *)&arg7, "fishgame.MyObject:AddVisualDieData");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_AddVisualDieData'", nullptr);
            return 0;
        }
        cobj->AddVisualDieData(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:AddVisualDieData",argc, 8);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_AddVisualDieData'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_GetVisualData(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetVisualData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetVisualData'", nullptr);
            return 0;
        }
        fishgame::VisualData* ret = cobj->GetVisualData();
        #pragma warning NO CONVERSION FROM NATIVE FOR VisualData*;
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetVisualData",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetVisualData'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_GetTarget(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetTarget'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetTarget'", nullptr);
            return 0;
        }
        int ret = cobj->GetTarget();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetTarget",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetTarget'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_GetDirection(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetDirection'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetDirection'", nullptr);
            return 0;
        }
        double ret = cobj->GetDirection();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetDirection",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetDirection'.",&tolua_err);
#endif

    return 0;
}

int lua_fishgame_MyObject_SetState(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetState'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.MyObject:SetState");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetState'", nullptr);
            return 0;
        }
        cobj->SetState((fishgame::ObjState)arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetState",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetState'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_getChairID(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_getChairID'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_getChairID'", nullptr);
            return 0;
        }
        unsigned int ret = cobj->getChairID();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:getChairID",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_getChairID'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetDirection(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetDirection'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MyObject:SetDirection");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetDirection'", nullptr);
            return 0;
        }
        cobj->SetDirection(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetDirection",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetDirection'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_Clear(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_Clear'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.MyObject:Clear");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_Clear'", nullptr);
            return 0;
        }
        cobj->Clear(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 2) 
    {
        bool arg0;
        bool arg1;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.MyObject:Clear");

        ok &= luaval_to_boolean(tolua_S, 3,&arg1, "fishgame.MyObject:Clear");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_Clear'", nullptr);
            return 0;
        }
        cobj->Clear(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:Clear",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_Clear'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_GetId(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetId'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetId'", nullptr);
            return 0;
        }
        unsigned long ret = cobj->GetId();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetId",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetId'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_GetManager(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetManager'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetManager'", nullptr);
            return 0;
        }
        fishgame::FishObjectManager* ret = cobj->GetManager();
        object_to_luaval<fishgame::FishObjectManager>(tolua_S, "fishgame.FishObjectManager",(fishgame::FishObjectManager*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetManager",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetManager'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_AddBuff(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_AddBuff'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 3) 
    {
        int arg0;
        double arg1;
        double arg2;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.MyObject:AddBuff");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.MyObject:AddBuff");

        ok &= luaval_to_number(tolua_S, 4,&arg2, "fishgame.MyObject:AddBuff");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_AddBuff'", nullptr);
            return 0;
        }
        cobj->AddBuff(arg0, arg1, arg2);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:AddBuff",argc, 3);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_AddBuff'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetVisualData(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetVisualData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        int arg0;
        int arg1;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.MyObject:SetVisualData");

        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "fishgame.MyObject:SetVisualData");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetVisualData'", nullptr);
            return 0;
        }
        cobj->SetVisualData(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetVisualData",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetVisualData'.",&tolua_err);
#endif

    return 0;
}

int lua_fishgame_MyObject_GetState(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetState'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetState'", nullptr);
            return 0;
        }
        int ret = cobj->GetState();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetState",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetState'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetTarget(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetTarget'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.MyObject:SetTarget");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetTarget'", nullptr);
            return 0;
        }
        cobj->SetTarget(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetTarget",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetTarget'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_SetSpecialShow(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetSpecialShow'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        bool arg0;
        
        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.MyObject:SetSpecialShow");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetSpecialShow'", nullptr);
            return 0;
        }
        cobj->SetSpecialShow(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetSpecialShow",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetSpecialShow'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_MyObject_GetType(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetType'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetType'", nullptr);
            return 0;
        }
        int ret = cobj->GetType();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetType",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetType'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_MyObject_GetSpecialShow(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetSpecialShow'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetSpecialShow'", nullptr);
            return 0;
        }
        bool ret = cobj->GetSpecialShow();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetSpecialShow",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetSpecialShow'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_OnUpdate(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_OnUpdate'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MyObject:OnUpdate");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_OnUpdate'", nullptr);
            return 0;
        }
        cobj->OnUpdate(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:OnUpdate",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_OnUpdate'.",&tolua_err);
#endif

    return 0;
}

int lua_fishgame_MyObject_SetPosition(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_SetPosition'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        double arg0;
        double arg1;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MyObject:SetPosition");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.MyObject:SetPosition");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_SetPosition'", nullptr);
            return 0;
        }
        cobj->SetPosition(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:SetPosition",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_SetPosition'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MyObject_InSideScreen(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_InSideScreen'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_InSideScreen'", nullptr);
            return 0;
        }
        bool ret = cobj->InSideScreen();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:InSideScreen",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_InSideScreen'.",&tolua_err);
#endif

    return 0;
}

int lua_fishgame_MyObject_GetPosition(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MyObject* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MyObject",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MyObject*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MyObject_GetPosition'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MyObject_GetPosition'", nullptr);
            return 0;
        }
        cocos2d::Point ret = cobj->GetPosition();
        point_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MyObject:GetPosition",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MyObject_GetPosition'.",&tolua_err);
#endif

    return 0;
}
static int lua_fishgame_MyObject_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (MyObject)");
    return 0;
}

int lua_register_fishgame_MyObject(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.MyObject");
    tolua_cclass(tolua_S,"MyObject","fishgame.MyObject","cc.Ref",nullptr);

    tolua_beginmodule(tolua_S,"MyObject");
        tolua_function(tolua_S,"AddVisualLiveData",lua_fishgame_MyObject_AddVisualLiveData);
        tolua_function(tolua_S,"SetMoveCompent",lua_fishgame_MyObject_SetMoveCompent);
        tolua_function(tolua_S,"GetOwner",lua_fishgame_MyObject_GetOwner);
        tolua_function(tolua_S,"setChairID",lua_fishgame_MyObject_setChairID);
        tolua_function(tolua_S,"SetOwner",lua_fishgame_MyObject_SetOwner);
        tolua_function(tolua_S,"OnMoveEnd",lua_fishgame_MyObject_OnMoveEnd);
        tolua_function(tolua_S,"GetMoveCompent",lua_fishgame_MyObject_GetMoveCompent);
        tolua_function(tolua_S,"SetId",lua_fishgame_MyObject_SetId);
        tolua_function(tolua_S,"updateWinSize",lua_fishgame_MyObject_updateWinSize);
        tolua_function(tolua_S,"OnClear",lua_fishgame_MyObject_OnClear);
        tolua_function(tolua_S,"SetManager",lua_fishgame_MyObject_SetManager);
        tolua_function(tolua_S,"AddVisualDieData",lua_fishgame_MyObject_AddVisualDieData);
        tolua_function(tolua_S,"GetVisualData",lua_fishgame_MyObject_GetVisualData);
        tolua_function(tolua_S,"GetTarget",lua_fishgame_MyObject_GetTarget);
        tolua_function(tolua_S,"GetDirection",lua_fishgame_MyObject_GetDirection);
        tolua_function(tolua_S,"SetState",lua_fishgame_MyObject_SetState);
        tolua_function(tolua_S,"getChairID",lua_fishgame_MyObject_getChairID);
        tolua_function(tolua_S,"SetDirection",lua_fishgame_MyObject_SetDirection);
        tolua_function(tolua_S,"Clear",lua_fishgame_MyObject_Clear);
        tolua_function(tolua_S,"GetId",lua_fishgame_MyObject_GetId);
        tolua_function(tolua_S,"GetManager",lua_fishgame_MyObject_GetManager);
        tolua_function(tolua_S,"AddBuff",lua_fishgame_MyObject_AddBuff);
        tolua_function(tolua_S,"SetVisualData",lua_fishgame_MyObject_SetVisualData);
    
        tolua_function(tolua_S,"AddVisualLiveDataWithZOrder",lua_fishgame_MyObject_AddVisualLiveDataWithZOrder);
        tolua_function(tolua_S,"AddVisualDieDataWithZOrder",lua_fishgame_MyObject_AddVisualDieDataWithZOrder);
    
        tolua_function(tolua_S,"GetState",lua_fishgame_MyObject_GetState);
        tolua_function(tolua_S,"SetTarget",lua_fishgame_MyObject_SetTarget);
        tolua_function(tolua_S,"SetSpecialShow",lua_fishgame_MyObject_SetSpecialShow);
        tolua_function(tolua_S,"GetSpecialShow",lua_fishgame_MyObject_GetSpecialShow);
        tolua_function(tolua_S,"GetType",lua_fishgame_MyObject_GetType);
        tolua_function(tolua_S,"OnUpdate",lua_fishgame_MyObject_OnUpdate);
        tolua_function(tolua_S,"SetPosition",lua_fishgame_MyObject_SetPosition);
        tolua_function(tolua_S,"InSideScreen",lua_fishgame_MyObject_InSideScreen);
        tolua_function(tolua_S,"GetPosition",lua_fishgame_MyObject_GetPosition);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::MyObject).name();
    g_luaType[typeName] = "fishgame.MyObject";
    g_typeCast["MyObject"] = "fishgame.MyObject";
    return 1;
}


int lua_fishgame_Fish_SetParticle(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_SetParticle'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "fishgame.Fish:SetParticle");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_SetParticle'", nullptr);
            return 0;
        }
        cobj->SetParticle(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:SetParticle",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_SetParticle'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_SetDirection(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_SetDirection'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.Fish:SetDirection");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_SetDirection'", nullptr);
            return 0;
        }
        cobj->SetDirection(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:SetDirection",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_SetDirection'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_getRefershID(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_getRefershID'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_getRefershID'", nullptr);
            return 0;
        }
        unsigned int ret = cobj->getRefershID();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:getRefershID",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_getRefershID'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_RegisterHitFishHandler(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_RegisterHitFishHandler'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        int handler = toluafix_ref_function(tolua_S, 2, 0);
        cobj->RegisterHitFishHandler(handler);
        return 0;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:RegisterHitFishHandler",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_RegisterHitFishHandler'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_Fish_SetHitFishColor(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_SetHitFishColor'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        cocos2d::Color3B arg0;
        
        ok &= luaval_to_color3b(tolua_S, 2, &arg0, "fishgame.Fish:SetHitFishColor");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_SetHitFishColor'", nullptr);
            return 0;
        }
        cobj->SetHitFishColor(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:SetHitFishColor",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_SetHitFishColor'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_Fish_GetHitFishColor(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_GetHitFishColor'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_GetHitFishColor'", nullptr);
            return 0;
        }
        cocos2d::Color3B ret = cobj->GetHitFishColor();
        color3b_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:GetHitFishColor",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_GetHitFishColor'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_Fish_SetNormalFishColor(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_SetNormalFishColor'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        cocos2d::Color3B arg0;
        
        ok &= luaval_to_color3b(tolua_S, 2, &arg0, "fishgame.Fish:SetNormalFishColor");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_SetNormalFishColor'", nullptr);
            return 0;
        }
        cobj->SetNormalFishColor(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:SetNormalFishColor",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_SetNormalFishColor'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_Fish_SetSpecialFishColor(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_SetSpecialFishColor'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        cocos2d::Color3B arg0;
        
        ok &= luaval_to_color3b(tolua_S, 2, &arg0, "fishgame.Fish:SetSpecialFishColor");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_SetSpecialFishColor'", nullptr);
            return 0;
        }
        cobj->SetSpecialFishColor(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:SetSpecialFishColor",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_SetSpecialFishColor'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_Fish_GetNormalFishColor(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_GetNormalFishColor'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_GetNormalFishColor'", nullptr);
            return 0;
        }
        cocos2d::Color3B ret = cobj->GetNormalFishColor();
        color3b_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:GetNormalFishColor",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_GetNormalFishColor'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_Fish_GetSpecialFishColor(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_GetSpecialFishColor'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_GetSpecialFishColor'", nullptr);
            return 0;
        }
        cocos2d::Color3B ret = cobj->GetSpecialFishColor();
        color3b_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:GetSpecialFishColor",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_GetSpecialFishColor'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_Fish_GetMaxRadio(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_GetMaxRadio'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_GetMaxRadio'", nullptr);
            return 0;
        }
        int ret = cobj->GetMaxRadio();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:GetMaxRadio",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_GetMaxRadio'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_SetMoveCompent(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_SetMoveCompent'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::MoveCompent* arg0;

        ok &= luaval_to_object<fishgame::MoveCompent>(tolua_S, 2, "fishgame.MoveCompent",&arg0, "fishgame.Fish:SetMoveCompent");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_SetMoveCompent'", nullptr);
            return 0;
        }
        cobj->SetMoveCompent(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:SetMoveCompent",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_SetMoveCompent'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_OnHit(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_OnHit'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_OnHit'", nullptr);
            return 0;
        }
        cobj->OnHit();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:OnHit",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_OnHit'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_OnUpdate(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_OnUpdate'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.Fish:OnUpdate");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_OnUpdate'", nullptr);
            return 0;
        }
        cobj->OnUpdate(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:OnUpdate",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_OnUpdate'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_GetParticle(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_GetParticle'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_GetParticle'", nullptr);
            return 0;
        }
        std::string ret = cobj->GetParticle();
        tolua_pushcppstring(tolua_S,ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:GetParticle",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_GetParticle'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_GetDirection(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_GetDirection'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_GetDirection'", nullptr);
            return 0;
        }
        double ret = cobj->GetDirection();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:GetDirection",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_GetDirection'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_setRefershID(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_setRefershID'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        unsigned int arg0;

        ok &= luaval_to_uint32(tolua_S, 2,&arg0, "fishgame.Fish:setRefershID");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_setRefershID'", nullptr);
            return 0;
        }
        cobj->setRefershID(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:setRefershID",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_setRefershID'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_AddBoundingBox(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_AddBoundingBox'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 3) 
    {
        double arg0;
        double arg1;
        double arg2;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.Fish:AddBoundingBox");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.Fish:AddBoundingBox");

        ok &= luaval_to_number(tolua_S, 4,&arg2, "fishgame.Fish:AddBoundingBox");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_AddBoundingBox'", nullptr);
            return 0;
        }
        cobj->AddBoundingBox(arg0, arg1, arg2);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:AddBoundingBox",argc, 3);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_AddBoundingBox'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_SetPosition(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_SetPosition'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        double arg0;
        double arg1;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.Fish:SetPosition");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.Fish:SetPosition");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_SetPosition'", nullptr);
            return 0;
        }
        cobj->SetPosition(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:SetPosition",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_SetPosition'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_GetPosition(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Fish* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Fish*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Fish_GetPosition'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Fish_GetPosition'", nullptr);
            return 0;
        }
        cocos2d::Point ret = cobj->GetPosition();
        point_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Fish:GetPosition",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_GetPosition'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Fish_Create(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"fishgame.Fish",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        fishgame::Fish* ret = fishgame::Fish::Create();
        object_to_luaval<fishgame::Fish>(tolua_S, "fishgame.Fish",(fishgame::Fish*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "fishgame.Fish:Create",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Fish_Create'.",&tolua_err);
#endif
    return 0;
}
static int lua_fishgame_Fish_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (Fish)");
    return 0;
}

int lua_register_fishgame_Fish(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.Fish");
    tolua_cclass(tolua_S,"Fish","fishgame.Fish","fishgame.MyObject",nullptr);

    tolua_beginmodule(tolua_S,"Fish");
        tolua_function(tolua_S,"SetParticle",lua_fishgame_Fish_SetParticle);
        tolua_function(tolua_S,"SetDirection",lua_fishgame_Fish_SetDirection);
        tolua_function(tolua_S,"getRefershID",lua_fishgame_Fish_getRefershID);
        tolua_function(tolua_S,"GetMaxRadio",lua_fishgame_Fish_GetMaxRadio);
        tolua_function(tolua_S,"SetMoveCompent",lua_fishgame_Fish_SetMoveCompent);
        tolua_function(tolua_S,"OnHit",lua_fishgame_Fish_OnHit);
        tolua_function(tolua_S,"OnUpdate",lua_fishgame_Fish_OnUpdate);
        tolua_function(tolua_S,"GetParticle",lua_fishgame_Fish_GetParticle);
        tolua_function(tolua_S,"GetDirection",lua_fishgame_Fish_GetDirection);
        tolua_function(tolua_S,"setRefershID",lua_fishgame_Fish_setRefershID);
        tolua_function(tolua_S,"AddBoundingBox",lua_fishgame_Fish_AddBoundingBox);
        tolua_function(tolua_S,"SetPosition",lua_fishgame_Fish_SetPosition);
        tolua_function(tolua_S,"GetPosition",lua_fishgame_Fish_GetPosition);
        tolua_function(tolua_S,"Create", lua_fishgame_Fish_Create);
        tolua_function(tolua_S,"RegisterHitFishHandler",lua_fishgame_Fish_RegisterHitFishHandler);
        tolua_function(tolua_S,"SetHitFishColor",lua_fishgame_Fish_SetHitFishColor);
        tolua_function(tolua_S,"GetHitFishColor",lua_fishgame_Fish_GetHitFishColor);
        tolua_function(tolua_S,"SetNormalFishColor",lua_fishgame_Fish_SetNormalFishColor);
        tolua_function(tolua_S,"SetSpecialFishColor",lua_fishgame_Fish_SetSpecialFishColor);
        tolua_function(tolua_S,"GetSpecialFishColor",lua_fishgame_Fish_GetSpecialFishColor);
        tolua_function(tolua_S,"GetNormalFishColor",lua_fishgame_Fish_GetNormalFishColor);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::Fish).name();
    g_luaType[typeName] = "fishgame.Fish";
    g_typeCast["Fish"] = "fishgame.Fish";
    return 1;
}

int lua_fishgame_Bullet_SetCannonData(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_SetCannonData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_SetCannonData'", nullptr);
            return 0;
        }
        cobj->SetCannonData();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:SetCannonData",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_SetCannonData'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_SetMoveCompent(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_SetMoveCompent'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::MoveCompent* arg0;

        ok &= luaval_to_object<fishgame::MoveCompent>(tolua_S, 2, "fishgame.MoveCompent",&arg0, "fishgame.Bullet:SetMoveCompent");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_SetMoveCompent'", nullptr);
            return 0;
        }
        cobj->SetMoveCompent(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:SetMoveCompent",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_SetMoveCompent'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_SetCatchRadio(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_SetCatchRadio'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.Bullet:SetCatchRadio");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_SetCatchRadio'", nullptr);
            return 0;
        }
        cobj->SetCatchRadio(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:SetCatchRadio",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_SetCatchRadio'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_GetCannonSetType(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_GetCannonSetType'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_GetCannonSetType'", nullptr);
            return 0;
        }
        int ret = cobj->GetCannonSetType();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:GetCannonSetType",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_GetCannonSetType'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_GetCannonData(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_GetCannonData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_GetCannonData'", nullptr);
            return 0;
        }
        cobj->GetCannonData();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:GetCannonData",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_GetCannonData'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_GetCatchRadio(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_GetCatchRadio'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_GetCatchRadio'", nullptr);
            return 0;
        }
        int ret = cobj->GetCatchRadio();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:GetCatchRadio",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_GetCatchRadio'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_OnUpdate(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_OnUpdate'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.Bullet:OnUpdate");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_OnUpdate'", nullptr);
            return 0;
        }
        cobj->OnUpdate(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:OnUpdate",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_OnUpdate'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_SetCannonSetType(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_SetCannonSetType'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.Bullet:SetCannonSetType");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_SetCannonSetType'", nullptr);
            return 0;
        }
        cobj->SetCannonSetType(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:SetCannonSetType",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_SetCannonSetType'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_GetCannonType(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_GetCannonType'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_GetCannonType'", nullptr);
            return 0;
        }
        int ret = cobj->GetCannonType();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:GetCannonType",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_GetCannonType'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_SetCannonType(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_SetCannonType'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.Bullet:SetCannonType");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_SetCannonType'", nullptr);
            return 0;
        }
        cobj->SetCannonType(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:SetCannonType",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_SetCannonType'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_SetState(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::Bullet* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::Bullet*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_Bullet_SetState'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.Bullet:SetState");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_Bullet_SetState'", nullptr);
            return 0;
        }
        cobj->SetState((fishgame::ObjState)arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.Bullet:SetState",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_SetState'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_Bullet_Create(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"fishgame.Bullet",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        fishgame::Bullet* ret = fishgame::Bullet::Create();
        object_to_luaval<fishgame::Bullet>(tolua_S, "fishgame.Bullet",(fishgame::Bullet*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "fishgame.Bullet:Create",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_Bullet_Create'.",&tolua_err);
#endif
    return 0;
}
static int lua_fishgame_Bullet_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (Bullet)");
    return 0;
}

int lua_register_fishgame_Bullet(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.Bullet");
    tolua_cclass(tolua_S,"Bullet","fishgame.Bullet","fishgame.MyObject",nullptr);

    tolua_beginmodule(tolua_S,"Bullet");
        tolua_function(tolua_S,"SetCannonData",lua_fishgame_Bullet_SetCannonData);
        tolua_function(tolua_S,"SetMoveCompent",lua_fishgame_Bullet_SetMoveCompent);
        tolua_function(tolua_S,"SetCatchRadio",lua_fishgame_Bullet_SetCatchRadio);
        tolua_function(tolua_S,"GetCannonSetType",lua_fishgame_Bullet_GetCannonSetType);
        tolua_function(tolua_S,"GetCannonData",lua_fishgame_Bullet_GetCannonData);
        tolua_function(tolua_S,"GetCatchRadio",lua_fishgame_Bullet_GetCatchRadio);
        tolua_function(tolua_S,"OnUpdate",lua_fishgame_Bullet_OnUpdate);
        tolua_function(tolua_S,"SetCannonSetType",lua_fishgame_Bullet_SetCannonSetType);
        tolua_function(tolua_S,"GetCannonType",lua_fishgame_Bullet_GetCannonType);
        tolua_function(tolua_S,"SetCannonType",lua_fishgame_Bullet_SetCannonType);
        tolua_function(tolua_S,"SetState",lua_fishgame_Bullet_SetState);
        tolua_function(tolua_S,"Create", lua_fishgame_Bullet_Create);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::Bullet).name();
    g_luaType[typeName] = "fishgame.Bullet";
    g_typeCast["Bullet"] = "fishgame.Bullet";
    return 1;
}

int lua_fishgame_FishObjectManager_FindFish(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_FindFish'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        unsigned long arg0;

        ok &= luaval_to_ulong(tolua_S, 2, &arg0, "fishgame.FishObjectManager:FindFish");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_FindFish'", nullptr);
            return 0;
        }
        fishgame::Fish* ret = cobj->FindFish(arg0);
        object_to_luaval<fishgame::Fish>(tolua_S, "fishgame.Fish",(fishgame::Fish*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:FindFish",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_FindFish'.",&tolua_err);
#endif

    return 0;
}

int lua_fishgame_FishObjectManager_FindLockFish(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_FindLockFish'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        unsigned long arg0;
        
        ok &= luaval_to_ulong(tolua_S, 2, &arg0, "fishgame.FishObjectManager:FindLockFish");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_FindLockFish'", nullptr);
            return 0;
        }
        fishgame::Fish* ret = cobj->FindLockFish(arg0);
        object_to_luaval<fishgame::Fish>(tolua_S, "fishgame.Fish",(fishgame::Fish*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:FindLockFish",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_FindLockFish'.",&tolua_err);
#endif
    
    return 0;
}


int lua_fishgame_FishObjectManager_ConvertCoortToScreenSize(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_ConvertCoortToScreenSize'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        float* arg0;
        float* arg1;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_ConvertCoortToScreenSize'", nullptr);
            return 0;
        }
        cobj->ConvertCoortToScreenSize(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:ConvertCoortToScreenSize",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_ConvertCoortToScreenSize'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_Init(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_Init'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 4) 
    {
        double arg0;
        double arg1;
        double arg2;
        double arg3;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.FishObjectManager:Init");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.FishObjectManager:Init");

        ok &= luaval_to_number(tolua_S, 4,&arg2, "fishgame.FishObjectManager:Init");

        ok &= luaval_to_number(tolua_S, 5,&arg3, "fishgame.FishObjectManager:Init");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_Init'", nullptr);
            return 0;
        }
        cobj->Init(arg0, arg1, arg2, arg3);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:Init",argc, 4);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_Init'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_IsSwitchingScene(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_IsSwitchingScene'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_IsSwitchingScene'", nullptr);
            return 0;
        }
        bool ret = cobj->IsSwitchingScene();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:IsSwitchingScene",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_IsSwitchingScene'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_GetIsUpdateCacheForFish(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_GetIsUpdateCacheForFish'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_GetIsUpdateCacheForFish'", nullptr);
            return 0;
        }
        bool ret = cobj->GetIsUpdateCacheForFish();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:GetIsUpdateCacheForFish",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_GetIsUpdateCacheForFish'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_FishObjectManager_GetIsUpdateCacheForBullet(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_GetIsUpdateCacheForBullet'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_GetIsUpdateCacheForBullet'", nullptr);
            return 0;
        }
        bool ret = cobj->GetIsUpdateCacheForBullet();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:GetIsUpdateCacheForBullet",argc, 0);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_GetIsUpdateCacheForBullet'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_FishObjectManager_GetServerWidth(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_GetServerWidth'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_GetServerWidth'", nullptr);
            return 0;
        }
        int ret = cobj->GetServerWidth();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:GetServerWidth",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_GetServerWidth'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_MirrowShow(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_MirrowShow'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_MirrowShow'", nullptr);
            return 0;
        }
        bool ret = cobj->MirrowShow();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:MirrowShow",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_MirrowShow'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_FindBullet(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_FindBullet'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        unsigned long arg0;

        ok &= luaval_to_ulong(tolua_S, 2, &arg0, "fishgame.FishObjectManager:FindBullet");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_FindBullet'", nullptr);
            return 0;
        }
        fishgame::Bullet* ret = cobj->FindBullet(arg0);
        object_to_luaval<fishgame::Bullet>(tolua_S, "fishgame.Bullet",(fishgame::Bullet*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:FindBullet",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_FindBullet'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_SetGameLoaded(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_SetGameLoaded'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.FishObjectManager:SetGameLoaded");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_SetGameLoaded'", nullptr);
            return 0;
        }
        cobj->SetGameLoaded(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:SetGameLoaded",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_SetGameLoaded'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_AddFishBuff(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_AddFishBuff'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 3) 
    {
        int arg0;
        double arg1;
        double arg2;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.FishObjectManager:AddFishBuff");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.FishObjectManager:AddFishBuff");

        ok &= luaval_to_number(tolua_S, 4,&arg2, "fishgame.FishObjectManager:AddFishBuff");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_AddFishBuff'", nullptr);
            return 0;
        }
        cobj->AddFishBuff(arg0, arg1, arg2);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:AddFishBuff",argc, 3);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_AddFishBuff'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_RemoveAllBullets(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_RemoveAllBullets'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.FishObjectManager:RemoveAllBullets");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_RemoveAllBullets'", nullptr);
            return 0;
        }
        bool ret = cobj->RemoveAllBullets(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:RemoveAllBullets",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_RemoveAllBullets'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_RegisterBulletHitFishHandler(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S, 1, "fishgame.FishObjectManager", 0, &tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S, 1, 0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S, "invalid 'cobj' in function 'tolua_fishgame_FishObjectManager_RegisterBulletHitFishHandler'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S) - 1;
    if (argc == 1)
    {
        int handler = toluafix_ref_function(tolua_S, 2, 0);
        cobj->RegisterBulletHitFishHandler(handler);
        return 0;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:RegisterBulletHitFishHandler", argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S, "#ferror in function 'tolua_fishgame_FishObjectManager_RegisterBulletHitFishHandler'.", &tolua_err);
#endif
    
    return 0;
}
/////////////
int lua_fishgame_FishObjectManager_RegisterCanClickShotHandler(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S, 1, "fishgame.FishObjectManager", 0, &tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S, 1, 0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S, "invalid 'cobj' in function 'tolua_fishgame_FishObjectManager_RegisterCanClickShotHandler'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S) - 1;
    if (argc == 1)
    {
        int handler = toluafix_ref_function(tolua_S, 2, 0);
        cobj->RegisterCanClickShotHandler(handler);
        return 0;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:RegisterCanClickShotHandler", argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S, "#ferror in function 'tolua_fishgame_FishObjectManager_RegisterCanClickShotHandler'.", &tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_FishObjectManager_SetSwitchingScene(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_SetSwitchingScene'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.FishObjectManager:SetSwitchingScene");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_SetSwitchingScene'", nullptr);
            return 0;
        }
        cobj->SetSwitchingScene(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:SetSwitchingScene",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_SetSwitchingScene'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_SetIsUpdateCacheForFish(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_SetIsUpdateCacheForFish'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        bool arg0;
        
        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.FishObjectManager:SetIsUpdateCacheForFish");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_SetIsUpdateCacheForFish'", nullptr);
            return 0;
        }
        cobj->SetIsUpdateCacheForFish(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:SetIsUpdateCacheForFish",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_SetIsUpdateCacheForFish'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_FishObjectManager_SetIsUpdateCacheForBullet(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;
    
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif
    
    
#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif
    
    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);
    
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_SetIsUpdateCacheForBullet'", nullptr);
        return 0;
    }
#endif
    
    argc = lua_gettop(tolua_S)-1;
    if (argc == 1)
    {
        bool arg0;
        
        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.FishObjectManager:SetIsUpdateCacheForBullet");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_SetIsUpdateCacheForBullet'", nullptr);
            return 0;
        }
        cobj->SetIsUpdateCacheForBullet(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:SetIsUpdateCacheForBullet",argc, 1);
    return 0;
    
#if COCOS2D_DEBUG >= 1
tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_SetIsUpdateCacheForBullet'.",&tolua_err);
#endif
    
    return 0;
}
int lua_fishgame_FishObjectManager_Clear(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_Clear'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_Clear'", nullptr);
            return 0;
        }
        cobj->Clear();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:Clear",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_Clear'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_IsGameLoaded(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_IsGameLoaded'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_IsGameLoaded'", nullptr);
            return 0;
        }
        bool ret = cobj->IsGameLoaded();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:IsGameLoaded",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_IsGameLoaded'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_RemoveAllFishes(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_RemoveAllFishes'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.FishObjectManager:RemoveAllFishes");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_RemoveAllFishes'", nullptr);
            return 0;
        }
        bool ret = cobj->RemoveAllFishes(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:RemoveAllFishes",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_RemoveAllFishes'.",&tolua_err);
#endif

    return 0;
}

int lua_fishgame_FishObjectManager_AddFish(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_AddFish'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::Fish* arg0;

        ok &= luaval_to_object<fishgame::Fish>(tolua_S, 2, "fishgame.Fish",&arg0, "fishgame.FishObjectManager:AddFish");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_AddFish'", nullptr);
            return 0;
        }
        bool ret = cobj->AddFish(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:AddFish",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_AddFish'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_SetFishGameLayer(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_SetFishGameLayer'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::FishLayer* arg0;

        ok &= luaval_to_object<fishgame::FishLayer>(tolua_S, 2, "fishgame.FishLayer",&arg0, "fishgame.FishObjectManager:SetFishGameLayer");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_SetFishGameLayer'", nullptr);
            return 0;
        }
        cobj->SetFishGameLayer(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:SetFishGameLayer",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_SetFishGameLayer'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_ConvertCoord(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_ConvertCoord'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        float* arg0;
        float* arg1;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_ConvertCoord'", nullptr);
            return 0;
        }
        cobj->ConvertCoord(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:ConvertCoord",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_ConvertCoord'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_GetAllFishes(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_GetAllFishes'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_GetAllFishes'", nullptr);
            return 0;
        }
		
		cocos2d::Vector<fishgame::Fish *> ret;
		cobj->GetAllFishes(ret);
        ccvector_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:GetAllFishes",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_GetAllFishes'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_AddBullet(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_AddBullet'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::Bullet* arg0;

        ok &= luaval_to_object<fishgame::Bullet>(tolua_S, 2, "fishgame.Bullet",&arg0, "fishgame.FishObjectManager:AddBullet");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_AddBullet'", nullptr);
            return 0;
        }
        bool ret = cobj->AddBullet(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:AddBullet",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_AddBullet'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_GetServerHeight(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_GetServerHeight'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_GetServerHeight'", nullptr);
            return 0;
        }
        int ret = cobj->GetServerHeight();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:GetServerHeight",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_GetServerHeight'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_OnUpdate(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_OnUpdate'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.FishObjectManager:OnUpdate");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_OnUpdate'", nullptr);
            return 0;
        }
        bool ret = cobj->OnUpdate(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:OnUpdate",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_OnUpdate'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_ConvertCoortToCleientPosition(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_ConvertCoortToCleientPosition'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        float* arg0;
        float* arg1;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_ConvertCoortToCleientPosition'", nullptr);
            return 0;
        }
        cobj->ConvertCoortToCleientPosition(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:ConvertCoortToCleientPosition",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_ConvertCoortToCleientPosition'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_ConvertDirection(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_ConvertDirection'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.FishObjectManager:ConvertDirection");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_ConvertDirection'", nullptr);
            return 0;
        }
        double ret = cobj->ConvertDirection(arg0);
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:ConvertDirection",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_ConvertDirection'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_SetMirrowShow(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_SetMirrowShow'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.FishObjectManager:SetMirrowShow");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_SetMirrowShow'", nullptr);
            return 0;
        }
        cobj->SetMirrowShow(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:SetMirrowShow",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_SetMirrowShow'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_ConvertMirrorCoord(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::FishObjectManager* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::FishObjectManager*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_FishObjectManager_ConvertMirrorCoord'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        float* arg0;
        float* arg1;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;

        #pragma warning NO CONVERSION TO NATIVE FOR float*
		ok = false;
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_ConvertMirrorCoord'", nullptr);
            return 0;
        }
        cobj->ConvertMirrorCoord(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.FishObjectManager:ConvertMirrorCoord",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_ConvertMirrorCoord'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_FishObjectManager_DestoryInstace(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_DestoryInstace'", nullptr);
            return 0;
        }
        fishgame::FishObjectManager::DestoryInstace();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "fishgame.FishObjectManager:DestoryInstace",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_DestoryInstace'.",&tolua_err);
#endif
    return 0;
}
int lua_fishgame_FishObjectManager_GetInstance(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"fishgame.FishObjectManager",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_FishObjectManager_GetInstance'", nullptr);
            return 0;
        }
        fishgame::FishObjectManager* ret = fishgame::FishObjectManager::GetInstance();
        object_to_luaval<fishgame::FishObjectManager>(tolua_S, "fishgame.FishObjectManager",(fishgame::FishObjectManager*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "fishgame.FishObjectManager:GetInstance",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_FishObjectManager_GetInstance'.",&tolua_err);
#endif
    return 0;
}
static int lua_fishgame_FishObjectManager_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (FishObjectManager)");
    return 0;
}

int lua_register_fishgame_FishObjectManager(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.FishObjectManager");
    tolua_cclass(tolua_S,"FishObjectManager","fishgame.FishObjectManager","cc.Ref",nullptr);

    tolua_beginmodule(tolua_S,"FishObjectManager");
        tolua_function(tolua_S,"FindFish",lua_fishgame_FishObjectManager_FindFish);
        tolua_function(tolua_S,"FindLockFish",lua_fishgame_FishObjectManager_FindLockFish);
        tolua_function(tolua_S,"ConvertCoortToScreenSize",lua_fishgame_FishObjectManager_ConvertCoortToScreenSize);
        tolua_function(tolua_S,"Init",lua_fishgame_FishObjectManager_Init);
        tolua_function(tolua_S,"IsSwitchingScene",lua_fishgame_FishObjectManager_IsSwitchingScene);
        tolua_function(tolua_S,"SetIsUpdateCacheForFish",lua_fishgame_FishObjectManager_SetIsUpdateCacheForFish);
        tolua_function(tolua_S,"GetIsUpdateCacheForFish",lua_fishgame_FishObjectManager_GetIsUpdateCacheForFish);
        tolua_function(tolua_S,"SetIsUpdateCacheForBullet",lua_fishgame_FishObjectManager_SetIsUpdateCacheForBullet);
        tolua_function(tolua_S,"GetIsUpdateCacheForBullet",lua_fishgame_FishObjectManager_GetIsUpdateCacheForBullet);
        tolua_function(tolua_S,"GetServerWidth",lua_fishgame_FishObjectManager_GetServerWidth);
        tolua_function(tolua_S,"MirrowShow",lua_fishgame_FishObjectManager_MirrowShow);
        tolua_function(tolua_S,"FindBullet",lua_fishgame_FishObjectManager_FindBullet);
        tolua_function(tolua_S,"SetGameLoaded",lua_fishgame_FishObjectManager_SetGameLoaded);
        tolua_function(tolua_S,"AddFishBuff",lua_fishgame_FishObjectManager_AddFishBuff);
        tolua_function(tolua_S,"RemoveAllBullets",lua_fishgame_FishObjectManager_RemoveAllBullets);
        tolua_function(tolua_S,"RegisterBulletHitFishHandler",lua_fishgame_FishObjectManager_RegisterBulletHitFishHandler);
        tolua_function(tolua_S,"RegisterCanClickShotHandler",lua_fishgame_FishObjectManager_RegisterCanClickShotHandler);
        tolua_function(tolua_S,"SetSwitchingScene",lua_fishgame_FishObjectManager_SetSwitchingScene);
        tolua_function(tolua_S,"Clear",lua_fishgame_FishObjectManager_Clear);
        tolua_function(tolua_S,"IsGameLoaded",lua_fishgame_FishObjectManager_IsGameLoaded);
        tolua_function(tolua_S,"RemoveAllFishes",lua_fishgame_FishObjectManager_RemoveAllFishes);
        tolua_function(tolua_S,"AddFish",lua_fishgame_FishObjectManager_AddFish);
        tolua_function(tolua_S,"SetFishGameLayer",lua_fishgame_FishObjectManager_SetFishGameLayer);
        tolua_function(tolua_S,"ConvertCoord",lua_fishgame_FishObjectManager_ConvertCoord);
        tolua_function(tolua_S,"GetAllFishes",lua_fishgame_FishObjectManager_GetAllFishes);
        tolua_function(tolua_S,"AddBullet",lua_fishgame_FishObjectManager_AddBullet);
        tolua_function(tolua_S,"GetServerHeight",lua_fishgame_FishObjectManager_GetServerHeight);
        tolua_function(tolua_S,"OnUpdate",lua_fishgame_FishObjectManager_OnUpdate);
        tolua_function(tolua_S,"ConvertCoortToCleientPosition",lua_fishgame_FishObjectManager_ConvertCoortToCleientPosition);
        tolua_function(tolua_S,"ConvertDirection",lua_fishgame_FishObjectManager_ConvertDirection);
        tolua_function(tolua_S,"SetMirrowShow",lua_fishgame_FishObjectManager_SetMirrowShow);
        tolua_function(tolua_S,"ConvertMirrorCoord",lua_fishgame_FishObjectManager_ConvertMirrorCoord);
        tolua_function(tolua_S,"DestoryInstace", lua_fishgame_FishObjectManager_DestoryInstace);
        tolua_function(tolua_S,"GetInstance", lua_fishgame_FishObjectManager_GetInstance);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::FishObjectManager).name();
    g_luaType[typeName] = "fishgame.FishObjectManager";
    g_typeCast["FishObjectManager"] = "fishgame.FishObjectManager";
    return 1;
}

int lua_fishgame_MoveCompent_GetOffest(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_GetOffest'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_GetOffest'", nullptr);
            return 0;
        }
        const cocos2d::Point& ret = cobj->GetOffest();
        point_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:GetOffest",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_GetOffest'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_GetDelay(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_GetDelay'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_GetDelay'", nullptr);
            return 0;
        }
        double ret = cobj->GetDelay();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:GetDelay",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_GetDelay'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_bTroop(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_bTroop'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_bTroop'", nullptr);
            return 0;
        }
        bool ret = cobj->bTroop();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:bTroop",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_bTroop'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_GetSpeed(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_GetSpeed'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_GetSpeed'", nullptr);
            return 0;
        }
        double ret = cobj->GetSpeed();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:GetSpeed",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_GetSpeed'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetSpeed(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetSpeed'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveCompent:SetSpeed");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetSpeed'", nullptr);
            return 0;
        }
        cobj->SetSpeed(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetSpeed",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetSpeed'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetOwner(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetOwner'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        fishgame::MyObject* arg0;

        ok &= luaval_to_object<fishgame::MyObject>(tolua_S, 2, "fishgame.MyObject",&arg0, "fishgame.MoveCompent:SetOwner");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetOwner'", nullptr);
            return 0;
        }
        cobj->SetOwner(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetOwner",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetOwner'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_IsPaused(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_IsPaused'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_IsPaused'", nullptr);
            return 0;
        }
        bool ret = cobj->IsPaused();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:IsPaused",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_IsPaused'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetPathID(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetPathID'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.MoveCompent:SetPathID");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetPathID'", nullptr);
            return 0;
        }
        cobj->SetPathID(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 2) 
    {
        int arg0;
        bool arg1;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.MoveCompent:SetPathID");

        ok &= luaval_to_boolean(tolua_S, 3,&arg1, "fishgame.MoveCompent:SetPathID");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetPathID'", nullptr);
            return 0;
        }
        cobj->SetPathID(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetPathID",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetPathID'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_HasBeginMove(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_HasBeginMove'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_HasBeginMove'", nullptr);
            return 0;
        }
        bool ret = cobj->HasBeginMove();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:HasBeginMove",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_HasBeginMove'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_OnUpdate(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_OnUpdate'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveCompent:OnUpdate");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_OnUpdate'", nullptr);
            return 0;
        }
        cobj->OnUpdate(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:OnUpdate",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_OnUpdate'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_IsEndPath(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_IsEndPath'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_IsEndPath'", nullptr);
            return 0;
        }
        bool ret = cobj->IsEndPath();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:IsEndPath",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_IsEndPath'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_Rebound(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_Rebound'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_Rebound'", nullptr);
            return 0;
        }
        bool ret = cobj->Rebound();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:Rebound",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_Rebound'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetDirection(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetDirection'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveCompent:SetDirection");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetDirection'", nullptr);
            return 0;
        }
        cobj->SetDirection(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetDirection",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetDirection'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetPause(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetPause'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetPause'", nullptr);
            return 0;
        }
        cobj->SetPause();
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.MoveCompent:SetPause");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetPause'", nullptr);
            return 0;
        }
        cobj->SetPause(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetPause",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetPause'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_OnDetach(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_OnDetach'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_OnDetach'", nullptr);
            return 0;
        }
        cobj->OnDetach();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:OnDetach",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_OnDetach'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetPathMoveData(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetPathMoveData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 12) 
    {
        int arg0;
        double arg1;
        double arg2;
        double arg3;
        double arg4;
        double arg5;
        double arg6;
        double arg7;
        double arg8;
        int arg9;
        double arg10;
        int arg11;

        ok &= luaval_to_int32(tolua_S, 2,(int *)&arg0, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 4,&arg2, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 5,&arg3, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 6,&arg4, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 7,&arg5, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 8,&arg6, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 9,&arg7, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 10,&arg8, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_int32(tolua_S, 11,(int *)&arg9, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_number(tolua_S, 12,&arg10, "fishgame.MoveCompent:SetPathMoveData");

        ok &= luaval_to_int32(tolua_S, 13,(int *)&arg11, "fishgame.MoveCompent:SetPathMoveData");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetPathMoveData'", nullptr);
            return 0;
        }
        cobj->SetPathMoveData(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetPathMoveData",argc, 12);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetPathMoveData'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_GetPathID(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_GetPathID'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_GetPathID'", nullptr);
            return 0;
        }
        int ret = cobj->GetPathID();
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:GetPathID",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_GetPathID'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetDelay(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetDelay'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveCompent:SetDelay");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetDelay'", nullptr);
            return 0;
        }
        cobj->SetDelay(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetDelay",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetDelay'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetRebound(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetRebound'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.MoveCompent:SetRebound");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetRebound'", nullptr);
            return 0;
        }
        cobj->SetRebound(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetRebound",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetRebound'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_updateWinSize(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_updateWinSize'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        double arg0;
        double arg1;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveCompent:updateWinSize");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.MoveCompent:updateWinSize");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_updateWinSize'", nullptr);
            return 0;
        }
        cobj->updateWinSize(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:updateWinSize",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_updateWinSize'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_GetOwner(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_GetOwner'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_GetOwner'", nullptr);
            return 0;
        }
        fishgame::MyObject* ret = cobj->GetOwner();
        object_to_luaval<fishgame::MyObject>(tolua_S, "fishgame.MyObject",(fishgame::MyObject*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:GetOwner",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_GetOwner'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_InitMove(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_InitMove'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_InitMove'", nullptr);
            return 0;
        }
        cobj->InitMove();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:InitMove",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_InitMove'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_OnAttach(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_OnAttach'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_OnAttach'", nullptr);
            return 0;
        }
        cobj->OnAttach();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:OnAttach",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_OnAttach'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetOffest(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetOffest'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        cocos2d::Point arg0;

        ok &= luaval_to_point(tolua_S, 2, &arg0, "fishgame.MoveCompent:SetOffest");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetOffest'", nullptr);
            return 0;
        }
        cobj->SetOffest(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetOffest",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetOffest'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetEndPath(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetEndPath'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "fishgame.MoveCompent:SetEndPath");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetEndPath'", nullptr);
            return 0;
        }
        cobj->SetEndPath(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetEndPath",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetEndPath'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveCompent_SetPosition(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveCompent* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveCompent",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveCompent*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveCompent_SetPosition'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        double arg0;
        double arg1;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveCompent:SetPosition");

        ok &= luaval_to_number(tolua_S, 3,&arg1, "fishgame.MoveCompent:SetPosition");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveCompent_SetPosition'", nullptr);
            return 0;
        }
        cobj->SetPosition(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveCompent:SetPosition",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveCompent_SetPosition'.",&tolua_err);
#endif

    return 0;
}
static int lua_fishgame_MoveCompent_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (MoveCompent)");
    return 0;
}

int lua_register_fishgame_MoveCompent(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.MoveCompent");
    tolua_cclass(tolua_S,"MoveCompent","fishgame.MoveCompent","cc.Ref",nullptr);

    tolua_beginmodule(tolua_S,"MoveCompent");
        tolua_function(tolua_S,"GetOffest",lua_fishgame_MoveCompent_GetOffest);
        tolua_function(tolua_S,"GetDelay",lua_fishgame_MoveCompent_GetDelay);
        tolua_function(tolua_S,"bTroop",lua_fishgame_MoveCompent_bTroop);
        tolua_function(tolua_S,"GetSpeed",lua_fishgame_MoveCompent_GetSpeed);
        tolua_function(tolua_S,"SetSpeed",lua_fishgame_MoveCompent_SetSpeed);
        tolua_function(tolua_S,"SetOwner",lua_fishgame_MoveCompent_SetOwner);
        tolua_function(tolua_S,"IsPaused",lua_fishgame_MoveCompent_IsPaused);
        tolua_function(tolua_S,"SetPathID",lua_fishgame_MoveCompent_SetPathID);
        tolua_function(tolua_S,"HasBeginMove",lua_fishgame_MoveCompent_HasBeginMove);
        tolua_function(tolua_S,"OnUpdate",lua_fishgame_MoveCompent_OnUpdate);
        tolua_function(tolua_S,"IsEndPath",lua_fishgame_MoveCompent_IsEndPath);
        tolua_function(tolua_S,"Rebound",lua_fishgame_MoveCompent_Rebound);
        tolua_function(tolua_S,"SetDirection",lua_fishgame_MoveCompent_SetDirection);
        tolua_function(tolua_S,"SetPause",lua_fishgame_MoveCompent_SetPause);
        tolua_function(tolua_S,"OnDetach",lua_fishgame_MoveCompent_OnDetach);
        tolua_function(tolua_S,"SetPathMoveData",lua_fishgame_MoveCompent_SetPathMoveData);
        tolua_function(tolua_S,"GetPathID",lua_fishgame_MoveCompent_GetPathID);
        tolua_function(tolua_S,"SetDelay",lua_fishgame_MoveCompent_SetDelay);
        tolua_function(tolua_S,"SetRebound",lua_fishgame_MoveCompent_SetRebound);
        tolua_function(tolua_S,"updateWinSize",lua_fishgame_MoveCompent_updateWinSize);
        tolua_function(tolua_S,"GetOwner",lua_fishgame_MoveCompent_GetOwner);
        tolua_function(tolua_S,"InitMove",lua_fishgame_MoveCompent_InitMove);
        tolua_function(tolua_S,"OnAttach",lua_fishgame_MoveCompent_OnAttach);
        tolua_function(tolua_S,"SetOffest",lua_fishgame_MoveCompent_SetOffest);
        tolua_function(tolua_S,"SetEndPath",lua_fishgame_MoveCompent_SetEndPath);
        tolua_function(tolua_S,"SetPosition",lua_fishgame_MoveCompent_SetPosition);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::MoveCompent).name();
    g_luaType[typeName] = "fishgame.MoveCompent";
    g_typeCast["MoveCompent"] = "fishgame.MoveCompent";
    return 1;
}

int lua_fishgame_MoveByPath_OnUpdate(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveByPath* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveByPath",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveByPath*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveByPath_OnUpdate'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveByPath:OnUpdate");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByPath_OnUpdate'", nullptr);
            return 0;
        }
        cobj->OnUpdate(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveByPath:OnUpdate",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByPath_OnUpdate'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveByPath_OnDetach(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveByPath* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveByPath",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveByPath*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveByPath_OnDetach'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByPath_OnDetach'", nullptr);
            return 0;
        }
        cobj->OnDetach();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveByPath:OnDetach",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByPath_OnDetach'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveByPath_InitMove(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveByPath* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveByPath",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveByPath*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveByPath_InitMove'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByPath_InitMove'", nullptr);
            return 0;
        }
        cobj->InitMove();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveByPath:InitMove",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByPath_InitMove'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveByPath_create(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"fishgame.MoveByPath",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByPath_create'", nullptr);
            return 0;
        }
        fishgame::MoveByPath* ret = fishgame::MoveByPath::create();
        object_to_luaval<fishgame::MoveByPath>(tolua_S, "fishgame.MoveByPath",(fishgame::MoveByPath*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "fishgame.MoveByPath:create",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByPath_create'.",&tolua_err);
#endif
    return 0;
}
static int lua_fishgame_MoveByPath_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (MoveByPath)");
    return 0;
}

int lua_register_fishgame_MoveByPath(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.MoveByPath");
    tolua_cclass(tolua_S,"MoveByPath","fishgame.MoveByPath","fishgame.MoveCompent",nullptr);

    tolua_beginmodule(tolua_S,"MoveByPath");
        tolua_function(tolua_S,"OnUpdate",lua_fishgame_MoveByPath_OnUpdate);
        tolua_function(tolua_S,"OnDetach",lua_fishgame_MoveByPath_OnDetach);
        tolua_function(tolua_S,"InitMove",lua_fishgame_MoveByPath_InitMove);
        tolua_function(tolua_S,"create", lua_fishgame_MoveByPath_create);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::MoveByPath).name();
    g_luaType[typeName] = "fishgame.MoveByPath";
    g_typeCast["MoveByPath"] = "fishgame.MoveByPath";
    return 1;
}

int lua_fishgame_MoveByDirection_OnUpdate(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveByDirection* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveByDirection",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveByDirection*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveByDirection_OnUpdate'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        double arg0;

        ok &= luaval_to_number(tolua_S, 2,&arg0, "fishgame.MoveByDirection:OnUpdate");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByDirection_OnUpdate'", nullptr);
            return 0;
        }
        cobj->OnUpdate(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveByDirection:OnUpdate",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByDirection_OnUpdate'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveByDirection_OnDetach(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveByDirection* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveByDirection",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveByDirection*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveByDirection_OnDetach'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByDirection_OnDetach'", nullptr);
            return 0;
        }
        cobj->OnDetach();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveByDirection:OnDetach",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByDirection_OnDetach'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveByDirection_InitMove(lua_State* tolua_S)
{
    int argc = 0;
    fishgame::MoveByDirection* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"fishgame.MoveByDirection",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (fishgame::MoveByDirection*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_fishgame_MoveByDirection_InitMove'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByDirection_InitMove'", nullptr);
            return 0;
        }
        cobj->InitMove();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "fishgame.MoveByDirection:InitMove",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByDirection_InitMove'.",&tolua_err);
#endif

    return 0;
}
int lua_fishgame_MoveByDirection_create(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"fishgame.MoveByDirection",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_fishgame_MoveByDirection_create'", nullptr);
            return 0;
        }
        fishgame::MoveByDirection* ret = fishgame::MoveByDirection::create();
        object_to_luaval<fishgame::MoveByDirection>(tolua_S, "fishgame.MoveByDirection",(fishgame::MoveByDirection*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "fishgame.MoveByDirection:create",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_fishgame_MoveByDirection_create'.",&tolua_err);
#endif
    return 0;
}
static int lua_fishgame_MoveByDirection_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (MoveByDirection)");
    return 0;
}

int lua_register_fishgame_MoveByDirection(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"fishgame.MoveByDirection");
    tolua_cclass(tolua_S,"MoveByDirection","fishgame.MoveByDirection","fishgame.MoveCompent",nullptr);

    tolua_beginmodule(tolua_S,"MoveByDirection");
        tolua_function(tolua_S,"OnUpdate",lua_fishgame_MoveByDirection_OnUpdate);
        tolua_function(tolua_S,"OnDetach",lua_fishgame_MoveByDirection_OnDetach);
        tolua_function(tolua_S,"InitMove",lua_fishgame_MoveByDirection_InitMove);
        tolua_function(tolua_S,"create", lua_fishgame_MoveByDirection_create);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(fishgame::MoveByDirection).name();
    g_luaType[typeName] = "fishgame.MoveByDirection";
    g_typeCast["MoveByDirection"] = "fishgame.MoveByDirection";
    return 1;
}
TOLUA_API int register_all_fishgame(lua_State* tolua_S)
{
    lua_getglobal(tolua_S, "_G");
    if (lua_istable(tolua_S,-1))//stack:...,_G,
    {
        tolua_open(tolua_S);
        
        tolua_module(tolua_S,"fishgame",0);
        tolua_beginmodule(tolua_S,"fishgame");
        
        lua_register_fishgame_FishObjectManager(tolua_S);
        lua_register_fishgame_MyObject(tolua_S);
        lua_register_fishgame_Bullet(tolua_S);
        lua_register_fishgame_MoveCompent(tolua_S);
        lua_register_fishgame_MoveByDirection(tolua_S);
        lua_register_fishgame_Fish(tolua_S);
        lua_register_fishgame_MoveByPath(tolua_S);
        lua_register_fishgame_FishLayer(tolua_S);
        
        tolua_endmodule(tolua_S);
        
    }
    lua_pop(tolua_S, 1);

	return 1;
}

