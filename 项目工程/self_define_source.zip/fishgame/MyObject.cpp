/*
  *MyObject类分离
  *2018年3月3日
  *author:xiaoxiong
 */
#include "MyObject.h"
#include "MoveCompent.h"
#include "FishObjectManager.h"
#include "Buff.h"

_NS_FISHGAME_BEGIN_
MyObject::MyObject()
	: m_nType(EOT_NONE)
	, m_nId(0)
	, m_fDirection(0.0f)
	, m_bInScreen(false)
	, m_bDirtyPos(false)
	, m_bDirtyDir(false)
	, m_bDirtyInScreen(false)
	, m_bSpecialShow(false)
	, m_nState(EOS_INIT)
	, m_bDirtyState(false)
	, m_pOwner(nullptr)
	, m_pManager(nullptr)
    , m_pFishLayer(nullptr)
	, m_pMoveCompent(nullptr)
	, m_nTargetId(0)
	, fWidth(1440)
	, fHeigth(900)
{
	m_pBuffList.clear();
}

MyObject::~MyObject() {
	auto it = m_pBuffList.begin();
	while (it != m_pBuffList.end())
	{
		if ((*it) != nullptr)
		{
			delete (*it);
		}
		m_pBuffList.erase(it);
		it = m_pBuffList.begin();
	}

	if (m_pMoveCompent != nullptr) {
		m_pMoveCompent->release();
	}
}

void MyObject::Clear(bool bForce, bool noCleanNode) {
	if (bForce) {
		for (auto v : m_pVisualNodeList) {
            if (v.target){
				//v.target->removeFromParentAndCleanup(true);
                m_pFishLayer->recycleObject(v.target);
            }
			v.target = nullptr;
		}
		m_pVisualNodeList.clear();
	}
	else {
		for (auto v : m_pVisualNodeList) {
            cocos2d::Node *target = v.target;
			if (v.target) v.target->runAction(cocos2d::Sequence::createWithTwoActions(
				cocos2d::DelayTime::create(m_nType == EOT_FISH ? 0.8 : 0.2), cocos2d::CallFuncN::create([this,target](cocos2d::Node* sender) {
				//sender->removeFromParentAndCleanup(true);
                m_pFishLayer->recycleObject(target);
			})));

			v.target = nullptr;
		}
		m_pVisualNodeList.clear();
	}

	OnClear(bForce);
}

void MyObject::OnClear(bool) {}

void MyObject::OnUpdate(float dt) {
	if (m_pMoveCompent != nullptr) {
		m_pMoveCompent->OnUpdate(dt);
	}

	for (auto it = m_pBuffList.begin(); it != m_pBuffList.end(); )
	{
		if ((*it) == NULL || (*it)->OnUpdate(dt) == false)
		{
			if ((*it) != NULL) delete (*it);

			it = m_pBuffList.erase(it);
		}
		else
		{
			++it;
		}
	}

	if (m_pManager != nullptr && m_bInScreen && m_bDirtyState && m_pManager->IsGameLoaded()) {
		m_bDirtyState = false;

		for (auto v : m_pVisualNodeList) {
            if (v.target) {
                //v.target->removeFromParentAndCleanup(true);
                m_pFishLayer->recycleObject(v.target);
            }
			v.target = nullptr;
		}

		m_pVisualNodeList.clear();

		//auto Layer = GetManager()->GetFishGameLayer();
		if (m_pFishLayer != NULL) {
			m_pFishLayer->AddMyObject(this, &m_pVisualNodeList);
		}

		m_bDirtyPos = true;
		m_bDirtyDir = true;
		m_bDirtyInScreen = true;
	}

	if (m_pManager != nullptr && (m_bDirtyPos || m_bDirtyDir || m_bDirtyInScreen)) {
		float x, y, dir, sinDir, cosDir;

		if (m_bDirtyPos) {
			x = m_pPosition.x;
			y = m_pPosition.y;
			m_pManager->ConvertCoord(&x, &y);

            dir = m_pManager->ConvertDirection(m_fDirection);
            sinDir = sinf(dir);//sinf(-m_fDirection);
            cosDir = cosf(dir);//cosf(-m_fDirection);
		}
		if (!m_bDirtyPos && m_bDirtyDir) {
			//dir = m_fDirection;
			dir = m_pManager->ConvertDirection(m_fDirection);
		}

		for (auto& i : m_pVisualNodeList)
		{
			if (m_bDirtyPos) {

				//if (m_pManager->MirrowShow()) {
				//	if (i.target) i.target->setPosition(-i.offsetX * cosDir + i.offsetY * sinDir + x,
				//		-i.offsetX * sinDir - i.offsetY * cosDir + y);
				//}
				//else {
					if (i.target) i.target->setPosition(i.offsetX * cosDir - i.offsetY * sinDir + x,
						i.offsetX * sinDir + i.offsetY * cosDir + y);
				//}
			}
			if (m_bDirtyDir) {
				if (i.target) i.target->setRotation(CC_RADIANS_TO_DEGREES(dir + i.direction));
			}
			if (m_bDirtyInScreen) {
				if (i.target) i.target->setVisible(m_bInScreen);
			}
		}
		m_bDirtyPos = false;
		m_bDirtyDir = false;
		m_bDirtyInScreen = false;
	}
}

void MyObject::OnMoveEnd() {
    SetState(EOS_DESTORY);
}

void MyObject::SetPosition(float x, float y) {
	if (m_pPosition.x == x && m_pPosition.y == y) {
		return;
	}
	m_pPosition.x = x;
	m_pPosition.y = y;
	m_bDirtyPos = true;

	if (x < -100 || y < -100 || x >(fWidth + 100) || y >(fHeigth + 100)) {
		if (m_bInScreen) {
			OnMoveEnd();
		}
		m_bInScreen = false;
	}
	else {
		m_bInScreen = true;
	}
}

void  MyObject::SetDirection(float dir) {
	if (m_fDirection == dir) {
		return;
	}
	m_fDirection = dir;
	m_bDirtyDir = true;
}

void MyObject::SetState(ObjState st) {
	if (st == m_nState) {
		return;
	}

	if ((st == EOS_LIVE || st == EOS_HIT)
		&& (m_nState == EOS_LIVE || m_nState == EOS_HIT)) {
		return;
	}

	m_nState = st;
	m_bDirtyState = true;
}

void MyObject::AddBuff(int buffType, float buffParam, float buffTime) {
	auto pBuff = Buff::create(buffType, buffParam, buffTime);
	if (pBuff != nullptr)
	{
		m_pBuffList.push_back(pBuff);
	}
}

void MyObject::SetMoveCompent(MoveCompent* p) {
	if (p == NULL) { return; }
	if (m_pMoveCompent != nullptr) {
		m_pMoveCompent->OnDetach();
		m_pMoveCompent->release();
	}

	m_pMoveCompent = p;
	m_pMoveCompent->retain();
	m_pMoveCompent->SetOwner(this);
	m_pMoveCompent->OnAttach();
}

void MyObject::SetTarget(int i) { m_nTargetId = i; }
int MyObject::GetTarget() {
	return m_nTargetId;
}

void MyObject::SetVisualData(int nId, int nTypeID)
{
	m_pVisualData.nID = nId;
	m_pVisualData.nTypeID = nTypeID;
}

void MyObject::AddVisualLiveData(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType)
{
	VisualImage visualTemp;
	visualTemp.Image = Image;
	visualTemp.ResPath = ResPath;
	visualTemp.Name = Name;
	visualTemp.Scale = Scale;
	visualTemp.OffestX = OffestX;
	visualTemp.OffestY = OffestY;
	visualTemp.Direction = Direction;
	visualTemp.AniType = AniType;
	m_pVisualData.ImageInfoLive.push_back(visualTemp);
}

void MyObject::AddVisualDieData(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType)
{
	VisualImage visualTemp;
	visualTemp.Image = Image;
	visualTemp.ResPath = ResPath;
	visualTemp.Name = Name;
	visualTemp.Scale = Scale;
	visualTemp.OffestX = OffestX;
	visualTemp.OffestY = OffestY;
	visualTemp.Direction = Direction;
	visualTemp.AniType = AniType;
	m_pVisualData.ImageInfoDie.push_back(visualTemp);
}

// 新增接口begin
void MyObject::AddVisualLiveDataWithZOrder(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType, int nZOrder)
{
	VisualImage visualTemp;
	visualTemp.Image = Image;
	visualTemp.ResPath = ResPath;
	visualTemp.Name = Name;
	visualTemp.Scale = Scale;
	visualTemp.OffestX = OffestX;
	visualTemp.OffestY = OffestY;
	visualTemp.Direction = Direction;
	visualTemp.AniType = AniType;
	visualTemp.nZOrder = nZOrder;
	m_pVisualData.ImageInfoLive.push_back(visualTemp);
}

void MyObject::AddVisualDieDataWithZOrder(std::string Image, std::string ResPath, std::string Name, float Scale, float OffestX, float OffestY, float Direction, int AniType, int nZOrder)
{
	VisualImage visualTemp;
	visualTemp.Image = Image;
	visualTemp.ResPath = ResPath;
	visualTemp.Name = Name;
	visualTemp.Scale = Scale;
	visualTemp.OffestX = OffestX;
	visualTemp.OffestY = OffestY;
	visualTemp.Direction = Direction;
	visualTemp.AniType = AniType;
	visualTemp.nZOrder = nZOrder;
	m_pVisualData.ImageInfoDie.push_back(visualTemp);
}

_NS_FISHGAME_END_
