#pragma once
#ifndef __FishObjectManager_h__
#define __FishObjectManager_h__

#include <set>
#include <list>
#include <map>
#include <memory>
#include <string.h>
#include "common.h"
#include "FishLayer.h"

_NS_FISHGAME_BEGIN_
    
class MyObject;
class Fish;
class Bullet;
    
class MoveCompent;
class Buff;
class Effect;
class FishObjectManager;
class FishCacheManager;
class FishObjectManager : public cocos2d::Ref
{
private:
	FishObjectManager();

	static FishObjectManager* m_Instance;
public:
	~FishObjectManager();

	static FishObjectManager* GetInstance(){
		if (m_Instance == NULL){
			m_Instance = new (std::nothrow) FishObjectManager();
			if (m_Instance){
				m_Instance->autorelease();
				m_Instance->retain();
			}
			else{
				CC_SAFE_DELETE(m_Instance);
			}
		}
		return m_Instance;
	}

	static void DestoryInstace(){
		if (m_Instance != NULL){
			m_Instance->release();
			m_Instance = NULL;
		}
	}
        
    void SetFishGameLayer(FishLayer* layer) {
        m_pFishLayer = layer;
        if(layer != nullptr)
            m_pFishLayer->setFishManager(this);
    }
    FishLayer* GetFishGameLayer() { return m_pFishLayer; }
    
	void Init(float,float,float,float);
	void Clear();
	bool AddBullet(Bullet* pBullet);
	Bullet* FindBullet(unsigned long  id);
	bool RemoveAllBullets(bool);

    bool AddFish(Fish* pFish);
    Fish* FindFish(unsigned long);
    Fish* FindLockFish(unsigned long);

	void GetAllFishes(cocos2d::Vector<Fish*> &fishVec);

	bool RemoveAllFishes(bool);
	bool OnUpdate(float dt);
	//游戏退出时调用,清理所有的鱼
	//void  removeAllFishesNew();

	void RegisterBulletHitFishHandler(int);
        
    /*
        * Modified : 手动锁定状态，点击水面开炮
        * Data     : 2017-09-18 18:00:29
        * Author   : 66
        */
    void RegisterCanClickShotHandler(int);


	void AddFishBuff(int buffType, float buffParam, float buffTime);

		
	inline bool MirrowShow()const { return m_bMorrow; };
	void SetMirrowShow(bool);

	void ConvertMirrorCoord(float*, float*);
	void ConvertCoortToCleientPosition(float*, float*);
	void ConvertCoortToScreenSize(float*, float*);

	void ConvertCoord(float*, float*);
	float ConvertDirection(float);

	void SetGameLoaded(bool b){ m_bLoaded = b; }
	bool IsGameLoaded(){ return m_bLoaded; }


	int GetServerWidth(){ return m_nServerWidth; }
	int GetServerHeight(){ return m_nServerHeight; }

	void	SetSwitchingScene(bool b){ m_bSwitchingScene = b; }
	bool	IsSwitchingScene(){ return m_bSwitchingScene; }
        
    void SetIsUpdateCacheForFish( bool b ) { m_bUpdateCacheForFish = b; }
    bool GetIsUpdateCacheForFish(){ return m_bUpdateCacheForFish; }
        
    void SetIsUpdateCacheForBullet( bool b ) { m_bUpdateCacheForBullet = b; }
    bool GetIsUpdateCacheForBullet(){ return m_bUpdateCacheForBullet; }
        
private:
	bool BBulletHitFish(Bullet* pBullet,Fish* pFish);
	void onActionBulletHitFish(Bullet* pBullet, Fish* pFish);
	void clean();
private:
    FishLayer                     *m_pFishLayer;
	FishCacheManager    *_fishCache;
	float                               m_nServerWidth;
	float                               m_nServerHeight;
	float                               m_nClientWidth;
	float                               m_nClientHeight; 
	//
	float                               _scaleX, _scaleY;

	int		m_nHandlerBulletHitFish;
    int       m_nHandlerCanClickShot;


	cocos2d::Map< unsigned long, Bullet*>	m_MapBullet;
	cocos2d::Map< unsigned long, Fish*>		m_MapFish;

	std::mutex m_lock;
	//std::mutex m_lock;

	bool m_bMorrow;
	bool m_bLoaded;
	bool m_bSwitchingScene;
        
    bool m_bUpdateCacheForFish;
    bool m_bUpdateCacheForBullet;
        
};

_NS_FISHGAME_END_

#endif // __FishObjectManager_h__
