/*
  *将子弹类的功能从FishObjectManager中剥离出来
  *不改变原来的功能
  *2018年3月3日
  *@author:xiaoxiong
 */
#include "Bullet.h"
#include "MoveCompent.h"
#include "editor-support/cocostudio/CCArmature.h"
#include "spine/SkeletonAnimation.h"
#include "FishObjectManager.h"
#include "Buff.h"
using namespace cocos2d;
using namespace cocostudio;
using namespace spine;
_NS_FISHGAME_BEGIN_

Bullet::Bullet()
	: MyObject()
	, m_nCatchRadio(30)
	, m_hitTime(0.0f)
{
	m_nType = EOT_BULLET;
}

Bullet::~Bullet() {}

void Bullet::SetCannonSetType(int n) {
	m_nCannonSetType = n;
}

int	Bullet::GetCannonSetType() { return m_nCannonSetType; }

void Bullet::SetCannonType(int n) {
	m_nCannonType = n;
}

int	Bullet::GetCannonType() { return m_nCannonType; }

void Bullet::SetCatchRadio(int n) { m_nCatchRadio = n; }

int	Bullet::GetCatchRadio() { return m_nCatchRadio; }

void Bullet::SetState(ObjState st) {
	MyObject::SetState(st);

	if (st == EOS_HIT) {
		m_hitTime = 0.5f;
	}
}

void Bullet::OnUpdate(float fdt) {
	if (m_hitTime > 0) {
		m_hitTime -= fdt;
		if (m_hitTime <= 0) {
			SetState(EOS_DEAD);
		}
	}

	MyObject::OnUpdate(fdt);
}
void Bullet::SetMoveCompent(MoveCompent* p) {
	if (p == NULL) { return; }
	if (m_pMoveCompent != nullptr) {
		m_pMoveCompent->OnDetach();
		m_pMoveCompent->release();
	}

	m_pMoveCompent = p;
	m_pMoveCompent->retain();
	m_pMoveCompent->SetOwner(this);
	m_pMoveCompent->OnAttach();
}

_NS_FISHGAME_END_
