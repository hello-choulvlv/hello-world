/*
  *功能分离/从FishObjectManager类中
  *@r2018年3月3日
  *@author:xiaoxiong
 */
#ifndef __BULLET_H__
#define __BULLET_H__
#include "MyObject.h"

_NS_FISHGAME_BEGIN_

class Bullet : public MyObject
{
	friend class FishCacheManager;
protected:
	Bullet();
public:
	virtual ~Bullet();

	static Bullet* Create() {
		Bullet * ret = new (std::nothrow) Bullet();
		if (ret)
		{
			ret->autorelease();
		}
		else
		{
			CC_SAFE_DELETE(ret);
		}
		return ret;
	}
	//
	void    SetCannonData() {}
	void    GetCannonData() {}
	void	    SetCannonSetType(int);
	int		GetCannonSetType();
	void	    SetCannonType(int);
	int		GetCannonType();
	void	    SetCatchRadio(int n);
	int		GetCatchRadio();

	void SetMoveCompent(MoveCompent* p);
	virtual void	SetState(ObjState);
	virtual void	OnUpdate(float fdt);
private:
	int m_nCannonSetType;
	int m_nCannonType;
	int m_nCatchRadio;

	float m_hitTime;
};

_NS_FISHGAME_END_

#endif
