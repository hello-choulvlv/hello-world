
#include "MoveCompent.h"
#include <math.h>
#include "FishObjectManager.h"
#include "FishUtils.h"
#include "Buff.h"
//#include "MathAide.h"
#include "MyObject.h"
namespace fishgame{
    
    MoveCompent::MoveCompent()
    :cocos2d::Ref()
    , m_pPosition(0,0)
    , m_fDirection(0)
    , m_fSpeed(0)
    , m_bPause(false)
    , m_nPathID(0)
    , m_bEndPath(false)
    , m_Offest(0,0)
    , m_fDelay(0.0f)
    , m_bBeginMove(false)
    , m_bRebound(false)
    , m_dwTargetID(0)
    , m_bTroop(false)
    , m_pOwner(nullptr)
    , fWidth(1440.0f)
    , fHeigth(900.0f)
    {
        
    }
    
    void MoveCompent::OnDetach(){}
    
    void MoveCompent::OnAttach(){
        InitMove();
    }
    
    void MoveCompent::SetPathMoveData(int nType, float xPos1, float xPos2, float xPos3, float xPos4, float yPos1, float yPos2, float yPos3, float yPos4, int nPointCount, float fDirction, int nDuration)
    {
        m_strMoveData.nType = nType;
        m_strMoveData.xPos[0] = xPos1;
        m_strMoveData.xPos[1] = xPos2;
        m_strMoveData.xPos[2] = xPos3;
        m_strMoveData.xPos[3] = xPos4;
        m_strMoveData.yPos[0] = yPos1;
        m_strMoveData.yPos[1] = yPos2;
        m_strMoveData.yPos[2] = yPos3;
        m_strMoveData.yPos[3] = yPos4;
        m_strMoveData.nPointCount = nPointCount;
        m_strMoveData.fDirction = fDirction;
        m_strMoveData.nDuration = nDuration;
        m_strMoveData.nStartTime = 0;
        m_strMoveData.nEndTime = 0;
    }
    
    MoveByPath::MoveByPath() :MoveCompent()
    {
        m_Elaspe = 0;
        m_LastElaspe = 0;
    }
    
    MoveByPath::~MoveByPath(){}
    
    MoveByPath* MoveByPath::create(){
        MoveByPath * ret = new (std::nothrow) MoveByPath();
        if (ret)
        {
            ret->autorelease();
        }
        else
        {
            CC_SAFE_DELETE(ret);
        }
        return ret;
    }
    
    void MoveByPath::InitMove(){
        m_Elaspe = 0;
        m_LastElaspe = -1;
        m_bEndPath = false;
    }
    
    
    void MoveByPath::OnUpdate(float fdt){
        if (m_pOwner == NULL) return;
        if (m_bEndPath) {
            m_pOwner->OnMoveEnd();
            return;
        }
        
        auto buffs = m_pOwner->GetBuffs();
        for (auto buff : buffs){
            if (buff->GetType() == EBT_CHANGESPEED){
                fdt *= buff->GetParam();
            }
        }
        
        if (m_fDelay > 0){
            m_fDelay = m_fDelay - fdt;
            if (m_fDelay >= 0){
                m_pOwner->SetPosition(-500.0f, -500.0f);
                return;
            }
            else{
                fdt = fabs(m_fDelay);
            }
        }
        
        if (m_bBeginMove == false && m_Elaspe > 0){
            m_bBeginMove = true;
        }
        
        m_Elaspe = m_Elaspe + fdt * GetSpeed(); // 已经走过的路程
        
        int tempElaspe = (int)m_Elaspe;
        
        if (m_LastElaspe == tempElaspe)
            return;
        
        m_LastElaspe = tempElaspe;
        
        if (tempElaspe >= m_strMoveData.nDuration) {
            // TODO 理论上需要判断是否在屏幕内，若在屏幕内则仍需要继续游动出屏幕
            m_bEndPath = true;
        }
        
        float percent = MIN(1.0f, (float)(tempElaspe) / m_strMoveData.nDuration); // 已走路程占比 相当于 时间分频
        float x(0.0f), y(0.0f), dir(0.0f);
        
        // 计算在某一时间下在曲线上的位置
        switch (m_strMoveData.nType)
        {
            case PMT_LINE:
                FishUtils::CacLine(
                                   m_strMoveData.xPos,
                                   m_strMoveData.yPos,
                                   percent, &x, &y, &dir);
                break;
            case PMT_BEZIER:
                FishUtils::CacBesier(
                                     m_strMoveData.xPos,
                                     m_strMoveData.yPos,
                                     m_strMoveData.nPointCount,
                                     percent, &x, &y, &dir);
                break;
            case PMT_CIRCLE:
                FishUtils::CalCircle(
                                     m_strMoveData.xPos[0],
                                     m_strMoveData.yPos[0],
                                     m_strMoveData.xPos[1],
                                     m_strMoveData.xPos[2],
                                     m_strMoveData.yPos[2],
                                     m_strMoveData.yPos[1],
                                     percent, &x, &y, &dir);
                break;
            case PMT_STAY:
                x = m_strMoveData.xPos[0];
                y =  m_strMoveData.yPos[0];
                dir = m_strMoveData.fDirction;
                break;
            default:
                break;
        }
        
        m_pOwner->SetPosition(x + m_Offest.x, y + m_Offest.y);
        m_pOwner->SetDirection(dir);
    }
    
    void MoveByPath::OnDetach(){}
    
    MoveByDirection::MoveByDirection()
    : MoveCompent()
    , inited_(false)
    ,angle_(0)
    ,dx_(0)
    ,dy_(0)
    {
    }
    
    MoveByDirection::~MoveByDirection(){}
    
    MoveByDirection* MoveByDirection::create(){
        MoveByDirection * ret = new (std::nothrow) MoveByDirection();
        if (ret)
        {
            ret->autorelease();
        }
        else
        {
            CC_SAFE_DELETE(ret);
        }
        return ret;
    }
    
    void MoveByDirection::InitMove(){
        
        angle_ = m_fDirection;
        dx_ = cosf(angle_ - M_PI_2);
        dy_ = sinf(angle_ - M_PI_2);
        m_bEndPath = false;
        
    }
    
    void MoveByDirection::OnDetach(){}
    
    void MoveByDirection::OnUpdate(float fdt)
    {
        if (m_pOwner == nullptr) return;
        
        if (m_bEndPath){
            m_pOwner->OnMoveEnd();
            return;
        }
        
        if (m_pOwner->GetTarget() != 0 && !FishObjectManager::GetInstance()->IsSwitchingScene())
        {
            MyObject* pObj = (MyObject*)(FishObjectManager::GetInstance()->FindFish(m_pOwner->GetTarget()));
			//Fish *target = FishObjectManager::GetInstance()->FindFish(m_pOwner->GetTarget());
            if (pObj != nullptr && pObj->GetState() < EOS_DEAD && pObj->InSideScreen())
            {
                if (inited_){
					auto &targetPosition = pObj->GetPosition();
					auto &originPosition = m_pOwner->GetPosition();
                    if (FishUtils::CalcDistance2(targetPosition.x, targetPosition.y, originPosition.x, originPosition.y) > 10)
                    {
                        SetDirection(FishUtils::CalcAngle2(targetPosition.x, targetPosition.y, originPosition.x, originPosition.y));
                        InitMove();
                    }
                    else
                    {
                        SetPosition(originPosition.x, originPosition.y);
                        SetDirection(m_pOwner->GetDirection());
                        return;
                    }
                }
                else{
                    inited_ = true;
                }
            }
            else
            {
                m_pOwner->SetTarget(0);
            }
        }
        
        auto buffs = m_pOwner->GetBuffs();
        for (auto buff : buffs){
            if (buff->GetType() == EBT_CHANGESPEED){
                fdt *= buff->GetParam();
            }
        }
        
        if (GetDelay() > 0)
        {
            SetDelay(GetDelay() - fdt);
            
            if (GetDelay() >= 0){
                return;
            }else{
                fdt = fabs(GetDelay());
            }
        }
        
        if (m_bBeginMove == false)
        {
            m_bBeginMove = true;
        }
        
        
        m_pPosition.x += m_fSpeed* dx_ * fdt;
        m_pPosition.y += m_fSpeed* dy_ * fdt;
        
        if (Rebound())
        {
            if (m_pPosition.x < 0.0f) { m_pPosition.x = 0 + (0 - m_pPosition.x); dx_ = -dx_; angle_ = -angle_; }
            if (m_pPosition.x > fWidth)  { m_pPosition.x = fWidth - (m_pPosition.x - fWidth); dx_ = -dx_; angle_ = -angle_; }
            
            if (m_pPosition.y < 0.0f) { m_pPosition.y = 0 + (0 - m_pPosition.y); dy_ = -dy_; angle_ = M_PI - angle_; }
            if (m_pPosition.y > fHeigth)  { m_pPosition.y = fHeigth - (m_pPosition.y - fHeigth); dy_ = -dy_; angle_ = M_PI - angle_; }
        }
        else
        {
            if (m_pPosition.x < 0 || m_pPosition.x > fWidth || m_pPosition.y < 0 || m_pPosition.y > fHeigth)
                m_bEndPath = true;
        }
        
        
        m_pOwner->SetDirection(m_pOwner->GetType() == EOT_FISH ? angle_ - M_PI_2 : angle_);
        m_pOwner->SetPosition(m_pPosition.x, m_pPosition.y);
    }

}
