
#ifndef __CC_EXTENSION_CCHTTP_REQUEST_DELEGATE_H_
#define __CC_EXTENSION_CCHTTP_REQUEST_DELEGATE_H_


namespace sw {
    
    class HTTPRequest;
    
    class HTTPRequestDelegate
    {
    public:
        virtual void requestFinished(HTTPRequest* request) {}
        virtual void requestFailed(HTTPRequest* request) {}
    };
    
}

#endif // __CC_EXTENSION_CCHTTP_REQUEST_DELEGATE_H_

