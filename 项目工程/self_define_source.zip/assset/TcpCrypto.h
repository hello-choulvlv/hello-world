//
// Created by linsylar on 2017/5/14.
//

#ifndef COCOS2D_LUA_BINDINGS_TCPCRYPTO_H
#define COCOS2D_LUA_BINDINGS_TCPCRYPTO_H

#include <string>
#include "cocos2d.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"

#define DK_MAPPED            0X05                        //映射类型
typedef unsigned char * PBYTE;
typedef unsigned char BYTE;
#ifndef _WIN32
typedef unsigned int DWORD;
typedef unsigned short WORD;
typedef unsigned short TCHAR;
#endif
typedef unsigned int UINT;

typedef long long LONGLONG;
typedef double DOUBLE;
typedef short SHORT;
typedef int INT;
typedef float FLOAT;
typedef char CHAR;
#ifndef _WIN32
typedef unsigned int LONG;
#endif

//网络内核
typedef struct {
    DWORD dwIPAdress;                     //转发IP头
    BYTE cbDataKind;                        //数据类型
    BYTE cbCheckCode;                    //效验字段
    WORD wPacketSize;                    //数据大小
} TCP_Info;

//网络命令
typedef struct {
    DWORD dwIPAdress;                     //转发IP头
    WORD wMainCmdID;                        //主命令码
    WORD wSubCmdID;                        //子命令码
} TCP_Command;


//网络包头
typedef struct {
    TCP_Info TCPInfo;                        //基础结构
    TCP_Command CommandInfo;                    //命令信息
} TCP_Head;

class TcpCrypto {
public:
    TcpCrypto();

    ~TcpCrypto();

    bool mappedBuffer(void *pData, WORD &wDataSize, unsigned char *$dataType);

    bool unMappedBuffer(void *pData, WORD &wDataSize);

    void reset();

private:
    int m_cbSendRound;                        //字节映射
    int m_cbRecvRound;                        //字节映射
    DWORD m_dwSendXorKey;                        //发送密钥
    DWORD m_dwRecvXorKey;                        //接收密钥

    BYTE MapRecvByte(BYTE cbData);

    BYTE MapSendByte(BYTE cbData);

    WORD SeedRandMap(WORD wSeed);
};


#endif //COCOS2D_LUA_BINDINGS_TCPCRYPTO_H
