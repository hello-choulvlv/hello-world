//
//  SpineEntityManager.cpp
//  cocos2d_lua_bindings
//
//  Created by xiaoxiong2 on 2017/12/31.
//

#include <spine/spine.h>
#include <spine/SkeletonRenderer.h>
#include <spine/extension.h>
#include <spine/SkeletonBatch.h>
#include <spine/AttachmentVertices.h>
#include <spine/Cocos2dAttachmentLoader.h>

#include "SpineEntityManager.hpp"
#include "SpineEntity.hpp"
#include "SpineMirage.hpp"

void disposeTrackEntry (spTrackEntry* entry) {
    _spTrackEntry_dispose(entry);
}

SpineEntityManager* SpineEntityManager:: __sInstance = nullptr;

SpineEntityManager* SpineEntityManager::getInstance()
{
    if(__sInstance == nullptr)
    {
        __sInstance = new SpineEntityManager();
        __sInstance->init();
        __sInstance->initGLProgram();
    }
    
    return __sInstance;
}

SpineEntityManager::SpineEntityManager()
{
    _firstCommand = new Command();
    _command = _firstCommand;
}

SpineEntityManager::~SpineEntityManager()
{
    Command* command = _firstCommand;
    while (command) {
        Command* next = command->next;
        delete command;
        command = next;
    }
}

void SpineEntityManager::initGLProgram()
{
    setGLProgramState(cocos2d::GLProgramState::getOrCreateWithGLProgramName(cocos2d::GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR));
}

void SpineEntityManager::onEnter()
{
    Node::onEnter();
    scheduleUpdate();
}

void SpineEntityManager::onExit()
{
    Node::onExit();
    unscheduleUpdate();
}

void SpineEntityManager::registerEntity(std::string entityName, std::string jsonFilePath, std::string atlasFilePath)
{
    if(__entityRecords.find(entityName) == __entityRecords.end())
    {
        spAtlas* atlas = spAtlas_createFromFile(atlasFilePath.c_str(), 0);
        
        CCASSERT(atlas, "[SpineEntityManager] Error reading atlas file.");
        
        spAttachmentLoader* attachmentLoader = SUPER(Cocos2dAttachmentLoader_create(atlas));
        _spSkeletonJson jsonC;
        spSkeletonJson* json = spSkeletonJson_createWithLoader(attachmentLoader, &jsonC);
        json->scale = 1.0;
        spSkeletonData* skeletonData = spSkeletonJson_readSkeletonDataFile(json, jsonFilePath.c_str());
        CCASSERT(skeletonData, json->error ? json->error : "[SpineEntityManager] Error reading skeleton data file.");
        spSkeletonJson_dispose(json);
        spSkeleton* skeleton = spSkeleton_create(skeletonData);
        spAnimationState* state = spAnimationState_create(spAnimationStateData_create(skeleton->data));
        state->rendererObject = nullptr;
        state->listener = nullptr;
        ((_spAnimationState*)state)->disposeTrackEntry = disposeTrackEntry;
        
        SpineEntity* entity = new SpineEntity();
        entity->_atlas = atlas;
        entity->_skeleton = skeleton;
        entity->_attachmentLoader = attachmentLoader;
        entity->_state = state;
        entity->_name = entityName;
        entity->generateVertices();
        
        __entityRecords[entityName] = EntityRecord();
        __entityRecords[entityName].entity = entity;
        __entityRecords[entityName].livingNumber = 0;
        __entityRecords[entityName].commands.resize(1000);
        __entityRecords[entityName].commandNumber = 0;
    }
}

void SpineEntityManager::unregisterEntity(std::string entityName)
{
    auto result = __entityRecords.find(entityName);
    
    if(result != __entityRecords.end())
    {
        EntityRecord& record = result->second;
        
        delete record.entity;
        
        for(auto iter = record.refs.begin(); iter != record.refs.end(); iter++)
        {
            iter->second->__entity = nullptr;
        }
        
        __entityRecords.erase(result);
    }
}

SpineEntity* SpineEntityManager::getEntity(std::string entityName)
{
    if(__entityRecords.find(entityName) != __entityRecords.end())
    {
        return __entityRecords[entityName].entity;
    }
    else
    {
        return nullptr;
    }
}

SpineMirage* SpineEntityManager::generateMirage(std::string entityName)
{
    auto result = __entityRecords.find(entityName);
    
    if(result != __entityRecords.end())
    {
        EntityRecord& record = result->second;
        
        SpineMirage* mirage = new SpineMirage();
        mirage->init();
        mirage->initGLProgram();
        mirage->autorelease();
        mirage->__activated = false;
        mirage->__entity = record.entity;
        
        record.refs[mirage] = mirage;
        
        return mirage;
    }
    
    return nullptr;
}

void SpineEntityManager::destroyMirage(SpineMirage* mirage)
{
    SpineEntity* entity = mirage->__entity;
    
    if(entity)
    {
        auto result = __entityRecords.find(entity->getName());
        
        if(result != __entityRecords.end())
        {
            EntityRecord& record = result->second;
            
            auto iter = record.refs.find(mirage);
            record.refs.erase(iter);
        }
    }
}

void SpineEntityManager::onActivateStateChanged(SpineMirage* mirage)
{
    SpineEntity* entity = mirage->__entity;
    
    if(entity)
    {
        auto result = __entityRecords.find(entity->getName());
        
        if(result != __entityRecords.end())
        {
            EntityRecord& record = result->second;
            
            if(mirage->__activated)
            {
                record.livingNumber = record.livingNumber + 1;
            }
            else
            {
                record.livingNumber = record.livingNumber - 1;
            }
        }
    }
}

void SpineEntityManager::clearAllEntities()
{
    for(auto recordIter = __entityRecords.begin(); recordIter != __entityRecords.end();)
    {
        EntityRecord& record = recordIter->second;
        
        delete record.entity;
        
        for(auto mirageIter = record.refs.begin(); mirageIter != record.refs.end(); mirageIter++)
        {
            mirageIter->second->__entity = nullptr;
        }
        
        recordIter = __entityRecords.erase(recordIter);
    }
}

void SpineEntityManager::update(float dt)
{
    _command = _firstCommand;
    
    for(auto recordIter = __entityRecords.begin(); recordIter != __entityRecords.end(); recordIter++)
    {
        EntityRecord& record = recordIter->second;
        
        if(record.livingNumber > 0)
        {
            record.entity->update(dt);
            record.commandNumber = 0;
        }
    }
}


void SpineEntityManager::drawMirages(const cocos2d::Mat4 &transform, uint32_t flags)
{
    for(auto iter = __entityRecords.begin(); iter != __entityRecords.end(); iter++)
    {
        EntityRecord& record = iter->second;
        SpineEntity* entity = record.entity;
        
        if(record.commandNumber == 0 || entity->_vertexNumber == 0 || entity->_indexNumber == 0)
        {
            continue;
        }
        
        cocos2d::GL::bindTexture2D(entity->_textureName);
        cocos2d::GL::blendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        
        glBindBuffer(GL_ARRAY_BUFFER, entity->_vertexVBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(cocos2d::V3F_C4B_T2F) * entity->_vertexNumber, entity->_vertices);
        
        cocos2d::GL::enableVertexAttribs(cocos2d::GL::VERTEX_ATTRIB_FLAG_POS_COLOR_TEX);

        glVertexAttribPointer(cocos2d::GLProgram::VERTEX_ATTRIB_POSITION, 3, GL_FLOAT, GL_FALSE, sizeof(cocos2d::V3F_C4B_T2F), (GLvoid*) offsetof(cocos2d::V3F_C4B_T2F, vertices));
        glVertexAttribPointer(cocos2d::GLProgram::VERTEX_ATTRIB_COLOR, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(cocos2d::V3F_C4B_T2F), (GLvoid*) offsetof(cocos2d::V3F_C4B_T2F, colors));
        glVertexAttribPointer(cocos2d::GLProgram::VERTEX_ATTRIB_TEX_COORD, 2, GL_FLOAT, GL_FALSE, sizeof(cocos2d::V3F_C4B_T2F), (GLvoid*) offsetof(cocos2d::V3F_C4B_T2F, texCoords));

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, entity->_indexVBO);
        
        for(int i = 0; i < record.commandNumber; i++)
        {
            _glProgramState->apply(*record.commands[i]);
            glDrawElements(GL_TRIANGLES, entity->_indexNumber, GL_UNSIGNED_SHORT, nullptr);
        }
    }
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

void SpineEntityManager::draw(cocos2d::Renderer* renderer, const cocos2d::Mat4 & transform, uint32_t flags)
{
    __drawCommand.init(_globalZOrder, transform, flags);
    __drawCommand.func = CC_CALLBACK_0(SpineEntityManager::drawMirages, this, transform, flags);
//    renderer->addCommand(&__drawCommand);
}

void SpineEntityManager::addCommand (cocos2d::Renderer* renderer, float globalZOrder, GLuint textureID, cocos2d::GLProgramState* glProgramState,
                                     cocos2d::BlendFunc blendFunc, const cocos2d::TrianglesCommand::Triangles& triangles, const cocos2d::Mat4& transform, uint32_t /*transformFlags*/
) 
{
    _command->triangles->verts = const_cast<cocos2d::V3F_C4B_T2F*>(triangles.verts);
    _command->triangles->vertCount = triangles.vertCount;
    _command->triangles->indexCount = triangles.indexCount;
    _command->triangles->indices = triangles.indices;
    
    _command->trianglesCommand->init(globalZOrder, textureID, glProgramState, blendFunc, *_command->triangles, transform);
    renderer->addCommand(_command->trianglesCommand);
    
    if (!_command->next) _command->next = new Command();
    _command = _command->next;
}

void SpineEntityManager::addCommand(SpineEntity* entity, cocos2d::Mat4* mv)
{
    if(entity == nullptr)
    {
        return;
    }
    
    EntityRecord& record = __entityRecords[entity->getName()];
    record.commands[record.commandNumber] = mv;
    record.commandNumber = record.commandNumber + 1;
}

SpineEntityManager::Command::Command () :
next(nullptr)
{
    trianglesCommand = new cocos2d::TrianglesCommand();
    triangles = new cocos2d::TrianglesCommand::Triangles();
    filled = false;
}

SpineEntityManager::Command::~Command () {
    delete triangles;
    delete trianglesCommand;
}
