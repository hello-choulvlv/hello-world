/*
  *Sprite批处理渲染类实现
  *@date:2021年4月2日
  *@author:xiaoxiong
  *@version 1.0:实现基本的实例化渲染功能
 */
#include "SpriteBatchInstance.h"
#include "2d/CCSpriteFrameCache.h"
#include "renderer/CCRenderer.h"
#include "math/MathUtil.h"

namespace cocos2d {
    SpriteInstance::SpriteInstance(const std::string &sprite_frame_name, int zorder) :
        _internal_ptr(nullptr)
        ,_parent(nullptr)
        , _isObjectInQueue(false)
        , _isLocationDirty(true)
        , _isQuadDirty(true)
        , _isColorDirty(true)
        ,_isVisible(true)
        , _zOrder(zorder)
        ,_tag(0){
        _spriteFrame = SpriteFrameCache::getInstance()->getSpriteFrameByName(sprite_frame_name);
        //if (_spriteFrame != nullptr)
        CCASSERT(_spriteFrame != nullptr,"SpriteInstance frame could not be nullptr");
        _spriteFrame->retain();
    }

    SpriteInstance::~SpriteInstance() {
        if (_spriteFrame != nullptr) _spriteFrame->release();
        _spriteFrame = nullptr;

        _internal_ptr = nullptr;
        _isObjectInQueue = false;
    }

    void SpriteInstance::setPosition(const Vec3 &location) {
        if (_location != location) {
            _location = location;
            _isLocationDirty = true;
            if(_parent != nullptr)_parent->setQuadDirty(true);
        }
    }

    void SpriteInstance::setPosition(float x, float y) {
        if (_location.x != x || _location.y != y) {
            _location.x = x;
            _location.y = y;
            _isLocationDirty = true;
            if(_parent != nullptr)_parent->setQuadDirty(true);
        }
    }

    void SpriteInstance::setPositionX(float x) {
        if (_location.x != x) {
            _location.x = x;
            _isLocationDirty = true;
            if(_parent != nullptr)_parent->setQuadDirty(true);
        }
    }

    void SpriteInstance::setPositionY(float y) {
        if (_location.y != y) {
            _location.y = y;
            _isLocationDirty = true;
            if(_parent != nullptr)_parent->setQuadDirty(true);
        }
    }

    void SpriteInstance::setPositionZ(float z) {
        if (_location.z != z) {
            _location.z = z;
            _isLocationDirty = true;
            if(_parent != nullptr)_parent->setQuadDirty(true);
        }
    }

    void SpriteInstance::setSpriteFrame(const std::string &sprite_frame_name) {
        SpriteFrame  *frame_ptr = SpriteFrameCache::getInstance()->getSpriteFrameByName(sprite_frame_name);
        //if (frame_ptr != nullptr)frame_ptr->retain();
        //if (_spriteFrame != nullptr)_spriteFrame->release();
        CCASSERT(frame_ptr != nullptr, "SpriteInstance frame could not be nullptr");
        if (frame_ptr != _spriteFrame) {
            _isQuadDirty = true;
            frame_ptr->retain();
            _spriteFrame->release();
            _spriteFrame = frame_ptr;
            _isColorDirty = true;
            if(_parent != nullptr)_parent->setQuadDirty(true);
        }
    }

    const SpriteFrame* SpriteInstance::getSpriteFrame()const {
        return _spriteFrame;
    }

    bool SpriteInstance::removeFromParent(){
        if(_parent != nullptr)
            return _parent->removeInstance(this);
        return false;
    }

    SpriteBatchInstance *SpriteInstance::getParent()const{
        return _parent;
    }

    void SpriteInstance::setVisible(bool b2){
        if(b2 != _isVisible){
            _isVisible = b2;
            if(_parent != nullptr)_parent->setVisible(true);
        }
    }
    //////////////////////////////////////////////////////////////
    SpriteBatchInstance::SpriteBatchInstance(const Size &content_size, int sugest_capacity) :
    _quads(nullptr)
    ,_indice_array(nullptr)
    ,_texture(nullptr)
    , _quadCapacity(0)
    , _quadCount(0)
    , _sugestCapacity(sugest_capacity)
    , _isQuadDirty(true)
    ,_isColorDirty(false)
    ,_isModifyColor(true)
    , _isContentDirty(false)
    , _blendFunc(BlendFunc::ALPHA_PREMULTIPLIED){
        //_contentSize = content_size;
        //_anchorPoint.x = 0.5f;
       // _anchorPoint.y = 0.5f;
    }

    SpriteBatchInstance::~SpriteBatchInstance() {
        if (_quads != nullptr) {
            delete[] _quads;
            _quads = nullptr;
        }
        delete[] _indice_array;
        if (_offsets != nullptr) {
            delete[] _offsets;
            _offsets = nullptr;
        }
        for (link_list<SpriteInstance*>::link_node *it_ptr = _sprite_instance_list.head(); it_ptr != nullptr; it_ptr = _sprite_instance_list.next(it_ptr)) {
            it_ptr->tv_value->release();
            it_ptr->tv_value = nullptr;
        }
    }

    bool SpriteBatchInstance::init() {
        Node::init();
        setAnchorPoint(Vec2(0.5f,0.5f));
        setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR_NO_MVP));
        return true;
    }

    SpriteBatchInstance  *SpriteBatchInstance::create(const Size &content_size, int sugest_capacity) {
        SpriteBatchInstance  *instance = new SpriteBatchInstance(content_size, sugest_capacity);
        instance->init();
        instance->setContentSize(content_size);
        instance->autorelease();
        return instance;
    }

    bool SpriteBatchInstance::addInstance(SpriteInstance *instance) {
        CCASSERT(instance != nullptr && !instance->_isObjectInQueue, "SpriteInstance could not be nullptr and it could not be in queue.");
        link_list<SpriteInstance*>::link_node *node_ptr = _sprite_instance_list.back();
        while (node_ptr != nullptr && node_ptr->tv_value->_zOrder > instance->_zOrder)
            node_ptr = _sprite_instance_list.prev(node_ptr);

        if (!_sprite_instance_list.size())
            instance->_internal_ptr = _sprite_instance_list.push_back(instance);
        else if (node_ptr != nullptr)
            instance->_internal_ptr = _sprite_instance_list.insert_after(node_ptr, instance);
        else
            instance->_internal_ptr = _sprite_instance_list.push_front(instance);

        instance->_isObjectInQueue = true;
        instance->_parent = this;
        _isQuadDirty = true;
        instance->retain();
        return true;
    }

    bool SpriteBatchInstance::removeInstance(SpriteInstance *instance) {
        CCASSERT(instance != nullptr ,"SpriteInstance should not be nullptr");
        if(!instance->_isObjectInQueue) return false;
        
        instance->_internal_ptr->tv_value = nullptr;
        _sprite_instance_list.remove(instance->_internal_ptr);
        instance->_internal_ptr = nullptr;
        instance->_isObjectInQueue = false;
        instance->_parent = nullptr;
        instance->release();
        _isQuadDirty = true;
        return true;
    }

    void SpriteBatchInstance::removeAllInstance() {
        for (auto *it_ptr = _sprite_instance_list.head(); it_ptr != nullptr; it_ptr = _sprite_instance_list.next(it_ptr)) {
            it_ptr->tv_value->_isObjectInQueue = false;
            it_ptr->tv_value->_internal_ptr = nullptr;
            it_ptr->tv_value->_parent = nullptr;
            it_ptr->tv_value->release();
            it_ptr->tv_value = nullptr;
        }
        _sprite_instance_list.clear();
        _isQuadDirty = true;
        _quadCount = 0;
        _texture = nullptr;
    }

    void SpriteBatchInstance::changeZOrder(SpriteInstance *instance, int zorder) {
        CCASSERT(instance != nullptr && instance->_isObjectInQueue,"SpriteInstance shoule be in queue.");
        if (zorder != instance->_zOrder) {
            link_list<SpriteInstance*>::link_node *node_ptr = instance->_internal_ptr,*target_node = nullptr;
            //查找当前对象所处的位置,如果需要的话
            if (zorder > instance->_zOrder) {
                link_list<SpriteInstance*>::link_node *next_ptr = _sprite_instance_list.next(node_ptr);
                _sprite_instance_list.remove(node_ptr, false);
                node_ptr->next = node_ptr->prev = nullptr;
                //查找第一个不小于当前zorder的节点
                while (next_ptr != nullptr && zorder > next_ptr->tv_value->_zOrder)
                    next_ptr = _sprite_instance_list.next(next_ptr);
                
                if (next_ptr != nullptr)
                    _sprite_instance_list.insert_before(next_ptr, node_ptr);
                else
                    _sprite_instance_list.push_back(node_ptr);
                target_node = next_ptr;
            }
            else {
                link_list<SpriteInstance*>::link_node *prev_ptr = _sprite_instance_list.prev(node_ptr);
                _sprite_instance_list.remove(node_ptr, false);
                node_ptr->next = node_ptr->prev = nullptr;
                //查找第一个不小于当前zorder的节点
                while (prev_ptr != nullptr && zorder < prev_ptr->tv_value->_zOrder)
                    prev_ptr = _sprite_instance_list.prev(prev_ptr);

                if (prev_ptr != nullptr)
                    _sprite_instance_list.insert_after(prev_ptr, node_ptr);
                else
                    _sprite_instance_list.push_front(node_ptr);
                target_node = prev_ptr;
            }
            _isQuadDirty = true;
            instance->_zOrder = zorder;
        }
    }

    const Mat4& SpriteBatchInstance::getNodeToParentTransform()const {
        if (_transformDirty)
        {
            Mat4::createRotation(_rotationQuat, &_transform);

            if (_rotationZ_X != _rotationZ_Y)
            {
                // Rotation values
                // Change rotation code to handle X and Y
                // If we skew with the exact same value for both x and y then we're simply just rotating
                float radiansX = -CC_DEGREES_TO_RADIANS(_rotationZ_X);
                float radiansY = -CC_DEGREES_TO_RADIANS(_rotationZ_Y);
                float cx = cosf(radiansX);
                float sx = sinf(radiansX);
                float cy = cosf(radiansY);
                float sy = sinf(radiansY);

                float m0 = _transform.m[0], m1 = _transform.m[1], m4 = _transform.m[4], m5 = _transform.m[5], m8 = _transform.m[8], m9 = _transform.m[9];
                _transform.m[0] = cy * m0 - sx * m1, _transform.m[4] = cy * m4 - sx * m5, _transform.m[8] = cy * m8 - sx * m9;
                _transform.m[1] = sy * m0 + cx * m1, _transform.m[5] = sy * m4 + cx * m5, _transform.m[9] = sy * m8 + cx * m9;
            }
            //_transform = translation * _transform;

            if (_scaleX != 1.f)
                _transform.m[0] *= _scaleX, _transform.m[1] *= _scaleX, _transform.m[2] *= _scaleX;

            if (_scaleY != 1.f)
                _transform.m[4] *= _scaleY, _transform.m[5] *= _scaleY, _transform.m[6] *= _scaleY;

            if (_scaleZ != 1.f)
                _transform.m[8] *= _scaleZ, _transform.m[9] *= _scaleZ, _transform.m[10] *= _scaleZ;

            // FIXME:: Try to inline skew
            // If skew is needed, apply skew and then anchor point
            if (_skewX || _skewY) {
                float skewMatArray[16] = {
                    1.0f, (float)tanf(CC_DEGREES_TO_RADIANS(_skewY)), 0.0f, 0.0f,
                    (float)tanf(CC_DEGREES_TO_RADIANS(_skewX)), 1.0f, 0.0f, 0.0f,
                    0.0f,  0.0f,  1.0f, 0.0f,
                    0.0f,  0.0f,  0.0f, 1.0f,
                };
                //Mat4 skewMatrix(skewMatArray);

                //_transform = _transform * *(Mat4*)skewMatArray;
                MathUtil::multiplyMatrix(_transform.m,skewMatArray,_transform.m);
            }

            // adjust anchor point
            if (_anchorPointInPoints.x || _anchorPointInPoints.y)
            {
                // FIXME:: Argh, Mat4 needs a "translate" method.
                // FIXME:: Although this is faster than multiplying a vec4 * mat4
                _transform.m[12] += _transform.m[0] * -_anchorPointInPoints.x + _transform.m[4] * -_anchorPointInPoints.y;
                _transform.m[13] += _transform.m[1] * -_anchorPointInPoints.x + _transform.m[5] * -_anchorPointInPoints.y;
                _transform.m[14] += _transform.m[2] * -_anchorPointInPoints.x + _transform.m[6] * -_anchorPointInPoints.y;
            }
        }

        if (_additionalTransform)
        {
            if (_transformDirty)
                _additionalTransform[1] = _transform;

            if (_transformUpdated)
                _transform = _additionalTransform[1] * _additionalTransform[0];
        }

        _transformDirty = _additionalTransformDirty = false;

        return _transform;
    }

void SpriteBatchInstance::updateQuads(){
    bool need_alloc = false;
    if (_sprite_instance_list.size() > _quadCapacity || (_sprite_instance_list.size() > _sugestCapacity) && (_sprite_instance_list.size() < (_quadCapacity >> 2)))
        _isQuadDirty = need_alloc = true;
    //如果需要重新申请内存
    if (need_alloc) {
        if (!_quads) {
            _quadCapacity = _sugestCapacity > _sprite_instance_list.size() ? _sugestCapacity:_sprite_instance_list.size();
            _quads = new V3F_C4B_T2F_Quad[_quadCapacity];
            _offsets = new Vec3[_quadCapacity];
            _indice_array = new uint16_t[_quadCapacity * 6];
        }
        else {
            delete[] _quads;
            delete[] _offsets;
            delete[] _indice_array;

            if (_sprite_instance_list.size() > _quadCapacity)
                _quadCapacity <<= 1;
            else
                _quadCapacity >>= 1;

            _quads = new V3F_C4B_T2F_Quad[_quadCapacity];
            _offsets = new Vec3[_quadCapacity];
            _indice_array = new uint16_t[_quadCapacity * 6];
        }
        _triangle.verts = (V3F_C4B_T2F *)_quads;
        _triangle.indices = _indice_array;
    }
}

    void SpriteBatchInstance::updateInstanceQuads(SpriteInstance *instance) {
        float alpha_f2 = _isModifyColor? _displayedOpacity / 255.0f:1.0f;
        Color4B   color(_displayedColor.r * alpha_f2, _displayedColor.g * alpha_f2, _displayedColor.b * alpha_f2, _displayedOpacity);
        //遍历每一个四边形,如果发现某一个四边形没有对应的纹理,则直接忽略
        V3F_C4B_T2F_Quad &quad = instance->_quad;
        Texture2D  *texture2 = instance->_spriteFrame->getTexture();
        if (!_texture)
            _texture = texture2;
        else CCASSERT(_texture == texture2, "all sprite frame should be same.");
        auto texture_width = texture2->getPixelsWide();
        auto texture_height = texture2->getPixelsHigh();
        const Rect &frame_size = instance->_spriteFrame->getRect();
        const Vec2 &location = frame_size.origin;
        const Size &size = frame_size.size;
        bool b2_rotate = instance->_spriteFrame->isRotated();

        float x0 = location.x / texture_width;
        float y0 = location.y / texture_height;

        float u0 = b2_rotate ? size.height / texture_width : size.width / texture_width;
        float v0 = b2_rotate ? size.width / texture_height : size.height / texture_height;

        quad.tl.colors = color;
        quad.tl.vertices.x = 0.0f; quad.tl.vertices.y = _contentSize.height; quad.tl.vertices.z = 0.0f;
        quad.tl.texCoords.u = b2_rotate ? x0 + u0 : x0;
        quad.tl.texCoords.v = y0;

        quad.bl.colors = color;
        quad.bl.vertices.x = 0.0f; quad.bl.vertices.y = 0.0f; quad.bl.vertices.z = 0.0f;
        quad.bl.texCoords.u = x0;
        quad.bl.texCoords.v = b2_rotate ? y0 : y0 + v0;

        quad.br.colors = color;
        quad.br.vertices.x = _contentSize.width; quad.br.vertices.y = 0.0f; quad.br.vertices.z = 0.0f;
        quad.br.texCoords.u = b2_rotate ? x0 : x0 + u0;
        quad.br.texCoords.v = y0 + v0;

        quad.tr.colors = color;
        quad.tr.vertices.x = _contentSize.width; quad.tr.vertices.y = _contentSize.height; quad.tr.vertices.z = 0.0f;
        quad.tr.texCoords.u = x0 + u0;
        quad.tr.texCoords.v = b2_rotate ? y0 + v0 : y0;
    }

    void SpriteBatchInstance::setColor(const Color3B& color) {
        if (color != this->_displayedColor) {
            Node::setColor(color);
            _isColorDirty = true;
            _isQuadDirty = true;
        }
    }

    void SpriteBatchInstance::setOpacity(GLubyte opacity) {
        if (opacity != _displayedOpacity) {
            Node::setOpacity(opacity);
            _isColorDirty = true;
            _isQuadDirty = true;
        }
    }

    void SpriteBatchInstance::updateDisplayedOpacity(GLubyte opacity) {
        if (_displayedOpacity != opacity) {
            Node::updateDisplayedOpacity(opacity);
            _isColorDirty = true;
            _isQuadDirty = true;
        }
    }

    void SpriteBatchInstance::updateQuadColor(SpriteInstance *instance) {
        float s2f = _isModifyColor ? _displayedOpacity / 255.0f : 1.0f;
        Color4B color(GLubyte(_displayedColor.r*s2f), GLubyte(_displayedColor.g * s2f), GLubyte(_displayedColor.b * s2f), _displayedOpacity);
        V3F_C4B_T2F_Quad &quad = instance->_quad;
        quad.tl.colors = color;
        quad.bl.colors = color;
        quad.br.colors = color;
        quad.tr.colors = color;
    }

    void SpriteBatchInstance::setBlendFunc(const BlendFunc &blend) {
        if (blend != _blendFunc) {
            _blendFunc = blend;
            bool b2 = blend.src == GL_ONE;
            if (b2 != _isModifyColor) {
                _isColorDirty = true;
                _isModifyColor = b2;
            }
            _isQuadDirty = true;
        }
    }

    void SpriteBatchInstance::setContentSize(const Size& contentSize) {
        if (!_contentSize.equals(contentSize)) {
            _isContentDirty = true;
            _isQuadDirty = true;
            Node::setContentSize(contentSize);
        }
    }

    void SpriteBatchInstance::draw(Renderer *renderer, const Mat4& transform, uint32_t flags) {
        if (_sprite_instance_list.size() != 0) {
            if(_sprite_instance_list.size() > _quadCapacity)
                updateQuads();
            //Texture2D   *texture = nullptr;
            uint32_t        offset_idx = _isQuadDirty?0:_quadCount;
            for (auto *it_ptr = _sprite_instance_list.head();_isQuadDirty &&  it_ptr != nullptr; it_ptr = _sprite_instance_list.next(it_ptr)) {
                SpriteInstance *instance = it_ptr->tv_value;

                bool color_dirty = true;
                if (_isContentDirty || instance->_isQuadDirty) {
                    updateInstanceQuads(instance);
                    instance->_isQuadDirty = false;
                    instance->_isColorDirty = false;
                    color_dirty = false;
                }

                if (_isColorDirty && color_dirty) {
                    updateQuadColor(instance);
                    instance->_isColorDirty = false;
                }
                
                if(instance->_isVisible){
                    memcpy(_quads + offset_idx,&instance->_quad,sizeof(instance->_quad));
                    _offsets[offset_idx] = instance->_location;
                    
                    int32_t  base_l = offset_idx * 6,index_l = offset_idx * 4;
                    _indice_array[base_l] = index_l;
                    _indice_array[base_l + 1] = index_l + 1;
                    _indice_array[base_l + 2] = index_l + 2;
                    _indice_array[base_l + 3] = index_l + 2;
                    _indice_array[base_l + 4] = index_l + 1;
                    _indice_array[base_l + 5] = index_l + 3;
                    
                    ++offset_idx;
                }
            }
            
            if(offset_idx > 0){
                _triangle.vertCount = offset_idx * 4;
                _triangle.indexCount = offset_idx * 6;
               // _quadCommand.init(_globalZOrder, _texture->getName(), _glProgramState, _blendFunc, _quads, offset_idx,transform, flags);
                //renderer->addCommand(&_quadCommand);
                _triangleCommand.init(_globalZOrder, _texture, _glProgramState, _blendFunc, _triangle, transform, flags);
                renderer->addCommand(&_triangleCommand);
                
                _triangleCommand.setSecondaryOffsetV3(_offsets);
                _triangleCommand.setVertexStrideNum(4);
                _quadCount = offset_idx;
                _isQuadDirty = false;
            }
        }
        if (_isColorDirty) _isColorDirty = false;
        if (_isContentDirty) _isContentDirty = false;
        //if(_isQuadDirty)_isQuadDirty = false;
    }
}
