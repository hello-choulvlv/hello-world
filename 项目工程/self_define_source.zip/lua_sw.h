//
// Created by mbp on 2017/4/14.
// Copyright (c) 2017 shunwo. All rights reserved.
//

#ifndef LIBSHUNWOCOMMON_LUA_CRYPTOSW_H
#define LIBSHUNWOCOMMON_LUA_CRYPTOSW_H


#include "SwManager.h"

extern "C" {
#include "lua.h"
}

class lua_sw {
    
public:
    lua_sw();
    
    static int register_sw(lua_State *$L);
    
    static int lua_unmapBuffer(lua_State *$L);
    
    static int lua_mappedBuffer(lua_State *$L);
    
    static int lua_encrypKey(lua_State *$L);
    
    static int lua_reset(lua_State *$L);
    
    static int lua_unzipFileInThread(lua_State *$L);
    
    static int lua_getaddrinfoInThread(lua_State *$L);
    
    static int lua_whConverUnicodeToUtf8WithArray(lua_State *$L);
    
    static int lua_arc4String(lua_State *$L);
    
    /**
     *sam哥的加密算法
     */
    static int lua_ss(lua_State *$L);
    
    /**
     *sam哥的解密算法
     */
    static int lus_sr(lua_State *$L);
    
    /**
     *设置sam哥的加密算法的key
     */
    static int lus_setSK(lua_State *$L);
    
    
    
    
    
    /*
     * 新服务器绑定
     * */
    /*
     * 获取本地加密key
     * */
    static int lua_calCryptoKey(lua_State *$L);
    
    /*
     * 解key
     * */
    static int lua_unCryptoKey(lua_State *$L);
    
    /*
     * 指定dns的http请求（通过curl）
     * */
    static int lua_requestHttpSpecifiedDNS(lua_State * $L);
    
    /*
     * 指定dns服务器来解析域名（通过c-ares）
     * */
    static int lua_getaddrinfoInThreadViaDNS(lua_State *$L);
    
    ~lua_sw();
    
private:
    static SwManager *_swMgr;
};

#endif //LIBSHUNWOCOMMON_LUA_CRYPTOSW_H
