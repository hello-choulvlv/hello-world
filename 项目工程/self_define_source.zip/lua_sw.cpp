//
// Created by sj on 2017/4/14.
//
#include "scripting/lua-bindings/manual/swgadget/lua_sw.h"
#include "scripting/lua-bindings/manual/tolua_fix.h"
#include "cocos/cocos3dex/utils/cocos3dex_vector4.h"

SwManager *lua_sw::_swMgr = nullptr;
#ifndef _WIN32
typedef unsigned int DWORD;
#endif

int lua_sw::lua_unCryptoKey(lua_State *$L) {
    int64_t key_array[] = {100, 800, 536, 321};
    int size_count = (sizeof(key_array) / sizeof(int64_t)) - 1;

    int64_t key_num = lua_tointeger($L, 1);
    int64_t num = key_num;

    for (int i = size_count; i >= 0; i--) {
        num = num ^ key_array[i];
    }
    lua_pushnumber($L, num);
    return 1;
}

int lua_sw::lua_calCryptoKey(lua_State *$L) {
    int64_t key_array[] = {100, 800, 536, 321};
    int size_count = sizeof(key_array) / sizeof(int64_t);
    int64_t num = lua_tointeger($L, 1);
    int64_t key_num = num;
    for (int i = 0; i < size_count; i++) {
        key_num = key_num ^ key_array[i];
    }
    lua_pushnumber($L, key_num);
    return 1;

}

int lua_sw::lua_getaddrinfoInThread(lua_State *$L) {
    int argc = lua_gettop($L);
    std::string result;
    if (argc >= 2) {
        const char *ip = lua_tostring($L, 1);
        int luacallback = toluafix_ref_function($L, 2, 0);
        _swMgr->getaddrinfo(ip, luacallback);
    }
    return 0;
}

int lua_sw::lua_whConverUnicodeToUtf8WithArray(lua_State *$L) {
    int argc = lua_gettop($L);
    std::string result;
    if (argc >= 1) {
        //const void *temp = lua_topointer($L, 1);
        const char *temp = lua_tostring($L, 1);
        result = _swMgr->whConverUnicodeToUtf8WithArray((WORD *) temp);
    }
    tolua_pushstring($L, result.c_str());
    return 1;
}

int lua_sw::lua_unzipFileInThread(lua_State *$L) {
    std::string zipPath;
    std::string outputPath;
    int luaOnSuccess = 0;
    int luaOnFailed = 0;
    int argc = lua_gettop($L);
    if (argc >= 1) {
        zipPath = lua_tostring($L, 1);
    }
    if (argc >= 2) {
        outputPath = lua_tostring($L, 2);
    }
    if (argc >= 3) {
        luaOnSuccess = toluafix_ref_function($L, 3, 0);
    }

    if (argc >= 4) {
        luaOnFailed = toluafix_ref_function($L, 4, 0);
    }
    _swMgr->uncompressFile(zipPath, outputPath, luaOnSuccess, luaOnFailed);
    return 0;
}

int lua_sw::lua_mappedBuffer(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc >= 3) {
        size_t len = 0;
        const char *pData = luaL_checklstring($L, 1, &len);
#ifndef _WIN32
        char pBuffer[len + 64];
#else
		char *pBuffer = new char[len + 64];
#endif
        memcpy(pBuffer, pData, len);
        WORD newLen = (WORD) len;
        int dataType = (int) lua_tointeger($L, 2);
        size_t dataKindLen = 0;
        unsigned char* dataKind = (unsigned char*)luaL_checklstring($L, 3, &dataKindLen);
        bool b = _swMgr->mappedBuffer(pBuffer, newLen, dataType, dataKind);
        if (b) {
            lua_newtable($L);
            lua_pushstring($L, "buffer");
            lua_pushlstring($L, pBuffer, newLen);
            lua_rawset($L, -3);
            lua_pushstring($L, "len");
            lua_pushnumber($L, newLen);
            lua_rawset($L, -3);
#ifdef _WIN32
			delete[] pBuffer;
			pBuffer = nullptr;
#endif
            return 1;
        }
#ifdef _WIN32
		delete[] pBuffer;
		pBuffer = nullptr;
#endif
    }
    return 0;
}

int lua_sw::lua_unmapBuffer(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc > 0) {
        size_t len = 0;
        const char *pData = luaL_checklstring($L, 1, &len);
        WORD newLen = (WORD) len;
#ifndef _WIN32
		char pBuffer[len + 64];
#else
		char *pBuffer = new char[len + 64];
#endif
        memcpy(pBuffer, pData, len);
        int dataType = (int) lua_tointeger($L, 2);
        bool b = _swMgr->unMappedBuffer(pBuffer, newLen, dataType);
        if (b) {
            lua_newtable($L);
            lua_pushstring($L, "buffer");
            lua_pushlstring($L, pBuffer, newLen);
            lua_rawset($L, -3);
            lua_pushstring($L, "len");
            lua_pushnumber($L, newLen);
            lua_rawset($L, -3);
#ifdef _WIN32
			delete[] pBuffer;
			pBuffer = nullptr;
#endif
			return 1;
		}
#ifdef _WIN32
		delete[] pBuffer;
		pBuffer = nullptr;
#endif
	}
    return 0;
}


static std::map<std::string, cocos3dex4_vector3d *> s_arcMap;

int lua_sw::lua_arc4String(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc >= 2) {
        size_t srcSize = 0;
        size_t keySize = 0;
        unsigned char *src = (unsigned char *) luaL_checklstring($L, 1, &srcSize);
        std::string idStr = lua_tostring($L, 2);
        unsigned char *key = NULL;
        if (argc >= 3 && !lua_isnil($L, 3)) {
            key = (unsigned char *) luaL_checklstring($L, 3, &keySize);
        }
        cocos3dex4_vector3d *pArc4 = NULL;
        std::map<std::string, cocos3dex4_vector3d *>::iterator iter = s_arcMap.find(idStr);
        if (iter == s_arcMap.end()) {
            pArc4 = new cocos3dex4_vector3d();
            s_arcMap[idStr] = pArc4;
        } else {
            pArc4 = s_arcMap[idStr];
        }
        if (keySize != 0) {
            cocos3dex4_setup(pArc4, key, (int) keySize);
        }
        cocos3dex_vectorNormalize(pArc4, (int) srcSize, src, src);

        lua_pushlstring($L, (const char *) src, srcSize);
        return 1;
    }
    return 0;
}

int lua_sw::lua_encrypKey(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc >= 1) {
        const char *src = lua_tostring($L, 1);
        const char *key = lua_tostring($L, 2);
        std::string result = _swMgr->encrypKey(src, key);
        tolua_pushstring($L, result.c_str());
        return 1;
    }
    return 0;
}

int lua_sw::lua_reset(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc >= 1) {
        int dataType = (int) lua_tointeger($L, 1);
        _swMgr->resetCrypto(dataType);
    }
    return 0;
}

int lua_sw::lua_ss(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc > 0) {
        size_t len = 0;
        const char *pData = luaL_checklstring($L, 1, &len);
#ifndef _WIN32
		char pBuffer[len + 64];
#else
		char *pBuffer = new char[len + 64];
#endif
        memcpy(pBuffer, pData, len);
        WORD newLen = (WORD) len;
        bool b = _swMgr->EncryptData(pBuffer, newLen);
        if (b) {
            lua_newtable($L);
            lua_pushstring($L, "buffer");
            lua_pushlstring($L, pBuffer, newLen);
            lua_rawset($L, -3);
            lua_pushstring($L, "len");
            lua_pushnumber($L, newLen);
            lua_rawset($L, -3);
#ifdef _WIN32
			delete[] pBuffer;
			pBuffer = nullptr;
#endif
			return 1;
		}
#ifdef _WIN32
		delete[] pBuffer;
		pBuffer = nullptr;
#endif
	}
    return 0;
}

int lua_sw::lus_sr(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc > 0) {
        size_t len = 0;
        const char *pData = luaL_checklstring($L, 1, &len);
#ifndef _WIN32
		char pBuffer[len + 64];
#else
		char *pBuffer = new char[len + 64];
#endif
        memcpy(pBuffer, pData, len);
        WORD newLen = (WORD) len;
        bool b = _swMgr->DecryptData(pBuffer, newLen);
        if (b) {
            lua_newtable($L);
            lua_pushstring($L, "buffer");
            lua_pushlstring($L, pBuffer, newLen);
            lua_rawset($L, -3);
            lua_pushstring($L, "len");
            lua_pushnumber($L, newLen);
            lua_rawset($L, -3);
#ifdef _WIN32
			delete[] pBuffer;
			pBuffer = nullptr;
#endif
			return 1;
		}
#ifdef _WIN32
		delete[] pBuffer;
		pBuffer = nullptr;
#endif
    }
    return 0;
}

int lua_sw::lus_setSK(lua_State *$L) {
    int argc = lua_gettop($L);
    if (argc > 0) {
        size_t len = 0;
        const char *pData = luaL_checklstring($L, 1, &len);
        _swMgr->setSK(pData, len);
    }
    return 0;
}

int lua_sw::lua_requestHttpSpecifiedDNS(lua_State *$L){
    int argc = lua_gettop($L);
    if (argc > 2) {
        const char *url = lua_tostring($L, 1);
        const char *dns = lua_tostring($L, 2);
        int luaCallback = 0;
        if (argc >= 3) {
             luaCallback = toluafix_ref_function($L, 3, 0);
        }
        
        _swMgr->requestHttpSpeifiedDns(url, dns, luaCallback);
    }
    return 0;
}

int lua_sw::lua_getaddrinfoInThreadViaDNS(lua_State *$L){
    int argc = lua_gettop($L);
    std::string result;
    if (argc >= 3) {
        const char *host = lua_tostring($L, 1);
        const char *dnsServer = lua_tostring($L, 2);
        int luacallback = toluafix_ref_function($L, 3, 0);
        _swMgr->getaddrinfoInThreadViaDnsServer(host, dnsServer, luacallback);
    }
    return 0;
}

int lua_sw::register_sw(lua_State *$L) {
    _swMgr = SwManager::getInstance();
    _swMgr->deploy();
    lua_register($L, "CryptoSwManager_unmapBuffer", lua_unmapBuffer);
    lua_register($L, "CryptoSwManager_mappedBuffer", lua_mappedBuffer);
    lua_register($L, "CryptoSwManager_encrypKey", lua_encrypKey);
    lua_register($L, "CryptoSwManager_reset", lua_reset);
    lua_register($L, "CryptoSwManager_calCryptoKey", lua_calCryptoKey);
    lua_register($L, "CryptoSwManager_unCryptoKey", lua_unCryptoKey);
    lua_register($L, "CryptoSwManager_arc4String", lua_arc4String);
    lua_register($L, "SwManager_unzipFileInThread", lua_unzipFileInThread);
    lua_register($L, "SwManager_whConverUnicodeToUtf8WithArray", lua_whConverUnicodeToUtf8WithArray);
    lua_register($L, "SwManager_getaddrinfoInThread", lua_getaddrinfoInThread);
    lua_register($L, "SwManager_ss", lua_ss);
    lua_register($L, "SwManager_sr", lus_sr);
    lua_register($L, "SwManager_sk", lus_setSK);
    lua_register($L, "SwManager_requestHttpSpeifiedDNS", lua_requestHttpSpecifiedDNS);
    lua_register($L, "SwManager_getaddrinfoInThreadViaDNS", lua_getaddrinfoInThreadViaDNS);
    return 0;
}


lua_sw::lua_sw() {

}

lua_sw::~lua_sw() {

}
