//
//  SpineEntity.hpp
//  cocos2d_lua_bindings
//
//  Created by xiaoxiong2 on 2017/12/31.
//

#ifndef SpineEntity_hpp
#define SpineEntity_hpp

#include <stdio.h>
#include <cocos2d.h>
#include <spine/AttachmentVertices.h>

class SpineMirage;
class spAnimationState;
class spAtlas;
class spSkeleton;
class spAttachmentLoader;

class SpineEntity {
    
private:
    SpineEntity();
    ~SpineEntity();
    
public:
    void update(float dt);
    void setAnimation(int trackIndex, const std::string& name, bool loop);
    std::string& getName();
    
private:
    void generateVertices();
    void expendVertices(spine::AttachmentVertices* attachment, cocos2d::Color4B color);
    void expendIndices(spine::AttachmentVertices* attachment, cocos2d::Color4B color);
    
private:
    spAnimationState* _state;
    spAtlas* _atlas;
    spSkeleton* _skeleton;
    spAttachmentLoader* _attachmentLoader;
    std::string _name;
    GLint _textureName;
    
    GLuint _vertexVBO;
    GLsizei _vertexNumber;
    std::vector<cocos2d::V3F_C4B_T2F> _verticesContainer;
    cocos2d::V3F_C4B_T2F* _vertices;
    
    GLuint _indexVBO;
    GLsizei _indexNumber;
    std::vector<GLushort> _indicesContainer;
    GLushort* _indices;
    
    friend class SpineEntityManager;
    friend class SpineMirage;
};

#endif /* SpineEntity_hpp */
