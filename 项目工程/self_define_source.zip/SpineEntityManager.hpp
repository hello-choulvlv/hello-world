//
//  SpineEntityManager.hpp
//  cocos2d_lua_bindings
//
//  Created by xiaoxiong2 on 2017/12/31.
//

#ifndef SpineEntityManager_hpp
#define SpineEntityManager_hpp

#include <stdio.h>
#include <string>
#include <map>
#include "cocos2d.h"

class SpineEntity;
class SpineMirage;

class SpineEntityManager: public cocos2d::Node{
    
private:
    static SpineEntityManager* __sInstance;
    
public:
    static SpineEntityManager* getInstance();
    
private:
    SpineEntityManager();
    virtual ~SpineEntityManager();
    void initGLProgram();
    
public:
    virtual void onEnter();
    virtual void onExit();
    virtual void update(float dt);
    virtual void draw(cocos2d::Renderer* renderer, const cocos2d::Mat4 & transform, uint32_t flags);
    
public:
    void registerEntity(std::string entityName, std::string jsonFilePath, std::string atlasFilePath);
    void unregisterEntity(std::string entityName);
    void clearAllEntities();
    SpineEntity* getEntity(std::string entityName);
    SpineMirage* generateMirage(std::string entityName);
    
    void addCommand (cocos2d::Renderer* renderer, float globalOrder, GLuint textureID, cocos2d::GLProgramState* glProgramState,
                     cocos2d::BlendFunc blendType, const cocos2d::TrianglesCommand:: Triangles& triangles, const cocos2d::Mat4& mv, uint32_t flags);
    
    void addCommand (SpineEntity* entity, cocos2d::Mat4* mv);
    
    void drawMirages(const cocos2d::Mat4 &transform, uint32_t flags);
    
private:
    void destroyMirage(SpineMirage* mirage);
    void onActivateStateChanged(SpineMirage* mirage);
    
    struct EntityRecord
    {
        SpineEntity* entity;
        int livingNumber;
        std::map<SpineMirage*, SpineMirage*> refs;
        std::vector<cocos2d::Mat4*> commands;
        int commandNumber;
    };
    
    class Command {
    public:
        Command ();
        virtual ~Command ();
        
        bool filled;
        cocos2d::TrianglesCommand* trianglesCommand;
        cocos2d::TrianglesCommand::Triangles* triangles;
        Command* next;
    };
    
    Command* _firstCommand;
    Command* _command;
    
    std::map<std::string, EntityRecord> __entityRecords;
    
    cocos2d::CustomCommand __drawCommand;
    
    friend class SpineEntity;
    friend class SpineMirage;
};

#endif /* SpineEntityManager_hpp */
