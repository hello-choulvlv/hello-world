/****************************************************************************
Copyright (c) 2008-2010 Ricardo Quesada
Copyright (c) 2009      Jason Booth
Copyright (c) 2009      Robert J Payne
Copyright (c) 2010-2012 cocos2d-x.org
Copyright (c) 2011      Zynga Inc.
Copyright (c) 2013-2016 Chukong Technologies Inc.

http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/

#include "sprite/CCSpriteFrameCache.h"
#include "CCFileUtils.h"
#include <vector>
#include "ccMacros.h"
#include "base/ccUTF8.h"
#include "base/CCNS.h"
#include "CCTexture2D.h"

using namespace std;

NS_CC_BEGIN

SpriteFrameCache* SpriteFrameCache::create(){
    SpriteFrameCache *object = new SpriteFrameCache();
    object->init();
    return object;
}
    bool SpriteFrameCache::init() {
        _spriteFramesAliases.reserve(20);
        return true;
    }

    SpriteFrameCache::~SpriteFrameCache() {
        for(auto it = _spriteFrames.begin();it != _spriteFrames.end();++it)
            delete it->second;
    }

    void SpriteFrameCache::parseIntegerList(const std::string &string, std::vector<int> &res) {
        std::string delim(" ");

        size_t n = std::count(string.begin(), string.end(), ' ');
        res.resize(n + 1);

        size_t start = 0U;
        size_t end = string.find(delim);

        int i = 0;
        while (end != std::string::npos) {
            res[i++] = atoi(string.substr(start, end - start).c_str());
            start = end + delim.length();
            end = string.find(delim, start);
        }

        res[i] = atoi(string.substr(start, end).c_str());
    }

    void SpriteFrameCache::addSpriteFramesWithDictionary(ValueMap &dictionary, Texture2D *texture,SpriteFrame *sprite_frame) {
        /*
        Supported Zwoptex Formats:

        ZWTCoordinatesFormatOptionXMLLegacy = 0, // Flash Version
        ZWTCoordinatesFormatOptionXML1_0 = 1, // Desktop Version 0.0 - 0.4b
        ZWTCoordinatesFormatOptionXML1_1 = 2, // Desktop Version 1.0.0 - 1.0.1
        ZWTCoordinatesFormatOptionXML1_2 = 3, // Desktop Version 1.0.2+

        Version 3 with TexturePacker 4.0 polygon mesh packing
        */

        if (dictionary["frames"].getType() != Value::Type::MAP)
            return;

        ValueMap &framesDict = dictionary["frames"].asValueMap();
        int format = 0;

        Size2 textureSize;

        // get the format
        if (dictionary.find("metadata") != dictionary.end()) {
            ValueMap &metadataDict = dictionary["metadata"].asValueMap();
            format = metadataDict["format"].asInt();

            if (metadataDict.find("size") != metadataDict.end()) {
                textureSize = SizeFromString(metadataDict["size"].asString());
            }
        }

        // check the format
        CCASSERT(format >= 0 && format <= 3, "format is not supported for SpriteFrameCache addSpriteFramesWithDictionary:textureFilename:");

        for (auto &iter : framesDict) {
            ValueMap &frameDict = iter.second.asValueMap();
            std::string spriteFrameName = iter.first;
            SpriteFrame *spriteFrame = nullptr;
            auto it = _spriteFrames.find(spriteFrameName);
            if (it  != _spriteFrames.end()) {
                continue;
            }

            if (format == 0) {
                float x = frameDict["x"].asFloat();
                float y = frameDict["y"].asFloat();
                float w = frameDict["width"].asFloat();
                float h = frameDict["height"].asFloat();
                float ox = frameDict["offsetX"].asFloat();
                float oy = frameDict["offsetY"].asFloat();
                int ow = frameDict["originalWidth"].asInt();
                int oh = frameDict["originalHeight"].asInt();
                // check ow/oh
                if (!ow || !oh) {
                    CCLOGWARN("cocos2d: WARNING: originalWidth/Height not found on the SpriteFrame. AnchorPoint won't work as expected. Regenerate the .plist");
                }
                // abs ow/oh
                ow = std::abs(ow);
                oh = std::abs(oh);
                // create frame
                spriteFrame = SpriteFrame::createWithTexture(Rect4(x, y, w, h), false, Vec2(ox, oy), Size2( ow, oh));
            } else if (format == 1 || format == 2) {
                Rect4 frame = RectFromString(frameDict["frame"].asString());
                bool rotated = false;

                // rotation
                if (format == 2) {
                    rotated = frameDict["rotated"].asBool();
                }

                Vec2 offset = PointFromString(frameDict["offset"].asString());
                Size2 sourceSize = SizeFromString(frameDict["sourceSize"].asString());

                // create frame
                spriteFrame = SpriteFrame::createWithTexture(frame, rotated, offset, sourceSize);
            } else if (format == 3) {
                // get values
                Size2 spriteSize = SizeFromString(frameDict["spriteSize"].asString());
                Vec2 spriteOffset = PointFromString(frameDict["spriteOffset"].asString());
                Size2 spriteSourceSize = SizeFromString(frameDict["spriteSourceSize"].asString());
                Rect4 textureRect = RectFromString(frameDict["textureRect"].asString());
                bool textureRotated = frameDict["textureRotated"].asBool();

                // get aliases
                ValueVector &aliases = frameDict["aliases"].asValueVector();

                for (const auto &value : aliases) {
                    std::string oneAlias = value.asString();
                    if (_spriteFramesAliases.find(oneAlias) != _spriteFramesAliases.end()) {
                        CCLOGWARN("cocos2d: WARNING: an alias with name %s already exists", oneAlias.c_str());
                    }

                    _spriteFramesAliases[oneAlias] = Value(spriteFrameName);
                }

                // create frame
                spriteFrame = SpriteFrame::createWithTexture(
                        Rect4(textureRect.origin.x, textureRect.origin.y, spriteSize.width, spriteSize.height),
                        textureRotated,
                        spriteOffset,
                        spriteSourceSize);
            }
            // add sprite frame
            _spriteFrames.insert(std::make_pair(spriteFrameName, spriteFrame));
        }
    }

    void SpriteFrameCache::addSpriteFramesWithDictionary(ValueMap &dict, const std::string &texturePath) {
        std::string pixelFormatName;
        if (dict.find("metadata") != dict.end()) {
            ValueMap &metadataDict = dict.at("metadata").asValueMap();
            if (metadataDict.find("pixelFormat") != metadataDict.end()) {
                pixelFormatName = metadataDict.at("pixelFormat").asString();
            }
        }

        Texture2D *texture = nullptr;
        static std::unordered_map<std::string, Texture2D::PixelFormat> pixelFormats = {
                {"RGBA8888", Texture2D::PixelFormat::RGBA8888},
                {"RGBA4444", Texture2D::PixelFormat::RGBA4444},
                {"RGB5A1", Texture2D::PixelFormat::RGB5A1},
                {"RGBA5551", Texture2D::PixelFormat::RGB5A1},
                {"RGB565", Texture2D::PixelFormat::RGB565},
                {"A8", Texture2D::PixelFormat::A8},
                {"ALPHA", Texture2D::PixelFormat::A8},
                {"I8", Texture2D::PixelFormat::I8},
                {"AI88", Texture2D::PixelFormat::AI88},
                {"ALPHA_INTENSITY", Texture2D::PixelFormat::AI88},
                //{"BGRA8888", Texture2D::PixelFormat::BGRA8888}, no Image conversion RGBA -> BGRA
                {"RGB888", Texture2D::PixelFormat::RGB888}
        };

       // if (texture) {
            addSpriteFramesWithDictionary(dict, texture,nullptr);
     //   } else {
      //      CCLOG("cocos2d: SpriteFrameCache: Couldn't load texture");
      //  }
    }

    void SpriteFrameCache::addSpriteFramesWithFile(const std::string &plist, Texture2D *texture) {
        std::string fullPath = FileUtils::getInstance()->fullPathForFilename(plist);
        //std::string fullPath = FileUtils::getInstance()->fullPathForFilename(plist);
        ValueMap dict = FileUtils::getInstance()->getValueMapFromFile(fullPath);

        addSpriteFramesWithDictionary(dict, texture);
        //_loadedFileNames->insert(plist);
    }

    void SpriteFrameCache::addSpriteFramesWithFileContent(const std::string &plist_content, Texture2D *texture) {
        ValueMap dict = FileUtils::getInstance()->getValueMapFromData(plist_content.c_str(), static_cast<int>(plist_content.size()));
        addSpriteFramesWithDictionary(dict, texture);
    }

    void SpriteFrameCache::addSpriteFramesWithFile(const std::string &plist, const std::string &textureFileName) {
        CCASSERT(textureFileName.size() > 0, "texture name should not be null");

        const std::string fullPath = FileUtils::getInstance()->fullPathForFilename(plist);
        ValueMap dict = FileUtils::getInstance()->getValueMapFromFile(fullPath);
        addSpriteFramesWithDictionary(dict, textureFileName);
        _loadFileName = plist;
        _textureName = textureFileName;
    }

    void SpriteFrameCache::addSpriteFramesWithFile(const std::string &plist) {
        CCASSERT(plist.size() > 0, "plist filename should not be nullptr");

        std::string fullPath = FileUtils::getInstance()->fullPathForFilename(plist);
        if (fullPath.size() == 0) {
            // return if plist file doesn't exist
            CCLOG("cocos2d: SpriteFrameCache: can not find %s", plist.c_str());
            return;
        }
        
        _loadFileName = plist;
        {

            ValueMap dict = FileUtils::getInstance()->getValueMapFromFile(fullPath);

            string texturePath("");

            if (dict.find("metadata") != dict.end()) {
                ValueMap &metadataDict = dict["metadata"].asValueMap();
                // try to read  texture file name from meta data
                texturePath = metadataDict["textureFileName"].asString();
            }
            
            if (!texturePath.empty()) {
                    texturePath = FileUtils::getInstance()->fullPathFromRelativeFile(texturePath, plist);
            } else {
                // build texture path by replacing file extension
                texturePath = plist;

                // remove .xxx
                size_t startPos = texturePath.find_last_of(".");
                texturePath = texturePath.erase(startPos);

                // append .png
                texturePath = texturePath.append(".png");

                CCLOG("cocos2d: SpriteFrameCache: Trying to use file %s as texture", texturePath.c_str());
            }

            _textureName = texturePath;
            texturePath = FileUtils::getInstance()->fullPathForFilename(texturePath);
            addSpriteFramesWithDictionary(dict, texturePath);
        }
    }

    bool SpriteFrameCache::isSpriteFramesWithFileLoaded(const std::string &plist) const {
        bool result = false;

        return result;
    }

    void SpriteFrameCache::addSpriteFrame(SpriteFrame *frame, const std::string &frameName) {
        CCASSERT(frame, "frame should not be nil");
        _spriteFrames.insert(std::make_pair(frameName, frame));
    }

    void SpriteFrameCache::removeSpriteFrames() {
        _spriteFrames.clear();
        _spriteFramesAliases.clear();
    }

    void SpriteFrameCache::removeUnusedSpriteFrames() {

        //shengsmark 这是一个很sb的清除方式，绝对是最SB的，一张plist，
        // 很多个SpriteFrame，有些有用的有些没有用的，然后要分开删除，如果忽然又要用了岂不是要重新加载这个plist？
        // 更加不能理解的是下面fixme中标示的，全部plist文件的记录全删除了，这个不是绝世大sb么，
        // 触控的设计者一直以为开发者要遵循他们的开发方式，但是他们的又是一个坐井观天的开发方式，真实绝了
        //要清空纹理文件用removeSpriteFramesFromFile行了，这个api被我废了
        //-- by haosheng 2015年10月09日23:24:45


        /*bool removed = false;
        std::vector<std::string> toRemoveFrames;

        for (auto& iter : _spriteFrames)
        {
            SpriteFrame* spriteFrame = iter.second;
            if( spriteFrame->getReferenceCount() == 1 )
            {
                toRemoveFrames.push_back(iter.first);
                spriteFrame->getTexture()->removeSpriteFrameCapInset(spriteFrame);
                CCLOG("cocos2d: SpriteFrameCache: removing unused frame: %s", iter.first.c_str());
                removed = true;
            }
        }

        _spriteFrames.erase(toRemoveFrames);

        // FIXME:. Since we don't know the .plist file that originated the frame, we must remove all .plist from the cache
        if( removed )
        {
            _loadedFileNames->clear();
        }*/
    }


    void SpriteFrameCache::removeSpriteFrameByName(const std::string &name) {
        // explicit nil handling
        if (!(name.size() > 0))
            return;

        // Is this an alias ?
        std::string key = _spriteFramesAliases[name].asString();

        if (!key.empty()) {
            _spriteFrames.erase(key);
            _spriteFramesAliases.erase(key);
        } else {
            _spriteFrames.erase(name);
        }
    }

    void SpriteFrameCache::removeSpriteFramesFromFile(const std::string &plist) {
        std::string fullPath = FileUtils::getInstance()->fullPathForFilename(plist);
        ValueMap dict = FileUtils::getInstance()->getValueMapFromFile(fullPath);
        if (dict.empty()) {
            CCLOG("cocos2d:SpriteFrameCache:removeSpriteFramesFromFile: create dict by %s fail.", plist.c_str());
            return;
        }
        removeSpriteFramesFromDictionary(dict);

        // remove it from the cache
        //set<string>::iterator ret = _loadedFileNames->find(plist);
    }

    void SpriteFrameCache::removeSpriteFramesFromFileContent(const std::string &plist_content) {
        ValueMap dict = FileUtils::getInstance()->getValueMapFromData(plist_content.data(), static_cast<int>(plist_content.size()));
        if (dict.empty()) {
            CCLOG("cocos2d:SpriteFrameCache:removeSpriteFramesFromFileContent: create dict by fail.");
            return;
        }
        removeSpriteFramesFromDictionary(dict);
    }

    void SpriteFrameCache::removeSpriteFramesFromDictionary(ValueMap &dictionary) {
        if (dictionary["frames"].getType() != Value::Type::MAP)
            return;

        ValueMap framesDict = dictionary["frames"].asValueMap();
        //std::vector<std::string> keysToRemove;

        for (const auto &iter : framesDict) {
            if (_spriteFrames.at(iter.first)) {
                //keysToRemove.push_back(iter.first);
                _spriteFrames.erase(iter.first);
            }
        }

        //_spriteFrames.erase(keysToRemove);
    }

    SpriteFrame *SpriteFrameCache::getSpriteFrameByName(const std::string &name) {
        auto it = _spriteFrames.find(name);
        SpriteFrame *frame = it != _spriteFrames.end()?it->second : nullptr;
        
        if (!frame) {
            // try alias dictionary
            std::string key = _spriteFramesAliases[name].asString();
            if (!key.empty()) {
                auto it2  = _spriteFrames.find(key);
                frame = it2 != _spriteFrames.end()?it2->second : nullptr;
                if (!frame) {
                    CCLOG("cocos2d: SpriteFrameCache: Frame '%s' not found", name.c_str());
                }
            }
        }
        return frame;
    }

    void SpriteFrameCache::reloadSpriteFramesWithDictionary(ValueMap &dictionary, Texture2D *texture) {
        ValueMap &framesDict = dictionary["frames"].asValueMap();
        int format = 0;

        // get the format
        if (dictionary.find("metadata") != dictionary.end()) {
            ValueMap &metadataDict = dictionary["metadata"].asValueMap();
            format = metadataDict["format"].asInt();
        }

        // check the format
        CCASSERT(format >= 0 && format <= 3, "format is not supported for SpriteFrameCache addSpriteFramesWithDictionary:textureFilename:");

        for (auto &iter : framesDict) {
            ValueMap &frameDict = iter.second.asValueMap();
            std::string spriteFrameName = iter.first;

            auto it = _spriteFrames.find(spriteFrameName);
            if (it != _spriteFrames.end()) {
                _spriteFrames.erase(it);
            }

            SpriteFrame *spriteFrame = nullptr;

            if (format == 0) {
                float x = frameDict["x"].asFloat();
                float y = frameDict["y"].asFloat();
                float w = frameDict["width"].asFloat();
                float h = frameDict["height"].asFloat();
                float ox = frameDict["offsetX"].asFloat();
                float oy = frameDict["offsetY"].asFloat();
                int ow = frameDict["originalWidth"].asInt();
                int oh = frameDict["originalHeight"].asInt();
                // check ow/oh
                if (!ow || !oh) {
                    CCLOGWARN("cocos2d: WARNING: originalWidth/Height not found on the SpriteFrame. AnchorPoint won't work as expected. Regenerate the .plist");
                }
                // abs ow/oh
                ow = std::abs(ow);
                oh = std::abs(oh);
                // create frame
                spriteFrame = SpriteFrame::createWithTexture(
                        Rect4(x, y, w, h),
                        false,
                        Vec2(ox, oy),
                        Size2((float) ow, (float) oh)
                );
            } else if (format == 1 || format == 2) {
                Rect4 frame = RectFromString(frameDict["frame"].asString());
                bool rotated = false;

                // rotation
                if (format == 2) {
                    rotated = frameDict["rotated"].asBool();
                }

                Vec2 offset = PointFromString(frameDict["offset"].asString());
                Size2 sourceSize = SizeFromString(frameDict["sourceSize"].asString());

                // create frame
                spriteFrame = SpriteFrame::createWithTexture(
                        frame,
                        rotated,
                        offset,
                        sourceSize
                );
            } else if (format == 3) {
                // get values
                Size2 spriteSize = SizeFromString(frameDict["spriteSize"].asString());
                Vec2 spriteOffset = PointFromString(frameDict["spriteOffset"].asString());
                Size2 spriteSourceSize = SizeFromString(frameDict["spriteSourceSize"].asString());
                Rect4 textureRect = RectFromString(frameDict["textureRect"].asString());
                bool textureRotated = frameDict["textureRotated"].asBool();

                // get aliases
                ValueVector &aliases = frameDict["aliases"].asValueVector();

                for (const auto &value : aliases) {
                    std::string oneAlias = value.asString();
                    if (_spriteFramesAliases.find(oneAlias) != _spriteFramesAliases.end()) {
                        CCLOGWARN("cocos2d: WARNING: an alias with name %s already exists", oneAlias.c_str());
                    }

                    _spriteFramesAliases[oneAlias] = Value(spriteFrameName);
                }

                // create frame
                spriteFrame = SpriteFrame::createWithTexture(
                        Rect4(textureRect.origin.x, textureRect.origin.y, spriteSize.width, spriteSize.height),
                        textureRotated,
                        spriteOffset,
                        spriteSourceSize);
            }

            // add sprite frame
            //_spriteFrames.insert(spriteFrameName, spriteFrame);
            _spriteFrames.insert(std::make_pair(spriteFrameName,spriteFrame));
        }
    }
NS_CC_END
