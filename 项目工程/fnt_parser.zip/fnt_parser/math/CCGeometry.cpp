/****************************************************************************
Copyright (c) 2010-2012 cocos2d-x.org
Copyright (c) 2013-2014 Chukong Technologies

http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/

#include "math/CCGeometry.h"

#include <algorithm>
#include <cmath>
#include "ccMacros.h"

// implementation of Vec2
NS_CC_BEGIN

// implementation of Size

Size2::Size2(void) : width(0), height(0)
{
}

Size2::Size2(float w, float h) : width(w), height(h)
{
}

Size2::Size2(const Size2& other) : width(other.width), height(other.height)
{
}

Size2::Size2(const Vec2& point) : width(point.x), height(point.y)
{
}

Size2& Size2::operator= (const Size2& other)
{
    setSize(other.width, other.height);
    return *this;
}

Size2& Size2::operator= (const Vec2& point)
{
    setSize(point.x, point.y);
    return *this;
}

Size2 Size2::operator+(const Size2& right) const
{
    return Size2(this->width + right.width, this->height + right.height);
}

Size2 Size2::operator-(const Size2& right) const
{
    return Size2(this->width - right.width, this->height - right.height);
}

Size2 Size2::operator*(float a) const
{
    return Size2(this->width * a, this->height * a);
}

Size2 Size2::operator/(float a) const
{
	CCASSERT(a!=0, "CCSize division by 0.");
    return Size2(this->width / a, this->height / a);
}

void Size2::setSize(float w, float h)
{
    this->width = w;
    this->height = h;
}

bool Size2::equals(const Size2& target) const
{
    return (std::abs(this->width  - target.width)  < FLT_EPSILON)
        && (std::abs(this->height - target.height) < FLT_EPSILON);
}

const Size2 Size2::ZERO = Size2(0, 0);

// implementation of Rect4

Rect4::Rect4(void)
{
    setRect(0.0f, 0.0f, 0.0f, 0.0f);
}

Rect4::Rect4(float x, float y, float width, float height)
{
    setRect(x, y, width, height);
}
Rect4::Rect4(const Vec2& pos, const Size2& dimension)
{
    setRect(pos.x, pos.y, dimension.width, dimension.height);
}

Rect4::Rect4(const Rect4& other)
{
    setRect(other.origin.x, other.origin.y, other.size.width, other.size.height);
}

Rect4& Rect4::operator= (const Rect4& other)
{
    setRect(other.origin.x, other.origin.y, other.size.width, other.size.height);
    return *this;
}

void Rect4::setRect(float x, float y, float width, float height)
{
    // CGRect4 can support width<0 or height<0
    // CCASSERT(width >= 0.0f && height >= 0.0f, "width and height of Rect4 must not less than 0.");

    origin.x = x;
    origin.y = y;

    size.width = width;
    size.height = height;
}

bool Rect4::equals(const Rect4& Rect4) const
{
    return (origin.equals(Rect4.origin) &&
            size.equals(Rect4.size));
}

float Rect4::getMaxX() const
{
    return origin.x + size.width;
}

float Rect4::getMidX() const
{
    return origin.x + size.width / 2.0f;
}

float Rect4::getMinX() const
{
    return origin.x;
}

float Rect4::getMaxY() const
{
    return origin.y + size.height;
}

float Rect4::getMidY() const
{
    return origin.y + size.height / 2.0f;
}

float Rect4::getMinY() const
{
    return origin.y;
}

bool Rect4::containsPoint(const Vec2& point) const
{
    bool bRet = false;

    if (point.x >= getMinX() && point.x <= getMaxX()
        && point.y >= getMinY() && point.y <= getMaxY())
    {
        bRet = true;
    }

    return bRet;
}

bool Rect4::intersectsRect(const Rect4& Rect4) const
{
    return !(     getMaxX() < Rect4.getMinX() ||
             Rect4.getMaxX() <      getMinX() ||
                  getMaxY() < Rect4.getMinY() ||
             Rect4.getMaxY() <      getMinY());
}

bool Rect4::intersectsCircle(const Vec2& center, float radius) const
{
    Vec2 Rect4angleCenter((origin.x + size.width / 2),
                         (origin.y + size.height / 2));
    
    float w = size.width / 2;
    float h = size.height / 2;
    
    float dx = std::abs(center.x - Rect4angleCenter.x);
    float dy = std::abs(center.y - Rect4angleCenter.y);
    
    if (dx > (radius + w) || dy > (radius + h))
    {
        return false;
    }
    
    Vec2 circleDistance(std::abs(center.x - origin.x - w),
                        std::abs(center.y - origin.y - h));
    
    if (circleDistance.x <= (w))
    {
        return true;
    }
    
    if (circleDistance.y <= (h))
    {
        return true;
    }
    
    float cornerDistanceSq = powf(circleDistance.x - w, 2) + powf(circleDistance.y - h, 2);
    
    return (cornerDistanceSq <= (powf(radius, 2)));
}

void Rect4::merge(const Rect4& Rect4)
{
    float minX = std::min(getMinX(), Rect4.getMinX());
    float minY = std::min(getMinY(), Rect4.getMinY());
    float maxX = std::max(getMaxX(), Rect4.getMaxX());
    float maxY = std::max(getMaxY(), Rect4.getMaxY());
    setRect(minX, minY, maxX - minX, maxY - minY);
}

const Rect4 Rect4::ZERO = Rect4(0, 0, 0, 0);

NS_CC_END
