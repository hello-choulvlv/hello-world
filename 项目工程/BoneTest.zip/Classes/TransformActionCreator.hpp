//
//  TransformActionCreator.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/4.
//
//

#ifndef TransformActionCreator_hpp
#define TransformActionCreator_hpp

#include "TransformAction.hpp"
#include "pugixml.hpp"

class TransformActionCreator
{
public:
    static TransformActionCreator* getInstance();
    static TransformActionCreator* _instance;
    TransformAction* createActionWithConfig(pugi::xml_node& config);
    TransformAction* buildAction(pugi::xml_node& actionConfig);
    TransformAction* buildSwing(pugi::xml_node& actionConfig);
    TransformAction* buildSequence(pugi::xml_node& actionConfig);
    TransformAction* buildSpawn(pugi::xml_node& actionConfig);
    TransformAction* buildPosition(pugi::xml_node& actionConfig);
    TransformAction* buildDirection(pugi::xml_node& actionConfig);
    TransformAction* buildRoll(pugi::xml_node& actionConfig);
    TransformAction* buildScale(pugi::xml_node& actionConfig);
    
    cocos2d::Vec3 stringToVec3(std::string str);
    float stringToNumber(std::string str);

};

#endif /* TransformActionCreator_hpp */
