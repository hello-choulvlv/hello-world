////
#ifndef __TROOP_SET_MANAGER_H__
#define __TROOP_SET_MANAGER_H__

#include "pugixml.hpp"
#include "math/Vec3.h"
#include <vector>
#include <list>
#include <map>
#include "TransformActionCreator.hpp"

//#define SERVER_SIDE

class TypeSelector
{
public:
    TypeSelector();
    void setParam(int id, std::vector<int>& types, std::vector<int>& weights);
    int getType();
    
private:
    std::vector<int> _types;
    std::vector<int> _weights;
    int _total;
    int _typeNumber;
    int _id;
};

struct RandomTyped
{
    RandomTyped();
    void genType(int parentType);
    
    int typeSelectorId;
    bool fixType;
    int type;
};

template<class T>
struct DerivedProperty
{
    DerivedProperty() :changed(false) {}
    DerivedProperty(T const & v) :changed(false), value(v) {}
    
    DerivedProperty<T>& operator=(DerivedProperty<T>& r) {
        
        if (r.changed)
        {
            changed = true;
            value = r.value;
        }
        
        return *this;
    };
    
    DerivedProperty<T>& operator=(T const & r) {
        
        changed = true;
        value = r;
        
        return *this;
    };
    
    
    T get() { return value; }
    void set(T const & v) { value = v; changed = true; };
    
    T value;
    bool changed;
};

struct GenerateParam
{
    enum MOTION_TYPE { PATH, DIRECTION };
    
    GenerateParam()
    : belong(true)
    , pathId(0)
    , motionType(MOTION_TYPE::DIRECTION)
    , position(cocos2d::Vec3(0, 0, 0))
    , direction(cocos2d::Vec3(1, 0 ,0))
    , speed(0)
    , duration(0)
    , type(0) {}
    
    GenerateParam& operator=(GenerateParam const& r) {
        
        GenerateParam& temp = const_cast<GenerateParam&>(r);
        
        belong = temp.belong;
        pathId = temp.pathId;
        motionType = temp.motionType;
        position = temp.position;
        direction = temp.direction;
        speed = temp.speed;
        duration = temp.duration;
        type = temp.type;
        
        return *this;
    };
    
    GenerateParam& operator=(GenerateParam& r) {
        
        belong = r.belong;
        pathId = r.pathId;
        motionType = r.motionType;
        position = r.position;
        direction = r.direction;
        speed = r.speed;
        duration = r.duration;
        type = r.type;
        
        return *this;
    };
    
    DerivedProperty<bool> belong;
    DerivedProperty<int> pathId;
    DerivedProperty<MOTION_TYPE> motionType;
    DerivedProperty<cocos2d::Vec3> position;
    DerivedProperty<cocos2d::Vec3> direction;
    DerivedProperty<float> speed;
    DerivedProperty<float> duration;
    DerivedProperty<int> type;
};

struct SpawnElement : public RandomTyped
{
    enum CATEGORY {FISH, GROUP};
    
    SpawnElement() : category(FISH) {}
    
    CATEGORY category;
    GenerateParam param;
    
    std::map<int, GenerateParam> specialPatterns;
};

struct SpawnCluster : public RandomTyped
{
    GenerateParam param;
    std::vector<SpawnElement> elements;
};

struct GeneratorConfig : public RandomTyped
{
    GeneratorConfig() : delay(0), spawnInterval(0), spawnCount(0), spawnCircle(0){}
    
    float delay;
    float spawnInterval;
    float spawnCount;
    int spawnCircle;
    std::vector<SpawnCluster> clusters;
    
    GenerateParam param;
};

struct GroupConfig
{
    int id;
    TransformAction* transform;
    std::vector<GeneratorConfig> generator;
};

struct TroopConfig
{
    int							id;
    std::vector<std::wstring>	describ;
    std::vector<SpawnElement>	startGroups;
};

class TroopSetManager
{
public:
    static TroopSetManager* GetInstance();
    bool LoadTroop(std::string szFileName);
    
    GroupConfig* GetGroup(int id);
    TroopConfig* GetTroop(int id);
    TypeSelector* GetSelector(int id);
    
    void clear();
    
private:
    static TroopSetManager* _instance;
	TroopSetManager();
	virtual ~TroopSetManager();
    

private:
	bool LoadSelector(pugi::xml_document& doc);
	bool LoadTroopSet(pugi::xml_document& doc);
    bool LoadGroupDefinition(pugi::xml_document& doc);
    bool LoadGroup(pugi::xml_node& xmlGroup, GroupConfig& config);
    bool LoadTransform(pugi::xml_node& xmlTransform, TransformAction*& config);
    bool LoadGenerator(pugi::xml_node& xmlGenerator, GeneratorConfig& config);
    bool LoadCircle(pugi::xml_node& xmlCircle, SpawnCluster& config, GenerateParam param);
    bool LoadLine(pugi::xml_node& xmlLine, SpawnCluster& config, GenerateParam param);
    bool LoadElement(pugi::xml_node& xmlElement, SpawnElement& config, GenerateParam param);
    bool LoadElement(pugi::xml_node& xmlElement, SpawnElement& config, GenerateParam param, cocos2d::Vec3 startPosition, cocos2d::Vec3 startDirection);
    bool LoadSpecialPattern(pugi::xml_node& xmlElement, SpawnElement& config);
    bool LoadPoint(pugi::xml_node& xmlPoint, SpawnCluster& config, GenerateParam param);
    bool LoadGenerateParam(pugi::xml_node& xmlData, GenerateParam& param);

private:
	std::map<int, TroopConfig>	m_Troops;
	std::map<int, TypeSelector>	m_selectors;
    std::map<int, GroupConfig>  m_Groups;
};

#endif
