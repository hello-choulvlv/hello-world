//
//  CollisionAreaEditor.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/24.
//
//

#ifndef CollisionAreaEditor_hpp
#define CollisionAreaEditor_hpp

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "RctEditor.hpp"
#include "json/document.h"

class DrawNode3D;
class ModelInspector;
class ActionController;

namespace CollisionEditor {
    struct
    {
        cocos2d::Vec3 ZERO = cocos2d::Vec3(0, 0, 0);
        cocos2d::Vec3 IDENTITY = cocos2d::Vec3(1.0, 1.0, 1.0);
    }DEFAULT;
}

using namespace CollisionEditor;

struct Hex
{
    cocos2d::Vec3 p1 = DEFAULT.ZERO;
    cocos2d::Vec3 p2 = DEFAULT.ZERO;
    cocos2d::Vec3 p3 = DEFAULT.ZERO;
    cocos2d::Vec3 p4 = DEFAULT.ZERO;
    cocos2d::Vec3 p5 = DEFAULT.ZERO;
    cocos2d::Vec3 p6 = DEFAULT.ZERO;
    cocos2d::Vec3 p7 = DEFAULT.ZERO;
    cocos2d::Vec3 p8 = DEFAULT.ZERO;
    cocos2d::Vec3 scale = DEFAULT.IDENTITY;
    cocos2d::Vec3 translation = DEFAULT.ZERO;
    cocos2d::Vec3 rotation = DEFAULT.ZERO;

};

struct Rct
{
    cocos2d::Vec3 center = DEFAULT.ZERO;
    cocos2d::Vec3 axisX = cocos2d::Vec3(1, 0, 0);
    cocos2d::Vec3 axisY = cocos2d::Vec3(0, 1, 0);
    cocos2d::Vec3 axisZ = cocos2d::Vec3(0, 0, 1);
    cocos2d::Vec3 extension = DEFAULT.ZERO;
    cocos2d::Vec3 scale = DEFAULT.IDENTITY;
    cocos2d::Vec3 translation = DEFAULT.ZERO;
    cocos2d::Vec3 rotation = DEFAULT.ZERO;
};

struct SINGLE_BINDING
{
    enum TYPE {HEX, RET};
    
    TYPE type = TYPE::RET;
    struct Hex h;
    struct Rct r;
    
    cocos2d::Mat4 buildTransformMat(cocos2d::Vec3& rotation, cocos2d::Vec3& scale, cocos2d::Vec3& translation)
    {
        cocos2d::Mat4 transform;
        transform.rotate(cocos2d::Quaternion(cocos2d::Vec3(1, 0, 0), rotation.x)
                         * cocos2d::Quaternion(cocos2d::Vec3(0, 1, 0), rotation.y)
                         * cocos2d::Quaternion(cocos2d::Vec3(0, 0, 1), rotation.z));
        transform.scale(scale);
        transform.translate(translation);
        
        return transform;
    }
};

class MenuItemFrameLabel : public cocos2d::ui::Widget
{
    class COLOR_SCHEME;
public:
    enum TYPE {TRIGGER, ACTIVATOR};
    
public:
    static MenuItemFrameLabel* create();
    
public:
    MenuItemFrameLabel() {};
    virtual ~MenuItemFrameLabel() {};
    
public:
    virtual bool init();
    virtual void activate();
    virtual void deactivate();
    virtual void selected();
    virtual void unselected();
    virtual void setContentSize(const cocos2d::Size& contentSize);
    virtual void onEnter();
    virtual void onExit();
    
    void setString(std::string str);
    std::string getString();
    void setActivateCallback(std::function<void ()> onActivate);
    void setDeactivateCallback(std::function<void ()> onDeactivate);
    void setLoseFocusCallback(std::function<void (cocos2d::ui::Widget*, cocos2d::ui::Widget*)> onLoseFocus);
    void setGetFocusCallback(std::function<void (cocos2d::ui::Widget*, cocos2d::ui::Widget*)> onGetFocus);
    void clickToDeactivate(bool willDo);
    void setFontSize(int fontSize);
    void setType(TYPE type);
    
private:
    void changeColor(COLOR_SCHEME& strategy);
    void onFocusChanged(cocos2d::ui::Widget* loseFocus, cocos2d::ui::Widget* getFocus);
    void registerTouchEventListener();
    void registerFocusEventListener();
    
private:
    cocos2d::DrawNode* __frame;
    cocos2d::Label* __label;
    std::function<void ()> __onActivate;
    std::function<void ()> __onDeactivate;
    std::function<void (cocos2d::ui::Widget*, cocos2d::ui::Widget*)> __onLoseFocus;
    std::function<void (cocos2d::ui::Widget*, cocos2d::ui::Widget*)> __onGetFocus;
    bool __activated;
    bool __moved;
    bool __clickToDeactivate;
    cocos2d::Vec2 __lastTouchPosition;
    float __moveAccumulator;
    cocos2d::EventListenerFocus* __focusListener;
    TYPE __type;
    
    struct COLOR_SCHEME{
        
        cocos2d::Color4F _colorFrame;
        cocos2d::Color4F _colorBackground;
        cocos2d::Color3B _colorLabel;
        
    }COLOR_ACTIVATED_SELECTED, COLOR_DEACTIVATED_SELECTED, COLOR_ACTIVATED, COLOR_DEACTIVATED;
};

class EditorUI : public cocos2d::Node
{
public:
    EditorUI();
    virtual ~EditorUI();
    
public:
    static EditorUI* create();
    virtual bool init();
    void loadBones(cocos2d::Skeleton3D* skeleton);
    void loadBindings(int boneIndex, std::vector<SINGLE_BINDING>& bindings);
    void loadValue(SINGLE_BINDING& binding);
    void reset();
    void setSelectBoneCallback(std::function<void (int)> onSelectBone);
    void setSelectBindingCallback(std::function<void (int, int)> onSelectBinding);
    void setAddBindingCallback(std::function<void (int)> onAddBinding);
    void setRemoveBindingCallback(std::function<void (int, int)> onRemoveBinding);
    void setValueChangeCallback(std::function<void (int, int, SINGLE_BINDING&)> onValueChange);
    std::vector<cocos2d::Vec2> getBoneItemPositions();
    
private:
    MenuItemFrameLabel* createBoneItem(std::string name, int index);
    MenuItemFrameLabel* createBindingItem(int boneIndex, int bindingIndex, SINGLE_BINDING::TYPE type);
    cocos2d::ui::Widget* createAddItem(int boneIndex);
    MenuItemFrameLabel* createItem();
    cocos2d::ui::Widget* createMarginItem();
    void detailBoneItem(int boneIndex, int bindingIndex);
    void recoverBoneItem(int boneIndex);
    void selectBone(int boneIndex);
    void unselectBone();
    void selectBinding(int boneIndex, int bindingIndex);
    void unselectBinding();
    bool focusInsideList(cocos2d::ui::Widget* widget, cocos2d::ui::ListView* list);
    bool focusOnItem(cocos2d::ui::Widget* widget, cocos2d::ui::ListView* list);
    void showBindings(bool willShow);
    std::string truncateString(std::string original);
    void rearrangeListView(cocos2d::ui::ListView* listView);
    void retainItems(cocos2d::Vector<cocos2d::ui::Widget*>& items);
    void pushAndReleaseItems(cocos2d::Vector<cocos2d::ui::Widget*>& items, cocos2d::ui::ListView* listView);
    void onRctEditorValueChange(Rct);
    
private:
    cocos2d::ui::ListView* __listViewBone;
    cocos2d::ui::ListView* __listViewBinding;
    cocos2d::Skeleton3D* __skeleton;
    
    int __selectedBoneIndex;
    int __selectedBindingIndex;
    
    std::function<void (int)> __onSelectBone;
    std::function<void (int, int)> __onSelectBinding;
    std::function<void (int)> __onAddBinding;
    std::function<void (int, int)> __onRemoveBinding;
    std::function<void (int, int, SINGLE_BINDING&)> __onValueChange;
    
    const cocos2d::Size NORMAL_SIZE;
    const cocos2d::Size DETAILED_SIZE;
    
    RctEditor* __rctEditor;
};

class BindingPresentor : public cocos2d::Node
{
public:
    static BindingPresentor* create();
    
public:
    BindingPresentor();
    virtual ~BindingPresentor();
    
public:
    void updateWithSkeleton(cocos2d::Skeleton3D* skeleton);
    void setContent(cocos2d::Skeleton3D* skeleton, std::vector<std::vector<SINGLE_BINDING>>& bindings);
    void addBinding(int boneIndex, SINGLE_BINDING& binding);
    void removeBinding(int boneIndex, int bindingIndex);
    void changeBinding(int boneIndex, int bindingIndex, SINGLE_BINDING& binding);
    void emphasizeBone(int boneIndex);
    void deemphasizeBone(int boneIndex);
    void emphasizeBinding(int boneIndex, int bindingIndex);
    void deemphasizeBinding(int boneIndex, int bindingIndex);
    std::vector<cocos2d::Vec2> getBoneDrawNodePositions();
    
private:
    struct DRAW_NODE_TREE
    {
        int _index;
        std::vector<DrawNode3D*> _node;
        std::vector<DRAW_NODE_TREE*> _children;
    };
    
    struct COLOR_SCHEME
    {
        cocos2d::Color4F _colorBone;
        cocos2d::Color4F _colorBinding;
        
    }NORMAL, RELATED, HIGHLIGHT;
    
private:
    DRAW_NODE_TREE* drawBoneConnRecursively(cocos2d::Bone3D* bone, cocos2d::Skeleton3D* skeleton);
    void setSkeleton(cocos2d::Skeleton3D* skeleton);
    void setBinding(std::vector<std::vector<SINGLE_BINDING>>& bindings);
    DrawNode3D* drawRct(SINGLE_BINDING& binding, DrawNode3D* node = nullptr);
    DrawNode3D* drawHex(SINGLE_BINDING& binding, DrawNode3D* node = nullptr);
    void updateBoneTransforms(cocos2d::Skeleton3D* skeleton);
    void updateTreeRecursively(DRAW_NODE_TREE* treeNode);
    void updatePositionDrawNodes();
    void updateBindingDrawNodes();
    void clear();
    void clearTreeRecursively(DRAW_NODE_TREE* root);
    DRAW_NODE_TREE* findTreeNodeByIndex(DRAW_NODE_TREE* root, int index);
    bool isBoneAvailable(int boneIndex);
    bool isBindingAvailable(int boneIndex, int bindingIndex);
    void setNodeColor(DrawNode3D* node, cocos2d::Color4F color);
    void setBoneConnNodeColor(int boneIndex, cocos2d::Color4F color);
    void setBoneBindingColor(int boneIndex, cocos2d::Color4F color);
    DrawNode3D* createBindingDrawNode();
    
private:
    DRAW_NODE_TREE* __boneConnDrawNodeTree;
    std::vector<DrawNode3D*> __bonePositionDrawNodes;
    std::vector<std::vector<DrawNode3D*>> __bindingDrawNodes;
    std::vector<cocos2d::Mat4> __boneTransform;
    
    int __boneIndexHighlight;
    int __bindingIndexHighLigt;
};

class CollisionAreaEditor : public cocos2d::Node
{
public:
    CollisionAreaEditor();
    virtual ~CollisionAreaEditor();
    
public:
    static CollisionAreaEditor* create();
    
public:
    virtual bool init();
    
public:
    void setData(std::string dataFileName);
    bool saveBindingFile(std::string fileName);
    bool loadBindingFile(std::string fileName);
    
private:
    void initIndicationLine();
    void updateIndicationLine();
    void loadHex(Hex& hex, rapidjson::Value& jsonValue);
    void saveHex(Hex& hex, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator);
    void loadRct(Rct& rct, rapidjson::Value& jsonValue);
    void saveRct(Rct& rct, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator);
    void loadVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue);
    void saveVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator);
    void loadSingleBinding(SINGLE_BINDING& binding, rapidjson::Value& jsonValue);
    void saveSingleBinding(SINGLE_BINDING& binding, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator);
    void runAlertAnimation(std::string content, cocos2d::Color3B color);
    void bindModelAnimation();
    
    void onUISelectBone(int boneIndex);
    void onUISelectBinding(int boneIndex, int bindingIndex);
    void onUIAddBinding(int boneIndex);
    void onUIRemoveBinding(int boneIndex, int bindingIndex);
    void onUIValueChange(int boneIndex, int bindingIndex, SINGLE_BINDING& newValue);
    void onSaveClicked();
    void onToggleUI();
    void onToggleName();
    void onOpacityChanged();
    void onFrameStep();
    
    void addSearchPaths();
    
private:
    
    MenuItemFrameLabel* __saveButton;
    MenuItemFrameLabel* __uiToggleButton;
    MenuItemFrameLabel* __nameToggleButton;
    TextFieldEx* __modelOpacityInput;
    EditorUI* __ui;
    BindingPresentor* __presentor;
    ModelInspector* __inspector;
    ActionController* __actionController;
    cocos2d::Node* __indicationLineContainer;
    
    bool __showName;
    
    std::string __dataFileName;
    std::vector<std::vector<SINGLE_BINDING>> __bindings;
    cocos2d::Sprite3D* __model;
};

#endif /* CollisionAreaEditor_hpp */
