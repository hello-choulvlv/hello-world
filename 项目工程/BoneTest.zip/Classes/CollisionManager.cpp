//
//  CollisionManager.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/22.
//
//

#include "CollisionManager.hpp"
#include "DrawNode3D.hpp"
#include "json/writer.h"
#include "json/stringbuffer.h"

using namespace cocos2d;

CollisionManager* CollisionManager::__sInstance = nullptr;

CollisionManager* CollisionManager::getInstance()
{
    if(__sInstance == nullptr)
    {
        __sInstance = new SimpleCollisionManager();
    }
    
    return __sInstance;
}

void CollisionManager::destroyInstance()
{
    delete __sInstance;
    __sInstance = nullptr;
}


SimpleCollisionManager::SimpleCollisionManager()
{
    initConstants();
    
    allocateCaches();
    
    readConfig("shayu", COLLISION_AREA_TYPE::FISH);
    readConfig("bianfuyu", COLLISION_AREA_TYPE::FISH);
    readConfig("dianmanyu", COLLISION_AREA_TYPE::FISH);
    readConfig("jianyu", COLLISION_AREA_TYPE::FISH);
    readConfig("bullet_100", COLLISION_AREA_TYPE::BULLET);
}

SimpleCollisionManager::~SimpleCollisionManager()
{
    deallocateCaches();
}

CollisionManager::CollisionArea* SimpleCollisionManager::claimCollisionArea(std::string configName)
{
    for(int type = 0; type < COLLISION_AREA_TYPE::AREA_TYPE_COUNT; type++)
    {
        auto iter = _configs[type].find(configName);
        
        if(iter !=  _configs[type].end())
        {
            CollisionAreaTyped* area = new CollisionAreaTyped();
            area->_areaType = (COLLISION_AREA_TYPE)type;
            area->__config = &iter->second;
            
            return area;
        }
    }
    
    return nullptr;
}


void SimpleCollisionManager::reclaimCollisionArea(CollisionArea* collisionArea)
{
    unregisterArea(collisionArea);
    delete collisionArea;
}

void SimpleCollisionManager::registerArea(CollisionManager::CollisionArea* collisionArea)
{
    _registeredAreas.push_back(collisionArea);
}

void SimpleCollisionManager::unregisterArea(CollisionManager::CollisionArea* collisionArea)
{
    for(auto iter = _registeredAreas.begin(); iter != _registeredAreas.end(); iter++)
    {
        if(*iter == collisionArea)
        {
            _registeredAreas.erase(iter);
        }
    }
}

void SimpleCollisionManager::initConstants()
{
    CONST._shapeCacheSize = 300;
    CONST._regionCacheSize = 50;
    CONST._regionX = 9;
    CONST._regionY = 5;
    CONST._regionSize = 256;
}

void SimpleCollisionManager::allocateCaches()
{
    _configs.resize(COLLISION_AREA_TYPE::AREA_TYPE_COUNT);
    
    _transformedShapes.reserve(CONST._shapeCacheSize);
    
    _divisions.resize(CONST._regionX * CONST._regionY);
    for(int i = 0; i < CONST._regionX * CONST._regionY; i++)
    {
        _divisions[i].resize(COLLISION_AREA_TYPE::AREA_TYPE_COUNT);
        
        for(int i = 0; i < COLLISION_AREA_TYPE::AREA_TYPE_COUNT; i++)
        {
            _divisions[i].reserve(CONST._regionCacheSize);
        }
    }
}

void SimpleCollisionManager::deallocateCaches()
{
    for(auto cacheIter = _configs.begin(); cacheIter != _configs.end(); cacheIter++)
    {
        ConfigCache& cache = *cacheIter;
        
        for(auto listIter = cache.begin(); listIter != cache.end(); listIter++)
        {
            ConfigList& config = (*listIter).second;
            
            for(auto dataIter = config.begin(); dataIter != config.end(); dataIter++)
            {
                delete (*dataIter).second;
            }
        }
    }
}

void SimpleCollisionManager::clearCaches()
{
    _transformedShapes.clear();
    
    for(int regionIndex = 0; regionIndex < CONST._regionX * CONST._regionY; regionIndex++)
    {
        for(int typeIndex = 0; typeIndex < COLLISION_AREA_TYPE::AREA_TYPE_COUNT; typeIndex++)
        {
            _divisions[regionIndex][typeIndex].clear();
        }
    }
}

void SimpleCollisionManager::update(float dt)
{
    clearCaches();
    
    for(auto areaIter = _registeredAreas.begin(); areaIter != _registeredAreas.end(); areaIter++)
    {
        Sprite3D* bindingNode = (*areaIter)->__node;
        ConfigList& configList = *(*areaIter)->__config;
        COLLISION_AREA_TYPE areaType = static_cast<CollisionAreaTyped*>(*areaIter)->_areaType;
        Mat4 nodeToWorldTransform = bindingNode->getNodeToWorldTransform();
        Skeleton3D* skeleton = bindingNode->getSkeleton();
        
        for(auto dataIter = configList.begin(); dataIter != configList.end(); dataIter++)
        {
            ConfigData& data = (*dataIter);
            CollisionShape::Shape* shape = data.second;
            Bone3D* bone = getBone(skeleton, data.first);
            Mat4 boneWorldTransform = nodeToWorldTransform;
            if(bone)
            {
                boneWorldTransform = nodeToWorldTransform * bone->getWorldMat();
            }

            TransformedShapeInfo info;
            info.first._parent = (*areaIter);
            
            if(shape->_type == CollisionShape::SHAPE_TYPE::CRL)
            {
                pushShape(info, shape->_c, boneWorldTransform);
                settleShape(_transformedShapes.back(), areaType);
            }
            else if(shape->_type == CollisionShape::SHAPE_TYPE::RCT)
            {
                pushShape(info, shape->_r, boneWorldTransform);
                settleShape(_transformedShapes.back(), areaType);
            }
            else if(shape->_type == CollisionShape::SHAPE_TYPE::HEX)
            {
                pushShape(info, shape->_h, boneWorldTransform);
                settleShape(_transformedShapes.back(), areaType);
            }
        }
    }
    
    for(int regionIndex = 0; regionIndex < CONST._regionX * CONST._regionY; regionIndex++)
    {
        std::vector<TransformedShapeInfo*> bullets = _divisions[regionIndex][COLLISION_AREA_TYPE::BULLET];
        std::vector<TransformedShapeInfo*> fishes = _divisions[regionIndex][COLLISION_AREA_TYPE::FISH];
        
        for(int bulletIndex = 0; bulletIndex < bullets.size(); bulletIndex++)
        {
            for(int fishIndex = 0; fishIndex < fishes.size(); fishIndex++)
            {
                if(intersectAABB(bullets[bulletIndex]->second, fishes[fishIndex]->second))
                {
                    if(circleHexSAT(bullets[bulletIndex]->first, fishes[fishIndex]->first))
                    {
                        printf("%d", rand());
                    }
                }
            }
        }
    }
}

cocos2d::Bone3D* SimpleCollisionManager::getBone(cocos2d::Skeleton3D* skeleton, int boneIndex)
{
    if(skeleton)
    {
        return skeleton->getBoneByIndex(boneIndex);
    }
    else
    {
        return nullptr;
    }
}

void SimpleCollisionManager::pushShape(TransformedShapeInfo& info, CollisionShape::R& r, cocos2d::Mat4& transform)
{
    Vec3 vertex[8];
    vertex[0] = r._center + r._x + r._y + r._z;
    vertex[1] = r._center + r._x - r._y + r._z;
    vertex[2] = r._center - r._x - r._y + r._z;
    vertex[3] = r._center - r._x + r._y + r._z;
    vertex[4] = r._center + r._x + r._y - r._z;
    vertex[5] = r._center + r._x - r._y - r._z;
    vertex[6] = r._center - r._x - r._y - r._z;
    vertex[7] = r._center - r._x + r._y - r._z;
    
    for(int i = 0; i < 8; i++)
    {
        transform.transformPoint(vertex[i], &vertex[i]);
        info.first._vertex[i] = Camera::getDefaultCamera()->projectGL(vertex[i]);
    }
    
    info.second._maxX = info.second._maxY = -MAXFLOAT;
    info.second._minX = info.second._minY = MAXFLOAT;
    
    for(int i = 0; i < 8; i++)
    {
        info.second._maxX = info.second._maxX > info.first._vertex[i].x ? info.second._maxX : info.first._vertex[i].x;
        info.second._maxY = info.second._maxY > info.first._vertex[i].y ? info.second._maxY : info.first._vertex[i].y;
        info.second._minX = info.second._minX < info.first._vertex[i].x ? info.second._minX : info.first._vertex[i].x;
        info.second._minY = info.second._minY < info.first._vertex[i].y ? info.second._minY : info.first._vertex[i].y;
    }
    
    _transformedShapes.push_back(info);
}

void SimpleCollisionManager::pushShape(TransformedShapeInfo& info, CollisionShape::C& c, cocos2d::Mat4& transform)
{
    Vec3 _tCenter;
    transform.transformPoint(c._center, &_tCenter);
    
    Vec2 _tCenter2D = Camera::getDefaultCamera()->projectGL(_tCenter);
    info.first._vertex[0] = _tCenter2D;
    info.first._vertex[1].x = c._radius;
    
    info.second._maxX = _tCenter2D.x + c._radius;
    info.second._minX = _tCenter2D.x - c._radius;
    info.second._maxY = _tCenter2D.y + c._radius;
    info.second._minY = _tCenter2D.y - c._radius;
    
    _transformedShapes.push_back(info);
}

void SimpleCollisionManager::pushShape(TransformedShapeInfo& info, CollisionShape::H& h, cocos2d::Mat4& transform)
{
    
}

void SimpleCollisionManager::settleShape(TransformedShapeInfo& info, COLLISION_AREA_TYPE& type)
{
    int max_rX = info.second._maxX / CONST._regionSize;
    int max_rY = info.second._maxY / CONST._regionSize;
    int min_rX = info.second._minX / CONST._regionSize;
    int min_rY = info.second._minY / CONST._regionSize;
    
    for(int y = min_rY; y < max_rY + 1; y++)
    {
        for(int x = min_rX; x < max_rX + 1; x++)
        {
            if(y > -1 && y < CONST._regionY && x > -1 && x < CONST._regionX)
            {
                _divisions[x + y * CONST._regionX][type].push_back(&info);
            }
        }
    }
}

bool SimpleCollisionManager::intersectAABB(MinMax& a, MinMax& b)
{
    return ((a._minX >= b._minX && a._minX <= b._maxX) || (b._minX >= a._minX && b._minX <= a._maxX)) &&
    ((a._minY >= b._minY && a._minY <= b._maxY) || (b._minY >= a._minY && b._minY <= a._maxY));
}

bool SimpleCollisionManager::circleHexSAT(ShapeProjected& circle, ShapeProjected& hex)
{
    return (!circleQuadSAT(hex._vertex[0], hex._vertex[1], hex._vertex[2], hex._vertex[3], circle._vertex[0], circle._vertex[1].x) ||
            !circleQuadSAT(hex._vertex[4], hex._vertex[5], hex._vertex[6], hex._vertex[7], circle._vertex[0], circle._vertex[1].x) ||
            !circleQuadSAT(hex._vertex[0], hex._vertex[4], hex._vertex[5], hex._vertex[1], circle._vertex[0], circle._vertex[1].x) ||
            !circleQuadSAT(hex._vertex[1], hex._vertex[5], hex._vertex[6], hex._vertex[2], circle._vertex[0], circle._vertex[1].x) ||
            !circleQuadSAT(hex._vertex[2], hex._vertex[6], hex._vertex[7], hex._vertex[3], circle._vertex[0], circle._vertex[1].x) ||
            !circleQuadSAT(hex._vertex[3], hex._vertex[7], hex._vertex[4], hex._vertex[0], circle._vertex[0], circle._vertex[1].x));
}

bool SimpleCollisionManager::circleQuadSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius)
{
    return (circleAxisSAT(p1, p2, p3, p4, center, radius) ||
            circleAxisSAT(p2, p3, p4, p1, center, radius) ||
            circleAxisSAT(p3, p4, p1, p2, center, radius) ||
            circleAxisSAT(p4, p1, p2, p3, center, radius) ||
            circleVertexSAT(p1, p2, p3, p4, center, radius) ||
            circleVertexSAT(p2, p3, p4, p1, center, radius) ||
            circleVertexSAT(p3, p4, p1, p2, center, radius) ||
            circleVertexSAT(p4, p1, p2, p3, center, radius));
}

bool SimpleCollisionManager::circleAxisSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius)
{
    Vec2 prependicular = p2 - p1;
    prependicular = Vec2(-prependicular.y, prependicular.x);
    prependicular.normalize();
    
    float proj1 = prependicular.dot(p1);
    float proj3 = prependicular.dot(p3);
    float proj4 = prependicular.dot(p4);
    float min = proj1;
    float max = proj1;
    
    if(proj3 > max)
    {
        max = proj3;
    }
    else if(proj3 < min)
    {
        min = proj3;
    }
    
    if(proj4 > max)
    {
        max = proj4;
    }
    else if(proj4 < min)
    {
        min = proj4;
    }
    
    Vec2 vPositive = center + prependicular * radius;
    Vec2 vNegtive = center - prependicular * radius;
    float pPositive = prependicular.dot(vPositive);
    float pNegtive = prependicular.dot(vNegtive);
    
    if(pNegtive > max || pPositive < min)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool SimpleCollisionManager::circleVertexSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius)
{
    Vec2 prependicular = p1 - center;
    prependicular.normalize();
    
    float proj1 = prependicular.dot(p1);
    float proj2 = prependicular.dot(p2);
    float proj3 = prependicular.dot(p3);
    float proj4 = prependicular.dot(p4);
    float min = proj1;
    float max = proj1;
    
    if(proj2 > max)
    {
        max = proj2;
    }
    else if(proj2 < min)
    {
        min = proj2;
    }
    
    if(proj3 > max)
    {
        max = proj3;
    }
    else if(proj3 < min)
    {
        min = proj3;
    }
    
    if(proj4 > max)
    {
        max = proj4;
    }
    else if(proj4 < min)
    {
        min = proj4;
    }
    
    Vec2 vPositive = center + prependicular * radius;
    Vec2 vNegtive = center - prependicular * radius;
    float pPositive = prependicular.dot(vPositive);
    float pNegtive = prependicular.dot(vNegtive);
    
    if(pNegtive > max || pPositive < min)
    {
        return true;
    }
    else
    {
        return false;
    }
}


bool SimpleCollisionManager::readConfig(std::string configName, COLLISION_AREA_TYPE type)
{
    std::string writablePath = FileUtils::getInstance()->getInstance()->getWritablePath();
    writablePath.append(configName);
    writablePath.append(".json");
    
    Data fileData = FileUtils::getInstance()->getDataFromFile(writablePath);
    if(fileData.getSize() == 0)
    {
        return false;
    }
    
    rapidjson::Document readDoc;
    std::string stringtify = std::string((const char*)fileData.getBytes(), fileData.getSize());
    readDoc.Parse<0>(stringtify.c_str());
    
    if(readDoc.HasParseError())
    {
        printf("## Rapid Json ## %s has parse error \n", configName.c_str());
        return false;
    }
    
    rapidjson::Value& bindingConfig = readDoc["bindingConfig"];
    
    int size = bindingConfig.Capacity();
    
    _configs[type][configName] = ConfigList();
    
    for(int boneIndex = 0; boneIndex < size; boneIndex++)
    {
        rapidjson::Value& boneData = bindingConfig[boneIndex]["bindings"];
        
        for(int bindingIndex = 0; bindingIndex < boneData.Capacity(); bindingIndex++)
        {
            ConfigData data;
            data.first = boneIndex;
            data.second = new CollisionShape::Shape();
            loadConfigData(data, boneData[bindingIndex]);
            _configs[type][configName].push_back(data);
        }
    }
    
    if(readDoc.HasParseError())
    {
        printf("## Rapid Json ## %s has parse error \n", configName.c_str());
        return false;
    }
    
    return true;
}

void SimpleCollisionManager::loadConfigData(ConfigData& data, rapidjson::Value& jsonValue)
{
    int type = jsonValue["type"].GetInt();
    data.second->_type = (CollisionShape::SHAPE_TYPE)type;
    
    if(type == CollisionShape::SHAPE_TYPE::CRL)
    {
        loadCrl(*data.second, jsonValue["crl"]);
    }
    else if(type == CollisionShape::SHAPE_TYPE::RCT)
    {
        loadRct(*data.second, jsonValue["rct"]);
    }
    else if(type == CollisionShape::SHAPE_TYPE::HEX)
    {
        loadHex(*data.second, jsonValue["hex"]);
    }
}

void SimpleCollisionManager::loadHex(CollisionShape::Shape& hex, rapidjson::Value& jsonValue)
{
    
}

void SimpleCollisionManager::loadRct(CollisionShape::Shape& rct, rapidjson::Value& jsonValue)
{
    loadVec3(rct._r._center, jsonValue["center"]);
    
    Vec3 translation;
    Vec3 rotation;
    Vec3 scale;
    Vec3 extension;
    
    loadVec3(extension, jsonValue["extension"]);
    loadVec3(rotation, jsonValue["rotation"]);
    loadVec3(translation, jsonValue["translation"]);
    loadVec3(scale, jsonValue["scale"]);
    
    cocos2d::Mat4 transform;
    transform.rotate(cocos2d::Quaternion(cocos2d::Vec3(1, 0, 0), rotation.x)
                     * cocos2d::Quaternion(cocos2d::Vec3(0, 1, 0), rotation.y)
                     * cocos2d::Quaternion(cocos2d::Vec3(0, 0, 1), rotation.z));
    transform.translate(translation);
    
    transform.transformVector(&rct._r._x);
    transform.transformVector(&rct._r._y);
    transform.transformVector(&rct._r._z);
    transform.transformPoint(&rct._r._center);
    
    rct._r._x = rct._r._x.getNormalized() * extension.x * scale.x;
    rct._r._y = rct._r._y.getNormalized() * extension.y * scale.y;
    rct._r._z = rct._r._z.getNormalized() * extension.z * scale.z;
}

void SimpleCollisionManager::loadCrl(CollisionShape::Shape& crl, rapidjson::Value& jsonValue)
{
    loadVec3(crl._c._center, jsonValue["center"]);
    crl._c._radius = jsonValue["radius"].GetDouble();
}

void SimpleCollisionManager::loadVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue)
{
    vec.x = jsonValue[0].GetDouble();
    vec.y = jsonValue[1].GetDouble();
    vec.z = jsonValue[2].GetDouble();
}
