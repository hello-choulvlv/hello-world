//
//  CollisionTest.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/1.
//
//

#ifndef CollisionTest_hpp
#define CollisionTest_hpp

#include <stdio.h>

#endif /* CollisionTest_hpp */

class DrawNode3D;

class CollisionTest : public cocos2d::Node
{
private:
    struct ABQuad
    {
        cocos2d::Vec2 min;
        cocos2d::Vec2 max;
        
        float percentUp;
        float percentLeft;
        float percentDown;
        float percentRight;
    };
    
    struct CircQuad
    {
        cocos2d::Vec2 min;
        cocos2d::Vec2 max;
        
        float percentPenatration = 0.293;
    };
    
    enum POINT_WINDING {C, AC, ERR};
    
public:
    static CollisionTest* create();
    virtual bool init();
    virtual void onEnter();
    void updater(float dt);
    
private:
    bool circleAxisSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float radius);
    bool circleVertexSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float radius);
    bool circleVertexDistance(cocos2d::Vec2& p1, cocos2d::Vec2& center, float radius);
    
    ABQuad getABQuad(cocos2d::Vec2 (*vertices)[4]);
    CircQuad getCircQuad(cocos2d::Vec2& center, float radius);
    
    bool abIntersect(ABQuad ab, CircQuad circ);
    
    POINT_WINDING getWinding(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4);
    POINT_WINDING getWinding(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3);
    bool test(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float radius);
    bool testEdge(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3);
    bool testVertex(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4);
    
private:
    cocos2d::DrawNode* circle;
    DrawNode3D* obb;
    cocos2d::OBB obbData;
    cocos2d::DrawNode* projectionQuad;
    cocos2d::DrawNode* prepLine;
    std::vector<cocos2d::Label*> pLabel;
    cocos2d::Label* winding;
};
