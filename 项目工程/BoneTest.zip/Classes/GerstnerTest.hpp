//
//  GerstnerTest.hpp
//  BoneTest
//
//  Created by charlie on 2017/9/5.
//
//

#ifndef GerstnerTest_hpp
#define GerstnerTest_hpp

#include <stdio.h>
#include "cocos2d.h"

class DrawNode3D;

class GerstnerTest : public cocos2d::Node {
    
public:
    static GerstnerTest* create();
    virtual bool init();
    virtual void onEnter();
    virtual void onExit();
    virtual void update(float delta);

public:
    void initDrawNode();
    void initWaves();
    void initVertices();
    
    void updateDrawNode();
    void updateWaves(float dt);
    void updateVertices();
    
    void updateStrategySimpleSine();
    void updateStrategyGerstner();
    
public:
    struct WaveParam {
        cocos2d::Vec2 direction;
        float amplitude;
        float speed;
        float waveLength;
        float frequency;
        float amplitudePeriod;
        float phase;
        float timeElapsed;
        float realTimeAmplitude;
    };
    
private:
    static const int RESOLUTION;
    static const int GRID_STEP;
    cocos2d::Vec3** vertices;
    std::vector<WaveParam> waves;
    DrawNode3D* __drawNode;
    float __timeElapsed;
};

#endif /* GerstnerTest_hpp */
