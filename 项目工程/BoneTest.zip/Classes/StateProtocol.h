//
//  StateProtocol.h
//  BoneTest
//
//  Created by charlie on 2017/8/23.
//
//

#ifndef StateProtocol_h
#define StateProtocol_h

class StateProtocol
{
public:
    virtual void retrieveState(float distance,cocos2d::Vec3 &position,cocos2d::Vec3 &tangent) = 0;
};

#endif /* StateProtocol_h */
