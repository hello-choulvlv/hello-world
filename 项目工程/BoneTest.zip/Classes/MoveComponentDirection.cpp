//
//  MoveComponentDirection.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "MoveComponentDirection.hpp"

MoveComponentDirection::MoveComponentDirection()
{
    _distance = 0;
}

MoveComponentDirection::~MoveComponentDirection()
{
    
}

void MoveComponentDirection::retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection)
{
    currentPosition = _start + _direction * _distance;
    currentDirection = _direction;
    
    if(_timeElapsed >= _duration)
    {
        _end = true;
    }
    else
    {
        _end = false;
    }
}


void MoveComponentDirection::setStartPosition(cocos2d::Vec3 position)
{
    _start = position;
}

void MoveComponentDirection::setStartDirection(cocos2d::Vec3 direction)
{
    _direction = direction;
    _direction.normalize();
}

void MoveComponentDirection::setDuration(float duration)
{
    _duration = duration;
}
