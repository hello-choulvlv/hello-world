//
//  PathConfig.hpp
//  BoneTest
//
//  Created by charlie on 2017/8/12.
//
//

#ifndef PathConfig_hpp
#define PathConfig_hpp

#include <stdio.h>
#include "cocos2d.h"

class CubicBezierRoute;

class PathConfig {
    
public:
    static PathConfig* getInstance();
    
private:
    static PathConfig* __instance;
    
private:
    void loadConfigFile();
    void calculatePosition(cocos2d::Vec3& p);
    
public:
    void* getRouteData(int pathId);
    int getRouteType(int pathId);
    
private:
    std::map<int, void*> __routeData;
    std::map<int, int> __routeType;
    
};

#endif /* PathConfig_hpp */
