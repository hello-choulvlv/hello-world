//
//  LineRoute.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/16.
//
//

#include "LineRoute.hpp"

using namespace cocos2d;

LineRoute::LineRoute() :
_points(std::vector<Vec3>()),
_position(0),
_valueCache(Vec3(0, 0, 0)),
_tangentCache(Vec3(0, 0, 0)),
_currentIndex(0)
{
    
}

LineRoute* LineRoute::create()
{
    LineRoute* pRet = new LineRoute();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

void LineRoute::addPoints(std::vector<cocos2d::Vec3>& points)
{
    _points.insert(_points.end(), points.begin(), points.end());
}

cocos2d::Vec3 LineRoute::getDirection(float t)
{
    if(_points.size() > 1)
    {
        return (_points[_currentIndex + 1] - _points[_currentIndex]).getNormalized();
    }
    else
    {
        return Vec3(0, 0, 0);
    }
}

cocos2d::Vec3 LineRoute::getLocation(float t)
{
    if(_points.size() == 1)
    {
        return _points[_currentIndex];
    }
    else if(_points.size() > 1)
    {
        return _points[_currentIndex] * (1 - t) + _points[_currentIndex + 1] * t;
    }
    else
    {
        return Vec3(0, 0);
    }
}

cocos2d::Vec3 LineRoute::getCurrentDirection()
{
    return _tangentCache;
}

cocos2d::Vec3 LineRoute::getCurrentLocation()
{
    return _valueCache;
}

void LineRoute::advanceTo(float t)
{
    t = t < 0 ? 0 : t;
    t = t > 1 ? 1 : t;
    
    _position = t;
    _tangentCache = getDirection(_position);
    _valueCache = getLocation(_position);
}

void LineRoute::advanceBy(float deltaDist)
{
    if(_points.size() > 1)
    {
        while (true) {
            
            float segmentLength = getDirection(_position).length();
            
            _position = _position + segmentLength / deltaDist;
            
            if(_position > 1)
            {
                if(_currentIndex == _points.size() - 1)
                {
                    _position = 1;
                    break;
                }
                else
                {
                    deltaDist = segmentLength * (_position - 1);
                    _position = 0;
                    _currentIndex = _currentIndex + 1;
                }
            }
            else
            {
                break;
            }
            
        }
        
        advanceTo(_position);
    }
}

void LineRoute::reset()
{
    _position = 0;
    _currentIndex = 0;
    _valueCache = getDirection(_position);
    _tangentCache = getLocation(_position);
}

void LineRoute::clear()
{
    _points.clear();
    _position = 0;
    _valueCache = Vec3(0, 0, 0);
    _tangentCache = Vec3(0, 0, 0);
    _currentIndex = 0;
}
