//
//  BoneExtractor.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/17.
//
//

#include "BoneExtractor.hpp"

using namespace cocos2d;

BoneExtractor* BoneExtractor::create()
{
    BoneExtractor* pRet = new BoneExtractor();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

BoneExtractor::BoneExtractor()
{
    
}

BoneExtractor::~BoneExtractor()
{
    
}

int BoneExtractor::getBoneCount()
{
    
}


cocos2d::Bone3D* BoneExtractor::getBone(int index)
{
    
}

cocos2d::Bone3D* getBone(std::string name)
{
    
}

cocos2d::Bone3D* getBonePosition(int index)
{
    
}

cocos2d::Bone3D* getBonePosition(std::string index)
{
    
}

cocos2d::Bone3D* getBonePosition(cocos2d::Bone3D* index)
{
    
}

cocos2d::Mat4 BoneExtractor::getBoneTransform(int index, int filter)
{
    
}

cocos2d::Mat4 getBoneTransform(std::string index, int filter)
{
    
}

cocos2d::Mat4 getBoneTransform(cocos2d::Bone3D* index, int filter)
{
    
}
