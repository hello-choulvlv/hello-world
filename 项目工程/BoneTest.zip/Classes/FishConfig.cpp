//
//  FishConfig.cpp
//  BoneTest
//
//  Created by charlie on 2017/8/11.
//
//

#include "FishConfig.hpp"
#include "pugixml.hpp"


FishConfig* FishConfig::getInstance()
{
    
    if(__instance == nullptr)
    {
        __instance = new FishConfig();
        __instance->loadConfigFile();
    }
    
    return __instance;
}

FishConfig* FishConfig::__instance = nullptr;


void FishConfig::loadConfigFile()
{
    loadFishConfig();
    loadFishVisualConfig();
}

void FishConfig::loadFishConfig()
{
    pugi::xml_document doc;
    
    if(doc.load_file("Fish_New.xml"))
    {
        pugi::xml_node sets = doc.child("FishSet");
        
        auto fishConfigDatas = sets.children("Fish");
        
        for(auto dataIter = fishConfigDatas.begin(); dataIter != fishConfigDatas.end(); dataIter++)
        {
            pugi::xml_node configData = *dataIter;
            int type = configData.attribute("TypeID").as_int();
            int visualType = configData.attribute("VisualID").as_int();
            
            _fishConfigs[type] = visualType;
        }
    }
    else
    {
        printf("Load Fish_New.xml Failed !!!!!!!!!");
    }
}

void FishConfig::loadFishVisualConfig()
{
    pugi::xml_document doc;
    
    if(doc.load_file("Visual_New.xml"))
    {
        pugi::xml_node sets = doc.child("VisualSet");
        
        auto visualConfigDatas = sets.children();
        
        for(auto visualConfigIter = visualConfigDatas.begin(); visualConfigIter != visualConfigDatas.end(); visualConfigIter++)
        {
            pugi::xml_node configData = *visualConfigIter;
            int visualId = configData.attribute("Id").as_int();
            int typeId = configData.attribute("TypeID").as_int();
            
            _fishVisualConfigs[visualId].type = typeId;
            
            if(typeId == 1)
            {
                auto nestedVisuals = configData.children();
                
                for(auto nestedVisualIter = nestedVisuals.begin(); nestedVisualIter != nestedVisuals.end(); nestedVisualIter++)
                {
                    pugi::xml_node nestedVisual = *nestedVisualIter;
                    
                    _fishVisualConfigs[visualId]._nestedID.push_back(nestedVisual.attribute("Id").as_int());
                }
            }
            else if(typeId == 0)
            {
                pugi::xml_node liveData = configData.first_child();
                
                _fishVisualConfigs[visualId].from = liveData.attribute("ffrom").as_int();
                _fishVisualConfigs[visualId].to = liveData.attribute("fto").as_int();
                _fishVisualConfigs[visualId].modelName = liveData.attribute("Image").as_string();
                _fishVisualConfigs[visualId].scale = liveData.attribute("Scale").as_float();
            }
        }
        
    }
    else
    {
        printf("Load Fish_New.xml Failed !!!!!!!!!");
    }
}


FishConfig::FishVisual* FishConfig::getVisualConfigByFishId(int fishId)
{
    if(_fishConfigs.find(fishId) != _fishConfigs.end())
    {
        int visualId = _fishConfigs[fishId];
        
        if(_fishVisualConfigs.find(visualId) != _fishVisualConfigs.end())
        {
            return &_fishVisualConfigs[visualId];
        }
    }
    
    return nullptr;
}
