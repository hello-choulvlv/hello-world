//
//  MoveComponentStill.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "MoveComponentStill.hpp"

MoveComponentStill::MoveComponentStill()
{
    _distance = 0;
}

MoveComponentStill::~MoveComponentStill()
{
    
}

void MoveComponentStill::retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection)
{
    currentPosition = _start;
    currentDirection = _direction;
}

void MoveComponentStill::setStartPosition(cocos2d::Vec3 position)
{
    _start = position;
}

void MoveComponentStill::setStartDirection(cocos2d::Vec3 direction)
{
    _direction = direction;
    _direction.normalize();
}
