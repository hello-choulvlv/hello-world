//
//  MultiViewScene.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/11.
//
//

#ifndef MultiViewScene_hpp
#define MultiViewScene_hpp

#include "cocos2d.h"

class MultiViewScene : public cocos2d::Scene
{
public:
    static MultiViewScene* create();
    MultiViewScene();
    virtual ~MultiViewScene();
};

#endif /* MultiViewScene_hpp */
