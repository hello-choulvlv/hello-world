//
//  AxisEditor.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/11.
//
//

#include "AxisEditor.hpp"
#include "DrawNode3D.hpp"
#include "TouchCollision.hpp"

using namespace cocos2d;

AxisEditor* AxisEditor::create()
{
    AxisEditor* ret = new AxisEditor();
    ret->init();
    ret->autorelease();
    return ret;
}

AxisEditor::AxisEditor()
{
    _value = 0;
    _drawNode = DrawNode3D::create();
    this->addChild(_drawNode);
    
    _touchCollision = TouchCollision::create();
    this->addChild(_touchCollision);
    
    _label = Label::createWithSystemFont("", "", 24);
    this->addChild(_label);
    
    _onValueChanged = [](){};
    
    _min = _max = 0;
}

AxisEditor::~AxisEditor()
{
    
}

void AxisEditor::onEnter()
{
    Node::onEnter();
    
    EventListenerTouchOneByOne* touchEventListener = EventListenerTouchOneByOne::create();
    touchEventListener->onTouchBegan = CC_CALLBACK_2(AxisEditor::onTouchBegan, this);
    touchEventListener->onTouchMoved = CC_CALLBACK_2(AxisEditor::onTouchMoved, this);
    touchEventListener->setSwallowTouches(true);
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(touchEventListener, this);
    
    DrawNode3D* debugDraw = DrawNode3D::create();
    debugDraw->setName("debugDraw");
    this->addChild(debugDraw);
}

void AxisEditor::onExit()
{
    Node::onExit();
    
    this->getEventDispatcher()->removeEventListenersForTarget(this);
}

float AxisEditor::getValue()
{
    return _value;
}

void AxisEditor::setValue(float value)
{
    if(isfinite(value))
    {
        if(value > _max)
        {
            _value = _max;
        }
        else if(value < _min)
        {
            _value = _min;
        }
        else
        {
            _value = value;
        }
        
        _onValueChanged();
    }
    else
    {
        throw FloatException();
    }
}

void AxisEditor::update(float dt)
{
}

bool AxisEditor::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event)
{
    if(_touchCollision->touchHit(touch->getLocation()))
    {
        try {
            _startPosition = getIntersect(touch->getLocation());
            _startValue = _value;
            return true;
        }
        catch(FloatException)
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

void AxisEditor::onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* event)
{
    try {
        cocos2d::Vec3 currentPosition = getIntersect(touch->getLocation());
        Mat4 nodeTransform = getWorldToNodeTransform();
        Vec3 nodeStart = _startPosition;
        Vec3 nodeCurrent = currentPosition;
        nodeTransform.transformPoint(&nodeStart);
        nodeTransform.transformPoint(&nodeCurrent);
        
//        this->getChildByName<DrawNode3D*>("debugDraw")->drawLine(Vec3(0, 0, 0), nodeCurrent, Color4F(1.0, 0.0, 0.0, 1.0));
        
        setValue(_startValue + getProjectedDistance(nodeCurrent - nodeStart));
    }
    catch(FloatException)
    {
        return;
    }
}

cocos2d::Vec3 AxisEditor::getIntersect(cocos2d::Vec2 touchLocation)
{
    return Vec3(0, 0, 0);
}

float AxisEditor::getProjectedDistance(cocos2d::Vec3 distanceVec)
{
    return 0;
}

void AxisEditor::setMinMax(float min, float max)
{
    _min = min;
    _max = max;
}

void AxisEditor::setValueChangedCallback(std::function<void ()> callback)
{
    _onValueChanged = callback;
}

AxisEditorX* AxisEditorX::create()
{
    AxisEditorX* ret = new AxisEditorX();
    ret->init();
    ret->autorelease();
    return ret;
}

AxisEditorX::AxisEditorX()
{
    OBB body;
    body.set(Vec3(50, 0, 0), Vec3(1, 0 ,0), Vec3(0, 1 ,0), Vec3(0, 0 ,1), Vec3(30, 3, 3));
    
    _touchCollision->addObb(body);
    _drawNode->drawObb(body, Color4F(1.0, 0.0, 0.0, 1.0));
    
    _label->setPosition3D(Vec3(100, 0, 0));
    _label->setColor(Color3B(255, 0, 0));
    _label->setString("X");
}

AxisEditorX::~AxisEditorX()
{
    
}

cocos2d::Vec3 AxisEditorX::getIntersect(cocos2d::Vec2 touchLocation)
{
    Camera* camera = Director::getInstance()->getRunningScene()->getDefaultCamera();
    
    Mat4 worldTransform = this->getNodeToWorldTransform();
    Vec3 normal = Vec3(0, 0, 1);
    worldTransform.transformVector(&normal);
    normal.normalize();
    Vec3 pPlane = Vec3(0, 0, 0);
    worldTransform.transformPoint(&pPlane);
    Vec3 pNear = camera->unprojectGL(Vec3(touchLocation.x, touchLocation.y, -1));
    Vec3 pFar = camera->unprojectGL(Vec3(touchLocation.x, touchLocation.y, 1));
    Vec3 direction = pFar - pNear;
    direction.normalize();
    
    float t = (normal.dot(pPlane) - normal.dot(pNear)) / normal.dot(direction);
    
    if(isfinite(t))
    {
        Vec3 ret = pNear + direction * t;
        return ret;
    }
    else
    {
        throw FloatException();
    }
}

float AxisEditorX::getProjectedDistance(cocos2d::Vec3 distanceVec)
{
    if(isfinite(distanceVec.x))
    {
        return distanceVec.x;
    }
    else
    {
        throw FloatException();
    }
}

AxisEditorY* AxisEditorY::create()
{
    AxisEditorY* ret = new AxisEditorY();
    ret->init();
    ret->autorelease();
    return ret;
}

AxisEditorY::AxisEditorY()
{
    OBB body;
    body.set(Vec3(0, 50, 0), Vec3(1, 0 ,0), Vec3(0, 1 ,0), Vec3(0, 0 ,1), Vec3(3, 40, 3));
    
    _touchCollision->addObb(body);
    _drawNode->drawObb(body, Color4F(0.0, 1.0, 0.0, 1.0));
    
    _label->setPosition3D(Vec3(0, 110, 0));
    _label->setColor(Color3B(0, 255, 0));
    _label->setString("Y");
}

AxisEditorY::~AxisEditorY()
{
    
}

cocos2d::Vec3 AxisEditorY::getIntersect(cocos2d::Vec2 touchLocation)
{
    Camera* camera = Director::getInstance()->getRunningScene()->getDefaultCamera();
    
    Mat4 worldTransform = this->getNodeToWorldTransform();
    Vec3 normal = Vec3(1, 0, 0);
    worldTransform.transformVector(&normal);
    normal.normalize();
    Vec3 pPlane = Vec3(0, 0, 0);
    worldTransform.transformPoint(&pPlane);
    Vec3 pNear = camera->unprojectGL(Vec3(touchLocation.x, touchLocation.y, -1));
    Vec3 pFar = camera->unprojectGL(Vec3(touchLocation.x, touchLocation.y, 1));
    Vec3 direction = pFar - pNear;
    direction.normalize();
    
    float t = (normal.dot(pPlane) - normal.dot(pNear)) / normal.dot(direction);
    
    if(isfinite(t))
    {
        Vec3 ret = pNear + direction * t;
        return ret;
    }
    else
    {
        throw FloatException();
    }
}

float AxisEditorY::getProjectedDistance(cocos2d::Vec3 distanceVec)
{
    if(isfinite(distanceVec.y))
    {
        return distanceVec.y;
    }
    else
    {
        throw FloatException();
    }
}

AxisEditorZ* AxisEditorZ::create()
{
    AxisEditorZ* ret = new AxisEditorZ();
    ret->init();
    ret->autorelease();
    return ret;
}

AxisEditorZ::AxisEditorZ()
{
    OBB body;
    body.set(Vec3(0, 0, 50), Vec3(1, 0 ,0), Vec3(0, 1 ,0), Vec3(0, 0 ,1), Vec3(3, 3, 40));
    
    _touchCollision->addObb(body);
    _drawNode->drawObb(body, Color4F(0.0, 0.0, 1.0, 1.0));
    
    _label->setPosition3D(Vec3(0, 0, 110));
    _label->setColor(Color3B(0, 0, 255));
    _label->setString("Z");
}

AxisEditorZ::~AxisEditorZ()
{
    
}

cocos2d::Vec3 AxisEditorZ::getIntersect(cocos2d::Vec2 touchLocation)
{
    Camera* camera = Director::getInstance()->getRunningScene()->getDefaultCamera();
    
    Mat4 worldTransform = this->getNodeToWorldTransform();
    Vec3 normal = Vec3(0, 1, 0);
    worldTransform.transformVector(&normal);
    normal.normalize();
    Vec3 pPlane = Vec3(0, 0, 0);
    worldTransform.transformPoint(&pPlane);
    Vec3 pNear = camera->unprojectGL(Vec3(touchLocation.x, touchLocation.y, -1));
    Vec3 pFar = camera->unprojectGL(Vec3(touchLocation.x, touchLocation.y, 1));
    Vec3 direction = pFar - pNear;
    direction.normalize();
    
    float t = (normal.dot(pPlane) - normal.dot(pNear)) / normal.dot(direction);
    
    if(isfinite(t))
    {
        Vec3 ret = pNear + direction * t;
        return ret;
    }
    else
    {
        throw FloatException();
    }
}

float AxisEditorZ::getProjectedDistance(cocos2d::Vec3 distanceVec)
{
    if(isfinite(distanceVec.z))
    {
        return distanceVec.z;
    }
    else
    {
        throw FloatException();
    }
}
