//
//  TouchCollision.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/12.
//
//

#include "TouchCollision.hpp"

using namespace cocos2d;

TouchCollision* TouchCollision::create()
{
    TouchCollision* ret = new TouchCollision();
    ret->init();
    ret->autorelease();
    return ret;
}

TouchCollision::~TouchCollision()
{
    
}

void TouchCollision::addObb(cocos2d::OBB obb)
{
    _obbs.push_back(obb);
}

std::vector<cocos2d::OBB>& TouchCollision::getObbs()
{
    return _obbs;
}

void TouchCollision::getTransformedObbs(std::vector<cocos2d::OBB>& out)
{
    for(int i = 0; i < _obbs.size(); i++)
    {
        out.push_back(_obbs[i]);
        out[i].transform(getNodeToWorldTransform());
    }
}

bool TouchCollision::touchHit(cocos2d::Vec2 touchPosition)
{
    Camera* camera = Director::getInstance()->getRunningScene()->getDefaultCamera();
    Vec3 pNear = camera->unprojectGL(Vec3(touchPosition.x, touchPosition.y, -1));
    Vec3 pFar = camera->unprojectGL(Vec3(touchPosition.x, touchPosition.y, 1));
    
    Vec3 center = (pNear + pFar) / 2;
    Vec3 zAxis = pFar - pNear;
    zAxis.normalize();
    Vec3 xAxis = Vec3(1, 1, -(zAxis.x + zAxis.y) / zAxis.z);
    xAxis.normalize();
    Vec3 yAxis;
    Vec3::cross(zAxis, xAxis, &yAxis);
    yAxis.normalize();
    
    Vec3 extents = Vec3(2, 2, (pFar - pNear).length());
    
    OBB selector;
    selector.set(center, xAxis, yAxis, zAxis, extents);
    selector._extentX = selector._xAxis * selector._extents.x;
    selector._extentY = selector._yAxis * selector._extents.y;
    selector._extentZ = selector._zAxis * selector._extents.z;
    
    std::vector<OBB> vOBB;
    getTransformedObbs(vOBB);
    
    for(int i = 0; i < vOBB.size(); i++)
    {
        if(vOBB[i].intersects(selector))
        {
            return true;
        }
    }
    
    return false;
}
