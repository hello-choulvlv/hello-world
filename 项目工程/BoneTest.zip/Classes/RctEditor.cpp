//
//  RctEditor.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/27.
//
//

#include "RctEditor.hpp"
#include "CollisionAreaEditor.hpp"

using namespace cocos2d;

RctEditor::RctEditor() :
__valueChangeCallback([](Rct){})
{
    
}

RctEditor::~RctEditor()
{
    
}

RctEditor* RctEditor::create()
{
    RctEditor* pRet = new RctEditor();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

bool RctEditor::init()
{
    Vec2 posCenter = Vec2(250 + 440 * 0, 300 - 70);
    Vec2 posExtension = Vec2(250 + 440 * 1, 300 - 70);
    Vec2 posScale = Vec2(250 + 440 * 0, 150 - 70);
    Vec2 posRotation = Vec2(250 + 440 * 1, 150 - 70);
    Vec2 posTranslation = Vec2(250 + 440 * 2, 150 - 70);
    
    Color3B centerColor = Color3B(200, 0, 0);
    Color3B extensionColor = Color3B(0, 0, 200);
    Color3B transformColor = Color3B(0, 200, 0);
    
    __center = VecEditor::create();
    __center->setValueChangeCallback(CC_CALLBACK_1(RctEditor::onValueChange, this));
    __center->setPosition(posCenter);
    __center->setTitle("CENTER:");
    __center->setTitleColor(centerColor);
    __center->setMax(5000);
    this->addChild(__center);
    
    __extension = VecEditor::create();
    __extension->setValueChangeCallback(CC_CALLBACK_1(RctEditor::onValueChange, this));
    __extension->setPosition(posExtension);
    __extension->setTitle("EXTENSION:");
    __extension->setTitleColor(extensionColor);
    __extension->setMax(5000);
    this->addChild(__extension);
    
    __scale = VecEditor::create();
    __scale->setValueChangeCallback(CC_CALLBACK_1(RctEditor::onValueChange, this));
    __scale->setPosition(posScale);
    __scale->setTitle("SCALE:");
    __scale->setTitleColor(transformColor);
    __scale->setMax(1000);
    this->addChild(__scale);
    
    __rotation = VecEditor::create();
    __rotation->setValueChangeCallback(CC_CALLBACK_1(RctEditor::onValueChange, this));
    __rotation->setPosition(posRotation);
    __rotation->setTitle("ROTATION:");
    __rotation->setTitleColor(transformColor);
    this->addChild(__rotation);
    
    __translation = VecEditor::create();
    __translation->setValueChangeCallback(CC_CALLBACK_1(RctEditor::onValueChange, this));
    __translation->setPosition(posTranslation);
    __translation->setTitle("TRANSLATION:");
    __translation->setTitleColor(transformColor);
    __translation->setMax(5000);
    this->addChild(__translation);
    
    return true;
}

void RctEditor::setRct(Rct& rct)
{
    __center->setValue(rct.center);
    __extension->setValue(rct.extension);
    __scale->setValue((rct.scale - Vec3(1.0, 1.0, 1.0)) * 1000);
    __rotation->setValue(Vec3(CC_RADIANS_TO_DEGREES(rct.rotation.x), CC_RADIANS_TO_DEGREES(rct.rotation.y), CC_RADIANS_TO_DEGREES(rct.rotation.z)));
    __translation->setValue(rct.translation);
}

Rct RctEditor::getRct()
{
    Rct ret;
    ret.center = __center->getValue();
    ret.extension = __extension->getValue();
    ret.scale = Vec3(1.0, 1.0, 1.0) + __scale->getValue() / 1000;
    ret.rotation = Vec3(CC_DEGREES_TO_RADIANS(__rotation->getValue().x), CC_DEGREES_TO_RADIANS(__rotation->getValue().y), CC_DEGREES_TO_RADIANS(__rotation->getValue().z)),
    ret.translation = __translation->getValue();
    
    return ret;
}

void RctEditor::setValueChangeCallback(std::function<void(Rct)> callback)
{
    __valueChangeCallback = callback;
}

void RctEditor::onValueChange(cocos2d::Vec3 value)
{
    __valueChangeCallback(getRct());
}
