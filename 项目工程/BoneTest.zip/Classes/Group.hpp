//
//  Group.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#ifndef Group_hpp
#define Group_hpp

#include "GroupInterface.hpp"
#include "TroopSetManager.h"

class MoveComponent;
class Generator;

class Group : public IGroup
{
public:
    Group();
    virtual ~Group();
    void setConfig(GroupConfig& config);
    void setMoveComponent(MoveComponent* moveComponent);
    void update(float dt);
    void updateTransform(float dt);
    void updateGenerator(float dt);
    void setParentTransform(cocos2d::Mat4 transform);
    void setId(int id);
    void destroy();
    int getId();
    float getLifetime();
    bool getUpdateFlag();
    void setUpdateFlag(bool flag);
    MoveComponent* getMoveComponent();
    
    virtual cocos2d::Mat4 getTransform();
    
public:
    virtual void enterGroup();
    
protected:
    void buildTransformWithParam(cocos2d::Vec3 translation, cocos2d::Vec3 rotation, float roll, float scale, cocos2d::Mat4& transform);
    void notifyMembers();
    
protected:
    TransformAction* _transformAction;
    TransformAction::ActionTarget _transformResult;
    std::vector<Generator*> _generators;
    MoveComponent* _moveComponent;
    bool _transformCalculated;
    bool _localTransformUpdated;
    bool _parentTransformUpdated;
    cocos2d::Mat4 _parentTransform;
    cocos2d::Mat4 _localTransform;
    cocos2d::Mat4 _calculatedTransform;
    float _timeElapsed;
    int _id;
    int _type;
    bool _updateFlag;
};

#endif /* Group_hpp */
