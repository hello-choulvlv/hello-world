//
//  TransformActionCreator.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/4.
//
//

#include "TransformActionCreator.hpp"
#include <sstream>

TransformActionCreator* TransformActionCreator::_instance = nullptr;

TransformActionCreator* TransformActionCreator::getInstance()
{
    if(_instance == nullptr)
    {
        _instance = new TransformActionCreator();
    }
    
    return _instance;
}

TransformAction* TransformActionCreator::createActionWithConfig(pugi::xml_node& config)
{
    auto actionConfigs = config.children();
    
    if(actionConfigs.begin() == actionConfigs.end())
    {
        assert(false);
    }
    
    return buildAction(*actionConfigs.begin());
}

TransformAction* TransformActionCreator::buildAction(pugi::xml_node& actionConfig)
{
    std::string actionClassName = actionConfig.name();
    
    if(actionClassName == "Swing")
    {
        TransformAction* ret = buildSwing(actionConfig);
        assert(ret);
        return ret;
    }
    else if(actionClassName == "Sequence")
    {
        TransformAction* ret = buildSequence(actionConfig);
        assert(ret);
        return ret;
    }
    else if(actionClassName == "Spawn")
    {
        TransformAction* ret = buildSpawn(actionConfig);
        assert(ret);
        return ret;
    }
    else if(actionClassName == "Position")
    {
        TransformAction* ret = buildPosition(actionConfig);
        assert(ret);
        return ret;
    }
    else if(actionClassName == "Direction")
    {
        TransformAction* ret = buildDirection(actionConfig);
        assert(ret);
        return ret;
    }
    else if(actionClassName == "Scale")
    {
        TransformAction* ret = buildScale(actionConfig);
        assert(ret);
        return ret;
    }
    else if(actionClassName == "Roll")
    {
        TransformAction* ret = buildRoll(actionConfig);
        assert(ret);
        return ret;
    }
    else
    {
        assert(false);
        return nullptr;
    }
}

TransformAction* TransformActionCreator::buildSwing(pugi::xml_node& transformConfig)
{
    auto actionConfigs = transformConfig.children();
    
    if(actionConfigs.begin() == actionConfigs.end())
    {
        assert(false);
    }
    
    TransformSwing* ret = new TransformSwing();
    ret->setCount(transformConfig.attribute("count").as_int(1));
    ret->addAction(buildAction(*actionConfigs.begin()));
    return ret;
}

TransformAction* TransformActionCreator::buildSequence(pugi::xml_node& transformConfig)
{
    auto actionConfigs = transformConfig.children();
    
    if(actionConfigs.begin() == actionConfigs.end())
    {
        assert(false);
    }
    
    std::vector<TransformAction*> actions;
    
    auto iter = actionConfigs.begin();
    
    while(iter != actionConfigs.end())
    {
        actions.push_back(buildAction(*iter));
        iter++;
    }
    
    TransformSequence* ret = new TransformSequence();
    ret->addAction(actions);
    
    return ret;
}

TransformAction* TransformActionCreator::buildSpawn(pugi::xml_node& transformConfig)
{
    auto actionConfigs = transformConfig.children();
    
    if(actionConfigs.begin() == actionConfigs.end())
    {
        assert(false);
    }
    
    std::vector<TransformAction*> actions;
    
    auto iter = actionConfigs.begin();
    
    while(iter != actionConfigs.end())
    {
        actions.push_back(buildAction(*iter));
        iter++;
    }
    
    TransformSpawn* ret = new TransformSpawn();
    ret->addAction(actions);
    
    return ret;
}

TransformAction* TransformActionCreator::buildPosition(pugi::xml_node& transformConfig)
{
    cocos2d::Vec3 start = stringToVec3(transformConfig.attribute("from").as_string());
    cocos2d::Vec3 end = stringToVec3(transformConfig.attribute("to").as_string());
    float duration = transformConfig.attribute("duration").as_float(0);
    
    assert(duration != 0);
    
    TransformPosition* ret = new TransformPosition();
    ret->setDuration(duration);
    ret->setParam(start, end);
    return ret;
}

TransformAction* TransformActionCreator::buildDirection(pugi::xml_node& transformConfig)
{
    cocos2d::Vec3 start = stringToVec3(transformConfig.attribute("from").as_string());
    cocos2d::Vec3 end = stringToVec3(transformConfig.attribute("to").as_string());
    float duration = transformConfig.attribute("duration").as_float(0);
    
    assert(duration != 0);
    
    TransformDirection* ret = new TransformDirection();
    ret->setDuration(duration);
    ret->setParam(start, end);
    return ret;
}

TransformAction* TransformActionCreator::buildRoll(pugi::xml_node& transformConfig)
{
    float start = transformConfig.attribute("from").as_float(0);
    float  end = transformConfig.attribute("to").as_float(0);
    float duration = transformConfig.attribute("duration").as_float(0);
    
    assert(duration != 0);
    
    TransformRoll* ret = new TransformRoll();
    ret->setDuration(duration);
    ret->setParam(start, end);
    return ret;
}

TransformAction* TransformActionCreator::buildScale(pugi::xml_node& transformConfig)
{
    float start = transformConfig.attribute("from").as_float(0);
    float  end = transformConfig.attribute("to").as_float(0);
    float duration = transformConfig.attribute("duration").as_float(0);
    
    assert(duration != 0);
    
    TransformScale* ret = new TransformScale();
    ret->setDuration(duration);
    ret->setParam(start, end);
    return ret;
}

cocos2d::Vec3 TransformActionCreator::stringToVec3(std::string str)
{
    str+=",";
    int size = str.size();
    
    std::vector<float> numbers;
    int pos = 0;
    cocos2d::Vec3 ret;    
    while(pos < size)
    {
        int find = str.find(",", pos);
        
        if(find < size)
        {
            std::string numberStr = str.substr(pos, find - pos);
            std::stringstream converter;
            converter<<numberStr;
            
            try
            {
                float number;
                converter>>number;
                numbers.push_back(number);
            }
            catch(std::exception)
            {
                assert(false);
            }
            
            pos = find + 1;
        }
    }
    
    if(numbers.size() < 3)
    {
        assert(false);
    }
    
    ret.x = numbers[0];
    ret.y = numbers[1];
    ret.z = numbers[2];
    
    return ret;
}
