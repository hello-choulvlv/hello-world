//
//  VecEditor.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/27.
//
//

#ifndef VecEditor_hpp
#define VecEditor_hpp

#include "cocos2d.h"
#include "TextFieldEx.hpp"
#include "ui/CocosGUI.h"

class VecEditor : public cocos2d::ui::Widget
{
public:
    VecEditor();
    virtual ~VecEditor();
    
public:
    static VecEditor* create();
    virtual bool init();
    virtual void onEnter();
    virtual void onExit();
    
public:
    void setTitle(std::string title);
    void setTitleColor(cocos2d::Color3B color);
    void setValue(cocos2d::Vec3 value);
    cocos2d::Vec3 getValue();
    void setValueChangeCallback(std::function<void(cocos2d::Vec3)> callback);
    void setMax(int max);
    
private:
    void onValueChange();
    
private:
    TextFieldEx* __x;
    TextFieldEx* __y;
    TextFieldEx* __z;
    cocos2d::DrawNode* __background;
    cocos2d::Label* __title;
    std::function<void (cocos2d::Vec3)> __valueChangeCallback;
};

#endif /* VecEditor_hpp */
