//
//  MoveComponentSpiral.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "MoveComponentSpiral.hpp"
#include "SpiralRoute.h"

MoveComponentSpiral::MoveComponentSpiral()
{
    _route = nullptr;
}

MoveComponentSpiral::~MoveComponentSpiral()
{
    
}

void MoveComponentSpiral::retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection)
{
    _route->retrieveState(_distance, currentPosition, currentDirection);
    currentPosition = currentPosition + _offset;
    
    if(_distance >= _route->getSpiralLength())
    {
        _end = true;
    }
    else
    {
        _end = false;
    }
}

void MoveComponentSpiral::setSpiralRoute(SpiralRoute *route)
{
    if(_route)
    {
        delete _route;
    }
    
    _route = route;
}

void MoveComponentSpiral::setOffset(cocos2d::Vec3 offset)
{
    _offset = offset;
}
