//
//  BoneExtractor.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/17.
//
//

#ifndef BoneExtractor_hpp
#define BoneExtractor_hpp

#include "cocos2d.h"

class BoneExtractor : public cocos2d::Node
{
public:
    enum TRANSFORM_FILTER {
        
        ALL = 0x111,
        ROTATION = 0x100,
        SCALE = 0x010,
        TRANSLATION = 0x001,
        
    };
    
public:
    static BoneExtractor* create();
    BoneExtractor();
    virtual ~BoneExtractor();
    
public:
    
    int getBoneCount();
    int getRootCount();
    
    cocos2d::Bone3D* getRoot(int index);
    cocos2d::Bone3D* getRoot(std::string);
    
    cocos2d::Bone3D* getBone(int index);
    cocos2d::Bone3D* getBone(std::string name);
    
    cocos2d::Vec3* getBonePosition(int index);
    cocos2d::Vec3* getBonePosition(std::string index);
    cocos2d::Vec3* getBonePosition(cocos2d::Bone3D* index);
    
    cocos2d::Mat4 getBoneTransform(int index, int filter);
    cocos2d::Mat4 getBoneTransform(std::string index, int filter);
    cocos2d::Mat4 getBoneTransform(cocos2d::Bone3D* index, int filter);
    
    
private:
    
    std::map<std::string, cocos2d::Bone3D*> _mBoneMap;
};

#endif /* BoneExtractor_hpp */
