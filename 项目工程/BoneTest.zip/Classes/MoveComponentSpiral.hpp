//
//  MoveComponentSpiral.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef MoveComponentSpiral_hpp
#define MoveComponentSpiral_hpp

#include "MoveComponent.hpp"

class SpiralRoute;

class MoveComponentSpiral : public MoveComponent
{
public:
    MoveComponentSpiral();
    virtual ~MoveComponentSpiral();
    virtual void retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection);
    void setSpiralRoute(SpiralRoute* _route);
    void setOffset(cocos2d::Vec3 offset);
    
private:
    SpiralRoute* _route;
    cocos2d::Vec3 _offset;
};

#endif /* MoveComponentSpiral_hpp */
