//
//  NavigatorCircle.cpp
//  BoneTest
//
//  Created by charlie on 2017/6/30.
//
//

#include "NavigatorCircle.hpp"

using namespace cocos2d;

NavigatorCircle* NavigatorCircle::create(float radius, cocos2d::Vec3 center, cocos2d::Vec3 axis)
{
    NavigatorCircle* pRet = new NavigatorCircle();
    pRet->init(radius, center, axis);
    pRet->autorelease();
    return pRet;

}

bool NavigatorCircle::init(float pRadius, cocos2d::Vec3 pCenter, cocos2d::Vec3 pAxis)
{
    Navigator::init();
    
    _precision = 5;
    _radius = pRadius;
    _center = pCenter;
    _axisC = pAxis;
    _axisC.normalize();
    
    if(_axisC.x == 0 && _axisC.z == 0)
    {
        _axisA = Vec3(0, 0, 1);
        _axisB = Vec3(1, 0, 0);
    }
    else
    {
        float axisLength = sqrtf(_axisC.x * _axisC.x + _axisC.z * _axisC.z);
        _axisA = Vec3(-_axisC.z / axisLength, 0, _axisC.x / axisLength);
        
        Vec3::cross(_axisC, _axisA, &_axisB);
        _axisB.normalize();
    }
    
    _currentRotation = 0;
    _deltaR = 80;
    _deltaH = 200;
    _angularSpeed = M_PI / 6;
    _linearSpeed = 1500;
    
    _lastPosition = calculatePosition(_currentRotation, _radius, _center);
    _lastDirection = calculateDirection(_currentRotation, _radius, _center);
    _lastOverflow = 0;

    
    return true;
}

cocos2d::Vec3 NavigatorCircle::calculatePosition(float rotation, float radius, cocos2d::Vec3 center)
{
    return center + radius * (cos(rotation) * _axisA + sin(rotation) * _axisB);
}

cocos2d::Vec3 NavigatorCircle::calculateDirection(float rotation, float radius, cocos2d::Vec3 center)
{
    Vec3 ret =

    _axisC * _deltaH
    + _deltaR * (_axisA * cos(rotation) + _axisB * sin(rotation))
    + radius * (_axisB * cos(rotation) - _axisA * sin(rotation));
    
    ret.normalize();
    
    return ret;
}

//void NavigatorCircle::update(float dt)
//{
//    float rotationDelta = M_PI / 3 * dt;
//    
//    _currentRotation = _currentRotation + rotationDelta;
//    _radius = _radius + rotationDelta * _deltaR;
//    _center = _center + rotationDelta * _axisC * _deltaH;
//    
//    Vec3 currentPos = calculatePosition(_currentRotation, _radius, _center);
//    Vec3 direction = calculateDirection(_currentRotation, _radius, _center);
//    
//    float rotY = atan2f(direction.x, direction.z);
//    float rotZ = atanf(direction.y / sqrtf(direction.x * direction.x + direction.z * direction.z));
//    
//    Quaternion quatY = Quaternion(Vec3(0, 1, 0), rotY - M_PI / 2);
//    Quaternion quatZ = Quaternion(Vec3(0, 0, 1), rotZ);
//    
//    _parent->setPosition3D(currentPos);
//    _parent->setRotationQuat(quatY * quatZ);
//    
//    _lastPosition = currentPos;
//}

void NavigatorCircle::update(float dt)
{
    float distanceDelta = _linearSpeed * dt + _lastOverflow;
    Vec3 nextPosition;
    Vec3 nextDirection;
    
    do
    {
        Vec3 prevVec = _lastPosition - _center;
        Vec3 nextVec = prevVec + _lastDirection * _precision;
        
        Vec3 prevProj = prevVec - _axisC * _axisC.dot(prevVec);
        prevProj.normalize();
        
        Vec3 nextProj = nextVec - _axisC * _axisC.dot(nextVec);
        nextProj.normalize();
        
        float rotationDelta = acosf(prevProj.dot(nextProj));
        float nextRotation = _currentRotation + rotationDelta;
        float nextRadius = _radius + rotationDelta * _deltaR;
        Vec3 nextCenter = _center + rotationDelta * _axisC * _deltaH;
        nextPosition = calculatePosition(_currentRotation, _radius, _center);
        nextDirection = calculateDirection(_currentRotation, _radius, _center);
        
        if(distanceDelta >= _precision)
        {
            _currentRotation = nextRotation;
            _radius = nextRadius;
            _center = nextCenter;
            _lastPosition = nextPosition;
            _lastDirection = nextDirection;
            
            distanceDelta = distanceDelta - _precision;
        }
        else
        {
            break;
        }
    }
    while(true);
    
    _lastOverflow = distanceDelta;
    
    float t = _lastOverflow / _precision;
    
    Vec3 currentPosition = _lastPosition * (1 - t) + nextPosition * t;
    
    float rotY = atan2f(_lastDirection.x, _lastDirection.z);
    float rotZ = atanf(_lastDirection.y / sqrtf(_lastDirection.x * _lastDirection.x + _lastDirection.z * _lastDirection.z));

    Quaternion quatY = Quaternion(Vec3(0, 1, 0), rotY - M_PI / 2);
    Quaternion quatZ = Quaternion(Vec3(0, 0, 1), rotZ);

    _parent->setPosition3D(currentPosition);
    _parent->setRotationQuat(quatY * quatZ);
}
