//
//  PathEditor.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/11.
//
//

#ifndef PathEditor_hpp
#define PathEditor_hpp

#include "cocos2d.h"

class ModelInspector;

class PathEditor : public cocos2d::Node
{
public:
    PathEditor();
    ~PathEditor();
};

#endif /* PathEditor_hpp */
