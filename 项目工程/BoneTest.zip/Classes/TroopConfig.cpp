//
//  TroopConfig.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#include "TroopConfig.hpp"

TypeSelector::TypeSelector()
{
    _total = 0;
}

void TypeSelector::setParam(std::vector<int>& types, std::vector<int>& weights)
{
    assert(types.size() == weights.size());
    
    _types = types;
    _weights = weights;
    _typeNumber = _types.size();
    
    for(int i = 0; i < _typeNumber; i++)
    {
        _total = _total + _weights[i];
    }
}

int TypeSelector::getType()
{
    if(_typeNumber == 1)
    {
        return _types[0];
    }
    else
    {
        int random = rand() % _total;
        
        for(int i = 0; i < _typeNumber; i++)
        {
            if(random < _weights[i])
            {
                return _types[i];
            }
        }
    }
    
    return _types[0];
}

RandomTyped::RandomTyped()
{
    typeSelectorId = 0;
    fixType = false;
    type = 0;
}

void RandomTyped::genType(int parentType)
{
    if(typeSelectorId == 0)
    {
        type = parentType;
    }
    else if((fixType && type == 0) || !fixType)
    {
        TypeSelector& selector = TroopConfig::getInstance()->getTypeSelectorById(typeSelectorId);
        type = selector.getType();
    }
}

TroopConfig* TroopConfig::_instance = nullptr;

TroopConfig* TroopConfig::getInstance()
{
    if(_instance == nullptr)
    {
        _instance = new TroopConfig();
    }
    
    return _instance;
}

void TroopConfig::loadConfig(std::string configFilePath)
{
    
}

TypeSelector& TroopConfig::getTypeSelectorById(int typeSelectorId)
{
    
}
