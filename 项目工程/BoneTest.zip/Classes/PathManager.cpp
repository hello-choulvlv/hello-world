//
//  PathManager.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "PathManager.hpp"
#include "pugixml.hpp"

PathManager* PathManager::getInstance()
{
    if(_instance == nullptr)
    {
        _instance = new PathManager();
    }
    
    return _instance;
}

PathManager* PathManager::_instance = nullptr;


void loadPath(std::string pathFileName)
{
//    pugi::xml_document doc;
//    
//    if (!doc.load_file(pathFileName.c_str()))
//    {
//        assert(false);
//    }
//    
//    pugi::xml_node FishPath = doc.child("FishPath");
//    pugi::xml_node path = FishPath.child("Path");
//    while (!path.empty())
//    {
//        SPATH pd;
//        ZeroMemory(&pd, sizeof(SPATH));
//        
//        pd.id = path.attribute("id").as_int(0);
//        pd.type = path.attribute("Type").as_int(0);
//        pd.PointCount = 0;
//        pd.nNext = path.attribute("Next").as_int(0);
//        pd.nDelay = path.attribute("Delay").as_int(0);
//        pd.nPathType = path.attribute("Type").as_int(7);
//        pd.fWeight = path.attribute("weight").as_float(0.5);
//        
//        pugi::xml_node pt = path.child("Position");
//        while (!pt.empty())
//        {
//            MyPoint point;
//            
//            point.x_ = pt.attribute("x").as_float(0.0f);
//            point.y_ = pt.attribute("y").as_float(0.0f);
//            point.z_ = pt.attribute("z").as_float(0.0f);
//            
//            pd.PointList.push_back(point);
//            
//            pd.PointCount++;
//            
//            pt = pt.next_sibling("Position");
//        }
//        
//        if (pd.type == NPT_LINE)
//        {
//            pd.PointCount = 2;
//        }
//        else if (pd.type == NPT_BEZIER)
//        {
//            //if(pd.xPos[3] == 0.0f && pd.yPos[3] == 0.0f)
//            //	pd.PointCount = 3;
//        }
//        else
//        {
//            pd.PointCount = PTCOUNT;
//        }
//        
//        pathConfig.push_back(pd);
//        
//        path = path.next_sibling("Path");
//    }
}
