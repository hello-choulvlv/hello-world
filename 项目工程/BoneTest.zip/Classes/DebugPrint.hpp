//
//  DebugPrint.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/13.
//
//

#ifndef DebugPrint_hpp
#define DebugPrint_hpp

#include <string>

namespace Debug {
    
    class DebugPrint
    {
    public:
        enum FILTER_MODE {ENABLE, DISABLE, OPEN, CLOSE};
        enum DEFAULT_CATEGORY {ERROR = 0x01, LOG = 0x02};
        enum PREFIX_SHOW_MODE {SHOW_NONE = 0x00, SHOW_CATEGORY = 0x01, SHOW_TAG = 0x02, SHOW_ALL = 0x03};
        
    public:
        static void createInstance();
        static DebugPrint* getInstance();

    private:
        static DebugPrint* __instance;
        
    public:
        DebugPrint();
        ~DebugPrint();
        
    public:
        void print(unsigned int category, std::string tag, const char* format, ...);
        void print(unsigned int category, std::string tag, std::string content);
        
        void addTagFilter(std::string tagFilters);
        void setCategoryFilter(unsigned int categoryFilters);
        void setFilterMode(FILTER_MODE mode);
        void setPrefixShowMode(unsigned int prefixShowMode);
        void registerCategory(unsigned int category, std::string description);
        
    private:
        void printPrefix(unsigned int category, std::string tag);
        bool passCategoryFilter(unsigned int category);
        bool passTagFilter(std::string& tag);
        bool passFilter(unsigned int category, std::string& tag);
        
    private:
        std::vector<std::string> __tagFilters;
        unsigned int __categoryFilters;
        FILTER_MODE __filterMode;
        unsigned int __prefixShowMode;
        std::map<int, std::string> __categoryDescrptions;
        pthread_mutex_t __lock;
    };
    
}

#define CLASS_NAME(_name_) static const char* _TAG_CLASS_NAME_ = typeid(_name_).name();

#define ERR_PRINT(tag, format, ...) Debug::DebugPrint::getInstance()->print(Debug::DebugPrint::ERROR, tag, format, ##__VA_ARGS__);
#define LOG_PRINT(tag, format, ...) Debug::DebugPrint::getInstance()->print(Debug::DebugPrint::LOG, tag, format, ##__VA_ARGS__);

#define ERR_PRINT_C(format, ...) Debug::DebugPrint::getInstance()->print(Debug::DebugPrint::LOG, _TAG_CLASS_NAME_, format, ##__VA_ARGS__);
#define LOG_PRINT_C(format, ...) Debug::DebugPrint::getInstance()->print(Debug::DebugPrint::LOG, _TAG_CLASS_NAME_, format, ##__VA_ARGS__);

#define PRINT_ERRNO Debug::DebugPrint::getInstance()->print(Debug::DebugPrint::ERROR, "Errno", "ERROR_%d: %s", errno, strerror(errno));
#define ERRNO_PRINT_C(format, ...) ERR_PRINT_C(format, ##__VA_ARGS__) PRINT_ERRNO

#endif /* DebugPrint_hpp */
