//
//  CollisionArea.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/18.
//
//

#ifndef CollisionArea_hpp
#define CollisionArea_hpp

#include "cocos2d.h"

class CollisionArea : public cocos2d::Node
{
public:
    static CollisionArea* create();
    CollisionArea();
    virtual ~CollisionArea();
    
public:
    void loadConfig(std::map<std::string, cocos2d::OBB> areaConfig);
    void bindToSkeleton(cocos2d::Skeleton3D* skeleton);
    void bind();
    virtual void visit(cocos2d::Renderer *renderer, const cocos2d::Mat4& parentTransform, uint32_t parentFlags);
    void updateObb(cocos2d::OBB& original, cocos2d::OBB& target, cocos2d::Mat4& transform);
    std::vector<cocos2d::OBB*> getObbs();
    
private:
    std::map<std::string, cocos2d::OBB> __mAreaConfig;
    std::map<int, cocos2d::OBB> __mfastLookup;
    std::vector<std::pair<int, cocos2d::OBB>> __vAreaBinding;
    cocos2d::Skeleton3D* __pSkeleton;
};

#endif /* CollisionArea_hpp */
