//
//  TroopSet.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/5.
//
//

#include "TroopSet.hpp"

void IMember::setGroup(IGroup* group)
{
    _group = group;
}

IGroup* IMember::getGroup()
{
    return _group;
}


void IGroup::addMember(IMember* member)
{
    _members.push_back(member);
}

void IGroup::removeMember(IMember* member)
{
    for(auto iter = _members.begin(); iter != _members.end(); iter++)
    {
        if(*iter == member)
        {
            _members.erase(iter);
            break;
        }
    }
}

std::list<IMember*>& IGroup::getMembers()
{
    return _members;
}

Group::Group():
_route(nullptr),
_transformAction(nullptr),
_transformUpdated(true),
_cachedTransform(cocos2d::Mat4::IDENTITY)
{

}

Group::~Group()
{
    delete _transformAction;
    delete _route;
    
    for(int i = 0; i <_generators.size(); i++)
    {
        delete _generators[i];
    }
}

void Group::setConfig(GroupConfig& config)
{
    _transformAction = config.transform->clone();
    _transformAction->setTarget(&_transformResult);
    
    for(int i = 0; i < config.generator.size(); i++)
    {
        Generator* generator = new Generator();
        generator->setConfig(config.generator[i]);
        _generators.push_back(generator);
    }
    
    _route = new SpiralRoute(cocos2d::Vec3(0, 1, 0),            // axix
                             cocos2d::Vec3(0, 0, 0),            // center
                             100,                               // radius
                             0.5,                               // stepR
                             0.5,                               // stepH
                             1080,                              // maxAngle
                             5,                                 // precision
                             SpiralRoute::STEP_MODE::LINEAR);   // mode
}

void Group::update(float dt)
{
    if(_transformAction)
    {
        _transformAction->update(dt);
        _transformUpdated = false;
    }
    
    if(_route)
    {
        _distance += 300 * dt;
        _transformUpdated = false;
    }
}

void Group::buildTransformWithParam(cocos2d::Vec3 translation, cocos2d::Vec3 direction, float roll, float scale, cocos2d::Mat4& transform)
{
    cocos2d::Quaternion rotY = cocos2d::Quaternion(cocos2d::Vec3(0, 1, 0), atan2f(direction.x, direction.z) - M_PI / 2);
    cocos2d::Quaternion rotZ = cocos2d::Quaternion(cocos2d::Vec3(0, 0, 1), atanf(direction.y / sqrtf(direction.x * direction.x + direction.z * direction.z)));
    cocos2d::Quaternion rotX = cocos2d::Quaternion(cocos2d::Vec3(1, 0, 0), roll * M_PI / 180);

    transform.rotate(rotY * rotZ * rotX);
    transform.translate(translation);
    transform.scale(scale);
}

cocos2d::Mat4 Group::getTransform()
{
    if(!_transformUpdated)
    {
        cocos2d::Mat4 pathTransform = cocos2d::Mat4::IDENTITY;
        cocos2d::Mat4 actionTransform = cocos2d::Mat4::IDENTITY;
        
        if(_route)
        {
            float currentDistance = _distance;
            cocos2d::Vec3 currentPosition = cocos2d::Vec3(0, 0, 0);
            cocos2d::Vec3 currentDirection = cocos2d::Vec3(0, 0, 0);
            
            _route->retrieveState(currentDistance, currentPosition, currentDirection);
            
            buildTransformWithParam(currentPosition, currentDirection, 0.0, 1.0, pathTransform);
        }
        
        if(_transformAction)
        {
            buildTransformWithParam(_transformResult.targetPosition,
                                    _transformResult.targetDirection,
                                    _transformResult.targetRoll,
                                    _transformResult.targetScale,
                                    actionTransform);
        }
        
        _cachedTransform = ((Group*)_group)->getTransform() * actionTransform * pathTransform;
        _transformUpdated = true;
    }
    
    return _cachedTransform;
}

Generator::Generator():
_delayTimer(0),
_spawnTimer(0),
_spawnCount(0),
_generateId(0),
_group(nullptr)
{
    
}

void Generator::setConfig(GeneratorConfig& config)
{
    _config = config;
}

void Generator::setGroup(Group* group)
{
    _group = group;
}

void Generator::update(float dt)
{
    spawnTick(delayTick(dt));
}

float Generator::delayTick(float dt)
{
    _delayTimer = _delayTimer + dt;
    
    if(_delayTimer > _config.delay)
    {
        return _delayTimer - _config.delay;
    }
    else
    {
        return 0;
    }
}

float Generator::spawnTick(float dt)
{
    _spawnTimer = _spawnTimer + dt;
    
    while (_spawnTimer >= _config.spawnInterval
           && _spawnCount < _config.spawnCount) {
        
        _spawnTimer = _spawnTimer - _config.spawnInterval;
        _spawnCount = _spawnCount + 1;
        
        doSpawn();
    }
    
    return 0;
}

void Generator::generateTypes()
{
    _config.genType(0);
    
    for(int clusterIndex = 0; clusterIndex < _config.clusters.size(); clusterIndex++)
    {
        SpawnCluster& cluster = _config.clusters[clusterIndex];
        cluster.genType(_config.type);
        
        for(int elementIndex = 0; elementIndex < cluster.elements.size(); elementIndex++)
        {
            SpawnElement& element = cluster.elements[elementIndex];
            element.genType(cluster.type);
        }
    }
}

void Generator::doSpawn()
{
    generateTypes();
    
    for(int clusterIndex = 0; clusterIndex < _config.clusters.size(); clusterIndex++)
    {
        SpawnCluster& cluster = _config.clusters[clusterIndex];
        
        for(int elementIndex = 0; elementIndex < cluster.elements.size(); elementIndex++)
        {
            SpawnElement& element = cluster.elements[elementIndex];
            
            if(element.category == SpawnElement::CATEGORY::FISH)
            {
                generateFish(element);
            }
            else if(element.category == SpawnElement::CATEGORY::GROUP)
            {
                generateGroup(element);
            }
        }
    }
}

void Generator::generateFish(SpawnElement& config)
{
    
}

void Generator::generateGroup(SpawnElement& group)
{
    
}
