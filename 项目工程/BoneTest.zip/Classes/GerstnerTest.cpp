//
//  GerstnerTest.cpp
//  BoneTest
//
//  Created by charlie on 2017/9/5.
//
//

#include "GerstnerTest.hpp"
#include "DrawNode3D.hpp"
#include "ModelInspector.hpp"

using namespace cocos2d;

GerstnerTest* GerstnerTest::create()
{
    GerstnerTest* pRet = new GerstnerTest();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

const int GerstnerTest::RESOLUTION = 32;
const int GerstnerTest::GRID_STEP = 50;

bool GerstnerTest::init()
{
    Node::init();
    
    initWaves();
    initVertices();
    initDrawNode();
    
    return true;
}

void GerstnerTest::initDrawNode()
{
    ModelInspector* inspector = ModelInspector::create();
    this->addChild(inspector);
    
    __drawNode = DrawNode3D::create();
    inspector->append(__drawNode);
}

void GerstnerTest::initWaves()
{
    {
        WaveParam param;
        param.amplitude = 50;
        param.waveLength = 400;
        param.direction = Vec2(1, 1);
        param.speed = 180;
        param.frequency = 2 / param.speed;
        param.phase = param.speed * 2 / param.waveLength;
        param.amplitudePeriod = 10;
        param.timeElapsed = 0;
        param.realTimeAmplitude = 0;
        
        waves.push_back(param);
    }
    
//    {
//        WaveParam param;
//        param.amplitude = 35;
//        param.waveLength = 250;
//        param.direction = Vec2(1, 0.3);
//        param.speed = 200;
//        param.frequency = 2 / param.speed;
//        param.phase = param.speed * 2 / param.waveLength;
//        param.amplitudePeriod = 6;
//        param.timeElapsed = 0;
//        param.realTimeAmplitude = 0;
//        
//        waves.push_back(param);
//    }
//    
//    {
//        WaveParam param;
//        param.amplitude = 25;
//        param.waveLength = 600;
//        param.direction = Vec2(-1, -0.7);
//        param.speed = 100;
//        param.frequency = 2 / param.speed;
//        param.phase = param.speed * 2 / param.waveLength;
//        param.amplitudePeriod = 12;
//        param.timeElapsed = 0;
//        param.realTimeAmplitude = 0;
//        
//        waves.push_back(param);
//    }
}

void GerstnerTest::initVertices()
{
    vertices = new Vec3* [RESOLUTION];
    
    for (int i = 0; i < RESOLUTION; i++)
    {
        vertices[i] = new Vec3[RESOLUTION];
    }
    
    for (int col = 0; col < RESOLUTION; col++)
    {
        for(int row = 0; row < RESOLUTION; row++)
        {
            Vec3& vertex = vertices[col][row];
            vertex.x = col * GRID_STEP;
            vertex.y = 0;
            vertex.z = -row * GRID_STEP;
        }
    }
    
}

void GerstnerTest::onEnter()
{
    Node::onEnter();
    scheduleUpdate();
}

void GerstnerTest::onExit()
{
    Node::onExit();
    unscheduleUpdate();
}

void GerstnerTest::update(float delta)
{
    __timeElapsed += delta;
    
    updateWaves(delta);
    updateVertices();
    updateDrawNode();
}

void GerstnerTest::updateDrawNode()
{
    __drawNode->clear();
    
    for (int col = 0; col < RESOLUTION; col++)
    {
        for(int row = 0; row < RESOLUTION; row++)
        {
            if(row < RESOLUTION - 1)
            {
                __drawNode->drawLine(vertices[col][row], vertices[col][row + 1], Color4F(0.0, 0.0, 1.0, 1.0));
            }
            
            if(col < RESOLUTION - 1)
            {
                __drawNode->drawLine(vertices[col][row], vertices[col + 1][row], Color4F(0.0, 0.0, 1.0, 1.0));
            }
        }
    }
}

void GerstnerTest::updateWaves(float dt)
{
    for(int i = 0; i < waves.size(); i++)
    {
        WaveParam& param = waves[i];
        param.timeElapsed += dt;
        
        int index = param.timeElapsed / param.amplitudePeriod;
        float amplitudeTimer = param.timeElapsed - index * param.amplitudePeriod;
        param.realTimeAmplitude = param.amplitude;//fabs(param.amplitude * (amplitudeTimer / param.amplitudePeriod - index % 2));
    }
}


void GerstnerTest::updateStrategySimpleSine()
{
    for (int col = 0; col < RESOLUTION; col++)
    {
        for(int row = 0; row < RESOLUTION; row++)
        {
            float waveHeight = 0;
            Vec3& pos = vertices[col][row];
            
            for(int i = 0; i < waves.size(); i++)
            {
                WaveParam& param = waves[i];
                float dotProduct = pos.x + param.direction.x + pos.z * param.direction.y;
                
                waveHeight += param.realTimeAmplitude * sin(dotProduct * param.frequency + param.timeElapsed * param.phase);
            }
            
            pos.y = waveHeight;
        }
    }
}

void GerstnerTest::updateStrategyGerstner()
{
    for (int col = 0; col < RESOLUTION; col++)
    {
        for(int row = 0; row < RESOLUTION; row++)
        {
            Vec3& pos = vertices[col][row];
            float waveHeight = 0;
            float xAccu = col * GRID_STEP;
            float yAccu = -row * GRID_STEP;
            
            for(int i = 0; i < waves.size(); i++)
            {
                WaveParam& param = waves[i];
                float dotProduct = pos.x + param.direction.x + pos.z * param.direction.y;
                float triangleParam = dotProduct * param.frequency + param.timeElapsed * param.phase;
                float q = 1 / (param.frequency * param.realTimeAmplitude) * 0.2;
                
                xAccu += q * param.realTimeAmplitude * param.direction.x * cos(triangleParam);
                yAccu += q * param.realTimeAmplitude * param.direction.y * cos(triangleParam);
                waveHeight += param.realTimeAmplitude * sin(triangleParam);
            }
            
            pos.y = waveHeight;
            pos.x = xAccu;
            pos.z = yAccu;
        }
    }
}

void GerstnerTest::updateVertices()
{
//    updateStrategySimpleSine();
    updateStrategyGerstner();
}
