//
//  LineRoute.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/16.
//
//

#ifndef LineRoute_hpp
#define LineRoute_hpp

#include "cocos2d.h"
#include "RouteProtocol.hpp"

class LineRoute : public cocos2d::Node, public RouteProtocol
{
public:
    LineRoute();
    virtual ~LineRoute() {};
    static LineRoute* create();
    
public:
    virtual void addPoints(std::vector<cocos2d::Vec3>& points) override;
    virtual cocos2d::Vec3 getDirection(float t) override;
    virtual cocos2d::Vec3 getLocation(float t) override;
    virtual cocos2d::Vec3 getCurrentDirection() override;
    virtual cocos2d::Vec3 getCurrentLocation() override;
    virtual void advanceTo(float t) override;
    virtual void advanceBy(float deltaDist) override;
    virtual void reset() override;
    virtual void clear() override;
    
protected:
    float _position;
    cocos2d::Vec3 _valueCache;
    cocos2d::Vec3 _tangentCache;
    std::vector<cocos2d::Vec3> _points;
    int _currentIndex;
};

#endif /* LineRoute_hpp */
