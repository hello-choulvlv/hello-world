//
//  CollisionTest.cpp
//  BoneTest
//
//  Created by charlie on 2017/4/1.
//
//

#include "CollisionTest.hpp"
#include "CollisionManager.hpp"
#include "DrawNode3D.hpp"
#include "ModelInspector.hpp"
#include <string>

using namespace cocos2d;

CollisionTest* CollisionTest::create()
{
    CollisionTest* pRet = new CollisionTest();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

bool CollisionTest::init()
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
    
    ModelInspector* inspector = ModelInspector::create();
    inspector->showPlane(false);
    this->addChild(inspector);
    
    obbData = OBB(AABB(Vec3(-100, -100, -100), Vec3(100, 100, 100)));
    
    obb = DrawNode3D::create();
    obb->drawObb(obbData, Color4F(1.0, 0.0, 0.0, 1.0));
    obb->setPosition(visibleSize / 2);
    obb->setVisible(false);
    inspector->append(obb);
    
    circle = DrawNode::create();
    circle->drawCircle(visibleSize / 2, 100, 360, 64, false, 1.0, 1.0, Color4F(0.0, 0.0, 1.0, 1.0));
    this->addChild(circle);
    
    projectionQuad = DrawNode::create();
    this->addChild(projectionQuad);
    
    prepLine = DrawNode::create();
    this->addChild(prepLine);
    
    pLabel.resize(4);
    
    for(int i = 0; i < 4; i++)
    {
        pLabel[i] = Label::createWithSystemFont(std::to_string(i), "", 32);
        pLabel[i]->setColor(Color3B(255, 0, 0));
        this->addChild(pLabel[i]);
    }
    
    winding = Label::createWithSystemFont("", "", 32);
    winding->setColor(Color3B(255, 0, 0));
    winding->setPosition(Vec2(300, 300));
    this->addChild(winding);
    
    return true;
}

void CollisionTest::onEnter()
{
    Node::onEnter();
    
    this->schedule(schedule_selector(CollisionTest::updater), 0, CC_REPEAT_FOREVER, 0);
}

void CollisionTest::updater(float dt)
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
    
    OBB transformed;
    transformed.set(obbData._center, obbData._xAxis, obbData._yAxis, obbData._zAxis, obbData._extents);
    transformed.transform(obb->getNodeToWorldTransform());
    
    Vec3 p1 = transformed._center + transformed._extentX + transformed._extentY + transformed._extentZ;
    Vec3 p2 = transformed._center + transformed._extentX - transformed._extentY + transformed._extentZ;
    Vec3 p3 = transformed._center - transformed._extentX - transformed._extentY + transformed._extentZ;
    Vec3 p4 = transformed._center - transformed._extentX + transformed._extentY + transformed._extentZ;
    Vec3 p5 = transformed._center + transformed._extentX + transformed._extentY - transformed._extentZ;
    Vec3 p6 = transformed._center + transformed._extentX - transformed._extentY - transformed._extentZ;
    Vec3 p7 = transformed._center - transformed._extentX - transformed._extentY - transformed._extentZ;
    Vec3 p8 = transformed._center - transformed._extentX + transformed._extentY - transformed._extentZ;
    
    Vec2 p1p = Camera::getDefaultCamera()->projectGL(p1);
    Vec2 p2p = Camera::getDefaultCamera()->projectGL(p2);
    Vec2 p3p = Camera::getDefaultCamera()->projectGL(p3);
    Vec2 p4p = Camera::getDefaultCamera()->projectGL(p4);
    Vec2 p5p = Camera::getDefaultCamera()->projectGL(p5);
    Vec2 p6p = Camera::getDefaultCamera()->projectGL(p6);
    Vec2 p7p = Camera::getDefaultCamera()->projectGL(p7);
    Vec2 p8p = Camera::getDefaultCamera()->projectGL(p8);
    
    std::vector<Vec2> pp = std::vector<Vec2>(8);
    pp[0] = p1p;
    pp[1] = p2p;
    pp[2] = p3p;
    pp[3] = p4p;
    pp[4] = p5p;
    pp[5] = p6p;
    pp[6] = p7p;
    pp[7] = p8p;
    
    Color4F normalColor = Color4F(1.0, 1.0, 0.0, 1.0);
    Color4F selectColor = normalColor;
    Vec2 centerP = Vec2(visibleSize.width / 2, visibleSize.height / 2);
    prepLine->clear();
    
    for(int i = 0; i < 4; i++)
    {
        pLabel[i]->setPosition(pp[i]);
    }
    
    projectionQuad->clear();
    projectionQuad->setLineWidth(3);
    projectionQuad->drawLine(p1p, p2p, selectColor);
    projectionQuad->drawLine(p2p, p3p, selectColor);
    projectionQuad->drawLine(p3p, p4p, selectColor);
    projectionQuad->drawLine(p4p, p1p, selectColor);
    
    POINT_WINDING w = getWinding(p1p, p2p, p3p, p4p);
    
    if(w == POINT_WINDING::AC)
    {
        winding->setString("ANTI-CLOCKWISE");
    }
    else if(w == POINT_WINDING::C)
    {
        winding->setString("CLOCKWISE");
    }
    else if(w == POINT_WINDING::ERR)
    {
        winding->setString("LINE");
    }
}

bool CollisionTest::circleAxisSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float radius)
{
    Vec2 prependicular = p2 - p1;
    prependicular = Vec2(-prependicular.y, prependicular.x);
    prependicular.normalize();
    
//    prepLine->clear();
//    prepLine->drawLine(p1, p1 + prependicular * 100, Color4F(1.0, 0.0, 0.0, 1.0));
    
    float proj1 = prependicular.dot(p1);
    float proj2 = prependicular.dot(p1);
    float proj3 = prependicular.dot(p3);
    float proj4 = prependicular.dot(p4);
    float min = proj1;
    float max = proj1;
    
    if(proj3 > max)
    {
        max = proj3;
    }
    else if(proj3 < min)
    {
        min = proj3;
    }
    
    if(proj4 > max)
    {
        max = proj4;
    }
    else if(proj4 < min)
    {
        min = proj4;
    }
    
    Vec2 vPositive = center + prependicular * radius;
    Vec2 vNegtive = center - prependicular * radius;
    float pPositive = prependicular.dot(vPositive);
    float pNegtive = prependicular.dot(vNegtive);
    
    if(pNegtive > max || pPositive < min)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool CollisionTest::circleVertexSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float radius)
{
    Vec2 prependicular = p1 - center;
    prependicular.normalize();
    
    //    prepLine->clear();
    prepLine->drawLine(p1, p1 + prependicular * 100, Color4F(1.0, 0.0, 0.0, 1.0));
    
    float proj1 = prependicular.dot(p1);
    float proj2 = prependicular.dot(p2);
    float proj3 = prependicular.dot(p3);
    float proj4 = prependicular.dot(p4);
    float min = proj1;
    float max = proj1;
    
    if(proj2 > max)
    {
        max = proj2;
    }
    else if(proj2 < min)
    {
        min = proj2;
    }
    
    if(proj3 > max)
    {
        max = proj3;
    }
    else if(proj3 < min)
    {
        min = proj3;
    }
    
    if(proj4 > max)
    {
        max = proj4;
    }
    else if(proj4 < min)
    {
        min = proj4;
    }
    
    Vec2 vPositive = center + prependicular * radius;
    Vec2 vNegtive = center - prependicular * radius;
    float pPositive = prependicular.dot(vPositive);
    float pNegtive = prependicular.dot(vNegtive);
    
    if(pNegtive > max || pPositive < min)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool CollisionTest::circleVertexDistance(cocos2d::Vec2& p1, cocos2d::Vec2& center, float radius)
{
    Vec2 distVec = p1 - center;
    
    prepLine->drawLine(p1, center, Color4F(1.0, 0.0, 0.0, 1.0));
    
    return distVec.x * distVec.x + distVec.y * distVec.y > radius * radius;
}

CollisionTest::ABQuad CollisionTest::getABQuad(cocos2d::Vec2 (*vertices)[4])
{
    float epsilon = 0.000001;
    
    int i_MinX;
    int i_MinY;
    int i_MaxX;
    int i_MaxY;
    float minX = MAXFLOAT;
    float minY = MAXFLOAT;
    float maxX = -MAXFLOAT;
    float maxY = -MAXFLOAT;
    
    for(int i = 0; i < 4; i++)
    {
        float currentX = (*vertices)[0].x;
        float currentY = (*vertices)[0].y;
        
        if(currentX < minX)
        {
            minX = currentX;
            i_MinX = i;
        }
        else if(currentX > maxX)
        {
            maxX = currentX;
            i_MaxX = i;
        }
        
        if(currentY < minY)
        {
            minY = currentY;
            i_MinY = i;
        }
        else if(currentY > maxY)
        {
            maxY = currentY;
            i_MaxY = i;
        }
    }
    
    ABQuad ret;
    ret.min.x = (*vertices)[i_MinX].x;
    ret.min.y = (*vertices)[i_MinY].y;
    ret.max.x = (*vertices)[i_MaxX].x;
    ret.max.y = (*vertices)[i_MaxY].y;
    ret.percentUp = (*vertices)[i_MaxY].x - ret.min.x < epsilon ? 0 : (ret.max.x - ret.min.x) / ((*vertices)[i_MaxY].x - ret.min.x);
    ret.percentDown = (*vertices)[i_MinY].x - ret.min.x < epsilon ? 0 : (ret.max.x - ret.min.x) / ((*vertices)[i_MinY].x - ret.min.x);
    ret.percentRight = (*vertices)[i_MinX].y - ret.min.y < epsilon ? 0 : (ret.max.y - ret.min.y) / ((*vertices)[i_MinX].y - ret.min.y);
    ret.percentLeft = (*vertices)[i_MaxX].y - ret.min.y < epsilon ? 0 : (ret.max.y - ret.min.y) / ((*vertices)[i_MaxX].y - ret.min.y);
    
    return ret;
}

CollisionTest::CircQuad CollisionTest::getCircQuad(cocos2d::Vec2& center, float radius)
{
    CircQuad ret;
    ret.min.x = center.x - radius;
    ret.min.y = center.y - radius;
    ret.max.x = center.x + radius;
    ret.max.y = center.y + radius;
    
    return ret;
}

bool CollisionTest::abIntersect(ABQuad ab, CircQuad circ)
{
    
    
    return false;
}

CollisionTest::POINT_WINDING CollisionTest::getWinding(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4)
{
    return getWinding(p1, p2, p3) == POINT_WINDING::ERR ? getWinding(p2, p3, p4) : POINT_WINDING::ERR;
}

CollisionTest::POINT_WINDING CollisionTest::getWinding(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3)
{
    float epsilon = 0.0000001;
    
    float cp = (p1.x - p3.x) * (p2.y - p3.y) - (p1.y - p3.y) * (p2.x - p3.x);
    
    if(fabs(cp) < epsilon)
    {
        return POINT_WINDING::ERR;
    }
    else
    {
        return cp > 0 ? POINT_WINDING::AC : POINT_WINDING::C;
    }
}

bool CollisionTest::test(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float radius)
{
//    if(testEdge(p1, p2, center) ||
//       testEdge(p2, p3, center) ||
//       testEdge(p3, p4, center) ||
//       testEdge(p4, p1, center) ||
//       testVertex(p1, p2, p3, center) ||
//       testVertex(p2, p3, p4, center) ||
//       testVertex(p3, p4, p1, center) ||
//       testVertex(p4, p1, p2, center))
//    {
//        return true;
//    }
//    
//    return true;
}
