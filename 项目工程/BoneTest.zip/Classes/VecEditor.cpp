//
//  VecEditor.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/27.
//
//

#include "VecEditor.hpp"

using namespace cocos2d;

VecEditor::VecEditor() :
__valueChangeCallback([](Vec3){})
{
    
}

VecEditor::~VecEditor()
{
    
}

VecEditor* VecEditor::create()
{
    VecEditor* pRet = new VecEditor();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

bool VecEditor::init()
{
    Widget::init();
    
    Size contentSize = Size(420, 90);
    Vec2 xPos = Vec2(80, 35);
    Vec2 yPos = Vec2(80 + 130, 35);
    Vec2 zPos = Vec2(80 + 130 * 2, 35);
    
    __background = DrawNode::create();
    __background->drawSolidRect(Vec2(0, 0), contentSize, Color4F(0.1, 0.1, 0.1, 0.8));
    this->addChild(__background);
    
    __x = TextFieldEx::create();
    __x->setTitle("x");
    __x->setContentChangeCallback(CC_CALLBACK_0(VecEditor::onValueChange, this));
    __x->setPosition(xPos);
    __x->setTitleColor(Color3B(230, 230, 0));
    this->addChild(__x);
    
    __y = TextFieldEx::create();
    __y->setTitle("y");
    __y->setContentChangeCallback(CC_CALLBACK_0(VecEditor::onValueChange, this));
    __y->setPosition(yPos);
    __y->setTitleColor(Color3B(0, 230, 230));
    this->addChild(__y);
    
    __z = TextFieldEx::create();
    __z->setTitle("z");
    __z->setContentChangeCallback(CC_CALLBACK_0(VecEditor::onValueChange, this));
    __z->setPosition(zPos);
    __z->setTitleColor(Color3B(230, 0, 230));
    this->addChild(__z);
    
    __title = Label::createWithSystemFont("CENTER:", "", 22);
    __title->setColor(Color3B(180, 180, 180));
    __title->setAnchorPoint(Vec2(0, 0));
    __title->setPosition(Vec2(10, 90 + 10));
    this->addChild(__title);
    
    this->setContentSize(contentSize);
    
    return true;
}

void VecEditor::onEnter()
{
    Widget::onEnter();
}

void VecEditor::onExit()
{
    Widget::onExit();
}

void VecEditor::setValue(cocos2d::Vec3 value)
{
    __x->setContent(value.x);
    __y->setContent(value.y);
    __z->setContent(value.z);
}

cocos2d::Vec3 VecEditor::getValue()
{
    return Vec3(__x->getContent(), __y->getContent(), __z->getContent());
}

void VecEditor::setValueChangeCallback(std::function<void(cocos2d::Vec3)> callback)
{
    __valueChangeCallback = callback;
}

void VecEditor::onValueChange()
{
    __valueChangeCallback(getValue());
}

void VecEditor::setTitle(std::string title)
{
    __title->setString(title);
}

void VecEditor::setMax(int max)
{
    __x->setMax(max);
    __y->setMax(max);
    __z->setMax(max);
}

void VecEditor::setTitleColor(cocos2d::Color3B color)
{
    __title->setColor(color);
}
