//
//  MoveComponent.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef MoveComponent_hpp
#define MoveComponent_hpp

#include "cocos2d.h"

class MoveComponent
{
public:
    MoveComponent();
    virtual ~MoveComponent();
    virtual void retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection);
    void update(float dt);
    void setSpeed(float speed);
    bool ended();
    
protected:
    float _speed;
    float _distance;
    bool _end;
    float _timeElapsed;
};

#endif /* MoveComponent_hpp */
