//
//  TroopSetTestCase.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef TroopSetTestCase_hpp
#define TroopSetTestCase_hpp

#include "cocos2d.h"
#include "IUpdate.h"

class ModelInspector;
class Group;
class SpawnElement;
class MoveComponent;
class UpdateController;
class TextFieldEx;
class GenerateParam;

class TroopSetTestCase : public cocos2d::Node, public IUpdate
{
    public: static TroopSetTestCase* getInstance();
    private: static TroopSetTestCase* _instance;
    
public:
    virtual bool init();
    virtual void onEnter();
    virtual void onExit();
    
public:
    void startTroop(int troopId);
    virtual void onUpdate(float dt);
    void createGroup(SpawnElement* config, Group* group, float timeOverflow, int spawnIndex, int spawnCircle);
    void createFish(SpawnElement* config, Group* group, float timeOverflow, int spawnIndex, int spawnCircle);
    MoveComponent* createMoveComponent(GenerateParam* config, float fishSpeed);
    void removeGroup(Group* group);
    void resetScene();
    void reloadConfig();
    int generateId();
    void addReloadButton();
    void addTextField();
    void drawMeasure();
    cocos2d::Node* createFishModelById(int fishId);
    bool onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *event);

private:
    ModelInspector* _inspector;
    std::map<int, Group*> _groups;
    std::map<Group*, cocos2d::Node*> _visualMaps;
    std::map<cocos2d::Node*, cocos2d::Label*> _positionLabels;
    
    std::vector<Group*> _pendingAddRequest;
    std::vector<Group*> _pendingRemoveRequest;
    cocos2d::Label* _reloadLabel;
    UpdateController* _updateController;
    
    TextFieldEx* _troopSelector;
    TextFieldEx* _presentorSelector;
    
    cocos2d::Node* _drawNodeXY;
    cocos2d::Node* _drawNodeZ;
    std::vector<cocos2d::Node*> _vMeasureLabel;
    
    int _seed;
};

#endif /* TroopSetTestCase_hpp */
