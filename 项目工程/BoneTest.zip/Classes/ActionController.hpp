//
//  ActionController.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/24.
//
//

#ifndef ActionController_hpp
#define ActionController_hpp

#include "cocos2d.h"
#include "ui/CocosGUI.h"

class ActionController : public cocos2d::Node
{
public:
    static ActionController* create();
    
public:
    ActionController();
    virtual ~ActionController();
    virtual bool init();
    
public:
    void setAction(cocos2d::ActionInterval* action);
    void setTarget(cocos2d::Node* target);
    void setFrameRate(int frameRate);
    void setFrameStepCallback(std::function<void ()> callback);
    virtual void onEnter();
    virtual void onExit();
    
private:
    void playScheduler(float dt);
    void onTouchDown();
    void onTouchUp();
    void onValueChanged();
    void onForward();
    void onBackward();
    void onPause();
    void onStart();
    void bind();
    void stepForward();
    void stepBackward();
    void onForwardStep();
    void onBackwardStep();
    
private:
    enum DIRECTION {FORWARD, BACKWARD};
    
private:
    float __frameRate;
    cocos2d::ActionInterval* __action;
    cocos2d::Node* __target;
    cocos2d::ui::Slider* __slider;
    float __currentTimePassed;
    bool __paused;
    float __timer;
    std::function<void ()> __frameStepCallback;
    DIRECTION __direction;
};

#endif /* ActionController_hpp */
