/*
  *���г����л�
  *2017��11��4��
  *@Author:xiaoxiong
 */
#include "VortexNode.h"
//Shader
USING_NS_CC;
VortexNode::VortexNode() :
	_vortexProgram(nullptr)
	, _backTexture(nullptr)
	, _foreTexture(nullptr)
	, _framebuffer(nullptr)
	,_radiusLoc(-1)
	,_angleLoc(-1)
	, _alphaLoc(-1)
	,_positionLoc(-1)
	,_fragCoordLoc(-1)
	,_angle(0)
	,_radius(0)
	, _alpha(0)
{

}

VortexNode::~VortexNode()
{
	_vortexProgram->release();
	_vortexProgram = nullptr;
	if (_backTexture)
		_backTexture->release();
	if (_framebuffer)
		_framebuffer->release();
	_foreTexture->release();
	_foreTexture = nullptr;
}

void    VortexNode::loadShader(const char *vsh, const char *fsh)
{
	//
	_vortexProgram = GLProgram::createWithFilenames("shader/Vortex_VS.glsl","shader/Vortex_FS.glsl");
	_vortexProgram->retain();
	_radiusLoc = _vortexProgram->getUniformLocation("u_radius");
	_angleLoc = _vortexProgram->getUniformLocation("u_angle");
	_alphaLoc = _vortexProgram->getUniformLocation("u_alpha");

	_positionLoc = _vortexProgram->getAttribLocation("a_position");
	_fragCoordLoc = _vortexProgram->getAttribLocation("a_texCoord");
}

bool VortexNode::initWithTexture(cocos2d::Texture2D *backTexture, cocos2d::Texture2D *foreTexture)
{
	Node::init();
	_backTexture = backTexture;
	_foreTexture = foreTexture;

	backTexture->retain();
	foreTexture->retain();
	setContentSize(backTexture->getContentSize());
	loadShader(nullptr, nullptr);
	return true;
}

bool VortexNode::initWithFramebuffer(const cocos2d::Size &frameSize, cocos2d::Texture2D *foreTexture)
{
	Node::init();
	_foreTexture = foreTexture;
	foreTexture->retain();
	_framebuffer = RenderFramebuffer::create(frameSize);
	auto &winSize = Director::getInstance()->getWinSize();
	setContentSize(winSize);
	//
	loadShader(NULL, NULL);
	return true;
}

VortexNode *VortexNode::create(const cocos2d::Size &frameSize, cocos2d::Texture2D *foreTexture)
{
	VortexNode *node = new VortexNode();
	node->initWithFramebuffer(frameSize, foreTexture);
	node->autorelease();
	return node;
}

VortexNode *VortexNode::create(cocos2d::Texture2D *backTexture, cocos2d::Texture2D *foreTexture)
{
	VortexNode *node = new VortexNode();
	node->initWithTexture(backTexture, foreTexture);
	node->autorelease();
	return node;
}

void VortexNode::swap()
{
    CCASSERT(_backTexture && _foreTexture, "Swap Texture can only be used when _backTexture and _foreTexture are not nullptr.");
    Texture2D *x=_backTexture;
    _backTexture=_foreTexture;
    _foreTexture=x;
}

void VortexNode::draw(cocos2d::Renderer *renderer, const cocos2d::Mat4& transform, uint32_t flags)
{
	_vortexCommand.init(_globalZOrder);
	_vortexCommand.func =CC_CALLBACK_0(VortexNode::drawVortex,this,transform,flags) ;
	renderer->addCommand(&_vortexCommand);
	if (_framebuffer)
		_framebuffer->save();
}

void VortexNode::drawVortex(const cocos2d::Mat4 &transform, uint32_t flags)
{
	if (_framebuffer)
		_framebuffer->restore();
	//
	_vortexProgram->use();
	_vortexProgram->setUniformsForBuiltins(transform);
	GL::bindVAO(0);
	GL::bindTexture2D(_backTexture->getName());
	GL::bindTexture2DN(1,_foreTexture->getName());
	GL::blendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

	float halfWidth = _contentSize.width*0.5f;
	float halfHeight = _contentSize.height*0.5f;
	//�������㻺����
	float   VertexData[16] = {
		-halfWidth,halfHeight, 0,0,
		-halfWidth,-halfHeight,0,1,
		halfWidth,halfHeight,1,0,
		halfWidth,-halfHeight,1,1
	};

	int defaultVertexId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &defaultVertexId);
	if (defaultVertexId != 0)
		glBindBuffer(GL_ARRAY_BUFFER,0);
	//
	glEnableVertexAttribArray(_positionLoc);
	glVertexAttribPointer(_positionLoc, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, VertexData);

	glEnableVertexAttribArray(_fragCoordLoc);
	glVertexAttribPointer(_fragCoordLoc,2,GL_FLOAT,GL_FALSE,sizeof(float)*4,VertexData+2);

	glUniform1f(_radiusLoc,_radius);
	glUniform1f(_angleLoc,_angle);
	glUniform1f(_alphaLoc,_alpha);

	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	//
	if (defaultVertexId != 0)
		glBindBuffer(GL_ARRAY_BUFFER,defaultVertexId);
}
/////////////////////////////////////////
ActionChangeVortex::ActionChangeVortex():
	_radiusSpeed(0)
	,_angleSpeed(0)
	,_alphaSpeed(0)
	,_startRadius(0)
	,_startAngle(0)
	,_startAlpha(0)
{

}

ActionChangeVortex *ActionChangeVortex::create(float duration, float radiusSpeed, float angleSpeed,float alphaSpeed)
{
	ActionChangeVortex *action = new ActionChangeVortex();
	action->initWithDuration(duration, radiusSpeed, angleSpeed,alphaSpeed);
	action->autorelease();
	return action;
}

void  ActionChangeVortex::initWithDuration(float duration, float radiusSpeed, float angleSpeed,float alphaSpeed)
{
	ActionInterval::initWithDuration(duration);
	_radiusSpeed = radiusSpeed;
	_angleSpeed = angleSpeed;
	_alphaSpeed = alphaSpeed;
}

void ActionChangeVortex::startWithTarget(cocos2d::Node *target)
{
	VortexNode *node = dynamic_cast<VortexNode*>(target);
	CCASSERT(node,"Target Node Must Be VortexNode Object.");
	_startRadius = node->getRadius();
	_startAngle = node->getAngle();
	_startAlpha = node->getAlpha();
	ActionInterval::startWithTarget(target);
}
void ActionChangeVortex::update(float time)
{
	VortexNode *node = (VortexNode *)_target;
	node->setAngle(_startAngle+_angleSpeed * time * _duration);
	node->setRadius(_startRadius + _radiusSpeed*time *_duration);
	node->setAlpha(_startAlpha + _alphaSpeed * time *_duration);
}
