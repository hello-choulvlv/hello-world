//
//  PausableAction.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/24.
//
//

#include "PausableAction.hpp"

PauseabelAction* PauseabelAction::create(cocos2d::ActionInterval* action)
{
    PauseabelAction* pRet = new PauseabelAction();
    pRet->__action = action;
    pRet->__action->retain();
    pRet->__pause = false;
    return pRet;
}

void PauseabelAction::pause()
{
    __pause = true;
}

void PauseabelAction::start()
{
    __pause = false;
}

void PauseabelAction::startWithTarget(cocos2d::Node* target)
{
    ActionInterval::startWithTarget(target);
    __action->startWithTarget(target);
}

void PauseabelAction::step(float dt)
{
    if(!__pause)
    {
        __action->step(dt);
    }
}

bool PauseabelAction::isDone() const
{
    return __action->isDone();
}
