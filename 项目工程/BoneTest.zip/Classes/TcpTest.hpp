//
//  TcpTest.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/13.
//
//

#ifndef TcpTest_hpp
#define TcpTest_hpp

#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <unistd.h>

class TcpTest
{
public:
    static void* ServerListen(void*);
    static void* ServerTransmission(void*);
    static void* ClientTransmission(void*);
    static void runServerListen();
    static void runServerTransmission(int transmissionHandle);
    static void runClientTransmission();
};

#endif /* TcpTest_hpp */
