//
//  ActionController.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/24.
//
//

#include "UpdateController.hpp"

using namespace cocos2d;
using namespace cocos2d::ui;

UpdateController* UpdateController::create()
{
    UpdateController* pRet = new UpdateController();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

UpdateController::UpdateController() :
__frameRate(0.016),
__target(nullptr),
__slider(nullptr),
__paused(true),
__timer(0),
__currentTimePassed(0),
__frameStepCallback([](){}),
__direction(DIRECTION::FORWARD),
__duration(1),
__updateStep(0)
{
    
}

UpdateController::~UpdateController()
{

}

bool UpdateController::init()
{
    __slider = Slider::create();
    __slider->loadBarTexture("slider/bar.png");
    __slider->loadSlidBallTextures("slider/slider.png");
    __slider->loadProgressBarTexture("slider/bar_progress.png");
    __slider->setScale9Enabled(true);
    __slider->setCapInsetProgressBarRenderer(Rect(15, 9, 200, 11));
    __slider->setCapInsetsBarRenderer(Rect(7, 3, 235, 9));
    __slider->setContentSize(Size(Director::getInstance()->getVisibleSize().width / 2, 28));
    __slider->setPosition(cocos2d::Vec2(Director::getInstance()->getVisibleSize().width / 2, 80));
    __slider->addEventListener([this](Ref* sender, Slider::EventType event){
        
        if(event == Slider::EventType::ON_PERCENTAGE_CHANGED)
        {
            this->onValueChanged();
        }
        else if(event == Slider::EventType::ON_SLIDEBALL_DOWN)
        {
            this->onTouchDown();
        }
        else if(event == Slider::EventType::ON_SLIDEBALL_UP)
        {
            this->onTouchUp();
        }
        else if(event == Slider::EventType::ON_SLIDEBALL_CANCEL)
        {
            this->onTouchUp();
        }
        
    });
    this->addChild(__slider);
    
    cocos2d::MenuItemLabel* item_backward = cocos2d::MenuItemLabel::create(Label::createWithSystemFont("BACKWARD", "", 24), [this](Ref*){
        
        this->onBackward();
        
    });
    cocos2d::MenuItemLabel* item_forward = cocos2d::MenuItemLabel::create(Label::createWithSystemFont("FORWARD", "", 24), [this](Ref*){
        
        this->onForward();
        
    });
    cocos2d::Menu* menu_play = cocos2d::Menu::create(item_backward, item_forward, NULL);
    menu_play->alignItemsHorizontallyWithPadding(Director::getInstance()->getVisibleSize().width / 2 + 200);
    menu_play->setPosition(cocos2d::Vec2(Director::getInstance()->getVisibleSize().width / 2, 80));
    this->addChild(menu_play);
    
    cocos2d::MenuItemLabel* item_forward_step = cocos2d::MenuItemLabel::create(Label::createWithSystemFont(">", "", 48), [this](Ref*){
        
        this->onForwardStep();
        
    });
    cocos2d::MenuItemLabel* item_backward_step = cocos2d::MenuItemLabel::create(Label::createWithSystemFont("<", "", 48), [this](Ref*){
        
        this->onBackwardStep();
        
    });
    
    cocos2d::Menu* menu_step = cocos2d::Menu::create(item_backward_step, item_forward_step, NULL);
    menu_step->alignItemsHorizontallyWithPadding(Director::getInstance()->getVisibleSize().width / 2 + 80);
    menu_step->setPosition(cocos2d::Vec2(Director::getInstance()->getVisibleSize().width / 2, 80));
    this->addChild(menu_step);
    
    return true;
}

void UpdateController::onEnter()
{
    Node::onEnter();
    
    this->schedule(schedule_selector(UpdateController::playScheduler), 0, CC_REPEAT_FOREVER, 0);
}

void UpdateController::onExit()
{
    Node::onExit();
    
    this->unschedule(schedule_selector(UpdateController::playScheduler));
}

void UpdateController::playScheduler(float dt)
{
    __timer = __timer + dt;
    
    while(__timer > __frameRate)
    {
        __timer = __timer - __frameRate;
        
        if(__direction == DIRECTION::FORWARD)
        {
            stepForward(__updateStep);
        }
        else
        {
            stepBackward(__updateStep);
        }
    }
}


void UpdateController::setTarget(IUpdate* target)
{
    if(target)
    {
        __target = target;
        
        bind();
    }
    else
    {
        printf("## ActionController ## Target is null or already running other actions");
    }
}

void UpdateController::setFrameRate(int frameRate)
{
    __frameRate = frameRate;
}

void UpdateController::setFrameStepCallback(std::function<void ()> callback)
{
    __frameStepCallback = callback;
}

void UpdateController::bind()
{

}

void UpdateController::onTouchDown()
{
    onPause();
}

void UpdateController::onTouchUp()
{

}

void UpdateController::setDuration(float duration)
{
    __duration = duration;
}

void UpdateController::onValueChanged()
{
    float percentage = __slider->getPercent() / 100.0f;
    float currentTime = __duration * percentage;
    
    __target->onUpdate(currentTime - __currentTimePassed);
    
    __currentTimePassed = currentTime;
    
    __frameStepCallback();
}

void UpdateController::onForward()
{
    if(!__paused && __direction == DIRECTION::FORWARD)
    {
        onPause();
    }
    else
    {
        __direction = DIRECTION::FORWARD;
        onStart();
    }
}

void UpdateController::onBackward()
{
    if(!__paused && __direction == DIRECTION::BACKWARD)
    {
        onPause();
    }
    else
    {
        __direction = DIRECTION::BACKWARD;
        onStart();
    }
}

void UpdateController::onPause()
{
    __paused = true;
    __updateStep = 0;
}

void UpdateController::onStart()
{
    __paused = false;
    __updateStep = __frameRate;
}

void UpdateController::onForwardStep()
{
    onPause();
    stepForward(1);
}

void UpdateController::onBackwardStep()
{
    onPause();
    stepBackward(1);
}

void UpdateController::stepForward(float step)
{
    float time = __currentTimePassed + step;
    
    if(time > __duration)
    {
        step = __currentTimePassed - __duration;
        __currentTimePassed = __duration;
    }
    else
    {
        __currentTimePassed = time;
    }
    
    float percentage = __currentTimePassed / __duration;
    
    __target->onUpdate(step);
    __slider->setPercent(percentage * 100);
    __frameStepCallback();

}

void UpdateController::stepBackward(float step)
{
    float time = __currentTimePassed - step;
    
    if(time < 0)
    {
        step = __currentTimePassed;
        __currentTimePassed = 0;
    }
    else
    {
        __currentTimePassed = time;
    }
    
    float percentage = __currentTimePassed / __duration;
    
    __target->onUpdate(-step);
    __slider->setPercent(percentage * 100);
    __frameStepCallback();
}

void UpdateController::reset()
{
    __paused = true;
    __timer = 0;
    __currentTimePassed = 0;
    __direction = DIRECTION::FORWARD;
    __updateStep = 0;
    __slider->setPercent(0);
}
