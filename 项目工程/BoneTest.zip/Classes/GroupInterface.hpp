//
//  GroupInterface.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#ifndef GroupInterface_hpp
#define GroupInterface_hpp

class IGroup;

class IMember
{
public:
    IMember():_group(nullptr) {}
    virtual ~IMember();
    virtual void enterGroup() {};
    virtual void exitGroup() {};
    void setGroup(IGroup* group);
    IGroup* getGroup();
    
protected:
    IGroup* _group;
};

class IGroup : public IMember
{
public:
    virtual ~IGroup();
    void addMember(IMember* member);
    void removeMember(IMember* member);
    std::list<IMember*>& getMembers();
    
protected:
    std::list<IMember*> _members;
};

#endif /* GroupInterface_hpp */
