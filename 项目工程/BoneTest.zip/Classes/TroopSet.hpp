//
//  TroopSet.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/5.
//
//

#ifndef TroopSet_hpp
#define TroopSet_hpp

#include "cocos2d.h"
#include "TransformAction.hpp"
#include "NavigatorCircle.hpp"
#include "SpiralRoute.hpp"
#include "TroopConfig.hpp"

class Generator;
class IGroup;

class IMember
{
public:
    virtual ~IMember() {};
    void setGroup(IGroup* group);
    IGroup* getGroup();
    
protected:
    IGroup* _group;
};

class IGroup : public IMember
{
public:
    virtual ~IGroup() {};
    void addMember(IMember* member);
    void removeMember(IMember* member);
    std::list<IMember*>& getMembers();
    
protected:
    std::list<IMember*> _members;
};

class Group : public IGroup
{
public:
    Group();
    virtual ~Group();
    void setConfig(GroupConfig& config);
    void update(float dt);
    cocos2d::Mat4 getTransform();
    
private:
    void buildTransformWithParam(cocos2d::Vec3 translation, cocos2d::Vec3 rotation, float roll, float scale, cocos2d::Mat4& transform);
    
private:
    TransformAction* _transformAction;
    TransformAction::ActionTarget _transformResult;
    std::vector<Generator*> _generators;
    bool _transformUpdated;
    cocos2d::Mat4 _cachedTransform;
    SpiralRoute* _route;
    float _distance;
};


class Generator
{
public:
    Generator();
    void setConfig(GeneratorConfig& config);
    void update(float dt);
    void setGroup(Group* group);
    
private:
    float delayTick(float dt);
    float spawnTick(float dt);
    void doSpawn();
    void generateTypes();
    void generateFish(SpawnElement& config);
    void generateGroup(SpawnElement& group);
    
private:
    GeneratorConfig _config;
    Group* _group;
    float _delayTimer;
    float _spawnTimer;
    float _spawnCount;
    float _generateId;
};

#endif /* TroopSet_hpp */
