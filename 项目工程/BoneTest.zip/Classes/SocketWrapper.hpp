//
//  SocketWrapper.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/14.
//
//

#ifndef SocketWrapper_hpp
#define SocketWrapper_hpp

#include <sys/socket.h>
#include <netinet/in.h>
#include "NetworkDeclarations.h"

class SocketWrapper
{
private:
    static int INVALID_HANDLE;
    
public:
    SocketWrapper();
    virtual ~SocketWrapper();
    
public:
    int getHandle();
    
public:
    virtual bool bind(Network::Address* addr = nullptr);
    virtual bool bind(Network::Address& addr);
    virtual bool connect(Network::Address* addr = nullptr);
    virtual bool connect(Network::Address& addr);
    virtual bool listen();
    virtual int receive(void* data, size_t length);
    virtual int send(void* data, size_t length);
    virtual bool isConnected();
    virtual void close();
    virtual bool accept();
    
protected:
    static void copyLiteral(Network::Address& src, Network::Address& dst);
    static void sockAddrLocal(Network::Address& literal, sockaddr_in& sock);
    static void sockAddrRemote(Network::Address& literal, sockaddr_in& sock);
    static void literalAddrLocal(sockaddr_in& sock, Network::Address& literal);
    static void literalAddrRemote(sockaddr_in& sock, Network::Address& literal);
    static bool validHandle(int handle);
    static bool validAddress(sockaddr_in& addr);
    
protected:
    int __handle;
    Network::Address __literalLocal;
    Network::Address __literalRemote;
    sockaddr_in __sockLocal;
    sockaddr_in __sockRemote;
};

#endif /* SocketWrapper_hpp */
