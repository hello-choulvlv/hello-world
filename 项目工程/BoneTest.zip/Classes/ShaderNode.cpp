//   ShaderNode.cpp  
#include "ShaderNode.h"  
USING_NS_CC;
const int  VertexAttribFloatCount = 4;//ÿ������ĸ���������Ŀ
static struct
{
	float fx, fy;
}  _staicMeshTypeFactor[5] = { 
	{-0.5f,-0.5f},//��Ļ����
	{0.0f,0.0f},//���½�
	{0.0f,-1.0f},//���Ͻ�
	{-1.0f,0.0f},//���½�
	{-1.0f,-1.0f},//���Ͻ�
};
//
MeshPartition::MeshPartition()
{
	_vertexBufferId = 0;
	_normalBufferId = 0;
	_indexBufferId = 0;
	_countOfIndex = 0;
	_countOfVertex = 0;
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_meshType = MeshType_Center;
#endif
}

MeshPartition::~MeshPartition()
{
	glDeleteBuffers(1, &_vertexBufferId);
	glDeleteBuffers(1, &_normalBufferId);
	glDeleteBuffers(1, &_indexBufferId);
	_vertexBufferId = 0;
	_normalBufferId = 0;
	_indexBufferId = 0;
}

void MeshPartition::initWithMeshSquare(const cocos2d::Size &frameSize, int xgrid, int ygrid, bool isYReverse,MeshType meshType)
{
	assert(xgrid > 0 && ygrid > 0 && meshType>= MeshType_Center &&meshType <MeshType_Count);
	const float  offsetX = _staicMeshTypeFactor[meshType].fx * frameSize.width;
	const float  offsetY = _staicMeshTypeFactor[meshType].fy * frameSize.height;
	const float  fragCoordOffset = isYReverse ? 1.0f : 0.0f;
	const float  signCoord = isYReverse ? -1.0f: 1.0f;
	_countOfVertex = (xgrid + 1)*(ygrid + 1);
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_frameSize = frameSize;
	_xgrid = xgrid;
	_ygrid = ygrid;
	_isYReverse = isYReverse;
	_meshType = meshType;
#endif
	float *Vertex = new float[_countOfVertex*VertexAttribFloatCount];
	for (int j = 0; j < ygrid + 1; ++j)
	{
		const float factor = 1.0f * j / ygrid;
		const float y = frameSize.height*factor +offsetY;
		float  *nowVertex = Vertex + j*(xgrid + 1)*VertexAttribFloatCount;
		for (int i = 0; i < xgrid + 1; ++i)
		{
			const int index = i * VertexAttribFloatCount;
			nowVertex[index] = frameSize.width*i /xgrid +offsetX;
			nowVertex[index + 1] = y;
			//����VertexAttribFloatCount>=5���ܿ������������
			nowVertex[index + 2] = 1.0f * i / xgrid;
			nowVertex[index + 3] = signCoord* j / ygrid + fragCoordOffset;
		}
	}
	//generate index data
	_countOfIndex = xgrid*ygrid * 6;
	int *indexVertex = new int[_countOfIndex];
	const int xgrid_plus_one = xgrid + 1;
	for (int j = 0; j < ygrid; ++j)
	{
		int *nowIndex = indexVertex + j*xgrid * 6;
		for (int i = 0; i < xgrid; ++i)
		{
			const int _index = i * 6;
			nowIndex[_index] = (j + 1)*xgrid_plus_one + i;
			nowIndex[_index + 1] = j*xgrid_plus_one + i;
			nowIndex[_index + 2] = (j + 1)*xgrid_plus_one + (i + 1);

			nowIndex[_index + 3] = (j + 1)*xgrid_plus_one + (i + 1);
			nowIndex[_index + 4] = j*xgrid_plus_one + i;
			nowIndex[_index + 5] = j*xgrid_plus_one + i + 1;
		}
	}
	int _defaultVertexId, _defaultIndexId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &_defaultVertexId);
	glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &_defaultIndexId);
	//generate vertex and frag coord
	glGenBuffers(1, &_vertexBufferId);
	glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferId);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float)*_countOfVertex * VertexAttribFloatCount, Vertex, GL_STATIC_DRAW);
	//generate index 
	glGenBuffers(1, &_indexBufferId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBufferId);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(int)*_countOfIndex, indexVertex, GL_STATIC_DRAW);

	delete[] indexVertex;
	delete[] Vertex;
	glBindBuffer(GL_ARRAY_BUFFER, _defaultVertexId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _defaultIndexId);
}

void MeshPartition::drawMeshSquare(int posLoc, int fragCoordLoc)
{
	int _defaultVertexId;
	int _defaultIndexId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &_defaultVertexId);
	glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &_defaultIndexId);
	//bind vertex buffer
	glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferId);
	glEnableVertexAttribArray(posLoc);
	glVertexAttribPointer(posLoc, 2, GL_FLOAT, GL_FALSE, sizeof(float)*VertexAttribFloatCount, NULL);
	glEnableVertexAttribArray(fragCoordLoc);
	glVertexAttribPointer(fragCoordLoc, 2, GL_FLOAT, GL_FALSE, sizeof(float)*VertexAttribFloatCount, (void*)(sizeof(float) * 2));

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBufferId);
	glDrawElements(GL_TRIANGLES, _countOfIndex, GL_UNSIGNED_INT, NULL);

	glBindBuffer(GL_ARRAY_BUFFER, _defaultVertexId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _defaultIndexId);
}
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
void  MeshPartition::recreate()
{
	initWithMeshSquare(_frameSize, _xgrid, _ygrid, _isYReverse,_meshType);
}
#endif
MeshPartition *MeshPartition::createMeshSquare(const cocos2d::Size &frameSize, int xgrid, int ygrid, bool isYReverse,MeshType meshType)
{
	MeshPartition *_meshSquare = new MeshPartition();
	_meshSquare->initWithMeshSquare(frameSize, xgrid, ygrid, isYReverse, meshType);
	return _meshSquare;
}
////////////////////////////////////////////////////////

ShaderNode::ShaderNode():
	_framebuffer(nullptr)
	,_glProgram(nullptr)
	, _meshWater(nullptr)
	,_texture(nullptr)
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	,_backToForegroundListener(nullptr)
#endif
{  
      
}  

ShaderNode::~ShaderNode()
{
	if (_framebuffer)
		_framebuffer->release();
	_glProgram->release();
	_glProgram = nullptr;
	if(_texture)
		_texture->release();
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	if (_backToForegroundListener)
	{
		Director::getInstance()->getEventDispatcher()->removeEventListener(_backToForegroundListener);
		_backToForegroundListener = nullptr;
	}
#endif
}
  
ShaderNode* ShaderNode::create(const char *vert, const char *frag,int xgrid,const std::string &filename)  
{  
    ShaderNode* shader = new ShaderNode();
    if(shader && shader->initWithTexture(vert,frag,xgrid,filename))
    {  
        shader->autorelease();  
        return shader;  
    }
    CC_SAFE_DELETE(shader);
    return NULL;
}

ShaderNode *ShaderNode::create(const char *vert, const char *frag, int xgrid, const cocos2d::Size &frameSize)
{
	ShaderNode *shader = new ShaderNode();
	if (shader->initWithFramebuffer(vert, frag, xgrid,frameSize))
	{
		shader->autorelease();
		return shader;
	}
	delete shader;
	shader = nullptr;
	return shader;
}
  
void ShaderNode::loadShaderVertex(const char *vert, const char *frag)  
{  
    _glProgram = new GLProgram();  
	_glProgram = GLProgram::createWithFilenames(vert, frag);
	_glProgram->retain();
      
    //��ȡattribute������ʶ  
    _attributeFragCoord = _glProgram->getAttribLocation("a_texCoord");
    _attributePosition =   _glProgram->getAttribLocation( "a_position");
	_resolutionLoc = _glProgram->getUniformLocation("resolution");
	_colorLoc = _glProgram->getUniformLocation("u_color");

	_vertFilename = vert;
	_fragFilename = frag;
}  
  
void ShaderNode::setColor(const cocos2d::Color4F &newColor)  
{  
    _color.x = newColor.r;  
    _color.y = newColor.g;  
    _color.z= newColor.b;  
    _color.w = newColor.a;  
}  
  
bool ShaderNode::initWithTexture(const char *vert, const char *frag, int xgrid, const std::string &filename)
{  
	Node::init();
//    ��ȡshader����
    loadShaderVertex(vert,frag);  
//aaaa.pngΪ͸��ͼƬ
	_texture = CCTextureCache::getInstance()->addImage(filename);
	_texture->retain();
      
    setContentSize(_texture->getContentSize());
    //scheduleUpdate();
	auto &winSize = Director::getInstance()->getWinSize();
	_meshWater = MeshPartition::createMeshSquare(_contentSize, 0.5f + xgrid * winSize.width/winSize.height, true, MeshType_Center);
	setColor(Color4F(1,1,1,1));
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_backToForegroundListener = EventListenerCustom::create(EVENT_RENDERER_RECREATED, CC_CALLBACK_1(ShaderNode::recreate,this));
	Director::getInstance()->getEventDispatcher()->addEventListenerWithFixedPriority(_backToForegroundListener, -1);
#endif
    return true;
}

bool ShaderNode::initWithFramebuffer(const char *vert, const char *frag, int xgrid, const cocos2d::Size &frameSize)
{
	Node::init();
	loadShaderVertex(vert, frag);
	_framebuffer = RenderFramebuffer::create(frameSize);
	auto &winSize = Director::getInstance()->getWinSize();
	setContentSize(winSize);
	_meshWater = MeshPartition::createMeshSquare(frameSize,xgrid,0.5f+xgrid*winSize.height/winSize.width,false,MeshType::MeshType_Center);
	setColor(Color4F(1,1,1,1));

#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
	_backToForegroundListener = EventListenerCustom::create(EVENT_RENDERER_RECREATED, CC_CALLBACK_1(ShaderNode::recreate, this));
	Director::getInstance()->getEventDispatcher()->addEventListenerWithFixedPriority(_backToForegroundListener, -1);
#endif
	return true;
}
  
void ShaderNode::setContentSize(const Size& var)  
{  
    CCNode::setContentSize(var);  
} 

void ShaderNode::draw(cocos2d::Renderer *renderer, const cocos2d::Mat4& transform, uint32_t flags)
{
	_drawWaterCommand.init(_globalZOrder);
	_drawWaterCommand.func = CC_CALLBACK_0(ShaderNode::drawWater,this,transform,flags);
	renderer->addCommand(&_drawWaterCommand);
	//�ڴ˴��ж��Ƿ�����֡����������
	if (_framebuffer)
		_framebuffer->save();
}
  
void ShaderNode::drawWater( const cocos2d::Mat4& transform, uint32_t flags)
{  
	GL::bindVAO(0);
	int  textureName = 0;
	//�ж��Ƿ���Ⱦ������
	if (_framebuffer)
	{
		_framebuffer->restore();
		textureName = _framebuffer->getColorBuffer();
	}
	else
		textureName = _texture->getName();
	//
	_glProgram->use();
	_glProgram->setUniformsForBuiltins(transform);
    GL::bindTexture2D(textureName);               //����������Ԫ
	glUniform2f(_resolutionLoc, _contentSize.width, _contentSize.height);
	glUniform4fv(_colorLoc, 1, &_color.x);
	_meshWater->drawMeshSquare(_attributePosition,_attributeFragCoord);
}
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
void ShaderNode::recreate(cocos2d::EventCustom *recreateEvent)
{
	_glProgram->reset();
	_glProgram->initWithFilenames(_vertFilename, _fragFilename);
	_meshWater->recreate();
}
#endif