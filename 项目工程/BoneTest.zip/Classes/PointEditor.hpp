//
//  PointEditor.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/11.
//
//

#ifndef PointEditor_hpp
#define PointEditor_hpp

#include "cocos2d.h"

class DrawNode3D;
class AxisEditor;

class PointEditor : public cocos2d::Node
{
public:
    static PointEditor* create();
    PointEditor();
    virtual ~PointEditor();
    void setValue(cocos2d::Vec3 value);
    virtual void onEnter();
    virtual void onExit();

private:
    void setValueX(float x);
    void setValueY(float y);
    void setValueZ(float z);
    
private:
    AxisEditor* _axisEditorX;
    AxisEditor* _axisEditorY;
    AxisEditor* _axisEditorZ;
    cocos2d::Vec3 _value;
};

#endif /* PointEditor_hpp */
