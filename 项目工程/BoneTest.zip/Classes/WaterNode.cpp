//
//  WaterNode.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/8.
//
//

#include "WaterNode.hpp"

using namespace cocos2d;

WaterNode* WaterNode::create()
{
    WaterNode* pRet = new WaterNode();
    pRet->init();
    pRet->autorelease();
    pRet->dt = 0;
    pRet->time_passed = 0;
    
    return pRet;
}

void WaterNode::onEnter()
{
    Node::onEnter();
    
    setTextureRect(Rect(Vec2(0, 0), Director::getInstance()->getVisibleSize()));
    
    GLProgram* program = new GLProgram();
    program->initWithFilenames("waterShader/water.vert", "waterShader/water.frag");
    this->setGLProgram(program);
    program->bindAttribLocation(GLProgram::ATTRIBUTE_NAME_POSITION, GLProgram::VERTEX_ATTRIB_POSITION);
    program->link();
    program->updateUniforms();
    
    this->getScheduler()->schedule([this](float dt){
        
        this->dt = dt;
        this->time_passed += dt;
        
    }, this, 0.016, CC_REPEAT_FOREVER, 0, false, "update_time");
}

void WaterNode::draw(cocos2d::Renderer *renderer, const cocos2d::Mat4 &transform, uint32_t flags)
{
    GLProgram* gl = getGLProgram();
    gl->use();
    
    int location = gl->getUniformLocation("u_fTime");
    gl->setUniformLocationWith1f(location, time_passed);
    
    Sprite::draw(renderer, transform, flags);
}
