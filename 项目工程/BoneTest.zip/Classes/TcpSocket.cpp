//
//  TcpSocket.cpp
//  BoneTest
//
//  Created by charlie on 2017/4/14.
//
//

#include "TcpSocket.hpp"
#include "DebugPrint.hpp"
#include <fcntl.h>
#include <unistd.h>

using namespace Network;

CLASS_NAME(TcpSocket)

TcpSocket::TcpSocket()
:__connected(false)
{
    
}

TcpSocket::~TcpSocket()
{
    close();
}

bool TcpSocket::bind(Address& addr)
{
    if(__connected)
    {
        ERR_PRINT_C("Connect Rebind A Connected Socket!");
        return false;
    }
    
    close();
    
    sockaddr_in sockAddr;
    sockAddrLocal(addr, sockAddr);
    
    if(validAddress(sockAddr))
    {
        __sockLocal = sockAddr;
        copyLiteral(addr, __literalLocal);
        
        __handle = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
        
        if(__handle <= 0)
        {
            __handle = NETWORK_ERROR::PLAIN_ERROR;
            ERRNO_PRINT_C("Create Socket Failed");
            return false;
        }
        else
        {
            if(::bind(__handle, (const sockaddr*)&__sockLocal, sizeof(sockaddr_in)) == 0)
            {
                LOG_PRINT_C("Socket %d bind to %d.%d.%d.%d:%d", __handle, addr[ADDR_POS::A0], addr[ADDR_POS::A1], addr[ADDR_POS::A2], addr[ADDR_POS::A3], addr[ADDR_POS::PORT]);
                if(fcntl(__handle, F_SETFL, O_NONBLOCK, 1) == -1)
                {
                    ERRNO_PRINT_C("Socket %d failed to set non-blocking!", __handle);
                }
                
                return true;
            }
            else
            {
                ERRNO_PRINT_C("Socket %d Failed to bind %d.%d.%d.%d:%d", __handle, addr[ADDR_POS::A0], addr[ADDR_POS::A1], addr[ADDR_POS::A2], addr[ADDR_POS::A3], addr[ADDR_POS::PORT]);
                return false;
            }
        }
    }
    else
    {
        ERRNO_PRINT_C("Invalid Local Address %d.%d.%d.%d:%d", addr[ADDR_POS::A0], addr[ADDR_POS::A1], addr[ADDR_POS::A2], addr[ADDR_POS::A3], addr[ADDR_POS::PORT]);
        return false;
    }
}

bool TcpSocket::connect(Address& addr)
{
    if(validHandle(__handle))
    {
        sockaddr_in sockAddr;
        sockAddrLocal(addr, sockAddr);
        
        if(validAddress(sockAddr))
        {
            __sockRemote = sockAddr;
            copyLiteral(addr, __literalRemote);
            
            if(::connect(__handle, (sockaddr*)&__sockRemote, sizeof(sockaddr_in)) == 0)
            {
                LOG_PRINT_C("Socket %d Connect To Remote %d.%d.%d.%d:%d", __handle, addr[ADDR_POS::A0], addr[ADDR_POS::A1], addr[ADDR_POS::A2], addr[ADDR_POS::A3], addr[ADDR_POS::PORT]);
                __connected = true;
                return true;
            }
            else
            {
                ERRNO_PRINT_C("Socket %d Failed To Connect %d.%d.%d.%d:%d", __handle, addr[ADDR_POS::A0], addr[ADDR_POS::A1], addr[ADDR_POS::A2], addr[ADDR_POS::A3], addr[ADDR_POS::PORT]);
                return false;
            }
        }
        else
        {
            ERRNO_PRINT_C("Invalid Remote Address %d.%d.%d.%d:%d", addr[ADDR_POS::A0], addr[ADDR_POS::A1], addr[ADDR_POS::A2], addr[ADDR_POS::A3], addr[ADDR_POS::PORT]);
            return false;
        }
    }
    else
    {
        ERR_PRINT_C("Invalid Socket!");
        return false;
    }
}

bool TcpSocket::listen()
{
    if(validHandle(__handle))
    {
        if(::listen(__handle, 10) == 0)
        {
            LOG_PRINT_C("Socket %d start listen", __handle);
            return true;
        }
        else
        {
            ERRNO_PRINT_C("Socket %d Listen failed!", __handle);
            return false;
        }
    }
    else
    {
        ERR_PRINT_C("Invalid Socket!");
        return false;
    }
}

int TcpSocket::receive(void* data, size_t length)
{
    if(validHandle(__handle))
    {
        int result = recv(__handle, data, length, 0);
        
        if(result < 0)
        {
            ERRNO_PRINT_C("Socket %d receive failed!", __handle);
            return NETWORK_ERROR::PLAIN_ERROR;
        }
        else
        {
            LOG_PRINT_C("Socket %d received %d bytes", __handle, result);
            return result;
        }
    }
    else
    {
        return NETWORK_ERROR::PLAIN_ERROR;
    }
}

int TcpSocket::send(void* data, size_t length)
{
    if(validHandle(__handle))
    {
        int result = ::send(__handle, data, length, 0);
        
        if(result < 0)
        {
            ERRNO_PRINT_C("Socket %d send failed!", __handle);
            return NETWORK_ERROR::PLAIN_ERROR;
        }
        else
        {
            LOG_PRINT_C("Socket %d sent %d bytes", __handle, result);
            return result;
        }
    }
    else
    {
        return NETWORK_ERROR::PLAIN_ERROR;
    }
}

bool TcpSocket::isConnected()
{
    return validHandle(__handle) && __connected;
}

void TcpSocket::close()
{
    if(validHandle(__handle))
    {
        LOG_PRINT_C("Socket %d closed", __handle);
        ::close(__handle);
        __handle = -1;
        __connected = false;
    }
}

bool TcpSocket::accept()
{
    if(validHandle(__handle))
    {
        sockaddr_in remote;
        socklen_t size = sizeof(sockaddr_in);
        
        if(::accept(__handle, (sockaddr*)&remote, &size) == 0)
        {
            __connected = true;
            __sockRemote = remote;
            literalAddrLocal(remote, __literalRemote);
            return true;
        }
        else
        {
            ERRNO_PRINT_C("Socket %d accept failed!", __handle);
            return false;
        }
    }
    else
    {
        ERR_PRINT_C("Invalid Socket!");
        return false;
    }
}
