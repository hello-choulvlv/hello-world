//
//  MoveComponentDirection.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef MoveComponentDirection_hpp
#define MoveComponentDirection_hpp

#include "MoveComponent.hpp"

class MoveComponentDirection : public MoveComponent
{
public:
    MoveComponentDirection();
    virtual ~MoveComponentDirection();
    virtual void retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection);
    
public:
    void setStartPosition(cocos2d::Vec3 position);
    void setStartDirection(cocos2d::Vec3 direction);
    void setDuration(float direction);
    
private:
    cocos2d::Vec3 _start;
    cocos2d::Vec3 _direction;
    float _duration;
};

#endif /* MoveComponentDirection_hpp */
