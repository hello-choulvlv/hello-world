//
//  TcpSocket.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/14.
//
//

#ifndef TcpSocket_hpp
#define TcpSocket_hpp

#include "SocketWrapper.hpp"

class TcpSocket : public SocketWrapper
{
public:
    TcpSocket();
    virtual ~TcpSocket();
    
public:
    virtual bool bind(Network::Address& addr);
    virtual bool connect(Network::Address& addr);
    virtual bool listen();
    virtual bool accept();
    virtual int receive(void* data, size_t length);
    virtual int send(void* data, size_t length);
    virtual bool isConnected();
    virtual void close();
    
private:
    bool __connected;

};


#endif /* TcpSocket_hpp */
