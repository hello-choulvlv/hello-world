//
//  NetworkEntity.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/14.
//
//

#ifndef NetworkEntity_hpp
#define NetworkEntity_hpp

#include "TcpSocket.hpp"

class NetworkEntity
{
    virtual int receive(SocketWrapper* channel, Network::Packet* received);
    virtual int send(SocketWrapper* channel, Network::Packet* sent);
};

#endif /* NetworkEntity_hpp */
