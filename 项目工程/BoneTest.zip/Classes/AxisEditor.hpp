//
//  AxisEditor.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/11.
//
//

#ifndef AxisEditor_hpp
#define AxisEditor_hpp

#include "cocos2d.h"

class DrawNode3D;
class TouchCollision;

class FloatException {};

class AxisEditor : public cocos2d::Node
{
public:
    static AxisEditor* create();
    AxisEditor();
    virtual ~AxisEditor();
    virtual void onEnter();
    virtual void onExit();
    virtual void update(float dt);
    virtual bool onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event);
    virtual void onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* event);
    virtual cocos2d::Vec3 getIntersect(cocos2d::Vec2 touchLocation);
    virtual float getProjectedDistance(cocos2d::Vec3 intersect);
    float getValue();
    void setValue(float value);
    void setValueChangedCallback(std::function<void ()> callback);
    void setMinMax(float min, float max);
    
protected:
    DrawNode3D* _drawNode;
    TouchCollision* _touchCollision;
    cocos2d::Label* _label;
    float _value;
    float _startValue;
    cocos2d::Vec3 _startPosition;
    std::function<void ()> _onValueChanged;
    float _min, _max;
};

class AxisEditorX : public AxisEditor
{
public:
    static AxisEditorX* create();
    AxisEditorX();
    virtual ~AxisEditorX();
    virtual cocos2d::Vec3 getIntersect(cocos2d::Vec2 touchLocation);
    virtual float getProjectedDistance(cocos2d::Vec3 intersect);
};

class AxisEditorY : public AxisEditor
{
public:
    static AxisEditorY* create();
    AxisEditorY();
    virtual ~AxisEditorY();
    virtual cocos2d::Vec3 getIntersect(cocos2d::Vec2 touchLocation);
    virtual float getProjectedDistance(cocos2d::Vec3 intersect);
};

class AxisEditorZ : public AxisEditor
{
public:
    static AxisEditorZ* create();
    AxisEditorZ();
    virtual ~AxisEditorZ();
    virtual cocos2d::Vec3 getIntersect(cocos2d::Vec2 touchLocation);
    virtual float getProjectedDistance(cocos2d::Vec3 intersect);
};

#endif /* AxisEditor_hpp */
