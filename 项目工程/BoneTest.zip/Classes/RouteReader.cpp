//
//  RouteReader.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/16.
//
//

#include "RouteReader.hpp"

using namespace cocos2d;
using namespace std;

RouteReader* RouteReader::__spInstance = nullptr;

RouteReader* RouteReader::getInstance()
{
    if(__spInstance == nullptr)
    {
        __spInstance = new RouteReader();
        __spInstance->init();
    }
    
    return __spInstance;
}

RouteReader::RouteInfo* RouteReader::read(std::string fileName)
{
    clearNode();
    
    RouteInfo* ret = new std::map<std::string, std::vector<cocos2d::Vec3>>();
    
    string jsonStr = FileUtils::getInstance()->getStringFromFile(fileName);
    rapidjson::Document reader;
    
    if (reader.ParseInsitu<0>((char*)jsonStr.c_str()).HasParseError())
    {
        CCLOG("Parse json failed in Bundle3D::loadJson function");
    }
    
    buildNode(reader);
    
    if(reader.HasMember("lines"))
    {
        const rapidjson::Value& lines = reader["lines"];
        
        for(rapidjson::SizeType i = 0; i < lines.Size(); i++)
        {
            const rapidjson::Value& line = lines[i];
            std::string lineName = line["name"].GetString();
            
            (*ret)[lineName] = std::vector<cocos2d::Vec3>();
            
            Mat4 transform = findTransform(lineName);
            
            const rapidjson::Value& vertices = line["vertices"];
            
            std::vector<cocos2d::Vec3>& verts = (*ret)[lineName];
            
            for(rapidjson::SizeType vIndex = 0; vIndex < vertices.Size(); vIndex += 3)
            {
                Vec3 original = Vec3(vertices[vIndex].GetDouble(), vertices[vIndex + 1].GetDouble(),vertices[vIndex + 2].GetDouble());
                
                transform.translate(original);
                
                verts.push_back(original);
            }
        }
    }
    
    return ret;
}

void RouteReader::init()
{
    createRootNode();
}

void RouteReader::createRootNode()
{
    __pRoot = new FbxNode();
    __pRoot->transform = Mat4::IDENTITY;
    __pRoot->name = "root";
}

void RouteReader::clearNode()
{
    clearNodeRecursively(__pRoot);
}

void RouteReader::clearNodeRecursively(RouteReader::FbxNode *node)
{
    int numOfChildren = node->children.size();
    
    for(int i = 0; i < numOfChildren; i++)
    {
        clearNodeRecursively(node->children[i]);
    }
    
    delete node;
}

void RouteReader::buildNode(rapidjson::Document& reader)
{
    createRootNode();
    
    const rapidjson::Value& nodes = reader["nodes"];
    
    for(rapidjson::SizeType i = 0; i < nodes.Size(); i++)
    {
        __pRoot->children.push_back(buildNodeRecursively(nodes[i]));
    }
}

RouteReader::FbxNode* RouteReader::buildNodeRecursively(const rapidjson::Value& nodeData)
{
    FbxNode* node = new FbxNode();
    
    node->name = nodeData["id"].GetString();
    
    const rapidjson::Value& transform = nodeData["transform"];
    
    for (rapidjson::SizeType j = 0; j < transform.Size(); j++)
    {
        node->transform.m[j] = transform[j].GetDouble();
    }
    
    if(nodeData.HasMember("children"))
    {
        const rapidjson::Value& children = nodeData["children"];
        for (rapidjson::SizeType i = 0; i <  children.Size(); i++)
        {
            node->children.push_back(buildNodeRecursively(children[i]));
        }
    }
    
    return node;
}

cocos2d::Mat4 RouteReader::findTransform(std::string name)
{
    std::list<cocos2d::Mat4> transformChian;
    
    if(findTransformRecursively(name, __pRoot, transformChian))
    {
        Mat4 ret = Mat4::IDENTITY;
        
        for(auto iter = transformChian.begin(); iter != transformChian.end(); iter++)
        {
            ret = ret * (*iter);
        }
        
        return ret;
    }
    else
    {
        return Mat4::IDENTITY;
    }
}

bool RouteReader::findTransformRecursively(std::string& name, RouteReader::FbxNode* node, std::list<cocos2d::Mat4>& transformChain)
{
    if(node->name == name)
    {
        transformChain.push_front(node->transform);
        return true;
    }
    
    for(auto iter = node->children.begin(); iter != node->children.end(); iter++)
    {
        if(findTransformRecursively(name, *iter, transformChain))
        {
            transformChain.push_front(node->transform);
            return true;
        }
    }
    
    return false;
}
