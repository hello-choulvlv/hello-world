//
//  GeneratorCreator.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#ifndef GeneratorCreator_hpp
#define GeneratorCreator_hpp

#include <TroopSet.hpp>

class GeneratorCreator
{
public:
    static GeneratorCreator* getInstance();
    static GeneratorCreator* _instance;
    
    cocos2d::Vec3 stringToVec3(std::string str);
    float stringToNumber(std::string str);
};

#endif /* GeneratorCreator_hpp */
