//
//  TcpTest.cpp
//  BoneTest
//
//  Created by charlie on 2017/4/13.
//
//

#include "TcpTest.hpp"
#include "cocos2d.h"
#include "DebugPrint.hpp"

CLASS_NAME(TcpTest)

void* TcpTest::ServerListen(void*)
{
    unsigned int literal[5] = {10, 10, 10, 27, 30000};
    
    sockaddr_in addr;
    memset((void*)&addr, 0, sizeof(sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl((unsigned int)0);//htonl(literal[0]<<24 | literal[1]<<16 | literal[2]<<8 | literal[3]<<0);
    addr.sin_port = htons((unsigned short)literal[4]); //htons(literal[4]);
    
    int listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if(listenSock > 0)
    {
        LOG_PRINT_C("create server sock")
        
//        if(fcntl(listenSock, F_SETFL, O_NONBLOCK, 1) == 0)
//        {
//            LOG_PRINT_C("server set to non-block")
        
        int enable = 1;
        setsockopt(listenSock, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int));
        
            if(bind(listenSock, (sockaddr*)&addr, sizeof(sockaddr_in)) == 0)
            {
                LOG_PRINT_C("server binded")
                if(listen(listenSock, 10) == 0)
                {
                    LOG_PRINT_C("server start listen")
                    int transmissionHandle = accept(listenSock, nullptr, nullptr);
                    
                    if(transmissionHandle > 0)
                    {
                        LOG_PRINT_C("server accept connection")
                        runServerTransmission(transmissionHandle);
                    }
                    else
                    {
                        ERRNO_PRINT_C("server failed to accept")
                    }
                }
                else
                {
                    ERRNO_PRINT_C("server failed to listen")
                }
            }
            else
            {
                ERRNO_PRINT_C("server failed to bind")
            }
//        }
//        else
//        {
//            ERRNO_PRINT_C("failed to set server sock non-blocking")
//        }
    }
    else
    {
        ERRNO_PRINT_C("failed to create server sock")
    }
    
    return nullptr;
}

void* TcpTest::ClientTransmission(void*)
{
    unsigned int literal[5] = {10, 10, 10, 27, 30000};
    
    sockaddr_in addr;
    memset((void*)&addr, 0, sizeof(sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(literal[0]<<24 | literal[1]<<16 | literal[2]<<8 | literal[3]<<0);
    addr.sin_port = htons((unsigned short)literal[4]);
    
    int connectionSock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    
    if(connectionSock > 0)
    {
        LOG_PRINT_C("create client sock")
//        if(fcntl(connectionSock, F_SETFL, O_NONBLOCK, 1) == 0)
//        {
//            LOG_PRINT_C("client set to non-block")
            if(connect(connectionSock, (sockaddr*)&addr, sizeof(sockaddr_in)) == 0)
            {
                LOG_PRINT_C("client connect successful")
            }
            else
            {
                ERRNO_PRINT_C("client failed to connect")
            }
//        }
//        else
//        {
//            ERRNO_PRINT_C("failed to set client sock non-blocking")
//        }
    }
    else
    {
        ERRNO_PRINT_C("failed to create client sock")
    }
    
    return nullptr;
}

void* TcpTest::ServerTransmission(void* transmissionHandle)
{
    
    
    return nullptr;
}

void TcpTest::runServerListen()
{
    pthread_t thread;
    pthread_create(&thread, nullptr, TcpTest::ServerListen, nullptr);
}

void TcpTest::runClientTransmission()
{
    pthread_t thread;
    pthread_create(&thread, nullptr, TcpTest::ClientTransmission, nullptr);
}

void TcpTest::runServerTransmission(int transmissionHandle)
{
    pthread_t thread;
    pthread_create(&thread, nullptr, TcpTest::ServerTransmission, (void*)&transmissionHandle);
}
