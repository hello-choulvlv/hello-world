//
//  OpenFileDialog.m
//  BoneTest
//
//  Created by charlie on 2017/7/20.
//
//

#include "OpenFileDialog.h"
#import <Foundation/Foundation.h>
//#import <AppKit/NSOpenPanel.h>


OpenFileDialog::OpenFileDialog()
{
    //NSOpenPanel* dialog = [NSOpenPanel openPanel];
    //[dialog setCanChooseFiles:YES];
    //[dialog setCanChooseDirectories:NO];
    //[dialog setAllowsMultipleSelection:NO];
    //[dialog setPrompt:@"Select"];
   // [dialog setDirectoryURL:[NSURL URLWithString:@"/Users/charlie/Workspace/BoneTest/Resources"]];
   // [dialog setNameFieldStringValue:@""];
    
   // _cocoaDialog = dialog;
}

OpenFileDialog::~OpenFileDialog()
{
    
}

void OpenFileDialog::open()
{
    //NSOpenPanel* dialog = (NSOpenPanel*)_cocoaDialog;
    
    //if ([dialog runModal] == NSOKButton )
   // {
   //     NSArray<NSURL*>* files = [dialog URLs];
   //
    //    for(int i = 0; i < [files count]; i++ )
   //     {
    //        NSURL* url = [files objectAtIndex:i];
   //         NSString* str = [url absoluteString];
    //
    ////        _selectedFile = [str UTF8String];
    //    }
   // }
}

std::string OpenFileDialog::getSelectedFileName()
{
    return _selectedFile;
}

