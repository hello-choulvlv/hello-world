//
//  CollisionArea.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/18.
//
//

#include "CollisionArea.hpp"

using namespace cocos2d;

CollisionArea* CollisionArea::create()
{
    CollisionArea* pRet = new CollisionArea();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

CollisionArea::CollisionArea() :
__pSkeleton(nullptr)
{
    
}

CollisionArea::~CollisionArea()
{
    
}

void CollisionArea::loadConfig(std::map<std::string, cocos2d::OBB> areaConfig)
{
    this->__mAreaConfig = areaConfig;
    
    if(this->__pSkeleton != nullptr)
    {
        bind();
    }
}

void CollisionArea::bindToSkeleton(cocos2d::Skeleton3D* skeleton)
{
    if(skeleton != nullptr)
    {
        this->__pSkeleton = skeleton;
        bind();
    }
}

void CollisionArea::bind()
{
    __vAreaBinding.clear();
    __mfastLookup.clear();
    
    for(auto iter = __mAreaConfig.begin(); iter != __mAreaConfig.end(); iter++)
    {
        int boneCount = __pSkeleton->getBoneCount();
        int findResult = 0;
        
        for(; findResult < boneCount; findResult++)
        {
            Bone3D* bone = __pSkeleton->getBoneByIndex(findResult);
            
            if(bone->getName() == iter->first)
            {
                break;
            }
        }
        
        if(findResult != boneCount)
        {
            __mfastLookup[findResult] = iter->second;
            __vAreaBinding.push_back(std::pair<int, cocos2d::OBB>(findResult, iter->second));
        }
        else
        {
            printf("Bone: [%s] not found in skeleton", iter->first.c_str());
        }
    }
}

void CollisionArea::visit(cocos2d::Renderer *renderer, const cocos2d::Mat4& parentTransform, uint32_t parentFlags)
{
    for(int i = 0; i < __vAreaBinding.size(); i++)
    {
        int index = __vAreaBinding[i].first;
        OBB& original = __mfastLookup[index];
        OBB& target = __vAreaBinding[i].second;
        
        Bone3D* bone = __pSkeleton->getBoneByIndex(index);
        
        Mat4 boneTransform = bone->getWorldMat();
        Mat4 nodeTransform = getNodeToWorldTransform();
        Mat4 worldTransform = nodeTransform * boneTransform;
        
        updateObb(original, target, worldTransform);
        
        Vec3 boneModelPosition = Vec3(boneTransform.m[12], boneTransform.m[13], boneTransform.m[14]);
        nodeTransform.transformPoint(&boneModelPosition);
        
        Vec3 origin = Vec3(0, 0, 0);
        worldTransform.transformPoint(&origin);
        
        int a = 0;
    }
}

void CollisionArea::updateObb(cocos2d::OBB& original, cocos2d::OBB& target, cocos2d::Mat4& transform)
{
    Vec4 newcenter = transform * Vec4(original._center.x, original._center.y, original._center.z, 1.0f);// center;
    target._center.x = newcenter.x;
    target._center.y = newcenter.y;
    target._center.z = newcenter.z;
    
    target._xAxis = transform * original._xAxis;
    target._yAxis = transform * original._yAxis;
    target._zAxis = transform * original._zAxis;
    
    target._xAxis.normalize();
    target._yAxis.normalize();
    target._zAxis.normalize();
    
    Vec3 xaxis(transform.m[0], transform.m[1], transform.m[2]);
    Vec3 yaxis(transform.m[4], transform.m[5], transform.m[6]);
    Vec3 zaxis(transform.m[8], transform.m[9], transform.m[10]);
    
    target._extents.x = original._extents.x * xaxis.length();
    target._extents.y = original._extents.y * yaxis.length();
    target._extents.z = original._extents.z * zaxis.length();
    
    target._extentX = target._xAxis * target._extents.x;
    target._extentY = target._yAxis * target._extents.y;
    target._extentZ = target._zAxis * target._extents.z;
}

std::vector<cocos2d::OBB*> CollisionArea::getObbs()
{
    std::vector<OBB*> ret;
    
    for(int i = 0; i <__vAreaBinding.size(); i++)
    {
        ret.push_back(&__vAreaBinding[i].second);
    }
    
    return ret;
}
