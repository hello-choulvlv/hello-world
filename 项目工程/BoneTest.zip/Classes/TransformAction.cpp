//
//  TransformAction.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/4.
//
//

#include "TransformAction.hpp"

TransformAction::~TransformAction()
{}

void TransformAction::update(float dt)
{
    printf("TransformAction: [update] override this!!\n");
}

TransformAction* TransformAction::clone()
{
    printf("TransformAction: [clone] override this!!\n");
    return nullptr;
}

void TransformAction::setDuration(float duration)
{
    _duration = duration;
}

void TransformAction::setTarget(ActionTarget* target)
{
    _target = target;
}

TransformSwing::TransformSwing():
_count(1)
{
}

TransformSwing::~TransformSwing()
{
    delete _action;
}

void TransformSwing::setCount(int count)
{
    _count = count;
}

void TransformSwing::update(float dt)
{
    float doubledDuration = _action->_duration * 2;
    dt = dt > _duration ? _duration : dt;
    
    dt = dt - doubledDuration * (int)(dt / doubledDuration);
    
    if(dt < _action->_duration)
    {
        _action->update(dt);
    }
    else
    {
        _action->update(doubledDuration - dt);
    }
}

void TransformSwing::setTarget(ActionTarget* target)
{
    TransformAction::setTarget(target);
    _action->setTarget(target);
}

TransformAction* TransformSwing::clone()
{
    TransformSwing* clone = new TransformSwing();
    clone->_duration = _duration;
    clone->_action = _action->clone();
    return clone;
}

void TransformSwing::addAction(TransformAction* action)
{
    _action = action;
    _duration = _action->_duration * 2 * _count;
    _action->setTarget(_target);
}

TransformSequence::~TransformSequence()
{
    for(int i = 0; i < _actions.size(); i++)
    {
        delete _actions[i];
    }
}

void TransformSequence::update(float dt)
{
    for(int i = 0; i < _actions.size(); i++)
    {
        _actions[i]->update(dt);
        
        dt = dt - _actions[i]->_duration;
        
        if(dt <= 0)
        {
            break;
        }
    }
}

void TransformSequence::setTarget(ActionTarget* target)
{
    TransformAction::setTarget(target);
    
    for(int i = 0; i < _actions.size(); i++)
    {
        _actions[i]->setTarget(target);
    }
}

TransformAction* TransformSequence::clone()
{
    TransformSequence* clone = new TransformSequence();
    clone->_duration = _duration;
    for(int i = 0; i < _actions.size(); i++)
    {
        clone->_actions.push_back(_actions[i]->clone());
    }
    return clone;
}

void TransformSequence::addAction(std::vector<TransformAction*>& actions)
{
    for(int i = 0; i < actions.size(); i++)
    {
        _actions.push_back(actions[i]);
        _duration = _duration + actions[i]->_duration;
        _actions[i]->setTarget(_target);
    }
}

TransformSpawn::~TransformSpawn()
{
    for(int i = 0; i < _actions.size(); i++)
    {
        delete _actions[i];
    }
}

void TransformSpawn::update(float dt)
{
    for(int i = 0; i < _actions.size(); i++)
    {
        _actions[i]->update(dt);
    }
}

void TransformSpawn::setTarget(ActionTarget* target)
{
    TransformAction::setTarget(target);
    
    for(int i = 0; i < _actions.size(); i++)
    {
        _actions[i]->setTarget(target);
    }
}

TransformAction* TransformSpawn::clone()
{
    TransformSpawn* clone = new TransformSpawn();
    clone->_duration = _duration;
    for(int i = 0; i < _actions.size(); i++)
    {
        clone->_actions.push_back(_actions[i]->clone());
    }
    return clone;
}

void TransformSpawn::addAction(std::vector<TransformAction*>& actions)
{
    for(int i = 0; i < actions.size(); i++)
    {
        _actions.push_back(actions[i]);
        _duration = _duration < actions[i]->_duration ? actions[i]->_duration : _duration;
        _actions[i]->setTarget(_target);
    }
}

void TransformPosition::update(float dt)
{
    float percent = dt / _duration;
    percent = percent > 1 ? 1 : percent;
    _target->targetPosition = _start * (1 - percent) + _end * percent;
}

TransformAction* TransformPosition::clone()
{
    TransformPosition* clone = new TransformPosition();
    clone->_start = _start;
    clone->_end = _end;
    clone->_duration = _duration;
    return clone;
}

void TransformPosition::setParam(cocos2d::Vec3 start, cocos2d::Vec3 end)
{
    _start = start;
    _end = end;
}

void TransformDirection::update(float dt)
{
    float percent = dt / _duration;
    percent = percent > 1 ? 1 : percent;
    _target->targetDirection = _start * (1 - percent) + _end * percent;
}

TransformAction* TransformDirection::clone()
{
    TransformDirection* clone = new TransformDirection();
    clone->_start = _start;
    clone->_end = _end;
    clone->_duration = _duration;
    return clone;
}

void TransformDirection::setParam(cocos2d::Vec3 start, cocos2d::Vec3 end)
{
    _start = start;
    _end = end;
}

void TransformScale::update(float dt)
{
    float percent = dt / _duration;
    percent = percent > 1 ? 1 : percent;
    _target->targetScale = _start * (1 - percent) + _end * percent;
}

TransformAction* TransformScale::clone()
{
    TransformScale* clone = new TransformScale();
    clone->_start = _start;
    clone->_end = _end;
    clone->_duration = _duration;
    return clone;
}

void TransformScale::setParam(float start, float end)
{
    _start = start;
    _end = end;
}

void TransformRoll::update(float dt)
{
    float percent = dt / _duration;
    percent = percent > 1 ? 1 : percent;
    _target->targetRoll = _start * (1 - percent) + _end * percent;
}

TransformAction* TransformRoll::clone()
{
    TransformRoll* clone = new TransformRoll();
    clone->_start = _start;
    clone->_end = _end;
    clone->_duration = _duration;
    return clone;
}

void TransformRoll::setParam(float start, float end)
{
    _start = start;
    _end = end;
}

