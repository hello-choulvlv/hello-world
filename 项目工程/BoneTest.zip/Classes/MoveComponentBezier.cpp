//
//  MoveComponentBezier.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "MoveComponentBezier.hpp"
#include "BezierRoute.hpp"

MoveComponentBezier::MoveComponentBezier() :
_offset(cocos2d::Vec3(0, 0, 0)),
_route(nullptr)
{
    
}

MoveComponentBezier::~MoveComponentBezier()
{

}

void MoveComponentBezier::retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection)
{
    float speedCoef;
    float overflow;
    
    _route->retrieveState(currentPosition, currentDirection, speedCoef, overflow, _distance);
    currentPosition.x = currentPosition.x + _offset.x;
    currentPosition.y = currentPosition.y + _offset.y;
    currentPosition.z = currentPosition.z + _offset.z;
    
    if(overflow > 0)
    {
        _end = true;
    }
    else
    {
        _end = false;
    }
}

void MoveComponentBezier::setBezierRoute(CubicBezierRoute* route)
{
    _route = route;
}

void MoveComponentBezier::setOffset(cocos2d::Vec3 offset)
{
    _offset = offset;
}
