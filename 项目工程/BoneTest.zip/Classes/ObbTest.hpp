//
//  ObbTest.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/20.
//
//

#ifndef ObbTest_hpp
#define ObbTest_hpp

#include "cocos2d.h"

class ModelInspector;
class DrawNode3D;

class ObbTest : public cocos2d::Node
{
public:
    static ObbTest* create();
    virtual bool init();
    void scheduler(float);
    void updateObb();
    bool obbContainsPoint(cocos2d::Vec3& point, std::vector<cocos2d::Vec3>& obb, int farIndex);
    void rotate(std::vector<int>& position, int farIndex);
    
    cocos2d::OBB original;
    cocos2d::OBB transformed;
    cocos2d::OBB inflated;
    ModelInspector* inspector;
    cocos2d::DrawNode* far;
    cocos2d::DrawNode* testPoint;
    DrawNode3D* obbDrawNode;
    DrawNode3D* containDrawNode;
    std::vector<cocos2d::Label*> vPosLabel;
    
    inline int getIndex(int farIndex, int position);
    static int pointArrange[8][8];
    static int outline[7];
    static int outlineIndexing[8][7];
};

#endif /* ObbTest_hpp */
