//
//  TroopConfig.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#ifndef TroopConfig_hpp
#define TroopConfig_hpp

#include "cocos2d.h"
#include "TransformActionCreator.hpp"

class TypeSelector
{
public:
    TypeSelector();
    void setParam(std::vector<int>& types, std::vector<int>& weights);
    int getType();
    
private:
    std::vector<int> _types;
    std::vector<int> _weights;
    int _total;
    int _typeNumber;
};

struct RandomTyped
{
    RandomTyped();
    void genType(int parentType);
    
    int typeSelectorId;
    bool fixType;
    int type;
};

struct SpawnElement : public RandomTyped
{
    enum CATEGORY {FISH, GROUP};
    
    CATEGORY category;
    int typeSelectorId;
    bool fixType;
    int type;
    int motionType;
    int pathId;
    
    cocos2d::Vec3 spawnPosition;
    cocos2d::Vec3 spawnDirection;
};

struct SpawnCluster : public RandomTyped
{
    int typeSelectorId;
    bool fixType;
    int type;
    std::vector<SpawnElement> elements;
};

struct GeneratorConfig : public RandomTyped
{
    float delay;
    float spawnInterval;
    float spawnCount;
    int typeSelectorId;
    bool fixType;
    int type;
    std::vector<SpawnCluster> clusters;
};

struct GroupConfig
{
    TransformAction* transform;
    std::vector<GeneratorConfig> generator;
};

struct TroopSetConfig
{
    std::map<int, GroupConfig> _groupConfigs;
};

class TroopConfig
{
public:
    static TroopConfig* getInstance();
private:
    static TroopConfig* _instance;
    
public:
    void loadConfig(std::string configFilePath);
    TypeSelector& getTypeSelectorById(int typeSelectorId);
    TroopSetConfig& getTroopSetConfigById(int troopSetId);
    
private:
    std::map<int, TypeSelector> _typeSelectors;
    std::map<int, TroopSetConfig> _troopSetConfigs;
};

#endif /* TroopConfig_hpp */
