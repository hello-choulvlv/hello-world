//
//  ActionController.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/24.
//
//

#ifndef ActionController_hpp
#define ActionController_hpp

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "IUpdate.h"

class UpdateController : public cocos2d::Node
{
public:
    static UpdateController* create();
    
public:
    UpdateController();
    virtual ~UpdateController();
    virtual bool init();
    
public:
    void setTarget(IUpdate* target);
    void setFrameRate(int frameRate);
    void setFrameStepCallback(std::function<void ()> callback);
    void setDuration(float duration);
    void reset();
    virtual void onEnter();
    virtual void onExit();
    
private:
    void playScheduler(float dt);
    void onTouchDown();
    void onTouchUp();
    void onValueChanged();
    void onForward();
    void onBackward();
    void onPause();
    void onStart();
    void bind();
    void stepForward(float step);
    void stepBackward(float step);
    void onForwardStep();
    void onBackwardStep();
    
private:
    enum DIRECTION {FORWARD, BACKWARD};
    
private:
    float __frameRate;
    IUpdate* __target;
    cocos2d::ui::Slider* __slider;
    float __currentTimePassed;
    bool __paused;
    float __timer;
    std::function<void ()> __frameStepCallback;
    DIRECTION __direction;
    float __duration;
    float __updateStep;
};

#endif /* ActionController_hpp */
