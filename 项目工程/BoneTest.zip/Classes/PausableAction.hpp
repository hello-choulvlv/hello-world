//
//  PausableAction.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/24.
//
//

#ifndef PausableAction_hpp
#define PausableAction_hpp

#include "cocos2d.h"

class PauseabelAction : public cocos2d::ActionInterval
{
public:
    virtual ~PauseabelAction() {delete __action;};
    
    static PauseabelAction* create(cocos2d::ActionInterval* action);
    void pause();
    void start();
    virtual void startWithTarget(cocos2d::Node* target) override;
    virtual void step(float dt) override;
    virtual bool isDone(void) const override;
    
private:
    bool __pause;
    cocos2d::ActionInterval* __action;
};

#endif /* PausableAction_hpp */
