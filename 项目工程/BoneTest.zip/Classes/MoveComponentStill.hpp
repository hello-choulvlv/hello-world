//
//  MoveComponentStill.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef MoveComponentStill_hpp
#define MoveComponentStill_hpp

#include "MoveComponent.hpp"

class MoveComponentStill : public MoveComponent
{
public:
    MoveComponentStill();
    virtual ~MoveComponentStill();
    virtual void retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection);
    
public:
    void setStartPosition(cocos2d::Vec3 position);
    void setStartDirection(cocos2d::Vec3 direction);
    
private:
    cocos2d::Vec3 _start;
    cocos2d::Vec3 _direction;
};

#endif /* MoveComponentStill_hpp */
