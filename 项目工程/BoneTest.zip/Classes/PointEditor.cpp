//
//  PointEditor.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/11.
//
//

#include "PointEditor.hpp"
#include "AxisEditor.hpp"

PointEditor* PointEditor::create()
{
    PointEditor* ret = new PointEditor();
    ret->init();
    ret->autorelease();
    return ret;
}

PointEditor::PointEditor()
{
    _axisEditorX = AxisEditorX::create();
    _axisEditorX->setValueChangedCallback([this](){
        setValueX(_axisEditorX->getValue());
    });
    _axisEditorX->setMinMax(0, 1334);
    this->addChild(_axisEditorX);
    
    _axisEditorY = AxisEditorY::create();
    _axisEditorY->setValueChangedCallback([this](){
        setValueY(_axisEditorY->getValue());
    });
    _axisEditorY->setMinMax(0, 750);
    this->addChild(_axisEditorY);
    
    _axisEditorZ = AxisEditorZ::create();
    _axisEditorZ->setValueChangedCallback([this](){
        setValueZ(_axisEditorZ->getValue());
    });
    _axisEditorZ->setMinMax(-100, 100);
    this->addChild(_axisEditorZ);
}

PointEditor::~PointEditor()
{
    
}

void PointEditor::setValue(cocos2d::Vec3 value)
{
    _value = value;
    this->setPosition3D(_value);
    _axisEditorX->setValue(_value.x);
    _axisEditorY->setValue(_value.y);
    _axisEditorZ->setValue(_value.z);
}

void PointEditor::setValueX(float x)
{
    _value.x = x;
    this->setPosition3D(_value);
}

void PointEditor::setValueY(float y)
{
    _value.y = y;
    this->setPosition3D(_value);
}

void PointEditor::setValueZ(float z)
{
    _value.z = z;
    this->setPosition3D(_value);
}


void PointEditor::onEnter()
{
    Node::onEnter();
}

void PointEditor::onExit()
{
    Node::onExit();
}
