//
//  PathConfig.cpp
//  BoneTest
//
//  Created by charlie on 2017/8/12.
//
//

#include "PathConfig.hpp"
#include "pugixml.hpp"
#include "BezierRoute.hpp"
#include "SpiralRoute.h"


PathConfig* PathConfig::__instance = nullptr;


PathConfig* PathConfig::getInstance()
{
    if(__instance == nullptr)
    {
        __instance = new PathConfig();
        __instance->loadConfigFile();
    }
    
    return __instance;
}


void PathConfig::loadConfigFile()
{
    pugi::xml_document doc;
    
    if(doc.load_file("path.xml"))
    {
        pugi::xml_node sets = doc.child("FishPath");
        
        auto pathConfigDatas = sets.children("Path");
        
        for(auto pathIter = pathConfigDatas.begin(); pathIter != pathConfigDatas.end(); pathIter++)
        {
            pugi::xml_node pathData = (*pathIter);

            int pathId = pathData.attribute("id").as_int();
            float weight = pathData.attribute("weight").as_float();
            int type = pathData.attribute("Type").as_int();
            
            auto pointConfigDatas = pathData.children("Position");
            
            if(type == 1)
            {
                std::vector<CubicBezierRoute::PointInfo> vPointInfo;
                
                for(auto pointIter = pointConfigDatas.begin(); pointIter != pointConfigDatas.end(); pointIter++)
                {
                    pugi::xml_node point = (*pointIter);
                    
                    CubicBezierRoute::PointInfo temp;
                    
                    temp.position.x = point.attribute("x").as_float();
                    temp.position.y = point.attribute("y").as_float();
                    temp.position.z = point.attribute("z").as_float();
                    calculatePosition(temp.position);
                    
                    temp.speedCoef = point.attribute("speefCoef").as_float();
                    
                    vPointInfo.push_back(temp);
                }
                
                CubicBezierRoute* route = new CubicBezierRoute();
                route->setWeight(weight);
                route->addPoints(vPointInfo);
                
                __routeData[pathId] = route;
                __routeType[pathId] = type;
            }
            else if(type == 4)
            {
                std::vector<cocos2d::Vec3> vPointInfo;
                
                for(auto pointIter = pointConfigDatas.begin(); pointIter != pointConfigDatas.end(); pointIter++)
                {
                    pugi::xml_node point = (*pointIter);
                    
                    cocos2d::Vec3 temp;
                    
                    temp.x = point.attribute("x").as_float();
                    temp.y = point.attribute("y").as_float();
                    temp.z = point.attribute("z").as_float();
                    
                    vPointInfo.push_back(temp);
                }
                
                SpiralRoute* route = SpiralRoute::create(vPointInfo);
                
                __routeData[pathId] = route;
                __routeType[pathId] = type;
            }
        
        }
    }
    else
    {
        printf("Load Path.xml Failed !!!!!!!!!");
    }
}

void PathConfig::calculatePosition(cocos2d::Vec3& p)
{
    p.x = p.x * 1334;
    p.y = p.y * 750;
    
    if(p.z != 0)
    {
        float zeye = 750 / 1.1566;
        float far = zeye + 750 / 2 + 400;
        float near = 0.1;
        float depth = far - near;
        
        p.z = zeye - near - p.z * depth;
    }
}

void* PathConfig::getRouteData(int pathId)
{
    return __routeData[pathId];
}

int PathConfig::getRouteType(int pathId)
{
    return __routeType[pathId];
}
