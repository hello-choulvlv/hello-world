//
//  DrawNode3D.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/9.
//
//

#ifndef DrawNode3D_hpp
#define DrawNode3D_hpp

#include "cocos2d.h"

class DrawNode3D : public cocos2d::Node
{
public:
    DrawNode3D();
    virtual ~DrawNode3D();
    static DrawNode3D* create();
    virtual bool init() override;
    virtual void draw(cocos2d::Renderer *renderer, const cocos2d::Mat4& transform, uint32_t flags) override;
    void drawExecutor(const cocos2d::Mat4& transform, uint32_t flags);
    
public:
    void drawLine(cocos2d::Vec3 from, cocos2d::Vec3 to, cocos2d::Color4F color);
    void drawLine(cocos2d::Vec3 from, cocos2d::Vec3 to);
    void drawCubicBezier(std::vector<cocos2d::Vec3>& controlPoints, float weight, float precision, cocos2d::Color4F color);
    void drawCubicBezier(std::vector<cocos2d::Vec3>& controlPoints, float weight, float precision);
    void drawHighOrderBezier(std::vector<cocos2d::Vec3>& controlPoints, float precision, cocos2d::Color4F color);
    void drawObb(cocos2d::OBB& obb, cocos2d::Color4F color);
    void drawObb(cocos2d::OBB& obb);
    void clear();
    void setDefaultColor(cocos2d::Color4F color);
    cocos2d::Color4F getDefaultColor(cocos2d::Color4F color);
    void applyDefaultColor();
    
private:
    void ensureCapacity(int count);
    
private:
    
    struct V3F_C4B
    {
        cocos2d::Vec3     vertices;
        cocos2d::Color4B  colors;
    };
    
    GLuint _vao;
    GLuint _vbo;
    
    int _bufferCapacity;
    GLsizei _bufferCount;
    V3F_C4B* _buffer;
    
    bool _dirty;
    
    cocos2d::CustomCommand _customCommand;
    
    cocos2d::Director::Projection _projectionMode;
    
    cocos2d::Color4F __defaultColor;
};

#endif /* DrawNode3D_hpp */
