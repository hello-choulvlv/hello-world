//
//  NetworkDeclarations.h
//  BoneTest
//
//  Created by charlie on 2017/4/14.
//
//

#ifndef NetworkDeclarations_h
#define NetworkDeclarations_h

namespace Network {
    
    typedef unsigned int Address[5];
    
    enum NETWORK_ERROR {PLAIN_ERROR = -1};
    
    enum ADDR_POS {A0, A1, A2, A3, PORT};
    
    struct Packet
    {
        unsigned char* _data;
        unsigned int size;
    };
}

#endif /* NetworkDeclarations_h */
