//
//  PointRotate.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/1.
//
//

#ifndef PointRotate_hpp
#define PointRotate_hpp

#include "cocos2d.h"

class PointRotate
{
public:
    struct RotateAxis
    {
        cocos2d::Vec3 direction;
        cocos2d::Vec3 through;
    };

private:
    struct RotateParameter
    {
        cocos2d::Vec3 axisA;
        cocos2d::Vec3 axisB;
        cocos2d::Vec3 center;
        float radius;
    };
    
public:
    static PointRotate* getInstance();
private:
    static PointRotate* __instance;
    
public:
    void rotate(std::vector<std::vector<cocos2d::Vec3>>& result,
                    std::vector<cocos2d::Vec3>& points,
                    RotateAxis& axis,
                    float angluarStep = 30,
                    int times = 0);
};

#endif /* PointRotate_hpp */
