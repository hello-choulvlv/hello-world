//
//  DebugPrint.cpp
//  BoneTest
//
//  Created by charlie on 2017/4/13.
//
//

#include "DebugPrint.hpp"
#include <stdio.h>

using namespace Debug;


DebugPrint* DebugPrint::__instance = nullptr;

DebugPrint* DebugPrint::getInstance()
{
    return __instance;
}

void DebugPrint::createInstance()
{
    if(__instance == nullptr)
    {
        __instance = new DebugPrint();
    }
}

DebugPrint::DebugPrint()
: __filterMode(FILTER_MODE::OPEN)
, __categoryDescrptions({{DEFAULT_CATEGORY::ERROR, "ERR"}, {DEFAULT_CATEGORY::LOG, "LOG"}})
, __prefixShowMode(PREFIX_SHOW_MODE::SHOW_ALL)
, __categoryFilters(0xFFFFFFFF)
{
    pthread_mutex_init(&__lock, nullptr);
}

DebugPrint::~DebugPrint()
{
    pthread_mutex_destroy(&__lock);
}

void DebugPrint::print(unsigned int category, std::string tag, const char* format, ...)
{
    if(passFilter(category, tag))
    {
        pthread_mutex_lock(&__lock);
        
        printPrefix(category, tag);
        
        std::string suffixed = format;
        suffixed.append("\n");
        
        va_list argptr;
        va_start(argptr, format);
        vfprintf(stderr, suffixed.c_str(), argptr);
        va_end(argptr);
        
        pthread_mutex_unlock(&__lock);
    }
}

void DebugPrint::print(unsigned int category, std::string tag, std::string content)
{
    if(passFilter(category, tag))
    {
        pthread_mutex_lock(&__lock);
        
        printPrefix(category, tag);
        
        fprintf(stderr, "%s\n", content.c_str());
        
        pthread_mutex_unlock(&__lock);
    }
}

void DebugPrint::printPrefix(unsigned int category, std::string tag)
{
    std::string prefixStr;
    
    if(__prefixShowMode & PREFIX_SHOW_MODE::SHOW_CATEGORY)
    {
        for(auto iter = __categoryDescrptions.begin(); iter != __categoryDescrptions.end(); iter++)
        {
            if(iter->first & category)
            {
                prefixStr.append(iter->second);
                prefixStr.append("|");
            }
        }
    }
    
    if(__prefixShowMode & PREFIX_SHOW_MODE::SHOW_TAG)
    {
        prefixStr.append(tag);
        prefixStr.append("|");
    }
    
    prefixStr.append("  ");
    
    fprintf(stderr, "%s", prefixStr.c_str());
}

void DebugPrint::addTagFilter(std::string tagFilters)
{
    tagFilters.append(",");
    
    int begin = 0;
    int end = tagFilters.find(",", 0);
    
    while (end != std::string::npos) {
        
        __tagFilters.push_back(tagFilters.substr(begin, end));
        
        begin = end;
        end = tagFilters.find(",", end + 1);
    }
}

void DebugPrint::setCategoryFilter(unsigned int categoryFilters)
{
    __categoryFilters = categoryFilters;
}

void DebugPrint::setFilterMode(FILTER_MODE mode)
{
    __filterMode = mode;
}

void DebugPrint::setPrefixShowMode(unsigned int prefixShowMode)
{
    __prefixShowMode = prefixShowMode;
}

void DebugPrint::registerCategory(unsigned int category, std::string description)
{
    __categoryDescrptions[category] = description;
}

bool DebugPrint::passFilter(unsigned int category, std::string &tag)
{
    return passCategoryFilter(category) && passTagFilter(tag);
}

bool DebugPrint::passTagFilter(std::string& tag)
{
    if(__filterMode == FILTER_MODE::OPEN)
    {
        return true;
    }
    else if(__filterMode == FILTER_MODE::CLOSE)
    {
        return false;
    }
    else if(__filterMode == FILTER_MODE::ENABLE)
    {
        for(int i = 0; i < __tagFilters.size(); i++)
        {
            if(__tagFilters[i] == tag)
            {
                return true;
            }
        }
        
        return false;
    }
    else if(__filterMode == FILTER_MODE::DISABLE)
    {
        for(int i = 0; i < __tagFilters.size(); i++)
        {
            if(__tagFilters[i] == tag)
            {
                return false;
            }
        }
        
        return true;
    }
    else
    {
        return false;
    }
}

bool DebugPrint::passCategoryFilter(unsigned int category)
{
    if(__filterMode == FILTER_MODE::OPEN)
    {
        return true;
    }
    else if(__filterMode == FILTER_MODE::CLOSE)
    {
        return false;
    }
    else if(__filterMode == FILTER_MODE::ENABLE)
    {
        return category & __categoryFilters;
    }
    else if(__filterMode == FILTER_MODE::DISABLE)
    {
        return !(category & __categoryFilters);
    }
    else
    {
        return false;
    }
}
