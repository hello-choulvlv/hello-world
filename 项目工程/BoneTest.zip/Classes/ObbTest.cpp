//
//  ObbTest.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/20.
//
//

#include "ObbTest.hpp"
#include "DrawNode3D.hpp"
#include "ModelInspector.hpp"
#include "GlobalValue.hpp"

using namespace cocos2d;

ObbTest* ObbTest::create()
{
    ObbTest* pRet = new ObbTest();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

bool ObbTest::init()
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
//    Director::getInstance()->setProjection(cocos2d::Director::Projection::_2D);
    
    Sprite3D* shark = Sprite3D::create("shayu.c3t");
    this->addChild(shark);
    
    OBB obb = OBB(shark->getAABB());
    
    shark->setScale(0.1);
    shark->setPosition(visibleSize / 2);
    shark->setVisible(false);
    
    obb.transform(shark->getNodeToWorldTransform());
    
    this->original = obb;
    
    obbDrawNode = DrawNode3D::create();
    obbDrawNode->drawObb(obb, Color4F(1.0, 0.0, 0.0, 0.3));
//    obbDrawNode->setProjectionMode(cocos2d::Director::Projection::_2D);
//    obbDrawNode->setPosition3D(Vec3(300, 300, 0));
//    this->addChild(original);
    
//    OBB inflate;
//    inflate.set(obb._center, obb._xAxis, obb._yAxis, obb._zAxis, obb._extents + Vec3(30, 30, 30));
//    
//    DrawNode3D* drawInflated = DrawNode3D::create();
//    drawInflated->drawObb(inflate, Color4F(0.0, 0.0, 1.0, 1.0));
//    drawInflated->setProjectionMode(cocos2d::Director::Projection::_2D);
//    this->addChild(drawInflated);
    
    DrawNode3D* axes = DrawNode3D::create();
    axes->drawLine(obb._center, obb._center + obb._extentX, Color4F(1.0, 0.0, 0.0, 1.0));
    axes->drawLine(obb._center, obb._center + obb._extentY, Color4F(0.0, 1.0, 0.0, 1.0));
    axes->drawLine(obb._center, obb._center + obb._extentZ, Color4F(0.0, 0.0, 1.0, 1.0));
    
    containDrawNode = DrawNode3D::create();
//    containDrawNode->setProjectionMode(cocos2d::Director::Projection::_2D);
    this->addChild(containDrawNode);
    
    inspector = ModelInspector::create();
    inspector->append(obbDrawNode);
    inspector->append(axes);
    inspector->showPlane(true);
    this->addChild(inspector);
    
    far = DrawNode::create();
    far->drawSolidCircle(Vec2(0, 0), 5, 360, 64, 1.0, 1.0, Color4F(0.0, 0.0, 1.0, 1.0));
    this->addChild(far);
    
    testPoint = DrawNode::create();
    testPoint->drawSolidCircle(Vec2(0, 0), 5, 360, 64, 1.0, 1.0, Color4F(1.0, 1.0, 0.0, 1.0));
    this->addChild(testPoint);
    
    this->schedule(schedule_selector(ObbTest::scheduler), 0.0, CC_REPEAT_FOREVER, 0);
    
    for(int i = 0; i < 8; i ++)
    {
        Label* label = Label::createWithSystemFont("nono", "", 12);
        label->setColor(Color3B(200, 200, 0));
        vPosLabel.push_back(label);
        this->addChild(label);
    }
    
    return true;
}

void ObbTest::scheduler(float)
{
    updateObb();
    
    OBB& obb = transformed;
    
    std::vector<Vec3> points;
    points.resize(8);
    
    points[0] = obb._center + obb._extentX + obb._extentY + obb._extentZ;
    points[1] = obb._center + obb._extentX + obb._extentY - obb._extentZ;
    points[2] = obb._center - obb._extentX + obb._extentY - obb._extentZ;
    points[3] = obb._center - obb._extentX + obb._extentY + obb._extentZ;
    points[4] = obb._center + obb._extentX - obb._extentY + obb._extentZ;
    points[5] = obb._center + obb._extentX - obb._extentY - obb._extentZ;
    points[6] = obb._center - obb._extentX - obb._extentY - obb._extentZ;
    points[7] = obb._center - obb._extentX - obb._extentY + obb._extentZ;
    
    float minZ = 1000000;
    int index = 0;
    
    for(int i = 0; i < 8; i++)
    {
        if(points[i].z < minZ)
        {
            minZ = points[i].z;
            index = i;
        }
    }
    
    far->setPosition3D(points[index]);
    
    Vec3 p = Vec3(508, 330, 0);
    testPoint->setPosition3D(p);
    
    if(obbContainsPoint(p, points, index))
    {
        testPoint->clear();
        testPoint->drawSolidCircle(Vec2(0, 0), 5, 360, 64, 1.0, 1.0, Color4F(0.0, 1.0, 0.0, 1.0));
    }
    else
    {
        testPoint->clear();
        testPoint->drawSolidCircle(Vec2(0, 0), 5, 360, 64, 1.0, 1.0, Color4F(1.0, 0.0, 0.0, 1.0));
    }
    
    for(int i = 0; i < 8; i++)
    {
        char str[256];
        sprintf(str, "(%d)", i);
        vPosLabel[i]->setString(str);
        vPosLabel[i]->setPosition3D(points[i]);

    }
    
    Ray ray = Ray(Vec3(0, 0, 0), Vec3(100, 100, 100));
    
    clock_t start = clock();
    
    Vec3* p1;
    Vec3* p2;
    Vec3* p3;
    Vec3* p4;
    Vec3* p5;
    Vec3* p6;
    float result[6];
    int* outline;
    int counter = 0;
    
    outline = outlineIndexing[index];
    
    p1 = &points[outline[0]];
    p2 = &points[outline[1]];
    p3 = &points[outline[2]];
    p4 = &points[outline[3]];
    p5 = &points[outline[4]];
    p6 = &points[outline[5]];
    
//    for(int i = 0; i < 1000000; i++)
//    {
//        result[0] = (p1->x - p.x) * (p2->y - p.y) - (p1->y - p.y) * (p2->x - p.x);
//        result[1] = (p2->x - p.x) * (p3->y - p.y) - (p2->y - p.y) * (p3->x - p.x);
//        result[2] = (p3->x - p.x) * (p4->y - p.y) - (p3->y - p.y) * (p4->x - p.x);
//        result[3] = (p4->x - p.x) * (p5->y - p.y) - (p4->y - p.y) * (p5->x - p.x);
//        result[4] = (p5->x - p.x) * (p6->y - p.y) - (p5->y - p.y) * (p6->x - p.x);
//        result[5] = (p6->x - p.x) * (p1->y - p.y) - (p6->y - p.y) * (p1->x - p.x);
//        
//        counter = counter + (*((int*)result + 0) >> 31);
//        counter = counter + (*((int*)result + 1) >> 31);
//        counter = counter + (*((int*)result + 2) >> 31);
//        counter = counter + (*((int*)result + 3) >> 31);
//        counter = counter + (*((int*)result + 4) >> 31);
//        counter = counter + (*((int*)result + 5) >> 31);
//        counter = abs(counter);
//        
//        if(counter == 6 or counter == 0)
//        {
//            continue;
//        }
//        
//    }
    
    clock_t end = clock();
//
    printf("%.4f\n", (float)(end - start) / CLOCKS_PER_SEC);
}

void ObbTest::updateObb()
{
    Mat4 transform = obbDrawNode->getNodeToWorldTransform();
    
    Vec4 newcenter = transform * Vec4(original._center.x, original._center.y, original._center.z, 1.0f);// center;
    transformed._center.x = newcenter.x;
    transformed._center.y = newcenter.y;
    transformed._center.z = newcenter.z;
    
    transformed._xAxis = transform * original._xAxis;
    transformed._yAxis = transform * original._yAxis;
    transformed._zAxis = transform * original._zAxis;
    
    transformed._xAxis.normalize();
    transformed._yAxis.normalize();
    transformed._zAxis.normalize();
    
    Vec3 xaxis(transform.m[0], transform.m[1], transform.m[2]);
    Vec3 yaxis(transform.m[4], transform.m[5], transform.m[6]);
    Vec3 zaxis(transform.m[8], transform.m[9], transform.m[10]);
    
    transformed._extents.x = original._extents.x * xaxis.length();
    transformed._extents.y = original._extents.y * yaxis.length();
    transformed._extents.z = original._extents.z * zaxis.length();
    
    transformed._extentX = transformed._xAxis * transformed._extents.x;
    transformed._extentY = transformed._yAxis * transformed._extents.y;
    transformed._extentZ = transformed._zAxis * transformed._extents.z;
}

bool ObbTest::obbContainsPoint(cocos2d::Vec3& point, std::vector<cocos2d::Vec3>& obb, int farIndex)
{
    char c1 = 0;
    char c2 = 0;
    
    for(int i = 0; i < 6; i++)
    {
        Vec3& p1 = obb[outlineIndexing[farIndex][i]];
        Vec3& p2 = obb[outlineIndexing[farIndex][i + 1]];
        
        float result = (p1.x - point.x) * (p2.y - point.y) - (p1.y - point.y) * (p2.x - point.x);
        
        if(fabsf(result) < GLOBAL_VALUE::EPSILON)
        {
            continue;
        }
        else
        {
            c1++;
            c2 = c2 + ((((unsigned char*) &result)[sizeof(float) - 1] >> 7) << 1) - 1;
            
            if(c1 != abs(c2))
            {
                return false;
            }
        }
    }
    
    return true;
    
//    int c1 = 0;
//    int c2 = 0;
//    int ret = 1;
//    int index[3] = { 0, 0, 6 };
//    
//    for(int i = 0; i < 6; index[0]++)
//    {
//        Vec3& p1 = obb[getIndex(farIndex, i)];
//        Vec3& p2 = obb[getIndex(farIndex, i + 1)];
//        
//        float result = (p1.x - point.x) * (p2.y - point.y) - (p1.y - point.y) * (p2.x - point.x);
//        c2 = c2 + ((((unsigned char*) &result)[sizeof(float) - 1] >> 7) << 1) - 1;
//        ret = ++c1 - abs(c2);
//        i = index[ret];
//    }
//    
//    return !ret;
}

int ObbTest::getIndex(int farIndex, int position)
{
    return pointArrange[farIndex][outline[position]];
}

int ObbTest::pointArrange[8][8] = {
    
    {0, 1, 2, 3, 4, 5, 6, 7},
    {1, 2, 3, 0, 5, 6, 7, 4},
    {2, 3, 0, 1, 6, 7, 4, 5},
    {3, 0, 1, 2, 7, 4, 5, 6},
    {4, 5, 6, 7, 0, 1, 2, 3},
    {5, 6, 7, 4, 1, 2, 3, 0},
    {6, 7, 4, 5, 2, 3, 0, 1},
    {7, 4, 5, 6, 3, 0, 1, 2},
    
};

int ObbTest::outline[7] = {1, 2, 3, 7, 4, 5, 1};

int ObbTest::outlineIndexing[8][7] = {
    
    {1, 2, 3, 7, 4, 5, 1},
    {2, 3, 0, 4, 5, 6, 2},
    {3, 0, 1, 5, 6, 7, 3},
    {0, 1, 2, 6, 7, 4, 0},
    {5, 6, 7, 3, 0, 1, 5},
    {6, 7, 4, 0, 1, 2, 6},
    {7, 4, 5, 1, 2, 3, 7},
    {4, 5, 6, 2, 3, 0, 4},
    
};
