//
//  CheckNormal.hpp
//  BoneTest
//
//  Created by charlie on 2017/4/20.
//
//

#ifndef CheckNormal_hpp
#define CheckNormal_hpp

#include <stdio.h>

class CheckNormal
{
public:
    void check();
};

#endif /* CheckNormal_hpp */
