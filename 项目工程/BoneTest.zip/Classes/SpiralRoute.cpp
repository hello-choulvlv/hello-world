/*
  *��������ʵ��
  *2017-07-15
  *@Author:xiaoxiong
 */
#include "SpiralRoute.h"

SpiralRoute::SpiralRoute() :
	_length ( 0.0f)
	, _windCount(0.0f)
	, _radius0(0.0f)
	, _radius1(0.0f)
	, _spiralHeight(0.0f)
	, _height(0.0f)
    , _clockwise(1.0f)
{

}

void SpiralRoute::init(const std::vector<cocos2d::Vec3> &controlPoints)
{
	//��ת��
	_rotateAxis = controlPoints[0];
	_centerLocation = controlPoints[1];
	auto &point = controlPoints[2];
	_radius0 = point.x;
	_radius1 = point.y;
	_spiralHeight = point.z;
	_windCount = controlPoints[3].x;
	//�任����
	const cocos2d::Vec3 upVec(0.0f, 1.0f, 0.0f);
	cocos2d::Vec3 axis;
	cocos2d::Mat4 translateM, rotateM;
	cocos2d::Vec3::cross(upVec, _rotateAxis, &axis);
	//////////////////////////////////////////
	cocos2d::Mat4::createTranslation(_centerLocation, &translateM);
	const float dotValue = cocos2d::Vec3::dot(_rotateAxis, upVec);
	float   angle = acosf(dotValue);
	cocos2d::Mat4::createRotation(axis, angle, &rotateM);
	_trMatrix = translateM * rotateM;
	//�������ߵĳ���
	_length = getSpiralLengthPrivate();
	_height = _spiralHeight * _windCount;
    _clockwise = controlPoints[3].y;
}

SpiralRoute *SpiralRoute::create(const std::vector<cocos2d::Vec3> &controlPoints)
{
	SpiralRoute *rout = new SpiralRoute();
	rout->init(controlPoints);
	return rout;
}

float SpiralRoute::getSpiralLengthPrivate()
{
	//�������ߵĳ���
	const int integrity = (int)_windCount;//����������
	const float frag = _windCount - integrity;//ʣ��Ĳ���һ��������
	float length = 0.0f;
	const float realRadius = _radius0 + (_radius1 - _radius0) / _windCount * integrity;
	for (int k = 1; k <= integrity; ++k)
	{
		float lastRadius = _radius0 + 1.0f *(k - 1) / integrity * (realRadius - _radius0);
		float nowRadius = _radius0 + 1.0f *k / integrity * (realRadius - _radius0);
		float tmp = (lastRadius + nowRadius)*M_PI;
		length += sqrtf(tmp * tmp + _spiralHeight * _spiralHeight);
	}
	//�ۼ���ʣ���β��
	float tmp = M_PI *(realRadius + realRadius + 1.0f / integrity *(realRadius - _radius0));
	length += frag * sqrtf(tmp * tmp + _spiralHeight * _spiralHeight);
	return length;
}

//��������,����
void SpiralRoute::retrieveState(float distance, cocos2d::Vec3 &position, cocos2d::Vec3 &tangent)
{
	const float rate = distance / _length;
	const float height = _spiralHeight *_windCount;
	const float halfHeight = height *0.5f;
	const float paix2 = 2.0f *M_PI * _clockwise;
	const float totalAngle = paix2 * _windCount;
	float  angle = rate * totalAngle;
	float  radius = _radius0 + (_radius1 - _radius0)*angle / totalAngle;
	float  y = _spiralHeight * angle / paix2 - halfHeight;
	float  sinValue = sinf(angle);
	float  cosValue = cosf(angle);
	float  x = radius * sinValue;
	float  z = radius * cosValue;
	//�任����ϵ
	cocos2d::Vec4 newPoint = _trMatrix * cocos2d::Vec4(x, y, z, 1.0f);
	position = cocos2d::Vec3(newPoint.x, newPoint.y, newPoint.z);
	//��������
	const float c = paix2 * _windCount;
	const float dx = radius * cosValue * c;
	const float dy = _spiralHeight / paix2 * c;
	const float dz = -radius * sinValue * c;
	tangent = _trMatrix * cocos2d::Vec3(dx, dy, dz);
}

void SpiralRoute::getPositionAndTangentByRate(float rate, cocos2d::Vec3 &position, cocos2d::Vec3 &tangent)
{
	const float height = _spiralHeight *_windCount;
	const float halfHeight = height *0.5f;
	const float paix2 = 2.0f *M_PI;
	const float totalAngle = paix2 * _windCount;
	float  angle = rate * totalAngle;
	float  radius = _radius0 + (_radius1 - _radius0)*angle / totalAngle;
	float  y = _spiralHeight * angle / paix2 - halfHeight;
	float  sinValue = sinf(angle);
	float  cosValue = cosf(angle);
	float  x = radius * sinValue;
	float  z = radius * cosValue;
	//�任����ϵ
	cocos2d::Vec4 newPoint = _trMatrix * cocos2d::Vec4(x, y, z, 1.0f);
	position = cocos2d::Vec3(newPoint.x, newPoint.y, newPoint.z);
	//��������
	const float c = paix2 * _windCount;
	const float dx = radius * cosValue * c;
	const float dy = _spiralHeight / paix2 * c;
	const float dz = -radius * sinValue * c;
	tangent = _trMatrix * cocos2d::Vec3(dx, dy, dz);
}

