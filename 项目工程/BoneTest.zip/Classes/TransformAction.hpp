//
//  TransformAction.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/4.
//
//

#ifndef TransformAction_hpp
#define TransformAction_hpp

#include "cocos2d.h"

class TransformAction
{
public:
    struct ActionTarget {
        
        ActionTarget():
            targetPosition(cocos2d::Vec3(0, 0, 0)),
            targetDirection(cocos2d::Vec3(0, 0, 0)),
            targetScale(1.0),
            targetRoll(0)
        {}
        
        cocos2d::Vec3 targetPosition;
        cocos2d::Vec3 targetDirection;
        float targetScale;
        float targetRoll;
    };
    
public:
    virtual ~TransformAction();
    virtual void update(float dt);
    virtual TransformAction* clone();
    virtual void setTarget(ActionTarget* target);
    void setDuration(float duration);
    float _duration;
    ActionTarget* _target;
};

class TransformSwing : public TransformAction
{
public:
    TransformSwing();
    virtual ~TransformSwing();
    virtual void update(float dt);
    virtual TransformAction* clone();
    virtual void setTarget(ActionTarget* target);
    void addAction(TransformAction* action);
    void setCount(int count);
    TransformAction* _action;
    int _count;
};

class TransformSequence : public TransformAction
{
public:
    virtual ~TransformSequence();
    virtual void update(float dt);
    virtual TransformAction* clone();
    virtual void setTarget(ActionTarget* target);
    void addAction(std::vector<TransformAction*>& actions);
    std::vector<TransformAction*> _actions;
};

class TransformSpawn : public TransformAction
{
public:
    virtual ~TransformSpawn();
    virtual void update(float dt);
    virtual TransformAction* clone();
    virtual void setTarget(ActionTarget* target);
    void addAction(std::vector<TransformAction*>& actions);
    std::vector<TransformAction*> _actions;
};

class TransformPosition : public TransformAction
{
public:
    virtual void update(float dt);
    virtual TransformAction* clone();
    void setParam(cocos2d::Vec3 start, cocos2d::Vec3 end);
    cocos2d::Vec3 _start;
    cocos2d::Vec3 _end;
};

class TransformDirection : public TransformAction
{
public:
    virtual void update(float dt);
    virtual TransformAction* clone();
    void setParam(cocos2d::Vec3 start, cocos2d::Vec3 end);
    cocos2d::Vec3 _start;
    cocos2d::Vec3 _end;
};

class TransformScale : public TransformAction
{
public:
    virtual void update(float dt);
    virtual TransformAction* clone();
    void setParam(float start, float end);
    float _start;
    float _end;
};

class TransformRoll : public TransformAction
{
public:
    virtual void update(float dt);
    virtual TransformAction* clone();
    void setParam(float start, float end);
    float _start;
    float _end;
};



#endif /* TransformAction_hpp */
