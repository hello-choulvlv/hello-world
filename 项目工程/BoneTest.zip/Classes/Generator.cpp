//
//  Generator.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#include "Generator.hpp"
#include "Group.hpp"
#include "TroopSetTestCase.hpp"

Generator::Generator():
_delayTimer(0),
_spawnTimer(0),
_spawnCount(0),
_generateId(0),
_group(nullptr)
{
    
}

void Generator::setConfig(GeneratorConfig& config)
{
    _config = config;
    _spawnTimer = -_config.spawnInterval;
    _spawnCircle = _config.spawnCircle;
}

void Generator::setGroup(Group* group)
{
    _group = group;
}

void Generator::update(float dt)
{
    _delayTimer = _delayTimer + dt;
    
    float nextTime = _delayTimer - _config.delay;
   
    if(nextTime > 0 && nextTime > _spawnTimer)
    {
        int startIndex = _spawnTimer / _config.spawnInterval + 1;
        int finishIndex = nextTime / _config.spawnInterval;
        finishIndex = finishIndex < (_config.spawnCount - 1) ? finishIndex : (_config.spawnCount - 1);
        
        for(int i = startIndex; i <= finishIndex; i++)
        {
            doSpawn(nextTime - _config.spawnInterval * i, i);
        }
    }
    
    _spawnTimer = nextTime;
}

void Generator::generateTypes()
{
    _config.genType(0);
    
    for(int clusterIndex = 0; clusterIndex < _config.clusters.size(); clusterIndex++)
    {
        SpawnCluster& cluster = _config.clusters[clusterIndex];
        cluster.genType(_config.type);
        
        for(int elementIndex = 0; elementIndex < cluster.elements.size(); elementIndex++)
        {
            SpawnElement& element = cluster.elements[elementIndex];
            element.genType(cluster.type);
        }
    }
}

void Generator::doSpawn(float timeOverflow, int spawnIndex)
{
    generateTypes();
    
    for(int clusterIndex = 0; clusterIndex < _config.clusters.size(); clusterIndex++)
    {
        SpawnCluster& cluster = _config.clusters[clusterIndex];
        
        for(int elementIndex = 0; elementIndex < cluster.elements.size(); elementIndex++)
        {
            SpawnElement& element = cluster.elements[elementIndex];
            
            if(element.category == SpawnElement::CATEGORY::FISH)
            {
                generateFish(element, timeOverflow, spawnIndex);
            }
            else if(element.category == SpawnElement::CATEGORY::GROUP)
            {
                generateGroup(element, timeOverflow, spawnIndex);
            }
        }
    }
}

void Generator::generateFish(SpawnElement& config, float timeOverflow, int spawnIndex)
{
    TroopSetTestCase::getInstance()->createFish(&config, _group, timeOverflow, spawnIndex, _spawnCircle);
}

void Generator::generateGroup(SpawnElement& config, float timeOverflow, int spawnIndex)
{
    TroopSetTestCase::getInstance()->createGroup(&config, _group, timeOverflow, spawnIndex, _spawnCircle);
}
