//
//  SocketWrapper.cpp
//  BoneTest
//
//  Created by charlie on 2017/4/14.
//
//

#include "SocketWrapper.hpp"

using namespace Network;

int SocketWrapper::INVALID_HANDLE = -1;

SocketWrapper::SocketWrapper()
: __handle(INVALID_HANDLE)
, __literalLocal{ 127, 0, 0, 1, 30000 }
, __literalRemote{ 127, 0, 0, 1, 30001 }
{
    
}

SocketWrapper::~SocketWrapper()
{
    
}

void SocketWrapper::sockAddrLocal(Address& literal, sockaddr_in& sock)
{
    memset((void*)&sock, 0, sizeof(sockaddr_in));
    sock.sin_family = AF_INET;
    sock.sin_addr.s_addr = htonl(INADDR_ANY);
    sock.sin_port = htons((unsigned short) literal[ADDR_POS::PORT]);
}

void SocketWrapper::sockAddrRemote(Address& literal, sockaddr_in& sock)
{
    unsigned int address = (literal[ADDR_POS::A0] << 24
                            | literal[ADDR_POS::A1] << 16
                            | literal[ADDR_POS::A2] << 8
                            | literal[ADDR_POS::A3] << 0);
    
    memset((void*)&sock, 0, sizeof(sockaddr_in));
    sock.sin_family = AF_INET;
    sock.sin_addr.s_addr = htonl(address);
    sock.sin_port = htons((unsigned short) literal[ADDR_POS::PORT]);
}

void SocketWrapper::literalAddrLocal(sockaddr_in& sock, Network::Address& literal)
{
    int address = ntohl(sock.sin_addr.s_addr);
    int port = ntohs(sock.sin_port);
    
    literal[ADDR_POS::A0] = address >> 24 & 0x000000ff;
    literal[ADDR_POS::A1] = address >> 16 & 0x000000ff;
    literal[ADDR_POS::A2] = address >> 8 & 0x000000ff;
    literal[ADDR_POS::A3] = address >> 0 & 0x000000ff;
    literal[ADDR_POS::PORT] = port;
}

void SocketWrapper::literalAddrRemote(sockaddr_in& sock, Network::Address& literal)
{
    literalAddrLocal(sock, literal);
}

bool SocketWrapper::validHandle(int handle)
{
    if(handle == SocketWrapper::INVALID_HANDLE)
    {
        return false;
    }
    else
    {
        return true;
    }
}

bool SocketWrapper::validAddress(sockaddr_in& addr)
{
    return true;
}

void SocketWrapper::copyLiteral(Address& src, Address& dst)
{
    dst[0] = src[0];
    dst[1] = src[1];
    dst[2] = src[2];
    dst[3] = src[3];
    dst[4] = src[4];
}

bool SocketWrapper::bind(Address& addr)
{
    return false;
}

bool SocketWrapper::connect(Address& addr)
{
    return false;
}

bool SocketWrapper::bind(Address* addr)
{
    if(addr == nullptr)
    {
        return bind(__literalLocal);
    }
    else
    {
        return bind(*addr);
    }
}

bool SocketWrapper::connect(Address* addr)
{
    if(addr == nullptr)
    {
        return connect(__literalRemote);
    }
    else
    {
        return connect(*addr);
    }
}

bool SocketWrapper::listen()
{
    return false;
}

int SocketWrapper::getHandle()
{
    return __handle;
}

int SocketWrapper::receive(void* data, size_t length)
{
    return 0;
}

int SocketWrapper::send(void* data, size_t length)
{
    return 0;
}

void SocketWrapper::close()
{
    return;
}

bool SocketWrapper::isConnected()
{
    return false;
}

bool SocketWrapper::accept()
{
    return false;
}
