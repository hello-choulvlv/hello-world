#include "TroopSetManager.h"
#include <cstring>
#include <math.h>

TypeSelector::TypeSelector()
{
    _total = 0;
}

void TypeSelector::setParam(int id, std::vector<int>& types, std::vector<int>& weights)
{
    assert(types.size() == weights.size());
    
    _types = types;
    _weights = weights;
    _typeNumber = _types.size();
    _id = id;
    
    for(int i = 0; i < _typeNumber; i++)
    {
        _total = _total + _weights[i];
        _weights[i] = _total;
    }
}

int TypeSelector::getType()
{
    if(_typeNumber == 1)
    {
        return _types[0];
    }
    else
    {
        int random = rand() % _total;
        
        for(int i = 0; i < _typeNumber; i++)
        {
            if(random < _weights[i])
            {
                return _types[i];
            }
        }
    }
    
    return _types[0];
}

RandomTyped::RandomTyped()
{
    typeSelectorId = 0;
    fixType = false;
    type = 0;
}

void RandomTyped::genType(int parentType)
{
    if(typeSelectorId == 0)
    {
        type = parentType;
    }
    else if((fixType && type == 0) || !fixType)
    {
        TypeSelector* selector = TroopSetManager::GetInstance()->GetSelector(typeSelectorId);
        type = selector->getType();
    }
}

TroopSetManager* TroopSetManager::_instance = nullptr;

TroopSetManager* TroopSetManager::GetInstance()
{
    if(_instance == nullptr)
    {
        _instance = new TroopSetManager();
    }
    
    return _instance;
}

TroopSetManager::TroopSetManager()
{
}

TroopSetManager::~TroopSetManager()
{
}

static inline void SplitString(const std::string& src, std::vector<std::string>& dsts, std::string delim)
{
	dsts.clear();
	char * p = NULL;
	char *str = const_cast<char*>(src.c_str());
	p = strtok(const_cast<char*>(str), delim.c_str());
	while (p != NULL)
	{
		dsts.push_back(p);
		p = strtok(NULL, delim.c_str());
	}
}

static cocos2d::Vec3 strToVec3(std::string str)
{
    cocos2d::Vec3 ret;
    
    std::vector<std::string> parts;
    SplitString(str, parts, ",");
    
    assert(parts.size() == 3);
    
    ret.x = std::stof(parts[0]);
    ret.y = std::stof(parts[1]);
    ret.z = std::stof(parts[2]);
    
    return ret;
}


bool TroopSetManager::LoadTroop(std::string szFileName)
{
	pugi::xml_document doc;

    if(doc.load_file(szFileName.c_str()) &&
       LoadSelector(doc) &&
       LoadGroupDefinition(doc) &&
       LoadTroopSet(doc))
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool TroopSetManager::LoadSelector(pugi::xml_document& doc)
{
	pugi::xml_node selectorsConfig = doc.child("FishTypeSelector");
	if (selectorsConfig.empty()) return false;

	auto xmlSelectors = selectorsConfig.children("Selector");
    
    for(auto selectorIter = xmlSelectors.begin(); selectorIter != xmlSelectors.end(); selectorIter++)
    {
        pugi::xml_node& selectorConfig = *selectorIter;
		int id = selectorConfig.attribute("id").as_int(0);

		const char* type = selectorConfig.attribute("type").as_string(0);
        std::vector<int> vType;
        std::vector<int> vWeight;
		std::vector<std::string> strs;
		SplitString(type, strs, ",");
		for (size_t i = 0; i < strs.size(); i++)
		{
			vType.push_back(std::stoi(strs[i]));
		}

		const char* weight = selectorConfig.attribute("weight").as_string(0);
		SplitString(weight, strs, ",");
		for (size_t i = 0; i < strs.size(); i++)
		{
			vWeight.push_back(std::stoi(strs[i]));
		}
        
        m_selectors[id] = TypeSelector();
        m_selectors[id].setParam(id, vType, vWeight);
	}

	return true;
}

bool TroopSetManager::LoadGroupDefinition(pugi::xml_document& doc)
{
    pugi::xml_node container = doc.child("GroupDefinition");
    if (container.empty()) return false;
    
    auto xmlGroups = container.children("Group");
    
    for(auto groupIter = xmlGroups.begin(); groupIter != xmlGroups.end(); groupIter++)
    {
        pugi::xml_node& xmlGroup = *groupIter;
        int id = xmlGroup.attribute("id").as_int(0);
        
        if(id == 0)
        {
            return false;
        }
        
        m_Groups[id] = GroupConfig();
        m_Groups[id].id = id;
        m_Groups[id].transform = nullptr;
        LoadGroup(*groupIter, m_Groups[id]);
    }
    
    return true;
}

bool TroopSetManager::LoadGroup(pugi::xml_node& xmlGroup, GroupConfig& config)
{
    auto xmlGenerators = xmlGroup.children("Generator");
    
    for(auto generatorIter = xmlGenerators.begin(); generatorIter != xmlGenerators.end(); generatorIter++)
    {
        config.generator.push_back(GeneratorConfig());
        LoadGenerator(*generatorIter, config.generator[config.generator.size() - 1]);
    }
    
    auto xmlTransform = xmlGroup.child("Transform");
    
    if(!xmlTransform.empty())
    {
        config.transform = TransformActionCreator::getInstance()->createActionWithConfig(xmlTransform);
    }
    
    return true;
}

bool TroopSetManager::LoadGenerateParam(pugi::xml_node& xmlData, GenerateParam& param)
{
    if (!xmlData.attribute("belong").empty())
    {
        param.belong = xmlData.attribute("belong").as_bool(true);
    }
    
    if (!xmlData.attribute("pathId").empty())
    {
        param.pathId = xmlData.attribute("pathId").as_int(0);
    }
    
    if (!xmlData.attribute("type").empty())
    {
        param.type = xmlData.attribute("type").as_int(0);
    }
    
    if (!xmlData.attribute("duration").empty())
    {
        param.duration = xmlData.attribute("duration").as_float(0);
    }
    
    if (!xmlData.attribute("speed").empty())
    {
        param.speed = xmlData.attribute("speed").as_float(0);
    }
    
    if (!xmlData.attribute("position").empty())
    {
        param.position = strToVec3(xmlData.attribute("position").as_string("0, 0, 0"));
    }
    
    if (!xmlData.attribute("direction").empty())
    {
        cocos2d::Vec3 direction = strToVec3(xmlData.attribute("direction").as_string("1, 0, 0"));
        direction.normalize();
        param.direction = direction;
    }
    
    if (!xmlData.attribute("motion").empty())
    {
        if (strcmp(xmlData.attribute("motion").as_string(""), "path") == 0)
        {
            param.motionType = GenerateParam::MOTION_TYPE::PATH;
        }
        else
        {
            param.motionType = GenerateParam::MOTION_TYPE::DIRECTION;
        }
    }
    
    return true;
}

bool TroopSetManager::LoadGenerator(pugi::xml_node &xmlGenerator, GeneratorConfig &config)
{
    config.delay = xmlGenerator.attribute("delay").as_float(0);
    config.spawnCount = xmlGenerator.attribute("count").as_int(0);
    config.spawnInterval = xmlGenerator.attribute("interval").as_float(0);
    config.typeSelectorId = xmlGenerator.attribute("selector").as_int(0);
    config.fixType = xmlGenerator.attribute("fixed").as_bool(0);
    config.spawnCircle = xmlGenerator.attribute("spawnCircle").as_int(0);
    LoadGenerateParam(xmlGenerator, config.param);
    
    auto xmlClusters = xmlGenerator.children();
    
    for(auto clusterIter = xmlClusters.begin(); clusterIter != xmlClusters.end(); clusterIter++)
    {
        config.clusters.push_back(SpawnCluster());
        
        if(std::string((*clusterIter).name()) == "Line")
        {
            LoadLine(*clusterIter, config.clusters[config.clusters.size() - 1], config.param);
        }
        else if(std::string((*clusterIter).name()) == "Circle")
        {
            LoadCircle(*clusterIter, config.clusters[config.clusters.size() - 1], config.param);
        }
        else if(std::string((*clusterIter).name()) == "Point")
        {
            LoadPoint(*clusterIter, config.clusters[config.clusters.size() - 1], config.param);
        }
        else
        {
            return false;
        }
    }

    return true;
}

bool TroopSetManager::LoadCircle(pugi::xml_node& xmlCircle, SpawnCluster& config, GenerateParam param)
{
    GenerateParam temp;
    LoadGenerateParam(xmlCircle, temp);
    config.param = param = temp;
    
    config.typeSelectorId = xmlCircle.attribute("selector").as_int(0);
    config.fixType = xmlCircle.attribute("fixed").as_bool(false);
    
    float interval = xmlCircle.attribute("interval").as_float(0) * M_PI / 180;
    float count = xmlCircle.attribute("count").as_int(0);
    float startRadius = xmlCircle.attribute("startRadius").as_float(0);
    float startAngle = xmlCircle.attribute("startAngle").as_float(0) * M_PI / 180;
    cocos2d::Vec3 center = strToVec3(xmlCircle.attribute("center").as_string("1, 0, 0"));
    cocos2d::Vec3 axisC = strToVec3(xmlCircle.attribute("axis").as_string("0 ,0 ,0"));
    
    axisC.normalize();
    
    std::vector<cocos2d::Vec3> startPositions;
    std::vector<cocos2d::Vec3> startDirections;
    
    
    float axisLength = sqrtf(axisC.x * axisC.x + axisC.z * axisC.z);
    
    cocos2d::Vec3 axisA;
    
    if(axisLength == 0)
    {
        axisA = cocos2d::Vec3(0, 0, 1);
    }
    else
    {
        axisA = cocos2d::Vec3(-axisC.z / axisLength, 0, axisC.x / axisLength);
    }

    
    cocos2d::Vec3 axisB;
    cocos2d::Vec3::cross(axisC, axisA, &axisB);
    axisB.normalize();
    
    for(int i = 0; i < count; i++)
    {
        cocos2d::Vec3 position;
        cocos2d::Vec3 direction;
        position = center + startRadius * cos(i * interval + startAngle) * axisA + startRadius * sin(i * interval + startAngle) * axisB;
        direction = position - center;
        
        startPositions.push_back(position);
        startDirections.push_back(direction);
    }
    
    auto xmlElements = xmlCircle.children();
    
    for(auto elementIter = xmlElements.begin(); elementIter != xmlElements.end(); elementIter++)
    {
        int size = config.elements.size();
        
        if(size < count)
        {
            config.elements.push_back(SpawnElement());
            GenerateParam temp = config.param;
            temp.direction = startDirections[size];
            temp.position = startPositions[size];
            LoadElement(*elementIter, config.elements[size], temp);
        }
        else
        {
            break;
        }
    }
    
    return true;
}

bool TroopSetManager::LoadLine(pugi::xml_node& xmlLine, SpawnCluster& config, GenerateParam param)
{
    GenerateParam temp;
    LoadGenerateParam(xmlLine, temp);
    config.param = param = temp;
    
    config.typeSelectorId = xmlLine.attribute("selector").as_int(0);
    config.fixType = xmlLine.attribute("fixed").as_bool(false);
    
    float interval = xmlLine.attribute("interval").as_float(0);
    float count = xmlLine.attribute("count").as_int(0);

    cocos2d::Vec3 direction = strToVec3(xmlLine.attribute("axis").as_string("1, 0, 0"));
    direction.normalize();
    cocos2d::Vec3 start = strToVec3(xmlLine.attribute("start").as_string("0 ,0 ,0"));
    
    std::vector<cocos2d::Vec3> startPositions;
    
    for(int i = 0; i < count; i++)
    {
        startPositions.push_back(start + direction * interval * i);
    }
    
    auto xmlElements = xmlLine.children();
    
    for(auto elementIter = xmlElements.begin(); elementIter != xmlElements.end(); elementIter++)
    {
        int size = config.elements.size();
        
        if(size < count)
        {
            config.elements.push_back(SpawnElement());
            GenerateParam temp = config.param;
            temp.direction = direction;
            temp.position = startPositions[size];
            LoadElement(*elementIter, config.elements[size], temp);
        }
        else
        {
            break;
        }
    }
    
    return true;
}

bool TroopSetManager::LoadPoint(pugi::xml_node& xmlPoint, SpawnCluster& config, GenerateParam param)
{
    GenerateParam temp;
    LoadGenerateParam(xmlPoint, temp);
    config.param = param = temp;
    
    config.typeSelectorId = xmlPoint.attribute("selector").as_int(0);
    config.fixType = xmlPoint.attribute("fixed").as_bool(false);
    
    float count = xmlPoint.attribute("count").as_int(0);
    cocos2d::Vec3 position = strToVec3(xmlPoint.attribute("position").as_string("0, 0, 0"));
    cocos2d::Vec3 direction = strToVec3(xmlPoint.attribute("direction").as_string("1, 0, 0"));
    direction.normalize();
    
    auto xmlElements = xmlPoint.children();
    
    for(auto elementIter = xmlElements.begin(); elementIter != xmlElements.end(); elementIter++)
    {
        int size = config.elements.size();
        
        if(size < count)
        {
            config.elements.push_back(SpawnElement());
            LoadElement(*elementIter, config.elements[size], config.param, position, direction);
        }
        else
        {
            break;
        }
    }
    
    return true;
}

bool TroopSetManager::LoadElement(pugi::xml_node &xmlElement, SpawnElement &config, GenerateParam param)
{
    GenerateParam temp;
    LoadGenerateParam(xmlElement, temp);
    config.param = param = temp;
    config.typeSelectorId = xmlElement.attribute("selector").as_int(0);
    config.fixType = xmlElement.attribute("fixed").as_bool(false);
    
    if(std::string(xmlElement.name()) == "Fish")
    {
        config.category = SpawnElement::CATEGORY::FISH;
    }
    else if(std::string(xmlElement.name()) == "Group")
    {
        config.category = SpawnElement::CATEGORY::GROUP;
    }
    else
    {
        assert(false);
    }
    
    cocos2d::Vec3 offset = strToVec3(xmlElement.attribute("offset").as_string("0, 0, 0"));
    config.param.position = config.param.position.get() + offset;
    
    auto xmlElements = xmlElement.children();
    
    for(auto elementIter = xmlElements.begin(); elementIter != xmlElements.end(); elementIter++)
    {
        LoadSpecialPattern(*elementIter, config);
    }
    
    return true;
}

bool TroopSetManager::LoadElement(pugi::xml_node& xmlElement, SpawnElement& config, GenerateParam param, cocos2d::Vec3 startPosition, cocos2d::Vec3 startDirection)
{
    config.param.position = startPosition;
    config.param.direction = startDirection;
    return LoadElement(xmlElement, config, param);
}

bool TroopSetManager::LoadSpecialPattern(pugi::xml_node& xmlElement, SpawnElement& config)
{
    GenerateParam temp;
    LoadGenerateParam(xmlElement, temp);
    
    GenerateParam pattern = config.param;
    pattern = temp;
    
    int replaceIndex = xmlElement.attribute("replaceIndex").as_int();
    config.specialPatterns[replaceIndex] = pattern;
    
    return true;
}

bool TroopSetManager::LoadTroopSet(pugi::xml_document& doc)
{
    auto xmlTroopSets = doc.children("TroopSet");
    
    for(auto troopSetIter = xmlTroopSets.begin(); troopSetIter != xmlTroopSets.end(); troopSetIter++)
    {
        pugi::xml_node& xmlTroopSet = *troopSetIter;
        int id = xmlTroopSet.attribute("id").as_int(0);
        
        if(id == 0)
        {
            assert(false);
        }
        
        m_Troops[id] = TroopConfig();
        TroopConfig& config = m_Troops[id];
        
        auto xmlStartGroups = xmlTroopSet.child("StartGroup").children("Group");
        
        for(auto groupIter = xmlStartGroups.begin(); groupIter != xmlStartGroups.end(); groupIter++)
        {
            config.startGroups.push_back(SpawnElement());
            GenerateParam temp;
            LoadGenerateParam((*groupIter), temp);
            LoadElement(*groupIter, config.startGroups[config.startGroups.size() - 1], temp);
        }
        
#ifdef SERVER_SIDE
        pugi::xml_node des = xmlTroopSet.child("DescribeText");
        
        while (!des.empty())
        {
            std::string content = des.attribute("content").as_string("0");
            
            TCHAR szinof[256];
            DWORD	nLen = MultiByteToWideChar(CP_UTF8, 0, content.c_str(), content.length(), NULL, 0);
            MultiByteToWideChar(CP_UTF8, 0, content.c_str(), content.length(), szinof, nLen);
            szinof[nLen] = TCHAR('\0');
            
            config.describ.push_back(szinof);
            
            if (config.describ.size() >= 4) break;
            
            des = des.next_sibling("DescribeText");
        }
#endif
    }
    
    return true;
}

GroupConfig* TroopSetManager::GetGroup(int id)
{
    return &m_Groups[id];
}

TroopConfig* TroopSetManager::GetTroop(int id)
{
    if(m_Troops.find(id) != m_Troops.end())
    {
        return &m_Troops[id];
    }
    else
    {
        return nullptr;
    }
}

TypeSelector* TroopSetManager::GetSelector(int id)
{
    return &m_selectors[id];
}

void TroopSetManager::clear()
{
    for(auto iter = m_Groups.begin(); iter != m_Groups.end(); iter++)
    {
        GroupConfig& config = iter->second;
        
        delete config.transform;
    }
    
    m_Troops.clear();
    m_selectors.clear();
    m_Groups.clear();
}
