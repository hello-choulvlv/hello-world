#include "HelloWorldScene.h"
#include "WaterNode.hpp"
#include "DrawNode3D.hpp"
#include "ModelInspector.hpp"
#include "GlobalValue.hpp"
#include "Navigator.hpp"
#include "RouteReader.hpp"
#include "ObbTest.hpp"
#include "CollisionArea.hpp"
#include "PausableAction.hpp"
#include "ActionController.hpp"
#include "CollisionAreaEditor.hpp"
#include "TextFieldEx.hpp"
#include "VecEditor.hpp"
#include "ui/CocosGUI.h"
#include "RctEditor.hpp"
#include "CollisionManager.hpp"
#include "CollisionTest.hpp"
#include "GameDebugger.hpp"
#include "TcpTest.hpp"
#include "DebugPrint.hpp"
#include "NavigatorCircle.hpp"
#include "PointRotate.hpp"
#include "TransformActionCreator.hpp"
#include "TroopSetManager.h"
#include "Group.hpp"
#include "TroopSetTestCase.hpp"
#include "Particle3D/CCParticleSystem3D.h"
#include "Particle3D/PU/CCPUParticleSystem3D.h"
#include "OpenFileDialog.h"
#include "cocostudio/CCArmature.h"
#include "spine/SkeletonAnimation.h"
#include "GerstnerTest.hpp"
#include "ShaderNode.h"
#include "VortexNode.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();
    // return the scene
    scene->addChild(layer);
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    FileUtils::getInstance()->addSearchPath("Particle3D/materials");
    FileUtils::getInstance()->addSearchPath("Particle3D/scripts");
    FileUtils::getInstance()->addSearchPath("Particle3D/textures");
    
    //Scene* scene = Scene::create();
    
    //Director::getInstance()->setProjection(cocos2d::Director::Projection::_3D);
   // Director::getInstance()->getOpenGLView()->setFrameSize(1334, 750);
   // Director::getInstance()->getOpenGLView()->setDesignResolutionSize(2668, 1500, ResolutionPolicy::NO_BORDER);
    
    //Camera* cam = Camera::getDefaultCamera();
    
    /*                  */
    /*      碰撞编辑      */
    /*                  */
    
    CollisionAreaEditor* editor = CollisionAreaEditor::create();
    editor->setData("shiziyu");
    this->addChild(editor);
    
    
    /*                  */
    /*      鱼群预览      */
    /*                  */
//    AmbientLight* ambient = AmbientLight::create(Color3B(150, 150, 130));
//    scene->addChild(ambient);
//    
//    DirectionLight* direction = DirectionLight::create(Vec3(0.3, -1, -0.2), Color3B(160, 160, 180));
//    direction->setPosition3D(Vec3(667, 850, 100));
//    direction->setIntensity(1.2);
//    scene->addChild(direction);
//    
//    DirectionLight* direction3 = DirectionLight::create(Vec3(0.63, -1, 0.1), Color3B(150, 150, 170));
//    direction3->setPosition3D(Vec3(667, 850, 100));
//    direction3->setIntensity(0.6);
//    scene->addChild(direction3);
//    
//    DirectionLight* direction2 = DirectionLight::create(Vec3(-0.3, 1, 0.2), Color3B(100, 100, 100));
//    direction2->setPosition3D(Vec3(667, -100, -80));
//    direction2->setIntensity(1.2);
//    scene->addChild(direction2);
//    
//    DirectionLight* direction4 = DirectionLight::create(Vec3(-0.5, 1, -0.4), Color3B(60, 60, 60));
//    direction4->setPosition3D(Vec3(667, -100, 80));
//    direction4->setIntensity(0.7);
//    scene->addChild(direction4);
//    
//    DirectionLight* direction5 = DirectionLight::create(Vec3(0, 0, -0.4), Color3B(120, 120, 120));
//    direction5->setPosition3D(Vec3(667, 375, 100));
//    direction5->setIntensity(0.7);
//    scene->addChild(direction5);
//    
//    TroopSetTestCase* testCase = TroopSetTestCase::getInstance();
//    testCase->startTroop(1);
//    this->addChild(testCase);
    
//    GerstnerTest* testCase = GerstnerTest::create();
//    this->addChild(testCase);
    
    //scene->addChild(this);
    //Director::getInstance()->runWithScene(scene);
    
//    ShaderNode *node=ShaderNode::create("shader/Shader_VS.glsl", "shader/Shader_FS.glsl", "Map_new_0.jpg");
//    auto &winSize = Director::getInstance()->getWinSize();
//    node->setPosition(Vec2(winSize.width/2,winSize.height/2));
//    this->addChild(node);
//    auto &winSize=Director::getInstance()->getWinSize();
//    Texture2D *texture=TextureCache::getInstance()->addImage("Map_new_5.jpg");
//    Texture2D *texture1=TextureCache::getInstance()->addImage("Map_new_2.jpg");
//    VortexNode *node=VortexNode::create(texture, texture1);
//    node->setPosition(Vec2(winSize.width/2,winSize.height/2));
//    node->setTag(0x80);
//    this->addChild(node);
//    
//    node->runAction(Sequence::create(ActionChangeVortex::create(2,0.5f, -M_PI *2.0f, 0),
//                                     CallFunc::create([node](){
//        node->setAlpha(1);
//    }),ActionChangeVortex::create(2.0f, -0.5f, M_PI*2.0f, 0),
//                                     CallFunc::create([=](){
//        _lastSelectedIndex=0;
//        node->setRadius(0.000001);
//        node->swap();
//        node->setAlpha(0);
//    }),
//                                     nullptr));
//    _lastSelectedIndex=1;
//    
//    setTouchEnabled(true);
//    setTouchMode(Touch::DispatchMode::ONE_BY_ONE);
    return true;
}

bool HelloWorld::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *unused_event)
{
    if(!_lastSelectedIndex)
    {
        VortexNode *node=(VortexNode*)this->getChildByTag(0x80);
        node->runAction(Sequence::create(ActionChangeVortex::create(2,0.5f, -M_PI *2.0f, 0),
                                         CallFunc::create([node](){
            node->setAlpha(1);
        }),ActionChangeVortex::create(2.0f, -0.5f, M_PI*2.0f, 0),
                                         CallFunc::create([=](){
            _lastSelectedIndex=0;
            node->setRadius(0.000001);
            node->swap();
            node->setAlpha(0);
        }),nullptr));
        _lastSelectedIndex=1;
        
    }
    return true;
}

void HelloWorld::onTouchMoved(cocos2d::Touch *touch, cocos2d::Event *unused_event)
{
    
}

void HelloWorld::onTouchEnded(cocos2d::Touch *touch, cocos2d::Event *unused_event)
{
    
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}


//      ########## OPEN FILE DIALOG ##########

//    OpenFileDialog* dialog = new OpenFileDialog();



