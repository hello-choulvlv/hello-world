//
//  MultiViewScene.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/11.
//
//

#include "MultiViewScene.hpp"
#include "AxisEditor.hpp"
#include "ModelInspector.hpp"
#include "PointEditor.hpp"

using namespace cocos2d;

MultiViewScene* MultiViewScene::create()
{
    MultiViewScene* ret = new MultiViewScene();
    ret->init();
    ret->autorelease();
    return ret;
}

MultiViewScene::MultiViewScene()
{
    Size viewSize = Size(1334, 750);
    float viewAngle = 40;
    float eyePosition = viewSize.height * 0.5 / tan(viewAngle * 0.5 / 180 * M_PI);
    float proportion = viewSize.width / viewSize.height;
    
//    Camera* cam = Camera::create();
//    cam->initDefault();
//    cam->setViewport(experimental::Viewport(0, 0, viewSize.width / 2, viewSize.height / 2));
//    cam->initPerspective(viewAngle, proportion, eyePosition / 2, eyePosition / 2 + 5000);
//    cam->setPosition3D(Vec3(viewSize.width / 2, viewSize.height / 2, eyePosition));
//    cam->lookAt(Vec3(viewSize.width / 2, viewSize.height / 2, eyePosition), Vec3(0, 1, 0));
//    this->addChild(cam);
    
//    Sprite3D* testSprite = Sprite3D::create("3d/shayu/shayu.c3b");
//    testSprite->setPosition3D(Vec3(100, 750, -200));
//    testSprite->setRotation3D(Vec3(0, 0, 0));
//    testSprite->setScale(0.15);
//    this->addChild(testSprite);
    
    ModelInspector* inspector = ModelInspector::create();
    inspector->showPlane(false);
    this->addChild(inspector);
    
    PointEditor* editor = PointEditor::create();
    editor->setValue(Vec3(0, 0, 0));
    inspector->append(editor);
}

MultiViewScene::~MultiViewScene()
{
    
}
