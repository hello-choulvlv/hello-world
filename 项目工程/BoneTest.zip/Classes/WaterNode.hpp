//
//  WaterNode.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/8.
//
//

#ifndef WaterNode_hpp
#define WaterNode_hpp

#include "cocos2d.h"

class WaterNode : public cocos2d::Sprite
{
public:
    static WaterNode* create();
    virtual void onEnter() override;
    virtual void draw(cocos2d::Renderer *renderer, const cocos2d::Mat4 &transform, uint32_t flags) override;

private:
    float dt;
    float time_passed;
};

#endif /* WaterNode_hpp */
