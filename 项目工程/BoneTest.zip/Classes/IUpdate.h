//
//  IUpdate.h
//  BoneTest
//
//  Created by charlie on 2017/8/15.
//
//

#ifndef IUpdate_h
#define IUpdate_h

class IUpdate {
public:
    virtual void onUpdate(float dt) {};
};

#endif /* IUpdate_h */
