//
//  CollisionManager.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/22.
//
//

#ifndef CollisionManager_hpp
#define CollisionManager_hpp

#include "cocos2d.h"
#include "json/document.h"

class DrawNode3D;

namespace CollisionShape {
    
    enum SHAPE_TYPE {HEX, RCT, CRL};
    
    typedef  struct {
        SHAPE_TYPE _type = SHAPE_TYPE::RCT;
        cocos2d::Vec3 _x = cocos2d::Vec3(1, 0, 0);
        cocos2d::Vec3 _y = cocos2d::Vec3(0, 1, 0);
        cocos2d::Vec3 _z = cocos2d::Vec3(0, 0, 1);
        cocos2d::Vec3 _center = cocos2d::Vec3(0, 0, 0);
    } R;
    
    typedef struct {
        SHAPE_TYPE _type = SHAPE_TYPE::HEX;
        cocos2d::Vec3 _center = cocos2d::Vec3(0, 0, 0);
        cocos2d::Vec3 _p[8] = {
            {1, 1, 1},
            {1, -1, 1},
            {-1, -1, 1},
            {-1, 1, 1},
            {1, 1, -1},
            {1, -1, -1},
            {-1, -1, -1},
            {-1, 1, -1},
        };
    } H;
    
    typedef struct {
        SHAPE_TYPE _type = SHAPE_TYPE::CRL;
        cocos2d::Vec3 _center;
        float _radius;
    } C;
    
    union Shape
    {
        Shape(R& r):_r(r){}
        Shape(H& h):_h(h){}
        Shape(C& c):_c(c){}
        Shape():_r(R()){}
        Shape(Shape& s){ memcpy(this, &s, sizeof(Shape));}
        Shape(Shape const& s){ memcpy(this, &s, sizeof(Shape));}
        ~Shape() {}
        
        SHAPE_TYPE _type;
        R _r;
        H _h;
        C _c;
    };
}

class CollisionManager {
  
// TYPE //
    
public:
    typedef std::pair<int, CollisionShape::Shape*> ConfigData;
    typedef std::vector<ConfigData> ConfigList;
    
    struct CollisionArea
    {
        CollisionArea():__node(nullptr), __config(nullptr), __collisionMask(0) {}
        void bind(cocos2d::Sprite3D* node) {__node = node;}
        void unbind() {__node = nullptr;}
        void setCollisionMask(int collisionMask) {__collisionMask = collisionMask;}
        
        cocos2d::Sprite3D* __node;
        CollisionManager::ConfigList* __config;
        int __collisionMask;
    };

    
// CONSTRUCTOR //
    
protected:
    CollisionManager():__projectionMode(cocos2d::Director::Projection::_2D) {}
    virtual ~CollisionManager() {};
   
    
// NON-VIRTUAL //
    
public:
    void setProjectionMode(cocos2d::Director::Projection projectionMode) {__projectionMode = projectionMode;}
    
    
// VIRTUAL //
    
public:
    virtual CollisionArea* claimCollisionArea(std::string configName) {return nullptr;}
    virtual void reclaimCollisionArea(CollisionArea*) {};
    virtual void registerArea(CollisionArea* area) {};
    virtual void unregisterArea(CollisionArea* area) {};
    virtual void update(float dt) {};
    
    
// ATTRIBUTE //
    
protected:
    cocos2d::Director::Projection __projectionMode;
    
    
// STATIC //
    
public:
    static CollisionManager* getInstance();
    static void destroyInstance();
private:
    static CollisionManager* __sInstance;

};

class SimpleCollisionManager : public CollisionManager
{
private:
    
    // Augment the [CollisionArea] class with a type attribute.
    //
    // -- PS:
    //      The augmented type attribute will be used by the [SimpleCollisionManager] to
    //      categorize [CollisionArea] into different groups. Since the game requires that
    //      shapes colliding with each other only if they were in different groups, this
    //      categorization will help speed up the search progress for collidable shape pairs;
    //
    //      Inside [SimpleCollisionManager], each type of [CollisionArea] is stored seperatedly,
    //      you will see this implemented in the declaration of [RegionCache] type;
    //
    //      BTW, the [CollisionArea] class has a mask attribute, which is wholly capable of
    //      doing simple categorizations, but it will also be used to implment the "locking"
    //      function. So, to make things clearer, I put type info into a different attribute,
    //      and type it with an enum, which will help a lot when doing debugs.
    
    enum COLLISION_AREA_TYPE {BULLET, FISH, AREA_TYPE_COUNT};

    struct CollisionAreaTyped : public CollisionArea {
        
        CollisionAreaTyped():CollisionArea(), _areaType(COLLISION_AREA_TYPE::BULLET) {}
        COLLISION_AREA_TYPE _areaType;
        
    };
    
public:
    SimpleCollisionManager();
    virtual ~SimpleCollisionManager();
    
public:
    
    //  claimCollisionArea function acts as a simple factory for [CollisionArea].
    //
    //  Different types of [CollisionArea] will be generated according to the
    //  configName parameter. However, the end user of these generated instances
    //  will only understand it at the interface level. All they need to do and can
    //  do is to bind the [CollisionArea] instance to the object they want.
    //
    //  [SimpleCollisionManager] does not offer a pool for collisionArea.
    //
    //  Every time a user claim an [CollisionArea], [SimpleCollisionManager] will allocate
    //  a new instance for him. And if the user reclaim the [CollisionArea] they claimed
    //  beforehand, it will simply be deleted.
    
    virtual CollisionArea* claimCollisionArea(std::string configName);
    virtual void reclaimCollisionArea(CollisionArea* collisionArea);
    
    //  An instance of [CollisionArea] claimed by the end user need to be registered
    //  to the [CollisionManager] to add into the collision space. Only registered
    //  [CollisionArea] will be handled by [CollisionManager].

    virtual void registerArea(CollisionArea* area);
    virtual void unregisterArea(CollisionArea* area);
    
    //  Update action of [SimpleCollisionManager] includes the following phases
    //
    //      1.  Transform all shapes with the node they are binded to.
    //      2.  Project the transformed shapes onto 2D view plane.
    //      3.  Caculate aabb for each projected shape.
    //      4.  Put shapes into the regions the covered.
    //      5.  For each region do collision detection between groups of shapes.
    //      6.  Generate collision events.
    
    virtual void update(float dt);
    
protected:
    
    // This struct describes an axis-alligned 2D aabb with min-max pattern

    struct MinMax
    {
        float _minX;
        float _minY;
        float _maxX;
        float _maxY;
    };
    
    // This struct describes an projected hexahedron with its eight vertices defined
    
    struct ShapeProjected
    {
        CollisionArea* _parent;
        cocos2d::Vec2 _vertex[8];
    };
    
    //  Pre-edited collision shape configs, these shapes are stored in config files
    //  exported by editor software, and will be loaded during initialization progress
    
    typedef std::map<std::string, ConfigList> ConfigCache;
    
    //  Only registered [CollisionArea] will be handled by [CollisionManager], when
    //  to add or remove a [CollisionArea] is totally controled by users
    
    typedef std::list<CollisionArea*> AreaList;
    
    //  After each frame, collision shapes will be transformed by the object they were
    //  binding to and finally projected onto the view plane. Also, an aabb of the projected
    //  shape is generated during this progress for fast pruning.
    //
    //  This data structure cached the result of the manipulations above for each shape,
    //  in order to remove redundant calculation action in collision detection phase.
    //
    //  This data structure will be refreshed in each frame.
    
    typedef std::pair<ShapeProjected, MinMax> TransformedShapeInfo;
    typedef std::vector<TransformedShapeInfo> TransformedShapeCache;
    
    //  The game world is recognized as groups of square regions by the [CollisionManager].
    //  Each projected shape will finally be put into one or more of these regions, according to
    //  its aabb. During the collision detection phase, only shapes in the same region will
    //  be checked to reduce calculation overhead.
    //
    //  This data structure will be refreshed in each frame.
    //
    //  PS:
    //      No complicated data structure like quad tree is used here for space partitioning
    //      because the implementation overhead is too big.
    
    typedef std::vector<std::vector<std::vector<TransformedShapeInfo*>>> RegionCache;
    
    // Size of each storage data structure, used for pre allocation.
    
    struct {
        
        int _shapeCacheSize;
        int _regionCacheSize;
        int _regionX;
        int _regionY;
        int _regionSize;
        
    } CONST;
    
    // Instances of the storage data structure declared above.
    
    std::vector<ConfigCache> _configs;
    AreaList _registeredAreas;
    TransformedShapeCache _transformedShapes;
    RegionCache _divisions;
    
private:
    
    bool readConfig(std::string configName, COLLISION_AREA_TYPE type);
    void initConstants();
    void allocateCaches();
    void deallocateCaches();
    void clearCaches();
    
    void pushShape(TransformedShapeInfo& info, CollisionShape::R& r, cocos2d::Mat4& transform);
    void pushShape(TransformedShapeInfo& info, CollisionShape::C& c, cocos2d::Mat4& transform);
    void pushShape(TransformedShapeInfo& info, CollisionShape::H& h, cocos2d::Mat4& transform);
    void settleShape(TransformedShapeInfo& info, COLLISION_AREA_TYPE& type);
    
    bool intersectAABB(MinMax& a, MinMax& b);
    bool circleHexSAT(ShapeProjected& circle, ShapeProjected& hex);
    bool circleQuadSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius);
    bool circleAxisSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius);
    bool circleVertexSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius);
    
    void loadHex(CollisionShape::Shape& hex, rapidjson::Value& jsonValue);
    void loadConfigData(ConfigData& data, rapidjson::Value& jsonValue);
    void loadRct(CollisionShape::Shape& rct, rapidjson::Value& jsonValue);
    void loadCrl(CollisionShape::Shape& rct, rapidjson::Value& jsonValue);
    void loadVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue);
    
    cocos2d::Bone3D* getBone(cocos2d::Skeleton3D* skeleton, int boneIndex);
    
    friend class GameDebugger;
    
};

#endif /* CollisionManager_hpp */
