//
//  GlobalValue.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/11.
//
//

#ifndef GlobalValue_hpp
#define GlobalValue_hpp

namespace GLOBAL_VALUE {
    extern float const EPSILON;
}


#endif /* GlobalValue_hpp */
