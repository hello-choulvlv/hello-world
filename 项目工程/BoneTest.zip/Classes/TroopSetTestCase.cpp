//
//  TroopSetTestCase.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "TroopSetTestCase.hpp"
#include "TroopSetManager.h"
#include "ModelInspector.hpp"
#include "Group.hpp"
#include "Fish.hpp"
#include "Navigator.hpp"
#include "MoveComponentStill.hpp"
#include "MoveComponentBezier.hpp"
#include "MoveComponentDirection.hpp"
#include "MoveComponentSpiral.hpp"
#include "FishConfig.hpp"
#include "PathConfig.hpp"
#include "UpdateController.hpp"
#include "TextFieldEx.hpp"
#include "DrawNode3D.hpp"

TroopSetTestCase* TroopSetTestCase::getInstance()
{
    if(_instance == nullptr)
    {
        _instance = new TroopSetTestCase();
        _instance->init();
    }
    
    return _instance;
}

TroopSetTestCase* TroopSetTestCase::_instance = nullptr;

bool TroopSetTestCase::init()
{
    Node::init();
    
    _seed = 0;
    
    TroopSetManager::GetInstance()->LoadTroop("TroopSet.xml");
    
    cocos2d::Sprite* background = cocos2d::Sprite::create("Map_new_0.jpg");
    background->setGlobalZOrder(-10000);
    background->setPosition(1334 / 2, 750 / 2);
    background->setScale(1334.0 / 1280 * 1.02);
    background->setScaleY(750.0 / 723 * 1.02);
    this->addChild(background);
    
    _inspector = ModelInspector::create();
    _inspector->setVisible(false);
    this->addChild(_inspector);
    
    _updateController = UpdateController::create();
    _updateController->setTarget(this);
    _updateController->setDuration(300);
    this->addChild(_updateController);
    
    addReloadButton();
    addTextField();
    drawMeasure();
    
    return true;
}

void TroopSetTestCase::onEnter()
{
    Node::onEnter();
}

void TroopSetTestCase::onExit()
{
    Node::onExit();
}

int TroopSetTestCase::generateId()
{
    return ++_seed;
}

void TroopSetTestCase::startTroop(int troopId)
{
    TroopSetManager* instance = TroopSetManager::GetInstance();
    
    TroopConfig* config = TroopSetManager::GetInstance()->GetTroop(troopId);
    
    if(config)
    {
        for(int i = 0; i < config->startGroups.size(); i++)
        {
            SpawnElement copy = config->startGroups[i];
            copy.genType(0);
            
            createGroup(&copy, nullptr, 0.0001, 0, 0);
        }
        
        onUpdate(0.0001);
    }
    else
    {
        cocos2d::Label* contentLabel = cocos2d::Label::createWithSystemFont("找不到指定ID的GROUP！！！", "", 24);
        contentLabel->setColor(cocos2d::Color3B(255, 0, 0));
        cocos2d::DrawNode* background = cocos2d::DrawNode::create();
        background->drawSolidRect(cocos2d::Vec2(-200, -30), cocos2d::Vec2(200, 30), cocos2d::Color4F(0.1, 0.1, 0.1, 0.5));
        
        Node* animationNode = Node::create();
        animationNode->addChild(background);
        animationNode->addChild(contentLabel);
        animationNode->setPosition(cocos2d::Director::getInstance()->getVisibleSize() / 2 + cocos2d::Size(0, -100));
        this->addChild(animationNode, 3);
        
        cocos2d::MoveBy* move = cocos2d::MoveBy::create(1.4, cocos2d::Vec2(0, 200));
        animationNode->runAction(cocos2d::Sequence::create(move, cocos2d::RemoveSelf::create(), NULL));
    }
}

MoveComponent* TroopSetTestCase::createMoveComponent(GenerateParam* config, float fishSpeed)
{
    if(config->motionType.get() == GenerateParam::MOTION_TYPE::DIRECTION)
    {
        MoveComponentDirection* move = new MoveComponentDirection();
        move->setStartPosition(config->position.get());
        move->setStartDirection(config->direction.get());
        move->setSpeed(config->speed.get());
        move->setDuration(config->duration.get());
        return move;
    }
    else if(config->motionType.get() == GenerateParam::MOTION_TYPE::PATH)
    {
        int pathType = PathConfig::getInstance()->getRouteType(config->pathId.get());
        
        if(pathType == 1)
        {
            MoveComponentBezier* move = new MoveComponentBezier();
            move->setBezierRoute((CubicBezierRoute*)PathConfig::getInstance()->getRouteData(config->pathId.get()));
            move->setOffset(config->position.get());
            move->setSpeed(config->speed.get());
            
            return move;
        }
        else if(pathType == 4)
        {
            MoveComponentSpiral* move = new MoveComponentSpiral();
            move->setSpiralRoute((SpiralRoute*)PathConfig::getInstance()->getRouteData(config->pathId.get()));
            move->setOffset(config->position.get());
            move->setSpeed(config->speed.get());
            
            return move;
        }

        return nullptr;
    }
    else
    {
        return nullptr;
    }
}

void TroopSetTestCase::createGroup(SpawnElement* config, Group* parentGroup, float timeOverflow, int spawnIndex, int spawnCircle)
{
    GenerateParam* param;
    int specialIndex = spawnCircle > 0 ? spawnIndex % spawnCircle : 0;
    
    if(spawnCircle <= 0 || config->specialPatterns.find(specialIndex) == config->specialPatterns.end())
    {
        param = &(config->param);
    }
    else
    {
        param = &(config->specialPatterns[specialIndex]);
    }
    
    int groupType = param->type.get() == 0 ? config->type : param->type.get();
    
    GroupConfig* groupConfig = TroopSetManager::GetInstance()->GetGroup(groupType);
    
    Group* group = new Group();
    group->setConfig(*groupConfig);
    group->setMoveComponent(createMoveComponent(param, 0));
    
    if(parentGroup)
    {
        if(config->param.belong.get())
        {
            group->setParentTransform(parentGroup->getTransform());
            parentGroup->addMember(group);
        }
        else
        {
            group->setParentTransform(parentGroup->getTransform());
        }
    }
    
    int id = generateId();
    group->setId(id);
    _groups[id] = group;
    
    group->update(timeOverflow);
}

void TroopSetTestCase::createFish(SpawnElement* config, Group* parentGroup, float timeOverflow, int spawnIndex, int spawnCircle)
{
    GenerateParam* param;
    int specialIndex = spawnCircle > 0 ? spawnIndex % spawnCircle : 0;
    
    if(spawnCircle <= 0 || config->specialPatterns.find(specialIndex) == config->specialPatterns.end())
    {
        param = &(config->param);
    }
    else
    {
        param = &(config->specialPatterns[specialIndex]);
    }
    
    Fish* fish = new Fish();
    fish->setMoveComponent(createMoveComponent(param, 0));

    if(parentGroup)
    {
        if(config->param.belong.get())
        {
            fish->setParentTransform(parentGroup->getTransform());
            parentGroup->addMember(fish);
        }
        else
        {
            fish->setParentTransform(parentGroup->getTransform());
        }
    }
    
    int id = generateId();
    fish->setId(id);
    _groups[id] = fish;
    
    fish->update(timeOverflow);
    
    
    int fishType = param->type.get() == 0 ? config->type : param->type.get();
    
    cocos2d::Node* fishModel = createFishModelById(fishType);
    
    cocos2d::Label* posLabel = cocos2d::Label::createWithSystemFont("", "", 16);
    posLabel->setPosition3D(cocos2d::Vec3(fishModel->getPosition3D()));
    
    
    if(_presentorSelector->getContent() > 0)
    {
        _inspector->append(fishModel);
        _inspector->append(posLabel);
    }
    else
    {
        this->addChild(fishModel);
        this->addChild(posLabel);
    }
    
    _visualMaps[fish] = fishModel;
    _positionLabels[fishModel] = posLabel;
}

cocos2d::Node* TroopSetTestCase::createFishModelById(int fishId)
{
    FishConfig* config = FishConfig::getInstance();
    FishConfig::FishVisual* visualConfig = config->getVisualConfigByFishId(fishId);
    
    if(visualConfig)
    {
        if(visualConfig->type == 0)
        {
            char modelFilePath[256];
            sprintf(modelFilePath, "3d/%s/%s.c3b", visualConfig->modelName.c_str(), visualConfig->modelName.c_str());
            cocos2d::Sprite3D* sprite = cocos2d::Sprite3D::create(modelFilePath);
            
            if(sprite)
            {
                sprite->setScale(visualConfig->scale);
                
                cocos2d::Animation3D* animation = cocos2d::Animation3D::create(modelFilePath);
                cocos2d::Animate3D* animate = cocos2d::Animate3D::createWithFrames(animation, visualConfig->from, visualConfig->to);
                
                sprite->runAction(cocos2d::RepeatForever::create(animate));
            }
            
            return sprite;
        }
        else if(visualConfig->type == 1)
        {
            cocos2d::Node* node = cocos2d::Node::create();
            
            for(int i = 0; i < visualConfig->_nestedID.size(); i++)
            {
                FishConfig::FishVisual* visualConfigNested = config->getVisualConfigByFishId(visualConfig->_nestedID[i]);
                
                if(visualConfigNested->type == 1)
                {
                    break;
                }
                else
                {
                    char modelFilePath[256];
                    sprintf(modelFilePath, "3d/%s/%s.c3b", visualConfigNested->modelName.c_str(), visualConfigNested->modelName.c_str());
                    cocos2d::Sprite3D* sprite = cocos2d::Sprite3D::create(modelFilePath);
                    
                    if(sprite)
                    {
                        sprite->setScale(visualConfigNested->scale);
                        
                        cocos2d::Animation3D* animation = cocos2d::Animation3D::create(modelFilePath);
                        cocos2d::Animate3D* animate = cocos2d::Animate3D::createWithFrames(animation, visualConfigNested->from, visualConfigNested->to);
                        
                        sprite->runAction(cocos2d::RepeatForever::create(animate));
                    }
                    
                    node->addChild(sprite);
                }
            }
            
            return node;
        }
    }
    
    return nullptr;
}




void TroopSetTestCase::onUpdate(float dt)
{
    for(auto iter = _groups.begin(); iter != _groups.end(); iter++)
    {
        (*iter).second->setUpdateFlag(false);
    }
    
    for(auto iter = _groups.begin(); iter != _groups.end(); iter++)
    {
        (*iter).second->update(dt);
    }
    
    for(auto iter = _visualMaps.begin(); iter != _visualMaps.end(); iter++)
    {
        Group* group = (*iter).first;
        cocos2d::Node* visualNode = (*iter).second;
        
        float scale = visualNode->getScale();
        cocos2d::Mat4 transform = group->getTransform();
        transform.m[0]  *= scale;
        transform.m[1]  *= scale;
        transform.m[2]  *= scale;
        transform.m[4]  *= scale;
        transform.m[5]  *= scale;
        transform.m[6]  *= scale;
        transform.m[8]  *= scale;
        transform.m[9]  *= scale;
        transform.m[10] *= scale;
        
        visualNode->setNodeToParentTransform(transform);
        
        cocos2d::Label* posLabel = _positionLabels[visualNode];
        
        cocos2d::Vec3 pos;
        visualNode->getNodeToParentTransform().getTranslation(&pos);
        posLabel->setPosition3D(pos);
        posLabel->setGlobalZOrder(1000);
        posLabel->setVisible(false);
        posLabel->setColor(cocos2d::Color3B(0, 10, 0));
        
        char str[30];
        sprintf(str, "(%d, %d, %d)", (int)pos.x, (int)pos.y, (int)pos.z);
        posLabel->setString(str);
        
        
        bool hide = group->getMoveComponent()->ended();
        Group* parent = (Group*)group->getGroup();
        
        while (parent) {
            hide = hide || parent->getMoveComponent()->ended();
            parent = (Group*)parent->getGroup();
        }
        
        if(group->getMoveComponent())
        {
            visualNode->setVisible(!hide);
            posLabel->setVisible(false);
        }
    }
    
    for(auto iter = _groups.begin(); iter != _groups.end(); )
    {
        Group* group = (*iter).second;
        
        if(group->getLifetime() < 0)
        {
            auto visualIter = _visualMaps.find(group);
            
            if(visualIter != _visualMaps.end())
            {
                visualIter->second->removeFromParent();
                _positionLabels[visualIter->second]->removeFromParent();
                _visualMaps.erase(visualIter);
                _positionLabels.erase(_positionLabels.find(visualIter->second));
            }
            
            delete group;
            
            iter = _groups.erase(iter);
        }
        else
        {
            iter++;
        }
    }
}

void TroopSetTestCase::resetScene()
{
    for(auto iter = _groups.begin(); iter != _groups.end(); iter++)
    {
        Group* group = (*iter).second;
        
        auto visualIter = _visualMaps.find(group);
        
        if(visualIter != _visualMaps.end())
        {
            visualIter->second->removeFromParent();
            _positionLabels[visualIter->second]->removeFromParent();
        }
        
        delete group;
    }
    
    _groups.clear();
    _visualMaps.clear();
    _positionLabels.clear();
}

void TroopSetTestCase::reloadConfig()
{
    TroopSetManager::GetInstance()->clear();
    TroopSetManager::GetInstance()->LoadTroop("TroopSet.xml");
}

void TroopSetTestCase::addReloadButton()
{
    _reloadLabel = cocos2d::Label::createWithSystemFont("RELOAD", "", 32);
    _reloadLabel->setPosition(cocos2d::Vec2(100, 700));
    _reloadLabel->setColor(cocos2d::Color3B(255, 0, 0));
    this->addChild(_reloadLabel);
    
    cocos2d::EventListenerTouchOneByOne* touchEventListener = cocos2d::EventListenerTouchOneByOne::create();
    touchEventListener->onTouchBegan = CC_CALLBACK_2(TroopSetTestCase::onTouchBegan, this);;
    touchEventListener->setSwallowTouches(true);
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(touchEventListener, this);
}

void TroopSetTestCase::addTextField()
{
    _presentorSelector = TextFieldEx::create();
    _presentorSelector->setPosition(cocos2d::Vec2(280, 700));
    _presentorSelector->setScale(0.7);
    _presentorSelector->setTitle("Use Inspector");
    _presentorSelector->setContent(0);
    this->addChild(_presentorSelector);
    
    _troopSelector = TextFieldEx::create();
    _troopSelector->setPosition(cocos2d::Vec2(400, 700));
    _troopSelector->setScale(0.7);
    _troopSelector->setTitle("troop");
    _troopSelector->setContent(1);
    this->addChild(_troopSelector);
}

void TroopSetTestCase::drawMeasure()
{
    cocos2d::DrawNode* drawNode = cocos2d::DrawNode::create();
    drawNode->setLineWidth(1);
    
    for(int i = 0; i < 1334 / 50 + 2; i++)
    {
        char str[30];
        
        if(i % 2 == 0)
        {
            if(i == 0)
            {
                continue;
            }
            else
            {
                sprintf(str, "%d", i * 50);
                cocos2d::Label* label = cocos2d::Label::createWithSystemFont(str, "", 13);
                label->setPosition(cocos2d::Vec2(i * 50, 15 + 8));
                this->addChild(label, 3);
                
                _vMeasureLabel.push_back(label);
            }
            
            drawNode->drawLine(cocos2d::Vec2(i * 50, 0), cocos2d::Vec2(i * 50, 15), cocos2d::Color4F(0.8, 0.2, 0, 1.0));
        }
        else
        {
            drawNode->drawLine(cocos2d::Vec2(i * 50, 0), cocos2d::Vec2(i * 50, 8), cocos2d::Color4F(0.7, 0.2, 0, 1.0));
            sprintf(str, "%d", i * 50);
            cocos2d::Label* label = cocos2d::Label::createWithSystemFont(str, "", 11);
            label->setPosition(cocos2d::Vec2(i * 50, 8 + 8));
            this->addChild(label, 3);
            
            _vMeasureLabel.push_back(label);
        }
    }
    
    for(int i = 0; i < 1334 / 5 + 2; i++)
    {
        if(i % 10 != 0)
        {
            drawNode->drawLine(cocos2d::Vec2(i * 5, 0), cocos2d::Vec2(i * 5, 5), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
        }

    }
    
    for(int i = 0; i < 750 / 50 + 2; i++)
    {
        char str[30];
        
        if(i % 2 == 0)
        {
            if(i == 0)
            {
                continue;
            }
            else
            {
                sprintf(str, "%d", i * 50);
                cocos2d::Label* label = cocos2d::Label::createWithSystemFont(str, "", 13);
                label->setPosition(cocos2d::Vec2(15 + 12, i * 50));
                this->addChild(label, 3);
                
                _vMeasureLabel.push_back(label);
            }
            
            drawNode->drawLine(cocos2d::Vec2(0, i * 50), cocos2d::Vec2(15, i * 50), cocos2d::Color4F(0.8, 0.2, 0, 1.0));
        }
        else
        {
            drawNode->drawLine(cocos2d::Vec2(0, i * 50), cocos2d::Vec2(8, i * 50), cocos2d::Color4F(0.7, 0.2, 0, 1.0));
            sprintf(str, "%d", i * 50);
            cocos2d::Label* label = cocos2d::Label::createWithSystemFont(str, "", 11);
            label->setPosition(cocos2d::Vec2(8 + 12, i * 50));
            this->addChild(label, 3);
            
            _vMeasureLabel.push_back(label);
        }
    }
    
    for(int i = 2; i < 750 / 5 + 2; i++)
    {
        if(i % 10 != 0)
        {
            drawNode->drawLine(cocos2d::Vec2(0, i * 5), cocos2d::Vec2(5, i * 5), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
        }
        
    }
    
    this->addChild(drawNode, 3);
    
    DrawNode3D* zDrawNode = DrawNode3D::create();
    zDrawNode->drawLine(cocos2d::Vec3(0, 0, 0), cocos2d::Vec3(0, 0, -2000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(1334, 0, 0), cocos2d::Vec3(1334, 0, -2000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(0, 0, -1000), cocos2d::Vec3(1334, 0, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(0, 0, -1000), cocos2d::Vec3(1334, 0, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(0, 0, -1000), cocos2d::Vec3(0, 750, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(1334, 0, -1000), cocos2d::Vec3(1334, 750, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(0, 750, -1000), cocos2d::Vec3(1334, 750, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(0, 750, -1000), cocos2d::Vec3(1334, 750, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(0, 750, -1000), cocos2d::Vec3(1334, 750, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(0, 750, 0), cocos2d::Vec3(0, 750, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    zDrawNode->drawLine(cocos2d::Vec3(1334, 750, 0), cocos2d::Vec3(1334, 750, -1000), cocos2d::Color4F(0.5, 0.2, 0, 1.0));
    
    for(int i = 0; i < 2000 / 50 + 2; i++)
    {
        char str[30];
        
        if(i % 2 == 0)
        {
            if(i == 0)
            {
                continue;
            }
            else
            {
                sprintf(str, "%d", i * 50);
                cocos2d::Label* label = cocos2d::Label::createWithSystemFont(str, "", 13);
                label->setPosition3D(cocos2d::Vec3(15 + 12, 0, i * -50));
                this->addChild(label, 3);
                
                _vMeasureLabel.push_back(label);
            }
            
            zDrawNode->drawLine(cocos2d::Vec3(0, 0, i * -50), cocos2d::Vec3(15, 0, i * -50), cocos2d::Color4F(0.8, 0.2, 0, 1.0));
        }
        else
        {
            sprintf(str, "%d", i * 50);
            cocos2d::Label* label = cocos2d::Label::createWithSystemFont(str, "", 11);
            label->setPosition3D(cocos2d::Vec3(8 + 12, 0, i * -50));
            this->addChild(label, 3);
            
            zDrawNode->drawLine(cocos2d::Vec3(0 ,0, i * -50), cocos2d::Vec3(8, 0, i * -50), cocos2d::Color4F(0.7, 0.2, 0, 1.0));
            
            _vMeasureLabel.push_back(label);
        }
    }
    
    this->addChild(zDrawNode);
    
    _drawNodeXY = drawNode;
    _drawNodeZ = zDrawNode;
}

bool TroopSetTestCase::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *event)
{
    cocos2d::Rect bBox = _reloadLabel->getBoundingBox();
    
    if(bBox.containsPoint(touch->getLocation()))
    {
        _updateController->reset();
        resetScene();
        reloadConfig();
        startTroop(_troopSelector->getContent());
        
        if(_presentorSelector->getContent() > 0)
        {
            _inspector->setVisible(true);
            _drawNodeZ->setVisible(false);
            _drawNodeXY->setVisible(false);
            
            for(int i = 0; i < _vMeasureLabel.size(); i++)
            {
                _vMeasureLabel[i]->setVisible(false);
            }
        }
        else
        {
            _inspector->setVisible(false);
            _drawNodeZ->setVisible(true);
            _drawNodeXY->setVisible(true);
            
            for(int i = 0; i < _vMeasureLabel.size(); i++)
            {
                _vMeasureLabel[i]->setVisible(true);
            }
        }
            
        
        return true;
    }
    else
    {
        return false;
    }
}
