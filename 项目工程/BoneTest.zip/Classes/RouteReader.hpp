//
//  RouteReader.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/16.
//
//

#ifndef RouteReader_hpp
#define RouteReader_hpp

#include <string>
#include "json/document.h"
#include "cocos2d.h"

class RouteReader {

public:
    typedef std::map<std::string, std::vector<cocos2d::Vec3>> RouteInfo;
    
private:
    struct FbxNode {
        
        std::string name;
        cocos2d::Mat4 transform;
        std::vector<FbxNode*> children;
        
    };
    
public:
    static RouteReader* getInstance();
    
public:
    RouteInfo* read(std::string fileName);
    
private:
    void init();
    void clearNode();
    void clearNodeRecursively(FbxNode* node);
    void buildNode(rapidjson::Document& reader);
    FbxNode* buildNodeRecursively(const rapidjson::Value& nodeData);
    void createRootNode();
    
    cocos2d::Mat4 findTransform(std::string name);
    bool findTransformRecursively(std::string& name, FbxNode* node, std::list<cocos2d::Mat4>& transformChain);
    
    FbxNode* __pRoot;
    static RouteReader* __spInstance;
    
};

#endif /* RouteReader_hpp */
