//
//  PointRotate.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/1.
//
//

#include "PointRotate.hpp"

using namespace cocos2d;

PointRotate* PointRotate::__instance = nullptr;

PointRotate* PointRotate::getInstance()
{
    if(__instance == nullptr)
        __instance = new PointRotate();
    
    return __instance;
}


void PointRotate::rotate(std::vector<std::vector<cocos2d::Vec3>>& results, std::vector<cocos2d::Vec3>& points, RotateAxis& axis, float angluarStep, int times)
{
    if(fabs(angluarStep) > 360)
    {
        angluarStep = 360;
    }
    
    if(times == 0)
    {
        times = 360 / angluarStep;
    }
    
    angluarStep = angluarStep * M_PI / 180;
    axis.direction.normalize();
    
    std::vector<RotateParameter> params;
    params.resize(points.size());
    
    for(int index = 0; index < points.size(); index++)
    {
        RotateParameter& param = params[index];

        param.center = axis.through + axis.direction * (points[index] - axis.through).dot(axis.direction);
        param.axisB = points[index] - param.center;
        param.radius = param.axisB.length();
        Vec3::cross(param.axisB, axis.direction, &param.axisA);
        param.axisA.normalize();
        param.axisB.normalize();
    }
    
    results.resize(times);
    
    for(int pass = 0; pass < times; pass++)
    {
        std::vector<Vec3>& result = results[pass];
        result.resize(points.size());
        
        for(int index = 0; index < points.size(); index++)
        {
            RotateParameter& param = params[index];
            
            result[index] = param.center + param.radius * (sin(angluarStep * pass) * param.axisB + cos(angluarStep * pass) * param.axisA);
        }
    }
}
