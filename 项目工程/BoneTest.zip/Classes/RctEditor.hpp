//
//  RctEditor.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/27.
//
//

#ifndef RctEditor_hpp
#define RctEditor_hpp

#include "cocos2d.h"
#include "VecEditor.hpp"

class Rct;

class RctEditor : public cocos2d::Node
{
public:
    RctEditor();
    virtual ~RctEditor();
    
public:
    static RctEditor* create();
    virtual bool init();

public:
    void setRct(Rct& rct);
    Rct getRct();
    void setValueChangeCallback(std::function<void(Rct)> callback);
    
private:
    void onValueChange(cocos2d::Vec3 value);
    
private:
    VecEditor* __center;
    VecEditor* __xAxis;
    VecEditor* __yAxis;
    VecEditor* __zAxis;
    VecEditor* __extension;
    VecEditor* __rotation;
    VecEditor* __translation;
    VecEditor* __scale;
    std::function<void (Rct)> __valueChangeCallback;
};


#endif /* RctEditor_hpp */
