//
//  Fish.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "Fish.hpp"
#include "MoveComponent.hpp"

Fish::Fish()
{
    _currentPosition = cocos2d::Vec3(0, 0, 0);
    _currentDirection = cocos2d::Vec3(0, 0, 0);
}

cocos2d::Mat4 Fish::getTransform()
{
    if(!_transformCalculated)
    {
        if(_localTransformUpdated)
        {
            _localTransform = cocos2d::Mat4::IDENTITY;
            _calculatedTransform = cocos2d::Mat4::IDENTITY;
            
            if(_moveComponent)
            {
                cocos2d::Vec3 currentPosition = cocos2d::Vec3(0, 0, 0);
                cocos2d::Vec3 currentDirection = cocos2d::Vec3(0, 0, 0);

                _moveComponent->retrieveState(_currentPosition, _currentDirection);
            }
        }
        
        if(_parentTransformUpdated && _group)
            _parentTransform = ((Group*)_group)->getTransform();
        
        if(_localTransformUpdated || _parentTransformUpdated)
        {
            _parentTransform.transformVector(&_currentDirection);
            _parentTransform.transformPoint(&_currentPosition);
            
            buildTransformWithParam(_currentPosition, _currentDirection, 0.0, 1.0, _calculatedTransform);
        }
        
        _localTransformUpdated = false;
        _parentTransformUpdated = false;
        _transformCalculated = true;
    }
    
    return _calculatedTransform;
}
