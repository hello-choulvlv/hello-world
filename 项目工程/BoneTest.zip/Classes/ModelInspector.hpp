//
//  ModelInspector.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/9.
//
//

#ifndef ModelInspector_hpp
#define ModelInspector_hpp

#include "DrawNode3D.hpp"

class ModelInspector : public cocos2d::Node
{
public:
    static ModelInspector* create();
    virtual bool init() override;
    virtual void onEnter() override;
    virtual void onExit() override;
    void append(Node* child, int localZOrder = 0, const std::string &name = "");
    void showPlane(bool willShow);
    cocos2d::Mat4 getTransform();
    
private:
    void rotateNodeBy(float xOffset, float yOffset, cocos2d::Node* node);
    void scaleNodeBy(float distanceOffset, cocos2d::Node* node);
    void moveNodeBy(cocos2d::Vec2 directionOffset, cocos2d::Node* node);
    bool onTouchesBegan(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event *event);
    void onTouchesMoved(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event *event);
    void onTouchesEnded(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event *event);
    void onMouseScroll(cocos2d::EventMouse* event);
    void onKeyPressed(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event);
    void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event);
    void saveTouchData(cocos2d::Touch* touch);
    void removeTouchData(int id);
    cocos2d::Vec2 getTouchData(int id);
    
private:
    enum TOUCH_MODE {ONE, MULTI};
    
    Node* _rotator;
    DrawNode3D* _axisPresentation;
    
    int _division;
    int _representationWidth;
    
    float _offsetToAngleScale;
    
    cocos2d::EventListenerKeyboard* _keyboardListener;
    cocos2d::EventListenerMouse* _mouseListener;
    cocos2d::EventListenerTouchAllAtOnce* _touchListener;
    cocos2d::Vec2 _lastTouchPosition;
    
    float _xOffset;
    float _yOffset;
    float _distanceOffset;
    bool _ctrlPressed;
    
    TOUCH_MODE _touchMode;
    std::list<std::pair<int, cocos2d::Vec2>> _touchData;
};

#endif /* ModelInspector_hpp */
