//
//  GroupInterface.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#include "GroupInterface.hpp"

void IMember::setGroup(IGroup* group)
{
    _group = group;
}

IGroup* IMember::getGroup()
{
    return _group;
}

IMember::~IMember()
{
    if(_group)
    {
        _group->removeMember(this);
    }
}


void IGroup::addMember(IMember* member)
{
    _members.push_back(member);
    member->setGroup(this);
    member->enterGroup();
}

void IGroup::removeMember(IMember* member)
{
    for(auto iter = _members.begin(); iter != _members.end(); iter++)
    {
        if(*iter == member)
        {
            member->exitGroup();
            member->setGroup(nullptr);
            _members.erase(iter);
            break;
        }
    }
}

std::list<IMember*>& IGroup::getMembers()
{
    return _members;
}

IGroup::~IGroup()
{
    for(auto iter = _members.begin(); iter != _members.end(); iter++)
    {
        (*iter)->exitGroup();
        (*iter)->setGroup(nullptr);
    }
}
