//
//  DrawNode3D.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/9.
//
//

#include "DrawNode3D.hpp"

using namespace cocos2d;

DrawNode3D::DrawNode3D()
:_bufferCount(0),
_bufferCapacity(0),
_buffer(nullptr),
_vao(0),
_vbo(0),
_dirty(false),
__defaultColor(Color4F(1.0, 1.0, 1.0, 1.0))
{

}

bool DrawNode3D::init()
{
    Node::init();

    setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_COLOR));
    
    ensureCapacity(512);
    
    if(Configuration::getInstance()->supportsShareableVAO())
    {
        glGenVertexArrays(1, &_vao);
        GL::bindVAO(_vao);
    }
    
    glGenBuffers(1, &_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, _vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(V3F_C4B)*_bufferCapacity, _buffer, GL_STREAM_DRAW);
    
    glEnableVertexAttribArray(GLProgram::VERTEX_ATTRIB_POSITION);
    glVertexAttribPointer(GLProgram::VERTEX_ATTRIB_POSITION, 3, GL_FLOAT, GL_FALSE, sizeof(V3F_C4B), (GLvoid*)offsetof(V3F_C4B, vertices));
    
    glEnableVertexAttribArray(GLProgram::VERTEX_ATTRIB_COLOR);
    glVertexAttribPointer(GLProgram::VERTEX_ATTRIB_COLOR, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(V3F_C4B), (GLvoid*)offsetof(V3F_C4B, colors));
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    if(Configuration::getInstance()->supportsShareableVAO())
    {
        GL::bindVAO(0);
    }
    
    CHECK_GL_ERROR_DEBUG();
    
    return true;
}

DrawNode3D::~DrawNode3D()
{
    free(_buffer);
    glDeleteBuffers(1, &_vbo);
    
    if(Configuration::getInstance()->supportsShareableVAO())
    {
        glDeleteVertexArrays(1, &_vao);
        GL::bindVAO(0);
    }
}

DrawNode3D* DrawNode3D::create()
{
    DrawNode3D* pRet = new DrawNode3D();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

void DrawNode3D::draw(cocos2d::Renderer *renderer, const cocos2d::Mat4& transform, uint32_t flags)
{
    _customCommand.init(_globalZOrder, transform, flags);
    _customCommand.func = CC_CALLBACK_0(DrawNode3D::drawExecutor, this, transform, flags);
    _customCommand.set3D(false);
    _customCommand.setTransparent(false);
    renderer->addCommand(&_customCommand);
}

void DrawNode3D::drawExecutor(const cocos2d::Mat4& transform, uint32_t flags)
{
    
    GLProgram* gl = getGLProgram();
    gl->use();
    gl->setUniformsForBuiltins(transform);
//    glEnable(GL_DEPTH_TEST);
//    glDepthMask(true);
//    glDepthFunc(GL_LEQUAL);
//    RenderState::StateBlock::_defaultState->setDepthTest(true);
    GL::blendFunc(BlendFunc::ALPHA_NON_PREMULTIPLIED.src, BlendFunc::ALPHA_NON_PREMULTIPLIED.dst);

    if(_dirty)
    {
        glBindBuffer(GL_ARRAY_BUFFER, _vbo);
        glBufferData(GL_ARRAY_BUFFER, sizeof(V3F_C4B) * _bufferCapacity, _buffer, GL_STREAM_DRAW);
        _dirty = false;
    }
    
    if(Configuration::getInstance()->supportsShareableVAO())
    {
        GL::bindVAO(_vao);
    }
    else
    {
        GL::enableVertexAttribs(GL::VERTEX_ATTRIB_FLAG_POS_COLOR_TEX);
        
        glBindBuffer(GL_ARRAY_BUFFER, _vbo);
        glVertexAttribPointer(GLProgram::VERTEX_ATTRIB_POSITION, 3, GL_FLOAT, GL_FALSE, sizeof(V3F_C4B), (GLvoid *)offsetof(V3F_C4B, vertices));
        glVertexAttribPointer(GLProgram::VERTEX_ATTRIB_COLOR, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(V3F_C4B), (GLvoid *)offsetof(V3F_C4B, colors));
    }
    //int depthTest = glIsEnabled(GL_DEPTH_TEST);
   // if(!depthTest)
   //     glEnable(GL_DEPTH_TEST);
    glLineWidth(2);
    glDrawArrays(GL_LINES, 0, _bufferCount);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
   // if(!depthTest)
    //    glDisable(GL_DEPTH_TEST);
    
    CC_INCREMENT_GL_DRAWN_BATCHES_AND_VERTICES(1, _bufferCount);
    CHECK_GL_ERROR_DEBUG();
}

void DrawNode3D::drawLine(cocos2d::Vec3 from, cocos2d::Vec3 to, cocos2d::Color4F color)
{
    ensureCapacity(2);
    
    Color4B tColor = Color4B(color);
    V3F_C4B fromData = {from, tColor};
    V3F_C4B toData = {to, tColor};
    
    V3F_C4B* storePosition = _buffer +_bufferCount;
    storePosition[0] = fromData;
    storePosition[1] = toData;
    
    _bufferCount += 2;
    _dirty = true;
}

void DrawNode3D::drawLine(cocos2d::Vec3 from, cocos2d::Vec3 to)
{
    drawLine(from, to, __defaultColor);
}

void DrawNode3D::drawCubicBezier(std::vector<cocos2d::Vec3>& routePoints, float weight, float precision, cocos2d::Color4F color)
{
    int pointNumber = routePoints.size();
    
    std::vector<cocos2d::Vec3> controlPoints;
    
    for(int i = 0; i < pointNumber; i++)
    {
        int index_back = (pointNumber + i - 1) % pointNumber;
        int index_forward = (i + 1) % pointNumber;
        Vec3 mid_back = (routePoints[index_back] + routePoints[i]) / 2;
        Vec3 mid_forward = (routePoints[index_forward] + routePoints[i]) / 2;
        float dist_back = routePoints[index_back].distance(routePoints[i]);
        float dist_forward = routePoints[index_forward].distance(routePoints[i]);
        Vec3 control_point_back = (mid_back - mid_forward) * dist_back * weight / (dist_back + dist_forward) + routePoints[i];
        Vec3 control_point_forward = (mid_forward - mid_back) * dist_forward * weight / (dist_back + dist_forward) + routePoints[i];
        
        controlPoints.push_back(control_point_back);
        controlPoints.push_back(control_point_forward);
        
//        drawLine(routePoints[index_back], routePoints[i], color);
//        drawLine(control_point_back, control_point_forward, color);
    }
    
    for(int i = 0; i < pointNumber - 1; i ++)
    {
        Vec3& p0 = routePoints[i];
        Vec3& p1 = controlPoints[(i * 2 + 1) % (pointNumber * 2)];
        Vec3& p2 = controlPoints[(i * 2 + 2) % (pointNumber * 2)];
        Vec3& p3 = routePoints[(i + 1) % pointNumber];
        
        Vec3 a = -1 * p0 + 3 * p1 - 3 * p2 + p3;
        Vec3 b =  3 * p0 - 6 * p1 + 3 * p2;
        Vec3 c = -3 * p0 + 3 * p1;
        Vec3 d =      p0;
        
        Vec3 da = -3 * p0 +  9 * p1 - 9 * p2 + 3 * p3;
        Vec3 db =  6 * p0 - 12 * p1 + 6 * p2;
        Vec3 dc = -3 * p0 +  3 * p1;
        
        float t = 0.0;
        
        do {
            
            float t0 = t;
            float t1 = t = t + precision / (t * t * da + t * db + dc).length();
            t1 = t = t > 1 ? 1 : t ;
            
            Vec3 from = t0 * t0 * t0 * a + t0 * t0 * b + t0 * c + d;
            Vec3 to = t1 * t1 * t1 * a + t1 * t1 * b + t1 * c + d;
            
            drawLine(from, to, color);
            
        }while(t != 1);
        
    }
}

void DrawNode3D::drawCubicBezier(std::vector<cocos2d::Vec3>& routePoints, float weight, float precision)
{
    drawCubicBezier(routePoints, weight, precision, __defaultColor);
}

void DrawNode3D::drawObb(cocos2d::OBB& obb, cocos2d::Color4F color)
{
    Vec3& center = obb._center;
    Vec3& vx = obb._extentX;
    Vec3& vy = obb._extentY;
    Vec3& vz = obb._extentZ;
    
    drawLine(center + vx + vy + vz, center - vx + vy + vz, color);
    drawLine(center + vx - vy + vz, center - vx - vy + vz, color);
    drawLine(center + vx + vy + vz, center + vx - vy + vz, color);
    drawLine(center - vx + vy + vz, center - vx - vy + vz, color);
    
    drawLine(center + vx + vy - vz, center - vx + vy - vz, color);
    drawLine(center + vx - vy - vz, center - vx - vy - vz, color);
    drawLine(center + vx + vy - vz, center + vx - vy - vz, color);
    drawLine(center - vx + vy - vz, center - vx - vy - vz, color);
    
    drawLine(center + vx + vy + vz, center + vx + vy - vz, color);
    drawLine(center - vx - vy + vz, center - vx - vy - vz, color);
    drawLine(center + vx - vy + vz, center + vx - vy - vz, color);
    drawLine(center - vx + vy + vz, center - vx + vy - vz, color);
}

void DrawNode3D::drawObb(cocos2d::OBB& obb)
{
    drawObb(obb, __defaultColor);
}

void DrawNode3D::applyDefaultColor()
{
    for(int i = 0; i < _bufferCount; i++)
    {
        V3F_C4B* storePosition = _buffer + i;
        storePosition[0].colors = Color4B(__defaultColor);
        storePosition[1].colors = Color4B(__defaultColor);
    }
    
    _dirty = true;
}

void DrawNode3D::setDefaultColor(cocos2d::Color4F color)
{
    __defaultColor = color;
}

cocos2d::Color4F DrawNode3D::getDefaultColor(cocos2d::Color4F color)
{
    return __defaultColor;
}

void DrawNode3D::drawHighOrderBezier(std::vector<cocos2d::Vec3>& controlPoints, float precision, cocos2d::Color4F color)
{
    
}

void DrawNode3D::clear()
{
    _bufferCount = 0;
    _dirty = true;
}

void DrawNode3D::ensureCapacity(int count)
{
    if(_bufferCount + count > _bufferCapacity)
    {
        _bufferCapacity += MAX(_bufferCapacity, count);
        _buffer = (V3F_C4B*)realloc(_buffer, _bufferCapacity * sizeof(V3F_C4B));
    }
}

