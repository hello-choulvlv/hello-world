//
//  FishConfig.hpp
//  BoneTest
//
//  Created by charlie on 2017/8/11.
//
//

#ifndef FishConfig_hpp
#define FishConfig_hpp

#include <stdio.h>

class FishConfig {
    
public:
    
    typedef struct {
        
        int type;
        std::vector<int> _nestedID;
        float from;
        float to;
        float scale;
        std::string modelName;
        
    }FishVisual;
    
public:
    static FishConfig* getInstance();
private:
    static FishConfig* __instance;
    
    
public:
    void loadConfigFile();
    FishVisual* getVisualConfigByFishId(int fishId);
    
private:
    void loadFishConfig();
    void loadFishVisualConfig();
    
private:
    std::map<int, int> _fishConfigs;
    std::map<int, FishVisual> _fishVisualConfigs;
    
};

#endif /* FishConfig_hpp */
