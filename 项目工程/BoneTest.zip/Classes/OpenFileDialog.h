//
//  OpenFileDialog.h
//  BoneTest
//
//  Created by charlie on 2017/7/20.
//
//

#ifndef OpenFileDialog_h
#define OpenFileDialog_h


class OpenFileDialog
{
public:
    OpenFileDialog();
    ~OpenFileDialog();
    
public:
    void open();
    std::string getSelectedFileName();
    
private:
    void* _cocoaDialog;
    std::string _selectedFile;
};

#endif /* OpenFileDialog_h */
