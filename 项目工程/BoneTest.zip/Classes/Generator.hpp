//
//  Generator.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#ifndef Generator_hpp
#define Generator_hpp

#include "TroopSetManager.h"

class Group;

class Generator
{
public:
    Generator();
    void setConfig(GeneratorConfig& config);
    void update(float dt);
    void setGroup(Group* group);
    
private:
    void doSpawn(float timeOverflow, int spawnIndex);
    void generateTypes();
    void generateFish(SpawnElement& config, float timeOverflow, int spawnIndex);
    void generateGroup(SpawnElement& config, float timeOverflow, int spawnIndex);
    
private:
    GeneratorConfig _config;
    Group* _group;
    float _delayTimer;
    float _spawnTimer;
    float _spawnCount;
    float _generateId;
    int _spawnCircle;
};

#endif /* Generator_hpp */
