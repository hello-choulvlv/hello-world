//
//  NavigatorCircle.hpp
//  BoneTest
//
//  Created by charlie on 2017/6/30.
//
//

#ifndef NavigatorCircle_hpp
#define NavigatorCircle_hpp

#include <Navigator.hpp>

class NavigatorCircle: public Navigator
{
public:
    static NavigatorCircle* create(float radius, cocos2d::Vec3 center, cocos2d::Vec3 axis);
    bool init(float radius, cocos2d::Vec3 center, cocos2d::Vec3 axis);
    
public:
    virtual void update(float dt);
    
private:
    cocos2d::Vec3 calculatePosition(float rotation, float radius, cocos2d::Vec3 center);
    cocos2d::Vec3 calculateDirection(float rotation, float radius, cocos2d::Vec3 center);
    
private:
    float _radius;
    cocos2d::Vec3 _axisA;
    cocos2d::Vec3 _axisB;
    cocos2d::Vec3 _axisC;
    cocos2d::Vec3 _center;
    cocos2d::Vec3 _lastPosition;
    cocos2d::Vec3 _lastDirection;
    float _currentRotation;
    float _deltaR;
    float _deltaH;
    float _angularSpeed;
    float _linearSpeed;
    float _precision;
    float _lastOverflow;
    
};

#endif /* NavigatorCircle_hpp */
