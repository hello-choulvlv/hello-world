//
//  GameDebugger.cpp
//  BoneTest
//
//  Created by charlie on 2017/4/5.
//
//

#include "GameDebugger.hpp"

#include "CollisionManager.hpp"

using namespace cocos2d;

GameDebugger* GameDebugger::__sInstance = nullptr;

GameDebugger* GameDebugger::getInstance()
{
    if(__sInstance == nullptr)
    {
        __sInstance = new GameDebugger();
    }
    
    return __sInstance;
}

void GameDebugger::debugCollisionManager()
{
    SimpleCollisionManager* manager = static_cast<SimpleCollisionManager*>(CollisionManager::getInstance());
    
    for(int regionIndex = 0; regionIndex < manager->CONST._regionX * manager->CONST._regionY; regionIndex++)
    {
        std::vector<SimpleCollisionManager::TransformedShapeInfo*>& shapes = manager->_divisions[regionIndex][SimpleCollisionManager::COLLISION_AREA_TYPE::FISH];
            
        for(int shapeIndex = 0; shapeIndex < shapes.size(); shapeIndex++)
        {
            SimpleCollisionManager::TransformedShapeInfo* shape = shapes[shapeIndex];
            SimpleCollisionManager::ShapeProjected& pj = shape->first;
            SimpleCollisionManager::MinMax& aabb = shape->second;
            
            __drawNode->drawLine(pj._vertex[0], pj._vertex[1], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[1], pj._vertex[2], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[2], pj._vertex[3], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[3], pj._vertex[0], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[4], pj._vertex[5], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[5], pj._vertex[6], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[6], pj._vertex[7], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[7], pj._vertex[4], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[0], pj._vertex[4], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[1], pj._vertex[5], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[2], pj._vertex[6], Color4F(1.0, 0.0, 0.0, 1.0));
            __drawNode->drawLine(pj._vertex[3], pj._vertex[7], Color4F(1.0, 0.0, 0.0, 1.0));
            
            __drawNode->drawLine(Vec2(aabb._minX, aabb._minY), Vec2(aabb._maxX, aabb._minY), Color4F(0.0, 0.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(aabb._maxX, aabb._minY), Vec2(aabb._maxX, aabb._maxY), Color4F(0.0, 0.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(aabb._maxX, aabb._maxY), Vec2(aabb._minX, aabb._maxY), Color4F(0.0, 0.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(aabb._minX, aabb._maxY), Vec2(aabb._minX, aabb._minY), Color4F(0.0, 0.0, 1.0, 1.0));
            
            int regionY = regionIndex / manager->CONST._regionX;
            int regionX = regionIndex % manager->CONST._regionX;
            float minX = regionX * manager->CONST._regionSize;
            float minY = regionY * manager->CONST._regionSize;
            float maxX = minX + manager->CONST._regionSize;
            float maxY = minY + manager->CONST._regionSize;
            
            __drawNode->drawLine(Vec2(minX, minY), Vec2(maxX, minY), Color4F(0.0, 1.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(maxX, minY), Vec2(maxX, maxY), Color4F(0.0, 1.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(maxX, maxY), Vec2(minX, maxY), Color4F(0.0, 1.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(minX, maxY), Vec2(minX, minY), Color4F(0.0, 1.0, 1.0, 1.0));
        }
        
        std::vector<SimpleCollisionManager::TransformedShapeInfo*>& bullets = manager->_divisions[regionIndex][SimpleCollisionManager::COLLISION_AREA_TYPE::BULLET];
        
        for(int shapeIndex = 0; shapeIndex < bullets.size(); shapeIndex++)
        {
            SimpleCollisionManager::TransformedShapeInfo* shape = bullets[shapeIndex];
            SimpleCollisionManager::ShapeProjected& pj = shape->first;
            SimpleCollisionManager::MinMax& aabb = shape->second;
            
            __drawNode->drawCircle(pj._vertex[0], pj._vertex[1].x, 360, 32, false, 1.0, 1.0, Color4F(1.0, 1.0, 0.0, 1.0));
            
            __drawNode->drawLine(Vec2(aabb._minX, aabb._minY), Vec2(aabb._maxX, aabb._minY), Color4F(0.0, 0.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(aabb._maxX, aabb._minY), Vec2(aabb._maxX, aabb._maxY), Color4F(0.0, 0.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(aabb._maxX, aabb._maxY), Vec2(aabb._minX, aabb._maxY), Color4F(0.0, 0.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(aabb._minX, aabb._maxY), Vec2(aabb._minX, aabb._minY), Color4F(0.0, 0.0, 1.0, 1.0));
            
            int regionY = regionIndex / manager->CONST._regionX;
            int regionX = regionIndex % manager->CONST._regionX;
            float minX = regionX * manager->CONST._regionSize;
            float minY = regionY * manager->CONST._regionSize;
            float maxX = minX + manager->CONST._regionSize;
            float maxY = minY + manager->CONST._regionSize;
            
            __drawNode->drawLine(Vec2(minX, minY), Vec2(maxX, minY), Color4F(0.0, 1.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(maxX, minY), Vec2(maxX, maxY), Color4F(0.0, 1.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(maxX, maxY), Vec2(minX, maxY), Color4F(0.0, 1.0, 1.0, 1.0));
            __drawNode->drawLine(Vec2(minX, maxY), Vec2(minX, minY), Color4F(0.0, 1.0, 1.0, 1.0));
        }
    }
}

void GameDebugger::initWithScene(cocos2d::Scene *scene)
{
    __scene = scene;
    __drawNode = DrawNode::create();
    scene->addChild(__drawNode, 99);
}

void GameDebugger::update(float dt)
{
    __drawNode->clear();
    
    debugCollisionManager();
}
