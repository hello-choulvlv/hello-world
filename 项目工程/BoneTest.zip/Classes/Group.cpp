//
//  Group.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/6.
//
//

#include "Group.hpp"
#include "Generator.hpp"
#include "MoveComponent.hpp"

Group::Group():
_moveComponent(nullptr),
_transformAction(nullptr),
_localTransformUpdated(false),
_parentTransformUpdated(false),
_transformCalculated(true),
_calculatedTransform(cocos2d::Mat4::IDENTITY),
_localTransform(cocos2d::Mat4::IDENTITY),
_parentTransform(cocos2d::Mat4::IDENTITY),
_timeElapsed(0),
_type(0),
_updateFlag(false)
{
    
}

Group::~Group()
{
    delete _transformAction;
    delete _moveComponent;
    
    for(int i = 0; i <_generators.size(); i++)
    {
        delete _generators[i];
    }
}

void Group::setId(int id)
{
    _id = id;
}

int Group::getId()
{
    return _id;
}

void Group::setConfig(GroupConfig& config)
{
    _type = config.id;
    
    if(config.transform)
    {
        _transformAction = config.transform->clone();
        _transformAction->setTarget(&_transformResult);
    }
    
    for(int i = 0; i < config.generator.size(); i++)
    {
        Generator* generator = new Generator();
        generator->setConfig(config.generator[i]);
        generator->setGroup(this);
        _generators.push_back(generator);
    }
}

void Group::enterGroup()
{
    _parentTransformUpdated = true;
}

void Group::setMoveComponent(MoveComponent* moveComponent)
{
    _moveComponent = moveComponent;
}

void Group::update(float dt)
{
    if(not getUpdateFlag())
    {
        _timeElapsed = _timeElapsed + dt;
        
        updateTransform(dt);
        updateGenerator(dt);
        
        setUpdateFlag(true);
    }
}

void Group::updateTransform(float dt)
{
    _transformCalculated = false;
    
    bool transformUpdated = false;
    
    if(_transformAction)
    {
        _transformAction->update(_timeElapsed);
        transformUpdated = true;
    }
    
    if(_moveComponent)
    {
        _moveComponent->update(_timeElapsed);
        transformUpdated = true;
    }
    
    if(!_localTransformUpdated && transformUpdated)
    {
        _localTransformUpdated = true;
        notifyMembers();
    }
}

void Group::updateGenerator(float dt)
{
    for(int i = 0; i < _generators.size(); i++)
    {
        _generators[i]->update(dt);
    }
}

void Group::buildTransformWithParam(cocos2d::Vec3 translation, cocos2d::Vec3 direction, float roll, float scale, cocos2d::Mat4& transform)
{
    float length = sqrtf(direction.x * direction.x + direction.z * direction.z);

    cocos2d::Quaternion rotY;
    cocos2d::Quaternion rotZ;
    
    if(length == 0)
    {
        rotY = cocos2d::Quaternion(cocos2d::Vec3(0, 1, 0), 0);
        
        if(direction.y == 0)
        {
            rotZ = cocos2d::Quaternion(cocos2d::Vec3(0, 0, 1), 0);
        }
        else
        {
            rotZ = cocos2d::Quaternion(cocos2d::Vec3(0, 0, 1), -M_PI_2);
        }
    }
    else
    {
        rotY = cocos2d::Quaternion(cocos2d::Vec3(0, 1, 0), atan2f(-direction.z, direction.x));
        rotZ = cocos2d::Quaternion(cocos2d::Vec3(0, 0, 1), atanf(direction.y / length));
    }
    
    cocos2d::Quaternion rotX = cocos2d::Quaternion(cocos2d::Vec3(1, 0, 0), roll * M_PI / 180);
    
    transform.translate(translation);
    transform.rotate(rotY * rotZ * rotX);

    transform.m[0]  *= scale;
    transform.m[1]  *= scale;
    transform.m[2]  *= scale;
    transform.m[4]  *= scale;
    transform.m[5]  *= scale;
    transform.m[6]  *= scale;
    transform.m[8]  *= scale;
    transform.m[9]  *= scale;
    transform.m[10] *= scale;
}

void Group::notifyMembers()
{
    for(auto iter = _members.begin(); iter != _members.end(); iter++)
    {
        Group* memeber = (Group*)*iter;
        memeber->_parentTransformUpdated = true;
        memeber->notifyMembers();
    }
}

void Group::setParentTransform(cocos2d::Mat4 transform)
{
    _parentTransform = transform;
    _parentTransformUpdated = true;
}

MoveComponent* Group::getMoveComponent()
{
    return _moveComponent;
}

cocos2d::Mat4 Group::getTransform()
{
    if(!_transformCalculated)
    {
        if(_localTransformUpdated)
        {
            cocos2d::Mat4 pathTransform = cocos2d::Mat4::IDENTITY;
            cocos2d::Mat4 actionTransform = cocos2d::Mat4::IDENTITY;
            
            if(_moveComponent)
            {
                cocos2d::Vec3 currentPosition = cocos2d::Vec3(0, 0, 0);
                cocos2d::Vec3 currentDirection = cocos2d::Vec3(0, 0, 0);
                
                _moveComponent->retrieveState(currentPosition, currentDirection);
                
                buildTransformWithParam(currentPosition, currentDirection, 0.0, 1.0, pathTransform);
            }
            
            if(_transformAction)
            {
                buildTransformWithParam(_transformResult.targetPosition,
                                        _transformResult.targetDirection,
                                        _transformResult.targetRoll,
                                        _transformResult.targetScale,
                                        actionTransform);
            }
            
            _localTransform = actionTransform * pathTransform;
        }
        
        if(_parentTransformUpdated && _group)
            _parentTransform = ((Group*)_group)->getTransform();
        
        if(_localTransformUpdated || _parentTransformUpdated)
            _calculatedTransform = _parentTransform * _localTransform;
        
        _localTransformUpdated = false;
        _parentTransformUpdated = false;
        _transformCalculated = true;
    }
    
    return _calculatedTransform;
}

float Group::getLifetime()
{
    return _timeElapsed;
}

bool Group::getUpdateFlag()
{
    return _updateFlag;
}

void Group::setUpdateFlag(bool flag)
{
    _updateFlag = flag;
}
