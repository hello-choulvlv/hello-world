//
//  MoveComponentBezier.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef MoveComponentBezier_hpp
#define MoveComponentBezier_hpp

#include "MoveComponent.hpp"

class CubicBezierRoute;

class MoveComponentBezier : public MoveComponent
{
public:
    MoveComponentBezier();
    virtual ~MoveComponentBezier();
    virtual void retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection);
    void setBezierRoute(CubicBezierRoute* _route);
    void setOffset(cocos2d::Vec3 offset);
    
private:
    CubicBezierRoute* _route;
    cocos2d::Vec3 _offset;
};

#endif /* MoveComponentBezier_hpp */
