//
//  TouchCollision.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/12.
//
//

#ifndef TouchCollision_hpp
#define TouchCollision_hpp

#include "cocos2d.h"

class TouchCollision : public cocos2d::Node
{
public:
    static TouchCollision* create();
    virtual ~TouchCollision();
    void addObb(cocos2d::OBB obb);
    std::vector<cocos2d::OBB>& getObbs();
    void getTransformedObbs(std::vector<cocos2d::OBB>& out);
    bool touchHit(cocos2d::Vec2 touchPosition);
    
private:
    std::vector<cocos2d::OBB> _obbs;
};

#endif /* TouchCollision_hpp */
