//
//  PathManager.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef PathManager_hpp
#define PathManager_hpp

class PathManager
{
public:
    static PathManager* getInstance();
private:
    static PathManager* _instance;
    
public:
    void loadPath(std::string pathFileName);
};

#endif /* PathManager_hpp */
