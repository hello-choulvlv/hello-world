//
//  CheckNormal.cpp
//  BoneTest
//
//  Created by charlie on 2017/4/20.
//
//

#include "CheckNormal.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <dirent.h>
#include <string>
#include "cocos2d.h"

using namespace cocos2d;

void CheckNormal::check()
{
    std::string root = "/Users/charlie/Workspace/BoneTest/Resources/3d/";
    
    DIR* pRoot;
    struct dirent *pDirent;
    
    pRoot = opendir(root.c_str());
    
    if(pRoot)
    {
        while ((pDirent = readdir(pRoot)) != NULL) {
            
            std::string modelFullPath = root;
            modelFullPath.append(pDirent->d_name);
            modelFullPath.append("/");
            modelFullPath.append(pDirent->d_name);
            modelFullPath.append(".c3b");
            
            
            Sprite3D* model = Sprite3D::create(modelFullPath);
            
            if(model)
            {
                Mesh* mesh = model->getMesh();
                if(mesh->hasVertexAttrib(GLProgram::VERTEX_ATTRIB_NORMAL))
                {
                    printf("Model: %s | Normal : true\n", pDirent->d_name);
                }
                else
                {
                    printf("Model: %s | Normal : false\n", pDirent->d_name);
                }
            }

        }
    }
}
