//
//  Fish.hpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#ifndef Fish_hpp
#define Fish_hpp

#include "Group.hpp"

class Fish : public Group
{
public:
    Fish();
    virtual ~Fish() {};
    virtual cocos2d::Mat4 getTransform();
    
private:
    cocos2d::Vec3 _currentPosition;
    cocos2d::Vec3 _currentDirection;
};

#endif /* Fish_hpp */
