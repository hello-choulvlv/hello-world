//
//  MoveComponent.cpp
//  BoneTest
//
//  Created by charlie on 2017/7/7.
//
//

#include "MoveComponent.hpp"

MoveComponent::MoveComponent():
_speed(0),
_end(false),
_timeElapsed(0)
{
    
}

MoveComponent::~MoveComponent()
{
    
}

void MoveComponent::setSpeed(float speed)
{
    _speed = speed;
}

void MoveComponent::update(float dt)
{
    _timeElapsed = dt;
    _distance = _timeElapsed * _speed;
}

void MoveComponent::retrieveState(cocos2d::Vec3& currentPosition, cocos2d::Vec3& currentDirection)
{
    
}

bool MoveComponent::ended()
{
    return _end;
}
