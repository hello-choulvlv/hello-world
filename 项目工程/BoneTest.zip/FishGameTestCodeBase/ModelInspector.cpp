//
//  ModelInspector.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/9.
//
//

#include "ModelInspector.hpp"

using namespace cocos2d;

ModelInspector* ModelInspector::create()
{
    ModelInspector* pRet = new ModelInspector();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

bool ModelInspector::init()
{
    Node::init();
    
    _representationWidth = 320;
    _division = 25;
    _offsetToAngleScale = 0.08;
    _xOffset = 0;
    _yOffset = 0;
    _distanceOffset = 0;
    _ctrlPressed = false;
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    
    _axisPresentation = DrawNode3D::create();
    _axisPresentation->setPosition(Vec2(100, Director::getInstance()->getVisibleSize().height - 200));
    _axisPresentation->drawLine(Vec3(0, 0, 0), Vec3(0, 0, 60), Color4F(0.0, 0.0, 1.0, 1.0));
    _axisPresentation->drawLine(Vec3(0, 0, 0), Vec3(0, 60, 0), Color4F(0.0, 1.0, 0.0, 1.0));
    _axisPresentation->drawLine(Vec3(0, 0, 0), Vec3(60, 0, 0), Color4F(1.0, 0.0, 0.0, 1.0));

    this->Node::addChild(_axisPresentation);

    _rotator = Node::create();
    _rotator->setPosition(visibleSize / 2 + Size(0,  - visibleSize.height * _representationWidth / visibleSize.width / 2));
    this->Node::addChild(_rotator);
    
    DrawNode3D* bottomGrid = DrawNode3D::create();
    
    for(int index = 0; index < _division + 1; index++)
    {
        bottomGrid->drawLine(Vec3(-_representationWidth / 2 + index * _representationWidth / _division, 0, -_representationWidth / 2 + 0),
                             Vec3(-_representationWidth / 2 + index * _representationWidth / _division + 0, 0, _representationWidth / 2 + 0),
                             Color4F(0.3, 0.3, 0.3, 0.6));
        
        bottomGrid->drawLine(Vec3(-_representationWidth / 2, 0, -_representationWidth / 2 + index * _representationWidth / _division),
                             Vec3(_representationWidth / 2, 0, -_representationWidth / 2 + index * _representationWidth / _division),
                             Color4F(0.3, 0.3, 0.3, 0.6));
    }
    
    bottomGrid->setName("plane");
    _rotator->addChild(bottomGrid);
    
    DrawNode3D* viewPlane = DrawNode3D::create();
    
    viewPlane->drawLine(Vec3(-_representationWidth / 2, 0, 0),
                         Vec3(-_representationWidth / 2, visibleSize.height * _representationWidth / visibleSize.width, 0),
                         Color4F(0.0, 0.3, 0.0, 0.6));
    
    viewPlane->drawLine(Vec3(-_representationWidth / 2, visibleSize.height * _representationWidth / visibleSize.width, 0),
                         Vec3(_representationWidth / 2, visibleSize.height * _representationWidth / visibleSize.width, 0),
                         Color4F(0.0, 0.3, 0.0, 0.6));
    
    viewPlane->drawLine(Vec3(_representationWidth / 2, visibleSize.height * _representationWidth / visibleSize.width, 0),
                         Vec3(_representationWidth / 2, 0, 0),
                         Color4F(0.0, 0.3, 0.0, 0.6));
    
    viewPlane->drawLine(Vec3(_representationWidth / 2, 0, 0),
                         Vec3(-_representationWidth / 2, 0, 0),
                         Color4F(0.0, 0.3, 0.0, 1.0));
    
    viewPlane->drawLine(Vec3(_representationWidth / 2, 0, _representationWidth / 2),
                        Vec3(_representationWidth / 2, 0, -_representationWidth / 2),
                        Color4F(0.0, 0.3, 0.0, 1.0));
    
    viewPlane->setName("view");
    
    _rotator->addChild(viewPlane);
    
    return true;
}

void ModelInspector::rotateNodeBy(float xOffset, float yOffset, cocos2d::Node *node)
{
    float angleX = xOffset * _offsetToAngleScale;
    float angleY = -yOffset * _offsetToAngleScale;
    
    Mat4 rotateYInv;
    Mat4 rotateY;
    Mat4 rotateA;
    Mat4::createRotation(Vec3(0, 1, 0), CC_DEGREES_TO_RADIANS(angleX), &rotateY);
    Mat4::createRotation(Vec3(0, 1, 0), CC_DEGREES_TO_RADIANS(-angleX), &rotateYInv);
    Vec3 axis = rotateYInv * Vec3(1, 0, 0);
    Mat4::createRotation(axis, CC_DEGREES_TO_RADIANS(angleY), &rotateA);
    Quaternion quat;
    (rotateY * rotateA).getRotation(&quat);
    
    
    node->setRotationQuat(quat);
}

bool ModelInspector::onTouchesBegan(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event *event)
{
    for(int i = 0; i < touches.size(); i++)
    {
        saveTouchData(touches[i]);
    }
    
    return true;
}

void ModelInspector::onTouchesMoved(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event *event)
{
    if(_touchData.size() == 1)
    {
        Vec2 touchOffset = touches[0]->getLocation() - getTouchData(touches[0]->getID());
        
        if(_ctrlPressed)
        {
            moveNodeBy(touchOffset, _rotator);
        }
        else
        {
            _xOffset = _xOffset + touchOffset.x;
            _yOffset = _yOffset + touchOffset.y;
            
            rotateNodeBy(_xOffset, _yOffset, _axisPresentation);
            rotateNodeBy(_xOffset, _yOffset, _rotator);
        }
        
        saveTouchData(touches[0]);
    }
    else
    {
        float originalDist = _touchData.begin()->second.distance((++_touchData.begin())->second);
        
        for(int i = 0; i < touches.size(); i++)
        {
            saveTouchData(touches[i]);
        }
        
        float currentDist = _touchData.begin()->second.distance((++_touchData.begin())->second);
        
        float distanceOffset = currentDist - originalDist;
        
        scaleNodeBy(distanceOffset, _rotator);
    }
}

void ModelInspector::onTouchesEnded(const std::vector<cocos2d::Touch*>& touches, cocos2d::Event *event)
{
    for(int i = 0; i < touches.size(); i++)
    {
        removeTouchData(touches[i]->getID());
    }
}

void ModelInspector::onMouseScroll(cocos2d::EventMouse* event)
{
     scaleNodeBy(event->getScrollY() * 1000 / 50, _rotator);
}

void ModelInspector::onKeyPressed(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event)
{
    if (keyCode == EventKeyboard::KeyCode::KEY_CTRL)
    {
        _ctrlPressed = true;
    }
}

void ModelInspector::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event)
{
    if (keyCode == EventKeyboard::KeyCode::KEY_CTRL)
    {
        _ctrlPressed = false;
    }
}

void ModelInspector::onEnter()
{
    Node::onEnter();
    
    // Touch Event Listener
    auto listener = EventListenerTouchAllAtOnce::create();
    
    listener->onTouchesBegan = CC_CALLBACK_2(ModelInspector::onTouchesBegan, this);
    listener->onTouchesMoved = CC_CALLBACK_2(ModelInspector::onTouchesMoved, this);
    listener->onTouchesEnded = CC_CALLBACK_2(ModelInspector::onTouchesEnded, this);
    listener->onTouchesCancelled = CC_CALLBACK_2(ModelInspector::onTouchesEnded, this);
    
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
    _touchListener = listener;
    
    // Mouse Event Listener
    auto mouseListener = EventListenerMouse::create();
    mouseListener->onMouseScroll = CC_CALLBACK_1(ModelInspector::onMouseScroll, this);
    
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(mouseListener, this);
    _mouseListener = mouseListener;
    
    // Keyboard Event Listener
    auto keyboardListener = EventListenerKeyboard::create();
    keyboardListener->onKeyPressed = CC_CALLBACK_2(ModelInspector::onKeyPressed, this);
    keyboardListener->onKeyReleased = CC_CALLBACK_2(ModelInspector::onKeyReleased, this);
    
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(keyboardListener, this);
    _keyboardListener = keyboardListener;
}

void ModelInspector::onExit()
{
    Node::onExit();
    
    this->getEventDispatcher()->removeEventListener(_touchListener);
    this->getEventDispatcher()->removeEventListener(_mouseListener);
    this->getEventDispatcher()->removeEventListener(_keyboardListener);
}

void ModelInspector::append(Node* child, int localZOrder, const std::string &name)
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
    float scale = _representationWidth / visibleSize.width;
    
    Node* container = Node::create();
    container->setScale(scale);
    container->addChild(child);
    container->setPosition(Vec2(-_representationWidth / 2, 0));
    
    _rotator->addChild(container, localZOrder, name);
}

void ModelInspector::scaleNodeBy(float distanceOffset, cocos2d::Node *node)
{
    _distanceOffset = _distanceOffset + distanceOffset;
    
    _rotator->setScale(1.0 + _distanceOffset / 1000);
}

void ModelInspector::moveNodeBy(cocos2d::Vec2 directionOffset, cocos2d::Node* node)
{
    node->setPosition(node->getPosition() + directionOffset);
}

void ModelInspector::saveTouchData(cocos2d::Touch* touch)
{
    int id = touch->getID();
    
    for(auto iter = _touchData.begin(); iter != _touchData.end(); iter++)
    {
        if(iter->first == id)
        {
            iter->second = touch->getLocation();
            return;
        }
    }
    
    _touchData.push_back(std::pair<int, Vec2>(touch->getID(), touch->getLocation()));
}

void ModelInspector::removeTouchData(int id)
{
    for(auto iter = _touchData.begin(); iter != _touchData.end(); iter++)
    {
        if(iter->first == id)
        {
            _touchData.erase(iter);
            return;
        }
    }
}

cocos2d::Vec2 ModelInspector::getTouchData(int id)
{
    for(auto iter = _touchData.begin(); iter != _touchData.end(); iter++)
    {
        if(iter->first == id)
        {
            return iter->second;
        }
    }
    
    return Vec2(0, 0);
}

cocos2d::Mat4 ModelInspector::getTransform()
{
    return _rotator->getNodeToParentTransform();
}

void ModelInspector::showPlane(bool willShow)
{
    _rotator->getChildByName("plane")->setVisible(willShow);
}
