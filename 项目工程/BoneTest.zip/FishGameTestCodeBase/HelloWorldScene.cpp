#include "HelloWorldScene.h"
#include "WaterNode.hpp"
#include "DrawNode3D.hpp"
#include "ModelInspector.hpp"
#include "GlobalValue.hpp"
#include "Navigator.hpp"
#include "RouteReader.hpp"
#include "ObbTest.hpp"
#include "CollisionArea.hpp"
#include "PausableAction.hpp"
#include "ActionController.hpp"
#include "CollisionAreaEditor.hpp"
#include "TextFieldEx.hpp"
#include "VecEditor.hpp"
#include "ui/CocosGUI.h"
#include "RctEditor.hpp"
#include "CollisionManager.hpp"
#include "CollisionTest.hpp"
#include "GameDebugger.hpp"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();
    // return the scene
    return nullptr;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    Scene* scene = Scene::create();
    
//    Director::getInstance()->setDisplayStats(false);
    Director::getInstance()->setProjection(cocos2d::Director::Projection::_3D);
    Director::getInstance()->getOpenGLView()->setFrameSize(1136, 640);
    Director::getInstance()->getOpenGLView()->setDesignResolutionSize(2272, 1280, ResolutionPolicy::NO_BORDER);
    
//    Director::getInstance()->getOpenGLView()->setDesignResolutionSize(1136, 640, ResolutionPolicy::NO_BORDER);
//    Director::getInstance()->getOpenGLView()->setViewPortInPoints(-568, -320, 568, 320);
    Camera* cam = Camera::getDefaultCamera();
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
//    sprite = Sprite3D::create("shayu.c3t");
//    sprite->setPosition(Vec2(visibleSize.width / 2 - 200, visibleSize.height / 2));
//    sprite->setScale(0.15);
//    sprite->setRotation3D(Vec3(0, 0, 0));
//    sprite->setGlobalZOrder(0);
//    sprite->setTexture("test/shayu_0.jpg");
//    this->addChild(sprite);
//    
//    Sprite3D* sprite2 = Sprite3D::create("shayu.c3t");
//    sprite2->setPosition(Vec2(visibleSize.width / 2 + 100, visibleSize.height / 2));
//    sprite2->setScale(0.15);
//    sprite2->setRotation3D(Vec3(0, 0, 0));
//    sprite2->setGlobalZOrder(1);
//    sprite2->setTexture("test/shayu_1.jpg");
//    this->addChild(sprite2);
//
//    Sprite3D* sprite3 = Sprite3D::create("shayu.c3t");
//    sprite3->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2 - 150));
//    sprite3->setScale(0.15);
//    sprite3->setRotation3D(Vec3(0, 0, 0));
//    sprite3->setGlobalZOrder(2);
//    sprite3->setTexture("test/shayu_3.jpg");
//    this->addChild(sprite3);
    
    
    
//
//    MoveBy* move = MoveBy::create(2.0, Vec2(400, 0));
//    Sequence* seq = Sequence::create(move, move->reverse(), NULL);
//    RepeatForever* rep = RepeatForever::create(seq);
//    sprite2->runAction(rep);
    
//    std::vector<Sprite3D*> sharkSprites;
//    
//    for(int i = 0; i < 20; i++)
//    {
//        for(int j = 0; j < 5; j++)
//        {
//            char str[128];
//            sprintf(str, "test/shayu_%d.c3t", i);
//            Sprite3D* sprite = Sprite3D::create(str);
//            sprintf(str, "test/shayu_%d.jpg", i);
//            sprite->setTexture(str);
//            sprite->setPosition(visibleSize / 2);
//            sprite->setScale(0.12);
//            sprite->setRotation3D(Vec3(0, 0, 0));
//            this->addChild(sprite);
//            
//            sprintf(str, "test/shayu_%d.c3t", i);
//            auto animation = Animation3D::create(str);
//            sprite->runAction(RepeatForever::create(Animate3D::create(animation, 0.0f, 0.9f)));
//            sprite->runAction(RepeatForever::create(Sequence::create(ScaleTo::create(0.5, 0.15), ScaleTo::create(0.5, 0.12), NULL)));
//            
//            MoveBy* move = MoveBy::create(3.0, Point(450 * cos(i * 5 + j * 360 / 100), 250 * sin(i * 5 + j * 360 / 100)));
//            Sequence* seq = Sequence::create(move, move->reverse(), NULL);
//            sprite->runAction(RepeatForever::create(seq));
//            
//            sprite->runAction(RepeatForever::create(RotateBy::create(5, Vec3(360, 0, 0))));
//        }
//    }
//

    
//    Director::getInstance()->setProjection(cocos2d::Director::Projection::)
    
//    ModelInspector* inspector = ModelInspector::create();
//    this->addChild(inspector);
//
//    DrawNode3D* drawNode = DrawNode3D::create();
//    std::vector<Vec3> points = {
//        
//        Vec3(-50, 150, -340),
//        Vec3(300, 250, 200),
//        Vec3(700, 900, -350),
//        Vec3(1000, 300, 200),
//        
//    };
//    drawNode->drawCubicBezier(points, 1.0, 5, Color4F(1.0, 0.0, 0.0, 1.0));
//    inspector->append(drawNode);
//
//        sprite = Sprite3D::create("shayu.c3t");
//        sprite->setPosition(Vec2(visibleSize.width / 2 - 200, visibleSize.height / 2));
//        sprite->setScale(0.15);
//        sprite->setRotation3D(Vec3(0, 0, 0));
//        sprite->setGlobalZOrder(1);
//        sprite->setTexture("test/shayu_0.jpg");
//        inspector->append(sprite);
    
    
//    sprite = Sprite3D::create("shayu.c3t");
//    sprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
//    sprite->setScale(0.15);
//    sprite->setRotation3D(Vec3(0, 0, 0));
//    sprite->setAnchorPoint(Vec2(0.9, 0.5));
//    inspector->append(sprite);
//
//    sprite = Sprite3D::create("shayu.c3t");
//    sprite->setPosition(Vec2(visibleSize.width / 2 - 200, visibleSize.height / 2 + 200));
//    sprite->setScale(0.15);
//    sprite->setRotation3D(Vec3(0, 0, 0));
//    sprite->setGlobalZOrder(1);
//    sprite->setTexture("test/shayu_0.jpg");
//    inspector->append(sprite);
//    
//    sprite = Sprite3D::create("shayu.c3t");
//    sprite->setPosition(Vec2(visibleSize.width / 2 - 200, visibleSize.height / 2 - 400));
//    sprite->setScale(0.15);
//    sprite->setRotation3D(Vec3(0, 0, 0));
//    sprite->setGlobalZOrder(1);
//    sprite->setTexture("test/shayu_0.jpg");
//    inspector->append(sprite);
//    this->addChild(sprite);
    
//    auto animation = Animation3D::create("shayu.c3t");
    
//    Animate3D* swim = Animate3D::createWithFrames(animation, 300, 490, 30);
//    
//    Sequence*	pSequence = Sequence::create(swim,NULL);
//    RepeatForever* rep = RepeatForever::create(pSequence);
//    PauseabelAction* pause = PauseabelAction::create(rep);
//    pause->setTag(0);
//    sprite->runAction(pause);
//
//    
//    Navigator* nav = Navigator::create();
//    sprite->addChild(nav);
//    nav->start();
//
//    RouteReader* reader = RouteReader::getInstance();
//    RouteReader::RouteInfo* info = reader->read("line.c3t");
//
//    
//    DrawNode3D* line = DrawNode3D::create();
//    
//    std::vector<Vec3>& vertices = (*info)["Line001"];
//    
//    for(int i = 0; i < vertices.size() - 1; i++)
//    {
//        line->drawLine(vertices[i], vertices[i + 1], Color4F(1.0, 0, 0, 1.0));
//    }
//    
//    inspector->append(line);
//    
//    drawNodes.resize(this->sprite->getSkeleton()->getBoneCount());
//    
//    for(int i = 1; i < drawNodes.size(); i++)
//    {
//        DrawNode* node = DrawNode::create();
//        this->addChild(node, 10);
//        drawNodes[i] = node;
//    }
//    
//    this->getScheduler()->schedule([this](float){
//        
//        MeshSkin* skin = sprite->getSkin();
//        Skeleton3D* skeleton = sprite->getSkeleton();
//        
//        ssize_t boneCount = skeleton->getBoneCount();
//        
//        for(int i = 1; i < boneCount; i++)
//        {
//            Bone3D* bone = skeleton->getBoneByIndex(i);
//            const Mat4& boneModelMat = bone->getWorldMat();
//            const Mat4& boneBindMat = skin->getInvBindPose(bone);
//            Mat4 boneFinalMat;
//            Mat4::multiply(boneModelMat, boneBindMat, &boneFinalMat);
//            Vec3 boneModelPosition = Vec3(boneModelMat.m[12], boneModelMat.m[13], boneModelMat.m[14]);
//            const Mat4& spriteWorldMat = this->sprite->getNodeToWorldTransform();
//            
//            spriteWorldMat.transformPoint(&boneModelPosition);
//            
//            DrawNode* node = this->drawNodes[i];
//            node->clear();
//            node->setPosition3D(boneModelPosition);
//            node->drawSolidCircle(Vec2(0, 0), 8, 360, 36, 1.0, 1.0, Color4F(1.0, 0.0, 0.0, 1.0));
//        }
//        
//    }, this, 0, CC_REPEAT_FOREVER, false, false, "draw_skeleton");
    
//    ObbTest* testNode = ObbTest::create();
//    this->addChild(testNode);
    
//    std::map<std::string, cocos2d::OBB> areaConfig;
    
//    {
//        OBB obb = OBB(AABB(Vec3(-400, -150, -50), Vec3(400, 150, 50)));
//        
//        Vec3 translate = Vec3(200, 0, 0);
//        
//        Quaternion rotate_x = Quaternion(Vec3(1, 0, 0), CC_DEGREES_TO_RADIANS(-25));
//        Quaternion rotate_y = Quaternion(Vec3(0, 1, 0), CC_DEGREES_TO_RADIANS(0));
//        Quaternion rotate_z = Quaternion(Vec3(1, 0, 0), CC_DEGREES_TO_RADIANS(5));
//        Quaternion rotate = rotate_x * rotate_y * rotate_z;
//        
//        Mat4 transform;
//        transform.translate(translate);
//        transform.rotate(rotate);
//        obb.transform(transform);
//        
//        areaConfig["B_chibang_r"] = obb;
//    }
    
//    {
//        OBB obb = OBB(AABB(Vec3(-150, -100, -50), Vec3(150, 100, 50)));
//        
//        Vec3 translate = Vec3(50, 0, 0);
//        
//        Quaternion rotate_x = Quaternion(Vec3(1, 0, 0), CC_DEGREES_TO_RADIANS(-15));
//        Quaternion rotate_y = Quaternion(Vec3(0, 1, 0), CC_DEGREES_TO_RADIANS(0));
//        Quaternion rotate_z = Quaternion(Vec3(0, 0, 1), CC_DEGREES_TO_RADIANS(-15));
//        Quaternion rotate = rotate_x * rotate_y * rotate_z;
//        
//        Mat4 transform;
//        transform.translate(translate);
//        transform.rotate(rotate);
//        obb.transform(transform);
//        
//        areaConfig["Bone026"] = obb;
//    }
//    
//    CollisionArea* ca = CollisionArea::create();
//    ca->retain();
//    ca->bindToSkeleton(sprite->getSkeleton());
//    ca->loadConfig(areaConfig);
//    
//    sprite->addChild(ca);
//    
//    
//    std::vector<DrawNode3D*> vObbDraw;
//    
//    for(int i = 0 ; i < areaConfig.size(); i++)
//    {
//        DrawNode3D* obbDraw = DrawNode3D::create();
//        obbDraw->setProjectionMode(Director::Projection::_2D);
//        this->addChild(obbDraw);
//        
//        vObbDraw.push_back(obbDraw);
//    }
//    
//    DrawNode3D* obbDraw = DrawNode3D::create();
//    obbDraw->setProjectionMode(Director::Projection::_2D);
//    this->addChild(obbDraw);
//    
//    this->schedule([this, vObbDraw, ca](float){
//        
//        std::vector<OBB*> obbs = ca->getObbs();
//        
//        for(int i = 0; i < obbs.size(); i++)
//        {
//            vObbDraw[i]->clear();
//            vObbDraw[i]->drawObb(*obbs[i], Color4F(1.0, 0.0, 0.0, 1.0));
//        }
//        
//    }, "draw");
//    
//    
//    ActionController* controller = ActionController::create();
//    controller->setTarget(sprite);
//    controller->setAction(pSequence);
//    this->addChild(controller);
    
    
//    Vector<MenuItem*> items;
//    
//    for(int i = 0; i < 6; i++)
//    {
//        MenuItemFrameLabel* item = MenuItemFrameLabel::create();
//        item->setActivateCallback([i](){
//            
//            printf("%d", i);
//            
//        });
//        item->setContentSize(Size(190, 60));
//        items.pushBack(item);
//    }
//    
//    Menu* menu = Menu::createWithArray(items);
//    menu->setPosition(Vec2(0, 0));
//    menu->alignItemsVerticallyWithPadding(12);
//    menu->setPosition(Vec2(0, 0));
//    this->addChild(menu);
//    
//    menu->setPosition(Vec2(1136, 640));
    
    
//    ui::Widget* widget = ui::Widget::create();
//    widget->addChild(menu);
//    widget->setContentSize(Size(190, 70));
//    
//    ui::ListView* listView = ui::ListView::create();
//    listView->setDirection(cocos2d::ui::ScrollView::Direction::VERTICAL);
//    listView->setGravity(cocos2d::ui::ListView::Gravity::CENTER_HORIZONTAL);
//    listView->setPosition(Vec2(568, 320));
//    listView->setContentSize(Size(250, 300));
//    listView->pushBackCustomItem(widget);
//    listView->setClippingEnabled(true);
//    listView->setBackGroundColorType(cocos2d::ui::Layout::BackGroundColorType::GRADIENT);
//    listView->setBackGroundColor(Color3B(30, 30, 30), Color3B(0, 0, 0));
//    listView->setItemsMargin(15);
//    listView->doLayout();
//    
//    this->addChild(listView);
//    this->addChild(menu);
    
//    sprite = Sprite3D::create("shayu.c3t");
//    sprite->setPosition(Vec2(visibleSize.width / 2, 0));
//    sprite->setScale(0.8);
//    sprite->setRotation3D(Vec3(0, 0, 0));

//    
//    CollisionShape::R r;
//    CollisionShape::Shape shape(r);
    
//    ui::TextField* text = ui::TextField::create();
//    text->setPosition(visibleSize / 2);
//    this->addChild(text);
    
//    TextFieldEx* text = TextFieldEx::create();
//    text->setPosition(Vec2(300, 200));
//    this->addChild(text);
//
//    VecEditor* vecEditor = VecEditor::create();
//    vecEditor->setPosition(Vec2(500, 500));
//    this->addChild(vecEditor);
    
//    RctEditor* rct = RctEditor::create();
//    this->addChild(rct);
    
//    Vec3 *testP = new Vec3();
//    
//    this->getScheduler()->schedule([testP, this](float dt){
//        
//        for(int i = 0; i < 10000; i++)
//        {
//            Vec3 c = Vec3(rand() / 1.0, rand() / 1.0, rand() / 1.0);
//            Mat4 transform = this->getNodeToWorldTransform();
//            transform.transformPoint(&c);
//            *testP = c;
//        }
//        
//    }, this, 0, CC_REPEAT_FOREVER, 0, false, "t");
    
//    CollisionTest* test = CollisionTest::create();
//    this->addChild(test);
   
//    CollisionAreaEditor* editor = CollisionAreaEditor::create();
//    editor->setData("shayu");
//    this->addChild(editor);
    
    CollisionManager* manager = CollisionManager::getInstance();
    
    ModelInspector* inspector = ModelInspector::create();
    inspector->showPlane(false);
    this->addChild(inspector);
    
    Sprite3D* sprite = Sprite3D::create("3d/shayu/shayu.c3b");
    sprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    sprite->setScale(0.15);
    sprite->setRotation3D(Vec3(0, 0, 0));
    sprite->setAnchorPoint(Vec2(0.9, 0.5));
    inspector->append(sprite);
    
    Sprite3D* bullet = Sprite3D::create();
    bullet->setPosition(Vec2(300, 300));
    this->addChild(bullet);
    
    auto animation = Animation3D::create("3d/shayu/shayu.c3b");
    sprite->runAction(RepeatForever::create(Animate3D::create(animation, 0.0f, 100.9f)));
    
    CollisionManager::CollisionArea* areaFish = manager->claimCollisionArea("shayu");
    areaFish->bind(sprite);
    manager->registerArea(areaFish);
    
    CollisionManager::CollisionArea* areaBullet = manager->claimCollisionArea("bullet_100");
    areaBullet->bind(bullet);
    manager->registerArea(areaBullet);
    
    GameDebugger* debugger = GameDebugger::getInstance();
    debugger->initWithScene(scene);
    
    this->getScheduler()->schedule([](float dt){
        
        CollisionManager::getInstance()->update(dt);
        GameDebugger::getInstance()->update(dt);
        
    }, this, 0, CC_REPEAT_FOREVER, 0, false, "collision_update");

    
    scene->addChild(this);
    Director::getInstance()->runWithScene(scene);
    
    return true;
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}
