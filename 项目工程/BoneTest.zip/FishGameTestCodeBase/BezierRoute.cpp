//
//  BezierRoute.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/10.
//
//

#include "BezierRoute.hpp"

using namespace cocos2d;

BezierRoute::BezierRoute() :
_points(std::vector<Vec3>()),
_position(0),
_valueCache(Vec3(0, 0, 0)),
_tangentCache(Vec3(0, 0, 0))
{}

void BezierRoute::addPoints(std::vector<cocos2d::Vec3>& points)
{
    _points.insert(_points.end(), points.begin(), points.end());
    buildParameters();
}

cocos2d::Vec3 BezierRoute::getDirection(float t)
{
    return caculateValue(t);
}

cocos2d::Vec3 BezierRoute::getLocation(float t)
{
    return caculateTangent(t);
}

cocos2d::Vec3 BezierRoute::getCurrentDirection()
{
    return _tangentCache;
}

cocos2d::Vec3 BezierRoute::getCurrentLocation()
{
    return _valueCache;
}

void BezierRoute::advanceTo(float t)
{
    t = t < 0 ? 0 : t;
    t = t > 1 ? 1 : t;
    
    _position = t;
    
    _valueCache = caculateValue(_position);
    _tangentCache = caculateTangent(_position);
}

void BezierRoute::advanceBy(float deltaDist)
{
    advanceTo(getPositionByDeltaDistance(deltaDist));
}

CubicBezierRoute::CubicBezierRoute() :
BezierRoute(),
_controlPoints(std::vector<cocos2d::Vec3>()),
_caculatedParameters(std::vector<CaculatedParameter>()),
_currentStartIndex(0),
_weight(1.0),
_precision(5.0)
{
    
}

CubicBezierRoute* CubicBezierRoute::create()
{
    CubicBezierRoute* pRet = new CubicBezierRoute();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

void CubicBezierRoute::setWeight(float weight)
{
    _weight = weight;
}

void CubicBezierRoute::buildParameters()
{
    int pointNumber = _points.size();
    
    for(int i = 0; i < pointNumber; i++)
    {
        int index_back = (pointNumber + i - 1) % pointNumber;
        int index_forward = (i + 1) % pointNumber;
        Vec3 mid_back = (_points[index_back] + _points[i]) / 2;
        Vec3 mid_forward = (_points[index_forward] + _points[i]) / 2;
        float dist_back = _points[index_back].distance(_points[i]);
        float dist_forward = _points[index_forward].distance(_points[i]);
        Vec3 control_point_back = (mid_back - mid_forward) * dist_back * _weight / (dist_back + dist_forward) + _points[i];
        Vec3 control_point_forward = (mid_forward - mid_back) * dist_forward * _weight / (dist_back + dist_forward) + _points[i];
        
        _controlPoints.push_back(control_point_back);
        _controlPoints.push_back(control_point_forward);
    }
    
    for(int i = 0; i < pointNumber; i ++)
    {
        Vec3& p0 = _points[i];
        Vec3& p1 = _controlPoints[(i * 2 + 1) % (pointNumber * 2)];
        Vec3& p2 = _controlPoints[(i * 2 + 2) % (pointNumber * 2)];
        Vec3& p3 = _points[(i + 1) % pointNumber];
        
        CaculatedParameter param;
        
        param.a = -1 * p0 + 3 * p1 - 3 * p2 + p3;
        param.b =  3 * p0 - 6 * p1 + 3 * p2;
        param.c = -3 * p0 + 3 * p1;
        param.d =      p0;
        
        param.da = -3 * p0 +  9 * p1 - 9 * p2 + 3 * p3;
        param.db =  6 * p0 - 12 * p1 + 6 * p2;
        param.dc = -3 * p0 +  3 * p1;
        
        _caculatedParameters.push_back(param);
    }
}

cocos2d::Vec3 CubicBezierRoute::caculateTangent(float position)
{
    if(_points.size() > 0)
    {
        CaculatedParameter& param = _caculatedParameters[_currentStartIndex];
        
        return _position * _position * param.da + _position * param.db + param.dc;
    }
    else
    {
        return Vec3(0, 0, 0);
    }
}

cocos2d::Vec3 CubicBezierRoute::caculateValue(float position)
{
    if(_points.size() > 0)
    {
        CaculatedParameter& param = _caculatedParameters[_currentStartIndex];
        
        return _position * _position * _position * param.a + _position * _position * param.b + _position * param.c + param.d;
    }
    else
    {
        return Vec3(0, 0, 0);
    }
}

float CubicBezierRoute::getPositionByDeltaDistance(float deltaDistance)
{
    float newPosition = _position;
    
    while (deltaDistance > 0) {
        
        float delta = deltaDistance < _precision ? deltaDistance : _precision;
        float length = getCurrentDirection().length();
        length = length > 0 ? length : 0.0000000001f;
        
        newPosition = newPosition + delta / length;
        
        while(newPosition >= 1)
        {
            newPosition = newPosition - 1;
            _currentStartIndex = (_currentStartIndex + 1) % _points.size();
        }
        
        deltaDistance = deltaDistance - delta;
        
    }
    
    return newPosition;
}

void CubicBezierRoute::reset()
{
    _position = 0;
    _currentStartIndex = 0;
    _valueCache = caculateValue(_position);
    _tangentCache = caculateValue(_position);
}

void CubicBezierRoute::clear()
{
    _points.clear();
    _controlPoints.clear();
    _caculatedParameters.clear();
    _position = 0;
    _valueCache = Vec3(0, 0, 0);
    _tangentCache = Vec3(0, 0, 0);
    _currentStartIndex = 0;
}
