//
//  BezierRoute.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/10.
//
//

#ifndef BezierRoute_hpp
#define BezierRoute_hpp

#include "cocos2d.h"
#include "RouteProtocol.hpp"


class BezierRoute : public cocos2d::Node, public RouteProtocol
{
public:
    BezierRoute();
    virtual ~BezierRoute() {};
    
public:
    virtual void addPoints(std::vector<cocos2d::Vec3>& points) override;
    virtual cocos2d::Vec3 getDirection(float t) override;
    virtual cocos2d::Vec3 getLocation(float t) override;
    virtual cocos2d::Vec3 getCurrentDirection() override;
    virtual cocos2d::Vec3 getCurrentLocation() override;
    virtual void advanceTo(float t) override;
    virtual void advanceBy(float deltaDist) override;
    
protected:
    virtual void buildParameters() = 0;
    virtual cocos2d::Vec3 caculateTangent(float position) = 0;
    virtual cocos2d::Vec3 caculateValue(float position) = 0;
    virtual float getPositionByDeltaDistance(float deltaDistance) = 0;
    
protected:
    float _position;
    cocos2d::Vec3 _valueCache;
    cocos2d::Vec3 _tangentCache;
    std::vector<cocos2d::Vec3> _points;
};

class CubicBezierRoute : public BezierRoute
{
public:
    CubicBezierRoute();
    virtual ~CubicBezierRoute() {};
    static CubicBezierRoute* create();

public:
    void setWeight(float weight);
    void setPrecision(float precision);
    
public:
    virtual void reset() override;
    virtual void clear() override;
    
private:
    virtual void buildParameters() override;
    virtual cocos2d::Vec3 caculateTangent(float position) override;
    virtual cocos2d::Vec3 caculateValue(float position) override;
    virtual float getPositionByDeltaDistance(float deltaDistance) override;
    
private:
    struct CaculatedParameter
    {
        cocos2d::Vec3 a;
        cocos2d::Vec3 b;
        cocos2d::Vec3 c;
        cocos2d::Vec3 d;
        cocos2d::Vec3 da;
        cocos2d::Vec3 db;
        cocos2d::Vec3 dc;
    };
    
    std::vector<cocos2d::Vec3> _controlPoints;
    std::vector<CaculatedParameter> _caculatedParameters;
    int _currentStartIndex;
    float _weight;
    float _precision;
};

#endif /* BezierRoute_hpp */
