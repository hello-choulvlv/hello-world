//
//  CollisionAreaEditor.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/24.
//
//

#include "CollisionAreaEditor.hpp"
#include <string>
#include "DrawNode3D.hpp"
#include "ModelInspector.hpp"
#include "json/writer.h"
#include "json/prettywriter.h"
#include "json/stringbuffer.h"
#include "ActionController.hpp"


using namespace cocos2d;

MenuItemFrameLabel* MenuItemFrameLabel::create()
{
    MenuItemFrameLabel* pRet = new MenuItemFrameLabel();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

bool MenuItemFrameLabel::init()
{
    COLOR_ACTIVATED = {
        
        Color4F(0.0, 1.0, 0.0, 1.0),
        Color4F(0.0, 1.0, 0.0, 0.3),
        Color3B(255, 255, 255),
        
    },
    
    COLOR_DEACTIVATED = {
        
        Color4F(1.0, 0.0, 0.0, 1.0),
        Color4F(1.0, 0.0, 0.0, 0.3),
        Color3B(255, 255, 255),
        
    },
    
    COLOR_ACTIVATED_SELECTED = {
        
        Color4F(0.0, 0.7, 0.0, 1.0),
        Color4F(0.0, 0.7, 0.0, 0.2),
        Color3B(200, 200, 200),
        
    },
    
    COLOR_DEACTIVATED_SELECTED = {
        
        Color4F(0.7, 0.0, 0.0, 1.0),
        Color4F(0.7, 0.0, 0.0, 0.2),
        Color3B(200, 200, 200),
        
    },
    
    _enabled = true;
    __activated = false;
    __onActivate = [](){};
    __onDeactivate = [](){};
    __onLoseFocus = [](cocos2d::ui::Widget*, cocos2d::ui::Widget*){};
    __onGetFocus = [](cocos2d::ui::Widget*, cocos2d::ui::Widget*){};
    __clickToDeactivate = false;
    __type = TYPE::ACTIVATOR;
    
    __frame = DrawNode::create();
    this->addChild(__frame);
    
    __label = Label::createWithSystemFont("test", "", 24);
    this->addChild(__label);
    
    Widget::init(); // setContentSize is called from inside Widget::init , since setContentSize is overrided here , so the init call is delayed to ensure memebers in MenuItemFrameLabel are fully initialized;
    
    this->setContentSize(Size(150, 60));
    
    this->setTouchEnabled(true);
    
    return true;
}

void MenuItemFrameLabel::onEnter()
{
    Widget::onEnter();
    
    registerTouchEventListener();
    registerFocusEventListener();
}

void MenuItemFrameLabel::onExit()
{
    Widget::onExit();
}

void MenuItemFrameLabel::registerTouchEventListener()
{
    this->addTouchEventListener([this](Ref* sender, Widget::TouchEventType touchEventType){
        
        if(touchEventType == Widget::TouchEventType::BEGAN)
        {
            __moveAccumulator = 0;
            __moved = false;
            __lastTouchPosition = ((Widget*)sender)->getTouchBeganPosition();
            this->selected();
        }
        else if(touchEventType == Widget::TouchEventType::ENDED)
        {
            if(__moved)
            {
                this->unselected();
            }
            else
            {
                this->unselected();
                this->activate();
            }
        }
        else if(touchEventType == Widget::TouchEventType::CANCELED)
        {
            this->unselected();
        }
        else if(touchEventType == Widget::TouchEventType::MOVED)
        {
            Vec2 movePosition = ((Widget*)sender)->getTouchBeganPosition();
            Vec2 offset = movePosition - __lastTouchPosition;
            float delta = __moveAccumulator + offset.length();
            
            if(delta > 30)
            {
                __moved = true;
            }
            
            __lastTouchPosition = movePosition;
        }
        
    });
}

void MenuItemFrameLabel::setLoseFocusCallback(std::function<void (cocos2d::ui::Widget*, cocos2d::ui::Widget*)> onLoseFocus)
{
    __onLoseFocus = onLoseFocus;
}

void MenuItemFrameLabel::setGetFocusCallback(std::function<void (cocos2d::ui::Widget*, cocos2d::ui::Widget*)> onGetFocus)
{
    __onGetFocus = onGetFocus;
}

void MenuItemFrameLabel::registerFocusEventListener()
{
    EventListenerFocus* listener = EventListenerFocus::create();
    listener->onFocusChanged = CC_CALLBACK_2(MenuItemFrameLabel::onFocusChanged, this);
    
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
    __focusListener = listener;
}

void MenuItemFrameLabel::onFocusChanged(cocos2d::ui::Widget* loseFocus, cocos2d::ui::Widget* getFocus)
{
    if(loseFocus == this)
    {
        __onLoseFocus(this, getFocus);
    }
    else if(getFocus == this)
    {
        __onGetFocus(this, loseFocus);
    }
}

void MenuItemFrameLabel::activate()
{
    if(__type == TYPE::ACTIVATOR)
    {
        if(__activated)
        {
            if(__clickToDeactivate)
            {
                __activated = false;
                changeColor(COLOR_DEACTIVATED);
                __onDeactivate();
            }
            else
            {
                __activated = true;
                changeColor(COLOR_ACTIVATED);
                __onActivate();
            }
        }
        else
        {
            __activated = true;
            changeColor(COLOR_ACTIVATED);
            __onActivate();
        }
    }
    else if(__type == TYPE::TRIGGER)
    {
        __onActivate();
    }
}

void MenuItemFrameLabel::deactivate()
{
    if(__type == TYPE::ACTIVATOR)
    {
        if(__activated)
        {
            __activated = false;
            changeColor(COLOR_DEACTIVATED);
            __onDeactivate();
        }
    }
}

void MenuItemFrameLabel::selected()
{
    if(__activated)
    {
        changeColor(COLOR_ACTIVATED_SELECTED);
    }
    else
    {
        changeColor(COLOR_DEACTIVATED_SELECTED);
    }
}

void MenuItemFrameLabel::setContentSize(const cocos2d::Size& contentSize)
{
    Widget::setContentSize(contentSize);
    
    if(__activated)
    {
        changeColor(COLOR_ACTIVATED);
    }
    else
    {
        changeColor(COLOR_DEACTIVATED);
    }
    
    __label->setPosition(getContentSize() / 2);
}

void MenuItemFrameLabel::unselected()
{
    if(__activated)
    {
        changeColor(COLOR_ACTIVATED);
    }
    else
    {
        changeColor(COLOR_DEACTIVATED);
    }
}

void MenuItemFrameLabel::setActivateCallback(std::function<void ()> onActivate)
{
    __onActivate = onActivate;
}

void MenuItemFrameLabel::setDeactivateCallback(std::function<void ()> onDeactivate)
{
    __onDeactivate = onDeactivate;
}

void MenuItemFrameLabel::setString(std::string str)
{
    __label->setString(str);
}

std::string MenuItemFrameLabel::getString()
{
    return __label->getString();
}

void MenuItemFrameLabel::changeColor(COLOR_SCHEME& strategy)
{
    __label->setColor(strategy._colorLabel);
    
    __frame->clear();
    __frame->drawSolidRect(Vec2(0, 0), this->getContentSize(), strategy._colorBackground);
    __frame->drawRect(Vec2(0, 0), this->getContentSize(), strategy._colorFrame);
}

void MenuItemFrameLabel::clickToDeactivate(bool willDo)
{
    __clickToDeactivate = willDo;
}

void MenuItemFrameLabel::setFontSize(int fontSize)
{
    __label->setSystemFontSize(fontSize);
}

void  MenuItemFrameLabel::setType( MenuItemFrameLabel::TYPE type)
{
    __type = type;
    __activated = false;
}

EditorUI* EditorUI::create()
{
    EditorUI* pRet = new EditorUI();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

EditorUI::EditorUI() :
NORMAL_SIZE(220, 60)
,DETAILED_SIZE(220, 100)
,__selectedBoneIndex(-1)
,__selectedBindingIndex(-1)
,__onSelectBone([](int){})
,__onSelectBinding([](int, int){})
,__onAddBinding([](int){})
,__onRemoveBinding([](int, int){})
,__onValueChange([](int, int, SINGLE_BINDING&){})
{
    
}

EditorUI::~EditorUI()
{
    
}

bool EditorUI::init()
{
    __listViewBone = ui::ListView::create();
    __listViewBone->setDirection(cocos2d::ui::ScrollView::Direction::VERTICAL);
    __listViewBone->setGravity(cocos2d::ui::ListView::Gravity::CENTER_HORIZONTAL);
    __listViewBone->setPosition(Vec2(2272 - 300, 1280 - 1260));
    __listViewBone->setContentSize(Size(280, 1240));
    __listViewBone->setClippingEnabled(true);
    __listViewBone->setBackGroundColorType(cocos2d::ui::Layout::BackGroundColorType::GRADIENT);
    __listViewBone->setBackGroundColor(Color3B(50, 50, 50), Color3B(0, 0, 0));
    __listViewBone->setItemsMargin(15);
    
    this->addChild(__listViewBone, 1);
    
    __listViewBinding = ui::ListView::create();
    __listViewBinding->setDirection(cocos2d::ui::ScrollView::Direction::VERTICAL);
    __listViewBinding->setGravity(cocos2d::ui::ListView::Gravity::CENTER_HORIZONTAL);
    __listViewBinding->setPosition(Vec2(2272 - 570, 1280 - 660));
    __listViewBinding->setContentSize(Size(250, 640));
    __listViewBinding->setClippingEnabled(true);
    __listViewBinding->setBackGroundColorType(cocos2d::ui::Layout::BackGroundColorType::GRADIENT);
    __listViewBinding->setBackGroundColor(Color3B(30, 30, 30), Color3B(0, 0, 0));
    __listViewBinding->setItemsMargin(15);
    __listViewBinding->setVisible(false);
    
    this->addChild(__listViewBinding, 2);
    
    ui::Widget* backboard = ui::Widget::create();
    backboard->setTouchEnabled(true);
    backboard->setSwallowTouches(false);
    backboard->setContentSize(Director::getInstance()->getVisibleSize());
    backboard->setPosition(Director::getInstance()->getVisibleSize() / 2);
    this->addChild(backboard, 0);
    
    __rctEditor = RctEditor::create();
    __rctEditor->setVisible(false);
    __rctEditor->setValueChangeCallback(CC_CALLBACK_1(EditorUI::onRctEditorValueChange, this));
    this->addChild(__rctEditor);
    
    __selectedBoneIndex = -1;
    __selectedBindingIndex = -1;
    
    __onSelectBone = [](int){};
    __onSelectBinding = [](int, int){};
    __onAddBinding = [](int){};
    __onRemoveBinding = [](int, int){};
    __onValueChange = [](int, int, SINGLE_BINDING&){};
    
    return true;
}

MenuItemFrameLabel* EditorUI::createBoneItem(std::string name, int index)
{
    MenuItemFrameLabel* item = createItem();
    item->setString(name);
    
    item->setActivateCallback([this, index](){
    
        if(__selectedBoneIndex != index)
        {
            unselectBone();
        }
        
        selectBone(index);
        
    });
    
    item->setLoseFocusCallback([this](ui::Widget* self, ui::Widget* getter){
        
        if(!focusInsideList(getter, __listViewBinding))
        {
            showBindings(false);
        }
        
    });
    
    return item;
}

MenuItemFrameLabel* EditorUI::createBindingItem(int boneIndex, int bindingIndex, SINGLE_BINDING::TYPE type)
{
    std::string typeStr = type == SINGLE_BINDING::TYPE::HEX ? "H" : "R";
    
    MenuItemFrameLabel* item = createItem();
    item->setString("Binding_" + std::to_string(bindingIndex) + "(" + typeStr + ")");
    item->setActivateCallback([boneIndex, bindingIndex, this](){
        
        if(__selectedBindingIndex != bindingIndex)
        {
            unselectBinding();
            selectBinding(boneIndex, bindingIndex);
        }
        
    });
    item->setLoseFocusCallback([this](ui::Widget* self, ui::Widget* getter){
        
        if(!focusInsideList(getter, __listViewBinding))
        {
            showBindings(false);
        }
        
    });
    return item;
    
}

cocos2d::ui::Widget* EditorUI::createAddItem(int boneIndex)
{
    ui::Widget* item = ui::Widget::create();
    item->setContentSize(Size(220, 60));
    
    MenuItemFrameLabel* add = createItem();
    add->setString("+");
    add->setFontSize(48);
    add->setType(MenuItemFrameLabel::TYPE::TRIGGER);
    add->setContentSize(Size(150, 60));
    add->setPosition(Vec2(75, 30));
    add->setActivateCallback([boneIndex, this](){
        
        unselectBinding();
        this->__onAddBinding(boneIndex);
        
    });
    item->addChild(add);
    
    MenuItemFrameLabel* remove = createItem();
    remove->setString("-");
    remove->setFontSize(48);
    remove->setType(MenuItemFrameLabel::TYPE::TRIGGER);
    remove->setContentSize(Size(60, 60));
    remove->setPosition(Vec2(220 - 30, 30));
    remove->setActivateCallback([boneIndex, this](){
        
        if(__selectedBindingIndex != -1)
        {
            int indexCache = __selectedBindingIndex;
            unselectBinding();
            this->__onRemoveBinding(boneIndex, indexCache);
        }
        
    });
    item->addChild(remove);
    
    return item;
}

MenuItemFrameLabel* EditorUI::createItem()
{
    MenuItemFrameLabel* menuItem = MenuItemFrameLabel::create();
    menuItem->setContentSize(NORMAL_SIZE);
    
    return menuItem;
}

cocos2d::ui::Widget* EditorUI::createMarginItem()
{
    ui::Widget* item = ui::Widget::create();
    item->setContentSize(Size(1, 0));
    return item;
}

void EditorUI::loadBones(cocos2d::Skeleton3D* skeleton)
{
    __listViewBone->removeAllItems();
    __listViewBone->pushBackCustomItem(createMarginItem());
    
    if(skeleton == nullptr)
    {
        printf("## EditorUI ## Skeleton does not exist !");
        return;
    }
    
    int boneNumber = skeleton->getBoneCount();
    
    for(int i = 0; i < boneNumber; i++)
    {
        Bone3D* bone = skeleton->getBoneByIndex(i);
        std::string boneName = truncateString(bone->getName());
        
        __listViewBone->pushBackCustomItem(createBoneItem(boneName, i));
    }
    
    __listViewBone->doLayout();
    
    __skeleton = skeleton;
}

void EditorUI::loadBindings(int boneIndex, std::vector<SINGLE_BINDING>& bindings)
{
    __listViewBinding->removeAllItems();
    __listViewBinding->pushBackCustomItem(createMarginItem());
    __listViewBinding->pushBackCustomItem(createAddItem(boneIndex));
    
    for(int i = 0; i < bindings.size(); i++)
    {
        __listViewBinding->pushBackCustomItem(createBindingItem(boneIndex, i, bindings[i].type));
    }
}


void EditorUI::loadValue(SINGLE_BINDING& binding)
{
    if(binding.type == SINGLE_BINDING::TYPE::RET)
    {
        __rctEditor->setVisible(true);
        __rctEditor->setRct(binding.r);
    }
    else
    {
        
    }
}

std::string EditorUI::truncateString(std::string original)
{
    if(original.size() > 15)
    {
        std::string truncated = original.substr(0, 11);
        truncated.append("...");
        return truncated;
    }
    else
    {
        return original;
    }
}

void EditorUI::selectBone(int boneIndex)
{
    if(__selectedBoneIndex != boneIndex)
    {
        __selectedBoneIndex = boneIndex;
        __onSelectBone(boneIndex);
    }

    showBindings(true);
    
    if(__selectedBindingIndex != -1)
    {
        ((MenuItemFrameLabel*)(__listViewBinding->getItem(__selectedBindingIndex + 2)))->activate();
    }
}

void EditorUI::unselectBone()
{
    if(__selectedBoneIndex != -1)
    {
        unselectBinding();
        
        ((MenuItemFrameLabel*)(__listViewBone->getItem(__selectedBoneIndex + 1)))->deactivate();
        __selectedBoneIndex = -1;
    }
}

void EditorUI::selectBinding(int boneIndex, int bindingIndex)
{
    if(__selectedBindingIndex != bindingIndex)
    {
        __selectedBindingIndex = bindingIndex;
        detailBoneItem(boneIndex, bindingIndex);
        __onSelectBinding(boneIndex, bindingIndex);
    }
}

void EditorUI::unselectBinding()
{
    if(__selectedBindingIndex != -1)
    {
        recoverBoneItem(__selectedBoneIndex);
        
        ((MenuItemFrameLabel*)(__listViewBinding->getItem(__selectedBindingIndex + 2)))->deactivate();
        __selectedBindingIndex = -1;
        
        __rctEditor->setVisible(false);
    }
}

bool EditorUI::focusInsideList(cocos2d::ui::Widget* widget, cocos2d::ui::ListView* list)
{
    if(widget == list)
    {
        return true;
    }
    
    auto items = list->getItems();
    
    for(int i = 0; i < items.size(); i++)
    {
        if(items.at(i) == widget)
        {
            return true;
        }
        else
        {
            auto children = items.at(i)->getChildren();
            
            for(int i = 0; i < children.size(); i++)
            {
                if(children.at(i) == widget)
                {
                    return true;
                }
            }
        }
    }
    
    return false;
}

bool EditorUI::focusOnItem(cocos2d::ui::Widget* widget, cocos2d::ui::ListView* list)
{
    auto items = list->getItems();
    
    for(int i = 0; i < items.size(); i++)
    {
        if(items.at(i) == widget)
        {
            return true;
        }
    }
    
    return false;
}

void EditorUI::showBindings(bool willShow)
{
    __listViewBinding->setVisible(willShow);
}

void EditorUI::setSelectBoneCallback(std::function<void (int)> onSelectBone)
{
    __onSelectBone = onSelectBone;
}

void EditorUI::setSelectBindingCallback(std::function<void (int, int)> onSelectBinding)
{
    __onSelectBinding = onSelectBinding;
}

void EditorUI::setAddBindingCallback(std::function<void (int)> onAddBinding)
{
    __onAddBinding = onAddBinding;
}

void EditorUI::setRemoveBindingCallback(std::function<void (int, int)> onRemoveBinding)
{
    __onRemoveBinding = onRemoveBinding;
}

void EditorUI::setValueChangeCallback(std::function<void (int, int, SINGLE_BINDING&)> onValueChange)
{
    __onValueChange = onValueChange;
}

std::vector<cocos2d::Vec2> EditorUI::getBoneItemPositions()
{
    std::vector<cocos2d::Vec2> pos;
    Vector<ui::Widget*>& items = __listViewBone->getItems();
    
    for(int i = 1; i < items.size(); i++)
    {
        ui::Widget* item = items.at(i);
        pos.push_back(item->getParent()->convertToWorldSpace(item->getPosition() - Vec2(120, 0)));
    }
    
    return pos;
}

void EditorUI::detailBoneItem(int boneIndex, int bindingIndex)
{
    MenuItemFrameLabel* binding = (MenuItemFrameLabel*)__listViewBinding->getItem(bindingIndex + 2);
    MenuItemFrameLabel* bone = (MenuItemFrameLabel*)__listViewBone->getItem(boneIndex + 1);
    std::string detail = binding->getString();
    std::string boneName = bone->getString();
    std::string withDetail = boneName + "\n" + detail;
    bone->setString(withDetail);
    bone->setContentSize(DETAILED_SIZE);
    
    rearrangeListView(__listViewBone);
}

void EditorUI::recoverBoneItem(int boneIndex)
{
    MenuItemFrameLabel* item = (MenuItemFrameLabel*)__listViewBone->getItem(boneIndex + 1);
    std::string withDetail = item->getString();
    std::string boneName = withDetail.substr(0, withDetail.find('\n'));
    item->setString(boneName);
    item->setContentSize(NORMAL_SIZE);
    __listViewBone->doLayout();
    
    rearrangeListView(__listViewBone);
}

void EditorUI::rearrangeListView(cocos2d::ui::ListView* listView)
{
    Vector<ui::Widget*> items = __listViewBone->getItems();
    Vec2 originalPosition = __listViewBone->getInnerContainer()->getPosition();
    Vec2 originalSize = __listViewBone->getInnerContainer()->getContentSize();
    retainItems(items);
    __listViewBone->removeAllItems();
    pushAndReleaseItems(items, __listViewBone);
    __listViewBone->doLayout();
    Vec2 currentSize = __listViewBone->getInnerContainer()->getContentSize();
    Vec2 currentPosition = originalPosition + originalSize - currentSize;
    __listViewBone->getInnerContainer()->setPosition(currentPosition);
}

void EditorUI::retainItems(cocos2d::Vector<cocos2d::ui::Widget*>& items)
{
    for(int i = 0; i < items.size(); i++)
    {
        items.at(i)->retain();
    }
}

void EditorUI::pushAndReleaseItems(Vector<ui::Widget*>& items, ui::ListView* listView)
{
    for(int i = 0; i < items.size(); i++)
    {
        listView->pushBackCustomItem(items.at(i));
        items.at(i)->release();
    }
}

void EditorUI::reset()
{
    __listViewBone->removeAllItems();
    __listViewBinding->removeAllItems();
    __selectedBoneIndex = -1;
    __selectedBindingIndex = -1;
}

void EditorUI::onRctEditorValueChange(Rct r)
{
    SINGLE_BINDING binding;
    binding.type = SINGLE_BINDING::TYPE::RET;
    binding.r = r;
    
    __onValueChange(__selectedBoneIndex, __selectedBindingIndex, binding);
}

BindingPresentor* BindingPresentor::create()
{
    BindingPresentor* pRet = new BindingPresentor();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

BindingPresentor::BindingPresentor() :
__boneConnDrawNodeTree(nullptr),
__boneIndexHighlight(-1),
__bindingIndexHighLigt(-1)
{
    NORMAL = {
        
        Color4F(0.6, 0, 0, 1.0),
        Color4F(0.9, 0, 0, 1.0),
        
    };
    
    RELATED = {
        
        Color4F(0.0, 0.0, 0.6, 1.0),
        Color4F(0.0, 0.0, 0.9, 1.0),
        
    };
    
    HIGHLIGHT = {
        
        Color4F(0.0, 0.6, 0.0, 1.0),
        Color4F(0.0, 0.9, 0.0, 1.0),
        
    };
}

BindingPresentor::~BindingPresentor()
{
    clear();
}

void BindingPresentor::setContent(cocos2d::Skeleton3D* skeleton, std::vector<std::vector<SINGLE_BINDING>>& bindings)
{
    clear();
    
    setSkeleton(skeleton);
    setBinding(bindings);
    
    updateWithSkeleton(skeleton);
}

void BindingPresentor::setSkeleton(cocos2d::Skeleton3D* skeleton)
{
    int boneCount = skeleton->getBoneCount();
    
    for(int index = 0; index < boneCount; index++)
    {
        OBB obb = OBB(AABB(Vec3(-30, -30, -30), Vec3(30, 30, 30)));
        DrawNode3D* node = DrawNode3D::create();
        node->drawObb(obb);
        this->addChild(node);
        setNodeColor(node, NORMAL._colorBone);
        
        __bonePositionDrawNodes.push_back(node);
        __boneTransform.push_back(skeleton->getBoneByIndex(index)->getWorldMat());
    }
    
    __boneTransform.resize(boneCount);
    __boneConnDrawNodeTree = drawBoneConnRecursively(skeleton->getRootBone(0), skeleton);

}

BindingPresentor::DRAW_NODE_TREE* BindingPresentor::drawBoneConnRecursively(Bone3D* bone, Skeleton3D* skeleton)
{
    DRAW_NODE_TREE* treeNode = new DRAW_NODE_TREE();
    treeNode->_index = skeleton->getBoneIndex(bone);
    
    int childrenCount = bone->getChildBoneCount();
    
    for(int index = 0; index < childrenCount; index++)
    {
        Bone3D* child = bone->getChildBoneByIndex(index);
        
        DrawNode3D* node = DrawNode3D::create();
        this->addChild(node);
        setNodeColor(node, NORMAL._colorBone);
        
        treeNode->_node.push_back(node);
        treeNode->_children.push_back(drawBoneConnRecursively(child, skeleton));
    }
    
    return treeNode;
}

void BindingPresentor::setBinding(std::vector<std::vector<SINGLE_BINDING>>& bindings)
{
    __bindingDrawNodes.resize(bindings.size());
    
    for(int boneIndex = 0; boneIndex < bindings.size(); boneIndex++)
    {
        std::vector<SINGLE_BINDING>& binding = bindings[boneIndex];

        for(int bindingIndex = 0; bindingIndex < binding.size(); bindingIndex++)
        {
            SINGLE_BINDING& bindingInfo = binding[bindingIndex];
            DrawNode3D* node;
                
            if(bindingInfo.type == SINGLE_BINDING::TYPE::HEX)
            {
                node = drawHex(bindingInfo);
                setNodeColor(node, NORMAL._colorBinding);
            }
            else
            {
                node = drawRct(bindingInfo);
                setNodeColor(node, NORMAL._colorBinding);
            }
            
            this->addChild(node);
            
            __bindingDrawNodes[boneIndex].push_back(node);
        }
    }
}

void BindingPresentor::clear()
{
    this->removeAllChildren();
    
    __boneTransform.clear();
    __bindingDrawNodes.clear();
    __bonePositionDrawNodes.clear();
    
    clearTreeRecursively(__boneConnDrawNodeTree);
    __boneConnDrawNodeTree = nullptr;
}

void BindingPresentor::clearTreeRecursively(BindingPresentor::DRAW_NODE_TREE *root)
{
    if(root != nullptr)
    {
        for(int i = 0; i < root->_children.size(); i++)
        {
            clearTreeRecursively(root->_children[i]);
        }
        
        delete root;
    }
}

DrawNode3D* BindingPresentor::drawRct(SINGLE_BINDING& binding, DrawNode3D* node)
{
    OBB obb;
    obb.set(binding.r.center, binding.r.axisX, binding.r.axisY, binding.r.axisZ, binding.r.extension);
    obb.transform(binding.buildTransformMat(binding.r.rotation, binding.r.scale, binding.r.translation));
    
    DrawNode3D* ret = (node == nullptr ? createBindingDrawNode() : node);
    ret->clear();
    ret->drawObb(obb);
    
    DrawNode3D* axis = (DrawNode3D*)(ret->getChildByName("axis"));
    axis->clear();
    axis->drawLine(obb._center, obb._center + obb._extentX, Color4F(Color4B(230, 230, 0, 255)));
    axis->drawLine(obb._center, obb._center + obb._extentY, Color4F(Color4B(0, 230, 230, 255)));
    axis->drawLine(obb._center, obb._center + obb._extentZ, Color4F(Color4B(230, 0, 230, 255)));
    
    return ret;
}

DrawNode3D* BindingPresentor::drawHex(SINGLE_BINDING& binding, DrawNode3D* node)
{
    return node == nullptr ? DrawNode3D::create() : node;
}

DrawNode3D* BindingPresentor::createBindingDrawNode()
{
    DrawNode3D* axis = DrawNode3D::create();
    axis->setName("axis");
    axis->setVisible(false);
    
    DrawNode3D* ret = DrawNode3D::create();
    ret->addChild(axis);
    
    return ret;
}

void BindingPresentor::addBinding(int boneIndex, SINGLE_BINDING& binding)
{
    if(isBoneAvailable(boneIndex))
    {
        DrawNode3D* node;
        
        if(binding.type == SINGLE_BINDING::TYPE::HEX)
        {
            node = drawHex(binding);
            setNodeColor(node, NORMAL._colorBinding);
        }
        else
        {
            node = drawRct(binding);
            setNodeColor(node, NORMAL._colorBinding);
        }
        
        this->addChild(node);
        
        node->setNodeToParentTransform(__boneTransform[boneIndex]);
        
        __bindingDrawNodes[boneIndex].push_back(node);
    }
}

void BindingPresentor::removeBinding(int boneIndex, int bindingIndex)
{
    if(isBindingAvailable(boneIndex, bindingIndex))
    {
        std::vector<DrawNode3D*>& vBinding = __bindingDrawNodes[boneIndex];
        
        int counter = 0;
        
        for(auto iter = vBinding.begin(); iter != vBinding.end(); iter++)
        {
            if(counter == bindingIndex)
            {
                (*iter)->removeFromParent();
                vBinding.erase(iter);
                break;
            }
            
            counter++;
            
        }
    }
}

void BindingPresentor::changeBinding(int boneIndex, int bindingIndex, SINGLE_BINDING& binding)
{
    if(isBindingAvailable(boneIndex, bindingIndex))
    {
        if(binding.type == SINGLE_BINDING::TYPE::HEX)
        {
            drawHex(binding, __bindingDrawNodes[boneIndex][bindingIndex]);
        }
        else
        {
            drawRct(binding, __bindingDrawNodes[boneIndex][bindingIndex]);
        }
    }
}

void BindingPresentor::emphasizeBone(int boneIndex)
{
    deemphasizeBone(__boneIndexHighlight);
    
    if(isBoneAvailable(boneIndex))
    {
        __boneIndexHighlight = boneIndex;
        setNodeColor(__bonePositionDrawNodes[boneIndex], HIGHLIGHT._colorBone);
        setBoneConnNodeColor(boneIndex, RELATED._colorBone);
        setBoneBindingColor(boneIndex, RELATED._colorBinding);
    }

}

void BindingPresentor::deemphasizeBone(int boneIndex)
{
    if(isBoneAvailable(boneIndex))
    {
        __boneIndexHighlight = -1;
        setNodeColor(__bonePositionDrawNodes[boneIndex], NORMAL._colorBone);
        setBoneConnNodeColor(boneIndex, NORMAL._colorBone);
        setBoneBindingColor(boneIndex, NORMAL._colorBinding);
    }
}

void BindingPresentor::emphasizeBinding(int boneIndex, int bindingIndex)
{
    deemphasizeBinding(__boneIndexHighlight, __bindingIndexHighLigt);
    
    if(isBindingAvailable(boneIndex, bindingIndex))
    {
        __bindingIndexHighLigt = bindingIndex;
        setNodeColor(__bindingDrawNodes[boneIndex][bindingIndex], HIGHLIGHT._colorBinding);
        __bindingDrawNodes[boneIndex][bindingIndex]->getChildByName("axis")->setVisible(true);
    }
}

void BindingPresentor::deemphasizeBinding(int boneIndex, int bindingIndex)
{
    if(isBindingAvailable(boneIndex, bindingIndex))
    {
        __bindingIndexHighLigt = -1;
        
        DrawNode3D* node = __bindingDrawNodes[boneIndex][bindingIndex];
        
        if(__boneIndexHighlight == boneIndex)
        {
            setNodeColor(node, RELATED._colorBinding);
        }
        else
        {
            setNodeColor(node, NORMAL._colorBinding);
        }
        
        __bindingDrawNodes[boneIndex][bindingIndex]->getChildByName("axis")->setVisible(false);
    }
}

std::vector<cocos2d::Vec2> BindingPresentor::getBoneDrawNodePositions()
{
    std::vector<Vec2> pos;
    
    for(int i = 0; i < __bonePositionDrawNodes.size(); i++)
    {
        Vec3 p3d = __bonePositionDrawNodes[i]->getPosition3D();
        Mat4 transform = __boneTransform[i];
        Mat4 nodet = __bonePositionDrawNodes[i]->getNodeToWorldTransform();
        nodet.transformPoint(&p3d);
        
        pos.push_back(Vec2(p3d.x, p3d.y));
    }
    
    return pos;
}

bool BindingPresentor::isBoneAvailable(int boneIndex)
{
    return (boneIndex > -1 && boneIndex < __bonePositionDrawNodes.size());
}

bool BindingPresentor::isBindingAvailable(int boneIndex, int bindingIndex)
{
    if(isBoneAvailable(boneIndex))
    {
        return (bindingIndex > -1 && bindingIndex < __bindingDrawNodes[boneIndex].size());
    }
    
    return false;
}

void BindingPresentor::setNodeColor(DrawNode3D* node, cocos2d::Color4F color)
{
    node->setDefaultColor(color);
    node->applyDefaultColor();
}

void BindingPresentor::setBoneConnNodeColor(int boneIndex, cocos2d::Color4F color)
{
    if(isBoneAvailable(boneIndex))
    {
        DRAW_NODE_TREE* treeNode = findTreeNodeByIndex(__boneConnDrawNodeTree, boneIndex);
        
        if(treeNode)
        {
            for(int i = 0; i < treeNode->_children.size(); i++)
            {
                setNodeColor(treeNode->_node[i], color);
                
                int childIndex = treeNode->_children[i]->_index;
                setNodeColor(__bonePositionDrawNodes[childIndex], color);
            }
        }
    }
}

void BindingPresentor::setBoneBindingColor(int boneIndex, cocos2d::Color4F color)
{
    if(isBoneAvailable(boneIndex))
    {
        std::vector<DrawNode3D*>& vBinding = __bindingDrawNodes[boneIndex];
        
        for(int i = 0; i < vBinding.size(); i++)
        {
            setNodeColor(vBinding[i], color);
        }
    }
}

BindingPresentor::DRAW_NODE_TREE* BindingPresentor::findTreeNodeByIndex(BindingPresentor::DRAW_NODE_TREE* root, int index)
{
    if(root->_index == index)
    {
        return root;
    }
    else
    {
        for(int i = 0; i < root->_children.size(); i++)
        {
            DRAW_NODE_TREE* result = findTreeNodeByIndex(root->_children[i], index);
            
            if(result)
            {
                return result;
            }
        }
    }
    
    return nullptr;
}

void BindingPresentor::updateWithSkeleton(cocos2d::Skeleton3D* skeleton)
{
    updateBoneTransforms(skeleton);
    updateTreeRecursively(__boneConnDrawNodeTree);
    updateBindingDrawNodes();
    updatePositionDrawNodes();
}

void BindingPresentor::updateTreeRecursively(DRAW_NODE_TREE* treeNode)
{
    Vec3 pPos = Vec3(0, 0, 0);
    Mat4& parentTransform = __boneTransform[treeNode->_index];
    parentTransform.transformPoint(&pPos);
    
    for(int i = 0; i < treeNode->_children.size(); i++)
    {
        Vec3 cPos = Vec3(0, 0, 0);
        Mat4& childTransform = __boneTransform[treeNode->_children[i]->_index];
        childTransform.transformPoint(&cPos);
        
        treeNode->_node[i]->clear();
        treeNode->_node[i]->drawLine(pPos, cPos);
        
        updateTreeRecursively(treeNode->_children[i]);
    }
}

void BindingPresentor::updatePositionDrawNodes()
{
    for(int i = 0; i < __bonePositionDrawNodes.size(); i++)
    {
        __bonePositionDrawNodes[i]->setNodeToParentTransform(__boneTransform[i]);
    }
}

void BindingPresentor::updateBindingDrawNodes()
{
    for(int iBone = 0; iBone < __bindingDrawNodes.size(); iBone++)
    {
        std::vector<DrawNode3D*>& vBinding = __bindingDrawNodes[iBone];
        
        for(int iBinding = 0; iBinding < vBinding.size(); iBinding++)
        {
            DrawNode3D* drawNode = vBinding[iBinding];
            drawNode->setNodeToParentTransform(__boneTransform[iBone]);
        }
    }
}

void BindingPresentor::updateBoneTransforms(cocos2d::Skeleton3D* skeleton)
{
    for(int i = 0; i < __boneTransform.size(); i++)
    {
        Bone3D* bone = skeleton->getBoneByIndex(i);
        if(bone)
        {
            __boneTransform[i] = bone->getWorldMat();
        }
    }
}

CollisionAreaEditor::CollisionAreaEditor() :
__dataFileName("Collision_Area_Default"),
__showName(false)
{
    
}

CollisionAreaEditor::~CollisionAreaEditor()
{
    
}

CollisionAreaEditor* CollisionAreaEditor::create()
{
    CollisionAreaEditor* pRet = new CollisionAreaEditor();
    pRet->init();
    pRet->autorelease();
    return pRet;
}

bool CollisionAreaEditor::init()
{
    addSearchPaths();
    
    __inspector = ModelInspector::create();
    __inspector->showPlane(false);
    __inspector->setPositionY(100);
    this->addChild(__inspector);
    
    __presentor = BindingPresentor::create();
    __inspector->append(__presentor);
    
    __ui = EditorUI::create();
    __ui->setAddBindingCallback(CC_CALLBACK_1(CollisionAreaEditor::onUIAddBinding, this));
    __ui->setSelectBoneCallback(CC_CALLBACK_1(CollisionAreaEditor::onUISelectBone, this));
    __ui->setSelectBindingCallback(CC_CALLBACK_2(CollisionAreaEditor::onUISelectBinding, this));
    __ui->setRemoveBindingCallback(CC_CALLBACK_2(CollisionAreaEditor::onUIRemoveBinding, this));
    __ui->setValueChangeCallback(CC_CALLBACK_3(CollisionAreaEditor::onUIValueChange, this));
    this->addChild(__ui);
    
    __saveButton = MenuItemFrameLabel::create();
    __saveButton->setPosition(Size(1500, Director::getInstance()->getVisibleSize().height - 60));
    __saveButton->setType(MenuItemFrameLabel::TYPE::TRIGGER);
    __saveButton->setString("! SAVE !");
    __saveButton->runAction(RepeatForever::create(Sequence::create(ScaleTo::create(1.0, 1.1), ScaleTo::create(1.0, 1.0), NULL)));
    __saveButton->setActivateCallback(CC_CALLBACK_0(CollisionAreaEditor::onSaveClicked, this));
    this->addChild(__saveButton);
    
    __uiToggleButton = MenuItemFrameLabel::create();
    __uiToggleButton->setPosition(Size(400, Director::getInstance()->getVisibleSize().height - 60));
    __uiToggleButton->setType(MenuItemFrameLabel::TYPE::TRIGGER);
    __uiToggleButton->setString("ANIMATION");
    __uiToggleButton->setActivateCallback(CC_CALLBACK_0(CollisionAreaEditor::onToggleUI, this));
    this->addChild(__uiToggleButton);
    
    __nameToggleButton = MenuItemFrameLabel::create();
    __nameToggleButton->setPosition(Size(550, Director::getInstance()->getVisibleSize().height - 60));
    __nameToggleButton->setType(MenuItemFrameLabel::TYPE::TRIGGER);
    __nameToggleButton->setString("NAME");
    __nameToggleButton->setActivateCallback(CC_CALLBACK_0(CollisionAreaEditor::onToggleName, this));
    __nameToggleButton->setContentSize(Size(120, 60));
    this->addChild(__nameToggleButton);
    
    __modelOpacityInput = TextFieldEx::create();
    __modelOpacityInput->setMax(255);
    __modelOpacityInput->setContent(255);
    __modelOpacityInput->setContentChangeCallback(CC_CALLBACK_0(CollisionAreaEditor::onOpacityChanged, this));
    __modelOpacityInput->setPosition(Size(1300, Director::getInstance()->getVisibleSize().height - 70));
    __modelOpacityInput->setTitle("Opacity");
    this->addChild(__modelOpacityInput);
    
    __actionController = ActionController::create();
    __actionController->setFrameStepCallback(CC_CALLBACK_0(CollisionAreaEditor::onFrameStep, this));
    __actionController->setVisible(false);
    this->addChild(__actionController);
    
    __indicationLineContainer = Node::create();
    this->addChild(__indicationLineContainer);
    
    return true;
}

void CollisionAreaEditor::setData(std::string dataFileName)
{
    Sprite3D* model = Sprite3D::create(dataFileName + ".c3t");
    model = model == nullptr ? Sprite3D::create(dataFileName + ".c3b") : model;
    model->setPosition(Vec2(0, 0));
    model->setRotation(0);
    
    if(model == nullptr)
    {
        printf("## Collision Area Editor ## Cannot find model file %s.c3t \n", dataFileName.c_str());
        return;
    }
    
    __dataFileName = dataFileName;
    __model = model;
    __model->setRotation3D(Vec3(0, 0, 0));
    __model->setPosition(Vec2(Director::getInstance()->getVisibleSize().width / 2, 0));
    
    if(model->getSkeleton() == nullptr)
    {
        printf("## Collision Area Editor ## Model does not have available skeleton \n");
        return;
    }
    
    __bindings.resize(__model->getSkeleton()->getBoneCount());
    
    if(loadBindingFile(dataFileName + ".json") == false)
    {
        printf("## Collision Area Editor ## Cannot find binding file %s.json \n", dataFileName.c_str());
    }
    
    __inspector->append(model);
    __ui->reset();
    __ui->loadBones(model->getSkeleton());
    
    __presentor->setContent(model->getSkeleton(), __bindings);
    __presentor->setNodeToParentTransform(model->getNodeToParentTransform());
    
    bindModelAnimation();
}

void CollisionAreaEditor::bindModelAnimation()
{
    Animation3D* animation = Animation3D::create(__dataFileName + ".c3t");
    animation = animation == nullptr ? Animation3D::create(__dataFileName + ".c3b") : animation;
    
    if(animation == nullptr)
    {
        printf("## Collision Area Editor ## Animation not found for file %s.c3t \n", __dataFileName.c_str());
    }
    
    Animate3D* animate = Animate3D::create(animation);
    
    __actionController->setTarget(__model);
    __actionController->setAction(animate);
}

void CollisionAreaEditor::onUISelectBone(int boneIndex)
{
    __ui->loadBindings(boneIndex, __bindings[boneIndex]);
    __presentor->emphasizeBone(boneIndex);
}

void CollisionAreaEditor::onUISelectBinding(int boneIndex, int bindingIndex)
{
    SINGLE_BINDING& binding = __bindings[boneIndex][bindingIndex];
    
    __ui->loadValue(binding);
    
    __presentor->emphasizeBinding(boneIndex, bindingIndex);
}

void CollisionAreaEditor::onUIAddBinding(int boneIndex)
{
    __bindings[boneIndex].push_back(SINGLE_BINDING());
    __ui->loadBindings(boneIndex, __bindings[boneIndex]);
    __presentor->addBinding(boneIndex, __bindings[boneIndex][__bindings[boneIndex].size() - 1]);
}

void CollisionAreaEditor::onUIRemoveBinding(int boneIndex, int bindingIndex)
{
    int i = 0;
    std::vector<SINGLE_BINDING>& binding = __bindings[boneIndex];
    
    for(auto iter = binding.begin(); iter != binding.end(); iter++)
    {
        if(bindingIndex == i)
        {
            binding.erase(iter);
            break;
        }
        
        i++;
    }
    
    __ui->loadBindings(boneIndex, __bindings[boneIndex]);
    __presentor->removeBinding(boneIndex, bindingIndex);
}

void CollisionAreaEditor::onUIValueChange(int boneIndex, int bindingIndex, SINGLE_BINDING& newValue)
{
    SINGLE_BINDING& binding = __bindings[boneIndex][bindingIndex];
    
    binding.type = newValue.type;
    
    if(newValue.type == SINGLE_BINDING::TYPE::RET)
    {
        binding.r.center = newValue.r.center;
        binding.r.extension = newValue.r.extension;
        binding.r.rotation = newValue.r.rotation;
        binding.r.scale = newValue.r.scale;
        binding.r.translation = newValue.r.translation;
    }
    else
    {
        
    }
    
    __presentor->changeBinding(boneIndex, bindingIndex, binding);
}

bool CollisionAreaEditor::saveBindingFile(std::string fileName)
{
    rapidjson::Document writeDoc;
    writeDoc.SetObject();
    rapidjson::Document::AllocatorType& allocator = writeDoc.GetAllocator();
    
    rapidjson::Value boneArray(rapidjson::kArrayType);
    
    for(int boneIndex = 0; boneIndex < __bindings.size(); boneIndex++)
    {
        std::vector<SINGLE_BINDING>& vBinding = __bindings[boneIndex];
        rapidjson::Value boneObject(rapidjson::kObjectType);
        rapidjson::Value nameObject(__model->getSkeleton()->getBoneByIndex(boneIndex)->getName().c_str(), allocator);
        boneObject.AddMember("boneName", nameObject, allocator);
        rapidjson::Value bindingArray(rapidjson::kArrayType);
        
        for(int bindingIndex = 0; bindingIndex < vBinding.size(); bindingIndex++)
        {
            SINGLE_BINDING& bindingData = vBinding[bindingIndex];
            rapidjson::Value bindingObject(rapidjson::kObjectType);
            saveSingleBinding(bindingData, bindingObject, allocator);
            bindingArray.PushBack(bindingObject, allocator);
        }
        
        boneObject.AddMember("bindings", bindingArray, allocator);
        boneArray.PushBack(boneObject, allocator);
    }
    
    rapidjson::Value object(rapidjson::kObjectType);
    
    writeDoc.AddMember("bindingConfig", boneArray, allocator);
    
    rapidjson::StringBuffer buffer;
    rapidjson::PrettyWriter<rapidjson::StringBuffer> writer(buffer);
    writeDoc.Accept(writer);
    
    std::string writablePath = FileUtils::getInstance()->getInstance()->getWritablePath();
    writablePath.append(fileName);
    FILE* file = fopen(writablePath.c_str(), "wb");
    if(file)
    {
        fputs(buffer.GetString(), file);
        fclose(file);
    }
    else
    {
        return false;
    }
    
    return true;
}

bool CollisionAreaEditor::loadBindingFile(std::string fileName)
{
    std::string writablePath = FileUtils::getInstance()->getInstance()->getWritablePath();
    writablePath.append(fileName);
    
    Data fileData = FileUtils::getInstance()->getDataFromFile(writablePath);
    if(fileData.getSize() == 0)
    {
        return false;
    }
    
    rapidjson::Document readDoc;
    std::string stringtify = std::string((const char*)fileData.getBytes(), fileData.getSize());
    readDoc.Parse<0>(stringtify.c_str());
    
    if(readDoc.HasParseError())
    {
        printf("## Rapid Json ## %s has parse error \n", fileName.c_str());
        return false;
    }
    
    rapidjson::Value& bindingConfig = readDoc["bindingConfig"];
    
    int maxSize = __bindings.size() > bindingConfig.Capacity() ? __bindings.size() : bindingConfig.Capacity();
    int minSize = __bindings.size() < bindingConfig.Capacity() ? __bindings.size() : bindingConfig.Capacity();
    
    if(minSize != maxSize)
    {
        printf("## Rapid Json ## Binding number does not match \n");
    }
    
    __bindings.clear();
    __bindings.resize(maxSize);
    
    for(int boneIndex = 0; boneIndex < minSize; boneIndex++)
    {
        rapidjson::Value& boneData = bindingConfig[boneIndex]["bindings"];
        
        for(int bindingIndex = 0; bindingIndex < boneData.Capacity(); bindingIndex++)
        {
            SINGLE_BINDING binding;
            loadSingleBinding(binding, boneData[bindingIndex]);
            __bindings[boneIndex].push_back(binding);
        }
    }
    
    if(readDoc.HasParseError())
    {
        printf("## Rapid Json ## %s has parse error \n", fileName.c_str());
        return false;
    }
    
    return true;
}

void CollisionAreaEditor::saveHex(Hex& hex, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator)
{
    rapidjson::Value p1(rapidjson::kArrayType);
    saveVec3(hex.p1, p1, allocator);
    jsonValue.AddMember("p1", p1, allocator);
    
    rapidjson::Value p2(rapidjson::kArrayType);
    saveVec3(hex.p2, p2, allocator);
    jsonValue.AddMember("p2", p2, allocator);
    
    rapidjson::Value p3(rapidjson::kArrayType);
    saveVec3(hex.p3, p3, allocator);
    jsonValue.AddMember("p3", p3, allocator);
    
    rapidjson::Value p4(rapidjson::kArrayType);
    saveVec3(hex.p4, p4, allocator);
    jsonValue.AddMember("p4", p4, allocator);
    
    rapidjson::Value p5(rapidjson::kArrayType);
    saveVec3(hex.p5, p5, allocator);
    jsonValue.AddMember("p5", p5, allocator);
    
    rapidjson::Value p6(rapidjson::kArrayType);
    saveVec3(hex.p6, p6, allocator);
    jsonValue.AddMember("p6", p6, allocator);
    
    rapidjson::Value p7(rapidjson::kArrayType);
    saveVec3(hex.p7, p7, allocator);
    jsonValue.AddMember("p7", p7, allocator);
    
    rapidjson::Value p8(rapidjson::kArrayType);
    saveVec3(hex.p8, p8, allocator);
    jsonValue.AddMember("p8", p8, allocator);
    
    rapidjson::Value rotation(rapidjson::kArrayType);
    saveVec3(hex.rotation, rotation, allocator);
    jsonValue.AddMember("rotation", rotation, allocator);
    
    rapidjson::Value scale(rapidjson::kArrayType);
    saveVec3(hex.scale, scale, allocator);
    jsonValue.AddMember("scale", scale, allocator);
    
    rapidjson::Value translation(rapidjson::kArrayType);
    saveVec3(hex.translation, translation, allocator);
    jsonValue.AddMember("translation", translation, allocator);
}

void CollisionAreaEditor::loadHex(Hex& hex, rapidjson::Value& jsonValue)
{
    loadVec3(hex.p1, jsonValue["p1"]);
    loadVec3(hex.p2, jsonValue["p2"]);
    loadVec3(hex.p3, jsonValue["p3"]);
    loadVec3(hex.p4, jsonValue["p4"]);
    loadVec3(hex.p5, jsonValue["p5"]);
    loadVec3(hex.p6, jsonValue["p6"]);
    loadVec3(hex.p7, jsonValue["p7"]);
    loadVec3(hex.p8, jsonValue["p8"]);
    loadVec3(hex.rotation, jsonValue["rotation"]);
    loadVec3(hex.translation, jsonValue["translation"]);
    loadVec3(hex.scale, jsonValue["scale"]);
}

void CollisionAreaEditor::saveRct(Rct& rct, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator)
{
    rapidjson::Value center(rapidjson::kArrayType);
    saveVec3(rct.center, center, allocator);
    jsonValue.AddMember("center", center, allocator);
    
    rapidjson::Value extension(rapidjson::kArrayType);
    saveVec3(rct.extension, extension, allocator);
    jsonValue.AddMember("extension", extension, allocator);
    
    rapidjson::Value rotation(rapidjson::kArrayType);
    saveVec3(rct.rotation, rotation, allocator);
    jsonValue.AddMember("rotation", rotation, allocator);
    
    rapidjson::Value scale(rapidjson::kArrayType);
    saveVec3(rct.scale, scale, allocator);
    jsonValue.AddMember("scale", scale, allocator);
    
    rapidjson::Value translation(rapidjson::kArrayType);
    saveVec3(rct.translation, translation, allocator);
    jsonValue.AddMember("translation", translation, allocator);
}

void CollisionAreaEditor::loadRct(Rct& rct, rapidjson::Value& jsonValue)
{
    loadVec3(rct.center, jsonValue["center"]);
    loadVec3(rct.extension, jsonValue["extension"]);
    loadVec3(rct.rotation, jsonValue["rotation"]);
    loadVec3(rct.translation, jsonValue["translation"]);
    loadVec3(rct.scale, jsonValue["scale"]);
}

void CollisionAreaEditor::saveVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator)
{
    jsonValue.PushBack(vec.x, allocator);
    jsonValue.PushBack(vec.y, allocator);
    jsonValue.PushBack(vec.z, allocator);
}

void CollisionAreaEditor::loadVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue)
{
    vec.x = jsonValue[0].GetDouble();
    vec.y = jsonValue[1].GetDouble();
    vec.z = jsonValue[2].GetDouble();
}

void CollisionAreaEditor::saveSingleBinding(SINGLE_BINDING& binding, rapidjson::Value& jsonValue, rapidjson::Document::AllocatorType& allocator)
{
    jsonValue.AddMember("type", binding.type, allocator);
    
    rapidjson::Value rct(rapidjson::kObjectType);
    saveRct(binding.r, rct, allocator);
    jsonValue.AddMember("rct", rct, allocator);
    
    rapidjson::Value hex(rapidjson::kObjectType);
    saveHex(binding.h, hex, allocator);
    jsonValue.AddMember("hex", hex, allocator);
}

void CollisionAreaEditor::loadSingleBinding(SINGLE_BINDING& binding, rapidjson::Value& jsonValue)
{
    binding.type = jsonValue["type"].GetInt() == SINGLE_BINDING::TYPE::HEX ? SINGLE_BINDING::TYPE::HEX : SINGLE_BINDING::TYPE::RET;
    loadRct(binding.r, jsonValue["rct"]);
    loadHex(binding.h, jsonValue["hex"]);
}

void CollisionAreaEditor::onSaveClicked()
{
    if(saveBindingFile(__dataFileName + ".json"))
    {
        runAlertAnimation("Save Success !!!", Color3B(0, 255, 0));
    }
    else
    {
        runAlertAnimation("Save Failure !!!", Color3B(255, 0, 0));
    }
}

void CollisionAreaEditor::runAlertAnimation(std::string content, cocos2d::Color3B color)
{
    printf("## Collision Area Editor ## %s \n", content.c_str());
    
    Label* contentLabel = Label::createWithSystemFont(content, "", 32);
    contentLabel->setColor(color);
    DrawNode* background = DrawNode::create();
    background->drawSolidRect(Vec2(-200, -30), Vec2(200, 30), Color4F(0.1, 0.1, 0.1, 0.5));
    
    Node* animationNode = Node::create();
    animationNode->addChild(background);
    animationNode->addChild(contentLabel);
    animationNode->setPosition(Director::getInstance()->getVisibleSize() / 2 + Size(0, -100));
    this->addChild(animationNode);
    
    MoveBy* move = MoveBy::create(1.4, Vec2(0, 200));
    animationNode->runAction(Sequence::create(move, RemoveSelf::create(), NULL));
}

void CollisionAreaEditor::onOpacityChanged()
{
    if(__model)
    {
        __model->setOpacity(abs(__modelOpacityInput->getContent()));
    }
}

void CollisionAreaEditor::onFrameStep()
{
    if(__model && __model->getSkeleton())
    {
        __model->getSkeleton()->updateBoneMatrix();
        __presentor->updateWithSkeleton(__model->getSkeleton());
    }
}

void CollisionAreaEditor::onToggleUI()
{
    if(__actionController->isVisible())
    {
        __actionController->setVisible(false);
        __ui->setVisible(true);
        __uiToggleButton->setString("ANIMATION");
    }
    else
    {
        __actionController->setVisible(true);
        __ui->setVisible(false);
        __uiToggleButton->setString("COLLISION");
    }
}

void CollisionAreaEditor::onToggleName()
{
    if(__showName)
    {
        __indicationLineContainer->setVisible(false);
        this->getScheduler()->unschedule("NameLabelUpdater", this);    }
    else
    {
        __indicationLineContainer->setVisible(true);
        this->getScheduler()->schedule([this](float dt){
            
            this->updateIndicationLine();
            
        }, this, 0, CC_REPEAT_FOREVER, 0, false, "NameLabelUpdater");
    }
    
    __showName = !__showName;
}

void CollisionAreaEditor::updateIndicationLine()
{
    std::vector<Vec2> drawNodePos = __presentor->getBoneDrawNodePositions();
    
    for(int i = 0; i < drawNodePos.size(); i++)
    {
        Label* nameLabel = (Label*)__indicationLineContainer->getChildByTag(i);
        
        if(nameLabel == nullptr)
        {
            nameLabel = Label::createWithSystemFont(__model->getSkeleton()->getBoneByIndex(i)->getName(), "", 18);
            nameLabel->setTag(i);
            __indicationLineContainer->addChild(nameLabel);
        }
        
        nameLabel->setPosition(drawNodePos[i]);
    }
}

void CollisionAreaEditor::addSearchPaths()
{
    FileUtils::getInstance()->addSearchPath("3d/bianfuyu");
    FileUtils::getInstance()->addSearchPath("3d/dianmanyu");
    FileUtils::getInstance()->addSearchPath("3d/jianyu");
    FileUtils::getInstance()->addSearchPath("3d/haigui");
    FileUtils::getInstance()->addSearchPath("3d/denglongyu");
    FileUtils::getInstance()->addSearchPath("3d/cheqiyu");
    FileUtils::getInstance()->addSearchPath("3d/dinianyu");
    FileUtils::getInstance()->addSearchPath("3d/fangyu");
    FileUtils::getInstance()->addSearchPath("3d/hetun-1");
    FileUtils::getInstance()->addSearchPath("3d/hetun-2");
    FileUtils::getInstance()->addSearchPath("3d/jinqiangyu");
    FileUtils::getInstance()->addSearchPath("3d/tianshiyu");
    FileUtils::getInstance()->addSearchPath("3d/xiaochouyu");
    FileUtils::getInstance()->addSearchPath("3d/xiaohuangyu");
    FileUtils::getInstance()->addSearchPath("3d/shiziyu");
}
