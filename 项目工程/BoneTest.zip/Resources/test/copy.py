import os 
import os.path 
import shutil 
import time, datetime
import string

c3t_src = "./shayu_0.c3t"
png_src = "./shayu_0.jpg"

for i in range(1, 20):
    c3t_dst = "./shayu_%d.c3t"%(i)
    png_dst = "./shayu_%d.jpg"%(i)
    shutil.copyfile(c3t_src, c3t_dst)
    shutil.copyfile(png_src, png_dst)