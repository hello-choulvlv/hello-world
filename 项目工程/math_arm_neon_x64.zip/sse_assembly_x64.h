//
//  sse_assembly_x64.h
//  libcocos2d Mac
//
//  Created by yitong li on 11/8/2021.
//
/*
 *本篇程序代码专门为mac x64平台而设计,旨在解决使用sse/avx汇编指令用来加速程序的实现过程
 */

#ifndef sse_assembly_x64_h
#define sse_assembly_x64_h
#include "math/CCMathBase.h"

NS_CC_MATH_BEGIN
//以下比较的数据量为4Y
/*
 *sse指令实现,采用intel风格汇编格式实现
 *下面的函数是使用avx指令,sse 的xmm寄存器实现,加速比大概如下
 *optimal avx cost--> 1837672,normal -> 3341958 ,percent 54.987885%
 */
void  sse_assembly_matrix_multiply(const  float  *m1,const  float  *m2,float  *dst);
/*
 *与常规C++代码相比optimal avx cost--> 1325570,normal -> 2330079 ,percent 56.889488%
 *与SSE实现相比optimal avx cost--> 1276166,normal -> 2040767 ,percent 62.533646%
 */
void  sse_assembly_matrix_multiply_vec4(const  float  *m16,const  float  *m4,float  *dst);
/*
 *optimal avx cost--> 1224043,normal -> 1546258 ,percent 79.161629%
 */
void  sse_assembly_matrix_multiply_vec3(const  float  *m16,const  float  *m3,float  *dst);
/*
 *Renderer类中三角形顶点序列计算过程实现,其中也包含森林舞会优化实现
 *常规4顶点下:optimal avx cost--> 3773107,normal -> 11001045 ,percent 34.297714%
 *每16顶点数据下:optimal avx cost--> 15710363,normal -> 76195607 ,percent 20.618462%
 *由此可以看出,当共用数据较多时,优化的效果更明显
 *@2021.8.14
 */
void  sse_renderer_triangle_vertex_generate(const  float  *m16,float  *vertex,uint64_t  vertex_count,const float *addtional_vertex,uint64_t  stride_number);
/*
 *AABB8顶点变换函数实现
 *2021.8.16
 *optimal avx cost--> 8101765,normal -> 43584212 ,percent 18.588760%
 */
void  avx_aabb_transform_matrix(const float *m16,float  *aabb_m6,const float  *boundary_m2);
/*
 *3d捕鱼,计算3d包围盒到2d平面四边形的映射过程,该函数的实现过程综合了几种不同的运算过程,因此代码长度较长,切复杂度较高
 *optimal avx cost--> 18097949,normal -> 220610345 ,percent 8.203581%
 */
void avx_3dbuyu_aabb_project_box2d(const  float  *m16,const float *base_m12,const  float  *viewport_m4,float  *box2d_m16,float  *boundbox_2d);
/*
 *sprite屏幕外裁剪函数实现
 *optimal avx cost--> 18679856,normal -> 46046796 ,percent 40.567116%
 */
bool avx_sprite_screen_culling(const float *m1,const float *m2,const float *viewport_m4);
/*
 *Spine动画裁剪
 *optimal avx cost--> 13693340,normal -> 73058449 ,percent 18.742994%
 */
bool avx_spine_screen_culling(const  float *m,const float *vertex_buffer4,const float *bounding_m4);
/*
 *CCArmature boundingbox 2d
 *optimal avx cost--> 3986491,normal -> 54872276 ,percent 7.265037%
 */
void  avx_rect_apply_transform(const float *m16,const float *rect_m4,float  *m4);
/*
 *CCNode boundingbox 2d
 *optimal avx cost--> 46134529,normal -> 62926286 ,percent 73.315193%
 */
void  avx_rect_apply_affine_transform(const float *m6,const float *rect_m4,float  *m4);
NS_CC_MATH_END

#endif /* sse_assembly_x64_h */
