/*
  *Sprite 批处理渲染,实现单一Sprite多处静态渲染功能
  *该类用于解决在某些游戏中静态筹码Sprite对象过多问题
  *@2021年4月2日
  *@author:xiaoxiong
  *@version 1.0:实现基本批处理渲染功能
  *@version 2:修复渲染大量Sprite对象时,有时出现纹理寻址错误问题.
  *@version 3:增加颜色混合功能,解决Sprite对象不能反映颜色渐变问题.
  *@version 4:对SpriteBatchInstance类中纹理寻址过程进行优化。
  *@version 5:增加动态更改SpriteInstance渲染层序功能。
  *@version 6:修复内存扩张过程中出现的不正确逻辑.
 *@version 7:更改渲染机制,最大幅度优化矩阵运算,减少对象生成数目，以及数据复制过程。
 */
#ifndef __sprite_batch_instance_h
#define __sprite_batch_instance_h

#include "2d/CCNode.h"
#include "2d/CCSpriteFrame.h"
#include "renderer/CCQuadCommand.h"

//#include "scripting/lua-bindings/manual/swgadget/balance_tree.h"
#include "scripting/lua-bindings/manual/swgadget/link_list.h"

namespace cocos2d {

class Renderer;
class SpriteBatchInstance;

struct SpriteInstance : public Ref{
    //位置
    Vec3    _location;
    //Mat4  _translateMat4;
    SpriteFrame     *_spriteFrame;
    link_list<SpriteInstance*>::link_node  *_internal_ptr;
    SpriteBatchInstance             *_parent;
    //是否当前对象处于队列中
    bool   _isObjectInQueue;
    //是否当前对象的坐标位置发生了变化
    bool   _isLocationDirty;
    //是否当前对象的纹理四边形数据发生了变化
    bool   _isQuadDirty,_isColorDirty;
    bool   _isVisible;
    int      _zOrder,_queueIdx,_tag;//_queueIdx域为队列使用
    //QuadCommand   _quadCommand;
    V3F_C4B_T2F_Quad  _quad;

    SpriteInstance(const std::string &sprite_frame_name,int zorder = 0);
    ~SpriteInstance();

    void setPosition(float x,float y);
    void setPosition(const Vec3 &location);
    void setPositionX(float x);
    void setPositionY(float y);
    void setPositionZ(float z);

    const Vec2& getPosition()const { return *(Vec2*)(&_location); };
    const Vec3& getPosition3()const { return _location; };

    void   setZOrder(int zorder) { _zOrder = zorder; };
    int      getZOrder()const { return _zOrder; };

    float getPositionX()const { return _location.x; };
    float getPositionY()const { return _location.y; };
    float getPositionZ()const { return _location.z; };
    
    int    getTag(){return _tag;};
    void setTag(int t){_tag = t;};
    
    void  setVisible(bool b);//{_isVisible = b;};
    bool  isVisible(){return _isVisible;};
    bool  isInQueue(){return _isObjectInQueue;};

    //重新设置SpriteFrame
    void setSpriteFrame(const std::string &sprite_frame_name);
    const SpriteFrame* getSpriteFrame()const;
    
    bool removeFromParent();
    SpriteBatchInstance *getParent()const;
};
////////////////////////////////////SpriteBatchInstance//////////////////////////////////////////////////////
class SpriteBatchInstance : public Node {
    link_list<SpriteInstance*>  _sprite_instance_list;
    V3F_C4B_T2F_Quad          *_quads;
    Vec3                                     *_offsets;//记录所有Sprite的偏移
    QuadCommand                     _quadCommand;
    Texture2D                              *_texture;

    BlendFunc                               _blendFunc;
    int                                               _quadCapacity,_quadCount,_sugestCapacity;
    //是否需要重构四边形序列,如果需要重构的话,则需要从哪里开始,后面将对该类的实现进行优化
    bool                                            _isQuadDirty,_isContentDirty;
    bool                                            _isColorDirty, _isModifyColor;

    SpriteBatchInstance(const Size &content_size, int sugest_capacity);
public:
    static SpriteBatchInstance  *create(const Size &content_size,int sugest_capacity = 32);
    ~SpriteBatchInstance();

    virtual bool init();

    bool addInstance(SpriteInstance  *instance);
    bool removeInstance(SpriteInstance *instance);
    void removeAllInstance();
    //重构Sprite四边形序列
    void  updateInstanceQuads(SpriteInstance *instance);
    void  updateQuads();
    void updateQuadColor(SpriteInstance *instance);
    void changeZOrder(SpriteInstance *instance,int zorder);
    void setQuadDirty(bool b2){_isQuadDirty = b2;};

    //与颜色以及alpha值变化相关的函数
    void setBlendFunc(const BlendFunc &blend);
    virtual void setColor(const Color3B& color);
    virtual void setOpacity(GLubyte opacity);
    virtual void updateDisplayedOpacity(GLubyte opacity);
    virtual void setContentSize(const Size& contentSize);

    virtual const Mat4& getNodeToParentTransform()const;
    virtual void draw(Renderer *renderer, const Mat4& transform, uint32_t flags);
};
}
#endif
