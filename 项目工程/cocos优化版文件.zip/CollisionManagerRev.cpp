//
//  CollisionManager.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/22.
//
//

#include "CollisionManagerRev.hpp"
#include "json/writer.h"
#include "json/stringbuffer.h"
#include <ctime>
#include "math/MathUtil.h"

using namespace cocos2d;
using namespace Rev;
//是否调试新版算法
#define __debug_optimal_algo 0
#define __use_optimal_algo 1
//记录新算法与原版算法之间的消耗时间
//以下为优化后的大致数据
//after optimal, now cost 1.437000, origin cost 4.965000, percent 0.289426, optimal cost less times 937
//after optimal, now cost 1.451000, origin cost 3.980000, percent 0.364573, optimal cost less times 916
//after optimal, now cost 1.379000, origin cost 4.295000, percent 0.321071, optimal cost less times 912
//after optimal, now cost 1.697000, origin cost 4.375000, percent 0.387886, optimal cost less times 908
//after optimal, now cost 1.817000, origin cost 4.405000, percent 0.412486, optimal cost less times 903
//after optimal, now cost 1.331000, origin cost 3.776000, percent 0.352489, optimal cost less times 911
//after optimal, now cost 1.545000, origin cost 4.210000, percent 0.366983, optimal cost less times 899
//after optimal, now cost 1.980000, origin cost 4.615000, percent 0.429036, optimal cost less times 904
//after optimal, now cost 1.635000, origin cost 4.267000, percent 0.383173, optimal cost less times 898
//after optimal, now cost 1.419000, origin cost 4.839000, percent 0.293242, optimal cost less times 933
//after optimal, now cost 1.632000, origin cost 4.262000, percent 0.382919, optimal cost less times 935
//after optimal, now cost 1.472000, origin cost 4.565000, percent 0.322453, optimal cost less times 944
//after optimal, now cost 1.395000, origin cost 3.889000, percent 0.358704, optimal cost less times 930
//after optimal, now cost 1.460000, origin cost 4.156000, percent 0.351299, optimal cost less times 926
//after optimal, now cost 1.532000, origin cost 4.044000, percent 0.378833, optimal cost less times 905
//after optimal, now cost 1.455000, origin cost 4.269000, percent 0.340829, optimal cost less times 915

CollisionManager* CollisionManager::__sInstance = nullptr;

CollisionManager* CollisionManager::getInstance()
{
    if(__sInstance == nullptr)
    {
        __sInstance = new SimpleCollisionManager();
    }
    
    return __sInstance;
}

void CollisionManager::destroyInstance()
{
    delete __sInstance;
    __sInstance = nullptr;
}


SimpleCollisionManager::SimpleCollisionManager()
{
    initConstants();
    
    allocateCaches();
}

SimpleCollisionManager::~SimpleCollisionManager()
{
    deallocateCaches();
}

CollisionManager::CollisionArea* SimpleCollisionManager::claimCollisionArea(const std::string &configName)
{
    // 根据配置的名字生成一个CollisionArea对象
    //
    //  PS:
    //      从类结构上看，CollisionArea为CollisionManager的内部类，所以
    //      由CollisionManager来管理CollisionArea的生命周期是比较合适的做法
    //
    for(int type = 0; type < COLLISION_AREA_TYPE::AREA_TYPE_COUNT; type++)
    {
        auto iter = _configs[type].find(configName);
        
        if(iter !=  _configs[type].end())
        {
            CollisionAreaTyped* area = new CollisionAreaTyped();
            area->_areaType = (COLLISION_AREA_TYPE)type;
            area->__config = &iter->second;
            area->__lastTransform = area->__transform = Mat4::IDENTITY;
            
            return area;
        }
    }
    
    return nullptr;
}


void SimpleCollisionManager::reclaimCollisionArea(CollisionArea* collisionArea)
{
    // 将一个CollisionArea对象放入销毁队列当中
    unregisterArea(collisionArea);
    _removedAreas.push_back(collisionArea);
}

void SimpleCollisionManager::registerArea(CollisionManager::CollisionArea* collisionArea)
{
    // 注册一个CollisionArea对象到CollisionManager的检测队列当中
    //
    //  PS:
    //      用户调用了claimCollisionArea后只是获取了一个collisionArea的使用权，CollisionManager
    //      并不会主动将分派出去的collisionArea加入检测队列。一个collisionArea是否需要参与检测是由用户
    //      来决定的。如果用户想要手中的collisionArea参与检测，则必须调用registerArea函数在CollisionManager中
    //      对其进行注册。
    //
    _registeredAreas.push_back(collisionArea);
}

void SimpleCollisionManager::unregisterArea(CollisionManager::CollisionArea* collisionArea)
{
    // 从CollisionManager的检测队列当中移除一个CollisionArea对象
    for(auto iter = _registeredAreas.begin(); iter != _registeredAreas.end(); iter++)
    {
        if(*iter == collisionArea)
        {
            collisionArea->setEnabled(false);
            _registeredAreas.erase(iter);
            break;
        }
    }
}

void SimpleCollisionManager::initConstants()
{
    _CONST._shapeCacheSize = 3000;
    _CONST._regionCacheSize = 50;
    _CONST._regionX = 11;
    _CONST._regionY = 6;
    _CONST._regionSize = 256;
    _CONST.startX = -741;
    _CONST.startY = -393;
}

void SimpleCollisionManager::allocateCaches()
{
    _configs.resize(COLLISION_AREA_TYPE::AREA_TYPE_COUNT);
    
    _transformedShapes.reserve(_CONST._shapeCacheSize);
    
    _divisions.resize(_CONST._regionX * _CONST._regionY);
    for(int i = 0; i < _CONST._regionX * _CONST._regionY; i++)
    {
        _divisions[i].resize(COLLISION_AREA_TYPE::AREA_TYPE_COUNT);
        
        for(int i = 0; i < COLLISION_AREA_TYPE::AREA_TYPE_COUNT; i++)
        {
            _divisions[i].reserve(_CONST._regionCacheSize);
        }
    }
}

void SimpleCollisionManager::deallocateCaches()
{
    finishRemovedAreas();
    
    for(auto cacheIter = _configs.begin(); cacheIter != _configs.end(); cacheIter++)
    {
        ConfigCache& cache = *cacheIter;
        
        for(auto listIter = cache.begin(); listIter != cache.end(); listIter++)
        {
            ConfigList& config = (*listIter).second;
            
            for(auto dataIter = config.begin(); dataIter != config.end(); dataIter++)
            {
                delete (*dataIter).second;
            }
        }
    }
}

void SimpleCollisionManager::finishRemovedAreas()
{
    for(auto iter = _removedAreas.begin(); iter != _removedAreas.end(); iter++)
    {
        delete *iter;
    }
    
    _removedAreas.clear();
}

void SimpleCollisionManager::clearCaches()
{
    _transformedShapes.clear();
    
    for(int regionIndex = 0; regionIndex < _CONST._regionX * _CONST._regionY; regionIndex++)
    {
        for(int typeIndex = 0; typeIndex < COLLISION_AREA_TYPE::AREA_TYPE_COUNT; typeIndex++)
        {
            _divisions[regionIndex][typeIndex].clear();
        }
    }
}

void SimpleCollisionManager::update(float dt)
{
    // 碰撞检测的执行流程
    //  1. 清除上一次检测中制造的缓存对象
    clearCaches();
    
	Camera* camera = Director::getInstance()->getRunningScene()->getCameras()[0];
	const Mat4 &proj_mat4 = camera->getViewProjectionMatrix();
    for(auto areaIter = _registeredAreas.begin(); areaIter != _registeredAreas.end(); areaIter++)
    {
        CollisionArea* area = *areaIter;
        ConfigList& configList = *area->__config;
        COLLISION_AREA_TYPE areaType = static_cast<CollisionAreaTyped*>(area)->_areaType;
        Mat4 &nodeToWorldTransform = area->__transform;
        Skeleton3D* skeleton = area->__skeleton;
        //  2. 遍历所有参与碰撞检测的CollisionArea对象，对其关联的碰撞形进行变换、投影、区域划分的操作。
        for(auto dataIter = configList.begin(); dataIter != configList.end(); dataIter++)
        {
            // 3. 每个碰撞形都会与绑定对象或绑定对象上的某个骨骼点进行关联，该关联决定了碰撞形变换矩阵的数据来源。
            ConfigData& data = (*dataIter);
            CollisionShape::Shape* shape = data.second;
            Bone3D* bone = getBone(skeleton, data.first);
			float pArray[16];
			Mat4 &boneWorldTransform = *(Mat4*)pArray;
            //Mat4 boneWorldTransform = nodeToWorldTransform;
			//boneWorldTransform = nodeToWorldTransform;
			if (bone)
			{
				//boneWorldTransform = nodeToWorldTransform * bone->getWorldMat();
				Mat4::multiply(nodeToWorldTransform, bone->getWorldMat(), &boneWorldTransform);
			}
			else
				boneWorldTransform = nodeToWorldTransform;

            TransformedShapeInfo info;
            info.first._parent = area;
            
            if(shape->_type == CollisionShape::SHAPE_TYPE::CRL)
            {
                pushShape(info, shape->_c, boneWorldTransform, proj_mat4);
                settleShape(_transformedShapes.back(), areaType);
            }
            else if(shape->_type == CollisionShape::SHAPE_TYPE::RCT)
            {
                pushShape(info, shape->_r, boneWorldTransform, proj_mat4);
                settleShape(_transformedShapes.back(), areaType);
            }
            else if(shape->_type == CollisionShape::SHAPE_TYPE::HEX)
            {
                pushShape(info, shape->_h, boneWorldTransform, proj_mat4);
                settleShape(_transformedShapes.back(), areaType);
            }
        }
    }
    // 4. 遍历每个合法区域的缓存列表，对子弹和鱼的碰撞形进行碰撞检测操作
    for(int regionIndex = 0; regionIndex < _CONST._regionX * _CONST._regionY; regionIndex++)
    {
        std::vector<TransformedShapeInfo*> &bullets = _divisions[regionIndex][COLLISION_AREA_TYPE::BULLET];
        std::vector<TransformedShapeInfo*> &fishes = _divisions[regionIndex][COLLISION_AREA_TYPE::FISH];
        std::vector<TransformedShapeInfo*> &selectors = _divisions[regionIndex][COLLISION_AREA_TYPE::SELECT];
        // 5. 对子弹和鱼进行碰撞检测
        for(int bulletIndex = 0; bulletIndex < bullets.size(); bulletIndex++)
        {
            TransformedShapeInfo* bullet = bullets[bulletIndex];
            CollisionArea* bulletArea = bullet->first._parent;
            
            if(bulletArea->getEnabled())
            {
                for(int fishIndex = 0; fishIndex < fishes.size(); fishIndex++)
                {
                    TransformedShapeInfo* fish = fishes[fishIndex];
                    CollisionArea* fishArea = fish->first._parent;
                    
                    if(fishArea->getEnabled()
                       && (bulletArea->getCollisionMask() == 0xFFFFFFFF || bulletArea->getCollisionMask() == fishArea->getCollisionMask())
                       && intersectAABB(bullet->second, fish->second))
                    {
                        if(circleHexSAT(bullet->first, fish->first))
                        {
                            // 5. 如果发生碰撞，则调用代理函数发送消息
                            //
                            //  PS:
                            //      Demo阶段，CollisionManager只可接受一个代理。
                            //
                            __collisionEventCallback(bulletArea, fishArea);
                        }
                    }
                    
                    if(!bulletArea->getEnabled())
                    {
                        break;
                    }
                }
            }
        }
        // 6. 对选择器和鱼进行碰撞检测
        for(int selectorIndex = 0; selectorIndex < selectors.size(); selectorIndex++)
        {
            TransformedShapeInfo* selector = selectors[selectorIndex];
            CollisionArea* selectorArea = selector->first._parent;
            
            if(selectorArea->getEnabled())
            {
                for(int fishIndex = 0; fishIndex < fishes.size(); fishIndex++)
                {
                    TransformedShapeInfo* fish = fishes[fishIndex];
                    CollisionArea* fishArea = fish->first._parent;
                    // 6. 这里暂时不针对mask进行比较处理
                    if(fishArea->getEnabled() && intersectAABB(selector->second, fish->second))
                    {
                        if(circleHexSAT(selector->first, fish->first))
                        {
                            __collisionEventCallback(selectorArea, fishArea);
                        }
                    }
                }
            }
        }
    }
    // 7. 销毁被标记的CollisionArea对象
    finishRemovedAreas();
    
    //  ATTENTION:
    //      有一点需要特别注意的是，目前，CollisionArea与其绑定对象之间的关联为弱关联（bind过程并未调用retain函数）。若
    //      在碰撞检测过程当中释放了绑定对象则会产生内存访问错误。Demo阶段采用弱关联可以暴漏出一些逻辑上的错误，方便调试。
}

cocos2d::Bone3D* SimpleCollisionManager::getBone(cocos2d::Skeleton3D* skeleton, int boneIndex)
{
    if(skeleton)
    {
        return skeleton->getBoneByIndex(boneIndex);
    }
    else
    {
        return nullptr;
    }
}

void simple_project_gl(const Mat4 &proj_mat,const Size &win_size,const Vec3 &src,Vec2 &dst) {
	Vec4 clipPos;
	proj_mat.transformVector(Vec4(src.x, src.y, src.z, 1.0f), &clipPos);

	CCASSERT(clipPos.w != 0.0f, "clipPos.w can't be 0.0f!");

	dst.x = (clipPos.x / clipPos.w + 1.0f) * 0.5f * win_size.width;
	dst.y = (clipPos.y / clipPos.w + 1.0f) * 0.5f * win_size.height;
}

void SimpleCollisionManager::pushShape(TransformedShapeInfo& info, CollisionShape::R& r, cocos2d::Mat4& transform, const cocos2d::Mat4 &proj_mat4)
{
    // OBB 的投影形描述中包含了OBB经过投影后8个顶点在投影面上的具体位置
    //  1. 计算8个顶点的空间位置
#if defined(USE_NEON64) || defined(USE_NEON32) || defined(INCLUDE_NEON32)
    float  vertex_buffer[3 * 8];
    Vec3  *vertex = (Vec3 *)vertex_buffer;
    const float   boundary_inverse[4] = {FLT_MAX,FLT_MAX,-FLT_MAX,-FLT_MAX};
#else
    Vec3 vertex[8];
#endif
    
    bool  b2_optimal = false;
#if defined(USE_NEON64)
    b2_optimal = true;
    neon64_extend_center_3axis_vec3(&r._x.x, vertex_buffer);
#elif defined(USE_NEON32)
    b2_optimal = true;
    neon32_extend_center_3axis_vec3(&r._x.x, vertex_buffer);
#elif defined(INCLUDE_NEON32)
    if(MathUtil::isNeon32Enabled()){
        b2_optimal = true;
        neon32_extend_center_3axis_vec3(&r._x.x, vertex_buffer);
    }
#endif
    if(!b2_optimal){
        vertex[0] = r._center + r._x + r._y + r._z;
        vertex[1] = r._center + r._x - r._y + r._z;
        vertex[2] = r._center - r._x - r._y + r._z;
        vertex[3] = r._center - r._x + r._y + r._z;
        vertex[4] = r._center + r._x + r._y - r._z;
        vertex[5] = r._center + r._x - r._y - r._z;
        vertex[6] = r._center - r._x - r._y - r._z;
        vertex[7] = r._center - r._x + r._y - r._z;
    }
    
    //Camera* camera = Director::getInstance()->getRunningScene()->getCameras()[0];
	auto &viewport = Director::getInstance()->getWinSize();
	//const Mat4 &proj_mat4 = camera->getViewProjectionMatrix();// .transformVector(Vec4(src.x, src.y, src.z, 1.0f), &clipPos);
    //  2. 计算8个顶点经过变换和投影后的位置
#ifdef USE_NEON64
    //使用100000000次函数调用的结果,在iPhone6S,优化级别 -Os下得出计算测试结果
    //optimal neon 64 cost--> 489585,normal -> 5108369 ,percent 0.095840
    //在100000000次函数调用下,-O0级别下
    //optimal neon 64 cost--> 485430,normal -> 6526231 ,percent 0.074381
    //Mat4   view_proj_mat = proj_mat4 * transform;
    float    mat_4x4[16];
    MathUtil::multiplyMatrix(proj_mat4.m, transform.m, mat_4x4);
    float    m4[4] = {viewport.width * 0.5f,viewport.height * 0.5f,0.5f,0.5f};
    neon64_project_screen_vec3_store2(mat_4x4, (float *)vertex, (float *)info.first._vertex, m4, 8);
#elif defined(USE_NEON32)
    float    mat_4x4[16];
    MathUtil::multiplyMatrix(proj_mat4.m, transform.m, mat_4x4);
    float    m4[4] = {viewport.width * 0.5f,viewport.height * 0.5f,0.5f,0.5f};
    neon32_project_screen_vec3_store2(mat_4x4, (float *)ver+tex, (float *)info.first._vertex, m4, 8);
#elif defined(INCLUDE_NEON32)
    if(MathUtil::isNeon32Enabled()){
        float    mat_4x4[16];
        MathUtil::multiplyMatrix(proj_mat4.m, transform.m, mat_4x4);
        float    m4[4] = {viewport.width * 0.5f,viewport.height * 0.5f,0.5f,0.5f};
        neon32_project_screen_vec3_store2(mat_4x4, (float *)vertex, (float *)info.first._vertex, m4, 8);
    }
#endif
    if(!b2_optimal){
        for(int i = 0; i < 8; i++)
        {
            transform.transformPoint(vertex[i], &vertex[i]);
            //info.first._vertex[i] = camera->projectGL(vertex[i]);
            simple_project_gl(proj_mat4, viewport, vertex[i], info.first._vertex[i]);
        }
    }
#ifdef USE_NEON64
    neon64_3d_project_2d_boundingbox(&info.first._vertex[0].x, boundary_inverse,&info.second._minX, 8);
#elif defined(USE_NEON32)
    neon32_3d_project_2d_boundingbox(&info.first._vertex[0].x, boundary_inverse,&info.second._minX, 8);
#elif defined(INCLUDE_NEON32)
    if(MathUtil::isNeon32Enabled()){
        neon32_3d_project_2d_boundingbox(&info.first._vertex[0].x, boundary_inverse,&info.second._minX, 8);
    }
#endif
    //  3. 计算投影形的AABB
    if(!b2_optimal){
        info.second._maxX = info.second._maxY = -0x7FFFFFFF;
        info.second._minX = info.second._minY = 0x7FFFFFFF;
        
        auto &info_base = info.second;
        for(int i = 0; i < 8; i++)
        {
            const Vec2 &vertex = info.first._vertex[i];
            info_base._maxX = fmaxf(info_base._maxX , vertex.x);// ? info_base._maxX : vertex.x;
            info_base._maxY = fmaxf(info_base._maxY , vertex.y);// ? info_base._maxY : vertex.y;
            info_base._minX = fminf(info_base._minX , vertex.x);// ? info_base._minX : vertex.x;
            info_base._minY = fminf(info_base._minY , vertex.y);// ? info_base._minY : vertex.y;
        }
    }
    //  4. 将描述对象放入缓存区域当中
    _transformedShapes.push_back(info);
}

void SimpleCollisionManager::pushShape(TransformedShapeInfo& info, CollisionShape::C& c, cocos2d::Mat4& transform, const cocos2d::Mat4 &proj_mat4)
{
    // 圆 的描述计算比较简单，只需要计算圆心经过变换后的位置即可。
    Vec3 _tCenter;
    transform.transformPoint(c._center, &_tCenter);
    
    //Camera* camera = Director::getInstance()->getRunningScene()->getCameras()[0];
    // 变换后的圆心位置存储在ShapeProjected的第一个顶点当中，半径存储在第二个顶点的x分量当中。
	Vec2 _tCenter2D;// = camera->projectGL(_tCenter);
	simple_project_gl(proj_mat4, Director::getInstance()->getWinSize(), _tCenter, _tCenter2D);

    info.first._vertex[0] = _tCenter2D;
    info.first._vertex[1].x = c._radius;
    
    info.second._maxX = _tCenter2D.x + c._radius;
    info.second._minX = _tCenter2D.x - c._radius;
    info.second._maxY = _tCenter2D.y + c._radius;
    info.second._minY = _tCenter2D.y - c._radius;
    
    _transformedShapes.push_back(info);
}

void SimpleCollisionManager::pushShape(TransformedShapeInfo& info, CollisionShape::H& h, cocos2d::Mat4& transform, const cocos2d::Mat4 &proj_mat4)
{
    
}

void SimpleCollisionManager::settleShape(TransformedShapeInfo& info, COLLISION_AREA_TYPE& type)
{
    // 简单的区域划分处理
    //
    //  1. 根据初始化时定义的分割配置以及投影形的AABB确定投影形的所在区域索引
    int max_rX = (info.second._maxX - _CONST.startX) / _CONST._regionSize;
    int max_rY = (info.second._maxY - _CONST.startY) / _CONST._regionSize;
    int min_rX = (info.second._minX - _CONST.startX) / _CONST._regionSize;
    int min_rY = (info.second._minY - _CONST.startY) / _CONST._regionSize;
    
    if(max_rX > _CONST._regionX)
    {
        max_rX = _CONST._regionY;
    }
    
    if(max_rY > _CONST._regionY)
    {
        max_rY = _CONST._regionY;
    }
    
    if(min_rX < 0)
    {
        min_rX = 0;
    }
    
    if(min_rY < 0)
    {
        min_rY = 0;
    }
    
    //  2. 根据初始化时定义的合法区域大小，将处于合法区域内的投影形描述放入缓存队列当中
    for(int y = min_rY; y < max_rY + 1; y++)
    {
        for(int x = min_rX; x < max_rX + 1; x++)
        {
            if(y > -1 && y < _CONST._regionY && x > -1 && x < _CONST._regionX)
            {
                _divisions[x + y * _CONST._regionX][type].push_back(&info);
            }
        }
    }
}

bool SimpleCollisionManager::intersectAABB(MinMax& a, MinMax& b)
{
    //return ((a._minX >= b._minX && a._minX <= b._maxX) || (b._minX >= a._minX && b._minX <= a._maxX)) &&
    //((a._minY >= b._minY && a._minY <= b._maxY) || (b._minY >= a._minY && b._minY <= a._maxY));

	if (fabsf(b._minX + b._maxX - a._minX - a._maxX) > (a._maxX - a._minX) + (b._maxX - b._minX))
		return false;

	return fabsf(b._minY + b._maxY - a._minY - a._maxY) <= (a._maxY - a._minY) + (b._maxY - b._minY);
}

//inline float simple_cross(const Vec2 &v0,const Vec2 &v1,const Vec2 &v2) {
//	return (v1.x - v0.x) * (v2.y - v0.y) - (v2.x - v0.x) * (v1.y - v0.y);
//}
#define simple_cross(v0,v1,v2) ((v1.x - v0.x) * (v2.y - v0.y) - (v2.x - v0.x) * (v1.y - v0.y))
#define simple_dot(u,v) (u.x * v.x + u.y * v.y)
#define ortho_distance(normal,point) (-normal.y * point.x + normal.x * point.y)
#define simple_length(u) sqrtf(u.x * u.x + u.y * u.y)
//四边形的顺时针/逆时针未知
bool quad_polygon_cycle_intersect(const Vec2 &p0,const Vec2 &p1,const Vec2 &p2,const Vec2 &p3,const Vec2 &center,float r) {
	float f2 = simple_cross(p0,p2,p3);
	//求圆心与对角线之间的相对关系
	float f4 = simple_cross(p0,p2,center);
	bool b2 = f4 * f2 > 0.0f;
	//
	const Vec2 &p4 = b2?p3:p1;
	//如果是p3的三角形
	bool b3 = (b2 ? f2 : -f2) > 0.0f;
	const Vec2 &v0 = p0;
	const Vec2 &v1 = b3 ? p2 : p4;
	const Vec2 &v2 = b3 ? p4 : p2;
	//以下为求顶点center与三个顶点构成的序列之间的关系Voronoi特征域
	//v0
	const Vec2 v01 = v1 - v0,v02 = v2 - v0,v0c = center - v0;
	float fv01 = simple_dot(v0c,v01);
	float fv02 = simple_dot(v0c,v02);
	if (fv01 <= 0.0f && fv02 < 0.0f)
		return v0c.x * v0c.x + v0c.y * v0c.y <= r * r;
	//v1
	const Vec2 v1c = center - v1,v12 = v2 - v1;
	float fv10 = -simple_dot(v1c,v01);
	float fv12 = simple_dot(v1c,v12);
	if (fv10 <= 0.0f && fv12 <= 0.0f)
		return v1c.x * v1c.x + v1c.y * v1c.y <= r * r;
	//v2
	const Vec2 v2c = center - v2;
	float fv20 = -simple_dot(v02,v2c);
	float fv21 = -simple_dot(v2c,v12);
	if (fv20 <= 0.0f && fv21 <= 0.0f)
		return v2c.x * v2c.x + v2c.y * v2c.y <= r * r;
	//v01 optimal
	if (!b3 && fv01 >= 0.0f && fv10 >= 0.0f && simple_cross(v0, v1, center) <= 0.0f)
		return ortho_distance(v01,center) <= r * simple_length(v01);
	//v12
	if (fv12 >= 0.0f && fv21 >= 0.0f && simple_cross(v1, v2, center) <= 0.0f)
		return ortho_distance(v12,center) <= r * simple_length(v12);
	//v20 optimal
	if (b3 && fv20 >= 0.0f && fv02 >= 0.0f && simple_cross(v2, v0, center) <= 0.0f)
		return -ortho_distance(v02,center) <= r * simple_length(v02);

	return true;
}

bool SimpleCollisionManager::circleHexSAT(ShapeProjected& circle, ShapeProjected& hex)
{
    // 对每个面投影产生的四边形进行检测
	const Vec2 *vertex_array = hex._vertex;
	const Vec2 &center = circle._vertex[0];
	float r = circle._vertex[1].x;
	return	quad_polygon_cycle_intersect(vertex_array[0], vertex_array[1], vertex_array[2], vertex_array[3], center, r) ||
		quad_polygon_cycle_intersect(vertex_array[4], vertex_array[5], vertex_array[6], vertex_array[7], center, r) ||
		quad_polygon_cycle_intersect(vertex_array[0], vertex_array[4], vertex_array[5], vertex_array[1], center, r) ||
		quad_polygon_cycle_intersect(vertex_array[1], vertex_array[5], vertex_array[6], vertex_array[2], center, r) ||
		quad_polygon_cycle_intersect(vertex_array[2], vertex_array[6], vertex_array[7], vertex_array[3], center, r) ||
		quad_polygon_cycle_intersect(vertex_array[3], vertex_array[7], vertex_array[4], vertex_array[0], center, r);
}

bool SimpleCollisionManager::readConfig(const std::string &configName,const std::string &configPath, COLLISION_AREA_TYPE type)
{
    Data fileData = FileUtils::getInstance()->getDataFromFile(configPath);
    if(fileData.getSize() == 0)
    {
        return false;
    }
    
    rapidjson::Document readDoc;
    std::string stringtify = std::string((const char*)fileData.getBytes(), fileData.getSize());
    readDoc.Parse<0>(stringtify.c_str());
    
    if(readDoc.HasParseError())
    {
        printf("## Rapid Json ## %s has parse error \n", configName.c_str());
        return false;
    }
    
    rapidjson::Value& bindingConfig = readDoc["bindingConfig"];
    
    int size = bindingConfig.Capacity();
    
    _configs[type][configName] = ConfigList();
    
    for(int boneIndex = 0; boneIndex < size; boneIndex++)
    {
        rapidjson::Value& boneData = bindingConfig[boneIndex]["bindings"];
        
        for(int bindingIndex = 0; bindingIndex < boneData.Capacity(); bindingIndex++)
        {
            ConfigData data;
            data.first = boneIndex;
            data.second = new CollisionShape::Shape();
            loadConfigData(data, boneData[bindingIndex]);
            _configs[type][configName].push_back(data);
        }
    }
    
    if(readDoc.HasParseError())
    {
        printf("## Rapid Json ## %s has parse error \n", configName.c_str());
        return false;
    }
    
    return true;
}

void SimpleCollisionManager::loadConfigData(ConfigData& data, rapidjson::Value& jsonValue)
{
    int type = jsonValue["type"].GetInt();
    data.second->_type = (CollisionShape::SHAPE_TYPE)type;
    
    if(type == CollisionShape::SHAPE_TYPE::CRL)
    {
        loadCrl(*data.second, jsonValue["crl"]);
    }
    else if(type == CollisionShape::SHAPE_TYPE::RCT)
    {
        loadRct(*data.second, jsonValue["rct"]);
    }
    else if(type == CollisionShape::SHAPE_TYPE::HEX)
    {
        loadHex(*data.second, jsonValue["hex"]);
    }
}

void SimpleCollisionManager::loadHex(CollisionShape::Shape& hex, rapidjson::Value& jsonValue)
{
    
}

void SimpleCollisionManager::loadRct(CollisionShape::Shape& rct, rapidjson::Value& jsonValue)
{
    loadVec3(rct._r._center, jsonValue["center"]);
    
    Vec3 translation;
    Vec3 rotation;
    Vec3 scale;
    Vec3 extension;
    
    loadVec3(extension, jsonValue["extension"]);
    loadVec3(rotation, jsonValue["rotation"]);
    loadVec3(translation, jsonValue["translation"]);
    loadVec3(scale, jsonValue["scale"]);
    
    cocos2d::Mat4 transform;
    transform.rotate(cocos2d::Quaternion(cocos2d::Vec3(1, 0, 0), rotation.x)
                     * cocos2d::Quaternion(cocos2d::Vec3(0, 1, 0), rotation.y)
                     * cocos2d::Quaternion(cocos2d::Vec3(0, 0, 1), rotation.z));
    transform.translate(translation);
    
    transform.transformVector(&rct._r._x);
    transform.transformVector(&rct._r._y);
    transform.transformVector(&rct._r._z);
    transform.transformPoint(&rct._r._center);
    
    rct._r._x = rct._r._x.getNormalized() * extension.x * scale.x;
    rct._r._y = rct._r._y.getNormalized() * extension.y * scale.y;
    rct._r._z = rct._r._z.getNormalized() * extension.z * scale.z;
}

void SimpleCollisionManager::loadCrl(CollisionShape::Shape& crl, rapidjson::Value& jsonValue)
{
    loadVec3(crl._c._center, jsonValue["center"]);
    crl._c._radius = jsonValue["radius"].GetDouble();
}

void SimpleCollisionManager::loadVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue)
{
    vec.x = jsonValue[(rapidjson::SizeType)0].GetDouble();
    vec.y = jsonValue[(rapidjson::SizeType)1].GetDouble();
    vec.z = jsonValue[(rapidjson::SizeType)2].GetDouble();
}
