/****************************************************************************
Copyright (c) 2008-2010 Ricardo Quesada
Copyright (c) 2010-2012 cocos2d-x.org
Copyright (c) 2011      Zynga Inc.
Copyright (c) 2013-2016 Chukong Technologies Inc.
 
http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/
#ifndef __CCLABEL_ATLAS_H__
#define __CCLABEL_ATLAS_H__

#include "2d/CCAtlasNode.h"
#if CC_LABELATLAS_DEBUG_DRAW
#include "renderer/CCCustomCommand.h"
#include "2d/CCDrawNode.h"
#endif
#include "2d/CCFontAtlas.h"
NS_CC_BEGIN

/**
 * @addtogroup _2d
 * @{
 */

/** 
 * @class LabelAtlas
 * @brief LabelAtlas is a subclass of AtlasNode.
 *
 * It can be as a replacement of Label since it is MUCH faster.
 * 
 * LabelAtlas versus Label:
 * - LabelAtlas is MUCH faster than Label.
 * - LabelAtlas "characters" have a fixed height and width.
 * - LabelAtlas "characters" can be anything you want since they are taken from an image file.
 * 
 * A more flexible class is LabelBMFont. It supports variable width characters and it also has a nice editor.
 */
class CC_DLL LabelAtlas : public Node, public LabelProtocol
{
public:
    /** 
     * Creates an empty LabelAtlas.
     * User need to call initWithString(...) later to make this object work properly.
     */
    static LabelAtlas* create();
    
    /** Creates the LabelAtlas with a string, a char map file(the atlas), the width and height of each element and the starting char of the atlas. */
    static LabelAtlas* create(const std::string& string, const std::string& charMapFile, int itemWidth, int itemHeight, int startCharMap);
    
    /**
     * Creates the LabelAtlas with a string and a configuration file.
     * @since v2.0
     */
    static LabelAtlas* create(const std::string& string, const std::string& fntFile);

    /** Initializes the LabelAtlas with a string, a char map file(the atlas), the width and height of each element and the starting char of the atlas. */
    bool initWithString(const std::string& string, const std::string& charMapFile, int itemWidth, int itemHeight, int startCharMap);
    
    /** 
     * Initializes the LabelAtlas with a string and a configuration file.
     * @since v2.0
     */
    //bool initWithString(const std::string& string, const std::string& fntFile);
    
    /** Initializes the LabelAtlas with a string, a texture, the width and height in points of each element and the starting char of the atlas */
    bool initWithString(const std::string& string, Texture2D* texture, int itemWidth, int itemHeight, int startCharMap);
    
    virtual void setString(const std::string &label) override;
    virtual const std::string& getString(void) const override;

    void updateAtlasValues();
	//modify by xiaoxiong
	void   updateCharMap(const std::string &charSequence);
    
    //void   setOpacityModifyRGB(bool b2){_isOpacityModifyRGB = b2;};
    //bool   isOpacityModifyRGB()const{return _isOpacityModifyRGB;};
    
    virtual void setBlendFunc(const BlendFunc &blend);
    virtual BlendFunc getBlendFunc()const{return _blendFunc;};
    
    virtual void setColor(const Color3B& color)override;
    virtual void setOpacity(GLubyte opacity)override;
    virtual void updateDisplayedOpacity(GLubyte opacity)override;
	/**
     * @js NA
     */
    virtual std::string getDescription() const override;

//#if CC_LABELATLAS_DEBUG_DRAW
    virtual void draw(Renderer *renderer, const Mat4 &transform, uint32_t flags) override;
    
    static int32_t  getVersion(){return 1;};
//#endif

CC_CONSTRUCTOR_ACCESS:
    LabelAtlas();
//    :_string("")
//	, _useCharMap(false)
//    {
//#if CC_LABELATLAS_DEBUG_DRAW
//        _debugDrawNode = DrawNode::create();
//        addChild(_debugDrawNode);
//#endif
//    }

    virtual ~LabelAtlas();
    
protected:
    virtual void updateColor() override;

#if CC_LABELATLAS_DEBUG_DRAW
    DrawNode *_debugDrawNode;
#endif

    // string to render
    std::string _string;
    // the first char in the char map
    Texture2D        *_texture;
    SpriteFrame    *_spriteFrame;
    
    //quad sequence
    V3F_C4B_T2F_Quad    *_quad;
    uint16_t                         *_indice_array;
    int32_t                            _quadCapacity,_quadCount;
    
    //item dimension
    int32_t   _itemWidth,_itemHeight;
    int32_t   _itemsPerRow, _itemsPerColumn;
    
    int         _mapStartChar;
	//use char map,if some param is setting,then use char map
	bool                             _useCharMap,_isOpacityModifyRGB,_isColorDirty;
	std::map<int, int>     _charMap;
    
    BlendFunc                           _blendFunc;
    //QuadCommand                _quadCommand;
    TrianglesCommand         _triangleCommand;
    TrianglesCommand::Triangles  _triangle;
};

// end group
/// @}

/*
*有关字符集的描述
*/
class CC_DLL LabelFrameAtlas :public Node {
	std::string _frameNameFormat, _secondaryFormat;//字符串通用模板
	std::string _strContent;
	V3F_C4B_T2F_Quad   *_quads;//四边形顶点序列
    uint16_t                         *_indice_array;
	int                                        _quadCount, _quadCapacity;//顶点序列的数目,其数目跟_strContent的长度有着一定的关系
	bool                                     _isContentDirty, _isUseSecondary, _isColorDirty,_isModifyColor;//是否需要重构四边形内容

	Texture2D	                         *_textureRef;
	BlendFunc                           _blendFunc;
	//QuadCommand                  _quadCommand;
    TrianglesCommand         _triangleCommand;
    TrianglesCommand::Triangles  _triangle;
public:
	LabelFrameAtlas(const std::string &frame_name_format);
	~LabelFrameAtlas();
	bool init()override;
	static LabelFrameAtlas* create(const std::string &frame_name_format);
    static int              getVersion(){return 1;};

	void setFrameFormat(const std::string &frame_format);
	void setString(const std::string &str_content);
	void setString(const std::string &str_content, const std::string &secondary_format);
	const std::string &getString()const;

	//virtual const Size& getContentSize()const;
	virtual void setBlendFunc(const BlendFunc &blend);
	virtual void setColor(const Color3B& color)override;
	virtual void setOpacity(GLubyte opacity)override;
	virtual void updateDisplayedOpacity(GLubyte opacity)override;
	virtual void draw(Renderer *renderer, const Mat4& transform, uint32_t flags)override;
    
    virtual void updateColor() override;
private:
	void updateQuadContent();
};

//Fnt 字体渲染实现,与Label类相比,该类可以实现基于SpriteFrame的渲染
class  LabelFnt : public Node,public LabelProtocol,public BlendProtocol{
    std::string         _labelString;
    std::u16string  _utf16String;
    
    FontAtlas                       *_fontAtlas;
    V3F_C4B_T2F_Quad    *_quads;
    uint16_t                          *_indice_array;
    int32_t                            _quadCount,_quadCapacity;
    TrianglesCommand             _triangleCommand;
    //QuadCommand                  _quadCommand;
    TrianglesCommand::Triangles    _triangle;
    BlendFunc                     _blendFunc;
    bool                                _isOpacityModifyRGB,_isColorDirty;
public:
    LabelFnt();
    ~LabelFnt();
    static LabelFnt*    createWithFntFile(const std::string &fnt_path,const std::string &label_string);
    static int     getVersion(){return 1;};
    
    bool  initWithFntFile(const std::string &fnt_path,const std::string &label_string);
    void  setBMFontFilePath(const std::string &fnt_file);//for compatible of label
    //const std::string& getBMFontFilePath()const;
    
    virtual void setString(const std::string &label_string)override;
    virtual const std::string& getString()const override{return _labelString;};
    
    virtual void setBlendFunc(const BlendFunc &blend)override;
    virtual const BlendFunc& getBlendFunc()const override{return _blendFunc;};
    
    virtual void updateColor() override;
    virtual void setColor(const Color3B& color)override;
    virtual void setOpacity(GLubyte opacity)override;
    virtual void updateDisplayedOpacity(GLubyte opacity)override;
    
    virtual void draw(Renderer *renderer, const Mat4& transform, uint32_t flags)override;
    
private:
    void updateQuadContent();
};


NS_CC_END

#endif //__CCLABEL_ATLAS_H__
