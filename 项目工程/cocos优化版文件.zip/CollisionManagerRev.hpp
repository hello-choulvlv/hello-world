//
//  CollisionManager.hpp
//  BoneTest
//
//  Created by charlie on 2017/3/22.
//
//

#ifndef CollisionManager_hpp
#define CollisionManager_hpp

#include "cocos2d.h"
#include "json/document.h"
#include "GameDebugger.hpp"

class DrawNode3D;

namespace Rev {

namespace CollisionShape {
    
    enum SHAPE_TYPE {HEX, RCT, CRL};
    
    typedef  struct {
        SHAPE_TYPE _type = SHAPE_TYPE::RCT;
        cocos2d::Vec3 _x = cocos2d::Vec3(1, 0, 0);
        cocos2d::Vec3 _y = cocos2d::Vec3(0, 1, 0);
        cocos2d::Vec3 _z = cocos2d::Vec3(0, 0, 1);
        cocos2d::Vec3 _center = cocos2d::Vec3(0, 0, 0);
    } R;
    
    typedef struct {
        SHAPE_TYPE _type = SHAPE_TYPE::HEX;
        cocos2d::Vec3 _center = cocos2d::Vec3(0, 0, 0);
        cocos2d::Vec3 _p[8] = {
            {1, 1, 1},
            {1, -1, 1},
            {-1, -1, 1},
            {-1, 1, 1},
            {1, 1, -1},
            {1, -1, -1},
            {-1, -1, -1},
            {-1, 1, -1},
        };
    } H;
    
    typedef struct {
        SHAPE_TYPE _type = SHAPE_TYPE::CRL;
        cocos2d::Vec3 _center;
        float _radius;
    } C;
    
    union Shape
    {
        Shape(R& r):_r(r){}
        Shape(H& h):_h(h){}
        Shape(C& c):_c(c){}
        Shape():_r(R()){}
        Shape(Shape& s){ memcpy(this, &s, sizeof(Shape));}
        Shape(Shape const& s){ memcpy(this, &s, sizeof(Shape));}
        ~Shape() {}
        
        SHAPE_TYPE _type;
        R _r;
        H _h;
        C _c;
    };
}

class CollisionManager {
  
// TYPE //
    
public:
    typedef std::pair<int, CollisionShape::Shape*> ConfigData;
    typedef std::vector<ConfigData> ConfigList;
    
    struct CollisionArea
    {
        CollisionArea():__skeleton(nullptr), __transform(cocos2d::Mat4::IDENTITY), __config(nullptr), __collisionMask(0), __enabled(false) {}
        void bind(cocos2d::Skeleton3D* skeleton, cocos2d::Mat4 transform) {__lastTransform = __transform, __skeleton = skeleton; __transform = transform;}
        void unbind() {__skeleton = nullptr; __transform = cocos2d::Mat4::IDENTITY;}
        void setCollisionMask(int collisionMask) {__collisionMask = collisionMask;}
        unsigned int getCollisionMask() { return __collisionMask;}
        void setEnabled(bool enableFlag) {__enabled = enableFlag;};
        bool getEnabled() {return __enabled;};
        
        cocos2d::Skeleton3D* __skeleton;
        cocos2d::Mat4 __transform;
        cocos2d::Mat4 __lastTransform;
        CollisionManager::ConfigList* __config;
        unsigned int __collisionMask;
        bool __enabled;
    };

    
// CONSTRUCTOR //
    
protected:
    CollisionManager():__projectionMode(cocos2d::Director::Projection::_2D), __collisionEventCallback([](CollisionArea*, CollisionArea*){}) {}
    virtual ~CollisionManager() {};
   
    
// NON-VIRTUAL //
    
public:
    void setProjectionMode(cocos2d::Director::Projection projectionMode) {__projectionMode = projectionMode;}
    
    
// VIRTUAL //
    
public:
    virtual CollisionArea* claimCollisionArea(const std::string &configName) {return nullptr;}
    virtual void reclaimCollisionArea(CollisionArea*) {};
    virtual void registerArea(CollisionArea* area) {};
    virtual void unregisterArea(CollisionArea* area) {};
    virtual void update(float dt) {};
    virtual void setCollisionEventCallback(std::function<void (CollisionArea*, CollisionArea*)> callback) { __collisionEventCallback = callback;};
    
// ATTRIBUTE //
    
protected:
    cocos2d::Director::Projection __projectionMode;
    std::function<void (CollisionArea*, CollisionArea*)> __collisionEventCallback;
    
    
// STATIC //
    
public:
    static CollisionManager* getInstance();
    static void destroyInstance();
private:
    static CollisionManager* __sInstance;

};

// 碰撞管理器的实现类
//
//  ATTENTION:
//      该实现仍处于开发阶段，算法存在较大的优化空间，错误处理与健壮性上还有待增强。
//      后面将结合游戏需求和开发需求不断完善。

class SimpleCollisionManager : public CollisionManager
{
public:
     enum COLLISION_AREA_TYPE {BULLET, FISH, SELECT, AREA_TYPE_COUNT};
    
private:
    
    // Augment the [CollisionArea] class with a type attribute.
    //
    // -- PS:
    //      The augmented type attribute will be used by the [SimpleCollisionManager] to
    //      categorize [CollisionArea] into different groups. Since the game requires that
    //      shapes colliding with each other only if they were in different groups, this
    //      categorization will help speed up the search progress for collidable shape pairs;
    //
    //      Inside [SimpleCollisionManager], each type of [CollisionArea] is stored seperatedly,
    //      you will see this implemented in the declaration of [RegionCache] type;
    //
    //      BTW, the [CollisionArea] class has a mask attribute, which is wholly capable of
    //      doing simple categorizations, but it will also be used to implment the "locking"
    //      function. So, to make things clearer, I put type info into a different attribute,
    //      and type it with an enum, which will help a lot when doing debugs.

    struct CollisionAreaTyped : public CollisionArea {
        
        CollisionAreaTyped():CollisionArea(), _areaType(COLLISION_AREA_TYPE::BULLET) {}
        COLLISION_AREA_TYPE _areaType;
        
    };
    
public:
    SimpleCollisionManager();
    virtual ~SimpleCollisionManager();
    
public:
    
    //  claimCollisionArea function acts as a simple factory for [CollisionArea].
    //
    //  Different types of [CollisionArea] will be generated according to the
    //  configName parameter. However, the end user of these generated instances
    //  will only understand it at the interface level. All they need to do and can
    //  do is to bind the [CollisionArea] instance to the object they want.
    //
    //  [SimpleCollisionManager] does not offer a pool for collisionArea.
    //
    //  Every time a user claim an [CollisionArea], [SimpleCollisionManager] will allocate
    //  a new instance for him. And if the user reclaim the [CollisionArea] they claimed
    //  beforehand, it will simply be deleted.
    
    virtual CollisionArea* claimCollisionArea(const std::string &configName);
    virtual void reclaimCollisionArea(CollisionArea* collisionArea);
    
    //  An instance of [CollisionArea] claimed by the end user need to be registered
    //  to the [CollisionManager] to add into the collision space. Only registered
    //  [CollisionArea] will be handled by [CollisionManager].

    virtual void registerArea(CollisionArea* area);
    virtual void unregisterArea(CollisionArea* area);
    
    //  Update action of [SimpleCollisionManager] includes the following phases
    //
    //      1.  Transform all shapes with the node they are binded to.
    //      2.  Project the transformed shapes onto 2D view plane.
    //      3.  Caculate aabb for each projected shape.
    //      4.  Put shapes into the regions the covered.
    //      5.  For each region do collision detection between groups of shapes.
    //      6.  Generate collision events.
    
    virtual void update(float dt);
    
    // 读取碰撞包围体的配置文件
    //
    // PARAMS:
    //      -- configName: 文件名
    //      -- type: 包围体类型
    //
    // PS:
    //      目前支持两种类型的包围体，FISH以及BULLET，定义在COLLISION_AREA_TYPE枚举当中
    //
    bool readConfig(const std::string &configName,const std::string &configPath, COLLISION_AREA_TYPE type);
    
protected:
    
    // This struct describes an axis-alligned 2D aabb with min-max pattern

    struct MinMax
    {
        float _minX;
        float _minY;
        float _maxX;
        float _maxY;
    };
    
    // This struct describes an projected hexahedron with its eight vertices defined
    
    struct ShapeProjected
    {
        CollisionArea* _parent;
        cocos2d::Vec2 _vertex[8];
    };
    
    //  Pre-edited collision shape configs, these shapes are stored in config files
    //  exported by editor software, and will be loaded during initialization progress
    
    typedef std::map<std::string, ConfigList> ConfigCache;
    
    //  Only registered [CollisionArea] will be handled by [CollisionManager], when
    //  to add or remove a [CollisionArea] is totally controled by users
    
    typedef std::list<CollisionArea*> AreaList;
    
    //  After each frame, collision shapes will be transformed by the object they were
    //  binding to and finally projected onto the view plane. Also, an aabb of the projected
    //  shape is generated during this progress for fast pruning.
    //
    //  This data structure cached the result of the manipulations above for each shape,
    //  in order to remove redundant calculation action in collision detection phase.
    //
    //  This data structure will be refreshed in each frame.
    
    typedef std::pair<ShapeProjected, MinMax> TransformedShapeInfo;
    typedef std::vector<TransformedShapeInfo> TransformedShapeCache;
    
    //  The game world is recognized as groups of square regions by the [CollisionManager].
    //  Each projected shape will finally be put into one or more of these regions, according to
    //  its aabb. During the collision detection phase, only shapes in the same region will
    //  be checked to reduce calculation overhead.
    //
    //  This data structure will be refreshed in each frame.
    //
    //  PS:
    //      No complicated data structure like quad tree is used here for space partitioning
    //      because the implementation overhead is too big.
    
    typedef std::vector<std::vector<std::vector<TransformedShapeInfo*>>> RegionCache;
    
    // Size of each storage data structure, used for pre allocation.
    
    struct {
        
        int _shapeCacheSize;
        int _regionCacheSize;
        int _regionX;
        int _regionY;
        int _regionSize;
        int startX;
        int startY;
        
    } _CONST;
    
    // Instances of the storage data structure declared above.
    
    std::vector<ConfigCache> _configs;
    AreaList _registeredAreas;
    AreaList _removedAreas;
    TransformedShapeCache _transformedShapes;
    RegionCache _divisions;
    
private:
    
    
    // 初始化碰撞管理器所需的一些常量
    //
    // PS:
    //      常量定义在 _CONST结构体实例当中
    //
    void initConstants();
    
    
    // 初始化用于存放缓存对象的内存空间
    //
    void allocateCaches();
    
    // 释放化用于存放缓存对象的内存空间
    //
    void deallocateCaches();
    
    // 清理缓存空间内的缓存对象
    //
    // ATTENTION:
    //      该函数与deallocateCaches功能不同，deallocate函数将释放内存地址空间，用于管理器对象的销毁
    //      clear函数用于清除上一次碰撞检测操作过程中产生的缓存对象，为下一次检测操作做准备。
    //
    void clearCaches();
    
    // 销毁被移除操作所标记的CollisionArea对象
    //
    // PS:
    //      当用户调用reclaimCollisionArea函数时，传入的CollisionArea对象不会被立即销毁，而是转入
    //      一个专用的销毁队列（_removedAreas）当中，管理器的update函数在执行的最后阶段会对销毁队列
    //      当中的对象进行统一清理。
    //
    //      由于在碰撞检测过程当中TransformedShape与CollisionArea处于一种强连接关系，所以不能在检测
    //      过程当中直接销毁被用户释放的CollisionArea对象，由于CollisionArea并未继承自Ref基类所以无
    //      法参与cocos的计数式内存引用管理，故由碰撞管理器在Update函数执行的最后阶段进行延迟销毁。
    //
    void finishRemovedAreas();
    
    // 读取游戏所需的所有包围体配置文件
    //
    // PS:
    //      该函数在碰撞管理器的初始化阶段执行，调用readConfig函数依次读入游戏所需的包围体配置文件
    //      进入管理器的缓存当中
    //
    void loadConfigs();
    
    // 读取游戏所需的所有包围体配置文件
    //
    // PARAM:
    //      -- info: 碰撞检测描述对象的引用，
    //      -- r | c | h : 碰撞体描述对象的引用
    //      -- transform : 碰撞题变换矩阵的引用
    //
    // PS:
    //      碰撞检测的每一次更新都会根据碰撞体绑定对象的变换矩阵对碰撞体进行变换操作，
    //      操作产生的碰撞检测信息存放于TransformedShapeInfo的实例当中，TransformedShapeInfo
    //      中包含了包围体经过变换和投影操作后所获得的最终结果（2D Vertex Position & AABB）
    //
    void pushShape(TransformedShapeInfo& info, CollisionShape::R& r, cocos2d::Mat4& transform,const cocos2d::Mat4 &proj_mat4);
    void pushShape(TransformedShapeInfo& info, CollisionShape::C& c, cocos2d::Mat4& transform, const cocos2d::Mat4 &proj_mat4);
    void pushShape(TransformedShapeInfo& info, CollisionShape::H& h, cocos2d::Mat4& transform, const cocos2d::Mat4 &proj_mat4);
    
    // 将描述对象放入其对应区域的缓存列表当中
    //
    // PARAMS:
    //      -- info: 碰撞检测描述对象的引用
    //      -- type: 碰撞体类型的引用
    //
    // PS:
    //      为了减少不必要的检测操作，碰撞管理器对游戏的可视区域进行了划分，只有处于
    //      同一划分区域内的碰撞体才会接受碰撞检测。
    //
    //      根据捕鱼游戏的需求，只有子弹和鱼之间会产生碰撞信息，为了快速索引这两种不同
    //      类型的碰撞体，每个区域都包含了两个独立的缓存链表，分别对两种类型的检测信息进行
    //      存放
    //
    void settleShape(TransformedShapeInfo& info, COLLISION_AREA_TYPE& type);
    
    // AABB的碰撞检测实现
    //
    bool intersectAABB(MinMax& a, MinMax& b);
    
    // SAT碰撞检测的实现函数族
    //
    // PS:
    //      根据目前的需求，子弹的碰撞形均为圆形（或圆形的组合），而鱼的碰撞形则是3D OBB，
    //      所以这里只实现了圆形与多边形之间的SAT检测实现（SAT算法具体过程这里不再描述）
    //
    //      3D OBB在投影之后的边缘形状不固定，由于边缘检测需要提供额外的算法实现，所以这里
    //      采用了一个比较简单的办法来规避这一问题，即分别检测OBB的六个面投影与圆之间是否产生碰撞。
    //
    //
    // 圆形与OBB投影形之间的检测
    bool circleHexSAT(ShapeProjected& circle, ShapeProjected& hex);
    // 圆形与四边形之间的检测
    bool circleQuadSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius);
    // 圆形与边之间的检测
    bool circleAxisSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius);
    // 圆形与顶点之间的检测
    bool circleVertexSAT(cocos2d::Vec2& p1, cocos2d::Vec2& p2, cocos2d::Vec2& p3, cocos2d::Vec2& p4, cocos2d::Vec2& center, float& radius);
    
    // 解析碰撞体配置文件的功能函数
    //
    // PS:
    //      如上，封装了从JSON文件中获取对象信息的操作，这里不做详细说明。
    //
    void loadHex(CollisionShape::Shape& hex, rapidjson::Value& jsonValue);
    void loadConfigData(ConfigData& data, rapidjson::Value& jsonValue);
    void loadRct(CollisionShape::Shape& rct, rapidjson::Value& jsonValue);
    void loadCrl(CollisionShape::Shape& rct, rapidjson::Value& jsonValue);
    void loadVec3(cocos2d::Vec3& vec, rapidjson::Value& jsonValue);
    
    cocos2d::Bone3D* getBone(cocos2d::Skeleton3D* skeleton, int boneIndex);
    
    friend class ::GameDebugger;
    
};

}
#endif
