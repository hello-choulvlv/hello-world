/****************************************************************************
Copyright (c) 2008-2010 Ricardo Quesada
Copyright (c) 2010-2012 cocos2d-x.org
Copyright (c) 2011      Zynga Inc.
Copyright (c) 2013-2016 Chukong Technologies Inc.

http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/
#include "2d/CCLabelAtlas.h"
#include "renderer/CCTextureAtlas.h"
#include "platform/CCFileUtils.h"
#include "base/CCDirector.h"
#include "base/ccUTF8.h"
#include "renderer/CCTextureCache.h"
#include "2d/CCSpriteFrameCache.h"
#include "renderer/CCRenderer.h"
#include "2d/CCFontAtlasCache.h"

#if CC_LABELATLAS_DEBUG_DRAW
#include "renderer/CCRenderer.h"
#endif

NS_CC_BEGIN

//CCLabelAtlas - Creation & Init

LabelAtlas::LabelAtlas():
_texture(nullptr)
,_spriteFrame(nullptr)
,_quad(nullptr)
,_indice_array(nullptr)
,_quadCapacity(0)
,_quadCount(0)
,_itemWidth(0)
,_itemHeight(0)
,_itemsPerRow(0)
,_itemsPerColumn(0)
,_mapStartChar(0)
,_useCharMap(false)
,_isOpacityModifyRGB(true)
,_isColorDirty(false)
, _blendFunc(BlendFunc::ALPHA_PREMULTIPLIED) {
}

LabelAtlas::~LabelAtlas(){
    if(_texture != nullptr)
        _texture->release();
    if(_spriteFrame != nullptr)
        _spriteFrame->release();
    delete[] _quad;
    delete[] _indice_array;
}

LabelAtlas* LabelAtlas::create()
{
    LabelAtlas* ret = new (std::nothrow) LabelAtlas();
    if (ret != nullptr)
        ret->autorelease();
    else{
        CC_SAFE_RELEASE_NULL(ret);
    }
    
    return ret;
}

LabelAtlas* LabelAtlas::create(const std::string& string, const std::string& charMapFile, int itemWidth, int itemHeight, int startCharMap)
{
    LabelAtlas* ret = new (std::nothrow) LabelAtlas();
    if(ret && ret->initWithString(string, charMapFile, itemWidth, itemHeight, startCharMap))
    {
        ret->autorelease();
        return ret;
    }
    CC_SAFE_DELETE(ret);
    return nullptr;
}

bool LabelAtlas::initWithString(const std::string& string_l2, const std::string& charMapFile, int itemWidth, int itemHeight, int startCharMap)
{
    Node::init();
    if(charMapFile.at(0) == '#'){
        //std::string s2 = charMapFile.substr(1,charMapFile.size() - 1);
        _spriteFrame = SpriteFrameCache::getInstance()->getSpriteFrameByName(charMapFile.substr(1,charMapFile.size() - 1));
        CCASSERT(_spriteFrame != nullptr, "sprite frame not found");
        _spriteFrame->retain();
        const Rect &rect = _spriteFrame->getRect();
        _itemsPerRow = rect.size.height/itemHeight;
        _itemsPerColumn = rect.size.width/itemWidth;
    }
    else{
        _texture = Director::getInstance()->getTextureCache()->addImage(charMapFile);
        CCASSERT(_texture != nullptr, "_texturenot found");
        _texture->retain();
        
        const Size size = _texture->getContentSize();
        _itemsPerRow = size.height/itemHeight;
        _itemsPerColumn = size.width/itemWidth;
    }
    //如果字符串只是表示纹理集与字符串之间的映射
    if (startCharMap == -1)
    {
        updateCharMap(string_l2);
        _useCharMap = true;
    }
    
    _itemWidth = itemWidth;
    _itemHeight = itemHeight;
    _mapStartChar = startCharMap;
    
    if(!_useCharMap)
        this->setString(string_l2);
    setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR_NO_MVP));
    return true;
}

bool LabelAtlas::initWithString(const std::string& string_l2, Texture2D* texture, int itemWidth, int itemHeight, int startCharMap){
    Node::init();
    _texture = texture;
    CCASSERT(_texture != nullptr, "_texturenot found");
    _texture->retain();
    const Size size = _texture->getContentSize();
    _itemsPerRow = size.height/itemHeight;
    _itemsPerColumn = size.width/itemWidth;
    //如果字符串只是表示纹理集与字符串之间的映射
    if (startCharMap == -1)
    {
        updateCharMap(string_l2);
        _useCharMap = true;
    }
    
    _itemWidth = itemWidth;
    _itemHeight = itemHeight;
    _mapStartChar = startCharMap;
    
    if(!_useCharMap)
        this->setString(string_l2);
    setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR_NO_MVP));
    return true;
}

void  LabelAtlas::updateCharMap(const std::string &charSequence)
{
    _charMap.clear();
    for (int i = 0; i < charSequence.size(); ++i)
    {
        _charMap[charSequence[i]] = i;
    }
}

//CCLabelAtlas - Atlas generation
void LabelAtlas::updateAtlasValues()
{
    //update quad
    ssize_t n = _string.length();
    if(!_quad || n > _quadCapacity){
        delete[] _quad;
        delete[] _indice_array;
        _quadCapacity = (int32_t)n;
        _quad = new V3F_C4B_T2F_Quad[_quadCapacity];
        _indice_array = new uint16_t[_quadCapacity * 6];
        
        _triangle.verts = (V3F_C4B_T2F *)_quad;
        _triangle.indices = _indice_array;
    }
    _quadCount = (int32_t)n;

    const uint8_t *s = (const uint8_t*)_string.c_str();
    //Texture2D *texture = _textureAtlas->getTexture();
    Rect   frame_rect;
    if(_spriteFrame != nullptr) frame_rect = _spriteFrame->getRect();
    //const Size  texture_size = _spriteFrame?_spriteFrame->getTexture()->getContentSize() : _texture->getContentSize();
    
    float textureWide = _spriteFrame?_spriteFrame->getTexture()->getPixelsWide() : _texture->getPixelsWide();
    float textureHigh = _spriteFrame?_spriteFrame->getTexture()->getPixelsHigh() : _texture->getPixelsHigh();
    
    float itemWidthInPixels = _itemWidth* CC_CONTENT_SCALE_FACTOR();
    float itemHeightInPixels = _itemHeight * CC_CONTENT_SCALE_FACTOR();

    Color4B color4(_displayedColor.r, _displayedColor.g, _displayedColor.b, _displayedOpacity);
    if (_isOpacityModifyRGB)
    {
        color4.r *= _displayedOpacity/255.0f;
        color4.g *= _displayedOpacity/255.0f;
        color4.b *= _displayedOpacity/255.0f;
    }
    bool  b2_rotate = _spriteFrame?_spriteFrame->isRotated():false;
    
    //像素以左上角为参照基准,这样计算具有多行纹理集的时候,会更方便一些
    float  ws = _texture?itemWidthInPixels/textureWide:(b2_rotate?itemHeightInPixels/textureWide:itemWidthInPixels/textureWide);
    float  hs = _texture?itemHeightInPixels/textureHigh:(b2_rotate?itemWidthInPixels/textureHigh:itemHeightInPixels/textureHigh);
    
    float  s0 = _texture?0.0f : (b2_rotate? (frame_rect.origin.x + frame_rect.size.height)/textureWide : frame_rect.origin.x/textureWide);
    float  t0 = _texture?0.0f : frame_rect.origin.y/textureHigh;
    
    for(ssize_t i = 0; i < n; i++) {
        uint32_t a_index = !_useCharMap ? s[i] - _mapStartChar : _charMap[s[i]];
        float column = a_index % _itemsPerColumn;
        float row = a_index / _itemsPerColumn;
        
        V3F_C4B_T2F_Quad  &qauad = _quad[i];
        //left bottom
        float  x0 = _texture?column * ws : (b2_rotate?s0 - (row + 1) * ws: s0 + column * ws);
        float  y0 = _texture? (row + 1) * hs : (b2_rotate?t0 + column * hs : t0 + hs* (row + 1));
        //right top
        float  x1 = _texture?(column + 1) * ws: (b2_rotate?s0 + ws * row : s0 + (column + 1) * ws);
        float  y1 = _texture?row *  hs: (b2_rotate ? t0 + (column + 1) * hs : t0 + hs * row);
        
        qauad.bl.vertices.x = i * _itemWidth;
        qauad.bl.vertices.y = 0;
        qauad.bl.vertices.z = 0.0f;
        qauad.bl.texCoords.u = x0;
        qauad.bl.texCoords.v = y0;
        qauad.bl.colors = color4;
        
        qauad.br.vertices.x = i * _itemWidth + _itemWidth;
        qauad.br.vertices.y = 0;
        qauad.br.vertices.z = 0.0f;
        qauad.br.texCoords.u = b2_rotate? x0: x1;
        qauad.br.texCoords.v = b2_rotate? y1 : y0;
        qauad.br.colors = color4;
        
        qauad.tl.vertices.x = i * _itemWidth;
        qauad.tl.vertices.y = _itemHeight;
        qauad.tl.vertices.z = 0.0f;
        qauad.tl.texCoords.u = b2_rotate? x1 : x0;
        qauad.tl.texCoords.v = b2_rotate? y0 : y1;
        qauad.tl.colors = color4;
        
        qauad.tr.vertices.x = i * _itemWidth + _itemWidth;
        qauad.tr.vertices.y = _itemHeight;
        qauad.tr.vertices.z = 0.0f;
        qauad.tr.texCoords.u = x1;
        qauad.tr.texCoords.v = y1;
        qauad.tr.colors = color4;
        
        int32_t  base_l = (int32_t)i * 6,index_l =(int32_t) i * 4;
        _indice_array[base_l] = index_l;
        _indice_array[base_l + 1] = index_l + 1;
        _indice_array[base_l + 2] = index_l + 2;
        _indice_array[base_l + 3] = index_l + 2;
        _indice_array[base_l + 4] = index_l + 1;
        _indice_array[base_l + 5] = index_l + 3;
    }
    
    _isColorDirty = false;
    _triangle.vertCount = _quadCount * 4;
    _triangle.indexCount = _quadCount * 6;
}

//CCLabelAtlas - LabelProtocol
void LabelAtlas::setString(const std::string &label)
{
    ssize_t len = label.size();
    if(label != _string){
        _string = label;
        
        this->updateAtlasValues();
        Size s = Size(len * _itemWidth, _itemHeight);
        this->setContentSize(s);
    }
}

const std::string& LabelAtlas::getString(void) const
{
    return _string;
}

void LabelAtlas::setColor(const Color3B& color) {
    if (color != this->_displayedColor) {
        Node::setColor(color);
        _isColorDirty = true;
    }
}

void LabelAtlas::setOpacity(GLubyte opacity) {
    if (opacity != _displayedOpacity) {
        Node::setOpacity(opacity);
        _isColorDirty = true;
    }
}

void LabelAtlas::updateDisplayedOpacity(GLubyte opacity) {
    if (_displayedOpacity != opacity) {
        Node::updateDisplayedOpacity(opacity);
        _isColorDirty = true;
    }
}

void LabelAtlas::updateColor()
{
    Color4B color4( _displayedColor.r, _displayedColor.g, _displayedColor.b, _displayedOpacity);
    if (_isOpacityModifyRGB)
    {
        color4.r *= _displayedOpacity/255.0f;
        color4.g *= _displayedOpacity/255.0f;
        color4.b *= _displayedOpacity/255.0f;
    }

    ssize_t length = _string.length();
    for (int index = 0; index < length; index++)
    {
        _quad[index].bl.colors = color4;
        _quad[index].br.colors = color4;
        _quad[index].tl.colors = color4;
        _quad[index].tr.colors = color4;
    }
    _isColorDirty = false;
}

void LabelAtlas::setBlendFunc(const BlendFunc &blend) {
    if (blend != _blendFunc) {
        _blendFunc = blend;
        bool b2 = blend.src == GL_ONE;
        if (b2 != _isOpacityModifyRGB) {
            _isColorDirty = b2;
            _isOpacityModifyRGB = b2;
        }
    }
}

void LabelAtlas::draw(Renderer *renderer, const Mat4 &transform, uint32_t flags)
{
    if (!_visibilityTest || (_quadCount && renderer->checkVisibility(transform, _contentSize))) {
        //_quadCommand.init(_globalZOrder, _texture?_texture->getName():_spriteFrame->getTexture()->getName(), _glProgramState, _blendFunc, _quad, _quadCount, transform, flags);
       // renderer->addCommand(&_quadCommand);
        if(_isColorDirty)
            updateColor();
        _triangleCommand.init(_globalZOrder,_texture?_texture:_spriteFrame->getTexture(),_glProgramState,_blendFunc,_triangle,transform,flags);
        renderer->addCommand(&_triangleCommand);
    }
}

std::string LabelAtlas::getDescription() const
{
    return StringUtils::format("<LabelAtlas | Tag = %d, Label = '%s'>", _tag, _string.c_str());
}

/////////////////////////////LabelFrameAtlas////////////////////////////////
LabelFrameAtlas::LabelFrameAtlas(const std::string &frame_name_format) :_frameNameFormat(frame_name_format)
, _quads(nullptr)
,_indice_array(nullptr)
, _quadCount(0)
, _quadCapacity(0)
, _isContentDirty(false)
, _isUseSecondary(false)
, _isColorDirty(false)
, _isModifyColor(true)
, _textureRef(nullptr)
, _blendFunc(BlendFunc::ALPHA_PREMULTIPLIED) {
}

LabelFrameAtlas::~LabelFrameAtlas() {
    delete[] _quads;
    _quads = nullptr;
    
    delete[] _indice_array;
    _indice_array = nullptr;
}

LabelFrameAtlas *LabelFrameAtlas::create(const std::string &frame_name_format) {
    LabelFrameAtlas *object = new LabelFrameAtlas(frame_name_format);
    if (object->init()) {
        object->autorelease();
        return object;
    }
    object->release();
    object = nullptr;
    return nullptr;
}

bool LabelFrameAtlas::init() {
    Node::init();
    setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR_NO_MVP));
    return true;
}

void LabelFrameAtlas::setFrameFormat(const std::string &frame_format) {
    if (_frameNameFormat != frame_format || _isUseSecondary) {
        _frameNameFormat = frame_format;
        _isContentDirty = true;
        _isUseSecondary = false;

        this->updateQuadContent();
    }
}

void LabelFrameAtlas::setString(const std::string &str_content) {
    if (this->_strContent != str_content || _isUseSecondary) {
        this->_strContent = str_content;
        _isContentDirty = true;
        _isUseSecondary = false;

        this->updateQuadContent();
    }
}

void LabelFrameAtlas::setString(const std::string &str_content, const std::string &secondary_format) {
    bool b2 = this->_strContent != str_content;
    bool b3 = this->_secondaryFormat != secondary_format;
    bool b4 = b2 || b3;

    if (b2)this->_strContent = str_content;
    if (b3)_secondaryFormat = secondary_format;


    if (b4 || !_isUseSecondary)
        _isContentDirty = true;

    _isUseSecondary = true;

    this->updateQuadContent();
}

const std::string& LabelFrameAtlas::getString()const {
    return _strContent;
}

void LabelFrameAtlas::updateQuadContent() {
    const int str_length = static_cast<int>(_strContent.length());
    //计算需要的Quad单元的数目
    int  quad_count = 0;
    const char *str = _strContent.c_str();
    bool b2_found = false;
    for(int k=0;k<str_length;++k){
        if(!b2_found){
            if(str[k] == '@')
                b2_found = true;
            ++quad_count;
        }else{
            if(str[k] == '@')
                b2_found = false;
        }
    }
    
    bool b2 = false;
    int   inc_number = 4;
    if (quad_count > _quadCapacity) {
        b2 = true;
        inc_number = 16;
    }
    else if (quad_count > 16 && quad_count < (_quadCapacity >> 2))
        b2 = true;

    if (b2) {
        delete[] _quads;
        delete[] _indice_array;
        _quads = new V3F_C4B_T2F_Quad[quad_count + inc_number];
        _quadCapacity = str_length + inc_number;
        
        _indice_array = new uint16_t[_quadCapacity * 6];
        _triangle.verts = (V3F_C4B_T2F *)_quads;
        _triangle.indices = _indice_array;
    }
    _quadCount = 0;
    float s2f = _isModifyColor ? _displayedOpacity/255.0f:1.0f;
    Color4B     color(GLubyte(_displayedColor.r * s2f), GLubyte(_displayedColor.g * s2f), GLubyte(_displayedColor.b * s2f), _displayedOpacity);

    const char *format = _isUseSecondary ? _secondaryFormat.c_str() : _frameNameFormat.c_str();
    char  c_array[32];// = {0};
    int real_numner = 0;
    int texture_id = -1;//debug,所有的frame都必须来自于同一个纹理,否则报错
    float offset_x = 0;
    float max_height = 0.0f;
    //Size content_size;
    for (int j = 0; j < str_length; /*++j*/) {
        if(str[j] != '@'){
            c_array[0] = str[j];
            c_array[1] = 0;
            ++j;
        }else{
            //注意,有可能分隔符中间的字符会解析失败,此时什么都不用做
            int k=0;
            while(++j < str_length && str[j] != '@'){
                c_array[k++] = str[j];
            }
            //此时,要么j指向最后的字符串结尾,要么指向@,如果指向了结尾,则此时也可以视为分词的结束
            c_array[k] = 0;
            ++j;
            //如果没有任何的字符,则进行下一轮的循环
            if(! k)continue;
        }
        char buffer[256];
        sprintf(buffer, format, c_array);
        SpriteFrame  *frame = SpriteFrameCache::getInstance()->getSpriteFrameByName(buffer);
        if (!frame) {
            CCLOG("could not find frame '%s'", buffer);
            continue;
        };
        _textureRef = frame->getTexture();
        int s2_id = _textureRef->getName();
        if (texture_id == -1)texture_id = s2_id;
        if (texture_id != s2_id) {
            CCLOG("could not render LabelFrameAtlas by diffent texture.");
            break;
        }

        real_numner += 1;
        V3F_C4B_T2F_Quad &quad = _quads[_quadCount];
        bool is_rotate = frame->isRotated();
        //const size
        Size content_size = _textureRef->getContentSize();
        float width = content_size.width;
        float height = content_size.height;
        const Rect &frame_rect = frame->getRect();
        auto &size = frame_rect.size;
        //注意cocos2d的纹理坐标与OpenGL的纹理坐标有着显著的不同
        float w = is_rotate ? size.height : size.width;
        float h = is_rotate ? size.width : size.height;

        float sw = w / width;
        float sh = h / height;

        float x0 = is_rotate ? (frame_rect.origin.x + size.height) / width : frame_rect.origin.x / width;
        float y0 = frame_rect.origin.y / height;

        quad.tl.colors = color;
        quad.tl.texCoords.u = x0; quad.tl.texCoords.v = y0;
        quad.tl.vertices.x = offset_x; quad.tl.vertices.y = size.height; quad.tl.vertices.z = 0.0f;

        x0 = is_rotate ? x0 - sw : x0;
        y0 = is_rotate ? y0 : y0 + sh;

        quad.bl.colors = color;
        quad.bl.texCoords.u = x0; quad.bl.texCoords.v = y0;
        quad.bl.vertices.x = offset_x; quad.bl.vertices.y = 0; quad.bl.vertices.z = 0.0f;

        x0 = is_rotate ? x0 : x0 + sw;
        y0 = is_rotate ? y0 + sh : y0;

        quad.br.colors = color;
        quad.br.texCoords.u = x0; quad.br.texCoords.v = y0;
        quad.br.vertices.x = offset_x + size.width; quad.br.vertices.y = 0.0f; quad.br.vertices.z = 0.0f;

        x0 = is_rotate ? x0 + sw : x0;
        y0 = is_rotate ? y0 : y0 - sh;

        quad.tr.colors = color;
        quad.tr.texCoords.u = x0; quad.tr.texCoords.v = y0;
        quad.tr.vertices.x = offset_x + size.width; quad.tr.vertices.y = size.height; quad.tr.vertices.z = 0.0f;

        offset_x += size.width;
        max_height = fmaxf(max_height, size.height);
        
        int32_t  base_l = _quadCount * 6,index_l = _quadCount * 4;
        _indice_array[base_l] = index_l;
        _indice_array[base_l + 1] = index_l + 1;
        _indice_array[base_l + 2] = index_l + 2;
        _indice_array[base_l + 3] = index_l + 2;
        _indice_array[base_l + 4] = index_l + 1;
        _indice_array[base_l + 5] = index_l + 3;
        
        _quadCount += 1;
    }

    _triangle.vertCount = _quadCount * 4;
    _triangle.indexCount = _quadCount * 6;

    _isContentDirty = false;
    this->setContentSize(Size(offset_x, max_height));
}

void LabelFrameAtlas::setColor(const Color3B& color) {
    if (color != this->_displayedColor) {
        Node::setColor(color);
        _isColorDirty = true;
    }
}

void LabelFrameAtlas::setOpacity(GLubyte opacity) {
    if (opacity != _displayedOpacity) {
        Node::setOpacity(opacity);
        _isColorDirty = true;
    }
}

void LabelFrameAtlas::updateDisplayedOpacity(GLubyte opacity) {
    if (_displayedOpacity != opacity) {
        Node::updateDisplayedOpacity(opacity);
        _isColorDirty = true;
    }
}

void LabelFrameAtlas::updateColor() {
    float s2f = _isModifyColor?_displayedOpacity/255.0f:1.0f;
    Color4B color(GLubyte(_displayedColor.r*s2f), GLubyte(_displayedColor.g * s2f), GLubyte(_displayedColor.b * s2f), _displayedOpacity);
    for (int j = 0; j < _quadCount; ++j) {
        V3F_C4B_T2F_Quad &quad = _quads[j];
        quad.tl.colors = color;
        quad.bl.colors = color;
        quad.br.colors = color;
        quad.tr.colors = color;
    }
}

void LabelFrameAtlas::setBlendFunc(const BlendFunc &blend) {
    if (blend != _blendFunc) {
        _blendFunc = blend;
        bool b2 = blend.src == GL_ONE;
        if (b2 != _isModifyColor) {
            _isColorDirty = true;
            _isModifyColor = b2;
        }
    }
}

void LabelFrameAtlas::draw(Renderer *renderer, const Mat4& transform, uint32_t flags) {
    if (_isContentDirty) {
        updateQuadContent();
        _isContentDirty = false;
        _isColorDirty = false;
    }
    if (!_quadCount) return;
    if (_isColorDirty) {
        updateColor();
        _isColorDirty = false;
    }
    //bool visibility = _visibilityTest && renderer->checkVisibility(transform, _contentSize);
    if (!_visibilityTest || renderer->checkVisibility(transform, _contentSize)) {
       // _quadCommand.init(_globalZOrder, _textureRef, _glProgramState, _blendFunc, const Triangles &triangles, const Mat4 &mv, uint32_t flags);
        //_quadCommand.init(_globalZOrder, _textureRef->getName(), _glProgramState, _blendFunc, _quads, _quadCount, transform, flags);
        //renderer->addCommand(&_quadCommand);
        _triangleCommand.init(_globalZOrder,_textureRef,_glProgramState,_blendFunc,_triangle,transform,flags);
        renderer->addCommand(&_triangleCommand);
    }
}

//---------------------------------LabelFnt---------------------------------------
LabelFnt::LabelFnt():_fontAtlas(nullptr)
,_quads(nullptr)
,_indice_array(nullptr)
,_quadCount(0)
,_quadCapacity(0)
, _blendFunc(BlendFunc::ALPHA_PREMULTIPLIED)
,_isOpacityModifyRGB(true)
,_isColorDirty(false){
}

LabelFnt::~LabelFnt(){
    delete[] _quads;
    _quads = nullptr;
    delete[] _indice_array;
    _indice_array = nullptr;
    _fontAtlas->release();
}

bool  LabelFnt::initWithFntFile(const std::string &fnt_path, const std::string &label_string){
    Node::init();
    _fontAtlas = FontAtlasCache::getFontAtlasFNT(fnt_path);
    CCASSERT(_fontAtlas != nullptr, "could not find fnt file");
    _fontAtlas->retain();
    setGLProgramState(GLProgramState::getOrCreateWithGLProgramName(GLProgram::SHADER_NAME_POSITION_TEXTURE_COLOR_NO_MVP));
    setString(label_string);
    return true;
}

void LabelFnt::setBMFontFilePath(const std::string &fnt_file){
    FontAtlas *font_atlas = FontAtlasCache::getFontAtlasFNT(fnt_file);
    if(font_atlas != _fontAtlas){
        _fontAtlas->release();
        _fontAtlas = font_atlas;
        CCASSERT(font_atlas != nullptr, "font atlas fnt file coud not be null");
        _fontAtlas->retain();
        updateQuadContent();
    }
}

LabelFnt  *LabelFnt::createWithFntFile(const std::string &fnt_path, const std::string &label_string){
    LabelFnt  *label = new LabelFnt();
    label->initWithFntFile(fnt_path, label_string);
    label->autorelease();
    return label;
}

void LabelFnt::setBlendFunc(const BlendFunc &blend) {
    if (blend != _blendFunc) {
        _blendFunc = blend;
        bool b2 = blend.src == GL_ONE;
        if (b2 != _isOpacityModifyRGB) {
            _isOpacityModifyRGB = b2;
            _isColorDirty = true;
        }
    }
}

void LabelFnt::setString(const std::string &label_string){
    if(label_string != _labelString){
        _labelString = label_string;
        StringUtils::UTF8ToUTF16(label_string, _utf16String);
        updateQuadContent();
    }
}

void LabelFnt::updateQuadContent(){
    int32_t  str_len = (int32_t)_utf16String.size();
    if(!_quads || str_len > _quadCapacity){
        delete[] _quads;
        delete[] _indice_array;
        
        _quadCapacity = str_len;
        _quads = new V3F_C4B_T2F_Quad[str_len];
        _indice_array = new uint16_t[_quadCapacity * 6];
        
        _triangle.verts = (V3F_C4B_T2F *)_quads;
        _triangle.indices = _indice_array;
    }
    Color4B color4( _displayedColor.r, _displayedColor.g, _displayedColor.b, _displayedOpacity);
    if (_isOpacityModifyRGB){
        float f4 = _displayedOpacity/255.0f;
        color4.r *= f4;
        color4.g *= f4;
        color4.b *= f4;
    }
    SpriteFrame  *sprite_frame = _fontAtlas->getSpriteFrame();
    Texture2D     *texture = _fontAtlas->getTexture(0);
    bool b2_rotate = sprite_frame != nullptr ? sprite_frame->isRotated() : false;
    float pixel_width = texture->getPixelsWide();
    float pixel_height = texture->getPixelsHigh();
    float offset_x = 0,max_height = 0;
    float factor = 1.0f /CC_CONTENT_SCALE_FACTOR();
    
    _quadCount = 0;
    for (int j = 0; j < str_len; ++j) {
        const FontLetterDefinition  *letter_def= _fontAtlas->getLetterDefinitionForChar(_utf16String[j]);
        CCASSERT(letter_def !=nullptr,"could not render extra letter");
        //const size
        const Rect *frame_rect = sprite_frame?&sprite_frame->getRectInPixels() : nullptr;
        // u + v
        float  u_left = sprite_frame?(b2_rotate?(frame_rect->origin.x + frame_rect->size.height -  letter_def->V - letter_def->offsetY)/pixel_width : (frame_rect->origin.x + letter_def->U + letter_def->offsetX)/pixel_width) : (letter_def->U + letter_def->offsetX)/pixel_width;
        float  u_right = sprite_frame?(b2_rotate?(frame_rect->origin.x + frame_rect->size.height -  letter_def->V - letter_def->offsetY - letter_def->height)/pixel_width : (frame_rect->origin.x + letter_def->U + letter_def->offsetX + letter_def->width)/pixel_width) : (letter_def->U + letter_def->offsetX + letter_def->width)/pixel_width;
        
        float v_top = sprite_frame?(b2_rotate?(frame_rect->origin.y + letter_def->U + letter_def->offsetX)/pixel_height : (frame_rect->origin.y + letter_def->V + letter_def->offsetY)/pixel_height) : (letter_def->V + letter_def->offsetY)/pixel_height;
        float v_bottom = sprite_frame?(b2_rotate?(frame_rect->origin.y + letter_def->U + letter_def->offsetX + letter_def->width)/pixel_height : (frame_rect->origin.y + letter_def->V + letter_def->offsetY + letter_def->height)/pixel_height) : (letter_def->V + letter_def->offsetY + letter_def->height)/pixel_height;

        V3F_C4B_T2F_Quad &quad = _quads[_quadCount];
        quad.tl.colors = color4;
        quad.tl.texCoords.u = u_left;
        quad.tl.texCoords.v = v_top;
        quad.tl.vertices.x = offset_x; quad.tl.vertices.y = letter_def->height; quad.tl.vertices.z = 0.0f;

        quad.bl.colors = color4;
        quad.bl.texCoords.u = b2_rotate?u_right : u_left;
        quad.bl.texCoords.v = b2_rotate?v_top : v_bottom;
        quad.bl.vertices.x = offset_x; quad.bl.vertices.y = 0; quad.bl.vertices.z = 0.0f;

        quad.br.colors = color4;
        quad.br.texCoords.u = u_right;
        quad.br.texCoords.v = v_bottom;
        quad.br.vertices.x = offset_x + letter_def->xAdvance * factor;
        quad.br.vertices.y = 0.0f; quad.br.vertices.z = 0.0f;

        quad.tr.colors = color4;
        quad.tr.texCoords.u = b2_rotate?u_left : u_right;
        quad.tr.texCoords.v = b2_rotate? v_bottom : v_top;
        quad.tr.vertices.x = offset_x + letter_def->xAdvance * factor;
        quad.tr.vertices.y = letter_def->height; quad.tr.vertices.z = 0.0f;

        offset_x += letter_def->xAdvance * factor;
        max_height = fmaxf(max_height, letter_def->height * factor);
        
        int32_t  base_l = j * 6,index_l = j * 4;
        _indice_array[base_l] = index_l;
        _indice_array[base_l + 1] = index_l + 1;
        _indice_array[base_l + 2] = index_l + 2;
        _indice_array[base_l + 3] = index_l + 2;
        _indice_array[base_l + 4] = index_l + 1;
        _indice_array[base_l + 5] = index_l + 3;
        
        _quadCount += 1;
    }
    _isColorDirty = false;
    _triangle.vertCount = _quadCount * 4;
    _triangle.indexCount = _quadCount * 6;
    setContentSize(Size(offset_x,max_height));
}

void LabelFnt::setColor(const Color3B& color) {
    if (color != this->_displayedColor) {
        Node::setColor(color);
        _isColorDirty = true;
    }
}

void LabelFnt::setOpacity(GLubyte opacity) {
    if (opacity != _displayedOpacity) {
        Node::setOpacity(opacity);
        _isColorDirty = true;
    }
}

void LabelFnt::updateDisplayedOpacity(GLubyte opacity) {
    if (_displayedOpacity != opacity) {
        Node::updateDisplayedOpacity(opacity);
        _isColorDirty = true;
    }
}

void LabelFnt::updateColor()
{
    Color4B color4( _displayedColor.r, _displayedColor.g, _displayedColor.b, _displayedOpacity);
    if (_isOpacityModifyRGB)
    {
        float f4 = _displayedOpacity/255.0f;
        color4.r *= f4;
        color4.g *= f4;
        color4.b *= f4;
    }

    for (int index = 0; index < _quadCount; index++)
    {
        _quads[index].bl.colors = color4;
        _quads[index].br.colors = color4;
        _quads[index].tl.colors = color4;
        _quads[index].tr.colors = color4;
    }
    _isColorDirty = false;
}

void LabelFnt::draw(Renderer *renderer, const Mat4& transform, uint32_t flags){
    if (!_visibilityTest || (_quadCount && renderer->checkVisibility(transform, _contentSize))) {
       // _triangleCommand.init(_globalZOrder,_fontAtlas->getTexture(0), _glProgramState, _blendFunc, _quads, _quadCount, transform, flags);
        if(_isColorDirty)
            updateColor();
        _triangleCommand.init(_globalZOrder, _fontAtlas->getTexture(0), _glProgramState, _blendFunc, _triangle, transform, flags);
        renderer->addCommand(&_triangleCommand);
    }
}

NS_CC_END

