#include "scripting/lua-bindings/manual/LuaBasicConversions.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "SpriteBatchInstance.h"
////////////////////////////SpriteInstance -Lua API////////////////////////////////////
int lua_cocos2dx_SpriteInstance_setPosition(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_setPosition'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 3)
	{
		double arg0,arg1,arg2;

		ok &= luaval_to_number(tolua_S, 2, &arg0, "cc.SpriteInstance:setPosition");
		ok &= luaval_to_number(tolua_S, 3, &arg1, "cc.SpriteInstance:setPosition");
		ok &= luaval_to_number(tolua_S, 4, &arg2, "cc.SpriteInstance:setPosition");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setPosition'", nullptr);
			return 0;
		}
		cobj->setPosition(cocos2d::Vec3(arg0,arg1,arg2));
		lua_settop(tolua_S, 1);
		return 0;
	}
	else if (argc == 2) {
		double arg0, arg1;
		ok &= luaval_to_number(tolua_S, 2, &arg0, "cc.SpriteInstance:setPosition");
		ok &= luaval_to_number(tolua_S, 3, &arg1, "cc.SpriteInstance:setPosition");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setPosition'", nullptr);
			return 0;
		}
		cobj->setPosition(arg0,arg1);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:setPosition", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_setPosition'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_setPositionX(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_setPositionX'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 1)
	{
		double arg0;

		ok &= luaval_to_number(tolua_S, 2, &arg0, "cc.SpriteInstance:setPositionX");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setPositionX'", nullptr);
			return 0;
		}
		cobj->setPositionX(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:setPositionX", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_setPositionX'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_setPositionY(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_setPositionY'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 1)
	{
		double arg0;

		ok &= luaval_to_number(tolua_S, 2, &arg0, "cc.SpriteInstance:setPositionY");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setPositionY'", nullptr);
			return 0;
		}
		cobj->setPositionY(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:setPositionY", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_setPositionY'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_setPositionZ(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_setPositionZ'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 1)
	{
		double arg0;

		ok &= luaval_to_number(tolua_S, 2, &arg0, "cc.SpriteInstance:setPositionZ");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setPositionZ'", nullptr);
			return 0;
		}
		cobj->setPositionZ(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:setPositionZ", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_setPositionZ'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_getPosition(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_getPosition'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		const cocos2d::Vec2 &location = cobj->getPosition();
		lua_pushnumber(tolua_S, location.x);
		lua_pushnumber(tolua_S, location.y);
		return 2;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:getPosition", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_getPosition'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_getPositionX(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_getPositionX'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		lua_pushnumber(tolua_S, cobj->getPositionX());
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:getPositionX", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_getPositionX'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_getPositionY(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_getPositionY'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		lua_pushnumber(tolua_S, cobj->getPositionY());
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:getPositionY", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_getPositionY'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_getPositionZ(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_getPositionZ'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		lua_pushnumber(tolua_S, cobj->getPositionZ());
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:getPositionZ", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_getPositionZ'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_getZOrder(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_getZOrder'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		lua_pushinteger(tolua_S, cobj->getZOrder());
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:getZOrder", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_getZOrder'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_getSpriteFrame(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_getSpriteFrame'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		//lua_pushinteger(tolua_S, cobj->getZOrder());
		const cocos2d::SpriteFrame *frame_ptr = cobj->getSpriteFrame();
		object_to_luaval<cocos2d::SpriteFrame>(tolua_S, "cc.SpriteFrame", (cocos2d::SpriteFrame*)frame_ptr);
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:getSpriteFrame", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_getSpriteFrame'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_getPosition3(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_getPosition3'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		const cocos2d::Vec3 &location = cobj->getPosition3();
		lua_pushnumber(tolua_S, location.x);
		lua_pushnumber(tolua_S, location.y);
		lua_pushnumber(tolua_S, location.z);
		return 3;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:getPosition3", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_getPosition3'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_create(lua_State* tolua_S)
{
	int argc = 0;
	bool ok = true;
#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertable(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	argc = lua_gettop(tolua_S) - 1;

	if (argc == 1)
	{
		std::string arg0;
		ok &= luaval_to_std_string(tolua_S, 2, &arg0, "cc.SpriteInstance:create");
		if (!ok) {
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setPosition'", nullptr);
			return 0;
		}
		cocos2d::SpriteInstance* ret = new cocos2d::SpriteInstance(arg0);
		object_to_luaval<cocos2d::SpriteInstance>(tolua_S, "cc.SpriteInstance", (cocos2d::SpriteInstance*)ret);
		return 1;
	}
	else if (argc == 2)
	{
		std::string arg0;
		int              arg1 = 0;
		ok &= luaval_to_std_string(tolua_S, 2, &arg0, "cc.SpriteInstance:create");
		ok &= luaval_to_int32(tolua_S, 3, &arg1, "cc.SpriteInstance:create");
		if (!ok) {
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_create'", nullptr);
			return 0;
		}
		cocos2d::SpriteInstance* ret = new cocos2d::SpriteInstance(arg0,arg1);
		object_to_luaval<cocos2d::SpriteInstance>(tolua_S, "cc.SpriteInstance", (cocos2d::SpriteInstance*)ret);
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d", "cc.SpriteInstance:create", argc, 2);
	return 0;
#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_create'.", &tolua_err);
#endif
				return 0;
}

int lua_cocos2dx_SpriteInstance_setSpriteFrame(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_setSpriteFrame'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 1)
	{
		std::string arg0;
		ok &= luaval_to_std_string(tolua_S, 2, &arg0, "cc.SpriteInstance:setSpriteFrame");

		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setSpriteFrame'", nullptr);
			return 0;
		}
		cobj->setSpriteFrame(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:setSpriteFrame", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_setSpriteFrame'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteInstance_setZOrder(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteInstance_setZOrder'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 1)
	{
		int arg0;
		ok &= luaval_to_int32(tolua_S, 2, &arg0, "cc.SpriteInstance:setZOrder");

		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteInstance_setZOrder'", nullptr);
			return 0;
		}
		cobj->setZOrder(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteInstance:setZOrder", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_setZOrder'.", &tolua_err);
#endif

				return 0;
}

static int lua_cocos2dx_SpriteInstance_finalize(lua_State* tolua_S)
{
	printf("luabindings: finalizing LUA object (Sprite3D)");
	return 0;
}

int lua_register_sprite_instance(lua_State* tolua_S)
{
	tolua_usertype(tolua_S, "cc.SpriteInstance");
	tolua_cclass(tolua_S, "SpriteInstance", "cc.SpriteInstance", "cc.Ref", nullptr);

	tolua_beginmodule(tolua_S, "SpriteInstance");
	tolua_function(tolua_S, "setPosition", lua_cocos2dx_SpriteInstance_setPosition);
	tolua_function(tolua_S, "setPositionX", lua_cocos2dx_SpriteInstance_setPositionX);
	tolua_function(tolua_S, "setPositionY", lua_cocos2dx_SpriteInstance_setPositionY);
	tolua_function(tolua_S, "setPositionZ", lua_cocos2dx_SpriteInstance_setPositionZ);

	tolua_function(tolua_S, "getPosition", lua_cocos2dx_SpriteInstance_getPosition);
	tolua_function(tolua_S, "getPosition3", lua_cocos2dx_SpriteInstance_getPosition3);
	tolua_function(tolua_S, "getPositionX", lua_cocos2dx_SpriteInstance_getPositionX);
	tolua_function(tolua_S, "getPositionY", lua_cocos2dx_SpriteInstance_getPositionY);
	tolua_function(tolua_S, "getPositionZ", lua_cocos2dx_SpriteInstance_getPositionZ);

	tolua_function(tolua_S, "setSpriteFrame", lua_cocos2dx_SpriteInstance_setSpriteFrame);
	tolua_function(tolua_S, "getSpriteFrame", lua_cocos2dx_SpriteInstance_getSpriteFrame);

	tolua_function(tolua_S, "setZOrder", lua_cocos2dx_SpriteInstance_setZOrder);
	tolua_function(tolua_S, "getZOrder", lua_cocos2dx_SpriteInstance_getZOrder);

	tolua_function(tolua_S, "create", lua_cocos2dx_SpriteInstance_create);
	tolua_endmodule(tolua_S);
	std::string typeName = typeid(cocos2d::SpriteInstance).name();
	g_luaType[typeName] = "cc.SpriteInstance";
	g_typeCast["SpriteInstance"] = "cc.SpriteInstance";
	return 1;
}

////////////////////////////SpriteBatchInstance//////////////////////////////////////
int lua_cocos2dx_SpriteBatchInstance_addInstance(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteBatchInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteBatchInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteBatchInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteBatchInstance_addInstance'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 1)
	{
		cocos2d::SpriteInstance *arg0 = nullptr;
		ok &= luaval_to_object<cocos2d::SpriteInstance>(tolua_S, 2, "cc.SpriteInstance",&arg0, "cc.SpriteBatchInstance:addInstance");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteBatchInstance_addInstance'", nullptr);
			return 0;
		}
		cobj->addInstance(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteBatchInstance:addInstance", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteBatchInstance_addInstance'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteBatchInstance_removeInstance(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteBatchInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteBatchInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteBatchInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteBatchInstance_removeInstance'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 1)
	{
		cocos2d::SpriteInstance *arg0 = nullptr;
		ok &= luaval_to_object<cocos2d::SpriteInstance>(tolua_S, 2, "cc.SpriteInstance", &arg0, "cc.SpriteBatchInstance:removeInstance");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteBatchInstance_removeInstance'", nullptr);
			return 0;
		}
		cobj->removeInstance(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteBatchInstance:removeInstance", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteBatchInstance_removeInstance'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteBatchInstance_removeAllInstance(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteBatchInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteBatchInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteBatchInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteBatchInstance_removeInstance'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 0)
	{
		cobj->removeAllInstance();
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteBatchInstance:removeInstance", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteBatchInstance_removeInstance'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteBatchInstance_changeZOrder(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteBatchInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteBatchInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteBatchInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteBatchInstance_changeZOrder'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 2)
	{
		cocos2d::SpriteInstance *arg0 = nullptr;
		int   arg1;
		ok &= luaval_to_object<cocos2d::SpriteInstance>(tolua_S, 2, "cc.SpriteInstance", &arg0, "cc.SpriteBatchInstance:changeZOrder");
		ok &= luaval_to_int32(tolua_S,3,&arg1,"cc.SpriteInstance:changeZOrder");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteBatchInstance_changeZOrder'", nullptr);
			return 0;
		}
		cobj->changeZOrder(arg0,arg1);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteBatchInstance:changeZOrder", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteBatchInstance_changeZOrder'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteBatchInstance_setBlendFunc(lua_State* tolua_S)
{
	int argc = 0;
	cocos2d::SpriteBatchInstance* cobj = nullptr;
	bool ok = true;

#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertype(tolua_S, 1, "cc.SpriteBatchInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	cobj = (cocos2d::SpriteBatchInstance*)tolua_tousertype(tolua_S, 1, 0);

#if COCOS2D_DEBUG >= 1
	if (!cobj)
	{
		tolua_error(tolua_S, "invalid 'cobj' in function 'lua_cocos2dx_SpriteBatchInstance_setBlendFunc'", nullptr);
		return 0;
	}
#endif

	argc = lua_gettop(tolua_S) - 1;
	if (argc == 2)
	{
		cocos2d::BlendFunc  arg0;
		ok &= luaval_to_blendfunc(tolua_S, 2, &arg0, "cc.SpriteBatchInstance:setBlendFunc");
		if (!ok)
		{
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteBatchInstance_setBlendFunc'", nullptr);
			return 0;
		}
		cobj->setBlendFunc(arg0);
		lua_settop(tolua_S, 1);
		return 0;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "cc.SpriteBatchInstance:setBlendFunc", argc, 1);
	return 0;

#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteBatchInstance_setBlendFunc'.", &tolua_err);
#endif

				return 0;
}

int lua_cocos2dx_SpriteBatchInstance_create(lua_State* tolua_S)
{
	int argc = 0;
	bool ok = true;
#if COCOS2D_DEBUG >= 1
	tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
	if (!tolua_isusertable(tolua_S, 1, "cc.SpriteBatchInstance", 0, &tolua_err)) goto tolua_lerror;
#endif

	argc = lua_gettop(tolua_S) - 1;

	if (argc == 2)
	{
		cocos2d::Size arg0;
		int                     arg1;
		ok &= luaval_to_size(tolua_S, 2, &arg0, "cc.SpriteBatchInstance:create");
		ok &= luaval_to_int32(tolua_S, 3, &arg1, "cc.SpriteBatchInstance:create");
		if (!ok) {
			tolua_error(tolua_S, "invalid arguments in function 'lua_cocos2dx_SpriteBatchInstance_create", nullptr);
			return 0;
		}
		cocos2d::SpriteBatchInstance* ret = cocos2d::SpriteBatchInstance::create(arg0,arg1);
		object_to_luaval<cocos2d::SpriteBatchInstance>(tolua_S, "cc.SpriteBatchInstance", (cocos2d::SpriteBatchInstance*)ret);
		return 1;
	}
	luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d", "cc.SpriteInstance:create", argc, 2);
	return 0;
#if COCOS2D_DEBUG >= 1
	tolua_lerror:
				tolua_error(tolua_S, "#ferror in function 'lua_cocos2dx_SpriteInstance_create'.", &tolua_err);
#endif
				return 0;
}

int lua_register_sprite_batch_instance(lua_State* tolua_S)
{
	tolua_usertype(tolua_S, "cc.SpriteBatchInstance");
	tolua_cclass(tolua_S, "SpriteBatchInstance", "cc.SpriteBatchInstance", "cc.Node", nullptr);

	tolua_beginmodule(tolua_S, "SpriteBatchInstance");
	tolua_function(tolua_S, "addInstance", lua_cocos2dx_SpriteBatchInstance_addInstance);
	tolua_function(tolua_S, "removeInstance", lua_cocos2dx_SpriteBatchInstance_removeInstance);
	tolua_function(tolua_S, "removeAllInstance", lua_cocos2dx_SpriteBatchInstance_removeAllInstance);
	tolua_function(tolua_S, "changeZOrder", lua_cocos2dx_SpriteBatchInstance_changeZOrder);

	tolua_function(tolua_S, "setBlendFunc", lua_cocos2dx_SpriteBatchInstance_setBlendFunc);
	tolua_function(tolua_S, "create", lua_cocos2dx_SpriteBatchInstance_create);
	tolua_endmodule(tolua_S);
	std::string typeName = typeid(cocos2d::SpriteBatchInstance).name();
	g_luaType[typeName] = "cc.SpriteBatchInstance";
	g_typeCast["SpriteBatchInstance"] = "cc.SpriteBatchInstance";
	return 1;
}
///////////////////////////////////////////////////////////////////////////////////////
TOLUA_API int register_all_sprite_instance(lua_State* tolua_S)
{
	tolua_open(tolua_S);

	tolua_module(tolua_S, "cc", 0);
	tolua_beginmodule(tolua_S, "cc");

	lua_register_sprite_instance(tolua_S);
	lua_register_sprite_batch_instance(tolua_S);

	tolua_endmodule(tolua_S);
	return 1;
}

int register_sprite_batch_instance_module(lua_State* L)
{
	lua_getglobal(L, "_G");
	if (lua_istable(L, -1))//stack:...,_G,
	{
		register_all_sprite_instance(L);
	}
	lua_pop(L, 1);

	return 1;
}