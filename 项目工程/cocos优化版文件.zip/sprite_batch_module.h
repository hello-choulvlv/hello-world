/*
  *森林舞会所需要的lua函数
  *2018年11月16日
  *author:xiaoxiong
 */
#ifndef __FOREST_PARTY_MODULE_H__
#define __FOREST_PARTY_MODULE_H__

struct lua_State;
int register_sprite_batch_instance_module(lua_State* L);

#endif