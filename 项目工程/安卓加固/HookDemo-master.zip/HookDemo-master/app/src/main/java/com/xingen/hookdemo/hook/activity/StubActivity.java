package com.xingen.hookdemo.hook.activity;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by ${HeXinGen} on 2019/1/6.
 * blog博客:http://blog.csdn.net/hexingen
 *
 * 替身Activity
 */

public class StubActivity extends AppCompatActivity {

}
