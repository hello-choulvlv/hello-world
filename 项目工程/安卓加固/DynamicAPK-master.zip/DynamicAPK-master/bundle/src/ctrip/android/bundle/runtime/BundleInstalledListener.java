package ctrip.android.bundle.runtime;

/**
 * Created by yb.wang on 15/8/7.
 */
public interface BundleInstalledListener {
    void onBundleInstalled();
}
