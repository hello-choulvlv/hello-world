package ctrip.android.bundle.runtime;

import android.app.Application;
import android.content.res.Resources;

/**
 * Created by yb.wang on 15/1/4.
 * 运行时重要的参数
 */

public class RuntimeArgs {
    public static Application androidApplication;
    public static Resources delegateResources;
}
