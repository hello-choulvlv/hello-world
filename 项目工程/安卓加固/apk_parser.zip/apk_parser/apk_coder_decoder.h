//
//  apk_coder_decoder.h
//  apjk_parser
//
//  Created by yitong li on 2/9/2021.
//
/*
 *@version 2.0:实现文件加密,混合,打散功能
 *@date:2021/9/3
 */

#ifndef apk_coder_decoder_h
#define apk_coder_decoder_h
#include <string>
#include <list>
/*
 *获取文件内容,如果文件不存在,则返回false
 */
bool  apk_getFileContent(const std::string &file_name,std::string &file_content);
/*
 *在给定字符串,以及相关键,查找对应的值,并返回相关的索引,如果没有找到,则返回-1
 *target_string:目标字符串
 *prefix_string:待查找的字符串的标签前缀
 *key_string:键
 */
int32_t  apk_find_key_string(const std::string &target_string,const std::string &prefix_string,const std::string &key_string,std::string &value_string);
int32_t  apk_reverse_find_key_string(const std::string &target_string,const std::string &prefix_string,const std::string &postfix_string,const std::string &key_string,std::string &value_string);
/*
 *字符串查找,从后向前查找
 *查找成功,返回相关位置,否则返回-1
 */
int32_t  apk_string_reverse_find(const std::string &target_string,const std::string &compare_string,int32_t  from_pos,int32_t over_pos);
/*
 *给定字符串,以及相关键,替换其值字符串
 *
 */
int32_t  apk_replace_key_string(std::string &target_string,const std::string &prefix_string,const std::string &key_string,const std::string &value_string);
/*
 *向字符串中查找目标字符串,然后在其结尾插入目标字符串
 */
int32_t apk_insert_key_string(std::string &content,const std::string &prefix,const std::string &postfix,const std::string &insert_string);
/*
 *创建文件,并将数据写入到其中
 */
bool  apk_create_file_with_content(const std::string  &file_name,const char *buffer,int32_t  buffer_size);

/*
 *将某一个文件夹下文件集成,重新打散处理
 *class_file:classes.dex 文件
 *以上文件生成的汇总文件的名字
 *application_name代表包名
 */
bool  apk_create_class_so_library_integration(const std::string &class_file,const char *aes_buffer,const std::string &header_name,int32_t split_number,const std::string &target_path,const std::string &application_name);
/*
 *文件解码
 *class_content:classes.dex解密后的文件内容
 *aes_buffer:解密时需要用到的密钥
 */
bool apk_decode_class_so_library(const std::string &header_name,const char *aes_buffer,const std::string &target_path,std::string &application_name);
/*
 *随机数生成器,发生种子
 */
void  apk_rand_seed(uint32_t  seed);
uint32_t  apk_random();
/*
 *罗列给定目录下所有的文件名字
 *如果给定的名字不是文件夹,则枚举失败
 *注意,函数调用的开始,不会清空file_list
 */
bool  apk_enumerate_file_list_cascade(const std::string &directory,std::list<std::string> &file_list);
/*
 *给定字符串生成uint32_t数字
 */
uint32_t  apk_gen_seed_from_string(const char *buffer);
/*
 *生成加密Key
 */
void  apk_create_encrypto_key_buffer(char *buffer,int32_t buffer_size);
/*
 *字符串前缀比较
 *a字符串是否以b字符串为前缀
 */
bool apk_string_start_with(const char *a,const char *b);
/*
 *生成指定数目的随机字符串
 */
void apk_create_random_string(char *buffer,int32_t  buffer_size);

/*
 *如果制定的目录不存在,则创建
 *返回是已经否存在指定目录
 */
bool  apk_create_directory(const std::string &directory_name);
bool  apk_create_directory_cascade(const std::string &directory_name);
/*
 *复制文件到对应的目录中
 */
bool apk_copy_file_to_target(const std::string &src_file,const std::string &dst_file);

char *tiny_aes_encrypt_cbc(char *in_data, int input_length, const char *encrypto_buffer,int32_t encrypto_size,uint32_t *output_length);
char *tiny_aes_decrypt_cbc(char *in_data, int input_length,const char *encrypto_buffer,int32_t encrypto_size, uint32_t *output_length);

/*
 *生成合法包名称
 */
void  apk_create_pack_name(char *pack_buffer,int32_t pack_size);
/*
 *生成合法的类名
 */
void apk_create_class_name(char *base_buffer,int32_t base_size);
/*
 *替换字符
 */
void apk_replace_char_with(char *buffer,char c,char s);
/*
 *将源字符串替换为目标字符串
 */
bool apk_string_replace_with(std::string &target_string,const std::string &source_string,const std::string &dst_string);

/*
 *字符串比较
 */
bool apk_string_end_with(const char *s,const char *match);

#endif /* apk_coder_decoder_h */
