//
//  main.cpp
//  apjk_parser
//
//  Created by yitong li on 2/9/2021.
/*
 *@version 1.0:实现最基本的文件处理功能,在安卓方面与C++代码整合好之后,我们将实现带有文件分割+加密功能版本
 *@date:2021/9/2
 */

#include <iostream>
#include <fstream>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include "apk_coder_decoder.h"

//安卓配置文件名称
static const char *s_android_xml = "AndroidManifest.xml";
static const char *s_library_name = "liboceancs.so";
//dex文件集合
static const char  *s_dex_class = "classes.dex";
//目标文件夹
static const char *s_target_directory = "assets";
/*
 *执行shell命令,如果有输出的话,产生输出
 */
int32_t  apk_execute_shell_cmd(const char *buffer){
    FILE *fp = popen(buffer, "r");
    if(!fp)
        return 0;
    //产生输出
    char buffer_4p[1024+4];
    int32_t    byte_read = 0;
    while((byte_read = (int32_t)fread(buffer_4p, 1, sizeof(buffer_4p), fp)) != 0){
        buffer_4p[byte_read] = 0;;
        printf("%s",buffer_4p);
    }
    
    pclose(fp);
    return 1;
}
/*
 argv[1]:  待处理的apk文件
 argv[2]:  分割classes.dex  文件的数目,最好在4 -- 6之间
 argv[3]:   keystore文件路径
 argv[4]:   alias name
 argv[5]:   keystore password
 argv[6]:   alias password
 argv[7]:  输出路径
 */
int main(int argc,char *argv[]){
    if(argc < 7){
        printf("usage: %s [packname]  encrypto file\n ",argv[0]);
        return 1;
    }
    char  buffer[1024];
    int32_t split_number = atoi(argv[2]);
    if(split_number < 3)split_number = 3;
    else if(split_number > 6) split_number = 6;
    //首先将apk包解压,在这之前，需要将对应的目录删除,如果已经有了的话,该目录必须在当前目录下,因为需要用到很多的中间文件
    std::string apk_pack = argv[1];
    assert(apk_pack.find_last_of(".apk") == apk_pack.size() - 1);
    
    //获取当前目录
    char buffer_cd[1024];
    getcwd(buffer_cd, 1024);
    
    //获取文件名
    size_t np0 = apk_pack.find_last_of('/');
    const std::string apk_simple_name = np0 == std::string::npos ?apk_pack : apk_pack.substr(np0 + 1);
    
    //当前解压后的目录名称
    std::string apk_pack_directory = buffer_cd;
    apk_pack_directory.append("/").append(apk_simple_name.substr(0,apk_simple_name.find_last_of('.')));
    
    //std::string apk_pack_directory = apk_simple_name.substr(0,apk_pack.find_last_of('.'));
    DIR *apk_dir_ptr = opendir(apk_pack_directory.c_str());
    if(apk_dir_ptr != nullptr){
        closedir(apk_dir_ptr);
        printf("--目录 '%s' 已经存在，正在删除中.....\n",apk_pack_directory.c_str());
        sprintf(buffer,"rm -rf %s",apk_pack_directory.c_str());
        if(!apk_execute_shell_cmd(buffer)){
            printf("--删除目录 '%s' 异常........\n",apk_pack_directory.c_str());
            return 1;
        }
    }
    //解压
    sprintf(buffer,"java -jar apktool.jar d -s %s ",apk_pack.c_str());
    if(!apk_execute_shell_cmd(buffer)){
        printf("---解压apk安装包 ‘%s’ 失败..........\n",apk_pack.c_str());
        return 2;
    }
    //第三步,从解压后的目录中提取出 AndroidManifest.xml文件内容,并做相关的调整
    sprintf(buffer,"%s/%s",apk_pack_directory.c_str(),s_android_xml);
    std::string xml_content;
    if(!apk_getFileContent(buffer, xml_content)){
        printf("-----获取文件 '%s' 内容失败-------\n",s_android_xml);
        return 3;
    }
    //然后从中提取出包名,还有 application名字
    //获取文件的包名,该包名将是对所有资源进行加密解密的关键.
    std::string pack_name;
    int32_t  pack_ref = apk_find_key_string(xml_content, "<manifest", "package", pack_name);
    if(pack_ref == -1){
        printf("没有在文件AndroidManifest.xml文件中找到包名.....\n");
        return 4;
    }
    //查找Application名字
    std::string app_name;
    int32_t  app_ref = apk_find_key_string(xml_content, "<application", "android:name", app_name);
    if(app_ref == -1){
        printf("没有在文件AndroidManifest.xml文件中找到Application名字.....\n");
        return 5;
    }
    
    //生成随机数种子
    printf("---seed--string---> %s \n",pack_name.c_str());
    uint32_t seed = apk_gen_seed_from_string(pack_name.c_str());
    printf("seed--->%u \n",seed);
    apk_rand_seed(seed);
    
    //接下来生成需要用到的新版 meta data键值名称,以及Application的全名,NativeTool 类的新版全名,seed string 字符串
    int32_t  pack_size = 15 + apk_random()%8;
    int32_t  base_size = 6 + apk_random()%6;
    
    char pack_buffer[64];
    //生成包名
    apk_create_pack_name(pack_buffer, pack_size);
    
    //NativeTool 类名字
    char native_tool_buffer[32];
    apk_create_class_name(native_tool_buffer, 6 + apk_random() % 6);
    //函数名字
    char onCreate_buffer[64],attachBaseContext_buffer[64],unseal_buffer[64];
    apk_create_class_name(onCreate_buffer, 7 + apk_random() % 7);
    apk_create_class_name(attachBaseContext_buffer, 13 + apk_random() % 7);
    apk_create_class_name(unseal_buffer, 7 + apk_random() % 7);
    
    //以及Application名字
    char application_buffer[32];
    apk_create_class_name(application_buffer, base_size);
    
    //meta data 键值名称
    char meta_key[64];
    char meta_value[64];
    apk_create_random_string(meta_key, 9 + apk_random() % 7);
    apk_create_random_string(meta_value, 12 + apk_random() % 13);
    
    //MainActivity 类名字
    char  main_activity_buffer[64];
    apk_create_class_name(main_activity_buffer, apk_random() % 7 + 8);
    
    
    //接下来处理安卓工程中的C++文件,目前只有一个需要处理,那就是auto_patch.h
    std::string auto_patch_content;
    auto_patch_content.append("/*\n"
                              "* 工具生成文件,请不要自行编辑\n"
                              "* *2021/11/19\n"
                              "* *author:xiaoxiong\n"
                              "*/\n");
    auto_patch_content.append("#ifndef __auto_patch_h__\n#define __auto_patch_h__\n\n");
    
    sprintf(buffer,"%s/%s",pack_buffer,native_tool_buffer);
    apk_replace_char_with(buffer,  '.',  '/');
    
    auto_patch_content.append("#define Native_Tool_Name \"").append(buffer).append("\"\n\n");
    auto_patch_content.append("#define seed_string_random   \"").append(meta_value).append("\"\n\n");
    auto_patch_content.append("#define cx_meta_data_name  \"").append(meta_key).append("\"\n\n");
    auto_patch_content.append("#define __onCreate_micro  \"").append(onCreate_buffer).append("\"\n\n");
    auto_patch_content.append("#define __attachBaseContext_micro  \"").append(attachBaseContext_buffer).append("\"\n\n");
    auto_patch_content.append("#define __unseal_micro  \"").append(unseal_buffer).append("\"\n\n");
    auto_patch_content.append("\n#endif\n");
    if(apk_create_file_with_content("PackApkAuto/app/src/main/jni/auto_patch.h", auto_patch_content.c_str(), (int32_t)auto_patch_content.size())){
        printf("----处理 auto_patch.h 文件成功.........\n");
    }
    else{
        printf("----处理 auto_patch.h 文件失败 .........\n");
        return 8;
    }
    
    //处理java 文件,首先删除掉工程中的java文件夹
    const char *java_dir = "PackApkAuto/app/src/main/java";
    DIR  *dir_ptr = opendir(java_dir);
    if(dir_ptr != nullptr){
        closedir(dir_ptr);
        sprintf(buffer,"rm -rf %s",java_dir);
        if(!apk_execute_shell_cmd(buffer)){
            printf("---删除目录 %s 失败---------\n",java_dir);
            return 9;
        }
        printf("----移除目录 ‘%s’ 成功..............\n",java_dir);
    }
    //稍后,需要创建三个文件,
    std::string file_content;
    const char *native_file_list[3] = {"template/NativeTool.java",
        "template/ProxyApplication.java",
        "template/MainActivity.java"};
    
    const char *target_file_name[3] = {
        native_tool_buffer,
        application_buffer,
        main_activity_buffer,
    };
    
    //首先是需要创建目录 PackApkAuto/app/src/main/java
    
    char  buffer2[1024];
    strcpy(buffer2,pack_buffer);
    apk_replace_char_with(buffer2, '.', '/');
    sprintf(buffer,"%s/%s",java_dir,buffer2);
    
    std::string java_directory(buffer);
    
    apk_create_directory_cascade(buffer);
    const char *template_pack_name = "com.security.cvsample";
    //const char *native_tool_name = "NativeTool";
    //const char *proxy_app_name = "ProxyApplication";
    
    const char *class_name_list[3] = {
        "NativeTool",
        "ProxyApplication",
        "MainActivity"
    };
    
    const char *function_name_list[3] = {
        "onCreate",
        "attachBaseContext",
        "unseal",
    };
    
    const char *new_function_name_list[3] = {
        onCreate_buffer,
        attachBaseContext_buffer,
        unseal_buffer,
    };
    
    for(int j = 0;j < 3; ++j){
        if(!apk_getFileContent(native_file_list[j], file_content)){
            printf("--获取文件'%s'内容失败-----\n",native_file_list[j]);
            return 10;
        }
        //然后修改文件的内容,包名,以及类名
        if(!apk_string_replace_with(file_content,template_pack_name,pack_buffer)){
            printf("----非法的文件--‘%s’-----",native_file_list[j]);
            return 10;
        }
        const char *class_name = class_name_list[j];
        const char *new_class_name = target_file_name[j];
        
        if(!apk_string_replace_with(file_content,class_name,new_class_name)){
            printf("---文件 '%s' 找不到类名 '%s \n'",native_file_list[j],class_name);
            return 11;
        }
        //如果是前两个文件,则需要做更多的替换工作
        if(j < 2){
            //如果是NativeTool类,则需要替换函数名称
            if(j == 0){
                bool b2 = false;
                for(int k =0; k < 3; ++k){
                    b2 |= apk_string_replace_with(file_content, function_name_list[k], new_function_name_list[k]);
                }
            }
            //如果是 ProxyApplication类,则其更加特殊,需要替换其中的有关NativeTool类的使用
            if(j == 1){
                //替换掉有关函数全局属性的值
                const char *content = "System.setProperty(\"s2-67\",\"0\")";
                sprintf(buffer,"System.setProperty(\"s2-67\",\"%u\")",seed);
                if(!apk_string_replace_with(file_content, content, buffer)){
                    printf("--没有找到内容---- %s   -----\n",content);
                    return 29;
                }
                //meta dara
                const char *c2_content = "System.setProperty(\"v-metal\",\"0\")";
                sprintf(buffer,"System.setProperty(\"v-metal\",\"%s\")",meta_value);
                if(!apk_string_replace_with(file_content, c2_content, buffer)){
                    printf("-----没有找到内容-----  %s --------\n",c2_content);
                    return 30;
                }
                //还有相关的函数引用
                bool b3 = false;
                for(int k =0; k < 3; ++k){
                    sprintf(buffer,"%s.%s",class_name_list[0],function_name_list[k]);
                    sprintf(buffer2,"%s.%s",target_file_name[0],new_function_name_list[k]);
                    b3 |= apk_string_replace_with(file_content, buffer, buffer2);
                }
                
                if(!b3){
                    printf("-------没有找到有关NativeTool类的函数调用----------\n");
                    return 26;
                }
            }
        }
        //然后,将其写入到目标地址
        sprintf(buffer2,"%s/%s.java",java_directory.c_str(),target_file_name[j]);
        if(!apk_create_file_with_content(buffer2, file_content.c_str(), (int32_t)file_content.size())){
            printf("---写入文件'%s'失败-----------------\n",buffer2);
            return 26;
        }
    }
    //接着继续处理AndroidManifest.xml文件,将meta data数据写入其中,替换成新版Application
    sprintf(buffer,"%s.%s",pack_buffer,application_buffer);
    int32_t  result_ref = apk_replace_key_string(xml_content, "<application", "android:name", buffer);//替换新版Application名字
    //如果没有找到相关的配置,则解码失败
    if(result_ref == -1){
        printf("没有在AndroidManifest.xml文件中找到Application入口...\n");
        return 13;
    }
    //insert meta data
//    sprintf(buffer,"\n\t\t<meta-data android:name=\"%s\" android:value=\"%s\"/>",meta_key,meta_value);
//    result_ref = apk_insert_key_string(xml_content,"<application", ">",buffer);
//    if(result_ref == -1){
//        printf("---向AndroidManifest.xml文件中插入 meta data失败....\n");
//        return 14;
//    }
    //然后将以上内容写入到文件中.
    sprintf(buffer,"%s/%s",apk_pack_directory.c_str(),s_android_xml);
    if(!apk_create_file_with_content(buffer, xml_content.c_str(), (int32_t)xml_content.size())){
        printf("---写入文件'%s'失败。。。。。。\n",buffer);
        return 14;
    }
    
    //生成加密文件
    printf("--step---2-seed--string---> %s \n",meta_value);
    seed = apk_gen_seed_from_string(meta_value);
    printf("---step---2----seed--->%u \n",seed);
    apk_rand_seed(seed);
    
    const int encrypto_buffer_size = 256;
    char  aes_buffer[encrypto_buffer_size];
    //使用当前的包名生成加密key
    apk_create_encrypto_key_buffer(aes_buffer,encrypto_buffer_size);
    
    //header name
    char header_buffer[1024];
    const int32_t header_size = 12;
    apk_create_random_string(header_buffer, header_size);
    
    sprintf(buffer,"%s/assets/%s",apk_pack_directory.c_str(),header_buffer);
    std::string header_file(buffer);
    
    sprintf(buffer,"%s/%s",apk_pack_directory.c_str(),s_dex_class);
    std::string class_dex = buffer;
    
    sprintf(header_buffer,"%s/assets",apk_pack_directory.c_str());
    std::string target_path = header_buffer;
    
    bool ref = apk_create_class_so_library_integration(class_dex,aes_buffer,header_file,split_number,target_path,app_name);
    assert(ref);
    
    //另外需要将Androidmanifest.xml文件从工程模板中复制过去,并且替换掉成为目标值
    std::string xml_android;
    const char *xml_name_3 = "template/AndroidManifest.xml";
    if(!apk_getFileContent(xml_name_3, xml_android)){
        printf("--读取文件 '%s '失败....-\n",xml_name_3);
        return 20;
    }
    //然后替换目标字符串
    sprintf(buffer,"%s.%s",pack_buffer,application_buffer);
    apk_string_replace_with(xml_android, "com.security.cvsample.ProxyApplication", buffer);
    const char *target_xml_name = "PackApkAuto/app/src/main/AndroidManifest.xml";
    if(!apk_create_file_with_content(target_xml_name, xml_android.c_str(), (int32_t)xml_android.size())){
        printf("---创建文件失败...........\n");
        return 21;
    }
    
#if 1
    //第五步,从以上生成的jni代码 + java代码开始,编译Android工程,然后将生成的apk文件服导致当前目录,并且将其解压,从中提取出来so库与classes.dex文件
    sprintf(buffer,"cd PackApkAuto && ./gradlew clean && ./gradlew compileReleaseSource && ./gradlew assembleRelease ");
    if(!apk_execute_shell_cmd(buffer)){
        printf("---编译安卓项目失败,............\n");
        return 15;
    }
#endif
    //编译成功后,开始提取出来生成的.apk文件
    const char *born_apk_file = "PackApkAuto/app/build/outputs/apk/release/app-release.apk";
    const char *new_apk_file = "app-release.apk";
    if(!apk_copy_file_to_target(born_apk_file, new_apk_file)){
        printf("---复制文件 '%s' 到当前目录失败失败........\n",born_apk_file);
        return 16;
    }
    //然后,解压
    sprintf(buffer,"java -jar apktool.jar d -s -f %s",new_apk_file);
    if(!apk_execute_shell_cmd(buffer)){
        printf("---解码文件'%s' 失败..............\n",new_apk_file);
        return 17;
    }
    //复制classes.dex + libocean.so文件到目标目录中
    const char *src_directory = "app-release";
    sprintf(buffer,"%s/%s",src_directory,s_dex_class);
    sprintf(buffer2,"%s/%s",apk_pack_directory.c_str(),s_dex_class);
    if(!apk_copy_file_to_target(buffer, buffer2)){
        printf("----copy file '%s' failed-------\n",s_dex_class);
        return 18;
    }
    
    sprintf(buffer,  "%s/lib/armeabi-v7a/%s",src_directory,s_library_name);
    sprintf(buffer2,"%s/lib/armeabi-v7a/%s",apk_pack_directory.c_str(),s_library_name);
    if(!apk_copy_file_to_target(buffer, buffer2)){
        printf("-----copy file '%s'  failed............\n",s_library_name);
        return 19;
    }
    
    //最后一步,安卓重新打包,然后签名
    sprintf(buffer,"java -jar apktool.jar b %s",apk_pack_directory.c_str());
    if(!apk_execute_shell_cmd(buffer)){
        printf("-----重新打安卓包失败..........\n");
        return 23;
    }
    //签名
    std::string output_path =  argc < 8 ? "apk_destination" : argv[7];
    std::string keystore_path = argv[3];
    std::string alias_name = argv[4];
    std::string keystore_pass = argv[5];
    std::string alias_pass = argv[6];
    
    //输出路径有可能含有文件名称,需要做一次检查
    bool np5 = apk_string_end_with(output_path.c_str(),".apk");//output_path.find_last_of(".apk");
    
    
    size_t np4 = apk_pack_directory.find_last_of('/');
    std::string base_directory = np4 == std::string::npos ? apk_pack_directory : apk_pack_directory.substr(np4 + 1);
    std::string output_target_apk= np5 ? output_path : output_path + "/" + base_directory.c_str() + ".apk";
    
    size_t np6 = output_target_apk.find_last_of('/');
    std::string fix_path = np6 != std::string::npos ? output_target_apk.substr(0,np6) : ".";
    //如果没有当前目标目录,创建
    if(!apk_create_directory_cascade(fix_path.c_str())){
        printf("---创建目标路径 '%s'失败--------\n",fix_path.c_str());
        return 28;
    }
    
    sprintf(buffer,"jarsigner -verbose -keystore %s  -signedjar  %s %s/dist/%s.apk %s -storepass %s -keypass %s",
                                                keystore_path.c_str(),// 0
                                                output_target_apk.c_str(),// 1    2
                                                apk_pack_directory.c_str(),base_directory.c_str(),
                                                alias_name.c_str(),
                                                keystore_pass.c_str(),
                                                alias_pass.c_str());
    
    
    sprintf(buffer2,"./apksigner sign --ks %s --ks-key-alias %s --ks-pass pass:%s --key-pass pass:%s --out %s %s/dist/%s.apk ",
                                                keystore_path.c_str(),
                                                alias_name.c_str(),
                                                keystore_pass.c_str(),
                                                alias_pass.c_str(),
                                                output_target_apk.c_str(),
                                                apk_pack_directory.c_str(),base_directory.c_str());
    
    if(!apk_execute_shell_cmd(buffer2)){
        printf("-----重新签名失败。。。。。。\n");
        return 24;
    }
    
    printf("-----------success--------------------\n");
    
    return 0;
}
