//
//  apk_coder_decoder.cpp
//  apjk_parser
//
//  Created by yitong li on 2/9/2021.
//

#include "apk_coder_decoder.h"
#include <iostream>
#include <fstream>
#include <dirent.h>
#include <sys/stat.h>
#include "external/zlib.h"

//#include "aes.h"
#include "xxtea.h"

#define  __magic_number 0x7C8A5A4B
#define  __check_sum_mask  "wiyuopvnfbjk0747865"
typedef unsigned char byte;
static const char s_char_array[] = {
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    'a','b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
    '0','1','2','3','4','5','6','7','8','9','_','-','$'
};

static const char s_char_pack0[] = {
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    'a','b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','_',
};

static const char s_char_pack[] = {
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    'a','b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
    '0','1','2','3','4','5','6','7','8','9','_',
};

int apk_data_compress(const char *idata, int ilen, char *odata, int *olen)
{
    z_stream z = {0};

    z.next_in = (uint8_t *)idata;
    z.avail_in = ilen;
    z.next_out = (uint8_t *)odata;
    z.avail_out = *olen;
 
    printf("total %u bytes\n", z.avail_in);
 
    /* 使用最高压缩比 */
    if (deflateInit(&z, Z_BEST_COMPRESSION) != Z_OK) {
        printf("deflateInit failed!\n");
        return -1;
    }

    if (deflate(&z, Z_NO_FLUSH) != Z_OK) {
        printf("deflate Z_NO_FLUSH failed!\n");
        return -1;
    }

    if (deflate(&z, Z_FINISH) != Z_STREAM_END) {
        printf("deflate Z_FINISH failed!\n");
        return -1;
    }

    if (deflateEnd(&z) != Z_OK) {
        printf("deflateEnd failed!\n");
        return -1;
    }
 
    *olen = *olen - z.avail_out;

    printf("compressed data %d bytes.\n", *olen);

    return 0;
}

int apk_data_decompress(const char *idata, int ilen, char *odata, int *olen)
{
    z_stream z = {0};

    z.next_in = (unsigned char *)idata;
    z.avail_in = ilen;
    z.next_out = (uint8_t *)odata;
    z.avail_out = *olen;

    if (inflateInit(&z) != Z_OK) {
        printf("inflateInit failed!\n");
        return -1;
    }

    if (inflate(&z, Z_NO_FLUSH) != Z_STREAM_END) {
        printf("inflate Z_NO_FLUSH failed!\n");
        return -1;
    }

    if (inflate(&z, Z_FINISH) != Z_STREAM_END) {
        printf("inflate Z_FINISH failed!\n");
        return -1;
    }

    if (inflateEnd(&z) != Z_OK) {
        printf("inflateEnd failed!\n");
        return -1;
    }

    //*olen = (int32_t )strlen(odata);
    printf("decompressed data: %s\n", odata);
    
    return 0;
}


/*
 *获取文件内容,如果文件不存在,则返回false
 */
bool  apk_getFileContent(const std::string &file_name,std::string &file_content){
    std::ifstream  io_input;
    io_input.open(file_name);
    if(!io_input.is_open()){
        printf("file %s is not exist.\n",file_name.c_str());
        io_input.close();
        return false;
    }
    //获取文件长度
    io_input.seekg(0, std::ios::end);
    uint32_t  file_length = (uint32_t)io_input.tellg();
    io_input.seekg(0,std::ios::beg);
    
    file_content.resize(file_length);
    io_input.read((char *)file_content.c_str(), file_length);
    
    io_input.close();
    
    return true;
}
/*
 *获取文件的长度
 */
uint32_t apk_get_file_length(const std::string &file_name){
    std::ifstream  io_input;
    io_input.open(file_name);
    if(!io_input.is_open()){
        printf("file %s is not exist.\n",file_name.c_str());
        return -1;
    }
    
    io_input.seekg(0, std::ios::end);
    uint32_t  file_length = (uint32_t)io_input.tellg();
    io_input.seekg(0,std::ios::beg);
    io_input.close();
    
    return file_length;
}
/*
 *在给定字符串,以及相关键,查找对应的值,并返回相关的索引,如果没有找到,则返回-1
 *target_string:目标字符串
 *prefix_string:待查找的字符串的标签前缀
 *key_string:键
 */
int32_t  apk_find_key_string(const std::string &target_string,const std::string &prefix_string,const std::string &key_string,std::string &value_string){
    size_t  start_pos = target_string.find(prefix_string);
    if(start_pos == std::string::npos)
        return -1;
    
    size_t  sk = -1;
    bool b2 = (sk = target_string.find(">",start_pos)) != std::string::npos || (sk = target_string.find("/>",start_pos)) != std::string::npos;
    assert(b2 == true);
    
    size_t  target_pos = target_string.find(key_string,start_pos);
    if(target_pos == std::string::npos || target_pos > sk)
        return -1;
    
    //检索目标字符串下对应的值
    const char *str = target_string.c_str();
    while(str[target_pos] != '\"' && target_pos < sk)
        ++target_pos;
    ++target_pos;
    
    size_t  s0 = target_pos;
    while(str[s0] != '\"' && s0 < sk)
        ++s0;

    value_string.resize(s0 - target_pos);
    memcpy((char *)value_string.c_str(),str + target_pos,s0 - target_pos);
    
    return (int32_t)target_pos;
}

int32_t  apk_string_reverse_find(const std::string &target_string,const std::string &compare_string,int32_t  from_pos,int32_t over_pos){
    assert(target_string.size() > over_pos);
    assert(from_pos >= 0);
    const char *a  = target_string.c_str();
    const char *b = compare_string.c_str();
    
    for(int32_t  kx = over_pos;kx >= 0; --kx){
        int32_t    ks = kx;
        int32_t  compare_idx = (int32_t)compare_string.size() - 1;
        while(compare_idx >= 0 && ks >= 0 && b[compare_idx] == a[ks]){
            --compare_idx;
            --ks;
        }
        if(compare_idx == -1)
            return ks + 1;
    }
    return -1;
}

int32_t  apk_reverse_find_key_string(const std::string &target_string,const std::string &prefix_string,const std::string &postfix_string,const std::string &key_string,std::string &value_string){
    size_t  over_pos = target_string.find(postfix_string);
    if(over_pos == std::string::npos)
        return -1;
    
    int32_t  sk = apk_string_reverse_find(target_string,prefix_string,0,(int32_t)over_pos);
    bool b2 = sk != -1;
    assert(b2 == true);
    
    size_t  target_pos = target_string.find(key_string,sk);
    if(target_pos == std::string::npos || target_pos > over_pos)
        return -1;
    
    //检索目标字符串下对应的值
    const char *str = target_string.c_str();
    while(str[target_pos] != '\"' && target_pos < over_pos)
        ++target_pos;
    ++target_pos;
    
    size_t  s0 = target_pos;
    while(str[s0] != '\"' && s0 < over_pos)
        ++s0;

    value_string.resize(s0 - target_pos);
    memcpy((char *)value_string.c_str(),str + target_pos,s0 - target_pos);
    
    return (int32_t)target_pos;
}
/*
 *给定字符串,以及相关键,替换其值字符串
 *
 */
int32_t  apk_replace_key_string(std::string &target_string,const std::string &prefix_string,const std::string &key_string,const std::string &value_string){
    size_t  start_pos = target_string.find(prefix_string);
    if(start_pos == std::string::npos)
        return -1;
    
    size_t  sk = -1;
    bool b2 = (sk = target_string.find(">",start_pos)) != std::string::npos || (sk = target_string.find("/>",start_pos)) != std::string::npos;
    assert(b2 == true);
    
    size_t  target_pos = target_string.find(key_string,start_pos);
    if(target_pos == std::string::npos || target_pos > sk)
        return -1;
    
    //检索目标字符串下对应的值
    const char *str = target_string.c_str();
    while(str[target_pos] != '\"' && target_pos < sk)
        ++target_pos;
    ++target_pos;
    
    size_t  s0 = target_pos;
    while(str[s0] != '\"' && s0 < sk)
        ++s0;

    target_string.replace(target_pos,s0 - target_pos,value_string);
    
    return (int32_t)target_pos;
}

int32_t apk_insert_key_string(std::string &target_string,const std::string &prefix_string,const std::string &postfix,const std::string &insert_string){
    size_t  start_pos = target_string.find(prefix_string);
    if(start_pos == std::string::npos)
        return -1;
    
    size_t  sk = -1;
    bool b2 = (sk = target_string.find(postfix,start_pos)) != std::string::npos;
    assert(b2 == true);
    
    target_string.insert(sk + postfix.size(), insert_string);
    return (int32_t)sk;
}

/*
 *创建文件,并将数据写入到其中
 */
bool  apk_create_file_with_content(const std::string  &file_name,const char *buffer,int32_t  buffer_size){
    std::ofstream  io_out;
    io_out.open(file_name,std::ios::trunc);
    
    if(!io_out.is_open()){
        printf("open file '%s' failed.\n",file_name.c_str());
        return false;
    }
    
    io_out.write(buffer, buffer_size);
    io_out.close();
    
    return true;
}

static uint32_t  s_seed;
void  apk_rand_seed(uint32_t  seed){
    s_seed = seed;
}

uint32_t  apk_random(){
    uint32_t  new_seed = s_seed * 71597 + 1720273;
    s_seed = new_seed;
    return new_seed;
}
//计算文件的校验和
void  apk_compute_checksum(const char *buffer,int32_t buffer_size,char buffer_4[4]){
    const char *mask_ptr = __check_sum_mask;
    int32_t  mask_size = sizeof(__check_sum_mask);
    
    int32_t  buffer_idx = 0;
    int32_t  mask_idx = 0;
    
    for(int j = 0;j < buffer_size; ++j){
        buffer_4[buffer_idx] += buffer[j] ^ mask_ptr[mask_idx];
        buffer_idx = (buffer_idx +1) % 4;
        mask_idx = (mask_idx + 1) % mask_size;
    }
}
/*
 *赋值,将整数复制到缓冲区对象中
 */
void  apk_copy_int32(char *buffer,uint32_t  ick){
    buffer[0] = ick & 0xFF;
    buffer[1] = (ick >> 8) & 0xFF;
    buffer[2] = (ick >> 16) & 0xFF;
    buffer[3] = (ick >> 24) & 0xFF;
}

uint32_t apk_copy_buffer_to_uint32(const char *buffer){
    byte *b2c = (byte *)buffer;
    return b2c[0] | (b2c[1] << 8) | (b2c[2] << 16) | (b2c[3] << 24);
}

uint32_t apk_copy_buffer_to_uint16(const char *buffer){
    byte *b2c = (byte *)buffer;
    return b2c[0] | (b2c[1] << 8);
}

void apk_copy_int16(char *buffer,uint32_t  ick){
    buffer[0] = ick & 0xFF;
    buffer[1] = (ick >> 8) & 0xFF;
}

void apk_encrypto_buffer_with_string(char *buffer,int32_t buffer_size,const char *encrypto_buffer,int32_t encrypto_size){
    uint8_t *buffer_ptr = (uint8_t *)buffer;
    const uint8_t *buffer_2_ptr = (const uint8_t *)encrypto_buffer;
    
    int32_t base_l = 0;
    for(int32_t j = 0;j < buffer_size; ++j){
        buffer_ptr[j] = (buffer_ptr[j] ^ buffer_2_ptr[base_l]) + buffer_2_ptr[base_l + encrypto_size];
        
        base_l = (base_l + 1)%encrypto_size;
    }
}

void apk_decrypto_buffer_with_string(char *buffer,int32_t buffer_size,const char *encrypto_buffer,int32_t encrypto_size){
    uint8_t *buffer_ptr = (uint8_t *)buffer;
    const uint8_t *buffer_2_ptr = (const uint8_t *)encrypto_buffer;
    
    int32_t base_l = 0;
    for(int32_t j = 0;j < buffer_size; ++j){
        buffer_ptr[j] = (buffer_ptr[j] - buffer_2_ptr[base_l + encrypto_size]) ^ buffer_2_ptr[base_l];
        
        base_l = (base_l + 1)%encrypto_size;
    }
}

bool  apk_create_class_so_library_integration(const std::string &class_file,const char *aes_buffer,const std::string &header_name,int32_t split_number,const std::string &target_path,const std::string &application_name){
    char  buffer[8192];
    int32_t    base_addr = 0;
    
    //文件开头4字节的幻数
    uint32_t  magic = __magic_number;
    apk_copy_int32(buffer, magic);
    base_addr += 4;
    
    //接下来的4个字节记录文件长度,目前先空留着
    int32_t header_len_addr = base_addr;
    base_addr += 4;
    
    //接下来的2个字节是记录文件的数目
    apk_copy_int16(buffer + base_addr, split_number);
    base_addr += 2;
    
    //接下来的4字节是记录文件的长度
    int32_t file_length = apk_get_file_length(class_file);
    if(file_length == 0){
        printf("获取文件 %s 长度失败.............\n",class_file.c_str());
        return false;
    }
    int32_t file_length_addr = base_addr;
    //apk_copy_int32(buffer + base_addr, file_length);
    base_addr += 4;
    
    //接下来4个字节记录文件被压缩有的文件的长度,目前先空着,后面跟进
    int32_t  compress_length_addr = base_addr;
    base_addr += 4;
    
    //接下来,2字节记录application_name的字符串长度
    int32_t app_length = (int32_t)application_name.size();
    apk_copy_int16(buffer + base_addr, app_length + 1);
    base_addr += 2;
    //将字符串复制到缓冲区中
    memcpy(buffer + base_addr, application_name.c_str(), app_length);
    buffer[base_addr + app_length] = 0;
    base_addr += app_length + 1;
    
    //读取文件的内容
    std::string file_content;
    bool result_ref = apk_getFileContent(class_file, file_content);
    if(!result_ref){
        printf("--读取文件%s内容失败.....\n",class_file.c_str());
        return false;
    }
    
    //压缩文件数据
    char  *compress_data_ptr = new char[file_content.size()];
    int32_t  compress_length = (int32_t)file_content.size();
    int32_t compress_ref = apk_data_compress(file_content.data(), (int32_t)file_content.size(), compress_data_ptr, &compress_length);
    if(compress_ref != 0){
        printf("--压缩文件失败........\n");
        return false;
    }
    
    int32_t  file_size = compress_length;//(int32_t)file_content.size();
    uint32_t  aes_encrypto_size = 0;
    char *aes_data = tiny_aes_encrypt_cbc(compress_data_ptr, file_size, aes_buffer, 128, &aes_encrypto_size);
    
    int32_t  p_size = 0;//已经处理的字节数目
    //接下来将记录生成的文件名字,每一个名字的长度在 8 -- 15之间,并同时生成数据
    char  buffer_name[32];
    char buffer_file_name[1024];
    uint32_t dynamic_range = aes_encrypto_size * 2/(split_number * 3);
    uint32_t  varible = aes_encrypto_size/(3 * split_number);
    for(int32_t j = 0;j < split_number; ++j){
        int32_t  name_size = 8 + apk_random() % 8;
        //生成随机字符串
        apk_create_random_string(buffer_name, name_size);
        buffer_name[name_size] = 0;
        
        apk_copy_int16(buffer + base_addr, name_size + 1);
        base_addr += 2;
        
        memcpy(buffer + base_addr,buffer_name,name_size + 1);
        base_addr += name_size + 1;
        
        //同时生成相关的文件
        sprintf(buffer_file_name,"%s/%s",target_path.c_str(),buffer_name);
        std::ofstream  io_out;
        io_out.open(buffer_file_name,std::ios::trunc);
        if(!io_out.is_open()){
            printf("------生成文件 %s 失败.........\n",buffer_file_name);
            return false;
        }
        
        int32_t  process_size =( j ==split_number - 1)? aes_encrypto_size - p_size: dynamic_range + apk_random()%varible;
        io_out.write(aes_data + p_size, process_size);
        io_out.close();
        
        apk_copy_int32(buffer + base_addr, process_size);
        base_addr += 4;
        
        p_size += process_size;
    }
    
    if(aes_data != compress_data_ptr)
        delete[] aes_data;
    
    delete[] compress_data_ptr;
    compress_data_ptr = nullptr;
    //记录文件的总长度,作为以后的校验使用
    apk_copy_int32(buffer + header_len_addr, base_addr);
    apk_copy_int32(buffer + file_length_addr, (int32_t)file_content.size());
    apk_copy_int32(buffer + compress_length_addr, compress_length);
    
    apk_encrypto_buffer_with_string(buffer,base_addr,aes_buffer + 128,64);
    //将以上生成的信息写入到chapter文件中
    std::ofstream  out_io;
    out_io.open(header_name.c_str(),std::ios::trunc);
    if(!out_io.is_open()){
        printf("-----写入文件 %s 失败........\n",header_name.c_str());
        return false;
    }
    out_io.write(buffer, base_addr);
    out_io.close();
    
    return true;
}

void log_number(const uint8_t *buffer,int32_t number){
  //  char buffer2[512];
  //  int s = 0;

    for(int j = 0;j < number;++j) {
        uint32_t t0 = buffer[j];
        //s += sprintf(buffer2 + s, "%u,", t0);
        printf("------%d-----> %d\n",j,t0);

    }
}

bool apk_decode_class_so_library(const std::string &header_name,const char *aes_buffer,const std::string &target_path,std::string &application_name){
    std::string file_content;
    bool result_ref = apk_getFileContent(header_name, file_content);
    if(!result_ref){
        printf("---读取文件' %s'失败----------\n",header_name.c_str());
        return false;
    }
    //读取文件内容
    char *buffer = (char *)file_content.data();
    int32_t file_length = (int32_t)file_content.size();
    
    //log_number((const uint8_t *)buffer,10);
    
    //printf("---encrypto----content-----\n");
    log_number((const uint8_t *)aes_buffer + 128, 10);
    apk_decrypto_buffer_with_string(buffer,file_length,aes_buffer + 128,64);
    
    //printf("---after--decrypto-----\n");
    //log_number((const uint8_t *)buffer,10);
    
    int32_t  base_addr = 0;
    uint32_t  magic = apk_copy_buffer_to_uint32(buffer);
    base_addr += 4;
    if(magic != __magic_number){
        printf("--文件头 magic 校验失败......\n");
        return false;
    }
    
    //文件头长度
    uint32_t  header_size = apk_copy_buffer_to_uint32(buffer + base_addr);
    base_addr += 4;
    //如果文件长度校验不通过,则说明文件内容已经遭到了篡改
    if(header_size != file_length){
        printf("解码文件 失败,该文件已经被污染...\n");
        return false;
    }
    
    //计算文件数目
    int32_t file_number = apk_copy_buffer_to_uint16(buffer + base_addr);
    base_addr += 2;
    
    //计算文件的总的长度
    int32_t file_total_len = apk_copy_buffer_to_uint32(buffer + base_addr);
    base_addr += 4;
    
    //接下来是application名称
    int16_t app_len = apk_copy_buffer_to_uint16(buffer + base_addr);
    base_addr += 2;
    
    application_name.resize(app_len - 1);
    memcpy((char*)application_name.data(),buffer + base_addr,app_len - 1);
    base_addr += app_len;
    
    //进入循环处理
    std::string file_record;
    file_record.resize(file_total_len);
    char buffer_1024[1024];
    int32_t  p_size = 0;
    for(int32_t j = 0;j < file_number; ++j){
        int32_t name_size = apk_copy_buffer_to_uint16(buffer + base_addr);
        base_addr += 2;
        
        char buffer_name[64];
        memcpy(buffer_name,buffer + base_addr,name_size);
        base_addr += name_size;
        sprintf(buffer_1024,"%s/%s",target_path.c_str(),buffer_name);
        
        int32_t file_s0 = apk_copy_buffer_to_uint32(buffer + base_addr);
        base_addr += 4;
        
        //读取文件
        std::ifstream in_file;
        in_file.open(buffer_1024);
        if(!in_file.is_open()){
            printf("--读取文件'%s 失败.......\n'",buffer_1024);
            return false;
        }
        in_file.read((char *)file_record.data() + p_size,file_s0);
        in_file.close();
        
        p_size += file_s0;
    }
    
    uint32_t real_length = 0;
    char *buffer2_ptr = tiny_aes_decrypt_cbc((char *)file_record.data(), file_total_len,aes_buffer, 128, &real_length);
    
    //然后,将上述数据写入到文件中
    std::ofstream out_file;
    out_file.open("classes_v4.dex");
    if(!out_file.is_open()){
        printf("-----写入文件 %s 失败 。。。。\n","classes_v4.dex");
    }
    out_file.write(buffer2_ptr, real_length);
    out_file.close();
    
    if(buffer2_ptr != file_record.data())
        free(buffer2_ptr);
    
    return true;
}

bool  apk_enumerate_file_list_cascade(const std::string &directory,std::list<std::string> &file_list){
    std::list<std::string>   directory_list;
    directory_list.push_back(directory);
    
    while(!directory_list.empty()){
        auto &item = directory_list.front();
        DIR  *dir_ptr = opendir(item.c_str());
        
        struct dirent  *rent_item;
        while((rent_item = readdir(dir_ptr)) != nullptr){
            if(strcmp(rent_item->d_name,".") && strcmp(rent_item->d_name,"..") && !apk_string_start_with(rent_item->d_name,".")){
                char  buffer[512];
                //如果不是目录
                if(rent_item->d_type == DT_REG){
                    sprintf(buffer,"%s/%s",item.c_str(),rent_item->d_name);
                    file_list.push_back(buffer);
                }
                else if(rent_item->d_type == DT_DIR){
                    sprintf(buffer,"%s/%s",item.c_str(),rent_item->d_name);
                    directory_list.push_back(buffer);
                }
            }
        }
        
        closedir(dir_ptr);
        directory_list.pop_front();
    }
    
    return true;
}

uint32_t  apk_gen_seed_from_string(const char *buffer){
    uint32_t  seed = 0;
    for(int j = 0;buffer[j];++j){
        byte c = buffer[j];
        int32_t j2 = j + 1;
        seed += c *c* j2 + j2 * j2;
    }
    return seed;
}

bool apk_string_start_with(const char *a,const char *b){
    while(*a && *b && *a == *b){
        ++a;
        ++b;
    }
    return ! *b;
}

void apk_create_random_string(char *buffer,int32_t  buffer_size){
    for(int j = 0;j < buffer_size;++j){
        uint32_t  s0 = apk_random()%sizeof(s_char_array);
        buffer[j] = s_char_array[s0];
    }
    buffer[buffer_size] = 0;
}


void  apk_create_encrypto_key_buffer(char *buffer,int32_t buffer_size){
    for(int j =0;j < buffer_size;++j){
        uint32_t  s = apk_random();
        uint32_t j2 = j + 1;
        byte c = (s & 0xFF) + ((s >> 8) & 0xFF) + ((s >> 16) & 0xFF) + ((s >> 24) & 0xFF);
        buffer[j] = j2 * j2 * c * c + c * j2;
    }
}

int32_t  apk_encrypto_buffer_with_key(char *buffer,int32_t buffer_size,const char *encrypto_buffer,int32_t encrypto_size,int32_t from_idx){
    int32_t  base_s = from_idx;
    const byte *enc_ptr = (const byte *)encrypto_buffer;
    for(int32_t j = 0;j < buffer_size;++j){
        byte c = buffer[j];
        buffer[j] = (c ^ enc_ptr[base_s]) + enc_ptr[base_s + encrypto_size];
        base_s = (base_s + 1)%encrypto_size;
    }
    return base_s;
}

int32_t  apk_decrypto_buffer_with_key(char *buffer,int32_t buffer_size,const char *encrypto_buffer,int32_t encrypto_size,int32_t from_idx){
    int32_t  base_s = from_idx;
    const byte *enc_ptr = (const byte *)encrypto_buffer;
    for(int32_t j = 0;j < buffer_size;++j){
        byte c = buffer[j];
        buffer[j] = (c - enc_ptr[base_s + encrypto_size]) ^ enc_ptr[base_s];
        base_s = (base_s + 1)%encrypto_size;
    }
    return base_s;
}

bool  apk_create_directory(const std::string &directory_name){
    DIR *dir_ptr = opendir(directory_name.c_str());
    if(!dir_ptr){
        return !mkdir(directory_name.c_str(), 0775);
    }
    closedir(dir_ptr);
    dir_ptr = nullptr;
    return true;
}

bool  apk_create_directory_cascade(const std::string &directory_name){
    int j = 0;
    char  buffer[1024];
    
    const char *c_ptr = directory_name.c_str();
    while(c_ptr[j]){
        if(c_ptr[j] == '/'){
            buffer[j] = 0;
            DIR *dir_ptr = opendir(buffer);
            if(!dir_ptr){
                if(mkdir(buffer, 0775))
                    return false;
            }else
                closedir(dir_ptr);
        }
        
        buffer[j] = c_ptr[j];
        ++j;
    }
    buffer[j] = 0;
    //最后一步,也需要验证
    DIR *dir_ptr = opendir(buffer);
    if(!dir_ptr){
        if(mkdir(buffer, 0775))
            return false;
    }else
        closedir(dir_ptr);
    return true;
}

bool apk_copy_file_to_target(const std::string &src_file,const std::string &dst_file){
    std::ifstream  io_input;
    io_input.open(src_file);
    if(!io_input.is_open()){
        printf("file %s is not exist.\n",src_file.c_str());
        io_input.close();
        return false;
    }
    //获取文件长度
    io_input.seekg(0, std::ios::end);
    uint32_t  file_length = (uint32_t)io_input.tellg();
    io_input.seekg(0,std::ios::beg);
    
    char *buffer = new char[file_length];
    io_input.read(buffer, file_length);
    io_input.close();
    
    std::ofstream  io_out;
    io_out.open(dst_file,std::ios::trunc);
    
    if(!io_out.is_open()){
        delete[] buffer;
        printf("open file '%s' failed.\n",dst_file.c_str());
        return false;
    }
    io_out.write(buffer, file_length);
    io_out.close();
    
    delete[] buffer;
    buffer = nullptr;
    return true;
}

class RC4 {
    public:
        explicit RC4(void) {};
        void reset(const uint8_t *key, size_t len);
        void crypt(uint8_t *in, uint8_t *out, size_t len);
        ~RC4(void) {};

    private:
        uint8_t sbox[256];
        uint8_t idx1;
        uint8_t idx2;
        explicit RC4(const RC4&) = delete;
        explicit RC4(const RC4&&) = delete;
        const RC4& operator=(const RC4&) = delete;
        const RC4&& operator=(const RC4&&) = delete;
};

void RC4::reset(const uint8_t *key, size_t len) {
    uint8_t j = 0;

    for (auto i = 0; i < 256; i++)
        sbox[i] = i;
    idx1 = 0; idx2 = 0;

    for (auto i = 0; i < 256; i++) {
        j += sbox[i] + key[i % len];
        std::swap(sbox[i], sbox[j]);
    }
}

void RC4::crypt(uint8_t *in, uint8_t *out, size_t len) {
    uint8_t j = 0;

    for (auto i = 0; i < len; i++) {
        idx1++; idx2 += sbox[idx1];
        std::swap(sbox[idx1], sbox[idx2]);
        j = sbox[idx1] + sbox[idx2];
        out[i] = in[i] ^ sbox[j];
    }
}

//const char *AES_KEYCODE = "1234567812345678";
//const char *AES_IV = "1234567812345678";
#define AES_BLOCK_SIZE 16
char *tiny_aes_encrypt_cbc(char *in_data, int input_length, const char *encrypto_buffer,int32_t encrypto_size,uint32_t *output_length)
{
    RC4  rct;
    rct.reset((uint8_t *)encrypto_buffer, encrypto_size);
    rct.crypt((uint8_t *)in_data, (uint8_t *)in_data, input_length);
    
    *output_length = input_length;
    return in_data;
    
    //return (char *)xxtea_encrypt((uint8_t *)in_data,input_length,(uint8_t *)encrypto_buffer,encrypto_size,output_length);
}

char *tiny_aes_decrypt_cbc(char *in_data, int input_length,const char *encrypto_buffer,int32_t encrypto_size, uint32_t *output_length)
{
    RC4  rct;
    rct.reset((uint8_t *)encrypto_buffer, encrypto_size);
    rct.crypt((uint8_t *)in_data, (uint8_t *)in_data, input_length);
    
    *output_length = input_length;
    return in_data;
    //return (char *)xxtea_decrypt((uint8_t *)in_data, input_length, (uint8_t *)encrypto_buffer, encrypto_size, output_length);
}

void  apk_create_pack_name(char *pack_buffer,int32_t pack_size){
    //包名生成,中间需要增加点号
    int32_t  layer = pack_size/3;
    int32_t  base_l = 0;
    for(int32_t j = 0;j < 3; ++j){
        for(int32_t k = 0;k < layer; ++k){
            char c = !k ? s_char_pack0[apk_random()%sizeof(s_char_pack0)] : s_char_pack[apk_random()%sizeof(s_char_pack)];
            pack_buffer[base_l++] = c;
        }
        
        if(j !=  3 - 1)
            pack_buffer[base_l++] = '.';
    }
    pack_buffer[base_l] = 0;
    //包名开头不能以Fx开头
    if(pack_size >= 2 && (pack_buffer[0] == 'F' || pack_buffer['f']) && (pack_buffer[1] == 'X' || pack_buffer[1] == 'x')){
        char c = pack_buffer[0];
        pack_buffer[0] = pack_buffer[1];
        pack_buffer[1] = c;
    }
}

void apk_create_class_name(char *base_buffer,int32_t base_size){
    int32_t base_l = 0;
    for(int32_t k = 0;k < base_size; ++k){
        char c = !k ? s_char_pack0[apk_random()%sizeof(s_char_pack0)] : s_char_pack[apk_random()%sizeof(s_char_pack)];
        base_buffer[base_l++] = c;
    }
    base_buffer[base_l] = 0;
}

void apk_replace_char_with(char *buffer,char c,char s){
    for(int32_t j = 0;buffer[j];++j){
        if(buffer[j] == c)
            buffer[j] = s;
    }
}

bool apk_string_replace_with(std::string &target_string,const std::string &source_string,const std::string &dst_string){
    bool b2_sc = false;
    size_t  np = target_string.find(source_string);
    while(np != std::string::npos){
        target_string.replace(np, source_string.size(), dst_string);
        b2_sc = true;
        
        np = target_string.find(source_string);
    }
    return b2_sc;
}

bool apk_string_end_with(const char *s,const char *match){
    int j = 0,k = 0;
    while(s[j]) ++j;
    while(match[k]) ++k;
    
    while(j >=0 && k >= 0 && s[j] == match[k]){
        --j;
        --k;
    }
    return k == -1;
}
