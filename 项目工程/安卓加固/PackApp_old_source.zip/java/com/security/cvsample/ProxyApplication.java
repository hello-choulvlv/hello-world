package com.security.cvsample;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import android.annotation.SuppressLint;
import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.util.ArrayMap;
import android.util.Log;
import dalvik.system.DexClassLoader;
import dalvik.system.PathClassLoader;
//import dalvik.system.InMemoryDexClassLoader;
//import sun.misc.Cleaner;

import dalvik.system.DexFile;

public class ProxyApplication extends Application{
	static {
		System.loadLibrary("oceancs");
	}
	//private static final String appkey = "APPLICATION_CLASS_NAME";
	private String apkFileName;
	private String odexPath;
	private String libPath;
	private String[]  _run_string_array;

	public native String stringFromJNI();
	/*
	 *解码应用程序
	 * classes_dex_path:classes.dex文件存储路径
	 * so_path:so库的存储路径
	 */
	//public native String[] decodeApk(String pack_name,AssetManager asset,String classes_dex_path,String so_path);
	/*
	 *获取应用程序运行时,需要用到的三种数据
	 */
	//public native String[] decodeApk2(String pack_name,AssetManager asset);
	/*
	 *直接从JNI处创建ClassLoader,然后从内存直接加载字节码,启动应用程序
	 */
	private native int startFromNative(Application app,String pack_name,AssetManager asset,String jni_lib_path);

	private Application  _new_application;

	// 这是context赋值
	@SuppressLint("LongLogTag")
	@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(base);

		String source_dir = getApplicationInfo().sourceDir;
		File odex = this.getDir("payload_odex", MODE_PRIVATE);
		File libs = this.getDir("payload_lib", MODE_PRIVATE);
		File jni_libs = this.getDir("payload_jni_libs",MODE_PRIVATE);
		ClassLoader  loader = this.getClassLoader();
		loader.loadClass("");

		startFromNative(this,"org.cocos2dx.cpp.AppApplication",this.getAssets(),libs.getAbsolutePath());

		try {
			// 创建两个文件夹payload_odex、payload_lib，私有的，可写的文件目录
//			String source_dir = getApplicationInfo().sourceDir;
//			File odex = this.getDir("payload_odex", MODE_PRIVATE);
//			File libs = this.getDir("payload_lib", MODE_PRIVATE);
//			File jni_libs = this.getDir("payload_jni_libs",MODE_PRIVATE);


//
//			//getApplicationInfo().publicSourceDir;
//			//String install_path = this.getFilesDir();//getApplicationContext().getFilesDir().getAbsolutePath();
//			String install_path = this.getFilesDir().getAbsolutePath();
//			String install_2 = install_path.substring(0,install_path.lastIndexOf('/'));
//			displayFileTree(new File(install_2),"---install_path----");
//
//			String data_dir = this.getApplicationInfo().dataDir;
//			displayFileTree(new File(data_dir),"--------data_dir----");
//
//			//String res_path = getApplicationContext().getPackageResourcePath();
//			displayFileTree(new File(this.getPackageResourcePath()),"----res---path--");
//			displayFileTree(new File(this.getPackageResourcePath()).getParentFile(),"----base--res---path--");
//
//			odexPath = odex.getAbsolutePath();
//			libPath = libs.getAbsolutePath();
//			String jni_libs_dir = jni_libs.getAbsolutePath();
//
//			String jni_library = getApplicationInfo().nativeLibraryDir;
//			displayFileTree(new File(jni_library),"-----jni_library----");
//
//			Log.d("----odexPath---" + odex.exists(),odexPath);
//			Log.d("----libPath---" + libs.exists(),libPath);
//
//			displayFileTree(odex,"---source_dir");
//
//			apkFileName = odex.getAbsolutePath() + "/classes.dex";
//			File dexFile = new File(apkFileName);
//			Log.i("demo", "apk size:"+dexFile.length());
//			String packageName = this.getPackageName();//当前apk的包名
//			if (!dexFile.exists())
//				_run_string_array = this.decodeApk(packageName,this.getAssets(),odex.getAbsolutePath(),jni_libs_dir);
//			else
//				_run_string_array = this.decodeApk2(packageName,this.getAssets());
//			// 配置动态加载环境
//			Object currentActivityThread = RefInvoke.invokeStaticMethod(
//					"android.app.ActivityThread", "currentActivityThread",
//					new Class[] {}, new Object[] {});//获取主线程对象
//
//			ArrayMap mPackages = (ArrayMap) RefInvoke.getFieldOjbect(
//					"android.app.ActivityThread", currentActivityThread,
//					"mPackages");
//			WeakReference wr = (WeakReference) mPackages.get(packageName);
//			// 创建被加壳apk的DexClassLoader对象  加载apk内的类和本地代码（c/c++代码）
//			ClassLoader  default_class_loader2 = (ClassLoader) RefInvoke.getFieldOjbect("android.app.LoadedApk", wr.get(),"mClassLoader");
//			ClassLoader  default_class_loader = this.getClassLoader();
//			Log.d("----cladd-loader--0---",default_class_loader2.toString());
//			Log.d("----cladd-loader--1---",default_class_loader.toString());
//
//			DexClassLoader dLoader = new DexClassLoader(apkFileName, libPath,jni_libs_dir, default_class_loader);
//			//把当前进程的mClassLoader设置成了被加壳apk的DexClassLoader
//
//
//			inject_class_loader((PathClassLoader) default_class_loader2,dLoader);
//			RefInvoke.setFieldOjbect("android.app.LoadedApk", "mClassLoader", wr.get(), dLoader);
//
//			//显示odexPath文件夹下所有的文件
//			File target_file = new File(odexPath);
//			if(target_file.isDirectory()){
//				String[] sub_tree = target_file.list();
//				for(int j = 0;j < sub_tree.length;++j){
//					Log.d("--sub--directory--" + j,sub_tree[j]);
//				}
//			}
//
//			Log.i("------demo---------777---------","classloader:"+dLoader);
			
			try{
				//dLoader.findLibrary();
				//Object actObj = dLoader.loadClass(_run_string_array[2]);//"org.cocos2dx.lua.AppActivity");
				//Log.i("demo", "actObj:"+actObj);
			}catch(Exception e){
				Log.i("---发生异常---exception-----demo", "activity:"+Log.getStackTraceString(e));
			}
			
			this.attachBeforeCreation();
		} catch (Exception e) {
			Log.i("-----error----demo-------", "error:"+Log.getStackTraceString(e));
			e.printStackTrace();
		}
	}

	@SuppressLint("LongLogTag")
	private void attachBeforeCreation(){
		Log.i("----777----demo----", "onCreate");
		// 如果源应用配置有Appliction对象，则替换为源应用Applicaiton，以便不影响源程序逻辑。
		String appClassName = _run_string_array[1];//"org.cocos2dx.lua.SwtestApp";//null;
		//有值的话调用该Applicaiton
		Object currentActivityThread = RefInvoke.invokeStaticMethod(
				"android.app.ActivityThread", "currentActivityThread",
				new Class[] {}, new Object[] {});
		Object mBoundApplication = RefInvoke.getFieldOjbect(
				"android.app.ActivityThread", currentActivityThread,
				"mBoundApplication");
		Object loadedApkInfo = RefInvoke.getFieldOjbect(
				"android.app.ActivityThread$AppBindData",
				mBoundApplication, "info");
		//把当前进程的mApplication 设置成了null
		Log.i("----88888888----demo----", "onCreate");
		RefInvoke.setFieldOjbect("android.app.LoadedApk", "mApplication",
				loadedApkInfo, null);
		Object oldApplication = RefInvoke.getFieldOjbect(
				"android.app.ActivityThread", currentActivityThread,
				"mInitialApplication");
		// http://www.codeceo.com/article/android-context.html
		ArrayList<Application> mAllApplications = (ArrayList<Application>) RefInvoke
				.getFieldOjbect("android.app.ActivityThread",
						currentActivityThread, "mAllApplications");
		mAllApplications.remove(oldApplication); // 删除oldApplication

		ApplicationInfo appinfo_In_LoadedApk = (ApplicationInfo) RefInvoke
				.getFieldOjbect("android.app.LoadedApk", loadedApkInfo,
						"mApplicationInfo");
		ApplicationInfo appinfo_In_AppBindData = (ApplicationInfo) RefInvoke
				.getFieldOjbect("android.app.ActivityThread$AppBindData",
						mBoundApplication, "appInfo");
		Log.i("---9999----demo----", "onCreate");
		appinfo_In_LoadedApk.className = appClassName;
		appinfo_In_AppBindData.className = appClassName;
		Application app = (Application) RefInvoke.invokeMethod(
				"android.app.LoadedApk", "makeApplication", loadedApkInfo,
				new Class[] { boolean.class, Instrumentation.class },
				new Object[] { false, null }); // 执行 makeApplication（false,null）
		RefInvoke.setFieldOjbect("android.app.ActivityThread",
				"mInitialApplication", currentActivityThread, app);

		ArrayMap mProviderMap = (ArrayMap) RefInvoke.getFieldOjbect(
				"android.app.ActivityThread", currentActivityThread,
				"mProviderMap");
		Iterator it = mProviderMap.values().iterator();
		Log.i("----55555555----demo----", "onCreate");
		while (it.hasNext()) {
			Object providerClientRecord = it.next();
			Object localProvider = RefInvoke.getFieldOjbect(
					"android.app.ActivityThread$ProviderClientRecord",
					providerClientRecord, "mLocalProvider");
			RefInvoke.setFieldOjbect("android.content.ContentProvider",
					"mContext", localProvider, app);
		}

		Log.i("-----demo---000000--", "app:"+app);
		//app.onCreate();
		_new_application = app;
	}

	public void copyTargetFile(InputStream io_input,File out_file)throws IOException{
		if(!out_file.exists())
			out_file.createNewFile();
		FileOutputStream  file_out = new FileOutputStream(out_file);
		byte[]  buffer = new byte[1024];
		int byte_read = 0;
		while((byte_read = io_input.read(buffer)) != -1){
			file_out.write(buffer,0,byte_read);
		}
		file_out.close();
		io_input.close();

		//Class<?> class_object = Class.forName("");
		//Class.
	}

	public void displayFileTree(File  parent_s,String tag){
		LinkedList<File>  link = new LinkedList<File>();
		link.add(parent_s);

		int  idx = 0;
		while(!link.isEmpty()){
			File  file = link.removeFirst();
			Log.d(tag + idx,file.toString());

			if(file.isDirectory()) {
				File files[] = file.listFiles();
				for(int j= 0;files != null && j < files.length;++j)
					link.addLast(files[j]);
			}
			++idx;
		}
	}

	@SuppressLint("LongLogTag")
	@Override
	public void onCreate() {
		//super.onCreate();
		//loadResources(apkFileName);
//		Log.i("demo", "onCreate");
//		// 如果源应用配置有Appliction对象，则替换为源应用Applicaiton，以便不影响源程序逻辑。
//		String appClassName = _run_string_array[1];//"org.cocos2dx.lua.SwtestApp";//null;
//		//有值的话调用该Applicaiton
//		Object currentActivityThread = RefInvoke.invokeStaticMethod(
//				"android.app.ActivityThread", "currentActivityThread",
//				new Class[] {}, new Object[] {});
//		Object mBoundApplication = RefInvoke.getFieldOjbect(
//				"android.app.ActivityThread", currentActivityThread,
//				"mBoundApplication");
//		Object loadedApkInfo = RefInvoke.getFieldOjbect(
//				"android.app.ActivityThread$AppBindData",
//				mBoundApplication, "info");
//		//把当前进程的mApplication 设置成了null
//		RefInvoke.setFieldOjbect("android.app.LoadedApk", "mApplication",
//				loadedApkInfo, null);
//		Object oldApplication = RefInvoke.getFieldOjbect(
//				"android.app.ActivityThread", currentActivityThread,
//				"mInitialApplication");
//		// http://www.codeceo.com/article/android-context.html
//		ArrayList<Application> mAllApplications = (ArrayList<Application>) RefInvoke
//				.getFieldOjbect("android.app.ActivityThread",
//						currentActivityThread, "mAllApplications");
//		mAllApplications.remove(oldApplication); // 删除oldApplication
//
//		ApplicationInfo appinfo_In_LoadedApk = (ApplicationInfo) RefInvoke
//				.getFieldOjbect("android.app.LoadedApk", loadedApkInfo,
//						"mApplicationInfo");
//		ApplicationInfo appinfo_In_AppBindData = (ApplicationInfo) RefInvoke
//				.getFieldOjbect("android.app.ActivityThread$AppBindData",
//						mBoundApplication, "appInfo");
//		appinfo_In_LoadedApk.className = appClassName;
//		appinfo_In_AppBindData.className = appClassName;
//		Application app = (Application) RefInvoke.invokeMethod(
//				"android.app.LoadedApk", "makeApplication", loadedApkInfo,
//				new Class[] { boolean.class, Instrumentation.class },
//				new Object[] { false, null }); // 执行 makeApplication（false,null）
//		RefInvoke.setFieldOjbect("android.app.ActivityThread",
//				"mInitialApplication", currentActivityThread, app);
//
//		ArrayMap mProviderMap = (ArrayMap) RefInvoke.getFieldOjbect(
//				"android.app.ActivityThread", currentActivityThread,
//				"mProviderMap");
//		Iterator it = mProviderMap.values().iterator();
//		while (it.hasNext()) {
//			Object providerClientRecord = it.next();
//			Object localProvider = RefInvoke.getFieldOjbect(
//					"android.app.ActivityThread$ProviderClientRecord",
//					providerClientRecord, "mLocalProvider");
//			RefInvoke.setFieldOjbect("android.content.ContentProvider",
//					"mContext", localProvider, app);
//		}
//
//		Log.i("demo", "app:"+app);
//		app.onCreate();
		if(_new_application != null){
			_new_application.onCreate();
			Log.i("------_new_application-------", "--onCreate-----");
			_new_application = null;
		}
	}
	
	//以下是加载资源
	protected AssetManager mAssetManager;//资源管理器  
	protected Resources mResources;//资源  
	protected Theme mTheme;//主题  
	
	protected void loadResources(String dexPath) {  
        try {  
            AssetManager assetManager = AssetManager.class.newInstance();  
            Method addAssetPath = assetManager.getClass().getMethod("addAssetPath", String.class);  
            addAssetPath.invoke(assetManager, dexPath);  
            mAssetManager = assetManager;  
        } catch (Exception e) {  
        	Log.i("inject", "loadResource error:"+Log.getStackTraceString(e));
            e.printStackTrace();  
        }  
        Resources superRes = super.getResources();  
        superRes.getDisplayMetrics();  
        superRes.getConfiguration();  
        mResources = new Resources(mAssetManager, superRes.getDisplayMetrics(),superRes.getConfiguration());  
        mTheme = mResources.newTheme();  
        mTheme.setTo(super.getTheme());
    }  
	
	@Override  
	public AssetManager getAssets() {  
	    return mAssetManager == null ? super.getAssets() : mAssetManager;  
	}  
	
	@Override  
	public Resources getResources() {  
	    return mResources == null ? super.getResources() : mResources;  
	}  
	
	@Override  
	public Theme getTheme() {  
	    return mTheme == null ? super.getTheme() : mTheme;  
	}
	// -------------------------reflect-----------------
	/*
	 *将后面class loader中的类加载路径合并到前面的class loader 中去
	 */
	private void inject_class_loader(PathClassLoader path_class_loader,DexClassLoader loader){
		//PathClassLoader pathLoader = (PathClassLoader) getClassLoader();
		try {
			Object dexElements = combineArray(
					getDexElements(getPathList(path_class_loader)),
					getDexElements(getPathList(loader)));
			Object pathList = getPathList(loader);
			setField(pathList, pathList.getClass(), "dexElements", dexElements);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private static Object getPathList(Object baseDexClassLoader)
			throws IllegalArgumentException, NoSuchFieldException, IllegalAccessException, ClassNotFoundException {
		ClassLoader bc = (ClassLoader)baseDexClassLoader;
		return getField(bc, Class.forName("dalvik.system.BaseDexClassLoader"), "pathList");
	}

	private static Object getField(Object obj, Class<?> cl, String field)
			throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
		Field localField = cl.getDeclaredField(field);
		localField.setAccessible(true);
		return localField.get(obj);
	}

	private static Object getDexElements(Object paramObject)
			throws IllegalArgumentException, NoSuchFieldException, IllegalAccessException {
		return getField(paramObject, paramObject.getClass(), "dexElements");
	}
	private static void setField(Object obj, Class<?> cl, String field,
								 Object value) throws NoSuchFieldException,
			IllegalArgumentException, IllegalAccessException {

		Field localField = cl.getDeclaredField(field);
		localField.setAccessible(true);
		localField.set(obj, value);
	}

	private static Object combineArray(Object arrayLhs, Object arrayRhs) {
		Class<?> localClass = arrayLhs.getClass().getComponentType();
		int i = Array.getLength(arrayLhs);
		int j = i + Array.getLength(arrayRhs);
		Object result = Array.newInstance(localClass, j);
		for (int k = 0; k < j; ++k) {
			if (k < i) {
				Array.set(result, k, Array.get(arrayLhs, k));
			} else {
				Array.set(result, k, Array.get(arrayRhs, k - i));
			}
		}
		return result;
	}
}
