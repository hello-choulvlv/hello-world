//
// Created by yitong li on 9/5/21.
//

#ifndef PACKAPK_APK_CODER_DECODER_HPP
#define PACKAPK_APK_CODER_DECODER_HPP

#include <string>
#include <list>
#include <functional>
#include "android/asset_manager.h"
#include "android/log.h"
#include <stdint.h>

#define __TAG "----解码----"
#define apk_log_i(...) __android_log_print(ANDROID_LOG_INFO,__TAG,__VA_ARGS__)
// 定义debug信息
#define apk_log_d(...) __android_log_print(ANDROID_LOG_DEBUG, __TAG, __VA_ARGS__)
// 定义error信息
#define apk_log_e(...) __android_log_print(ANDROID_LOG_ERROR,__TAG,__VA_ARGS__)

#define  __magic_number 0x7C8A5A4B
#define  __chapter_magic  0x9A675E3F
#define  __check_sum_mask  "wiyuopvnfbjk0747865"

#ifdef __cplusplus
//extern "C"{
#endif

typedef unsigned char byte;
static const size_t kSha1DigestSize = 20;

// Raw header_item.
struct Header
{
    uint8_t  magic_[8];
    uint32_t checksum_;        // See also location_checksum_
    uint8_t  signature_[kSha1DigestSize];
    uint32_t file_size_;       // size of entire file
    uint32_t header_size_;     // offset to start of next section
    uint32_t endian_tag_;
    uint32_t link_size_;       // unused
    uint32_t link_off_;        // unused
    uint32_t map_off_;         // unused
    uint32_t string_ids_size_; // number of StringIds
    uint32_t string_ids_off_;  // file offset of StringIds array
    uint32_t type_ids_size_;   // number of TypeIds, we don't support more than 65535
    uint32_t type_ids_off_;    // file offset of TypeIds array
    uint32_t proto_ids_size_;  // number of ProtoIds, we don't support more than 65535
    uint32_t proto_ids_off_;   // file offset of ProtoIds array
    uint32_t field_ids_size_;  // number of FieldIds
    uint32_t field_ids_off_;   // file offset of FieldIds array
    uint32_t method_ids_size_; // number of MethodIds
    uint32_t method_ids_off_;  // file offset of MethodIds array
    uint32_t class_defs_size_; // number of ClassDefs
    uint32_t class_defs_off_;  // file offset of ClassDef array
    uint32_t data_size_;       // unused
    uint32_t data_off_;        // unused
};

//typedef int  int32_t;
//typedef unsigned int uint32_t;

uint32_t apk_copy_buffer_to_uint32(const char *buffer);
void  apk_copy_int32(char *buffer,uint32_t  ick);
uint32_t apk_copy_buffer_to_uint16(const char *buffer);
void apk_copy_int16(char *buffer,uint32_t  ick);
void  apk_compute_checksum(const char *buffer,int32_t buffer_size,char buffer_4[4]);


/*
 *获取文件内容,如果文件不存在,则返回false
 */
bool  apk_getFileContent(const std::string &file_name,std::string &file_content);
/*
 *创建文件,并将数据写入到其中
 */
bool  apk_create_file_with_content(const std::string  &file_name,const char *buffer,int32_t  buffer_size);
/*
 *文件解码
 */
void apk_decode_class_so_library(char *buffer,uint32_t  buffer_size,const std::string &classes_path,const std::string &so_path);
/*
 *随机数生成器,发生种子
 */
void  apk_rand_seed(uint32_t  seed);
uint32_t  apk_random();
/*
 *给定字符串生成uint32_t数字
 */
uint32_t  apk_gen_seed_from_string(const char *buffer);
/*
 *生成加密Key
 */
void  apk_create_encrypto_key_buffer(char *buffer,int32_t buffer_size);
/*
 *字符串前缀比较
 *a字符串是否以b字符串为前缀
 */
bool apk_string_start_with(const char *a,const char *b);
/*
 *生成指定数目的随机字符串
 */
void apk_create_random_string(char *buffer,int32_t  buffer_size);

/*
 *  解码大纲文件,并同时生成对应的离散文件
 */
bool apk_decode_chapter_file(const std::string &header_name,const char *encrypto_buffer,int32_t encrypto_size);
bool apk_decode_chapter_file(AAssetManager *native_asset,const std::string &header_name,const char *encrypto_buffer,int32_t encrypto_size,
        std::function<void(char *,int32_t,int32_t)> &class_callback,const std::string &so_path,std::string param_array[3]);
/*
 *解密缓冲区内容
 */
int32_t  apk_decrypto_buffer_with_key(char *buffer,int32_t buffer_size,const char *encrypto_buffer,int32_t encrypto_size,int32_t from_idx = 0);
/*
 * jstring到C++ string转换
 */
void apk_jstring_to_char_buffer(JNIEnv *env,jstring js_str,std::string &std_string);

#ifdef __cplusplus
//}
#endif

#endif //PACKAPK_APK_CODER_DECODER_HPP
