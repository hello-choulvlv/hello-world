//
// Created by yitong li on 9/5/21.
//

#include <jni.h>
#include <string>
#include "apk_coder_decoder.hpp"
#include "android/asset_manager.h"
#include "android/asset_manager_jni.h"
#include <stdlib.h>
#include <dlfcn.h>
#include "android/log.h"
#include "apk_coder_decoder.hpp"

#include <fstream>
#include <assert.h>

#define  __magic_number 0x7C8A5A4B
#define  __chapter_magic  0x9A675E3F
#define  __check_sum_mask  "wiyuopvnfbjk0747865"

static const char s_char_array[] = {
        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        'a','b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
        '0','1','2','3','4','5','6','7','8','9','_','-','$'
};

static uint32_t  s_seed;
void  apk_rand_seed(uint32_t  seed){
    s_seed = seed;
}

uint32_t  apk_random(){
    uint32_t  new_seed = s_seed * 71597 + 1720273;
    s_seed = new_seed;
    return new_seed;
}
//计算文件的校验和
void  apk_compute_checksum(const char *buffer,int32_t buffer_size,char buffer_4[4]){
    const char *mask_ptr = __check_sum_mask;
    int32_t  mask_size = sizeof(__check_sum_mask);

    int32_t  buffer_idx = 0;
    int32_t  mask_idx = 0;

    for(int j = 0;j < buffer_size; ++j){
        buffer_4[buffer_idx] += buffer[j] ^ mask_ptr[mask_idx];
        buffer_idx = (buffer_idx +1) % 4;
        mask_idx = (mask_idx + 1) % mask_size;
    }
}
/*
 *赋值,将整数复制到缓冲区对象中
 */
void  apk_copy_int32(char *buffer,uint32_t  ick){
    buffer[0] = ick & 0xFF;
    buffer[1] = (ick >> 8) & 0xFF;
    buffer[2] = (ick >> 16) & 0xFF;
    buffer[3] = (ick >> 24) & 0xFF;
}

uint32_t apk_copy_buffer_to_uint32(const char *buffer){
    const byte *b2c = (const byte *)buffer;
//    uint32_t a = b2c[0];
//    uint32_t b = b2c[1];
//    uint32_t c = b2c[2];
//    uint32_t d = b2c[3];
//    return a | (b << 8) | (c << 16) | (d << 24);
    return b2c[0] | (b2c[1] << 8) | (b2c[2] << 16) | (b2c[3] << 24);
}

uint32_t apk_copy_buffer_to_uint16(const char *buffer){
    const byte *b2c = (const byte *)buffer;
//    uint32_t a = *b2c;
//    uint32_t b = b2c[1];
//    return a | (b << 8);
    return b2c[0] | (b2c[1] << 8);
}

void apk_copy_int16(char *buffer,uint32_t  ick){
    buffer[0] = ick & 0xFF;
    buffer[1] = (ick >> 8) & 0xFF;
}

/*
 *解码文件,同时生成相关的文件
 */
void apk_decode_class_so_library(char *buffer,uint32_t  buffer_size,std::function<void(char *,int32_t,int32_t)> &class_callback,const std::string &so_path){
    uint32_t  magic = apk_copy_buffer_to_uint32(buffer);
    if(magic != __magic_number){
        apk_log_e("--文件头 magic 校验失败......\n");
        return;
    }
    //文件头长度
    uint32_t  header_size = apk_copy_buffer_to_uint16(buffer + 24);//buffer[24] + (buffer[25] << 8);
    //如果整个文件的长度没有达到这一步,则说明该文件非法
    if(header_size >= buffer_size){
        apk_log_e("解码文件 失败,该文件长度结构非法...\n");
        return ;
    }
    //计算有效的文件长度
    uint32_t total_size = apk_copy_buffer_to_uint32(buffer + 26);//buffer[26] + (buffer[27] << 8) + (buffer[28] << 16) + (buffer[29] << 24);
    if(total_size + header_size != buffer_size){
        apk_log_e("文件 内容遭到破坏,请重新给出正确格式文件进行解码....\n");
        return;
    }
    //读取剩下的文件头
    uint32_t  n_item = apk_copy_buffer_to_uint16(buffer + 30);//buffer[30] + (buffer[31] << 8);
    char  buffer_4[4] = {0,0,0,0};

    int32_t  base_addr = 32;
    const std::string classes_path = "classes.dex";
    uint32_t  file_offset = header_size;
    for(int  base_j = 0; base_j < n_item; ++base_j,base_addr += 2) {
        uint32_t struct_addr = apk_copy_buffer_to_uint16(buffer + base_addr);//buffer[base_addr] + (buffer[base_addr + 1] << 8);
        char *so_info = buffer + struct_addr;
        //文件长度
        uint32_t so_length = apk_copy_buffer_to_uint32(so_info);//so_info[0] + (so_info[1] << 8) + (so_info[2] << 16) + (so_info[3] << 24);
        //文件的指针
        uint32_t so_ptr = apk_copy_buffer_to_uint32(so_info + 4);//so_info[4] + (so_info[5] << 8) + (so_info[6] << 16) + (so_info[7] << 24);
        //文件名字长度
        uint32_t name_length = apk_copy_buffer_to_uint16(so_info + 8);//so_info[8] + (so_info[9] << 8);
        //assert(file_offset == so_ptr);
        file_offset += so_length;
        //文件名字
        char name_buffer[1024];
        const std::string &path_str = !base_j ? classes_path.c_str() : so_path.c_str();
        sprintf(name_buffer, "%s/", path_str.c_str());

        memcpy(name_buffer + path_str.size() + 1, so_info + 14, name_length);
        name_buffer[path_str.size() + 1 + name_length] = 0;
        //针对文件内容做校验
        char buffer_r4[4] = {0, 0, 0, 0};
        char *so_buffer = buffer + so_ptr;
        apk_compute_checksum(so_buffer, so_length, buffer_r4);
        //total_buffer += so_length;
        buffer_4[0] += buffer_r4[0];
        buffer_4[1] += buffer_r4[1];
        buffer_4[2] += buffer_r4[2];
        buffer_4[3] += buffer_r4[3];

        if (buffer_r4[0] != so_info[10] || buffer_r4[1] != so_info[11] ||
            buffer_r4[2] != so_info[12] || buffer_r4[3] != so_info[13]) {
            apk_log_e("文件 '%s' 校验和不正确....\n", name_buffer);
            continue;
        }
        //如果是classes.dex文件,则需要一个回调函数进行解析,在当前版本中,我们将会只进行单一文件的解析
        if (!base_j) {
            class_callback(so_buffer,0,so_length);
        } else {
            //写入到文件中
            std::ofstream io_out;
            io_out.open(name_buffer);
            if (!io_out.is_open()) {
                //写文件失败
                apk_log_e("写文件 '%s' 失败....\n", name_buffer);
                io_out.close();
                continue;
            }
            io_out.write(so_buffer, so_length);
            io_out.close();
        }
    }
    //最后一步,验证整个文件的校验和
    apk_compute_checksum(buffer + 8, header_size - 8, buffer_4);
    if(buffer_4[0] != buffer[4] || buffer_4[1] != buffer[5] || buffer_4[2] != buffer[6] || buffer_4[3] != buffer[7]){
        apk_log_e("文件 校验和不正确....\n ");
    }
}

uint32_t  apk_gen_seed_from_string(const char *buffer){
    uint32_t  seed = 0;
    for(int j = 0;buffer[j];++j){
        byte c = buffer[j];
        seed += c *c* j + j * j;
    }
    return seed;
}

bool apk_decode_chapter_file(AAssetManager *native_asset,const std::string &header_name,const char *encrypto_buffer,int32_t encrypto_size,
                             std::function<void(char *,int32_t,int32_t)> &class_callback,const std::string &so_path,std::string param_array[3]){
    //首先读取头20个字节的信息
    AAsset *asset = AAssetManager_open(native_asset,header_name.c_str(),AASSET_MODE_BUFFER);
    if(!asset){
        apk_log_e("---打开文件--%s---失败---",header_name.c_str());
        return false;
    }
    //获取文件的大小
    uint32_t  file_length = AAsset_getLength(asset);
    //如果小于26字节,则必定非法
    if(file_length < 26 || file_length > 4096){
        apk_log_e("---输入文件'%s'非法..... \n",header_name.c_str());
        AAsset_close(asset);
        return false;
    }
    //头26字节
    char *chapter_buffer = new char[file_length];
    int32_t read_ref = AAsset_read(asset,chapter_buffer,file_length);
    AAsset_close(asset);
    if(!read_ref){
        apk_log_e("---read--file-'%s'-content--error.",header_name.c_str());
        delete[] chapter_buffer;
        return false;
    }
    //解密
    apk_decrypto_buffer_with_key(chapter_buffer, file_length, encrypto_buffer, encrypto_size,0);

    uint32_t magic = apk_copy_buffer_to_uint32(chapter_buffer);
    //apk_log_d("--magic-->%x",magic);
    if(magic != __chapter_magic){
        apk_log_e("--文件'%s'magic不正确...\n",header_name.c_str());
        free(chapter_buffer);
        return false;
    }
    //读取文件的长度
    uint32_t  chapter_size = apk_copy_buffer_to_uint16(chapter_buffer + 8);
    if(chapter_size != file_length){
        apk_log_e("--文件'%s'结构已经遭到破坏------",header_name.c_str());
        free(chapter_buffer);
        return false;
    }
    //读取总文件长度
    uint32_t  total_file_size = apk_copy_buffer_to_uint32(chapter_buffer + 10);
    //pack offset
    uint32_t pack_offset = apk_copy_buffer_to_uint16(chapter_buffer + 14);
    for(int j =0;j < 3;++j){
        int32_t str_length = apk_copy_buffer_to_uint16(chapter_buffer + pack_offset);
        pack_offset += 2;
        param_array[j].resize(str_length);

        memcpy((char *)param_array[j].data(),chapter_buffer + pack_offset,str_length);
        pack_offset += str_length;
    }
    //计算文件的校验和
    char buffer_4[4] = {0,0,0,0};
    apk_compute_checksum(chapter_buffer + 8, file_length - 8, buffer_4);
    if(buffer_4[0] != chapter_buffer[4] || buffer_4[1] != chapter_buffer[5] || buffer_4[2] != chapter_buffer[6] || buffer_4[3] != chapter_buffer[7]){
        apk_log_e("----文件'%s' 内容已经被污染...\n",header_name.c_str());
        free(chapter_buffer);
        return false;
    }
    //针对剩余的项读取器中的值
    uint32_t  n_item = apk_copy_buffer_to_uint16(chapter_buffer + 24);
    uint32_t  total_size = 0;
    uint32_t  base_addr = 26;
    for(int32_t  step_l = 0;step_l < n_item;++step_l){
        uint32_t  sub_size = apk_copy_buffer_to_uint32(chapter_buffer + base_addr);
        base_addr += 4;
        //跳过文件名字符串
        while(chapter_buffer[base_addr] != 0)
            ++base_addr;
        ++base_addr;

        total_size += sub_size;
    }
    //与总文件长度进行校验
    if(total_size != total_file_size){
        apk_log_e("----文件'%s'结构已经被破坏....\n",header_name.c_str());
        free(chapter_buffer);
        return false;
    }
    //建立缓冲区
    char *total_buffer = new char[total_size];
    base_addr = 26;
    int32_t file_ptr = 0;
    //std::string  file_record;
    for(int32_t  step_l = 0;step_l < n_item;++step_l){
        uint32_t  sub_size = apk_copy_buffer_to_uint32(chapter_buffer + base_addr);
        base_addr += 4;

        AAsset  *secondary_asset = AAssetManager_open(native_asset,chapter_buffer + base_addr,AASSET_MODE_BUFFER);

        if(!secondary_asset){
            apk_log_e("---读取文件'%s'失败，解码中断...",chapter_buffer + base_addr);
            free(chapter_buffer);
            return false;
        }
        uint32_t secondary_length = AAsset_read(asset,total_buffer + file_ptr,sub_size);
        assert(secondary_length == sub_size);
        AAsset_close(secondary_asset);

        //跳过文件名字符串
        while(chapter_buffer[base_addr] != 0)
            ++base_addr;
        ++base_addr;

        file_ptr += sub_size;
    }
    //解密
    apk_decrypto_buffer_with_key(total_buffer, total_size, encrypto_buffer, encrypto_size);
    //再次调用另一个函数对已经生成的值进行解码
    apk_decode_class_so_library(total_buffer, total_size,class_callback,so_path);

    delete[] chapter_buffer;
    chapter_buffer = nullptr;

    delete[] total_buffer;
    total_buffer = nullptr;

    return true;
}

bool apk_decode_chapter_file(AAssetManager *native_asset,const std::string &header_name,const char *encrypto_buffer,int32_t encrypto_size,std::string param_array[3]) {
    AAsset *asset = AAssetManager_open(native_asset,header_name.c_str(),AASSET_MODE_BUFFER);
    if(!asset){
        return false;
    }
    //获取文件的大小
    uint32_t  file_length = AAsset_getLength(asset);
    //如果小于26字节,则必定非法
    if(file_length < 26 || file_length > 4096){
        AAsset_close(asset);
        return false;
    }
    //头26字节
    //char *chapter_buffer = new char[file_length + 32];
    char chapter_buffer[4096];
    int32_t read_ref = AAsset_read(asset,chapter_buffer,file_length);
    AAsset_close(asset);
    if(read_ref != file_length){
        free(chapter_buffer);
        return false;
    }
    //解密
    apk_decrypto_buffer_with_key(chapter_buffer, file_length, encrypto_buffer, encrypto_size,0);
    uint32_t magic = apk_copy_buffer_to_uint32(chapter_buffer);
    if(magic != __chapter_magic){
        apk_log_e("--文件'%s'magic不正确...\n",header_name.c_str());
        free(chapter_buffer);
        return false;
    }
    //读取文件的长度
    uint32_t  chapter_size = apk_copy_buffer_to_uint16(chapter_buffer + 8);
    if(chapter_size != file_length){
        free(chapter_buffer);
        return false;
    }
    //pack offset
    uint32_t pack_offset = apk_copy_buffer_to_uint16(chapter_buffer + 14);
    for(int j = 0;j < 3; ++j){
        int32_t str_length = apk_copy_buffer_to_uint16(chapter_buffer + pack_offset);
        pack_offset += 2;
        param_array[j].resize(str_length);
        memcpy((char *)param_array[j].data(),chapter_buffer + pack_offset,str_length);
        pack_offset += str_length;
    }
    return true;
}


void  apk_create_encrypto_key_buffer(char *buffer,int32_t buffer_size){
    for(int j =0;j < buffer_size;++j){
        uint32_t  s = apk_random();
        byte c = (s & 0xFF) + ((s >> 8) & 0xFF) + ((s >> 16) & 0xFF) + ((s >> 24) & 0xFF);
        buffer[j] = c * c + c;
    }
}

int32_t  apk_decrypto_buffer_with_key(char *buffer,int32_t buffer_size,const char *encrypto_buffer,int32_t encrypto_size,int32_t from_idx){
    int32_t  base_s = from_idx;
    const byte *enc_ptr = (const byte *)encrypto_buffer;
    for(int32_t j = 0;j < buffer_size;++j){
        byte c = buffer[j];
        buffer[j] = (c - enc_ptr[base_s + encrypto_size]) ^ enc_ptr[base_s];
        base_s = (base_s + 1)%encrypto_size;
    }
    return base_s;
}
/*
 * 从jstring到char*映射
 */
void apk_jstring_to_char_buffer(JNIEnv *env,jstring js_str,std::string &std_string){
    const char *js_char_ptr = env->GetStringUTFChars(js_str, nullptr);
    std_string = js_char_ptr;
    env->ReleaseStringUTFChars(js_str,js_char_ptr);
}


extern "C" JNIEXPORT JNICALL
jstring Java_com_security_cvsample_ProxyApplication_stringFromJNI(JNIEnv* env,jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}
/*
 * 对Apk中的文件进行解码
 * *需要输入apk安装包的包名
 * 以数组的形式返回将要运行的Pack名字 + Application名字 + Activity名字
 */
extern "C" JNIEXPORT JNICALL
jobjectArray Java_com_security_cvsample_ProxyApplication_decodeApk(JNIEnv* env,jobject /* this */,jstring apk_name,jobject asset_object,
                                                                   jstring classes_dex_path,jstring so_path){
    AAssetManager *native_asset =  AAssetManager_fromJava(env,asset_object);
    //获取包名
    std::string pack_name;
    apk_jstring_to_char_buffer(env,apk_name,pack_name);
    //apk_log_d("--pack--name-00->%s,pack size-->%d\n",pack_name.c_str(),(int32_t)pack_name.size());

    //生成随机数种子
    uint32_t seed = apk_gen_seed_from_string(pack_name.c_str());
    //apk_log_d("---seed--->%u",seed);
    apk_rand_seed(seed);

    //生成加密char buffer数组
    const int encrypto_buffer_size = 256;
    char encrypto_buffer[encrypto_buffer_size];
    int32_t  encrypto_size = 128;
    apk_create_encrypto_key_buffer(encrypto_buffer,encrypto_buffer_size);
//    for(int32_t j =0;j < 16;++j) {
//        uint32_t ts = (byte)encrypto_buffer[j];
//        apk_log_d("-B %d-> %x",j, ts);
//    }
//    //从encrypto_size索引开始遍历16个字节
//    for(int32_t j =0;j < 16;++j) {
//        uint32_t ts = (byte)encrypto_buffer[encrypto_size + j];
//        apk_log_d("-M-%d-> %x",encrypto_size + j, ts);
//    }
    //生成的文件的存储路径
    std::string classes_path_string,so_path_string;
    apk_jstring_to_char_buffer(env,classes_dex_path,classes_path_string);
    apk_jstring_to_char_buffer(env,so_path,so_path_string);

    //有关应用程序启动时需要的输入参数,需要从加密文件中解码生成
    std::string param_array[3];
    std::string header_name = "__param.userdata";
    //bool decoder_ref = apk_decode_chapter_file(native_asset,header_name,encrypto_buffer,encrypto_size,classes_path_string,so_path_string,param_array);
    //如果解码成功,则返回三个字符串信息
    jclass string_class = env->FindClass("java/lang/String");
    jobjectArray string_array = env->NewObjectArray(3,string_class, nullptr);

    for(int j = 0;j < 3;++j){
        jstring js_str = env->NewStringUTF(param_array[j].c_str());
        env->SetObjectArrayElement(string_array,j,js_str);
        env->DeleteLocalRef(js_str);
    }

    return string_array;
}
/*
 * 解码应用程序,只单纯的返回pack name + application name + activity name
 */
extern "C" JNIEXPORT JNICALL
jobjectArray Java_com_security_cvsample_ProxyApplication_decodeApk2(JNIEnv *env, jobject thiz, jstring apk_name,jobject asset) {
    //apk_log_d("-----stage --44444444--------");
    AAssetManager *native_asset =  AAssetManager_fromJava(env,asset);
    assert(native_asset != nullptr);
    //获取包名
    std::string pack_name;
    apk_jstring_to_char_buffer(env,apk_name,pack_name);

    //apk_log_d("--pack--name-->%s\n",pack_name.c_str());

    //生成随机数种子
    uint32_t seed = apk_gen_seed_from_string(pack_name.c_str());
    apk_rand_seed(seed);
    //apk_log_d("-----stage --00--------");
    //生成加密char buffer数组
    const int encrypto_buffer_size = 256;
    char encrypto_buffer[encrypto_buffer_size];
    int32_t  encrypto_size = 128;
    apk_create_encrypto_key_buffer(encrypto_buffer,encrypto_buffer_size);
//    for(int32_t j =0;j < 16;++j) {
//        uint32_t ts = (byte)encrypto_buffer[j];
//        apk_log_d("--> %x", ts);
//    }
    //apk_log_d("-----stage --111111--------");
    //有关应用程序启动时需要的输入参数,需要从加密文件中解码生成
    std::string param_array[3];
    std::string header_name = "__param.userdata";
    bool decoder_ref = apk_decode_chapter_file(native_asset,header_name,encrypto_buffer,encrypto_size,param_array);
    //apk_log_d("-----stage --222222--------");
    //如果解码成功,则返回三个字符串信息
    jclass string_class = env->FindClass("java/lang/String");
    jobjectArray string_array = env->NewObjectArray(3,string_class, nullptr);
    //apk_log_d("-----stage --555555--------");
    for(int j = 0;j < 3;++j){
        jstring js_str = env->NewStringUTF(param_array[j].c_str());
        env->SetObjectArrayElement(string_array,j,js_str);
        env->DeleteLocalRef(js_str);
    }
    //apk_log_d("-----stage --666666--------");
    //env->DefineClass();
    //env->
    return string_array;
}
