//
//  log.h
//  shell
//
//  Created by liu meng on 2018/2/4.
//  Copyright © 2018年 liu mengcom.example. All rights reserved.
//

#ifndef log_h
#define log_h
#define TRACE(fmt,args...)  printf(fmt,args)
#define DL_ERR(fmt,args...) printf(fmt,args)
#endif /* log_h */
