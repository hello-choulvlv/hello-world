//
//  Encryption.h
//  shell
//
//  Created by liu meng on 2018/2/4.
//  Copyright © 2018年 liu mengcom.example. All rights reserved.
//

#ifndef Encryption_h
#define Encryption_h
#include "elf.h"
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
int encryption(char *path);
#endif /* Encryption_h */
