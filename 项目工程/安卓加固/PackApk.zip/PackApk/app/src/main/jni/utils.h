#ifndef _BANGCLE_UTILS_H
#define _BANGCLE_UTILS_H
#include <jni.h>
#include <fcntl.h>
//#include <string>

int extract_file(JNIEnv *env, jobject ctx, char *app_name, char **buffer_ptr,int *buffer_size);
void *get_module_base(pid_t pid, const char *module_name);
void *get_addr_symbol(char *module_name, char *target_symbol);

#endif
