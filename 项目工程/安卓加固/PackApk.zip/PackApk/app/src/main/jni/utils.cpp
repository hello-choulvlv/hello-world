#include "utils.h"
#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>

#include <stdlib.h>
#include <string.h>
#include <string>
#include "elfGotHook/logger.h"

#include "xxtea.h"
#include "auto_patch.h"

#define  __magic_number 0x7C8A5A4B

static const char s_char_array[] = {
        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        'a','b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
        '0','1','2','3','4','5','6','7','8','9','_','-','$'
};

static const char s_char_pack0[] = {
        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        'a','b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','_',
};

static const char s_char_pack[] = {
        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        'a','b','c','d','e','f','g','h','i','g','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
        '0','1','2','3','4','5','6','7','8','9','_',
};

class RC4 {
public:
    explicit RC4(void) {};
    void reset(const uint8_t *key, size_t len);
    void crypt(uint8_t *in, uint8_t *out, size_t len);
    ~RC4(void) {};

private:
    uint8_t sbox[256];
    uint8_t idx1;
    uint8_t idx2;
    explicit RC4(const RC4&) = delete;
    explicit RC4(const RC4&&) = delete;
    const RC4& operator=(const RC4&) = delete;
    const RC4&& operator=(const RC4&&) = delete;
};

void RC4::reset(const uint8_t *key, size_t len) {
    uint8_t j = 0;

    for (auto i = 0; i < 256; i++)
        sbox[i] = i;
    idx1 = 0; idx2 = 0;

    for (auto i = 0; i < 256; i++) {
        j += sbox[i] + key[i % len];
        std::swap(sbox[i], sbox[j]);
    }
}

void RC4::crypt(uint8_t *in, uint8_t *out, size_t len) {
    uint8_t j = 0;

    for (auto i = 0; i < len; i++) {
        idx1++; idx2 += sbox[idx1];
        std::swap(sbox[idx1], sbox[idx2]);
        j = sbox[idx1] + sbox[idx2];
        out[i] = in[i] ^ sbox[j];
    }
}

void apk_decrypto_buffer_with_string(char *buffer,int32_t buffer_size,const char *encrypto_buffer,int32_t encrypto_size){
    uint8_t *buffer_ptr = (uint8_t *)buffer;
    const uint8_t *buffer_2_ptr = (const uint8_t *)encrypto_buffer;

    int32_t base_l = 0;
    for(int32_t j = 0;j < buffer_size; ++j){
        buffer_ptr[j] = (buffer_ptr[j] - buffer_2_ptr[base_l + encrypto_size]) ^ buffer_2_ptr[base_l];
        base_l = (base_l + 1)%encrypto_size;
    }
}

uint32_t  apk_gen_seed_from_string(const char *buffer){
    uint32_t  seed = 0;
    for(int j = 0;buffer[j];++j){
        uint8_t c = buffer[j];
        int32_t j2 = j + 1;
        seed += c *c* j2 + j2 * j2;
    }
    return seed;
}

static uint32_t  s_seed;
void  apk_rand_seed(uint32_t  seed){
    s_seed = seed;
}

uint32_t  apk_random(){
    uint32_t  new_seed = s_seed * 71597 + 1720273;
    s_seed = new_seed;
    return new_seed;
}

void  apk_create_encrypto_key_buffer(char *buffer,int32_t buffer_size){
    for(int j =0;j < buffer_size;++j){
        uint32_t  s = apk_random();
        uint32_t j2 = j + 1;
        uint8_t c = (s & 0xFF) + ((s >> 8) & 0xFF) + ((s >> 16) & 0xFF) + ((s >> 24) & 0xFF);
        buffer[j] = j2 * j2 * c * c + c * j2;
    }
}

uint32_t apk_copy_buffer_to_uint32(const char *buffer){
    uint8_t *b2c = (uint8_t *)buffer;
    return b2c[0] | (b2c[1] << 8) | (b2c[2] << 16) | (b2c[3] << 24);
}

uint32_t apk_copy_buffer_to_uint16(const char *buffer){
    uint8_t *b2c = (uint8_t *)buffer;
    return b2c[0] | (b2c[1] << 8);
}

void apk_create_random_string(char *buffer,int32_t  buffer_size){
    for(int j = 0;j < buffer_size;++j){
        uint32_t  s0 = apk_random()%sizeof(s_char_array);
        buffer[j] = s_char_array[s0];
    }
    //buffer[buffer_size] = 0;
}

void  apk_create_pack_name(char *pack_buffer,int32_t pack_size){
    //包名生成,中间需要增加点号
    int32_t  layer = pack_size/3;
    int32_t  base_l = 0;
    for(int32_t j = 0;j < 3; ++j){
        for(int32_t k = 0;k < layer; ++k){
            char c = !k ? s_char_pack0[apk_random()%sizeof(s_char_pack0)] : s_char_pack[apk_random()%sizeof(s_char_pack)];
            pack_buffer[base_l++] = c;
        }

        if(j !=  3 - 1)
            pack_buffer[base_l++] = '.';
    }
    pack_buffer[base_l] = 0;
    //包名开头不能以Fx开头
    if(pack_size >= 2 && (pack_buffer[0] == 'F' || pack_buffer['f']) && (pack_buffer[1] == 'X' || pack_buffer[1] == 'x')){
        char c = pack_buffer[0];
        pack_buffer[0] = pack_buffer[1];
        pack_buffer[1] = c;
    }
}

void apk_create_class_name(char *base_buffer,int32_t base_size){
    int32_t base_l = 0;
    for(int32_t k = 0;k < base_size; ++k){
        char c = !k ? s_char_pack0[apk_random()%sizeof(s_char_pack0)] : s_char_pack[apk_random()%sizeof(s_char_pack)];
        base_buffer[base_l++] = c;
    }
    base_buffer[base_l] = 0;
}

void apk_replace_char_with(char *buffer,char c,char s){
    for(int32_t j = 0;buffer[j];++j){
        if(buffer[j] == c)
            buffer[j] = s;
    }
}

char *tiny_aes_decrypt_cbc(char *in_data, int input_length,const char *encrypto_buffer,int32_t encrypto_size, uint32_t *output_length)
{
    RC4  rct;
    rct.reset((uint8_t *)encrypto_buffer, encrypto_size);
    rct.crypt((uint8_t *)in_data, (uint8_t *)in_data, input_length);

    *output_length = input_length;
    return in_data;
    //return (char *)xxtea_decrypt((uint8_t *)in_data, input_length, (uint8_t *)encrypto_buffer, encrypto_size, output_length);
}


void log_number(const uint8_t *buffer,int32_t number){
    int s = 0;

    for(int j = 0;j < number;++j) {
        uint32_t t0 = buffer[j];
        LOGD("------%d-----> %d",j,t0);

    }
}

int32_t apk_decode_class_so_library(AAssetManager *asset_manager,const std::string &header_name,const char *aes_buffer,char *application_name,char **file_buffer){
    std::string file_content;
    AAsset *header_asset = AAssetManager_open(asset_manager,header_name.c_str(),AASSET_MODE_STREAMING);
    if(!header_asset){
        LOGE("---读取文件' %s'失败----------\n",header_name.c_str());
        return 0;
    }
    //读取文件内容
    int32_t s0 = AAsset_getLength(header_asset);
    file_content.resize(s0);
    AAsset_read(header_asset,(char *)file_content.data(),s0);
    AAsset_close(header_asset);

    char *buffer = (char *)file_content.data();
    int32_t file_length = (int32_t)file_content.size();

    apk_decrypto_buffer_with_string(buffer,file_length,aes_buffer + 128,64);

    int32_t  base_addr = 0;
    uint32_t  magic = apk_copy_buffer_to_uint32(buffer);
    base_addr += 4;
    //LOGE("---文件头---%x-----",magic);
    if(magic != __magic_number){
        LOGE("--文件头 magic 校验失败......\n");
        return 0;
    }

    //文件头长度
    uint32_t  header_size = apk_copy_buffer_to_uint32(buffer + base_addr);
    base_addr += 4;
    //如果文件长度校验不通过,则说明文件内容已经遭到了篡改
    if(header_size != file_length){
        LOGE("解码文件 失败,该文件已经被污染...\n");
        return 0;
    }

    //计算文件数目
    int32_t file_number = apk_copy_buffer_to_uint16(buffer + base_addr);
    base_addr += 2;

    //计算文件的总的长度
    int32_t file_total_len = apk_copy_buffer_to_uint32(buffer + base_addr);
    base_addr += 4;

    //接下来是application名称
    int16_t app_len = apk_copy_buffer_to_uint16(buffer + base_addr);
    base_addr += 2;

    memcpy(application_name,buffer + base_addr,app_len);
    base_addr += app_len;

    //进入循环处理
    //file_record.resize(file_total_len);
    char *file_record = new char[file_total_len];
    int32_t  p_size = 0;
   // LOGD("-----------spli number--->  %d",file_number);
    for(int32_t j = 0;j < file_number; ++j){
        int32_t name_size = apk_copy_buffer_to_uint16(buffer + base_addr);
        base_addr += 2;

        char buffer_name[64];
        memcpy(buffer_name,buffer + base_addr,name_size);
        base_addr += name_size;

        int32_t file_s0 = apk_copy_buffer_to_uint32(buffer + base_addr);
        base_addr += 4;

        //读取文件
        AAsset *in_object = AAssetManager_open(asset_manager,buffer_name,AASSET_MODE_STREAMING);

        if(!in_object){
            LOGE("--读取文件'%s 失败.......\n'",buffer_name);
            return false;
        }
        AAsset_read(in_object,file_record + p_size,file_s0);
        AAsset_close(in_object);

        p_size += file_s0;
    }

    uint32_t real_length = 0;
    *file_buffer = tiny_aes_decrypt_cbc(file_record, file_total_len,aes_buffer, 128, &real_length);

    if(file_record != *file_buffer)
        delete[] file_record;

    return real_length;
}

int extract_file(JNIEnv *env, jobject ctx, char *app_name, char **buffer_ptr,int *buffer_size)
{
    jclass ApplicationClass = env->GetObjectClass(ctx);
    char seed_buffer[512];

    jclass system_class = env->FindClass("java/lang/System");
    //method getProperty
    jmethodID getProperty_id = env->GetStaticMethodID(system_class,"getProperty", "(Ljava/lang/String;)Ljava/lang/String;");
    jstring v_metal = env->NewStringUTF("v-metal");
    jstring value_str = (jstring)env->CallStaticObjectMethod(system_class,getProperty_id,v_metal);
    const char *c_value_str = env->GetStringUTFChars(value_str,nullptr);

    strcpy(seed_buffer,c_value_str);
    env->ReleaseStringUTFChars(value_str,c_value_str);

    env->DeleteLocalRef(value_str);
    env->DeleteLocalRef(v_metal);
    env->DeleteLocalRef(system_class);

    //LOGD("--seed--string--  %s",seed_buffer);

    jmethodID getAssets = env->GetMethodID(ApplicationClass, "getAssets", "()Landroid/content/res/AssetManager;");
    jobject Assets_obj = env->CallObjectMethod(ctx, getAssets);
    AAssetManager *asset_object = AAssetManager_fromJava(env, Assets_obj);

    if (!asset_object)
    {
        LOGE("[-]getAAssetManager failed");
        return 0;
    }

    uint32_t seed = apk_gen_seed_from_string(seed_buffer);
    //LOGD("seed--->%u \n",seed);
    apk_rand_seed(seed);

    //aes buffer
    const int encrypto_buffer_size = 256;
    char aes_buffer[encrypto_buffer_size];
    //使用当前的包名生成加密key
    apk_create_encrypto_key_buffer(aes_buffer,encrypto_buffer_size);

    char header_buffer[32];
    const int32_t header_size = 12;
    apk_create_random_string(header_buffer, header_size);
    header_buffer[header_size] = 0;
    std::string header_file(header_buffer);

    *buffer_size = apk_decode_class_so_library(asset_object,header_buffer, aes_buffer, app_name, buffer_ptr);

   // LOGD("---app name--- %s ",app_name);

    //env->DeleteLocalRef(PackageItemInfoClass);
    env->DeleteLocalRef(Assets_obj);
    //env->DeleteLocalRef(pmAppInfo);
    env->DeleteLocalRef(ApplicationClass);
    //env->DeleteLocalRef(packageManager);

    LOGD("-----------step----yyyyyyyy----------------");
    if(!*buffer_size)
        LOGE("--------error to decode file-----");
    return *buffer_size;
} // extract_file

void *get_module_base(pid_t pid, const char *module_name)
{
    FILE *fp;
    long addr = 0;
    char *pch;
    char filename[32];
    char line[1024];

    if (pid < 0)
    {
        /* self process */
        snprintf(filename, sizeof(filename), "/proc/self/maps", pid);
    }
    else
    {
        snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    }

    fp = fopen(filename, "r");

    if (fp != NULL)
    {
        while (fgets(line, sizeof(line), fp))
        {
            if (strstr(line, module_name))
            {
                pch = strtok(line, "-");
                addr = strtoull(pch, NULL, 16);

                if (addr == 0x8000)
                {
                    addr = 0;
                }

                break;
            }
        }

        fclose(fp);
    }

    return (void *)addr;
} // get_module_base
