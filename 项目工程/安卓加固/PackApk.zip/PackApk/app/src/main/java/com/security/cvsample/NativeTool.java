package com.security.cvsample;

/**
 * Created by i on 2021/10/30.
 */
import android.content.Context;
import android.app.Application;
public class NativeTool {
    public static native void attachBaseContext(Context ctx,Application app);
    public static native void onCreate(Context ctx,Application app);
    public static native int  unseal(Context ctx,Class class_2);
}
