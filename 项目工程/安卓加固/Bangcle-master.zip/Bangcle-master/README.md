# About

Bangcle  is a Android Protector

It use  the  second generation Android Hardening Protection, load the encrypted dex file from memory dynamically

## Compatibility

Support Android Version  

- 4.4
- 5.0
- 5.1
- 6.0
- 7.0
- 7.1
- 8.0
- 8.1

### How to use

Enter **bangcle_tool** directory    
Run this command to protect you App

```java
java -jar Bangcle.jar b AppName
```

The encrypted Apk is located at **output** folder


