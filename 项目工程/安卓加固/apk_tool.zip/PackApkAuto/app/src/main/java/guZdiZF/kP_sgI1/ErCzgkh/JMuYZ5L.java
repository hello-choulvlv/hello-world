package guZdiZF.kP_sgI1.ErCzgkh;

/**
 * Created by i on 2021/10/30.
 */
import android.content.Context;
import android.app.Application;
public class JMuYZ5L {
    public static native void QOVgPkCSLpldAd5Qw_h(Context ctx,Application app);
    public static native void XKQ5ATN5I3(Context ctx,Application app);
    public static native int  PJ_hWRNcNWwgS(Context ctx,Class class_2);
}
