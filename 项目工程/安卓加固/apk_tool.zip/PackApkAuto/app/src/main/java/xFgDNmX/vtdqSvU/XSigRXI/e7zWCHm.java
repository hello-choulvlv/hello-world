package xFgDNmX.vtdqSvU.XSigRXI;


import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.util.Log;

import java.lang.reflect.Method;

public class e7zWCHm extends Application{

	static {
		System.setProperty("v-metal","M0_5etM_I79$gz");
		System.setProperty("s2-67","2445937");
		System.loadLibrary("oceancs");
	}

	// 这是context赋值
	@SuppressLint("LongLogTag")
	@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(base);
		int ret = FM8LkHF.NP1uZSkGI9k4(base,Class.class);//Reflection.unseal(base);
		//Log.e("---reflection--result-->",Integer.toString(ret));
		FM8LkHF.JDHu12XmNCN2_mK(this.getBaseContext(),this);
	}

	@SuppressLint("LongLogTag")
	@Override
	public void onCreate() {
		FM8LkHF.mKoOepXauSWX(this.getBaseContext(),this);
	}
}
