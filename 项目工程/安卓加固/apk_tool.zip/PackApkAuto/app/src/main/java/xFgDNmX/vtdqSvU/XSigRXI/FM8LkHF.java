package xFgDNmX.vtdqSvU.XSigRXI;

/**
 * Created by i on 2021/10/30.
 */
import android.content.Context;
import android.app.Application;
public class FM8LkHF {
    public static native void JDHu12XmNCN2_mK(Context ctx,Application app);
    public static native void mKoOepXauSWX(Context ctx,Application app);
    public static native int  NP1uZSkGI9k4(Context ctx,Class class_2);
}
