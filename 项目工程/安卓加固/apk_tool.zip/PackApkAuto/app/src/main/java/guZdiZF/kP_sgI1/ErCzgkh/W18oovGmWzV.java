package guZdiZF.kP_sgI1.ErCzgkh;


import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.util.Log;

import java.lang.reflect.Method;

public class W18oovGmWzV extends Application{

	static {
		System.setProperty("v-metal","LSDg$qgnyc0JlYor");
		System.setProperty("s2-67","2208265");
		System.loadLibrary("oceancs");
	}

	// 这是context赋值
	@SuppressLint("LongLogTag")
	@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(base);
		int ret = JMuYZ5L.PJ_hWRNcNWwgS(base,Class.class);//Reflection.unseal(base);
		//Log.e("---reflection--result-->",Integer.toString(ret));
		JMuYZ5L.QOVgPkCSLpldAd5Qw_h(this.getBaseContext(),this);
	}

	@SuppressLint("LongLogTag")
	@Override
	public void onCreate() {
		JMuYZ5L.XKQ5ATN5I3(this.getBaseContext(),this);
	}
}
