#include "packer.h"
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <errno.h>
#include <assert.h>
#include <sys/system_properties.h>
#include <string>
#include <cstdlib>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <vector>
#include <bits/unique_ptr.h>

#include "common.h"
#include "dex_header.h"
#include "utils.h"
#include "byte_load.h"
#include "hook_instance.h"
#include "elfGotHook/tools.h"
#include "elfGotHook/elf_reader.h"
// #include "openssl/openssl/aes.h"
#include "auto_patch.h"
#include "fake_dlfcn.h"

#define CBC 1
#define CTR 1
#define ECB 1

#define PAGE_SIZE 4096
#define PAGE_OFFSET(x) ((x) & ~PAGE_MASK)
#define PAGE_END(x) PAGE_START((x) + (PAGE_SIZE - 1))

#if defined(__aarch64__)
#define LIB_ART_PATH "/system/lib64/libart.so"
#elif defined(__arm__)
#define LIB_ART_PATH "/system/lib/libart.so"
#else
#define LIB_ART_PATH "/system/lib/libart.so"
#endif

#define REGREX ".*/libart\\.so$"
#define JIAMI_MAGIC "jiami.dat"
#define PACKER_MAGIC ".jiagu"

using namespace std;

char g_jiagu_dir[256] = {0}; // 加密dex的所在目录
bool g_isArt = false;
int g_sdk_int = 0;
const char *g_file_dir;
//const char *g_NativeLibDir;
char *g_PackageResourcePath;
char *g_pkgName;
int g_dex_size = 0;  // main.dex的真正大小
int g_page_size = 0; // main.dex进行页面对齐后的大小
char g_fake_dex_magic[256] = {0};
void *g_decrypt_base = NULL;
void *g_ArtHandle = NULL;

static char g_application_name[512];

void native_attachBaseContext(JNIEnv *env, jobject obj, jobject ctx,jobject app_object);
void native_onCreate(JNIEnv *, jobject, jobject,jobject app_object);
jint JNICALL native_unseal(JNIEnv *env, jclass clazz, jobject ctx,jclass class_2);
int unseal(JNIEnv *env, jint targetSdkVersion);

typedef void (*API_setHiddenApiExemptions)(jobject ,jobjectArray);
void (*api_setHiddenApiExemptions_handler)(jobject ,jobjectArray) = nullptr;

void  apk_rand_seed(uint32_t  seed);
uint32_t  apk_random();
void apk_create_pack_name(char *pack_buffer,int32_t pack_size);
void apk_create_class_name(char *base_buffer,int32_t base_size);
void apk_replace_char_with(char *buffer,char c,char s);

unsigned char MINIDEX[292] = {
    0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x35, 0x00, 0xD9, 0x24, 0x14, 0xFD, 0x2F, 0x81, 0x4D, 0x8B,
    0x50, 0x48, 0x13, 0x1D, 0x8D, 0xA9, 0xCF, 0x1F, 0xF1, 0xF2, 0xDD, 0x06, 0xB4, 0x67, 0x70, 0xA1,
    0x24, 0x01, 0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x78, 0x56, 0x34, 0x12, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0xD8, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x70, 0x00, 0x00, 0x00,
    0x02, 0x00, 0x00, 0x00, 0x7C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x84, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0xA4, 0x00, 0x00, 0x00,
    0xA4, 0x00, 0x00, 0x00, 0xB4, 0x00, 0x00, 0x00, 0xC8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x0E, 0x4C, 0x63, 0x6F, 0x6D, 0x2F, 0x6D, 0x69, 0x78, 0x43, 0x6C, 0x61,
    0x73, 0x73, 0x3B, 0x00, 0x12, 0x4C, 0x6A, 0x61, 0x76, 0x61, 0x2F, 0x6C, 0x61, 0x6E, 0x67, 0x2F,
    0x4F, 0x62, 0x6A, 0x65, 0x63, 0x74, 0x3B, 0x00, 0x0D, 0x6D, 0x69, 0x78, 0x43, 0x6C, 0x61, 0x73,
    0x73, 0x2E, 0x6A, 0x61, 0x76, 0x61, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00,
    0x70, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x7C, 0x00, 0x00, 0x00,
    0x06, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x84, 0x00, 0x00, 0x00, 0x02, 0x20, 0x00, 0x00,
    0x03, 0x00, 0x00, 0x00, 0xA4, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
    0xD8, 0x00, 0x00, 0x00};

void write_mix_dex(const char *minidex)
{
    // If the file exists,skip
    if (access(minidex, F_OK) == -1)
    {
        FILE *file = fopen(minidex, "wb");
        fwrite(MINIDEX, 292, 1, file);
        fclose(file);
        LOGD("[+]mix dex saved at:%s", minidex);
    }
}

//static JNINativeMethod methods[] = {
//    {__attachBaseContext_micro, "(Landroid/content/Context;Landroid/app/Application;)V", (void *)native_attachBaseContext},
//    {__onCreate_micro, "(Landroid/content/Context;Landroid/app/Application;)V", (void *)native_onCreate},
//    {__unseal_micro, "(Landroid/content/Context;Ljava/lang/Class;)I", (void *)native_unseal}};

//为某一个类注册相关函数
int jniRegisterNativeMethods(JNIEnv *env, const char *className, const JNINativeMethod *gMethods, int numMethods)
{
    jclass clazz;
    int tmp;

    clazz = env->FindClass(className);
    if (clazz == NULL)
    {
        return -1;
    }
    if ((tmp = env->RegisterNatives(clazz, gMethods, numMethods)) < 0)
    {
        LOGE("[-]RegisterNatives failed");
        return -1;
    }
    return 0;
}

int lookup(JNINativeMethod *table, const char *name, const char *sig, void **fnPtrout)
{
    int i = 0;

    while (table[i].name != NULL)
    {
        // LOGD("[+]lookup %d %s" ,i,table[i].name);
        if ((strcmp(name, table[i].name) == 0) &&
            (strcmp(sig, table[i].signature) == 0))
        {
            *fnPtrout = table[i].fnPtr;
            return 1;
        }
        i++;
    }

    return 0;
}

char *mmap_dex(const char *szDexPath)
{
    int fd;
    struct stat buf = {0};

    fd = open(szDexPath, 0);
    if (!fd)
    {
        LOGE("[-]open %s failed:%s", szDexPath, strerror(errno));
        return NULL;
    }
    int status = stat(szDexPath, &buf);
    if (status == -1)
    {
        LOGE("[-]fstat %s failed", szDexPath);
        return NULL;
    }

    // 设置页面对齐
    g_dex_size = buf.st_size;
    char *dexBase = (char *)mmap(0, g_dex_size, 3, 2, fd, 0);
    close(fd);
    return dexBase;
}

#ifdef __cplusplus
extern "C"
{
#endif

    void _init(void)
    {
        LOGD("This is DT_INIT");
    }

#ifdef __cplusplus
}
#endif

jint mem_loadDex_dvm(JNIEnv *env, char *szPath)
{
    void (*openDexFile)(const u4 *args, union JValue *pResult);
    void *ldvm = (void *)dlopen("libdvm.so", 1);
    if (!ldvm)
    {
        LOGE("[-]could not dlopen dvm:%s", dlerror());
    }
    JNINativeMethod *dvm_dalvik_system_DexFile = (JNINativeMethod *)dlsym(ldvm, "dvm_dalvik_system_DexFile");
    if (0 == lookup(dvm_dalvik_system_DexFile, "openDexFile", "([B)I", (void **)&openDexFile))
    {
        LOGE("[-]dvm_dalvik_system_DexFile method does not found ");
        return 0;
    }

    char *arr;
    arr = (char *)malloc(16 + g_dex_size);
    ArrayObject *ao = (ArrayObject *)arr;
    // LOGD("sizeof ArrayObject:%d",sizeof(ArrayObject));
    ao->length = g_dex_size;
    memcpy(arr + 16, (char *)g_decrypt_base, g_dex_size);
    munmap((char *)g_decrypt_base, g_dex_size);
    g_decrypt_base = nullptr;

    u4 args[] = {(u4)(long)ao};
    union JValue pResult;
    if (openDexFile != NULL)
    {
        openDexFile(args, &pResult);
        jint mCookie = (jint)(long)pResult.l;
        return mCookie;
    }
    else
    {
        LOGE("[-]cannot get dvm_dalvik_system_DexFile addr");
        return 0;
    }
}

void make_dex_elements(JNIEnv *env, jobject classLoader, jobject dexFileobj)
{
    jclass PathClassLoader = env->GetObjectClass(classLoader);
    jclass BaseDexClassLoader = env->GetSuperclass(PathClassLoader);
    // get pathList fieldid
    jfieldID pathListid = env->GetFieldID(BaseDexClassLoader, "pathList", "Ldalvik/system/DexPathList;");
    jobject pathList = env->GetObjectField(classLoader, pathListid);

    // get DexPathList Class
    jclass DexPathListClass = env->GetObjectClass(pathList);
    // get dexElements fieldid
    jfieldID dexElementsid = env->GetFieldID(DexPathListClass, "dexElements", "[Ldalvik/system/DexPathList$Element;");
    jobjectArray dexElement = static_cast<jobjectArray>(env->GetObjectField(pathList, dexElementsid));

    jint len = env->GetArrayLength(dexElement);

    LOGD("[+]Elements size:%d", len);

    jclass ElementClass = env->FindClass("dalvik/system/DexPathList$Element"); // dalvik/system/DexPathList$Element
    jmethodID Elementinit = env->GetMethodID(ElementClass, "<init>",
                                             "(Ljava/io/File;ZLjava/io/File;Ldalvik/system/DexFile;)V");
    jboolean isDirectory = JNI_FALSE;

    jobject element_obj = env->NewObject(ElementClass, Elementinit, NULL, isDirectory, NULL, dexFileobj);

    // Get dexElement all values and add  add each value to the new array
    jobjectArray new_dexElement = env->NewObjectArray(len + 1, ElementClass, NULL);
    for (int i = 0; i < len; ++i)
    {
        env->SetObjectArrayElement(new_dexElement, i, env->GetObjectArrayElement(dexElement, i));
    }

    env->SetObjectArrayElement(new_dexElement, len, element_obj);
    env->SetObjectField(pathList, dexElementsid, new_dexElement);

    env->DeleteLocalRef(element_obj);
    env->DeleteLocalRef(ElementClass);
    env->DeleteLocalRef(dexElement);
    env->DeleteLocalRef(DexPathListClass);
    env->DeleteLocalRef(pathList);
    env->DeleteLocalRef(BaseDexClassLoader);
    env->DeleteLocalRef(PathClassLoader);
} // make_dex_elements

// For Nougat
void replace_cookie_N(JNIEnv *env, jobject mini_dex_obj, jlong value)
{
    jclass DexFileClass = env->FindClass("dalvik/system/DexFile"); // "dalvik/system/DexPathList$Element"
    jfieldID field_mCookie;
    jobject mCookie;

    field_mCookie = env->GetFieldID(DexFileClass, "mCookie", "Ljava/lang/Object;");
    mCookie = env->GetObjectField(mini_dex_obj, field_mCookie);

    jboolean is_data_copy = 1;
    jsize arraylen = env->GetArrayLength((jarray)mCookie);
    LOGD("[+]g_sdk_int:%d,cookie arrayLen:%d", g_sdk_int, arraylen);

    jlong *mix_element = env->GetLongArrayElements((jlongArray)mCookie, &is_data_copy);
    jlong *c_dex_cookie = (jlong *)value;

    jlong *tmp = mix_element;
    *(tmp + 1) = value;
    // 更新mCookie
    env->ReleaseLongArrayElements((jlongArray)mCookie, mix_element, 0);
    if (env->ExceptionCheck())
    {
        LOGE("[-]g_sdk_int:%d Update cookie failed", g_sdk_int);
        return;
    }

    jlong *second_mix_element = env->GetLongArrayElements((jlongArray)mCookie, &is_data_copy);
    jlong ptr = *(second_mix_element + 1);
    int dexbase = *(int *)(ptr + 4);
    int dexsize = *(int *)(ptr + 8);
    LOGD("[+]Nougat after replace cookie dex base:%x,dexsize:%x", dexbase, dexsize);
}

void replace_cookie_M(JNIEnv *env, jobject mini_dex_obj, jlong value)
{
    jclass DexFileClass = env->FindClass("dalvik/system/DexFile"); // "dalvik/system/DexPathList$Element"
    jfieldID field_mCookie;
    jobject mCookie;

    field_mCookie = env->GetFieldID(DexFileClass, "mCookie", "Ljava/lang/Object;");
    mCookie = env->GetObjectField(mini_dex_obj, field_mCookie);

    jboolean is_data_copy = 1;
    jsize arraylen = env->GetArrayLength((jarray)mCookie);
    LOGD("[+]g_sdk_int:%d,cookie arrayLen:%d", g_sdk_int, arraylen);

    jlong *mix_element = env->GetLongArrayElements((jlongArray)mCookie, &is_data_copy);

    // 这里的mix_element 等价于openMemory的返回值
    int ptr = *(int *)mix_element;
    int dexbase = *(int *)(ptr + 4);
    int dexsize = *(int *)(ptr + 8);
    LOGD("[+]mini dex array len :%d,dex magic:%x,dexsize:%x", arraylen, *(int *)dexbase, dexsize);
    // very important
    // jlong* tmp=mix_element;
    // *tmp=*c_dex_cookie;
    *mix_element = value;
    // 更新mCookie
    env->ReleaseLongArrayElements((jlongArray)mCookie, mix_element, 0);
    if (env->ExceptionCheck())
    {
        LOGE("[-]g_sdk_int:%d Update cookie failed", g_sdk_int);
        return;
    }
    jlong *second_mix_element = env->GetLongArrayElements((jlongArray)mCookie, &is_data_copy);
    ptr = *(int *)second_mix_element;
    dexbase = *(int *)(ptr + 4);
    dexsize = *(int *)(ptr + 8);
    LOGD("[+]second minidex dex dex magic:%x,dexsize:%x", *(int *)dexbase, dexsize);
    LOGD("[+]replace_cookie_one successful");
} // replace_cookie_M

char *get_path_frommaps(const char *pkgName, char *buffer, char *filter1, char *filter2)
{
    int pid = getpid();
    char map[256] = {0};

    sprintf(map, "/proc/%d/maps", pid);
    FILE *fd = fopen(map, "r");
    if (!fd)
    {
        LOGE("[-]open %s failed", map);
        return NULL;
    }

    while (true)
    {
        char line_buffer[256] = {0};
        if (!fgets(line_buffer, 255, fd))
        {
            break;
        }
        // 寻找带有包名和.dex或.odex的行
        if (strstr(line_buffer, pkgName) && (strstr(line_buffer, filter1) || strstr(line_buffer, filter2)))
        {
            // LOGD("[+]targt line buffer:%s", line_buffer);
            char *p= strchr(line_buffer, '/');
            // 获取需要复制的长度
            // line_buffer结尾是一个换行符
            int len = strlen(line_buffer) - (p- (char *)line_buffer) - 1;
            memcpy(buffer, p, len);
            return buffer;
        }
    }
    fclose(fd);
    return NULL;
}

jobject load_dex_fromfile(JNIEnv *env, const char *inPath, const char *outPath)
{
    jclass DexFileClass = env->FindClass("dalvik/system/DexFile"); // "dalvik/system/DexPathList$Element"
    // new DexFile==loadDex
    // loadDex方法比<init>方法通用性更好
    // jmethodID init = env->GetMethodID(DexFileClass, "<init>", "(Ljava/lang/String;Ljava/lang/String;I)V");
    jmethodID init = env->GetStaticMethodID(DexFileClass, "loadDex",
                                            "(Ljava/lang/String;Ljava/lang/String;I)Ldalvik/system/DexFile;");

    if (env->ExceptionCheck())
    {
        LOGE("[-]get loadDex methodID  error");
        return 0;
    }
    jstring apk = env->NewStringUTF(inPath);
    jstring odex = env->NewStringUTF(outPath);

    jobject dexobj = env->CallStaticObjectMethod(DexFileClass, init, apk, odex, 0);
    if (env->ExceptionCheck())
    {
        LOGE("[-]loadDex %s dex failed", inPath);
        return 0;
    }

    env->DeleteLocalRef(DexFileClass);
    env->DeleteLocalRef(apk);
    env->DeleteLocalRef(odex);

    // try delete mixdexobj localRef
    // env->DeleteLocalRef(mixdexobj);
    return dexobj;
}

void *get_lib_handle(const char *lib_path)
{
    void *handle_art = dlopen(lib_path, RTLD_NOW);

    if (!handle_art)
    {
        LOGE("[-]get %s handle failed:%s", lib_path, dlerror());
        return NULL;
    }
    return handle_art;
}

void write_file(const char *path, void *buffer, int size)
{
    FILE *file = fopen(path, "wb");

    if (!file)
    {
        LOGE("[-]fopen %s error:%s", path, strerror(errno));
        return;
    }
    int return_write = fwrite(buffer, 1, size, file);
    if (return_write != size)
    {
        LOGE("[-]fwrite %s error:%s", path, strerror(errno));
        fclose(file);
    }
    else
    {
        LOGE("[+]fwrite decrypt data success");
        fflush(file);
        fclose(file);
    }
}

void *openmemory_load_dex(void *art_handle, char *base, size_t size, int sdk_int)
{
    void *c_dex_cookie;
    switch (sdk_int)
    {
    //android 4.4 art mode
    case 19:
        c_dex_cookie = mem_loadDex_byte19(art_handle, base, g_dex_size);
        break;

    case 21:
        c_dex_cookie = mem_loadDex_byte21(art_handle, base, g_dex_size);
        break;

    case 22:
        c_dex_cookie = mem_loadDex_byte22(art_handle, base, g_dex_size);
        break;

    case 23:
        c_dex_cookie = mem_loadDex_byte23(art_handle, base, g_dex_size);
        break;

    // 7.0 and 7.1
    case 24:
    case 25:
        c_dex_cookie = mem_loadDex_byte24(g_ArtHandle, (char *)g_decrypt_base, (size_t)g_dex_size);
        //c_dex_cookie = NULL;
        break;

    //8.0
    case 26:
    case 27:
        //reserved
        c_dex_cookie = NULL;
        break;

    default:
        c_dex_cookie = NULL;
        break;
    }
    return c_dex_cookie;
}

void replace_cookie(JNIEnv *env, jobject mini_dex_obj, void *c_dex_cookie, int sdk_int)
{
    jfieldID cookie_field;
    jclass DexFileClass = env->FindClass("dalvik/system/DexFile");
    if (sdk_int == 19)
    {
        cookie_field = env->GetFieldID(DexFileClass, "mCookie", "I");
        LOGE("[+]sdk_int:%d,cookie_field:%p", g_sdk_int, cookie_field);
        env->SetIntField(mini_dex_obj, cookie_field, (int)(long)c_dex_cookie);
    }
    else if ((sdk_int == 21) || (sdk_int == 22))
    {
        unique_ptr<vector<const void *>> dex_files(new vector<const void *>());
        cookie_field = env->GetFieldID(DexFileClass, "mCookie", "J");
        //将c_dex_cookie转换为java层的cookie
        //jlong realcookie=get_real_cookie(env,c_dex_cookie);
        dex_files.get()->push_back(c_dex_cookie);
        jlong mCookie = static_cast<jlong>(reinterpret_cast<uintptr_t>(dex_files.release()));
        env->SetLongField(mini_dex_obj, cookie_field, mCookie);
    }
    else if (sdk_int == 23)
    {
        // cookie_field = env->GetFieldID(DexFileClass, "mCookie", "Ljava/lang/Object;");
        // dex_files.get()->push_back(c_dex_cookie);
        // jlong mCookie = static_cast<jlong>(reinterpret_cast<uintptr_t>(dex_files.release()));
        // LOGD("c_dex_cookie:%x,mCookie:%x",c_dex_cookie,mCookie);
        // env->SetObjectField(mini_dex_obj, cookie_field, (jobject)mCookie);
        replace_cookie_M(env, mini_dex_obj, (jlong)c_dex_cookie);
    }
    else if (sdk_int >= 24)
    {
        //cookie_field = env->GetFieldID(DexFileClass, "mCookie", "Ljava/lang/Object;");
        replace_cookie_N(env, mini_dex_obj, (jlong)c_dex_cookie);
    }
}

jobject hook_load_dex_internally(JNIEnv *env, const char *art_path, char *inPath, char *outPath)
{
    void *art_base = get_module_base(getpid(), art_path);
    if (!art_base)
    {
        LOGE("[-]get lib %s base failed", art_path);
        return NULL;
    }

#if 1
    ElfReader elfReader(art_path, art_base);
    if (0 != elfReader.parse())
    {
        LOGE("failed to parse %s in %d maps at %p", LIB_ART_PATH, getpid(), art_base);
        return NULL;
    }
    elfReader.hook("open", (void *)new_open, (void **)&old_open);
    elfReader.hook("read", (void *)new_read, (void **)&old_read);
    elfReader.hook("mmap", (void *)new_mmap, (void **)&old_mmap);
    elfReader.hook("munmap", (void *)new_munmap, (void **)&old_munmap);
    elfReader.hook("__read_chk", (void *)new_read_chk, (void **)&old_read_chk);
    elfReader.hook("fstat", (void *)new_fstat, (void **)&old_fstat);
    elfReader.hook("fork", (void *)new_fork, (void **)&old_fork);
    //LOGD("[+]Load fake dex inPath:%s,outPath:%s", inPath, outPath);
    jobject faked_dex_obj = load_dex_fromfile(env, inPath, outPath);
    //LOGD("[+]Load fake dex finished");
    //恢复fork和fstat的hook
    elfReader.hook("fork", (void *)old_fork, (void **)&old_fork);
    elfReader.hook("fstat", (void *)old_fstat, (void **)&old_fstat);
    return faked_dex_obj;
#endif
}

jobject  apk_getObjectField(JNIEnv *env,jobject classLoader){
    jclass PathClassLoader = env->GetObjectClass(classLoader);
    jclass BaseDexClassLoader = env->GetSuperclass(PathClassLoader);
    // get pathList fieldid
    jfieldID pathListid = env->GetFieldID(BaseDexClassLoader, "pathList", "Ldalvik/system/DexPathList;");
    jobject pathList = env->GetObjectField(classLoader, pathListid);

    return pathList;
}
/*
 * 安卓8.0以及以上classes.dex文件加载
 */
void apk_load_classes_dex_on_android_8(JNIEnv *env,jobject oApplication,const char *buffer_byte,int32_t buffer_size){
    jclass in_mem_class = env->FindClass("dalvik/system/InMemoryDexClassLoader");
    //LOGD("------dalvik/system/InMemoryDexClassLoader-----是否存在---- %s",in_mem_class != nullptr? "---exist--" : " do not");
    if(in_mem_class != nullptr){
        //LOGD("------dalvik/system/InMemoryDexClassLoader-----exist----");
        jbyteArray classes_byte_array = env->NewByteArray(buffer_size);
        env->SetByteArrayRegion(classes_byte_array,0,buffer_size,reinterpret_cast<const jbyte*>(buffer_byte));

        jclass clsContextWrapper = env->FindClass("android/content/ContextWrapper");
        jclass clsByteBuffer = env->FindClass("java/nio/ByteBuffer");
        jobject oDexByteBuffer = env->CallStaticObjectMethod(clsByteBuffer, env->GetStaticMethodID(clsByteBuffer, "wrap", "([B)Ljava/nio/ByteBuffer;"), classes_byte_array);
        jobjectArray baDexBufferArray = env->NewObjectArray(1, clsByteBuffer, oDexByteBuffer);
        //创建对象
        //LOGD("---loadSrcDEX----begin-----33333--------");
        jclass clsReference = env->FindClass("java/lang/ref/Reference");
        jclass clsMap = env->FindClass("java/util/Map");
        jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
        jclass clsLoadedApk = env->FindClass("android/app/LoadedApk");

        jstring stCurrntPkgNa = static_cast<jstring>(env->CallObjectMethod(oApplication,env->GetMethodID(clsContextWrapper,
                                                                                                         "getPackageName","()Ljava/lang/String;")));
        jobject oCurActivityThread = env->CallStaticObjectMethod(clsActivityThread, env->GetStaticMethodID(clsActivityThread, "currentActivityThread", "()Landroid/app/ActivityThread;"));
        jobject oMPkgs = env->GetObjectField(oCurActivityThread, env->GetFieldID(clsActivityThread, "mPackages", "Landroid/util/ArrayMap;"));
        jobject oWRShellLoadedApk = env->CallObjectMethod(oMPkgs, env->GetMethodID(clsMap, "get", "(Ljava/lang/Object;)Ljava/lang/Object;"), stCurrntPkgNa);
        jobject oShellLoadedApk = env->CallObjectMethod(oWRShellLoadedApk, env->GetMethodID(clsReference, "get", "()Ljava/lang/Object;"));
        jobject class_loader = env->GetObjectField(oShellLoadedApk, env->GetFieldID(clsLoadedApk, "mClassLoader", "Ljava/lang/ClassLoader;"));
        if(!class_loader){
            //LOGD("--error---origin--class ---loader is null");
        }
        jobject object_class_loader = object_class_loader = env->NewObject(in_mem_class,env->GetMethodID(in_mem_class,"<init>",
                               "([Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V"),baDexBufferArray,class_loader);

        //replace native directory field
        //获取so库加载路径
        jclass base_dex_class = env->FindClass("dalvik/system/BaseDexClassLoader");
        jobject path_list_object = env->GetObjectField(class_loader,env->GetFieldID(base_dex_class,"pathList","Ldalvik/system/DexPathList;"));
        jobject path_list_object2 = env->GetObjectField(object_class_loader,env->GetFieldID(base_dex_class,"pathList","Ldalvik/system/DexPathList;"));

        jclass path_list_class = env->FindClass("dalvik/system/DexPathList");
        //nativeLibraryDirectories
        jfieldID native_directory_field_id = env->GetFieldID(path_list_class,"nativeLibraryDirectories","Ljava/util/List;");
        env->SetObjectField(path_list_object2,native_directory_field_id,env->GetObjectField(path_list_object2,native_directory_field_id));

        //nativeLibraryPathElements
        jfieldID native_library_field_id = env->GetFieldID(path_list_class,"nativeLibraryPathElements","[Ldalvik/system/DexPathList$NativeLibraryElement;");
        env->SetObjectField(path_list_object2,native_library_field_id,env->GetObjectField(path_list_object,native_library_field_id));

        env->SetObjectField(oShellLoadedApk, env->GetFieldID(clsLoadedApk, "mClassLoader", "Ljava/lang/ClassLoader;"), object_class_loader);

        env->DeleteLocalRef(classes_byte_array);
        env->DeleteLocalRef(oDexByteBuffer);
        env->DeleteLocalRef(baDexBufferArray);
        env->DeleteLocalRef(object_class_loader);
    }
}


void mem_loadDex(JNIEnv *env, jobject ctx, const char *dex_path,const char *buffer_ptr,int buffer_size)
{
    char inPath[256] = {0};
    char outPath[256] = {0};
    jobject mini_dex_obj = nullptr;
    void *c_dex_cookie = nullptr;

    jclass ApplicationClass = env->GetObjectClass(ctx);
    jmethodID getClassLoader = env->GetMethodID(ApplicationClass, "getClassLoader", "()Ljava/lang/ClassLoader;");
    jobject classLoader = env->CallObjectMethod(ctx, getClassLoader);

    char szDexPath[256] = {0};

    sprintf((char *)szDexPath, dex_path, strlen(dex_path));
    LOGD("[+]Dex Path:%s", szDexPath);

    int zero = open("/dev/zero", PROT_WRITE);
    g_decrypt_base = mmap(0, buffer_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, zero, 0);
    close(zero);

    if (g_decrypt_base == MAP_FAILED)
    {
        LOGE("[-]ANONYMOUS mmap failed:%s", strerror(errno));
        exit(-1);
    }

    char decrypt_path[256] = {0};
    sprintf((char *)decrypt_path, "%s/decrypt.dat", g_jiagu_dir);
    g_dex_size = buffer_size;

    memcpy(g_decrypt_base, buffer_ptr, g_dex_size);
    g_page_size = PAGE_END(g_dex_size);

    //LOGD("[+]After decrypt dex magic:0x%x,size:%d,page_size:%d", *(int *)g_decrypt_base, g_dex_size, g_page_size);

    if (!g_isArt)
    {
        sprintf(inPath, "%s/mini.dex", g_jiagu_dir);
        sprintf(outPath, "%s/mini.oat", g_jiagu_dir);
        write_mix_dex(inPath);
        //LOGD("-------------------22222-----------------------");
        jint mCookie = mem_loadDex_dvm(env, (char *)szDexPath);
        //LOGE("[+]Dalvik dex cookie :0x%x", mCookie);
        jclass DexFileClass = env->FindClass("dalvik/system/DexFile");
        mini_dex_obj = load_dex_fromfile(env, inPath, outPath);
        if(!mini_dex_obj)
            LOGE("----%d---mini_dex_obj------is nullptr",g_sdk_int);
        jfieldID cookie_field = env->GetFieldID(DexFileClass, "mCookie", "I");
        //replace cookie
        if(!cookie_field)
            LOGE("--------env->SetIntField---------cookie_field--is nullptr ?--%s----",cookie_field?"false" : "true");
        env->SetIntField(mini_dex_obj, cookie_field, mCookie);
        make_dex_elements(env, classLoader, mini_dex_obj);
        //LOGE("-------------------3333333-----------------------");
        return;
    }
    else
    {
        sprintf(inPath, "%s/mini.dex", g_jiagu_dir);
        sprintf(outPath, "%s/mini.oat", g_jiagu_dir);
        write_mix_dex(inPath);

        g_ArtHandle = get_lib_handle(LIB_ART_PATH);

        //LOGD("-------------------4444-----------------------");
        if (g_ArtHandle)
        {
            c_dex_cookie = openmemory_load_dex(g_ArtHandle, (char *)g_decrypt_base, (size_t)g_dex_size, g_sdk_int);
            //LOGD("[+]sdk_int :%d,c_dex_cookie:%p", g_sdk_int, c_dex_cookie);
            if (c_dex_cookie)
            {
                // 加载mini.dex
                //获取当前类加载器的dex对象
                //mini_dex_obj = apk_getObjectField(env,classLoader);
                mini_dex_obj = load_dex_fromfile(env, inPath, outPath);
                replace_cookie(env, mini_dex_obj, c_dex_cookie, g_sdk_int);
                make_dex_elements(env, classLoader, mini_dex_obj);
                //LOGD("[+]using fast plan load dex finished");
            }
            else
            {
                // 执行方案二
                LOGD("[-]get c_dex_cookie failed! Try second plan");
                goto label;
            }
        }
        else
        {
            LOGD("[-]get art handle failed! Try second plan");
        label:
            // get_path_frommaps(g_pkgName, (char *)g_fake_dex_path, (char *)".dex", (char *)".odex");
            // pkgName
            sprintf((char*)g_fake_dex_magic,"%s/mini.dex",PACKER_MAGIC);
            LOGD("[+]g_faked_dex_magic:%s",(char*)g_fake_dex_magic);
            // 加载fake_dex
            mini_dex_obj = hook_load_dex_internally(env, (const char *)LIB_ART_PATH, (char *)inPath, outPath);
            
            make_dex_elements(env, classLoader, mini_dex_obj);
            LOGD("[+]using second plan load dex finished");
        }

        if (g_ArtHandle)
        {
            dlclose(g_ArtHandle);
        }
        return;
    }

    if(mini_dex_obj != nullptr) {
        env->DeleteLocalRef(mini_dex_obj);
        mini_dex_obj = nullptr;
    }

    if(g_decrypt_base != nullptr){
        munmap(g_decrypt_base,g_dex_size);
        g_decrypt_base = nullptr;
    }
    //LOGE("-------------------777777777-----------------------");
}

void native_attachBaseContext(JNIEnv *env, jobject thiz, jobject ctx,jobject app_object) {
#if defined(__arm__)
    LOGD("[+]Running arm libdexload");
#elif defined(__aarch64__)
    LOGD("[+]Running aarch64 libdexload");

#endif

    jclass ApplicationClass = env->GetObjectClass(ctx);
    jmethodID getFilesDir = env->GetMethodID(ApplicationClass, "getFilesDir", "()Ljava/io/File;");
    jobject File_obj = env->CallObjectMethod(ctx, getFilesDir);
    jclass FileClass = env->GetObjectClass(File_obj);

    jmethodID getAbsolutePath = env->GetMethodID(FileClass, "getAbsolutePath",
                                                 "()Ljava/lang/String;");
    jstring data_file_dir = static_cast<jstring>(env->CallObjectMethod(File_obj, getAbsolutePath));

    g_file_dir = env->GetStringUTFChars(data_file_dir, NULL);
    //g_file_dir_backup=g_file_dir;
    LOGD("[+]FilesDir:%s", g_file_dir);
    env->DeleteLocalRef(data_file_dir);
    env->DeleteLocalRef(File_obj);
    env->DeleteLocalRef(FileClass);

    // NativeLibraryDir
    jmethodID getApplicationInfo = env->GetMethodID(ApplicationClass, "getApplicationInfo",
                                                    "()Landroid/content/pm/ApplicationInfo;");
    jobject ApplicationInfo_obj = env->CallObjectMethod(ctx, getApplicationInfo);
    jclass ApplicationInfoClass = env->GetObjectClass(ApplicationInfo_obj);
    //jfieldID nativeLibraryDir_field = env->GetFieldID(ApplicationInfoClass, "nativeLibraryDir","Ljava/lang/String;");
    //jstring nativeLibraryDir = (jstring) (env->GetObjectField(ApplicationInfo_obj,nativeLibraryDir_field));

    //g_NativeLibDir = env->GetStringUTFChars(nativeLibraryDir, NULL);
    //LOGD("[+]NativeLibDir:%s", g_NativeLibDir);

    //env->DeleteLocalRef(nativeLibraryDir);
    env->DeleteLocalRef(ApplicationInfoClass);
    env->DeleteLocalRef(ApplicationInfo_obj);

    jmethodID getPackageResourcePath = env->GetMethodID(ApplicationClass, "getPackageResourcePath",
                                                        "()Ljava/lang/String;");

    jstring mPackageFilePath = static_cast<jstring>(env->CallObjectMethod(ctx,
                                                                          getPackageResourcePath));
    const char *cmPackageFilePath = env->GetStringUTFChars(mPackageFilePath, NULL);
    g_PackageResourcePath = const_cast<char *>(cmPackageFilePath);
    //LOGD("[+]PackageResourcePath:%s", g_PackageResourcePath);
    env->DeleteLocalRef(mPackageFilePath);

    jmethodID getPackageName = env->GetMethodID(env->GetObjectClass(app_object) , "getPackageName",
                                                "()Ljava/lang/String;");
    //LOGD("-------------init--application--is null?--%s",app_object?"false":"true");
    jstring PackageName = static_cast<jstring>(env->CallObjectMethod(app_object, getPackageName));
    const char *packagename = env->GetStringUTFChars(PackageName, NULL);
    g_pkgName = (char *) packagename;
    LOGD("[+]g_pkgName :%s", g_pkgName);
    env->DeleteLocalRef(PackageName);

    char jiaguPath[256] = {0}; // 加密dex的存储路径

    sprintf(g_jiagu_dir, "%s/%s", g_file_dir, PACKER_MAGIC);
    sprintf(jiaguPath, "%s/%s", g_jiagu_dir, JIAMI_MAGIC);
    LOGD("[+]g_jiagu_dir:%s,jiaguPath:%s", g_jiagu_dir, jiaguPath);
    if (access(g_jiagu_dir, F_OK) != 0) {
        if (mkdir(g_jiagu_dir, 0755) == -1) {
            LOGE("[-]mkdir %s error:%s", g_jiagu_dir, strerror(errno));
        }
    }

    //LOGD("-----------step----000----------------");
    //从assets目录提取加密dex
    char *buffer_ptr = nullptr;
    int32_t buffer_size = 0;
    int32_t ref_s0 = extract_file(env, ctx, g_application_name, &buffer_ptr, &buffer_size);
    //LOGD("-----------step----qqqqqqqqqq----------------");
    //安卓8.0以及以上
    if (g_sdk_int >= 26) {
        apk_load_classes_dex_on_android_8(env,app_object,buffer_ptr,buffer_size);
    }
    else
        mem_loadDex(env, ctx, jiaguPath,buffer_ptr,buffer_size);
    //LOGD("-----------step----over--over----------------");

    delete[] buffer_ptr;
    buffer_size = 0;
    //LOGE("-------------------8888888-----------------------");
} // native_attachBaseContext

void native_onCreate(JNIEnv *env, jobject thiz, jobject instance,jobject app_object)
{
  //  LOGD("[+]native onCreate is called");
    jstring originApplicationName = env->NewStringUTF(g_application_name);
    if (originApplicationName == NULL)
    {
        LOGE("[-]not found original Application Name");
        return;
    }
   // LOGD("[+]original Application Name : %s", env->GetStringUTFChars(originApplicationName, NULL));

    //将LoadedApk中的mApplication对象替换
    jclass ActivityThreadClass = env->FindClass("android/app/ActivityThread");
    jmethodID currentActivityThread = env->GetStaticMethodID(ActivityThreadClass, "currentActivityThread", "()Landroid/app/ActivityThread;");
    jobject activityThread = env->CallStaticObjectMethod(ActivityThreadClass, currentActivityThread);
  //  LOGE("get ActivityThreadClass");
    //得到AppBindData
    jfieldID mBoundApplicationField = env->GetFieldID(ActivityThreadClass, "mBoundApplication", "Landroid/app/ActivityThread$AppBindData;");
    jobject mBoundApplication = env->GetObjectField(activityThread, mBoundApplicationField);
  //  LOGE("get AppBindData");
    //得到LoadedApk
    jfieldID infoField = env->GetFieldID(env->GetObjectClass(mBoundApplication), "info", "Landroid/app/LoadedApk;");
    jobject info = env->GetObjectField(mBoundApplication, infoField);
  //  LOGE("get LoadedApk");
    //把LoadedApk中的成员变量private Application mApplication;置空
    jfieldID mApplicationField = env->GetFieldID(env->GetObjectClass(info), "mApplication", "Landroid/app/Application;");
    env->SetObjectField(info, mApplicationField, NULL);
  //  LOGE("mApplication set null");
    //得到壳Application
    jfieldID mInitialApplicationField = env->GetFieldID(ActivityThreadClass, "mInitialApplication", "Landroid/app/Application;");
    jobject mInitialApplication = env->GetObjectField(activityThread, mInitialApplicationField);
  //  LOGE("get packer Application");

    //将壳Application移除
    jfieldID mAllApplicationsField = env->GetFieldID(ActivityThreadClass, "mAllApplications", "Ljava/util/ArrayList;");
    jobject mAllApplications = env->GetObjectField(activityThread, mAllApplicationsField);
    jmethodID remove = env->GetMethodID(env->GetObjectClass(mAllApplications), "remove", "(Ljava/lang/Object;)Z");
    env->CallBooleanMethod(mAllApplications, remove, mInitialApplication);
   // LOGE("remove packer Application");
    //得到AppBindData中的ApplicationInfo
    jfieldID appInfoField = env->GetFieldID(env->GetObjectClass(mBoundApplication), "appInfo", "Landroid/content/pm/ApplicationInfo;");
    jobject appInfo = env->GetObjectField(mBoundApplication, appInfoField);
   // LOGE("get AppBindData's ApplicationInfo");
    //得到LoadedApk中的ApplicationInfo
    jfieldID mApplicationInfoField = env->GetFieldID(env->GetObjectClass(info), "mApplicationInfo", "Landroid/content/pm/ApplicationInfo;");
    jobject mApplicationInfo = env->GetObjectField(info, mApplicationInfoField);
   // LOGE("get LoadedApk's ApplicationInfo");
    //替换掉ApplicationInfo中的className
    jfieldID classNameField = env->GetFieldID(env->GetObjectClass(appInfo), "className", "Ljava/lang/String;");
    env->SetObjectField(appInfo, classNameField, originApplicationName);
    env->SetObjectField(mApplicationInfo, classNameField, originApplicationName);
   // LOGE("replace ApplicationInfo's className");
    //创建新的Application
    jmethodID makeApplication = env->GetMethodID(env->GetObjectClass(info), "makeApplication", "(ZLandroid/app/Instrumentation;)Landroid/app/Application;");
    //这里调用原始app的attacheBaseContext
    jobject originApp = env->CallObjectMethod(info, makeApplication, false, NULL);
   // LOGE("create new Application");
    //将句柄赋值到mInitialApplicationField
    env->SetObjectField(activityThread, mInitialApplicationField, originApp);
   // LOGE("set object mInitialApplicationField");
    jfieldID mProviderMapField;
    if (g_sdk_int < 19)
    {
        mProviderMapField = env->GetFieldID(ActivityThreadClass, "mProviderMap", "Ljava/util/HashMap;");
    }
    else
    {
        mProviderMapField = env->GetFieldID(ActivityThreadClass, "mProviderMap", "Landroid/util/ArrayMap;");
    }
    if (mProviderMapField == NULL)
    {
        LOGE("not found mProviderMapField");
        return;
    }
    //LOGE("-------------------999999-----------------------");
    //LOGE("found mProviderMapField");
    jobject mProviderMap = env->GetObjectField(activityThread, mProviderMapField);
    //LOGE("found mProviderMap");
    jmethodID values = env->GetMethodID(env->GetObjectClass(mProviderMap), "values", "()Ljava/util/Collection;");
    jobject collections = env->CallObjectMethod(mProviderMap, values);
    jmethodID iterator = env->GetMethodID(env->GetObjectClass(collections), "iterator", "()Ljava/util/Iterator;");
    jobject mIterator = env->CallObjectMethod(collections, iterator);
    jmethodID hasNext = env->GetMethodID(env->GetObjectClass(mIterator), "hasNext", "()Z");
    jmethodID next = env->GetMethodID(env->GetObjectClass(mIterator), "next", "()Ljava/lang/Object;");

    //替换所有ContentProvider中的Context
    //LOGE("ready replace all ContentProvider's context");
    //LOGE("-------------------101010101-----------------------");
    while (env->CallBooleanMethod(mIterator, hasNext))
    {
        jobject providerClientRecord = env->CallObjectMethod(mIterator, next);
        if (providerClientRecord == NULL)
        {
            LOGD("providerClientRecord = NULL");
            continue;
        }
        jclass ProviderClientRecordClass = env->FindClass("android/app/ActivityThread$ProviderClientRecord");
        jfieldID mLocalProviderField = env->GetFieldID(ProviderClientRecordClass, "mLocalProvider", "Landroid/content/ContentProvider;");
        if (mLocalProviderField == NULL)
        {
            LOGD("mLocalProviderField not found");
            continue;
        }
        jobject mLocalProvider = env->GetObjectField(providerClientRecord, mLocalProviderField);
        if (mLocalProvider == NULL)
        {
            LOGD("mLocalProvider is NULL");
            continue;
        }
        jfieldID mContextField = env->GetFieldID(env->GetObjectClass(mLocalProvider), "mContext", "Landroid/content/Context;");
        if (mContextField == NULL)
        {
            LOGD("mContextField not found");
            continue;
        }
        env->SetObjectField(mLocalProvider, mContextField, originApp);
    }
    //LOGE("-------------------1111111-----------------------");

    //执行originApp的onCreate
    jmethodID onCreate = env->GetMethodID(env->GetObjectClass(originApp), "onCreate", "()V");
    env->CallVoidMethod(originApp, onCreate);
    LOGD("Packer is done");
    //LOGE("-------------------12122112121212-----------------------");
}

void init(JNIEnv *env)
{
    jclass jclazz = env->FindClass("android/os/Build$VERSION");
    jfieldID SDK_INT = env->GetStaticFieldID(jclazz, "SDK_INT", "I");

    g_sdk_int = env->GetStaticIntField(jclazz, SDK_INT);
    LOGE("[+]sdk_int:%d", g_sdk_int);
    if (g_sdk_int > 13)
    {
        jclass System = env->FindClass("java/lang/System");
        jmethodID System_getProperty = env->GetStaticMethodID(System, "getProperty", "(Ljava/lang/String;)Ljava/lang/String;");

        jstring vm_version_name = env->NewStringUTF("java.vm.version");
        jstring vm_version_value = (jstring)(env->CallStaticObjectMethod(System, System_getProperty, vm_version_name));

        char *cvm_version_value = (char *)env->GetStringUTFChars(vm_version_value, NULL);
        double version = atof(cvm_version_value);
        g_isArt = version >= 2 ? true : false;
        LOGE("[+]Android VmVersion:%f", version);

        env->ReleaseStringUTFChars(vm_version_value, cvm_version_value);
        env->DeleteLocalRef(System);
        env->DeleteLocalRef(vm_version_name);
        env->DeleteLocalRef(vm_version_value);
    }
    else
    {
        LOGE("[-]unsupported Android version");
        assert(false);
    }
    env->DeleteLocalRef(jclazz);

    //动态注册jni函数
    jclass system_class = env->FindClass("java/lang/System");
    //method getProperty
    jmethodID getProperty_id = env->GetStaticMethodID(system_class,"getProperty", "(Ljava/lang/String;)Ljava/lang/String;");
    jstring s2_67 = env->NewStringUTF("s2-67");
    jstring value_str = (jstring)env->CallStaticObjectMethod(system_class,getProperty_id,s2_67);
    const char *c_value_str = env->GetStringUTFChars(value_str,nullptr);

    uint32_t seed = atol(c_value_str);
    LOGD("----native--tool--seed----%u",seed);
    apk_rand_seed(seed);

    //接下来生成需要用到的新版 meta data键值名称,以及Application的全名,NativeTool 类的新版全名,seed string 字符串
    int32_t  pack_size = 15 + apk_random()%8;
    int32_t  base_size = 6 + apk_random()%6;

    char pack_buffer[64];
    //生成包名
    apk_create_pack_name(pack_buffer, pack_size);

    //NativeTool 类名字
    char native_tool_buffer[32];
    apk_create_class_name(native_tool_buffer, 6 + apk_random() % 6);
    //函数名字
    char onCreate_buffer[64],attachBaseContext_buffer[64],unseal_buffer[64];
    apk_create_class_name(onCreate_buffer, 7 + apk_random() % 7);
    apk_create_class_name(attachBaseContext_buffer, 13 + apk_random() % 7);
    apk_create_class_name(unseal_buffer, 7 + apk_random() % 7);

    char buffer[512];

#if 0
    const char *attach_method_ptr = "attachBaseContext";//attachBaseContext_buffer
    const char *onCreate_ptr = "onCreate";//onCreate_buffer
    const char *unseal_ptr = "unseal";//unseal_buffer
    sprintf(buffer,"com/security/cvsample/NativeTool");
#else
    const char *attach_method_ptr = attachBaseContext_buffer;
    const char *onCreate_ptr = onCreate_buffer;
    const char *unseal_ptr = unseal_buffer;

    sprintf(buffer,"%s/%s",pack_buffer,native_tool_buffer);
    apk_replace_char_with(buffer,  '.',  '/');
#endif

    const JNINativeMethod methods[] = {
            {attach_method_ptr, "(Landroid/content/Context;Landroid/app/Application;)V", (void *)native_attachBaseContext},
            {onCreate_ptr, "(Landroid/content/Context;Landroid/app/Application;)V", (void *)native_onCreate},
            {unseal_ptr, "(Landroid/content/Context;Ljava/lang/Class;)I", (void *)native_unseal}};

    jniRegisterNativeMethods(env, buffer,methods, sizeof(methods) / sizeof(methods[0]));

    env->ReleaseStringUTFChars(value_str, c_value_str);
    env->DeleteLocalRef(value_str);
    env->DeleteLocalRef(s2_67);
    env->DeleteLocalRef(system_class);
}

jint JNICALL native_unseal(JNIEnv *env, jclass clazz, jobject ctx,jclass class_2) {
    //安卓 8 以及以上需要调用下列函数
    if(g_sdk_int < 28)
        return 26;
    //LOGD("--------------call-----native_unseal-----");
    int ret_result = 0;//unseal(env,g_sdk_int);

    jclass class_0 = env->FindClass("java/lang/Class");
    jmethodID forName_id_0 = env->GetStaticMethodID(class_0,"forName", "(Ljava/lang/String;)Ljava/lang/Class;");
    //LOGD("-------forName_id_0---exist?- ---%s",forName_id_0? "yes" : "no");

    //查找类java/lang/Class
    jobject class_1 = class_2;//(jclass)env->CallStaticObjectMethod(class_0,forName_id_0,env->NewStringUTF("java.lang.Class"));
    //LOGD("---------native_unseal-------00000---------");
    jclass obj_class = env->GetObjectClass(class_0);
    jmethodID forName_id_1 = env->GetStaticMethodID(obj_class,"forName","(Ljava/lang/String;)Ljava/lang/Class;");

    jclass method_class = env->FindClass("java/lang/reflect/Method");
    //invoke 函数
    jmethodID invoke_id = env->GetMethodID(method_class,"invoke", "(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");

    jstring vm_class_name = env->NewStringUTF("dalvik.system.VMRuntime");
    //LOGD("---------native_unseal-------11111111---------");
    jclass class_1_class = env->GetObjectClass(class_1);
    jclass vm_class = (jclass)env->CallStaticObjectMethod(class_1_class,forName_id_1,vm_class_name);
    //LOGD("-------dalvik.system.VMRuntime---exist?- ---%s",vm_class? "yes" : "no");

    if(vm_class != nullptr){
        //获取getDeclaredMethod
        jmethodID getDeclaredMethod_id = env->GetMethodID(class_1_class,"getDeclaredMethod","(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
        //LOGD("-------getDeclaredMethod_id-00--exist?- ---%s",getDeclaredMethod_id? "yes" : "no");

        jclass string_class_0 = env->FindClass("java/lang/String");
        jobjectArray class_array_0 = env->NewObjectArray(2,class_0,nullptr);
        env->SetObjectArrayElement(class_array_0,0,string_class_0);
        env->SetObjectArrayElement(class_array_0,1,env->FindClass("[Ljava/lang/Class;"));

        jstring declare_name = env->NewStringUTF("getDeclaredMethod");
        jmethodID getDeclaredMethod_id_2 = (jmethodID)env->CallObjectMethod(class_1,getDeclaredMethod_id,declare_name,class_array_0);
        //LOGD("-------getDeclaredMethod_id_2---exist?- ---%s",getDeclaredMethod_id_2? "yes" : "no");

        jclass object_class = env->FindClass("java/lang/Object");
        //获取运行时函数
        jstring runtime_id_name = env->NewStringUTF("getRuntime");
        //jobjectArray void_class_array = env->NewObjectArray(0,class_0,string_class_0);

        //jmethodID getRuntime_id = (jmethodID)env->CallObjectMethod(vm_class,getDeclaredMethod_id_2,runtime_id_name,void_class_array);
        jobjectArray obj_array_2 = env->NewObjectArray(2,object_class,runtime_id_name);
        env->SetObjectArrayElement(obj_array_2,1,nullptr);
        jmethodID getRuntime_id = (jmethodID)env->CallObjectMethod((jobject)getDeclaredMethod_id_2,invoke_id,vm_class,obj_array_2);
        //jmethodID getRuntime_id = (jmethodID)env->CallObjectMethod;
        //LOGD("-------getRuntime_id---exist?- ---%s",getRuntime_id? "yes" : "no");

        jstring setHidden_name = env->NewStringUTF("setHiddenApiExemptions");

        jclass string_array_class2 = env->FindClass("[Ljava/lang/String;");
        jobjectArray class_array2 = env->NewObjectArray(0,class_0,string_array_class2);

        //jmethodID setHidden_id = (jmethodID)env->CallObjectMethod(vm_class,getDeclaredMethod_id_2,setHidden_name,class_array2);
        jobjectArray  obj_array3 = env->NewObjectArray(2,object_class,setHidden_name);
        env->SetObjectArrayElement(obj_array3,1,env->NewObjectArray(1,class_0,string_array_class2));
        jmethodID setHidden_id = (jmethodID)env->CallObjectMethod((jobject)getDeclaredMethod_id_2,invoke_id,vm_class,obj_array3);

        //LOGD("-------setHidden_id---exist?- ---%s",setHidden_id? "yes" : "no");

        jobject runtime_obj = env->CallObjectMethod((jobject)getRuntime_id,invoke_id, (jobject)nullptr,(jobject)nullptr);//env->CallStaticObjectMethod(vm_class,getRuntime_id);
        //LOGD("-------runtime_obj---exist?- ---%s",runtime_obj? "yes" : "no");

        //env->CallVoidMethod(runtime_obj,setHidden_id,jstring_array);

        //LOGD("---------native_unseal-------2222222---------");
        if(setHidden_id != nullptr) {
            jclass method_class = env->GetObjectClass((jobject) setHidden_id);
            //LOGD("---------native_unseal-------33333333---------");
            jmethodID setAccessible_id = env->GetMethodID(method_class, "setAccessible", "(Z)V");
            //LOGD("-------setAccessible_id---exist?- ---%s",runtime_obj? "yes" : "no");

            env->CallVoidMethod((jobject) setHidden_id, setAccessible_id,
                                JNI_TRUE);//env->GetStaticObjectField(boolean_class,true_field_id));
            //LOGD("------setAccessible-----");

            //JNI_TRUE;
            const char *signature = "L";
            jstring java_signature = env->NewStringUTF(signature);
            jobjectArray jstring_array = env->NewObjectArray(1, string_class_0, java_signature);
            jobjectArray obj4_array = env->NewObjectArray(1, object_class, jstring_array);

            env->CallObjectMethod((jobject) setHidden_id, invoke_id, runtime_obj, obj4_array);

            env->DeleteLocalRef(method_class);
            env->DeleteLocalRef(java_signature);
            env->DeleteLocalRef(jstring_array);
            env->DeleteLocalRef(obj4_array);
        }
        //LOGD("----setHidden_id --finish---");

        //env->DeleteLocalRef((jobject)getDeclaredMethod_id);
        env->DeleteLocalRef(string_class_0);
        env->DeleteLocalRef(class_array_0);
        env->DeleteLocalRef(declare_name);
        //env->DeleteLocalRef((jobject)getDeclaredMethod_id_2);
        env->DeleteLocalRef(object_class);
        env->DeleteLocalRef(runtime_id_name);
        env->DeleteLocalRef(obj_array_2);
        //env->DeleteLocalRef((jobject)getRuntime_id);
        env->DeleteLocalRef(setHidden_name);
        env->DeleteLocalRef(string_array_class2);
        env->DeleteLocalRef(class_array2);
        env->DeleteLocalRef(obj_array3);
        //env->DeleteLocalRef((jobject)setHidden_id);
        env->DeleteLocalRef(runtime_obj);
        //env->DeleteLocalRef((jobject)setAccessible_id);
    }

    env->DeleteLocalRef(method_class);
    env->DeleteLocalRef(vm_class);
    env->DeleteLocalRef(class_1_class);
    env->DeleteLocalRef(vm_class_name);
    //env->DeleteLocalRef((jobject)invoke_id);
    env->DeleteLocalRef(obj_class);
    //env->DeleteLocalRef((jobject)forName_id_1);
    //env->DeleteLocalRef((jobject)forName_id_0);
    env->DeleteLocalRef(class_0);

    return ret_result;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved){
    JNIEnv *env = NULL;

    //LOGD("------------load--begin-----------");
    //LOGE("-----------init__JNI_OnLoad-------------------");

    if (vm->GetEnv((void **)&env, JNI_VERSION_1_6) != JNI_OK)
    {
        return -1;
    }
    //LOGE("-----------init__JNI_OnLoad----------00000000---------");

    init(env);
    //LOGE("-----------init__JNI_OnLoad----------1111111---------");
    return JNI_VERSION_1_6;
}
