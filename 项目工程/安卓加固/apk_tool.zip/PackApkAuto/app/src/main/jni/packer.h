#ifndef PACKER_H
#define PACKER_H


typedef unsigned char u1;
typedef unsigned short u2;
typedef unsigned int u4;


extern void* g_decrypt_base;
extern int g_dex_size;
extern int g_page_size;
extern char g_fake_dex_magic[256];
extern const char* g_file_dir;
extern int g_sdk_int;
#endif
