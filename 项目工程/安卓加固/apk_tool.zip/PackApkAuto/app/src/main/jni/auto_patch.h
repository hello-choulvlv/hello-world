/*
* 工具生成文件,请不要自行编辑
* *2021/11/19
* *author:xiaoxiong
*/
#ifndef __auto_patch_h__
#define __auto_patch_h__

#define Native_Tool_Name "guZdiZF/kP_sgI1/ErCzgkh/JMuYZ5L"

#define seed_string_random   "LSDg$qgnyc0JlYor"

#define cx_meta_data_name  "ab4sg-327CdN"

#define __onCreate_micro  "XKQ5ATN5I3"

#define __attachBaseContext_micro  "QOVgPkCSLpldAd5Qw_h"

#define __unseal_micro  "PJ_hWRNcNWwgS"


#endif
