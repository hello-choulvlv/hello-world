/*
* 工具生成文件,请不要自行编辑
* *2021/11/19
* *author:xiaoxiong
*/
#ifndef __auto_patch_h__
#define __auto_patch_h__

#define Native_Tool_Name "xFgDNmX/vtdqSvU/XSigRXI/FM8LkHF"

#define seed_string_random   "M0_5etM_I79$gz"

#define cx_meta_data_name  "ZgOlLc$2mt_qx"

#define __onCreate_micro  "mKoOepXauSWX"

#define __attachBaseContext_micro  "JDHu12XmNCN2_mK"

#define __unseal_micro  "NP1uZSkGI9k4"


#endif
