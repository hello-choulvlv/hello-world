/*
 * 2021/11/22
 * xiaoxiong
 */

#ifndef __fake_dlfcn_h__
#define __fake_dlfcn_h__

#ifdef __cplusplus
extern "C" {
#endif

void *fake_dlopen(const char *filename, int flags);

int fake_dlclose(void *handle);

void *fake_dlsym(void *handle, const char *symbol);

#ifdef __cplusplus
};
#endif

#endif