package com.security.cvsample;


import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.util.Log;

import java.lang.reflect.Method;

public class ProxyApplication extends Application{

	static {
		System.setProperty("v-metal","0");
		System.setProperty("s2-67","0");
		System.loadLibrary("oceancs");
	}

	// 这是context赋值
	@SuppressLint("LongLogTag")
	@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(base);
		int ret = NativeTool.unseal(base,Class.class);//Reflection.unseal(base);
		//Log.e("---reflection--result-->",Integer.toString(ret));
		NativeTool.attachBaseContext(this.getBaseContext(),this);
	}

	@SuppressLint("LongLogTag")
	@Override
	public void onCreate() {
		NativeTool.onCreate(this.getBaseContext(),this);
	}
}
