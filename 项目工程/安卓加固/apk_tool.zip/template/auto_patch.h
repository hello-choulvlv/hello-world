/*
 * 工具生成文件,请不要自行编辑
 * *2021/11/19
 * *author:xiaoxiong
 */
#ifndef __auto_patch_h__
#define __auto_patch_h__

//#define application_meta_name   ""

#define Native_Tool_Name  "com/security/cvsample/NativeTool"

#define seed_string_random "qcxse.kcsp.wet.-$pghk;!@#"

//metal data name
#define cx_meta_data_name "kaka-ww-xx-p2sc"

#endif