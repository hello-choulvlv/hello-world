#! /bin/bash
current_dir=$(cd `dirname $0`; pwd)
echo $current_dir
cd $current_dir

#需要一次传入的参数1个,那就是待加固的安卓安装包apk完整路径,最后将会被生成到 apk_folder文件夹下

#文件合并后,将会被分割的数目,建议该值大于等于4,分割的数目越大,破解的难度越大,但在第一次运行时,所需要消耗的解码时间就越长
split_number="4"

#签名时需要用到的keystore存放路径
keystore_path="/Users/yitongli/workspace/proj_usa2/shunwo_zq_sw16.keystore"

#keystore 密码
keystore_password="shunwo123456"

#alias名字
alias_name="swzq"

#alias密码
alias_password="shunwo123456"

#目标输出路径
output_path="apk_destination"


./apk_parser "$1" "$split_number" "$keystore_path" "$alias_name" "$keystore_password" "$alias_password" "$output_path"