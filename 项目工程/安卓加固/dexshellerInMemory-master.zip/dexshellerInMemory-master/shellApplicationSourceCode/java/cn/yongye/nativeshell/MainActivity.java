package cn.yongye.nativeshell;

import android.app.Activity;
import android.os.Bundle;

import java.nio.ByteBuffer;

public class MainActivity extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


}
