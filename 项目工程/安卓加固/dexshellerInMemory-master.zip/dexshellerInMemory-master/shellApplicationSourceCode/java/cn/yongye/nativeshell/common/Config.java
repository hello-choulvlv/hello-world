package cn.yongye.nativeshell.common;

public class Config {
    public static final String MAIN_APPLICATION = "android.app.Application";
}