//
//  main.cpp
//  fnt_parser
//
//  Created by yitong li on 14/10/2021.
//
#include <iostream>
#include <fstream>
#include <string>
#include <list>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include "CCImage.h"
#include "fnt/CCFontFNT.h"
#include "sprite/CCSpriteFrameCache.h"

#define fx_min(x,y) (x) < (y) ? (x) : (y)

void  fnt_parser(const std::string &fnt_name);
bool  spine_atlas_parse(const std::string &atlas_name,const std::string &out_directory,std::string &record);
bool  string_begin_with(const char *a0,const char *b0);
bool  string_end_with(const char *a0,const char *b0);
void  spine_search_atlas_file(const std::string &directory,std::list<std::string> &atlas_list);
void  spine_process_atlas_file(std::string &atlas_directory,const std::string &out_directory,std::string &record);
int32_t string_sub_string_last_with(const char *buffer,char c,std::string &str);
bool  plist_texture_atlas_rotate_justify(Image *image,SpriteFrameCache *cache_map,const std::string &new_name,std::set<std::string> need_parse_sprite_set);
bool chapter_file_parser(const std::string &chapter_name,const std::string &prefix_content,SpriteFrameCache *cache_map,const std::string &output_directory,std::set<std::string> &need_parse_sprite_name);
bool plist_process_sumplement_key_info(const std::string &plist_name,const std::string &sub_plist_directory,const std::string &new_plist_name);
bool plist_split_frame(const std::string &plist_name,const std::string &output_directory);

int32_t  apk_execute_shell_cmd(const char *buffer){
    FILE *fp = popen(buffer, "r");
    if(!fp)
        return 0;
    //产生输出
    char buffer_4p[1024+4];
    int32_t    byte_read = 0;
    while((byte_read = (int32_t)fread(buffer_4p, 1, sizeof(buffer_4p), fp)) != 0){
        buffer_4p[byte_read] = 0;;
        printf("%s",buffer_4p);
    }
    
    pclose(fp);
    return 1;
}

int main(int argc, const char * argv[]) {
    //解析命令行,fnt文件,以及对Fnt文件的内容进行分析
    if(argc < 3){
        printf("error: 命令行参数少于 3\n");
        printf("Usage : %s [-sp,-fnt, -atlas,-plist] [file name] \n",argv[0]);
        return 1;
    }
    char buffer[1024];
    if(!strcmp(argv[1],"-fnt")){
        std::string fnt_name = argv[2];
        //检测文件是否存在
        if(access(argv[2], R_OK) != 0){
            printf("目标文件不存在,请重新输入.....\n");
            return 2;
        }
        //如果不是以.fnt扩展名结尾,报错
       // int32_t ss = fnt_name.find_last_of(".fnt");
        if(fnt_name.find_last_of(".fnt") != fnt_name.size() - 1){
            printf("当前只支持fnt文件解析....\n");
            return 3;
        }
        fnt_parser(fnt_name);
    }
    else if(!strcmp(argv[1],"-sp")){
        std::string atlas_name = argv[2];
        //检测文件是否存在
        if(access(argv[2], R_OK) != 0){
            printf("目标文件不存在,请重新输入.....\n");
            return 2;
        }
        
        DIR *dir_ptr = nullptr;
        if(atlas_name.find_last_of(".atlas") != atlas_name.size() - 1 && !(dir_ptr = opendir(atlas_name.c_str()))){
            printf("当前只支持atlas文件或者atlas文件夹解析....\n");
            return 3;
        }
        //目标目录
        std::string output_directory = argc <= 3 ? "." : argv[3];
        //测试目标目录是否存在
        if(argc > 3){
            DIR *out_ptr = opendir(output_directory.c_str());
            if(out_ptr != nullptr){
                closedir(out_ptr);
                printf("--中间目录‘%s’已经存在,正在删除中.....\n",output_directory.c_str());
                sprintf(buffer,"rm -rf %s",output_directory.c_str());
                if(!apk_execute_shell_cmd(buffer)){
                    printf("删除已经存在的目录'%s'失败...",output_directory.c_str());
                    return 5;
                }
            }//否则,创建目录
            if(mkdir(output_directory.c_str(), 0775) != 0){
                printf("--创建文件夹‘%s’失败----\n",output_directory.c_str());
                return 4;
            }
        }
        if(output_directory.back() != '/')output_directory.append("/");
        
        //在当前目录下生成一个chapter文件
        size_t s2_pos = atlas_name.rfind('.');
        std::string chapter_file_name = s2_pos == std::string::npos ?atlas_name : atlas_name.substr(0,s2_pos);
        sprintf(buffer,"%s_chapter.txt",chapter_file_name.c_str());
        //如果是目录
        std::string record;
        if(dir_ptr != nullptr){
            closedir(dir_ptr);
            spine_process_atlas_file(atlas_name,output_directory,record);
        }
        else{
            spine_atlas_parse(atlas_name,output_directory,record);
        }
        std::ofstream output_stream;
        output_stream.open(buffer,std::ios::trunc);
        if(!output_stream.is_open()){
            output_stream.close();
            printf("创建chapter文件'%s'失败....\n",buffer);
            return 6;
        }
        output_stream.write(record.c_str(), record.size());
        output_stream.close();
    }
    else if(!strcmp(argv[1],"-atlas")){
        if(argc < 5){
            printf("usage: %s -atlas chapter_file plist_file  output_directory....\n",argv[0]);
            return 7;
        }
        //需要同时处理plist/chapter/texture文件
        std::string chapter_name = argv[2];
        std::string plist_name = argv[3];
        std::string output_directory = argv[4];
        
        if(access(chapter_name.c_str(), R_OK) != 0){
            printf("chapter文件'%s'不存在,请重新检查.....\n",chapter_name.c_str());
            return 8;
        }
        
        if(access(plist_name.c_str(), R_OK) != 0){
            printf("plist文件'%s'不存在,请重新输入.....\n",plist_name.c_str());
            return 9;
        }
        
        //检查文件扩展名
        if(plist_name.find_last_of(".plist") != plist_name.size() - 1 ){
            printf("输入的plist文件名并非标准扩展名称,请重新输入....\n");
            return 10;
        }
        
        DIR *out_ptr = opendir(output_directory.c_str());
        if(out_ptr != nullptr){
            closedir(out_ptr);
            printf("--中间目录‘%s’已经存在,正在删除中.....\n",output_directory.c_str());
            sprintf(buffer,"rm -rf %s",output_directory.c_str());
            if(!apk_execute_shell_cmd(buffer)){
                printf("删除已经存在的目录'%s'失败...",output_directory.c_str());
                return 5;
            }
        }//否则,创建目录
        if(mkdir(output_directory.c_str(), 0775) != 0){
            printf("--创建文件夹‘%s’失败----\n",output_directory.c_str());
            return 4;
        }

        if(output_directory.back() != '/')output_directory.append("/");
        
        SpriteFrameCache  *cache_map = SpriteFrameCache::create();
        cache_map->addSpriteFramesWithFile(plist_name);
        const std::string &texture_name = cache_map->getTextureName();
        
        //计算新生成的文件名
        size_t  r0_pos = texture_name.rfind('.');
        std::string new_texture_name = texture_name.substr(0,r0_pos == std::string::npos ? texture_name.size() : r0_pos) + "_atlas.png";
        //首先处理plist文件集
        Size2  extent;
        Image  *image = new Image();
        image->initWithImageFile(texture_name);
        if(!image->getData()){
            delete image;
            printf("输入的纹理文件名'%s'不存在,请再次检查.....\n",texture_name.c_str());
            return 12;
        }
        //再次生成atlas文件集
        size_t s_pos = new_texture_name.rfind('/');
        std::string simple_name = s_pos == std::string::npos ? new_texture_name : new_texture_name.substr(s_pos + 1);
        sprintf(buffer,"\n%s\nsize: %d, %d",simple_name.c_str(),image->getWidth(),image->getHeight());
        
        std::set<std::string> need_parse_sprite_set;
        chapter_file_parser(chapter_name,buffer,cache_map,output_directory,need_parse_sprite_set);
        
        plist_texture_atlas_rotate_justify(image,cache_map,new_texture_name,need_parse_sprite_set);
        
        delete image;
        printf("--处理atlas文件集合完毕。。。。\n");
    }else if(!strcmp(argv[1],"-plist")){
        std::string plist_name = argv[2];
        std::string plist_directory = argv[3];
        
        if(access(plist_name.c_str(), R_OK) != 0){
            printf("plist文件'%s'不存在,请重新检查.....\n",plist_name.c_str());
            return 17;
        }
        
        if(access(plist_name.c_str(), R_OK) != 0){
            printf("plist文件'%s'不存在,请重新输入.....\n",plist_name.c_str());
            return 18;
        }
        
        DIR *src_ptr = opendir(plist_directory.c_str());
        if(!src_ptr){
            printf("输入文件夹不存在，请重新输入....\n");
            return 19;
        }
        closedir(src_ptr);
        //检测是否有目标文件
        std::string output_plist = argc < 5? plist_name : argv[4];
        if(plist_process_sumplement_key_info(plist_name,plist_directory,output_plist)){
            printf("处理plist文件完毕......\n");
        }
    }
    else if(!strcmp(argv[1],"-split_plist")){
        if(argc < 4){
            printf("usgae: %s -split_plist plist文件命名 输出文件夹名\n",argv[0]);
            return 25;
        }
        std::string plist_name = argv[2];
        std::string output_directory = argv[3];
        
        if(access(plist_name.c_str(), R_OK) != 0){
            printf("plist文件'%s'不存在,请重新检查.....\n",plist_name.c_str());
            return 20;
        }
        
        if(plist_name.find_last_of(".plist") != plist_name.size() - 1 ){
            printf("输入的plist文件名并非标准扩展名称,请重新输入....\n");
            return 10;
        }
        
        DIR *src_ptr = opendir(output_directory.c_str());
        if(src_ptr != nullptr){
            closedir(src_ptr);
            printf("--中间目录‘%s’已经存在,正在删除中.....\n",output_directory.c_str());
            sprintf(buffer,"rm -rf %s",output_directory.c_str());
            if(!apk_execute_shell_cmd(buffer)){
                printf("删除已经存在的目录'%s'失败...",output_directory.c_str());
                return 22;
            }
        }//否则,创建目录
        if(mkdir(output_directory.c_str(), 0775) != 0){
            printf("--创建文件夹‘%s’失败----\n",output_directory.c_str());
            return 23;
        }
        if(plist_split_frame(plist_name,output_directory)){
            printf("---分割plist文件 frame帧完成.....\n");
        }
    }
    return 0;
}

void  fnt_parser(const std::string &fnt_name){
    BMFontConfiguration *fnt_config =  BMFontConfiguration::create(fnt_name);
    const std::string &atlas_png = fnt_config->getAtlasName();
    const std::string sub_png_prefix = atlas_png.substr(0,atlas_png.find_last_of('.'));
    
    Image  *image = new Image();
    image->initWithImageFile(atlas_png);
    
    //目前暂时认为png图片的深度为32位,后面讲进一步对其进行分析
    //size_t numGlyphs = fnt_config->_characterSet->size();
    uint8_t *image_data = image->getData();
    int32_t image_width = image->getWidth();
    //int32_t image_height = image->getHeight();
    const int32_t step_cx = 4;
    char buffer[512];
    
    int32_t  c_seq = 0;
    for (auto&& e : fnt_config->_fontDefDictionary)
    {
        BMFontDef &fontDef = e.second;
        int32_t  offset_x = fontDef.rect.origin.x + fontDef.xOffset;
        int32_t  offset_y = fontDef.rect.origin.y + fontDef.yOffset;
        int32_t  width = fontDef.rect.size.width - fontDef.xOffset;//fx_min(fontDef.rect.size.width - fontDef.xOffset,fontDef.xAdvance);
        int32_t  height = fontDef.rect.size.height - fontDef.yOffset;
        //将上述图片从以上数据指示的dimension导出
        uint8_t  *sub_data = new uint8_t[width * height * step_cx];
        //copy
        for(int32_t  row_c = 0;row_c < height; ++row_c){
            int32_t begin_cx = row_c * width * step_cx;
            memcpy(sub_data + begin_cx,image_data + (offset_y + row_c) * image_width * step_cx + offset_x * step_cx,width * step_cx);
            //save to file
        }
        int32_t  char_seq = fontDef.charID < 10 + 48 ? fontDef.charID - 48 : c_seq + 58;
        sprintf(buffer,"%s_%d.png",sub_png_prefix.c_str(),char_seq);
        Image  *atlas_image = new Image();
        atlas_image->initWithRawData(sub_data, width * height * step_cx, width, height, step_cx);
        atlas_image->saveToFile(buffer,false);
        
        delete atlas_image;
        
        ++c_seq;
        delete[] sub_data;
    }
    
    delete image;
    printf("parse file '%s' success .\n",fnt_name.c_str());
}

void  spine_process_atlas_file(std::string &atlas_directory,const std::string &out_directory,std::string &record){
    std::list<std::string> atlas_list;
    spine_search_atlas_file(atlas_directory,atlas_list);
    //逐个的调用
    for(auto it = atlas_list.begin();it != atlas_list.end();++it){
        spine_atlas_parse(*it,out_directory,record);
    }
}
//遍历文件夹,查找所有符合条件的atlas文件
void  spine_search_atlas_file(const std::string &directory,std::list<std::string> &atlas_list){
        DIR  *dir_ptr = opendir(directory.c_str());
        struct dirent  *rent_item;
    
        while((rent_item = readdir(dir_ptr)) != nullptr){
            if(strcmp(rent_item->d_name,".") && strcmp(rent_item->d_name,"..") && !string_begin_with(rent_item->d_name,".")){
                char  buffer[512];
                //如果不是目录
                if(rent_item->d_type == DT_REG && string_end_with(rent_item->d_name,".atlas")){
                    sprintf(buffer,"%s/%s",directory.c_str(),rent_item->d_name);
                    atlas_list.push_back(buffer);
                }
            }
        }
        
        closedir(dir_ptr);
}
//从现有的字符串开始处,读取一行字符串
int32_t  string_read_line(const char *buffer,char *line_buffer){
    int32_t c_count = 0,u0 = 0;
    while(buffer[c_count] && buffer[c_count] != '\n' && buffer[c_count] != '\r'){
        line_buffer[u0] = buffer[c_count];
        ++c_count;
        ++u0;
    }
    line_buffer[u0] = 0;
    return buffer[c_count] ? c_count + 1: c_count;
}
//字符串裁剪,中间的空白符号也会被裁剪掉
int32_t string_trim(char  *str_buffer){
    int32_t  u0 = -1, u2 = 0;
    while(str_buffer[u2]){
        if(str_buffer[u2] != ' ' && str_buffer[u2] != '\n' && str_buffer[u2] != '\t' && str_buffer[u2] != '\r'){
            if(u2 != u0 + 1){
                str_buffer[u0 + 1] = str_buffer[u2];
            }
            ++u0;
        }
        ++u2;
    }
    str_buffer[u0 + 1] = 0;
    
    return u0 + 1;
}

int32_t string_sub_string_last_with(const char *buffer,char c,std::string &str){
    int32_t u0 = 0;
    int32_t u2 = -1;
    while(buffer[u0]) {
        if(buffer[u0] == c)u2 = u0;
        ++u0;
    }
    
    assert(u2 > 0);
    str.assign(buffer,u2);
    
    return 0;
}

bool  string_begin_with(const char *a0,const char *b0){
    while(*a0 && *b0 && *a0 == *b0){
        ++a0;
        ++b0;
    }
    return !*b0;
}

bool string_end_with(const char *a0,const char *b0){
    int32_t u0 = 0,s0 = 0;
    while(a0[u0]) ++ u0;
    while(b0[s0]) ++ s0;
    
    while(s0 >=0 && s0 >=0 && a0[u0] == b0[s0]){
        --u0;
        --s0;
    }
    return s0 == -1;
}
//从字符串中提取出两个数字
bool string_extract_2_number(const char *buffer,int32_t &a,int32_t &b){
    //先跳过第一个分词
    int32_t  s0 = 0;
    while(buffer[s0] && buffer[s0] != ':')
        ++s0;
    assert(buffer[s0] == ':');
    
    ++s0;
    int32_t p0 = 1;
    if(buffer[s0] == '-'){
        p0 = -1;
        ++s0;
    }
    a = 0;
    while(buffer[s0] && buffer[s0] != ','){
        a *= 10;
        a += buffer[s0] - '0';
        ++s0;
    }
    a *= p0;
    //第二个
    assert(buffer[s0] == ',');
    ++s0;
    p0 = 1;
    if(buffer[s0] == '-'){
        p0 = -1;
        ++s0;
    }
    b = 0;
    while(buffer[s0]){
        b *= 10;
        b += buffer[s0] - '0';
        ++s0;
    }
    b *= p0;
    
    return true;
}

bool string_extract_1_number(const char *buffer,int32_t &a){
    //先跳过第一个分词
    int32_t  s0 = 0;
    while(buffer[s0] && buffer[s0] != ':')
        ++s0;
    assert(buffer[s0] == ':');
    
    ++s0;
    int32_t p0 = 1;
    if(buffer[s0] == '-'){
        p0 = -1;
        ++s0;
    }
    a = 0;
    while(buffer[s0] && buffer[s0] != ','){
        a *= 10;
        a += buffer[s0] - '0';
        ++s0;
    }
    a *= p0;
    return true;
}

int32_t string_extract_2_string(const char *buffer,char *buffer_1,char *buffer_2){
    int32_t  u0 = 0,t0 = 0;
    bool   b0 = true;
    while(buffer[u0]){
        if(buffer[u0] != ':'){
            if(b0)
                buffer_1[u0] = buffer[u0];
            else
                buffer_2[t0++] = buffer[u0];
        }else{
            b0 = false;
            buffer_1[u0] = 0;
        }
        ++u0;
    }
    buffer_2[t0] = 0;
    return u0 - t0;
}

//分析atlas文件工具,将生成的中间文件写入到out_directory目录中,并将产生的信息数据追加到record对象中
bool  spine_atlas_parse(const std::string &atlas_name,const std::string &out_directory,std::string &record){
    //读取文件内容
    std::ifstream  io_input;
    io_input.open(atlas_name);
    if(!io_input.is_open()){
        printf("file %s is not exist.\n",atlas_name.c_str());
        io_input.close();
        return false;
    }
    //获取文件长度
    io_input.seekg(0, std::ios::end);
    uint32_t  file_length = (uint32_t)io_input.tellg();
    io_input.seekg(0,std::ios::beg);
    
    char *buffer = new char[file_length + 1];
    io_input.read(buffer, file_length);
    io_input.close();
    buffer[file_length + 1] = 0;
    
    int32_t  byte_read = 0;
    char  line_buffer[1024];
    
    size_t split_pos = atlas_name.find_last_of('/');
    const std::string directory_name = split_pos == std::string::npos? "" : atlas_name.substr(0,split_pos + 1);
    const std::string simple_name = atlas_name.substr(split_pos == std::string::npos?0:split_pos + 1);
    record.append("#\n").append(simple_name).append("\n");
    
    while(byte_read <= file_length){
        //第一行必定为空
        int32_t  r0 = string_read_line(buffer + byte_read, line_buffer);
        int32_t  r1 = string_trim(line_buffer);
        assert(r1 == 0);
        byte_read += r0;
        //第二行开始
        int32_t  r2 = string_read_line(buffer + byte_read,line_buffer);
        int32_t  r3 = string_trim(line_buffer);
        byte_read += r2;
        //如果r3 == 0,则跳出循环,此时已经没有任何需要处理的字符串了
        if(r3 == 0)break;
        //record.append(line_buffer).append("\n");//文件名
        
        std::string png_name = directory_name + line_buffer;
        std::string png_prefix;
        string_sub_string_last_with(line_buffer,'.', png_prefix);
        
        Image  *image = new Image();
        image->initWithImageFile(png_name);
        uint8_t *image_data = image->getData();
        if(!image_data){
            printf("--process atlas file '%s'  ref image file '%s'error ------\n",atlas_name.c_str(),png_name.c_str());
            assert(image_data != nullptr);
        }
        int32_t image_width = image->getWidth();
        const int32_t step_cx = 4;
        //size
        int32_t  r4 = string_read_line(buffer + byte_read,line_buffer);
        byte_read += r4;
        //record.append(line_buffer).append("\n");
        //format
        int32_t r5 = string_read_line(buffer + byte_read,line_buffer);
        byte_read += r5;
        record.append(line_buffer).append("\n");
        //filter
        int32_t r6 = string_read_line(buffer + byte_read,line_buffer);
        byte_read += r6;
        record.append(line_buffer).append("\n");
        //repeat
        int32_t r7 = string_read_line(buffer + byte_read, line_buffer);
        byte_read += r7;
        record.append(line_buffer).append("\n");
        //接下来开始处理atlas纹理子集
        int32_t r8 = string_read_line(buffer + byte_read, line_buffer);
        byte_read += r8;
        while(byte_read <= file_length && string_trim(line_buffer) != 0){
            //name
            std::string sub_name = line_buffer;
            char name_buffer[1024];
            sprintf(name_buffer,"%s_%s.png",png_prefix.c_str(),sub_name.c_str());
            record.append(line_buffer).append(":").append(name_buffer).append("\n");
            //rotate
            int32_t r9 = string_read_line(buffer + byte_read,line_buffer);
            byte_read += r9;
            string_trim(line_buffer);
            assert(string_begin_with(line_buffer,"rotate:"));
            bool is_rotate = string_end_with(line_buffer,"true");
            //xy
            int32_t r10 = string_read_line(buffer + byte_read,line_buffer);
            byte_read += r10;
            
            string_trim(line_buffer);
            assert(string_begin_with(line_buffer,"xy:"));
            
            int32_t  x = 0,y = 0;
            string_extract_2_number(line_buffer,x,y);
            
            //只记录size/origin/index,其他数据可以在运行时生成
            //size
            int32_t r11 = string_read_line(buffer + byte_read,line_buffer);
            byte_read += r11;
            //record.append(line_buffer).append("\n");
            string_trim(line_buffer);
            assert(string_begin_with(line_buffer, "size:"));
            
            int32_t sub_width = 0,sub_height = 0;
            string_extract_2_number(line_buffer,sub_width,sub_height);
            
            //orig
            int32_t r12 = string_read_line(buffer + byte_read, line_buffer);
            byte_read += r12;
            record.append(line_buffer).append("\n");
            string_trim(line_buffer);
            assert(string_begin_with(line_buffer, "orig:"));
            
            int32_t origin_width = 0,origin_height = 0;
            string_extract_2_number(line_buffer,origin_width,origin_height);
            
            //offset
            int32_t r13 = string_read_line(buffer + byte_read, line_buffer);
            byte_read += r13;
            record.append(line_buffer).append("\n");
            string_trim(line_buffer);
            assert(string_begin_with(line_buffer, "offset:"));
            
            int32_t  offset_x = 0,offset_y = 0;
            string_extract_2_number(line_buffer,offset_x,offset_y);
            
            //index
            int32_t  r14 = string_read_line(buffer + byte_read, line_buffer);
            byte_read += r14;
            record.append(line_buffer).append("\n");
            string_trim(line_buffer);
            assert(string_begin_with(line_buffer, "index:"));
            
            int32_t  index = -1;
            string_extract_1_number(line_buffer,index);
            
            //分割纹理
            int32_t  pixel_number = sub_width * sub_height * step_cx;
            uint8_t  *sub_image_data = new uint8_t[pixel_number];
            
            //copy
            if(!is_rotate){
                for(int32_t j = 0;j < sub_height; ++j)
                    memcpy(sub_image_data + j * sub_width * step_cx,image_data + ((y + j) * image_width + x) * step_cx,sub_width * step_cx);
            }
            else{//如果帧是处于旋转状态,则需要矫正过来
                for(int32_t row = 0;row < sub_height; ++row){
                    uint8_t  *row_data = sub_image_data + row * sub_width * step_cx;
                    for(int32_t column = 0;column < sub_width; ++column){
                        int32_t  base_x4 = ((y + sub_width - column - 1) * image_width + x + row) * step_cx;
                        int32_t  k4 = column * step_cx;
                        for(int32_t j = 0;j < step_cx; ++j)
                            row_data[k4+ j] = image_data[base_x4 + j];
                    }
                }
            }
            
            sprintf(name_buffer,"%s%s_%s.png",out_directory.c_str(),png_prefix.c_str(),sub_name.c_str());
            Image  *sub_image = new Image();
            sub_image->initWithRawData(sub_image_data, pixel_number, sub_width, sub_height, step_cx,false);
            sub_image->saveToFile(name_buffer,false);
            
            delete sub_image;
            delete[] sub_image_data;
            //再次读取
            int32_t  r15 = string_read_line(buffer + byte_read, line_buffer);
            byte_read += r15;
        }
        
        delete image;
    }
    
    delete[] buffer;
    buffer = nullptr;
    printf("process file '%s' success ....\n",atlas_name.c_str());
    return true;
}
/*
 *2021/10/19 221:00
 *分析plist文件,生成对应的atlas文件,该文件将被输出到一个定向目录中
 *并且,程序将不检查输入文件的合法性，如果出现意外,使用者且小心
 *输出目录以/结尾
 */
bool chapter_file_parser(const std::string &chapter_name,const std::string &prefix_content,SpriteFrameCache *cache_map,const std::string &output_directory,std::set<std::string> &need_parse_sprite_set){
    //读取文件内容
    std::ifstream  io_input;
    io_input.open(chapter_name);
    if(!io_input.is_open()){
        printf("file %s is not exist.\n",chapter_name.c_str());
        io_input.close();
        return false;
    }
    //获取文件长度
    io_input.seekg(0, std::ios::end);
    uint32_t  file_length = (uint32_t)io_input.tellg();
    io_input.seekg(0,std::ios::beg);
    
    char *buffer = new char[file_length + 1];
    io_input.read(buffer, file_length);
    io_input.close();
    buffer[file_length + 1] = 0;
    
    int32_t  byte_read = 0;
    char  line_buffer[1024];
    
    int32_t  r0 = string_read_line(buffer + byte_read, line_buffer);
    byte_read += r0;
    while(*line_buffer == '#' && byte_read < file_length){
        //第一行为atlas文件名字
        int32_t  r1 = string_read_line(buffer + byte_read, line_buffer);
        byte_read += r1;
        string_trim(line_buffer);
        std::string atlas_name = line_buffer;
        
        std::string file_record;//记录文件的内容
        file_record.append(prefix_content).append("\n");
        
        //format
        int32_t  r2 = string_read_line(buffer + byte_read, line_buffer);
        byte_read += r2;
        file_record.append(line_buffer).append("\n");
        
        //filter
        int32_t  r3 = string_read_line(buffer + byte_read, line_buffer);
        byte_read += r3;
        file_record.append(line_buffer).append("\n");
        
        //repeat
        int32_t  r4 = string_read_line(buffer + byte_read, line_buffer);
        byte_read += r4;
        file_record.append(line_buffer).append("\n");
        
        //atlas region
        int32_t  r5 = string_read_line(buffer + byte_read, line_buffer);
        byte_read += r5;
        while(*line_buffer != '#' && byte_read < file_length){
            string_trim(line_buffer);
            char  buffer_1[256],buffer_2[256];
            string_extract_2_string(line_buffer,buffer_1,buffer_2);
            file_record.append(buffer_1).append("\n");
            
            //rotate
            SpriteFrame  *frame = cache_map->getSpriteFrameByName(buffer_2);
            assert(frame != nullptr);
            file_record.append("  rotate: ").append(frame->isRotated()?"true" : "false").append("\n");
            need_parse_sprite_set.insert(buffer_2);
            
            //xy
            const Rect4 &rect  = frame->getRectInPixels();
            sprintf(buffer_1,"  xy: %d, %d\n",(int32_t)rect.origin.x,(int32_t)rect.origin.y);
            file_record.append(buffer_1);
            
            //size
            sprintf(buffer_2,"  size: %d, %d\n",(int32_t)rect.size.width,(int32_t)rect.size.height);
            file_record.append(buffer_2);
            
            //origin
            int32_t r6 = string_read_line(buffer + byte_read,line_buffer);
            byte_read += r6;
            file_record.append(line_buffer).append("\n");
            
            //offset
            int32_t r7 = string_read_line(buffer + byte_read,line_buffer);
            byte_read += r7;
            file_record.append(line_buffer).append("\n");
            
            //index
            int32_t r8 = string_read_line(buffer + byte_read, line_buffer);
            byte_read += r8;
            file_record.append(line_buffer).append("\n");
            
            int32_t r9 = string_read_line(buffer + byte_read, line_buffer);
            byte_read += r9;
        }
        //将以上数据写入到相关文件中
        char name_buffer[1024];
        sprintf(name_buffer,"%s%s",output_directory.c_str(),atlas_name.c_str());
        
        std::ofstream  out_stream;
        out_stream.open(name_buffer,std::ios::trunc);
        if(!out_stream.is_open()){
            out_stream.close();
            printf("could not create file '%s', failed...\n",name_buffer);
            continue;
        }
        out_stream.write(file_record.c_str(), file_record.size());
        out_stream.close();
    }
    
    delete[] buffer;
    buffer = nullptr;
    
    return true;
}
/*
 *将plist文件中与其对应的textur纹理集文件中局部方向处于旋转状态的frame往相反方向旋转
 */
bool  plist_texture_atlas_rotate_justify(Image  *image,SpriteFrameCache *cache_map,const std::string &new_name,std::set<std::string> need_parse_sprite_set){
    uint8_t  *image_data = image->getData();
    int32_t   image_width = image->getWidth();
    int32_t  image_height = image->getHeight();
    const int32_t step_cx = 4;
    //visit
    //const std::map<std::string,SpriteFrame*> &sprite_frame_map = cache_map->getSpriteFrameMap();
    std::set<int32_t> incase_frame_alias_set;
    for(auto it = need_parse_sprite_set.begin(); it != need_parse_sprite_set.end();++it){
        SpriteFrame  *sprite_frame = cache_map->getSpriteFrameByName(*it);
        assert(sprite_frame != nullptr);
        //如果处于旋转状态,则需要左右/上下各镜像一次
        if(!sprite_frame->isRotated() || sprite_frame->isVerify())continue;
        //另外需要判断是否已经矫正过该frame
        sprite_frame->setVerify(true);
        const Rect4 &rect = sprite_frame->getRectInPixels();
        int32_t offset_x = rect.origin.x;
        int32_t offset_y = rect.origin.y;
        int32_t width = rect.size.width;
        int32_t height = rect.size.height;
        
        int32_t key_alias = (width << 24) + (height << 16) + (offset_x << 8) + offset_y;
        if(incase_frame_alias_set.find(key_alias) != incase_frame_alias_set.end())continue;
        incase_frame_alias_set.insert(key_alias);
        
        //左右
        int32_t half_width = height/2;
        for(int32_t x = 0;x < half_width;++x){
            for(int32_t y = 0;y < width;++y){
                int32_t  L0 = ((offset_y + y) * image_width + x + offset_x) * step_cx;
                int32_t  R0 = ((offset_y + y) * image_width +offset_x + height - 1 - x) * step_cx;
                
                char c0[4];
                memcpy(c0,image_data + L0,step_cx);
                memcpy(image_data + L0,image_data + R0,step_cx);
                memcpy(image_data + R0,c0,step_cx);
            }
        }
        //上下
        int32_t half_height = width/2;
        for(int32_t  y = 0;y < half_height;++y){
            for(int32_t x = 0;x < height; ++ x){
                int32_t  T0 = ((offset_y + y) * image_width + offset_x + x) * step_cx;
                int32_t  B0 = ((offset_y + width - 1 - y) * image_width + offset_x + x) * step_cx;
                
                char c0[4];
                memcpy(c0,image_data + T0,step_cx);
                memcpy(image_data + T0,image_data + B0,step_cx);
                memcpy(image_data + B0,c0,step_cx);
            }
        }
    }
    
    //最后,使用新生成的数据,重生导出新文件
    Image  *new_image = new Image();
    new_image->initWithRawData(image_data, image_width * image_height * step_cx, image_width, image_height, step_cx);
    new_image->saveToFile(new_name,false);
    
    delete new_image;
   // delete image;
    
    return true;
}
//
void  spine_search_file_cascade(const std::string &directory,std::list<std::string> &file_list,const char *postfix_name){
    std::list<std::string>  secondary_directory;
    secondary_directory.push_back(directory);
    
    while(!secondary_directory.empty()){
        const std::string &directory_item = secondary_directory.front();
        DIR  *dir_ptr = opendir(directory_item.c_str());
        struct dirent  *rent_item;
        
        while((rent_item = readdir(dir_ptr)) != nullptr){
            if(strcmp(rent_item->d_name,".") && strcmp(rent_item->d_name,"..") && !string_begin_with(rent_item->d_name,".")){
                char  buffer[4096];
                //如果不是目录
                if(rent_item->d_type == DT_REG && string_end_with(rent_item->d_name,postfix_name)){
                    sprintf(buffer,"%s/%s",directory_item.c_str(),rent_item->d_name);
                    file_list.push_back(buffer);
                }else if(rent_item->d_type == DT_DIR){
                    sprintf(buffer,"%s/%s",directory_item.c_str(),rent_item->d_name);
                    secondary_directory.push_back(buffer);
                }
            }
        }
        secondary_directory.pop_front();
        closedir(dir_ptr);
    }
}
/*
 *处理plist文件,可以将关键信息补充完全
 *已经嘉定所有输入数据完全合法
 *2021/10/23
 */
bool plist_process_sumplement_key_info(const std::string &plist_name,const std::string &sub_plist_directory,const std::string &new_plist_name){
    //第一步,读取文件的内容信息
    std::ifstream  io_input;
    io_input.open(plist_name);
    if(!io_input.is_open()){
        printf("file %s is not exist.\n",plist_name.c_str());
        io_input.close();
        return false;
    }
    //获取文件长度
    io_input.seekg(0, std::ios::end);
    uint32_t  file_length = (uint32_t)io_input.tellg();
    io_input.seekg(0,std::ios::beg);
    
    std::string file_record;
    file_record.resize(file_length);
    
    io_input.read((char *)file_record.data(), file_length);
    io_input.close();
    
    const char *buffer_ptr = file_record.data();
    int32_t  byte_read = 0;
    char  line_buffer[1024];
    
    //获取sub_plist_directory目录中所有的plist文件,函数将逐层级遍历
    std::list<std::string> file_list;
    spine_search_file_cascade(sub_plist_directory,file_list,".plist");
    //将以上文件全部加载到SpriteFrameCache对象中
    SpriteFrameCache  *frame_cache = SpriteFrameCache::create();
    for(auto it = file_list.begin();it != file_list.end();++it){
        frame_cache->addSpriteFramesWithFile(*it);
    }
    //然后针对所有的对象,将其中所涉及到关键信息,写入到file_record中
    const std::map<std::string,SpriteFrame *> &sprite_frame_map = frame_cache->getSpriteFrameMap();
    for(auto it = sprite_frame_map.begin();it != sprite_frame_map.end();++it){
        const std::string &frame_name = it->first;
        SpriteFrame *frame_object = it->second;
        //检测offset信息,如果其值不为0，则需要作出变更
        const Vec2  &offset = frame_object->getOffsetInPixels();
        if(offset.x == 0.0f && offset.y == 0.0f)continue;
        //否则,需要查找,如果没有找到则直接跳到下一轮的循环
        size_t find_loc = file_record.find(frame_name);
        if(find_loc == std::string::npos)continue;
        //接下来,我们将开始进行字符串替换
        char  replace_buffer[128];
        sprintf(replace_buffer,"\t\t\t\t<string>{%d,%d}</string>",(int32_t)offset.x,(int32_t)offset.y);
        
        byte_read = (int32_t)find_loc;
        int32_t r0 = string_read_line(buffer_ptr + byte_read, line_buffer);
        byte_read += r0;
        
        int32_t r6 = string_read_line(buffer_ptr + byte_read, line_buffer);
        byte_read += r6;
        string_trim(line_buffer);
        assert(string_begin_with(line_buffer, "<dict>"));
        
        int32_t r1 = string_read_line(buffer_ptr + byte_read, line_buffer);
        byte_read += r1;
        string_trim(line_buffer);
        assert(string_begin_with(line_buffer, "<key>"));
        
        int32_t r2 = string_read_line(buffer_ptr + byte_read, line_buffer);
        byte_read += r2;
        string_trim(line_buffer);
        assert(string_begin_with(line_buffer, "<string>"));
        
        int32_t r3 = string_read_line(buffer_ptr + byte_read,line_buffer);
        byte_read += r3;
        string_trim(line_buffer);
        assert(string_begin_with(line_buffer, "<key>"));//offset
        
        int32_t r4 = string_read_line(buffer_ptr + byte_read, line_buffer);
        string_trim(line_buffer);
        assert(string_begin_with(line_buffer, "<string>"));
        
        file_record.replace(byte_read, r4 - 1, replace_buffer);
    }
    delete frame_cache;
    
    //将以上数据写入到相关文件中
    std::ofstream  out_stream;
    out_stream.open(new_plist_name.c_str(),std::ios::trunc);
    if(!out_stream.is_open()){
        out_stream.close();
        printf("could not create file '%s', failed...\n",new_plist_name.c_str());
        return false;
    }
    out_stream.write(file_record.c_str(), file_record.size());
    out_stream.close();
    
    return true;
}

bool create_direcory_cascade(const std::string &directory,const char *frame_name,std::set<std::string> &directory_set){
    char  buffer2[1024];
    int32_t  s0 = sprintf(buffer2,"%s",directory.c_str());
    buffer2[s0] = '/';
    s0 += 1;
    
    for(int32_t j = 0; frame_name[j]; ++j){
        if(frame_name[j] == '/'){
            buffer2[s0 + j] = 0;
            if(directory_set.find(buffer2) == directory_set.end()){
                directory_set.insert(buffer2);
                if(mkdir(buffer2, 0775) != 0){
                    printf("--创建目录%s失败，请稍后再试....\n",buffer2);
                }
            }
        }
        buffer2[s0 + j] = frame_name[j];
    }
    return true;
}
/*
 *分割plist文件中所涉及到的frame,并处理带有旋转/或者带有特殊路径符号的帧
 */
bool plist_split_frame(const std::string &plist_name,const std::string &output_directory){
    SpriteFrameCache  *cache_object = SpriteFrameCache::create();
    cache_object->addSpriteFramesWithFile(plist_name);
    const std::string &texture_name = cache_object->getTextureName();
    size_t tex_loc =plist_name.find_last_of('/');
    const std::string texture_plist = tex_loc == std::string::npos?texture_name : plist_name.substr(0,tex_loc + 1) + texture_name;
    //image
    Image  *image = new Image();
    image->initWithImageFile(texture_name);
    uint8_t  *image_data = image->getData();
    assert(image->getData());
    
    int32_t image_width = image->getWidth();
    std::set<std::string>  directory_set;
    char  buffer[1024];
    //visit
    const std::map<std::string,SpriteFrame*>  &frame_map = cache_object->getSpriteFrameMap();
    const int32_t step_cx = 4;
    for(auto it = frame_map.cbegin();it != frame_map.cend();++it){
        const std::string &frame_name = it->first;
        SpriteFrame *frame = it->second;
        const Rect4 &rect = frame->getRectInPixels();
        
        int32_t  width = rect.size.width;
        int32_t  height = rect.size.height;
        int32_t  offset_x = rect.origin.x;
        int32_t  offset_y = rect.origin.y;
        
        uint8_t  *sub_image_data = new uint8_t[width * height * step_cx];
        
        //需要区分是否旋转
        if(!frame->isRotated()){
            for(int32_t y = 0;y < height; ++y)
                memcpy(sub_image_data + y * width * step_cx,image_data + ((offset_y + y) * image_width + offset_x) * step_cx,width * step_cx);
        }
        else{
            for(int32_t x = 0;x < height;++x){
                for(int32_t y = 0;y < width; ++y){
                    int32_t s0 = ((offset_y + y) * image_width + offset_x + (height - 1 - x)) * step_cx;
                    int32_t t0 = (x * width + y) * step_cx;
                    
                    memcpy(sub_image_data + t0,image_data + s0,step_cx);
                }
            }
        }
        create_direcory_cascade(output_directory,frame_name.c_str(),directory_set);
        sprintf(buffer,"%s/%s",output_directory.c_str(),frame_name.c_str());
        //output
        Image *sub_image = new Image();
        sub_image->initWithRawData(sub_image_data, width * height * step_cx, width, height, step_cx);
        sub_image->saveToFile(buffer,false);
        
        delete sub_image;
        delete[] sub_image_data;
    }
    
    delete image;
    
    return true;
}
