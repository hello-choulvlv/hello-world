#if defined(__LP64__) && __LP64__
#include"tiffconf-64.h"
#else
#include"tiffconf-32.h"
#endif