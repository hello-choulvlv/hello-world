参考https://github.com/chago/ADVMP.git

1.实现hook调用

2.实现225指令集

3.解决报错问题


