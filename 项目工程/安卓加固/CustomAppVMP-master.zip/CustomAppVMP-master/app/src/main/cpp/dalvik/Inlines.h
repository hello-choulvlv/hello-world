//
// Created by liu meng on 2018/8/31.
//

#ifndef CUSTOMAPPVMP_INLINES_H
#define CUSTOMAPPVMP_INLINES_H
#ifndef _DALVIK_GEN_INLINES             /* only defined by Inlines.c */
# define INLINE extern __inline__
#else
# define INLINE
#endif
#endif //CUSTOMAPPVMP_INLINES_H
