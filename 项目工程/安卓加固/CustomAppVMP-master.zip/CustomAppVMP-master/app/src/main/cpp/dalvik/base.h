//
// Created by liu meng on 2018/9/3.
//

#ifndef CUSTOMAPPVMP_BASE_H
#define CUSTOMAPPVMP_BASE_H
#define false 0
#define  true 1
#endif //CUSTOMAPPVMP_BASE_H
