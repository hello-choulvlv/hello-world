#pragma once

#include <jni.h>


extern JNIEnv *gEnv;
