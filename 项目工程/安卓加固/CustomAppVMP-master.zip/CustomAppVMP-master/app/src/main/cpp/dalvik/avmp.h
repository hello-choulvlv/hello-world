//
// Created by liu meng on 2018/9/4.
//

#ifndef CUSTOMAPPVMP_AVMP_H
#define CUSTOMAPPVMP_AVMP_H
#include "InterpC.h"
#include <dlfcn.h>
#endif //CUSTOMAPPVMP_AVMP_H
