//
//  GlobalValue.cpp
//  BoneTest
//
//  Created by charlie on 2017/3/11.
//
//

#include "GlobalValue.hpp"

float const GLOBAL_VALUE::EPSILON = 0.0000001;
