/*
  *3D模型批处理渲染类
  *2019年1月3日
  *@author:xiaohuaxiong
 */
#include "3d/CCSprite3DBatch.h"
#include "3d/CCMesh.h"
#include "3d/CCMeshSkin.h"
#include "base/CCDirector.h"
#include "base/CCConfiguration.h"
#include "2d/CCCamera.h"
#include "renderer/CCRenderState.h"
#include "renderer/CCMaterial.h"
#include "renderer/CCRenderer.h"
#include "renderer/CCTextureCache.h"
#include "renderer/CCTextureCube.h"

NS_CC_BEGIN
bool Sprite3DBatch::checkSupportOpenGL3()
{
	return Configuration::getInstance()->supportGLES3();
}

bool  Sprite3DBatch::checkSupportDrawInstanced()
{
	return Configuration::getInstance()->supportDrawInstanced();
}

bool Sprite3DBatch::checkSupportInstancedArrays()
{
	return Configuration::getInstance()->supportInstancedArrays();
}

int  Sprite3DBatch::getVersion()
{
	return 3;
}

float Sprite3DBatch::getGLVersion(){
    return Configuration::getInstance()->getGLVersion();
}

int  Sprite3DBatch::getMaxTextureImageUnits()
{
	return Configuration::getInstance()->getMaxTextureImageUnits();
}

Sprite3DBatch::Sprite3DBatch():
	_batchMesh(nullptr)
    ,_texture2DArray(nullptr)
    ,_textureArrayLoc(-1)
    ,_texture2DArrayLoc(-1)
	, _isSupportTextureArray(false)
	, _isSupportMVPMatrix(false)
{
}

Sprite3DBatch::~Sprite3DBatch()
{
	if(_batchMesh)
		_batchMesh->release();
    if(_texture2DArray != nullptr)
        _texture2DArray->release();
}

Sprite3DBatch *Sprite3DBatch::create(Mesh *mesh)
{
	Sprite3DBatch *model_batch = new Sprite3DBatch();
	if (model_batch->init(mesh,nullptr))
	{
        model_batch->autorelease();
		return model_batch;
	}
    model_batch->release();
	return model_batch;
}

Sprite3DBatch *Sprite3DBatch::createWithTextureArray(Mesh *mesh, Texture2DArray *texture_array)
{
    Sprite3DBatch *model_batch = new Sprite3DBatch();
    if (model_batch->init(mesh,texture_array))
    {
        model_batch->autorelease();
        return model_batch;
    }
    model_batch->release();
    return model_batch;
}

bool  Sprite3DBatch::init(Mesh *mesh,Texture2DArray *texture_array)
{
	Node::init();
	if(mesh != nullptr)
		setBatchMesh(mesh);
    if(texture_array != nullptr)
        setTexture2DArray(texture_array);
	return true;
}

void  Sprite3DBatch::setBatchMesh(Mesh *mesh)
{
	CCASSERT(mesh !=nullptr,"template mesh could not be nullptr");
	mesh->retain();
	if (_batchMesh)
		_batchMesh->release();
	_batchMesh = mesh;
	//
	_glProgramState = _batchMesh->getGLProgramState();
	_glProgramState->retain();
	//提取出相关的信息
	GLProgram *program = _glProgramState->getGLProgram();
	_textureArrayLoc = program->getUniformLocation("CSVK_TextureArray");
	_textureIndexArrayLoc = program->getUniformLocation("CSVK_TextureIndexArray");
    _texture2DArrayLoc = program->getUniformLocation("CV_Texture2DArray");
	_isSupportTextureArray = _textureArrayLoc != -1 || _texture2DArrayLoc != -1;
	_batchCommand.setSupportTextureArray(_isSupportTextureArray);
	_batchCommand.setTextureArrayLoc(_textureArrayLoc);
    _batchCommand.setTexture2DArrayLoc(_texture2DArrayLoc);
	_batchCommand.setTextureIndexArrayLoc(_textureIndexArrayLoc);

	_modelViewProjLoc = program->getUniformLocation("CSVK_ModelViewProj");
	_isSupportMVPMatrix = _modelViewProjLoc != -1;
	//如果不支持MVP矩阵,则必须支持模型矩阵
	if (!_isSupportMVPMatrix)
		_modelViewProjLoc = program->getUniformLocation("CSVK_ModelMatrix");
	_batchCommand.setSupportMVPMatrix(_isSupportMVPMatrix);
	_batchCommand.setMVPMatrixLoc(_modelViewProjLoc);
}

void Sprite3DBatch::setTexture2DArray(Texture2DArray *texture_array){
    if(texture_array != nullptr)texture_array->retain();
    if(_texture2DArray != nullptr)_texture2DArray->release();
    _texture2DArray = texture_array;
}

void  Sprite3DBatch::visit(Renderer *renderer, const Mat4& parentTransform, uint32_t parentFlags)
{
	// quick return if not visible. children won't be drawn.
	if (!_visible)
		return;

	uint32_t flags = processParentFlags(parentTransform, parentFlags);
	flags |= FLAGS_RENDER_AS_3D;
	//
	Director* director = Director::getInstance();
	director->pushMatrix(MATRIX_STACK_TYPE::MATRIX_STACK_MODELVIEW);
	director->loadMatrix(MATRIX_STACK_TYPE::MATRIX_STACK_MODELVIEW, _modelViewTransform);

	bool visibleByCamera = isVisitableByVisitingCamera();

	int i = 0;

	if (!_children.empty() && visibleByCamera)
	{
		sortAllChildren();
		// draw children zOrder < 0
		for (auto size = _children.size(); i < size; i++)
		{
			auto node = _children.at(i);

			if (node && node->getLocalZOrder() < 0)
				node->visit(renderer, _modelViewTransform, flags);
			else
				break;
		}
		for (auto it = _children.cbegin() + i, itCend = _children.cend(); it != itCend; ++it)
			(*it)->visit(renderer, _modelViewTransform, flags | FLAGS_RENDER_BATCH);
		// self draw
		this->draw(renderer, _modelViewTransform, flags);
	}
	else if (visibleByCamera)
	{
		this->draw(renderer, _modelViewTransform, flags);
	}

	director->popMatrix(MATRIX_STACK_TYPE::MATRIX_STACK_MODELVIEW);
}

void  Sprite3DBatch::draw(Renderer *renderer, const Mat4& transform, uint32_t flags)
{
	//针对每一个Sprite3D,依次遍历,并且提取出模型矩阵
	int  child_count = 0;
	const Camera  *visitingCamera = Camera::getVisitingCamera();
	Vec4  color_4f(_displayedColor.r/255.0f,_displayedColor.g/255.0f,_displayedColor.g/255.0f, _displayedOpacity/255.0f);//color->transform children

	std::map<int,int>		texture_array;
	for (int k = 0; k < _children.size(); ++k)
	{
		Sprite3D  *v3d = (Sprite3D *)_children.at(k);
		//模型可见,并且视锥体可见,提取出模型矩阵
		if (!v3d->isVisible() || !visitingCamera->isVisibleInFrustum(&v3d->getAABB()))
			continue;
		Skeleton3D  *skeleton = v3d->getSkeleton();
		if(skeleton)
			skeleton->updateBoneMatrix();
        memcpy(_modelViewProj[child_count].m,v3d->_modelViewTransform.m,sizeof(float) * 16);
		//_modelViewProj[child_count] = v3d->_modelViewTransform;
        
        //要么程序使用Texture Array,要么使用Texture2D Array
        if(_textureArrayLoc != -1){
            _textureIDIndexArray[child_count] = v3d->getMesh()->getTexture()->getName();
            if (texture_array.find(_textureIDIndexArray[child_count]) == texture_array.end())
                texture_array[_textureIDIndexArray[child_count]] = (int)texture_array.size();
        }else if(_texture2DArrayLoc != -1){
            const std::string &file_name = v3d->getMesh()->getOriginTextureName();
            int32_t  layer_index = _texture2DArray->checkTextureIndex(file_name);
            CCASSERT(layer_index != -1,"could not load texture layer");
            _textureIDIndexArray[child_count] = layer_index;
        }

        //v3d->getMesh()->getTextureFileName();
		++child_count;
	}
	//texture_array的尺寸不能大于4
	//CCASSERT(texture_array.size()< 5,"Sprite3DBatch could not support texture array,which size greater than 4.");
	if (child_count > 0 && _batchMesh)
	{
		_batchCommand.init(_globalZOrder, _batchMesh->getMaterial(), _batchMesh->getVertexBuffer(),
			_batchMesh->getIndexBuffer(), _batchMesh->getPrimitiveType(), _batchMesh->getIndexFormat(), _batchMesh->getIndexCount(),
			_modelViewProj,child_count,flags);

		_batchMesh->getMaterial()->getStateBlock()->setDepthWrite(true);

		_batchCommand.set3D(_batchMesh->_force2DQueue);
		_batchMesh->getMaterial()->getStateBlock()->setBlend(_batchMesh->_force2DQueue || color_4f.w < 1.0f);

		// set default uniforms for Mesh
		auto technique = _batchMesh->getMaterial()->_currentTechnique;
		for (const auto pass : technique->_passes)
		{
			auto programState = pass->getGLProgramState();
			programState->setUniformVec4("u_color", color_4f);

			if (_batchMesh->_skin)
				programState->setUniformVec4v("u_matrixPalette", (GLsizei)_batchMesh->_skin->getMatrixPaletteSize(), _batchMesh->_skin->getMatrixPalette());
		}
		//检测是否支持纹理数组
		if (_isSupportTextureArray)
		{
			//检查纹理的索引顺序
            if(_textureArrayLoc != -1){
                for (int k = 0; k < child_count; ++k)
                {
                    auto it = texture_array.find(_textureIDIndexArray[k]);
                    _textureIDIndexArray[k] = it->second;
                }
                _batchCommand.setTextureArray(texture_array);
            }else
                _batchCommand.setTexture2DArray(_texture2DArray->getName());
			_batchCommand.setTextureIndexArray(_textureIDIndexArray, child_count,_textureArrayLoc != -1);
		}
		renderer->addCommand(&_batchCommand);
	}
}

NS_CC_END
