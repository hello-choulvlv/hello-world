/*
  *3d模型批处理渲染
  *2019年1月3日
  *@author:xiaohuaxiong
  *@Version-1:实现基本的实例化渲染功能
  *@Version-2:优化程序实现,删除了多余的功能,并且增加了对纹理数组的支持
  *@Version-3:支持多个一个SpriteD模型的多个Mesh同时实例化渲染
 */
#ifndef _SPRITE_3D_BATCH_H_
#define _SPRITE_3D_BATCH_H_
#include "2d/CCNode.h"
#include "3d/CCSprite3D.h"
#include "renderer/CCTexture2D.h"
#include "renderer/CCMeshBatchCommand.h"
NS_CC_BEGIN

class  Texture2DArray;

class CC_DLL Sprite3DBatch : public Node
{
	//目前暂时定义每次最大渲染数目为36
	Mat4                                _modelViewProj[36];
	//纹理数组
	int                                     _textureIDIndexArray[36];
	//最大纹理数目
	int                                     _maxTextureUnitNumber;
	//模型批处理
	MeshBatchCommand   _batchCommand;
	Mesh                                *_batchMesh;
    Texture2DArray               *_texture2DArray;
	//是否支持纹理数组,如果为false,则表示单一的纹理
	bool                                   _isSupportTextureArray;
	//是否支持MVP矩阵,如果不支持,则表示单一的模型矩阵
	bool                                   _isSupportMVPMatrix;
	//location
	int                                      _textureArrayLoc,_texture2DArrayLoc;
	int                                      _textureIndexArrayLoc;
	int                                      _modelViewProjLoc;
public:
	Sprite3DBatch();
	~Sprite3DBatch();
	static Sprite3DBatch   *create(Mesh *mesh);
	static Sprite3DBatch   *createWithTextureArray(Mesh *mesh,Texture2DArray *texture_array);
	/*
	  *Version
	 */
	static int		getVersion();
    static float  getGLVersion();
	/*
	  *max texture unit
	 */
	static int   getMaxTextureImageUnits();
	/*
	  *check OpenGL Version
	 */
	static bool  checkSupportOpenGL3();
	/*
	  *检测是否支持扩展 GL_EXT_draw_instanced扩展
	 */
	static bool  checkSupportDrawInstanced();
	/*
	  *检测是否支持扩展GL_EXT_instanced_arrays
	 */
	static bool checkSupportInstancedArrays();
	/*
	  *init
	 */
	bool  init(Mesh *mesh,Texture2DArray *texture_array);
	/*
	  *设置待处理的Mesh批处理模板
	 */
	void  setBatchMesh(Mesh  *mesh);
    void  setTexture2DArray(Texture2DArray *texture_array);
    Texture2DArray  *getTexture2dArray()const{return _texture2DArray;};
	/*
	  *visit函数
	 */
	virtual  void  visit(Renderer *renderer, const Mat4& parentTransform, uint32_t parentFlags);
	/*
	  *最重要的draw函数
	 */
	virtual  void  draw(Renderer *renderer, const Mat4& transform, uint32_t flags);
};
NS_CC_END
#endif
