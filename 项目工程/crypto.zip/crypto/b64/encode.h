// :mode=c++:
/*
encode.h - c++ wrapper for a base64 encoding algorithm

This is part of the libb64 project, and has been placed in the public domain.
For details, see http://sourceforge.net/projects/libb64
*/
#ifndef BASE64_ENCODE_H
#define BASE64_ENCODE_H

#ifndef BUFFERSIZE
#define BUFFERSIZE 1024
#endif

#include <iostream>

namespace base64
{
	extern "C" 
	{
		#include "cencode.h"
	}

	struct encoder
	{
		base64_encodestate _state;
		int _buffersize;

		encoder(int buffersize_in = BUFFERSIZE)
		: _buffersize(buffersize_in)
		{}

		int encode(char value_in)
		{
			return base64_encode_value(value_in);
		}

		int encode(const char* code_in, const int length_in, char* plaintext_out)
		{
			return base64_encode_block(code_in, length_in, plaintext_out, &_state);
		}

		int encode_end(char* plaintext_out)
		{
			return base64_encode_blockend(plaintext_out, &_state);
		}

		void encode(std::istream& istream_in, std::ostream& ostream_in)
		{
			base64_init_encodestate(&_state);
			//
			const int N = _buffersize;
			char* plaintext = new char[N];
			char* code = new char[2*N];
			int plainlength;
			int codelength;

			do
			{
				istream_in.read(plaintext, N);
				plainlength = istream_in.gcount();
				//
				codelength = encode(plaintext, plainlength, code);
				ostream_in.write(code, codelength);
			}
			while (istream_in.good() && plainlength > 0);

			codelength = encode_end(code);
			ostream_in.write(code, codelength);
			//
			base64_init_encodestate(&_state);

			delete [] code;
			delete [] plaintext;
		}
        int encode2(const char* code_in, const int length_in, char* plaintext_out)
		{
			base64_init_encodestate(&_state);
			//
			const int N = _buffersize;
			char* plaintext = new char[N];
			char* code = new char[2*N];
			int plainlength;
			int codelength;
            
            int start = 0;
            int plaintext_out_len = 0;
            while (start + N <= length_in) {
                codelength = encode(code_in+start,N,code);                
                strncpy(plaintext_out+plaintext_out_len, code, codelength);
                start += N;
                plaintext_out_len += codelength;
            }
            if(length_in-start>0){
                codelength = encode(code_in+start,length_in-start,code);
                strncpy(plaintext_out+plaintext_out_len, code, codelength);
                plaintext_out_len += codelength;
            }
            
            codelength = encode_end(code);
            strncpy(plaintext_out+plaintext_out_len, code, codelength);
            plaintext_out_len += codelength;
            
            base64_init_encodestate(&_state);
            
			delete [] code;
			delete [] plaintext;
            return plaintext_out_len;
		}
	};

} // namespace base64

#endif // BASE64_ENCODE_H

