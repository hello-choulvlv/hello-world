// :mode=c++:
/*
decode.h - c++ wrapper for a base64 decoding algorithm

This is part of the libb64 project, and has been placed in the public domain.
For details, see http://sourceforge.net/projects/libb64
*/
#ifndef BASE64_DECODE_H
#define BASE64_DECODE_H

#ifndef BUFFERSIZE
#define BUFFERSIZE 1024
#endif

#include <iostream>

namespace base64
{
	extern "C"
	{
		#include "cdecode.h"
	}

	struct decoder
	{
		base64_decodestate _state;
		int _buffersize;

		decoder(int buffersize_in = BUFFERSIZE)
		: _buffersize(buffersize_in)
		{}

		int decode(char value_in)
		{
			return base64_decode_value(value_in);
		}

		int decode(const char* code_in, const int length_in, char* plaintext_out)
		{
			return base64_decode_block(code_in, length_in, plaintext_out, &_state);
		}
        
        int decode2(const char* code_in, const int length_in, unsigned char* plaintext_out){
            
            
            base64_decodestate state;
            base64_init_decodestate(&state);
            int r1 = base64_decode_block(code_in, length_in, (char*)plaintext_out, &state);
            return r1;
            /*
             
            base64_init_decodestate(&_state);
			//
			const int N = _buffersize;
			char* code = new char[N];
			char* plaintext = new char[N];
			int codelength;
			int plainlength;
            int start = 0;
            int plaintext_out_len = 0;
            while(start + N <=length_in){
                plainlength = decode(code_in+start,N,plaintext);
                // unsigned char * 不能用strncpy
                //strncpy((char*)plaintext_out+plaintext_out_len, plaintext,plainlength);
                memcpy(plaintext_out+plaintext_out_len, plaintext, plainlength);
                plaintext_out_len+= plainlength;
                start += N;
            }
            
            if(length_in - start>0){
                plainlength = decode(code_in+start,length_in-start,plaintext);
                // unsigned char * 不能用strncpy
                //strncpy((char*)plaintext_out+plaintext_out_len, plaintext,plainlength);
                memcpy(plaintext_out+plaintext_out_len, plaintext, plainlength);
                plaintext_out_len+= plainlength;
            }
            
            //base64_init_decodestate(&_state);
            
			delete [] code;
			delete [] plaintext;
            return plaintext_out_len;
             */
        }

		void decode(std::istream& istream_in, std::ostream& ostream_in)
		{
			base64_init_decodestate(&_state);
			//
			const int N = _buffersize;
			char* code = new char[N];
			char* plaintext = new char[N];
			int codelength;
			int plainlength;

			do
			{
				istream_in.read((char*)code, N);
				codelength = istream_in.gcount();
				plainlength = decode(code, codelength, plaintext);
				ostream_in.write((const char*)plaintext, plainlength);
			}
			while (istream_in.good() && codelength > 0);
			//
			base64_init_decodestate(&_state);

			delete [] code;
			delete [] plaintext;
		}
	};

} // namespace base64



#endif // BASE64_DECODE_H

