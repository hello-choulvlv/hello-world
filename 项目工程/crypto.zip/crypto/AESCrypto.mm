#include "PCAES.h"
#if USE_CRYPTO_LIB_ON_IOS == 1

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCryptor.h>

void AESDecrypt(const unsigned char* encryptedMessage,size_t encryptedMessageSize,
               const unsigned char* decryptKey,size_t decryptKeySize,
               unsigned char** buf,size_t* buf_size
               ){
    
    const void *iv,*encrypted_data;
    int encrypted_data_size;
    
    iv = encryptedMessage;
    encrypted_data = encryptedMessage+16;
    encrypted_data_size = encryptedMessageSize - 16;
    
    size_t numBytesEncrypted = 0;
    CCCryptorStatus result;
    
	size_t bufferSize = encryptedMessageSize + kCCBlockSizeAES128;
    
	void *buffer_decrypt = malloc(bufferSize);
    
    result = CCCrypt( kCCDecrypt , kCCAlgorithmAES128, 0,
                     decryptKey, decryptKeySize,
                     iv,
                     encrypted_data, encrypted_data_size,
                     buffer_decrypt, bufferSize,
                     &numBytesEncrypted );
    
    if( result == kCCSuccess )
    {
        int padding_length = ((unsigned char*)buffer_decrypt)[numBytesEncrypted-1];
        for (int i=1; i<=padding_length; i++) {
            ((unsigned char*)buffer_decrypt)[numBytesEncrypted - i] = '\0';
        }
        *buf = (unsigned char*)buffer_decrypt;
        *buf_size = numBytesEncrypted - padding_length;
    }else {
        *buf = NULL;
        *buf_size = 0;
        free(buffer_decrypt);
    }

    
}
#endif
