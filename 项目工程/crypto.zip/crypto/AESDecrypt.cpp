#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include "aes.h"
#include "PCAES.h"

#include "md5.h"


/*
#include "cocos2d.h"
//#include "CCCommon.h"

#if defined ( WIN32 ) || defined ( ANDROID )
#define hexdumpfunc cocos2d::CCLog
#else
#define hexdumpfunc printf
#endif
void hexdump(void *ptr, int buflen) {
    unsigned char *buf = (unsigned char*)ptr;
    int i, j;
    char line[1024];
    string linea = "";
    for (i=0; i<buflen; i+=16) {
        linea = "";
        sprintf(line, "%06x: ",i);
        linea += line;
        //hexdumpfunc("%06x: ", i);
        for (j=0; j<16; j++) 
            if (i+j < buflen){
                //hexdumpfunc("%02x ", buf[i+j]);
                sprintf(line, "%02x ", buf[i+j]);
                linea += line;
            }else{
                //hexdumpfunc("   ");
                linea += "   ";
            }
                
        //hexdumpfunc(" ");
        linea+= " ";
        for (j=0; j<16; j++) 
            if (i+j < buflen){
                //hexdumpfunc("%c", isprint(buf[i+j]) ? buf[i+j] : '.');
                sprintf(line,"%c", isprint(buf[i+j]) ? buf[i+j] : '.');
                linea += line;
            }

        //hexdumpfunc("\n");
        hexdumpfunc("%s",linea.c_str());
    }
}
*/
void hexdump(void *ptr, int buflen) {
    unsigned char *buf = (unsigned char*)ptr;
    int i, j;
    for (i=0; i<buflen; i+=16) {
        printf("%06x: ", i);
        for (j=0; j<16; j++) 
            if (i+j < buflen)
                printf("%02x ", buf[i+j]);
            else
                printf("   ");
        printf(" ");
        for (j=0; j<16; j++) 
            if (i+j < buflen)
                printf("%c", isprint(buf[i+j]) ? buf[i+j] : '.');
        printf("\n");
    }
}

void strxor(unsigned char *src, size_t size, const unsigned char* key, size_t key_size){
    int key_index=0;
    for(int i=0;i<size;i++){
        src[i] = src[i]^key[key_index];
        key_index ++;
        if(key_index==key_size) key_index=0;
    }
}


#if USE_CRYPTO_LIB_ON_IOS == 0

void AESDecrypt(const unsigned char* encryptedMessage,size_t encryptedMessageSize,
        const unsigned char* decryptKey,size_t decryptKeySize,
        unsigned char** buf,size_t* buf_size
        ){
    if(encryptedMessage==NULL || 
            encryptedMessageSize<=16 || 
            encryptedMessageSize%16!=0 ||
            decryptKey == NULL ||
            decryptKeySize != 32
      ){
        *buf = NULL;
        *buf_size = 0;
        return;
    }
    aes_init();
    aes_decrypt_ctx ctx[1];
    aes_decrypt_key256(decryptKey,ctx);

    unsigned char iv[16];
    memcpy(iv,encryptedMessage,16);

    const unsigned char *inBuffer;
    unsigned char *outBuffer;

    size_t bufferSize = encryptedMessageSize + AES_BLOCK_SIZE;

    unsigned char *buffer_decrypt = (unsigned char*)malloc(bufferSize);

    inBuffer = encryptedMessage + 16;
    outBuffer = buffer_decrypt;

    while(inBuffer < encryptedMessage + encryptedMessageSize){
        aes_cbc_decrypt(inBuffer, outBuffer, 16, iv, ctx);
        inBuffer = inBuffer + 16;
        outBuffer = outBuffer + 16;
    }

    int padding_length = *(outBuffer-1);
    if(padding_length<1 || padding_length>16){
        free(buffer_decrypt);
        *buf = NULL;
        *buf_size = 0;
        return;
    }
    int i;
    for (i=1; i<=padding_length; i++) {
        *(outBuffer-i) = '\0';
    }
    *buf = buffer_decrypt;
    *buf_size = outBuffer - buffer_decrypt - padding_length;
}

#endif

void AESEncrypt(const unsigned char* buf,size_t buf_size,
        const unsigned char* aeskey,size_t aeskey_size,
        const unsigned char* iv2,size_t iv_size,
        unsigned char** encrypted_buf,size_t* encrypted_buf_size
        ){
    int i,padding;
    aes_encrypt_ctx ctx[1];
    unsigned char iv[16]; /* initialisation vector */
    aes_init();
    memcpy(iv,iv2,16);

    aes_encrypt_key256(aeskey, ctx);
    const unsigned char *inBuffer = buf;
    /*
     * 头部有iv，尾部有padding，所以最多是 buf_size + 2 * AES_BLOCK_SIZE
     */
    unsigned char *buffer_encrypt = (unsigned char*)malloc(buf_size+AES_BLOCK_SIZE*2);
    memcpy(buffer_encrypt, iv, 16);
    unsigned char *outBuffer = buffer_encrypt + 16;
    *encrypted_buf_size = 16;


    for(i=0;i+16<=buf_size;i+=16){
        aes_cbc_encrypt(buf+i, outBuffer, 16, iv, ctx);
        outBuffer+=16;
        *encrypted_buf_size+=16;
    }
    unsigned char last_round_buf[16];
    padding = i + 16 - buf_size ;
    if(padding==16){
        memset(last_round_buf,padding,padding);
        aes_cbc_encrypt(last_round_buf,outBuffer,16,iv,ctx);
        *encrypted_buf_size+=16;
    }else{
        memcpy(last_round_buf,buf+i,16 - padding);
        memset(last_round_buf+16-padding,padding,padding);
        aes_cbc_encrypt(last_round_buf,outBuffer,16,iv,ctx);
        *encrypted_buf_size+=16;
    }
    *encrypted_buf = buffer_encrypt;
}

void AESEncrypt(const unsigned char* buf,size_t buf_size,
                const unsigned char* aeskey,size_t aeskey_size,
                unsigned char** encrypted_buf,size_t* encrypted_buf_size
                ){
    int i;
    unsigned char iv[16]; /* initialisation vector */
    
    
    unsigned char mbuffer[1024];
    MD5 m;
    for(i=0;i+1024<=buf_size;i+=1024){
        memcpy(mbuffer, buf+i, 1024);
        m.update(mbuffer, 1024);
    }
    if(i<buf_size){
        memcpy(mbuffer, buf+i, buf_size-i);
        m.update(mbuffer, buf_size-i);
    }
    m.finalize();
    unsigned char* digest = m.raw_digest();
    memcpy(iv, digest, 16);
    delete digest;
    AESEncrypt(buf, buf_size, aeskey, aeskey_size, iv, 16,encrypted_buf,encrypted_buf_size);
}

/*
 compr 的前4个字节用来存放压缩前内容的实际大小
 */
void zip_uncompress(Bytef *compr, uLongf comprLen,Bytef **buf,uLongf *bufSize)
{
    Bytef *uncompr;
    uLongf uncomprLen;
    if(comprLen==0 || compr == NULL){
        *buf = NULL;
        *bufSize = 0;
        return;
    }
    /* 获取压缩文件的内容大小 */
    comprLen = comprLen-4;
    uncomprLen = 1+*(int *)(compr+comprLen);
    /* 申请解压缩缓冲区 */
    uncompr = (Bytef*)malloc(sizeof(Bytef) * uncomprLen);
    int result = uncompress(uncompr, &uncomprLen, compr, comprLen);
    uncompr[uncomprLen] = '\0';
    *buf = uncompr;
    *bufSize = uncomprLen;
}


/*
void readDataFromFile(const char* filename,unsigned char** buffer, unsigned long* buffer_size){
    FILE *fp = fopen(filename, "rb");
    fseek(fp,0,SEEK_END);
    *buffer_size = ftell(fp);
    fseek(fp,0,SEEK_SET);
    *buffer = (unsigned char*)malloc(*buffer_size);
    fread(*buffer,sizeof(unsigned char), *buffer_size,fp);
    fclose(fp);
}
int main() {
    const unsigned char key[] = "19920214198502071992021419850207";
    const unsigned char iv[] = "1234567890123456";

    srand(time(NULL));

    //aes_init();

    unsigned long size;
    unsigned char* pData;
    //readDataFromFile("encrypted",&pData,&size);
    readDataFromFile("txt",&pData,&size);
    printf("txt size: %lu\ntxt content:\n%s\n",size,pData);

    unsigned char* encrypted_buf;
    unsigned long encrypted_buf_size;
    AESEncrypt(pData,size,key,32,iv,16,&encrypted_buf,&encrypted_buf_size);
    printf("encrypted_buf_size: %lu\n",encrypted_buf_size);
    //printf("encrypted_buf\n%s\n",encrypted_buf);
    //return 0;

    unsigned char* decryptedData;
    unsigned long decryptedSize;
    AESDecrypt(encrypted_buf ,encrypted_buf_size, key, 32,&decryptedData,&decryptedSize);
    printf("decrypt size: %lu\n",decryptedSize);
    printf("decrypt content:\n%s\n",(char*)decryptedData);
    free(pData);
    return 0;
}
*/
