
#ifndef _PCAES_H
#define _PCAES_H

#if defined ( WIN32 ) || defined ( ANDROID )
#define USE_CRYPTO_LIB_ON_IOS 0
#endif

#if defined ( TARGET_OS_IPHONE )
#define USE_CRYPTO_LIB_ON_IOS 0
#endif

#include "zlib.h"

void AESDecrypt(const unsigned char* encrypted_buf,size_t encrypted_buf_size,
               const unsigned char* aeskey,size_t aeskey_size,
               unsigned char** buf,size_t* buf_size
               );

void AESEncrypt(const unsigned char* buf,size_t buf_size,
               const unsigned char* aeskey,size_t aeskey_size,
               unsigned char** encrypted_buf,size_t* encrypted_buf_size
               );
void AESEncrypt(const unsigned char* buf,size_t buf_size,
                const unsigned char* aeskey,size_t aeskey_size,
                const unsigned char* iv2,size_t iv_size,
                unsigned char** encrypted_buf,size_t* encrypted_buf_size
                );
void hexdump(void *ptr, int buflen) ;

void strxor(unsigned char *src, size_t size, const unsigned char* key, size_t key_size);


void zip_uncompress(Bytef *compr, uLongf comprLen,Bytef **buf,uLongf *bufSize);
#endif
