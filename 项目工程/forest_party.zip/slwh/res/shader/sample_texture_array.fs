#ifdef GL_ES
varying mediump vec2 TextureCoordOut;
varying float  v_textureIndex;
#else
varying vec2 TextureCoordOut;
varying float  v_textureIndex;
#endif
uniform sampler2DArray CV_Texture2DArray;
uniform int       CSVK_TextureIndexArray[32];
uniform vec4 u_color;

void main(void)
{
	int  texture_index = int(v_textureIndex);
	texture_index = CSVK_TextureIndexArray[texture_index];
    gl_FragColor = texture2DArray(CV_Texture2DArray, vec3(TextureCoordOut,float(texture_index))) * u_color;
}
