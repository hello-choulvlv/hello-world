layout(location=0)out	vec4	outColor;

uniform sampler2DArray  CV_Texture2DArray;
uniform vec4 	  		u_color;

in vec2 TextureCoordOut;
flat in int v_textureIndex;

void main(void)
{
    outColor = texture(CV_Texture2DArray, vec3(TextureCoordOut,float(v_textureIndex))) * u_color;
}