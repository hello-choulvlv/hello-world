#ifdef GL_ES
varying mediump vec2 TextureCoordOut;
varying float  v_textureIndex;
#else
varying vec2 TextureCoordOut;
varying float  v_textureIndex;
#endif
uniform sampler2D CSVK_TextureArray[6];
uniform int       CSVK_TextureIndexArray[24];
uniform vec4 u_color;

void main(void)
{
	int  texture_index = int(v_textureIndex);
	texture_index = CSVK_TextureIndexArray[texture_index];
    gl_FragColor = texture2D(CSVK_TextureArray[texture_index], TextureCoordOut) * u_color;
}
