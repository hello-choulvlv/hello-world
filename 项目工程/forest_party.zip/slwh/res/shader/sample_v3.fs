layout(location=0)out	vec4	outColor;
#ifdef GL_ES
in highp vec2 TextureCoordOut;
#else
in vec2 TextureCoordOut;
#endif
uniform vec4 u_color;

void main(void)
{
    outColor = texture(CC_Texture0, TextureCoordOut) * u_color;
}