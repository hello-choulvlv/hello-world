//#extension GL_EXT_gpu_shader5 : enable

layout(location=0)out	vec4	outColor;
#ifdef GL_ES
in mediump vec2 TextureCoordOut;
#else
in vec2 TextureCoordOut;
#endif

flat in int v_textureIndex;

uniform sampler2D CSVK_TextureArray[6];
uniform int       CSVK_TextureIndexArray[24];
uniform vec4 	  u_color;

void main(void)
{
	int texture_index = v_textureIndex;
	texture_index = CSVK_TextureIndexArray[texture_index];
    outColor = texture(CSVK_TextureArray[texture_index], TextureCoordOut) * u_color;
}
