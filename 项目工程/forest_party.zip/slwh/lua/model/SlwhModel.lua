--森林舞会场景入口数据模型
--2018年5月8日
--@author:xiaoxiong
SlwhModel = class("SlwhModel")

function SlwhModel:ctor()
    ClassUtil.extends(self, BaseGameModel, true, GameKind_SLWH,nil,nil,false,true);
    --设置数据模型
    createSetterGetter(self,"isShowingConfirm",false,true)
    createSetterGetter(self,"isShowingExit",false,true)
    createSetterGetter(self,"isShowingJetton",false,true)
    createSetterGetter(self,"isShowingRewardNormal",false,true)
    --玩家当前的状态
    createSetterGetter(self,"userGameStatus",0,false)
    --可下注的筹码
    createSetterGetter(self,"cellScoreArray",{},false)
    --各个区域的玩家下注总额
    createSetterGetter(self,"areaUserBetArray",{},false)
    --各个区域的所有玩家下注总额
    createSetterGetter(self,"areaTotalBetArray",{},false)
    --下注区域的倍数
    createSetterGetter(self,"areaBetMultiplyArray",{},false)
    --玩家获得的奖励
    createSetterGetter(self,"userReward",{},false)
    --玩家获奖记录
    createSetterGetter(self,"historyRewards",{},false)
    createSetterGetter(self,"gameRewardData",{},false)
    --剩余时间
    createSetterGetter(self,"remindTime",0,false)
    --当前玩家自己的总的下注分数
    createSetterGetter(self,"userTotalJetton",0,true)
    --所有玩家当前的下注金额
    createSetterGetter(self,"allUserBetNumber",0,true)
    --玩家本局获得的分数
    createSetterGetter(self,"userSessionScore",0,false)
    --玩家在开奖阶段的真实分数
    createSetterGetter(self,"userRealyScore",0,false)
    --玩家本局获得的彩金
    createSetterGetter(self,"userSessionCaiJin",0,false)
    --上一局各个区域的玩家下注顺序
    createSetterGetter(self,"preAreaUserBetOrder",{},false)
    createSetterGetter(self,"curAreaUserBetOrder",{},false)
    createSetterGetter(self,"curSelectdGold",0,false)
    createSetterGetter(self,"canJettonContinue",false,false)
    if( false == SLWH_AFTER_WITHDRAWAL_CAN_BET ) then 
        createSetterGetter( self, "selfBetStartMoney", 0, false ) 
        createSetterGetter( self, "selfBetStartMoneyTemp", 0, false ) 
    end
    --是否自动续押
    createSetterGetter(self,"isAutoJetton",false)
    --是否已经续押完毕
    createSetterGetter(self,"isJettonContinue",false)
    --记录刚开始开局的时候,玩家的金钱数目
    createSetterGetter(self,"userScoreOnStrat",0)
    --本次获奖内容
    --createSetterGetter(self,"user")
    self.musicBg = Tree.Sound.roomBgSound
    self.useCustomizedLogoAnimation = true;
    self.spineLogoKeyInLoading = "slwh_loading"
    self.spineLogoKeyInLoading2 = "slwh_loadinggx"
    self.logoAnimationConfig = {"start", "idle"}

    self.onlineItemPath = "module/slwh/csb/common/SlwhOnlineThreeItem.csb"
    self.onlineItemScoreNumRes = "#slwh_jetton_player_gold_%s.png"
    self.onlineDataCount = 3 

    self._loadingDuration = 4

    self.noticeIconOffset = cc.p(20,0)
    self.bankInputOldPosition = {[1]=cc.p(9.77,4.94),[2]=cc.p(367.97,236.21),[3]=cc.p(668.58,237.14),[4]=cc.p(0,-43.60),[5]=cc.p(6.55,88.00)}
    self.bankInputNewPosition = {[1]=cc.p(9.77,44.94),[2]=cc.p(367.97,276.21),[3]=cc.p(668.58,277.14),[4]=cc.p(0,-3.60)}

    self.bankTitleImg = {
        [1] = Tree.root .. "bank/slwh_bank_title.png",
        [2] = Tree.root .. "bank/slwh_bank_title2.png"
    }

    self.bankHld1 = {
        [1] = Tree.root .. "bank/slwh_bank_money.png",
        [2] = Tree.root .. "bank/slwh_bank_money2.png"
    }

    self.menuSprQk = {
        [1] = Tree.root .. "menu/meny_icon.png",
        [2] = Tree.root .. "menu/meny_icon2.png"
    }
end

function SlwhModel:isMeBet()
    local lUserJettonScore = self:getAreaUserBetArray()
  
    if lUserJettonScore then
        for i,v in pairs(lUserJettonScore) do
            if v > 0 then
                return true
            end
        end
    end
    return false
end

function SlwhModel:destroy()
    BaseGameModel.destroy(self)
end