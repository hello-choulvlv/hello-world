--连环夺宝缓存管理器
--2018年5月16日
--@author:xiaoxiong
TreeCacheManager = class("TreeCacheManager")

function TreeCacheManager:init()
    --所有的键值的起始索引
    self._keyIndex = 1
    self._objectType = {
        --C++对象类型映射表
        [Tree.CacheType.CacheType_Spine] = Tree.ObjectType.ObjectType_Cocos2dx,
        [Tree.CacheType.CacheType_Particle] = Tree.ObjectType.ObjectType_Cocos2dx,
        [Tree.CacheType.CacheType_Sprite] = Tree.ObjectType.ObjectType_Cocos2dx,
        [Tree.CacheType.CacheType_SpriteFrame] = Tree.ObjectType.ObjectType_Cocos2dx,
        --lua对象类型映射表
        [Tree.CacheType.CacheType_RollingText] = Tree.ObjectType.ObjectType_Lua,
    }
    --3d模型的动画缓存
    self._animation3DCache = {}
end

function TreeCacheManager:registerCocos2dxObject(object_array)
    self._cocos2dxObject = {}
    for key,object_map in pairs(object_array) do
        self._cocos2dxObject[key] = object_map
        self._cocos2dxObject[key] ._inuseObject = {}
        self._cocos2dxObject[key] ._freeObject = {}
        self._cocos2dxObject[key]._base_key = key
        self._cocos2dxObject[key]._base_index = 1
        
        self._keyIndex = self._keyIndex + 1
    end
end
--加载动画模型
function TreeCacheManager:putAnimation3D(animation,key)
    animation:retain()
    self._animation3DCache[key] = animation
end
--get animation
function TreeCacheManager:getAnimation3D(key)
    return self._animation3DCache[key]
end
--get
--从缓存中获取对象
function TreeCacheManager:getCacheObject(object_key,...)
    local cache_info = self._cocos2dxObject[object_key]
    if not cache_info then
        print("object key ",object_key ," do not exitst.")
        return nil
    end
    local object
    --检测是否有空闲的对象
    if #cache_info._freeObject > 0 then
        object = table.remove(cache_info._freeObject)
        --需要重置对象的状态
        if cache_info.type == Tree.CacheType.CacheType_Particle then
            object:resetSystem()
        end
        cache_info._inuseObject[object.__base_index] = object
    else
        if cache_info.type == Tree.CacheType.CacheType_Spine then
            if sp.SkeletonAnimation.isExistSkeletonDataInCache and not cache_info.isRead then
                local cccc_map = cache_info
                sp.SkeletonAnimation:readSkeletonDataToCacheByJson(cache_info.cache,cache_info.json,cache_info.atlas)
                cccc_map.isRead = true
            end
            if sp.SkeletonAnimation.createFromCache then
                object = sp.SkeletonAnimation:createFromCache(cache_info.cache)
            else
                object = sp.SkeletonAnimation:create(cache_info.json,cache_info.atlas)
            end
        elseif cache_info.type == Tree.CacheType.CacheType_Particle then
            object = cc.ParticleSystemQuad:create(cache_info.particle)
            object:setScale(cache_info.scale)
        elseif cache_info.type == Tree.CacheType.CacheType_Sprite then
            object = cc.Sprite:create(cache_info.path)
        elseif cache_info.type == Tree.CacheType.CacheType_SpriteFrame then
            object = cc.Sprite:createWithSpriteFrameName(cache_info.frame_name)
        elseif cache_info.type == Tree.CacheType.CacheType_RollingText then--滚动数字
            object = require(cache_info.class).new(...)
            object:init()
        end
        object.__key = cache_info._base_key
        object.__base_index = cache_info._base_index
        cache_info._base_index = cache_info._base_index + 1
        object:retain()
        --加入到缓存中
        cache_info._inuseObject[object.__base_index] = object
    end
    return object
end
--回收一个对象
function TreeCacheManager:recycleCocos2dxObject(object)
    local cache_info = self._cocos2dxObject[object.__key]
    if not cache_info then
        print("could not recycle object,key-->",object.__key)
        return
    end
    --检测是否在使用中
    if not cache_info._inuseObject[object.__base_index] then
        print("could not recycle uninuse object",object.__key)
        return
    end
    object:removeFromParent()
    --object:stopAllActions()
    cache_info._inuseObject[object.__base_index] = nil
    --检测是否超过了最大缓存数目
    if #cache_info._freeObject >= cache_info.max_count then
        object:release()
    else
        table.insert(cache_info._freeObject,object)
    end
end
--退出场景时调用
function TreeCacheManager:onExit()
    --回收所有的资源
    for key,cache_info in pairs(self._cocos2dxObject) do
        --print("---recycle-->",cache_info._base_key)
        for baseIndex , object in pairs(cache_info._inuseObject) do
            self:recycleCocos2dxObject(object)
        end
    end
end
--离开游戏时调用
function TreeCacheManager:onDestroy()
    for key,cache_info in pairs(self._cocos2dxObject) do
        --print("---destroy-->",cache_info._base_key)
        --正在使用中的对象
        for baseIndex , object in pairs(cache_info._inuseObject) do
            cache_info._inuseObject[baseIndex] = nil
            object:removeFromParent()
            object:release()
        end
        --空闲的对象
        for index= 1,#cache_info._freeObject do
            cache_info._freeObject[index]:release()
        end
        cache_info._freeObject = {}
        cache_info.isRead = nil
    end
    --release animation
    for key,animation in pairs(self._animation3DCache) do
        animation:release()
    end
    self._animation3DCache = {}
end
