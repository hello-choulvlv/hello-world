--森林舞会入口模块
--2018年11月23日
--@author:xiaoxiong
local SlwhModule = class("SlwhModule")
requireLuaFromModule("slwh.TreeConstant")
requireLuaFromModule("slwh.model.SlwhModel")
requireLuaFromModule("slwh.controller.SlwhController")
requireLuaFromModule("slwh.view.SlwhView")

function SlwhModule:ctor()
    ClassUtil.extends(self,BaseGameModule,true)
    self.model = SlwhModel.new()
    self.controller = SlwhController.new(self.model)
    self.view = SlwhView.new(self.model,self.controller)
end

function SlwhModule:show(onSwitchComplete, onSwitchMiddle, switchDelay, middleDelay, isEnterBattle)
    BaseGameModule.show(self, onSwitchComplete, onSwitchMiddle, switchDelay, middleDelay, isEnterBattle)
end

ProxySlwh = SlwhModule.new()

return ProxySlwh