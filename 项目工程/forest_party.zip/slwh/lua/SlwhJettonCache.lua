--下注面板缓存管理器
--之所以不使用自带的缓存管理,是因为随着游戏的退出,而不能一起发动从父节点删除
--2019年3月15日
--@author:xiaoxiong
SlwhJettonCache = SlwhJettonCache or {}

function SlwhJettonCache:init()
    --带缓存的对象
    self._cacheObjects = {}
    self._keyIndex = 1
end

function SlwhJettonCache:registerCacheMap(cache_list)
    for key_name,cache_info in pairs(cache_list)do
        self._cacheObjects[key_name] = cache_info
        self._cacheObjects[key_name] ._inuseObject = {}
        self._cacheObjects[key_name] ._freeObject = {}
        self._cacheObjects[key_name]._base_key = key_name
        self._cacheObjects[key_name]._base_index = 1
        
        self._keyIndex = self._keyIndex + 1
    end
end
--从缓存中获取对象
function SlwhJettonCache:getCacheObject(object_key)
    local cache_info = self._cacheObjects[object_key]
    if not cache_info then
        print("jetton object key ",object_key ," do not exitst.")
        return nil
    end
    local object
    --检测是否有空闲的对象
    if #cache_info._freeObject > 0 then
        object = table.remove(cache_info._freeObject)
        cache_info._inuseObject[object.__base_index] = object
    else
        object = cc.Sprite:createWithSpriteFrameName(cache_info.frame_name)
        object.__key = cache_info._base_key
        object.__base_index = cache_info._base_index
        cache_info._base_index = cache_info._base_index + 1
        object:retain()
        --加入到缓存中
        cache_info._inuseObject[object.__base_index] = object
    end
    return object
end
--回收对象
function SlwhJettonCache:recycleObject(object)
    local cache_info = self._cacheObjects[object.__key]
    if not cache_info then
        print("could not recycle jetton object,key-->",object.__key)
        return
    end
    --检测是否在使用中
    if not cache_info._inuseObject[object.__base_index] then
        print("could not recycle uninuse jetton object",object.__key)
        return
    end
    object:removeFromParent()
    --object:stopAllActions()
    cache_info._inuseObject[object.__base_index] = nil
    --检测是否超过了最大缓存数目
    if #cache_info._freeObject >= cache_info.max_count then
        object:release()
    else
        table.insert(cache_info._freeObject,object)
    end
end
--从一个节点中提取出所有的缓存对象
function SlwhJettonCache:sampleCacheObject(parent_object)
    local children = parent_object:getChildren()
    for index_j = 1,#children do
        child = children[index_j]
        self:recycleObject(child)
    end
end
--退出场景时调用
function SlwhJettonCache:onExit()
    --回收所有的资源
    for key,cache_info in pairs(self._cacheObjects) do
        for baseIndex , object in pairs(cache_info._inuseObject) do
            self:recycleObject(object)
        end
    end
end
--销毁
function SlwhJettonCache:onDestroy()
    for key,cache_info in pairs(self._cacheObjects) do
        --正在使用中的对象
        for baseIndex , object in pairs(cache_info._inuseObject) do
            cache_info._inuseObject[baseIndex] = nil
            object:release()
        end
        --空闲的对象
        for index= 1,#cache_info._freeObject do
            cache_info._freeObject[index]:release()
        end
        cache_info._freeObject = {}
    end
end
--使用了TreeFunc类中的一部分函数,但是对缓存内容做了一些修改
function SlwhJettonCache:createSpriteNumber(num,texture_template,dimension_map,anchor_point,root_node)
    local anchor_point2 = anchor_point or {x=0,y = 0.5}
    local parent_node = root_node or cc.Node:create()
    --判断是否使用cc.Sprite:createWithSpriteFrameName函数
    local width = 0
    local height = 0
    local sprites = {}
    while true do
        local digit = num%10
        local texture_path = string.format(texture_template,tostring(digit))
        local sprite = self:getCacheObject(texture_path)
        local size = sprite:getContentSize()
        width = width + size.width
        height = size.height
        table.insert(sprites,1,sprite)

        num = math.floor(num/10)
        if num <= 0  then
            break
        end
    end

    local offset_x = -width * anchor_point2.x
    local offset_y = -height * (anchor_point2.y - 0.5)
    for idx = 1,#sprites do
        local size = sprites[idx]:getContentSize()
        sprites[idx]:setPosition(offset_x + size.width*0.5,offset_y)
        parent_node:addChild(sprites[idx])

        offset_x = offset_x + size.width
    end
    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height = height
    end
 
    return parent_node
end
--带有逗号
function SlwhJettonCache:createSpriteNumberWithDot(num,texture_template,dimension_map,anchor_point,root_node)
    local anchor_point2 = anchor_point or {x = 0,y = 0.5}
    local parent_node = root_node or cc.Node:create()
    local sprites = {}
    local width = 0
    local height = 0
    local num_c = 0

    while true do
        local num_t = num%10
        local texture_path = string.format(texture_template,tostring(num_t))
        local sprite = self:getCacheObject(texture_path)
        local size = sprite:getContentSize()
        width = width + size.width
        height = size.height
        num_c = num_c + 1
        table.insert(sprites,1,sprite)

        num = math.floor(num/10)
        if num <= 0 then
            break
        end
        --检查是否是3的倍数
        if num_c %3 == 0 then
            texture_path = string.format(texture_template,"d")
            sprite = self:getCacheObject(texture_path)
            size = sprite:getContentSize()
            width = width + size.width
            table.insert(sprites,1,sprite)
        end
    end
    local offset_x = -width * anchor_point2.x
    local offset_y =  -height * (anchor_point2.y - 0.5)

    for index = 1,#sprites do
        local sprite = sprites[index]
        local size = sprite:getContentSize()
        sprite:setPosition(offset_x + size.width*0.5,offset_y)
        parent_node:addChild(sprite)
        offset_x = offset_x + size.width
    end
    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height= height
    end
    return parent_node
end
--如果分数大于等于1亿,则最多只显示亿后面的有效位数2位,否则跟createSpriteNumberWithDot函数没有什么区别
function SlwhJettonCache:createSpriteNumberWith1Y(num,texture_template,dimension_map,anchor_point,root_node)
    local anchor_point2 = anchor_point or {x=0,y=0.5}
    local parent_node = root_node or cc.Node:create()
    local num_table = {}
    --记录,是否数字大于1y
    local greater_than_1y = false
    local num_f = num + 0.5
    if num >=  100000000 then--1y
        local num_y = math.floor(num_f/100000000)
        TreeFunc.splitNumber(num_y,num_table)
        num = num%100000000
        greater_than_1y = true
    end
    --如果大于1亿的话,剩余的数字只需查看最多两位即可
    if greater_than_1y then
        num_f = num + 0.5
        if num >= 1000000 then--100w
            table.insert(num_table,"f")--小数点
            local num_w = math.floor(num_f/1000000)
            TreeFunc.splitNumber(num_w,num_table)
            num = 0--num%1000000
        end
        table.insert(num_table,"y")
    else
        TreeFunc.splitNumber(num,num_table)
    end
    --
    local sprites = {}
    local width = 0
    local height = 0
    local num_cd = 0

    for idx=#num_table,1,-1 do--从低位到高位
        local num_c = num_table[idx]
        local texture_path = string.format(texture_template,tostring(num_c))
        local sprite = self:getCacheObject(texture_path)
        local size = sprite:getContentSize()
        --sprite:setPosition(offset_x + size.width*0.5,0)
        table.insert(sprites,1,sprite)
        parent_node:addChild(sprite)

        width = width + size.width
        height = size.height
        num_cd = num_cd + 1
        --检查是否是3的倍数
--        if not greater_than_1y and idx ~= 1 and num_cd %3 == 0 then
--            texture_path = string.format(texture_template,"d")
--            sprite = self:getCacheObject(texture_path)
--            parent_node:addChild(sprite)
--            size = sprite:getContentSize()
--            width = width + size.width
--            table.insert(sprites,1,sprite)
--        end
    end
    --调整位置
    local offset_x = -anchor_point2.x * width
    local offset_y = - (anchor_point2.y-0.5) * height
    for index = 1,#sprites do
        local sprite = sprites[index]
        local size = sprite:getContentSize()
        sprite:setPosition(offset_x + size.width * 0.5,offset_y)

        offset_x = offset_x + size.width
    end

    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height = height
    end

    return parent_node
end
--
--如果分数大于等于1亿,或者大于等于1w,则最多只显示后面的有效位数2位,否则跟createSpriteNumberWithDot函数没有什么区别
function SlwhJettonCache:createSpriteNumberWith1WY(num,texture_template,dimension_map,anchor_point,root_node)
    local anchor_point2 = anchor_point or {x=0,y=0.5}
    local parent_node = root_node or cc.Node:create()
    local num_table = {}
    --记录,是否数字大于1y
    local greater_than_1y = false
    local greater_than_1w = false
    if num >=  100000000 then--1y
        local num_y = math.floor(num/100000000)
        TreeFunc.splitNumber(num_y,num_table)
        num = num%100000000
        greater_than_1y = true
    elseif num >= 10000 then
        local num_y = math.floor(num/10000)
        TreeFunc.splitNumber(num_y,num_table)
        num = num%10000
        greater_than_1w = true
    end
    --如果大于1亿的话,剩余的数字只需查看最多两位即可
    if greater_than_1y then
        if num >= 1000000 then--100w
            table.insert(num_table,"f")--小数点
            local num_w = math.floor(num/1000000)
            TreeFunc.splitNumber(num_w,num_table)
            num = 0--num%1000000
        end
        table.insert(num_table,"y")
    elseif greater_than_1w then
        if num >= 100 then--100
            table.insert(num_table,"f")--小数点
            local num_w = math.floor(num/100)
            TreeFunc.splitNumber(num_w,num_table)
            num = 0--num%1000000
        end
        table.insert(num_table,"w")
    else
        TreeFunc.splitNumber(num,num_table)
    end
    --
    local sprites = {}
    local width = 0
    local height = 0
    local num_cd = 0

    local should_use_dot = not greater_than_1w and not greater_than_1y

    for idx=#num_table,1,-1 do--从低位到高位
        local num_c = num_table[idx]
        local texture_path = string.format(texture_template,tostring(num_c))
        local sprite = self:getCacheObject(texture_path)
        local size = sprite:getContentSize()
        --sprite:setPosition(offset_x + size.width*0.5,0)
        table.insert(sprites,1,sprite)
        parent_node:addChild(sprite)

        width = width + size.width
        height = size.height
        num_cd = num_cd + 1
        --检查是否是3的倍数
        if should_use_dot and idx ~= 1 and num_cd %3 == 0 then
            texture_path = string.format(texture_template,"d")
            sprite = self:getCacheObject(texture_path)
            parent_node:addChild(sprite)
            size = sprite:getContentSize()
            width = width + size.width
            table.insert(sprites,1,sprite)
        end
    end
    --调整位置
    local offset_x = -anchor_point2.x * width
    local offset_y = - (anchor_point2.y-0.5) * height
    for index = 1,#sprites do
        local sprite = sprites[index]
        local size = sprite:getContentSize()
        sprite:setPosition(offset_x + size.width * 0.5,offset_y)

        offset_x = offset_x + size.width
    end

    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height = height
    end

    return parent_node
end