--森林舞会所有luaAction管理类
--2018年11月30日
--xiaoxiong
TreeActionManager = class("TreeActionManager")

function TreeActionManager:ctor()
    self._actions = {}
    self._objectMaps = {}--对象到动作的映射表
    --动作的分配索引
    self._baseActionIndex = 1
    --当前帧的时间
    self._lastTime = 0
end
--初始化
function TreeActionManager:start()
    self._actions = {}
    self._objectMaps = {}
    self._lastTime = TimeApi:getTime()
end

function TreeActionManager:addAction(object,action)
    assert(not action:isInQueue(),"TreeAction could not entry secondary.")

    table.insert(self._actions,action)
    if not self._objectMaps[object] then
        self._objectMaps[object] = {}
    end
    action:startWithTarget(object)
    table.insert(self._objectMaps[object],action)

    action:setInQueue(true)
end
--返回某一个对象的所有动作
function TreeActionManager:getTargetAction(object)
    return self._objectMaps[action]
end
--逐个遍历回调
function TreeActionManager:visit()
    local now_time = TimeApi:getTime()
    local delta_time = (now_time - self._lastTime) / 1000
    local idx = 1

    while idx <= #self._actions do
        --now_time = TimeApi:getTime()
        local action = self._actions[idx]
        --delta_time = (now_time - self._lastTime)/1000

        if not action:isRemoved() and not action:finish() then
            action:step(delta_time)
        end

        if action:finish() or action:isRemoved() then
            table.remove(self._actions,idx)
            self:removeActionFromObjectMap(action)
            action:setInQueue(false)
        else
            idx = idx + 1
        end
    end
    self._lastTime = now_time
end
--删除某一个对象的所有动作
function TreeActionManager:removeTargetAction(object)
    local target_map = self._objectMaps[object]
    if target_map then
        for idx,action in pairs(target_map)do
            action:setRemoved(true)
        end
        self._objectMaps[object] = nil
    end
end
--删除某一个动作
function TreeActionManager:removeAction(action)
    action:setRemoved(true)
end
--
function TreeActionManager:removeActionFromObjectMap(action)
    local object_map = self._objectMaps[action._target]
    if object_map then
        for idx = 1,#object_map do
            if object_map[idx] == action then
                table.remove(object_map,idx)
                break
            end
        end
        if #object_map <= 0 then
            self._objectMaps[action._target] = nil
        end
    end
end
--清理所有的队列,包括对象映射表
function TreeActionManager:clear()
    self._actions = {}
    self._objectMaps = {}
end