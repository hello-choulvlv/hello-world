--森林舞会,所有的自定义动作类实现
--2018年11月30日
--@author:xiaoxiong
TreeAction = class("TreeAction")
--TreeAction对象所有的函数都不可重入
function TreeAction:ctor(duration,action_type)
    --self._target = target
    self._duration = duration
    self._actionType = action_type
    --从action添加到队列开始的时间戳
    self._timeline = 0
    --本对象是否需要被删除
    self._removed = false
    --是否在队列中
    self._inQueue = false
    assert(duration > 0,"duration could not less than 0.")
end
--添加到队列
function TreeAction:startWithTarget(object)
    self._timeline = 0
    self._target = object
end
--type
function TreeAction:getType()
    return self._actionType
end
--设置删除标记
function TreeAction:setRemoved(b)
    self._removed = b
end

--设置在队列中
function TreeAction:setInQueue(b)
    self._inQueue = b
end

function TreeAction:isInQueue()
    return self._inQueue
end

function TreeAction:isRemoved()
    return self._removed
end
--传入从上一次调用到现在开始,经过了多少毫秒
function TreeAction:step(delay_time)
    self._timeline = self._timeline + delay_time
    local rate = math.min(self._timeline/self._duration,1)
    self:update(rate)
end
--动作是否结束了
function TreeAction:finish()
    return self._timeline >= self._duration
end

function TreeAction:update(time_rate)
    
end
--此函数暂时没有使用
function TreeAction:destroy()

end
--3d路径------------------------
TreeMoveBy3D = class("TreeMoveBy")
function TreeMoveBy3D:ctor(duration,target_position)
    ClassUtil.extends(self, TreeAction,true,duration,Tree.ActionType.ActionType_MoveBy)
    --TreeAction.ctor(self,duration)
    self._targetPosition = target_position
end

function TreeMoveBy3D:startWithTarget(object)
    TreeAction.startWithTarget(self,object)
    self._originPosition = object:getPosition3D()

    self._delta_x  = self._targetPosition.x - self._originPosition.x
    self._delta_y  = self._targetPosition.y - self._originPosition.y2
    self._delta_z = self._targetPosition.z - self._originPosition.z
end

function TreeMoveBy3D:update(time_rate)
    local x = self._originPosition.x + self._delta_x * time_rate
    local y = self._originPosition.y + self._delta_y * time_rate
    local z = self._originPosition.z + self._delta_z * time_rate

    self._target:setPosition3D({x = x,y = y,z = z})
end
----------------3d弹跳类---------------------------
--与cocos2dx自带的2d弹跳不同,此弹跳过程会增加间歇等待时间
TreeJump3DBy = class("TreeJump3DBy")

function TreeJump3DBy:ctor(duration,target_position,height,jump_times)
    ClassUtil.extends(self, TreeAction,true,duration,Tree.ActionType.ActionType_Jump)
    --TreeAction.ctor(self,duration)
    self._targetPosition = target_position
    self._height = height
    self._jumpTimes = jump_times or 1
end

function TreeJump3DBy:startWithTarget(object)
    TreeAction.startWithTarget(self,object)
    self._originPosition = object:getPosition3D()

    self._vec_x = self._targetPosition.x - self._originPosition.x
    self._vec_y = self._targetPosition.y - self._originPosition.y
    self._vec_z = self._targetPosition.z - self._originPosition.z

    self._delay_time = 0
end

function TreeJump3DBy:step(delay_time)
    self._timeline = self._timeline + delay_time
    local rate = math.min(self._timeline/self._duration,1)
    self:update(rate)
end

function TreeJump3DBy:update(time_rate)
    local frac = math.fmod( time_rate * self._jumpTimes, 1.0);
    local s = 4 * frac * (1 - frac)

    local  y = self._height * s;
    y = y + self._vec_y * time_rate + self._originPosition.y;

    local x = self._vec_x * time_rate + self._originPosition.x
    local z = self._vec_z * time_rate + self._originPosition.z

    self._target:setPosition3D({x = x,y = y,z = z})
end
-----------------回掉函数-------------------
TreeCallFunc = class("TreeCallFunc")
function TreeCallFunc:ctor(callback_func,param)
    ClassUtil.extends(self, TreeAction,true,1,Tree.ActionType.ActionType_Callback)
    --TreeAction.ctor(self,1)
    self._callFunc = callback_func
    self._param = param
end

function TreeCallFunc:update(time_rate)
    self._callFunc(self._param)
end
--
function TreeCallFunc:finish()
    return true
end
-------------------延时动作----------------------
TreeDelayTime = class("TreeDelayTime")

function TreeDelayTime:ctor(duration)
    ClassUtil.extends(self, TreeAction,true,duration,Tree.ActionType.ActionType_DelayTime)
end
-----------------------连续动作---------------
TreeSequence = class("TreeSequence")

function TreeSequence:ctor(table_action)
    ClassUtil.extends(self, TreeAction,true,100,Tree.ActionType.ActionType_Sequence)
    self._tableAction = table_action
    assert(#table_action > 0,"table action could not be empty.")
end

function TreeSequence:startWithTarget(object)
    TreeAction.startWithTarget(self,object)
    self._tableAction[1]:startWithTarget(object)
end

function TreeSequence:step(time)
    self._tableAction[1]:step(time)
    self:update(time)
end

function TreeSequence:finish()
    return #self._tableAction <= 0 
end

function TreeSequence:update(time_rate)
    if self._tableAction[1]:finish() then
        table.remove(self._tableAction,1)
        if self._tableAction[1] then
            self._tableAction[1]:startWithTarget(self._target)
            --local yyy = 0
        end
    end
end
--------------------------速度------------------------------------------------------
TreeSpeed = class("TreeSpeed")

function TreeSpeed:ctor(action,speed)
    ClassUtil.extends(self,TreeAction,true,100,Tree.ActionType.ActionType_Speed)
    self._innerAction = action
    self._speed = speed
end

function TreeSpeed:startWithTarget(object)
    TreeAction.startWithTarget(self,object)
    self._innerAction:startWithTarget(object)
end

function TreeSpeed:setSpeed(speed)
    self._speed = speed
end

function TreeSpeed:getSpeed()
    return self._speed
end

function TreeSpeed:step(dt)
    self._innerAction:step(dt * self._speed)
end

function TreeSpeed:finish()
    return self._innerAction:finish()
end
----------------------缓动EaseSineOut实现-------------------------------
TreeEaseSineOut = class("TreeEaseSineOut")

function TreeEaseSineOut:ctor(action)
    ClassUtil.extends(self,TreeAction,true,action._duration,Tree.ActionType.ActionType_SineOut)
    self._innerAction = action
end

function TreeEaseSineOut:startWithTarget(object)
    TreeAction.startWithTarget(self,object)
    self._innerAction:startWithTarget(object)
end

function TreeEaseSineOut:update(time_rate)
    self._innerAction:update(math.sin(time_rate * 0.5 * math.pi))
end
