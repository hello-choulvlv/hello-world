--森林舞会
--2018年11月23日
--@author:xiaoxiong
TreeFunc = {}
TreeFunc._randomSeed = 0--隨機數種子

--传入数据结构,计算精灵,并返回最终的实际的宽度/高度
function TreeFunc.createSpriteNumber(num,texture_template,dimension_map,anchor_point,min_number,root_node,use_cache)
    local anchor_point2 = anchor_point or {x=0,y = 0.5}
    min_number = min_number or 0
    local parent_node = root_node or cc.Node:create()
    --判断是否使用cc.Sprite:createWithSpriteFrameName函数
    local create_func = cc.Sprite.create
    if string.byte(texture_template) == 35 then
        create_func = cc.Sprite.createWithSpriteFrameName
        texture_template = string.sub(texture_template,2)
    end
    local width = 0
    local height = 0
    local sprites = {}
    while true do
        local digit = num%10
        local texture_path = string.format(texture_template,tostring(digit))
        local sprite = use_cache and  TreeCacheManager:getCacheObject(texture_path) or create_func(cc.Sprite,texture_path)
        local size = sprite:getContentSize()
        width = width + size.width
        height = size.height
        table.insert(sprites,1,sprite)

        num = math.floor(num/10)
        if num <= 0  then
            break
        end
    end

    if min_number > 0 then
        --空闲出的位数补充0
        local need_count = min_number - #sprites
        for idx = 1,need_count do
            local texture_path = string.format(texture_template,"0")
            local sprite = use_cache and  TreeCacheManager:getCacheObject(texture_path) or create_func(cc.Sprite,texture_path)
            local size = sprite:getContentSize()
            width = width + size.width
            table.insert(sprites,1,sprite)
        end
    end

    local offset_x = -width * anchor_point2.x
    local offset_y = -height * (anchor_point2.y - 0.5)
    for idx = 1,#sprites do
        local size = sprites[idx]:getContentSize()
        sprites[idx]:setPosition(offset_x + size.width*0.5,offset_y)
        parent_node:addChild(sprites[idx])

        offset_x = offset_x + size.width
    end
    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height = height
    end
 
    return parent_node
end
--数字精灵,并且带有逗点
function TreeFunc.createSpriteNumberWithDot(num,texture_template,dimension_map,anchor_point,root_node,use_cache)
    local anchor_point2 = anchor_point or {x = 0,y = 0.5}
    local parent_node = root_node or cc.Node:create()
    local sprites = {}
    local width = 0
    local height = 0
    local num_c = 0

    local create_func = cc.Sprite.create
    if string.byte(texture_template) == 35 then
        create_func = cc.Sprite.createWithSpriteFrameName
        texture_template = string.sub(texture_template,2)
    end

    while true do
        local num_t = num%10
        local texture_path = string.format(texture_template,tostring(num_t))
        local sprite = use_cache and TreeCacheManager:getCacheObject(texture_path) or create_func(cc.Sprite,texture_path)
        local size = sprite:getContentSize()
        width = width + size.width
        height = size.height
        num_c = num_c + 1
        table.insert(sprites,1,sprite)

        num = math.floor(num/10)
        if num <= 0 then
            break
        end
        --检查是否是3的倍数
        if num_c %3 == 0 then
            texture_path = string.format(texture_template,"d")
            sprite = use_cache and  TreeCacheManager:getCacheObject(texture_path) or create_func(cc.Sprite,texture_path)
            size = sprite:getContentSize()
            width = width + size.width
            table.insert(sprites,1,sprite)
        end
    end
    local offset_x = -width * anchor_point2.x
    local offset_y =  -height * (anchor_point2.y - 0.5)
    local totalWidth = 0
    for index = 1,#sprites do
        local sprite = sprites[index]
        local size = sprite:getContentSize()
        totalWidth = totalWidth + size.width
        sprite:setPosition(offset_x + size.width*0.5,offset_y)
        parent_node:addChild(sprite)
        offset_x = offset_x + size.width
    end
    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height= height
    end
    return parent_node, totalWidth
end

function TreeFunc.createSpriteNumberWithShort(num,texture_template,dimension_map,anchor_point,root_node,use_cache)
    local anchor_point2 = anchor_point or {x=0,y=0.5}
    local parent_node = root_node or cc.Node:create()
    local num_table = {}
    if num >=  100000000 then
        local num_y = math.floor(num/100000000)
        TreeFunc.splitNumber(num_y,num_table)
        table.insert(num_table,100)
        num = num%100000000
    end

    if num >= 10000 then
        local num_w = math.floor(num/10000)
        TreeFunc.splitNumber(num_w,num_table)
        table.insert(num_table,10)
        num = num%10000
    end
    if #num_table < 1 or num > 0 then
        TreeFunc.splitNumber(num,num_table)
    end
    local sprites = {}
    local width = 0
    local height = 0

    local create_func = cc.Sprite.create
    if string.byte(texture_template) == 35 then
        create_func = cc.Sprite.createWithSpriteFrameName
        texture_template = string.sub(texture_template,2)
    end

    for idx=1,#num_table do
        local num_c = num_table[idx]
        local texture_path
        if num_c == 100 then--亿
            texture_path = string.format(texture_template,"y")
        elseif num_c == 10 then
            texture_path = string.format(texture_template,"w")
        else
            texture_path = string.format(texture_template,tostring(num_c))
        end
        local sprite = use_cache and  TreeCacheManager:getCacheObject(texture_path) or create_func(cc.Sprite,texture_path)
        local size = sprite:getContentSize()
        --sprite:setPosition(offset_x + size.width*0.5,0)
        table.insert(sprites,sprite)
        parent_node:addChild(sprite)

        width = width + size.width
        height = size.height
    end
    --调整位置
    local offset_x = -anchor_point2.x * width
    local offset_y = - (anchor_point2.y-0.5) * height
    for index = 1,#sprites do
        local sprite = sprites[index]
        local size = sprite:getContentSize()
        sprite:setPosition(offset_x + size.width * 0.5,offset_y)

        offset_x = offset_x + size.width
    end

    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height = height
    end

    return parent_node
end
--超过100w时,显示的方式有所不同,其他的跟createSpriteNumberDot没有什么不同
function TreeFunc.createSpriteNumberWithShortW(num,texture_template,dimension_map,anchor_point,root_node,use_cache)
    local anchor_point2 = anchor_point or {x=0,y=0.5}
    local parent_node = root_node or cc.Node:create()
    local num_table = {}
    if num >=  100000000 then--1y
        local num_y = math.floor(num/100000000)
        TreeFunc.splitNumber(num_y,num_table)
        table.insert(num_table,100)
        num = num%100000000
    end

    if num >= 1000000 then--w
        local num_w = math.floor(num/10000)
        TreeFunc.splitNumber(num_w,num_table)
        table.insert(num_table,10)
        num = 0--num%1000000
    end
    if #num_table < 1 or num > 0 then
        TreeFunc.splitNumber(num,num_table)
    end
    local sprites = {}
    local width = 0
    local height = 0
    local num_cd = 0
    local should_count = true

    local create_func = cc.Sprite.create
    if string.byte(texture_template) == 35 then
        create_func = cc.Sprite.createWithSpriteFrameName
        texture_template = string.sub(texture_template,2)
    end

    for idx=#num_table,1,-1 do--从低位到高位
        local num_c = num_table[idx]
        local texture_path
        if num_c == 100 then--亿
            texture_path = string.format(texture_template,"y")
            should_count = false
        elseif num_c == 10 then
            texture_path = string.format(texture_template,"w")
            should_count = false
        else
            texture_path = string.format(texture_template,tostring(num_c))
        end
        local sprite = use_cache and  TreeCacheManager:getCacheObject(texture_path) or create_func(cc.Sprite,texture_path)
        local size = sprite:getContentSize()
        --sprite:setPosition(offset_x + size.width*0.5,0)
        table.insert(sprites,1,sprite)
        parent_node:addChild(sprite)

        width = width + size.width
        height = size.height
        num_cd = num_cd + 1
        --检查是否是3的倍数
        if should_count and idx ~= 1 and num_cd %3 == 0 then
            texture_path = string.format(texture_template,"d")
            sprite = use_cache and  TreeCacheManager:getCacheObject(texture_path) or create_func(cc.Sprite,texture_path)
            parent_node:addChild(sprite)
            size = sprite:getContentSize()
            width = width + size.width
            table.insert(sprites,1,sprite)
        end
    end
    --调整位置
    local offset_x = -anchor_point2.x * width
    local offset_y = - (anchor_point2.y-0.5) * height
    for index = 1,#sprites do
        local sprite = sprites[index]
        local size = sprite:getContentSize()
        sprite:setPosition(offset_x + size.width * 0.5,offset_y)

        offset_x = offset_x + size.width
    end

    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height = height
    end

    return parent_node
end
--简写数字,但是如果是个位数的万,则直接写,不再产生万字
function TreeFunc.createSpriteNumberWithShort2(num,texture_template,dimension_map,anchor_point)
    local anchor_point2 = anchor_point or {x=0,y=0.5}
    local parent_node = cc.Node:create()
    local num_table = {}
    if num >=  100000000 then--一亿
        num = math.floor(num/100000000)
        TreeFunc.splitNumber(num,num_table)
        table.insert(num_table,100)
    elseif num >= 100000 then--10w
        num = math.floor(num/10000)
        TreeFunc.splitNumber(num,num_table)
        table.insert(num_table,10)
    else
        TreeFunc.splitNumber(num,num_table)
    end

    local sprites = {}
    local width = 0
    local height = 0

    local create_func = cc.Sprite.create
    if string.byte(texture_template) == 35 then
        create_func = cc.Sprite.createWithSpriteFrameName
        texture_template = string.sub(texture_template,2)
    end

    for idx=1,#num_table do
        local num_c = num_table[idx]
        local texture_path
        if num_c == 100 then--亿
            texture_path = string.format(texture_template,"y")
        elseif num_c == 10 then
            texture_path = string.format(texture_template,"w")
        else
            texture_path = string.format(texture_template,tostring(num_c))
        end
        local sprite = create_func(cc.Sprite,texture_path)
        local size = sprite:getContentSize()
        --sprite:setPosition(offset_x + size.width*0.5,0)
        table.insert(sprites,sprite)
        parent_node:addChild(sprite)

        width = width + size.width
        height = size.height
    end
    --调整位置
    local offset_x = -anchor_point2.x * width
    local offset_y = - (anchor_point2.y-0.5) * height
    for index = 1,#sprites do
        local sprite = sprites[index]
        local size = sprite:getContentSize()
        sprite:setPosition(offset_x + size.width * 0.5,offset_y)

        offset_x = offset_x + size.width
    end

    if dimension_map then
        local map = dimension_map
        map.width = width
        map.height = height
    end

    return parent_node
end

function TreeFunc.splitNumber(num,num_table)
    local table_t = {}
    while true do
        local num_t = num%10
        table.insert(table_t,1,num_t)
        num = math.floor(num/10)

        if num <= 0 then
            break
        end
    end
    for idx = 1,#table_t do
        table.insert(num_table,table_t[idx])
    end
end
function TreeFunc.splitNumber2(num)
    local table_t = {}
    while true do
        local num_t = num%10
        table.insert(table_t,num_t)
        num = math.floor(num/10)

        if num <= 0 then
            break
        end
    end
    return table_t
end
--添加X方向晃动效果action_count需要是一个偶数
function TreeFunc.addRandomMoveX(delayTime,move_x,action_count,action_table)
    local offset_x = 0
    local attenuation = 1.0
    for idx =1,action_count -1 do
        local x = math.random() * move_x * attenuation
        table.insert(action_table,cc.MoveBy:create(delayTime * (0.3 + 0.7) * math.random(),cc.p(offset_x + x,0)))
        offset_x = -offset_x - x
        attenuation = attenuation * 0.5
    end
    --恢复
    table.insert(action_table,cc.MoveBy:create(delayTime *(0.3 + 0.7) * math.random(),cc.p(offset_x,0)))
end

function TreeFunc.sign(x)
    return x >0 and 1 or (x<0 and -1 or 0)
end
--创建包装函数
function TreeFunc.createWrapFunc(obj,origin_func_name,listener)
    local last_func = obj[origin_func_name]
    local nobj = obj
    nobj["__" .. origin_func_name] = last_func
    nobj[origin_func_name] = function(c_obj,...)
        last_func(c_obj,...)
        listener(c_obj,...)
    end
end
--恢复原来的包装函数设置
function TreeFunc.restoreWrapFunc(obj,origin_func_name)
    local nobj = obj
    local origin_func = nobj["__" .. origin_func_name]
    if origin_func then
        nobj[origin_func_name] = origin_func
    end
end
--返回数字的整数部分与尾数部分,数字的数目
--该整数部分只能为1
function TreeFunc.computeIntegerReminder(value)
    local origin = value
    local reminder = 0
    local integer = 1
    local index = 1

    while value >= 10 do
        value = math.floor(value/10)
        integer = integer * 10
        index = index + 1
    end

    return integer,origin%integer,index
end
--返回与一个数字最远的下界,所谓最远是指滚动的距离最远
function TreeFunc.getLowerBound(value)
    local table_s = TreeFunc.splitNumber2(value)
    local number = 0
    
    for idx = #table_s,1,-1 do
        local num = (table_s[idx] + math.random(1,9))%10
        if num == 0 and idx == #table_s then
            num = math.random(1,9)
        end
        number = number * 10 + num
    end

    return number
end
--递归式加载子节点命名
function TreeFunc.loadChildCascade(root,cascade)
    local other_root = root
    local children = other_root:getChildren()
    for ke,child in pairs(children) do
        local name = child:getName()
        other_root[name] = child
        if cascade and child:getChildrenCount() > 0 then
            TreeFunc.loadChildCascade(child)
        end
    end
end
--查找目标值在表中的索引
function TreeFunc.indexOf(table_t,target_value)
    local index_t = -1
    for index = 1, #table_t do
        if table_t[index] == target_value then
            index_t = index
            break
        end
    end
    return index_t
end
--查找目标值不在表中的索引
function TreeFunc.indexOfNot(table_t,target_value)
    local index_t = 0
    for index = 1, #table_t do
        if table_t[index] ~= target_value then
            index_t = index
            break
        end
    end
    return index_t
end
--查找目标值所的在表中的所有索引集合
function TreeFunc.checkAllIndex(table_t,target_value,final_index)
    local table_index =  {}
    final_index = final_index or #table_t
    final_index = math.min(final_index,#table_t)

    for index = 1, final_index do
        if table_t[index] == target_value then
            table.insert(table_index,index)
        end
    end
    return table_index
end
--查找目标值不在表中的所有索引集合
function TreeFunc.checkAllIndexNot(table_t,target_value)
    local table_index =  {}
    for index = 1, #table_t do
        if table_t[index] ~= target_value then
            table.insert(table_index,index)
        end
    end
    return table_index
end
--截取表的前n项
function TreeFunc.trunk(table_t,count)
    count = math.min(count,#table_t)
    local table_n = {}
    for idx = 1,count do
        table.insert(table_n,table_t[idx])
    end
    return table_n
end
--对表中的每一项安排索引
function TreeFunc.assignIndex(table_t,count)
    count = math.min(#table_t,count or #table_t)
    for idx = 1,count do
        table_t[idx]._index = idx
    end
end

function TreeFunc.setRandomSeed(seed)
    TreeFunc._randomSeed = seed
end

function TreeFunc.random()
    local seed = TreeFunc._randomSeed
    local v = (seed * 351245 + 12345) % 65535
    TreeFunc._randomSeed = v
    return v/65535
end
--将某一个对象的所有子节点移除并放入到缓存中
function TreeFunc.extractCacheWithNode(parent_node)
    if parent_node:getChildrenCount() > 0 then
        local children = parent_node:getChildren()
        for key_index,child in pairs(children) do
            TreeCacheManager:recycleCocos2dxObject(child)
        end
    end
end
--求数组内容之和
function TreeFunc.checkSumary(table_t)
    local sumary = 0
    for k, v in pairs( table_t or {} ) do 
        sumary = sumary + v
    end
    return sumary
end
--shuffle
function TreeFunc.shuffle(table_t,index_f)
    local index = #table_t--math.min(index_f,#table_t)
    --local place_index = index
    while index > 0 do
        local r_index = math.floor(TreeFunc.random() * index) + 1
        local t_v = table_t[r_index]

        table.remove(table_t,r_index)
        table.insert(table_t,t_v)

        index = index - 1
    end
end
function TreeFunc.ceshidaima(random_array,start_index,total_count,cheat_animal_index)
    local color_type = 1
    if cheat_animal_index then
        local color_index = cheat_animal_index + start_index - 1
        color_index = (color_index - 1) % 24 + 1
        random_array[color_index] = math.ceil(cheat_animal_index/4)
        local other_color_type = (random_array[color_index] + 1) %3
        if other_color_type == 0 then
            other_color_type = 1
        end
        local cheat_color_index = color_index
        color_type = random_array[color_index]
        for animal_index = 1, 24 do
            local color_index = animal_index + start_index - 1
            color_index = (color_index - 1) % 24 + 1

            local model_type = (animal_index - 1) % 4  + 1
            if animal_index ~= cheat_animal_index then
                table.insert(color_map[other_color_type][model_type],animal_index)
                random_array[color_index] = other_color_type
            else
                table.insert(color_map[color_type][model_type],animal_index)
                random_array[color_index] = color_type
            end
        end
        return color_map
    end
end
--使用新版的算法实现随机乱序排列颜色
function TreeFunc.shuffle3(random_array,start_index,total_count)
    --计算动物模型1对应的索引
    local color_map = {
        [1] = {[1] = {},[2] = {},[3] = {},[4] = {}},
        [2] = {[1] = {},[2] = {},[3] = {},[4] = {}},
        [3] = {[1] = {},[2] = {},[3] = {},[4] = {}},
    }
    local color_type = 1
    while color_type <= 3 do
        --基础索引
        local base_index = (color_type - 1) * 4 + 1
        --颜色表的基础索引
        local base_color_index = (start_index + base_index - 2)%total_count + 1
        for index_j = 0,3 do
            --当前处理的动物模型索引
            local index_animal1 = base_index + index_j
            --对面的动物模型索引
            local index_animal2 = index_animal1 + 12
            --当前处理的色块的索引
            local index_color1 = (base_color_index + index_j - 1) % total_count + 1
            --对面的色块的索引,镜像
            local index_color2 = (index_color1 + 12 -1)%total_count + 1
            --随机假设颜色
            local other_color_type = math.floor(TreeFunc.random() * 3) + 1
            if other_color_type == color_type then--排除掉相同类型的颜色
                other_color_type = (other_color_type + 3 + (TreeFunc.random() > 0.5 and 1 or -1) - 1)% 3 + 1--随机向两侧查找第一个数字
            end
            --
            if math.floor(TreeFunc.random() * 101)%2 ~= 0 then
                table.insert(color_map[color_type][index_j + 1],index_animal1)
                table.insert(color_map[other_color_type][index_j + 1],index_animal2)

                random_array[index_color1] = color_type
                random_array[index_color2] = other_color_type
            else
                table.insert(color_map[color_type][index_j + 1],index_animal2)
                table.insert(color_map[other_color_type][index_j + 1],index_animal1)

                random_array[index_color1] = other_color_type
                random_array[index_color2] = color_type
            end
        end
        color_type = color_type + 1
    end

    return color_map
end
-- shuffle 2,专用函数
--table_color:颜色表
--table_animal:被选中的动物模型表
--start_index:起始的索引
--random_array,table_animal,index_start,24
function TreeFunc.shuffle2(table_color,table_animal,start_index,total_count)
    local index = #table_color
    while index > 0 do
        local r_index = math.floor(TreeFunc.random() * index) + 1
        local t_v = table_color[r_index]

        table.remove(table_color,r_index)
        table.insert(table_color,t_v)

        index = index - 1
    end
    --统计颜色(实际的色块的颜色)-模型(旋转后的模型)之间的映射关系
    local color_map = {
        [1] = {[1] = {},[2] = {},[3] = {},[4] = {}},
        [2] = {[1] = {},[2] = {},[3] = {},[4] = {}},
        [3] = {[1] = {},[2] = {},[3] = {},[4] = {}},
    }
    local index = #table_color
    while index > 0 do
        --固定索引向模型相对索引转换,场景动物转盘旋转之后,当前的固定的色块的索引对应的实际的动物模型的索引
        local index_fix = index - start_index
        index_fix = index_fix - math.floor(index_fix/total_count) * total_count + 1

        local color_type = table_color[index]
        local model_type = (index_fix - 1)%4 + 1
        table.insert(color_map[color_type][model_type],index_fix)

        index = index - 1
    end
    --统计目标动物的最小需求,颜色,模型,数目
    local animal_need_map = {
        [1] = {[1] = 0,[2] = 0,[3] = 0,[4] = 0},
        [2] = {[1] = 0,[2] = 0,[3] = 0,[4] = 0},
        [3] = {[1] = 0,[2] = 0,[3] = 0,[4] = 0},
    }
    local index = #table_animal
    while index > 0 do
        local animal_type = table_animal[index]
        local model_type = (animal_type - 1)%4 + 1
        local color_type = math.ceil(animal_type/4)

        animal_need_map[color_type][model_type] = animal_need_map[color_type][model_type] + 1

        index = index - 1
    end

    --每一种动物至少要求的颜色,并且,在计算的过程中,检测并排除掉不符合要求的表格内容
    local index = #table_animal
    while index > 0 do
        local animal_type = table_animal[index]
        local model_type = (animal_type - 1)%4 + 1
        local color_type = math.ceil(animal_type/4)
        --检测是否目标里面有相关的类型
        local animal_array = color_map[color_type][model_type]
        if #animal_array < 1 then--如果对应的颜色表中的动物模型表里面为空
            --此时需要从二维表中,将该元素删除,并添加到当前的表格中,并修改table_color
            local color_placeholder,animal_index = TreeFunc.removeEleFrom2Map(animal_need_map,color_map,model_type)--返回值必不为空
            --修改颜色,从相对索引到固定索引转换
            local relocate_index = (animal_index + start_index - 2) % total_count + 1
            table_color[relocate_index] = color_type
            --修改颜色-模型映射表
            table.insert(animal_array,animal_index)
        end

        index = index - 1
    end

    return color_map
end
--专用函数
function TreeFunc.removeEleFrom2Map(animal_need_map,color_map,animal_type)
    --某些情况下需要排除掉,防止算法先将某一个对象添加到表中,后来又把它删除了
    for color_type,animal_table_seq in pairs(color_map) do
        local animal_array = animal_table_seq[animal_type]
        if # animal_array > animal_need_map[color_type][animal_type] then--下面的语句可以触发的条件为,相关的动物的颜色与类型需求得到满足
            return color_type, table.remove(animal_array)
        end
    end
end
--计算视锥体下模型的缩放比例
function TreeFunc.computeFrustumScale(camera_pos,rotation,model_pos,eye_z)
    local rad = math.rad(rotation.x)
    local d_x = 0
    local d_y = math.sin(rad)
    local d_z = - math.cos(rad)

    local p_x = model_pos.x - camera_pos.x
    local p_y = model_pos.y - camera_pos.y
    local p_z = model_pos.z - camera_pos.z

    local length_s = math.sqrt(p_x * p_x + p_y * p_y + p_z * p_z)
    local v_x = p_x/length_s
    local v_y = p_y/length_s
    local v_z = p_z/length_s

    local dot_v = v_x * d_x + v_y * d_y + v_z * d_z
    local distance_z = eye_z/dot_v

    return length_s/distance_z
end

function TreeFunc.formatNumber(num)
    --如果分数大于等于1亿
    local n_y = 100000000
    if num >= n_y then
        local iy = math.floor((num + 0.5)/n_y)
        local iw = num%n_y
        local i1 = math.floor((iw + 0.5)/10000000)
        local i2 = math.floor((iw%10000000 + 0.5)/1000000)

        if i1 + i2 == 0 then
            return string.format("%dy",iy)
        end
        if (i1 ~= 0 and i2 ~= 0) or i2 ~= 0 then
            return string.format("%df%d%dy",iy,i1,i2)
        else
            return string.format("%df%dy",iy,i1)
        end
    end
    --剩下的数字需要判断是否大于等于1000 * 1000
    local i2 = 1000000
    local i3 = 1000

    local s0 = math.floor((num + 0.5)/i2)
    local t0 = num%i2

    local s1 = math.floor((t0 + 0.5)/i3)
    local s2 = t0%i3
    --以上一共三个数字
    if s0 ~= 0 then
        return string.format("%dd%03dd%03d",s0,s1,s2)
    end
    if s1 ~= 0 then
        return string.format("%dd%03d",s1,s2)
    end
    return tostring(s2)
end

function TreeFunc.formatNumberDot(num)
    --剩下的数字需要判断是否大于等于1000 * 1000 * 1000
    local i2 = 1000000000
    local i3 = 1000000
    local i4 = 1000

    local s0 = math.floor((num + 0.5)/i2)
    local t0 = num%i2

    local s1 = math.floor((t0 + 0.5)/i3)
    local t1 = t0%i3

    local s2 = math.floor((t1 + 0.5)/i4)
    local s3 = t1%i4
    --以上一共三个数字
    if s0 ~= 0 then
        return string.format("%dd%03dd%03dd%03d",s0,s1,s2,s3)
    end
    if s1 ~= 0 then
        return string.format("%dd%03dd%03d",s1,s2,s3)
    end
    if s2 ~= 0 then
        return string.format("%dd%03d",s2,s3)
    end
    return tostring(s3)
end

function TreeFunc.formatNumberWY(num)
    local pw = 100000000
    local pw2 = 10000000
    local pw3 = 1000000
    local yw = nil
    if num >= pw then
        yw = "y"
    elseif num >= 10000 then
        pw = 10000
        pw2 = 1000
        pw3 = 100
        yw = "w"
    end

    if yw ~= nil then
        local s0 = math.floor((num + 0.5)/pw)
        local t0 = num%pw

        local s1 = math.floor((t0 + 0.5)/pw2)
        local t1 = t0%pw2

        local s2 = math.floor((t1 + 0.5)/pw3)

        if s2 ~= 0 then
            return string.format("%df%d%d%s",s0,s1,s2,yw)
        end
        if s1 ~= 0 then
            return string.format("%df%d%s",s0,s1,yw)
        end
        return string.format("%d%s",s0,yw)
    end
    return tostring(num)
end