--森林舞会
--2018年11月23日
--@author:xiaoxiong
--加载事件控制器
requireLuaFromModule("slwh.TreeEventDispatcher")
requireLuaFromModule("slwh.func.TreeFunc")
requireLuaFromModule("slwh.func.TreeActionManager")
requireLuaFromModule("slwh.func.TreeAction")
requireLuaFromModule("slwh.SlwhCacheManager")
requireLuaFromModule("slwh.SlwhJettonCache")

SlwhController = class("SlwhController")
--加载各种配置

function SlwhController:ctor(model)
    self.model = model
    ClassUtil.extends(self, BaseGameController)
    self.model:setSwitchStatePos({offX = 67.27, onX = 143.14})
    self.battleView = nil
    --是否进入了前台
    self._isEnterForeground = false
    self._msgCaches = {}
    --取消定时纹理清理,lua内存清理,因为此时会预加载纹理资源
    mainMgr:onStopTick2Gc()
    --resMgr:loadTextureAtlas(self:getSpriteSheetPath("slwh_jetton_atlas.plist"), true);--jetton_atlas.plist
    resMgr:loadTextureAtlas(self:getSpriteSheetPath("slwh_battle_animal_time.plist"), true);
    resMgr:loadTextureAtlas(self:getSpriteSheetPath("slwh_result_sprite.plist"),true)
    --resMgr:loadTextureAtlas(self:getSpriteSheetPath("slwh_jetton.plist"),true)
    --设置预加载的资源
    self:setPreloadResource()
    --EventController:init()
    self:initProtocolConfig()
    --cc.Director:getInstance():setDisplayStats(true)

    TreeCacheManager:init()
    TreeCacheManager:registerCocos2dxObject(Tree.CacheTemplate)
    --other cache
    SlwhJettonCache:init()
    SlwhJettonCache:registerCacheMap(Tree.JettonCache)
    TreeEventDispatcher:init()
    --eventMgr:add(GameEvent.whNd_Main_Sub_CM_System, self.setWentToBank, self)
    self:registerListeners()
    self._isEnterScene = false
    self.netJetton = {}
    self.netJettonRemand = {}

end

function SlwhController:getNetJetton() 
    return table.remove( self.netJetton, 1 )
end
function SlwhController:getNetRemand()
    return table.remove( self.netJettonRemand, 1 )
end
function SlwhController:setNetJetton(t ) 
    self.netJetton = t
end
function SlwhController:setNetRemand(t)
    self.netJettonRemand = t
end
function SlwhController:setEnterScene(b)
    self._isEnterScene = b
end

function SlwhController:onViewTypeChanged()
    BaseGameController.onViewTypeChanged(self)
    if(self.model:getCurShowingViewType() ~= VIEW_TYPE_BATTLE ) then 
        self.model:setIsShowingJetton(false)
        TreeEventDispatcher:dispatchEvent(Tree.Event.showAllModels)
    end
end

--设置于加载的资源
function SlwhController:setPreloadResource()
    self._resProcessConfigs = {
        {url = "spritesheet/slwh_room_number",type = "plist",isForbidUnload = true},
        {url = "spritesheet/slwh_jetton_number",type = "plist",isForbidUnload = true},
        {url = "spritesheet/slwh_jetton",type = "plist",isForbidUnload = true},
        {url = "spritesheet/slwh_jetton_small_bet_number",type = "plist",isForbidUnload = true},
        {url = "spritesheet/bet_numbers",type = "plist", isForbidUnload = true},
        {url = "spritesheet/slwh_bank_font",type = "plist", isForbidUnload = true},
        {url = "spritesheet/slwh_battle_animal_time",type = "png",isForbidUnload = true},
        {url = "spritesheet/slwh_result_sprite",type = "png",isForbidUnload = true},
        {url = "spritesheet/slwh_battle_bonus",type = "plist",isForbidUnload = true},
        --room,初级场
        {url = "animation/slwh_cjc/slwh_cjxc",type = "png"},
        {url = "animation/slwh_cjc/slwh_cjxcbg",type = "png"},
        {url = "animation/slwh_cjc/slwh_cjxcgx",type = "png"},
        --高级场
        {url = "animation/slwh_gjc/slwh_gjxc",type = "png"},
        {url = "animation/slwh_gjc/slwh_gjxcbg",type = "png"},
        {url = "animation/slwh_gjc/slwh_gjxcgx",type = "png"},
        --普通场
        {url = "animation/slwh_ptc/slwh_ptxc",type = "png"},
        {url = "animation/slwh_ptc/slwh_ptxcbg",type = "png"},
        {url = "animation/slwh_ptc/slwh_ptxcgx",type = "png"},
        --体验场
        {url = "animation/slwh_tyc/slwh_tycgx",type = "png"},
        {url = "animation/slwh_tyc/slwh_tyxc",type = "png"},
        {url = "animation/slwh_tyc/slwh_tyxcbg",type = "png"},
        --中级场
        {url = "animation/slwh_zjc/slwh_zjxc",type = "png"},
        {url = "animation/slwh_zjc/slwh_zjxcbg",type = "png"},
        {url = "animation/slwh_zjc/slwh_zjxcgx",type = "png"},
        --快速开始
        {url = "animation/quickstart/slwh_quickstart",type = "png"},
        --房间背景
        {url = "common/slwh_bg",type = "jpg"},
        --模型的纹理
        {url = "model/01_basecolor",type = "png"},
        --light texture
        {url = "model/light/02_basecolor_01",type = "png"},
        {url = "model/light/02_basecolor_02",type = "png"},
        {url = "model/light/02_basecolor_03",type = "png"},
        {url = "model/light/02_basecolor_04",type = "png"},
        {url = "model/light/02_basecolor_0_03",type = "png"},
        {url = "model/light/02_basecolor_0_06",type = "png"},
        {url = "model/light/02_basecolor_0_09",type = "png"},

        {url = "model/gold/houzi",type = "png"},
        {url = "model/gold/shizi",type = "png"},
        {url = "model/gold/tuzi",type = "png"},
        {url = "model/gold/xiongmao",type = "png"},
        --
        {url = "model/bg_model",type = "png"},
        {url = "model/t_plant1_model",type = "png"},
        {url = "model/t_plant2_model",type = "png"},
        {url = "model/t_plant3_model",type = "png"},
        {url = "model/t_plant4_model",type = "png"},
        {url = "model/t_plant5_model",type = "png"},
        {url = "model/tree1_model",type = "png"},
        {url = "model/tree2_model",type = "png"},
        {url = "model/tree3_model",type = "png"},
        {url = "model/houzi/houzi",type = "png"},
        {url = "model/tuzi/tuzi",type = "png"},
        {url = "model/xiongmao/xiongmao_D",type = "png"},
        {url = "model/shizi/shizi_D",type = "png"},
        {url = "model/caijin/caijin_basecolor",type = "png"},
        {url = "model/dasanyuan/dasanyuan_basecolor",type = "png"},
        {url = "model/dasixi/dasixi_basecolor_gree",type = "png"},
        {url = "model/dasixi/dasixi_basecolor_Red",type = "png"},
        {url = "model/dasixi/dasixi_basecolor_Yellow",type = "png"},
        {url = "model/dasixi/dasixi_basecolor_Flow",type = "png"},

        {url = "result/sprite_mask",type = "png"},
        {url = "effect/slwh_xztxlg",type = "png"},
        {url = "effect/slwh_kjjg",type = "png"},
        {url = "effect/slwh_dsy",type = "png"},
        {url = "effect/slwh_dsx",type = "png"},
        {url = "effect/slwh_xiazhumenu",type = "png"},
        {url = "effect/slwh_xztxlg",type = "png"},
        {url = "effect/slwh_yanhuaeffect",type = "png"},
        {url = "effect/slwh_stagewater",type = "png"},
        {url = "effect/slwh_stagewateryy",type = "png"},
        {url = "effect/slwh_dancinggs",type = "png"},
        {url = "effect/slwh_stagegs",type = "png"},
        {url = "jettonNew/slwh_jetton_bg_bg",type = "jpg"},
    }
    --需要缓存的资源
    self._cacheResource = {}
    ----------------------------------------------------------------
    self._currentIndex = 1
    self._preIndex = 0
    --self._userCallFunc = self.loadSpineAndParticle
end
--每帧调用的函数
function SlwhController:loadSpineAndParticle()
    self._preIndex = self._preIndex + 1
    --按次序每帧加载一个C++对象
    if self._currentIndex <= #self._cacheResource then
        local cache_info = self._cacheResource[self._currentIndex]

        if cache_info.type == Tree.LoadingType.LoadingType_Animation3D then
            self:loadAnimation3D(cache_info)
            self._currentIndex = self._currentIndex + 1
        elseif cache_info.type == Tree.LoadingType.LoadingType_Sprite then
            local table_object = {}
            for index = 1,cache_info.fcount do
                table.insert(table_object,TreeCacheManager:getCacheObject(cache_info.key))
            end
            for index = 1, cache_info.fcount do
                TreeCacheManager:recycleCocos2dxObject(table_object[index])
            end
            self._currentIndex = self._currentIndex + 1
        end
    end
    return self._currentIndex > #self._cacheResource
end
function SlwhController:loadAnimation3D(cache_info)
    local animation = cc.Animation3D:create(cache_info.path)
    TreeCacheManager:putAnimation3D(animation,cache_info.key)
end
--有关协议的配置
function SlwhController:initProtocolConfig()
    self._protocol = {
        [SLWH_SUB_S_GAME_START] = {messageName = "SLWH_CMD_S_GameStart",func = self.onMsgGameStart},
        [SLWH_SUB_S_GAME_END] = {messageName = "SLWH_CMD_S_GameEnd",func = self.onMsgGameEnd},
        [SLWH_SUB_S_JETTON] = {messageName = "SLWH_CMD_S_Jetton",func = self.onMsgGameBet},
        [SLWH_SUB_S_JETTON_CONTINUE] = {messageName = "SLWH_CMD_S_Jetton_Continue",func = self.onMsgGameBetContinue},
        [SLWH_SUB_S_REFRESH_STATUS] = {messageName = "SLWH_CMD_S_GameStatus",func = self.onMsgRefreshStatus},
        [SLWH_SUB_S_JETTON_FAIL] = {messageName = "SLWH_CMD_S_PlaceBetFail",func = self.onMsgGameFailed},
        [SLWH_SUB_S_REQUEST_STATE] = {messageName = "SLWH_CMD_S_GameStatus",func = self.onMsgQueryStatus},
    }
end
--查询游戏的状态
function SlwhController:requestQueryStatus()
    self._queryTime = socket.gettime()
    reqSlwhQueryStatus()
end
function SlwhController:onMsgQueryStatus(bodyData)
    local body_data = bodyData
    local remind_time = body_data.cbTimeLeave - socket.gettime() + self._queryTime
    body_data.cbTimeLeave = remind_time
    TreeEventDispatcher:dispatchEvent(Tree.Event.queryGameStatus,body_data)
    --检查是否有目标协议,并且当前的阶段必须也是开奖阶段
    if (bodyData.cbStatus == Tree.Status.Over and bodyData.cbTimeLeave > 2.5) and (self._gameProtocolLast and self._gameProtocolLast.subCmdId == SLWH_SUB_S_GAME_END)then
        local msgBody = self._gameProtocolLast.binaryMsg
        local protocol = self._gameProtocolLast.protocol
         if protocol.messageName and ffiMgr:isSizeEqual(self._gameProtocolLast.binaryMsg, protocol.messageName)then 
             local bodyData = ffiMgr:castStruct2TableByLuaStr(self._gameProtocolLast.binaryMsg,protocol.messageName)
             self.model:setGameRewardData(bodyData)
            --玩家获得的奖励
            self.model:setUserReward(bodyData.tAward)
            --玩家的总的下注分数
            self.model:setUserTotalJetton(bodyData.lJettoned)
            --玩家本局获得的分数
            self.model:setUserSessionScore(bodyData.lScore)
            --玩家本局获得的彩金
            self.model:setUserSessionCaiJin(bodyData.lCaijin)
            self.model:setHistoryRewards(bodyData.tAwardRecord)
            local body_data = bodyData
            body_data.cbTimeLeave = remind_time
            TreeEventDispatcher:dispatchEvent(Tree.Event.gameOverFromBack,bodyData)
        end 
    end
    self._gameProtocolLast = nil
end
--游戏开始
function SlwhController:onMsgGameStart(bodyData)
    self.netJetton = {}
    self.netJettonRemand = {}
    self.model:setCellScoreArray(bodyData.lJettonConfig)
    self:dynamicGlobalConfig()
    self.model:setAreaBetMultiplyArray(bodyData.nJettonAreaTimes)
    --重置本局下注
    self.model:setAllUserBetNumber(0)
    self.model:setCurAreaUserBetOrder({})
    self.model:setCurSelectdGold(0)
    self.model:setCanJettonContinue(true)
    local player_jettons = {}
    for idx = 1,15 do
        player_jettons[idx] = 0
    end
    self.model:setAreaUserBetArray(player_jettons)
    if( false == SLWH_AFTER_WITHDRAWAL_CAN_BET ) then 
        self.model:setSelfBetStartMoney( Hero:getUserScore() )
        self.model:setSelfBetStartMoneyTemp( Hero:getUserScore() )
    end


    TreeEventDispatcher:dispatchEvent(Tree.Event.gameStart,bodyData)

end

local winTypeDesc = {
    [Tree.RewardType.RewardType_Normal] = "普通",
    [Tree.RewardType.RewardType_DaSanYuan] = "大三元",
    [Tree.RewardType.RewardType_DaSiXi] = "大四喜",
    [Tree.RewardType.RewardType_SongDeng] = "送灯",
    [Tree.RewardType.RewardType_ShanDian] = "闪电",
    [Tree.RewardType.RewardType_CaiJin] = "彩金",
}

--游戏结束
function SlwhController:onMsgGameEnd(bodyData)
    self.netJetton = {}
    self.netJettonRemand = {}
    self.model:setGameRewardData(bodyData)
    --玩家获得的奖励
    self.model:setUserReward(bodyData.tAward)
    --玩家的总的下注分数
    self.model:setUserTotalJetton(bodyData.lJettoned)
    --玩家本局获得的分数
    self.model:setUserSessionScore(bodyData.lScore)
    --玩家本局获得的彩金
    self.model:setUserSessionCaiJin(bodyData.lCaijin)
    self.model:setHistoryRewards(bodyData.tAwardRecord)
    self:savePreJettonMap()
    Hero:setUserFakeScore(0,false,true)
    self.model:setUserRealyScore(bodyData.lEndScore)
    --print("SlwhController:onMsgGameEnd->bodyData.lJettoned->",bodyData.lJettoned)
    --print("onMsgGameEnd->Caijin->",bodyData.lCaijin)
    TreeEventDispatcher:dispatchEvent(Tree.Event.gameOver,bodyData)
end

function SlwhController:onMsgGameBet(bodyData)
    if( bodyData.cbRet == Tree.JettonRetType.RetType_Success ) then 
        local playerId = Hero:getWChairID()
        local userId = bodyData.wChairID
        if( playerId == userId ) then 
            self:_onMsgGameBet(bodyData)
        else
            self.netJetton[ #self.netJetton + 1 ] = bodyData
        end

        self.model:setAllUserBetNumber(self.model:getAllUserBetNumber() + bodyData.lScore)
        local areaTotalBet = self.model:getAreaTotalBetArray()
        areaTotalBet[bodyData.nArea + 1] = bodyData.lTotalJetton


--        if bodyData.nArea == 0 then
--            print("--jetton-1->",bodyData.lTotalJetton)
--        end
    end
    TreeEventDispatcher:dispatchEvent(Tree.Event.gameBet,bodyData)
end
--游戏下注返回
function SlwhController:_onMsgGameBet(bodyData)
    --print("SlwhController:onMsgGameBet->")
    if bodyData.cbRet == Tree.JettonRetType.RetType_Success then

        local playerId = Hero:getWChairID()
        local userId = bodyData.wChairID

        if playerId == userId then
            local playerBetData = self.model:getAreaUserBetArray()
            playerBetData[bodyData.nArea + 1] = bodyData.lJetton

            local areaUserBetOrder = self.model:getCurAreaUserBetOrder()
            if( nil == areaUserBetOrder[bodyData.nArea + 1] ) then 
                areaUserBetOrder[bodyData.nArea + 1] = 0
            end
            areaUserBetOrder[bodyData.nArea + 1] = bodyData.lJetton
            self.model:setCurAreaUserBetOrder( areaUserBetOrder )
            self.model:setCanJettonContinue(false)
        end
    end
    --TreeEventDispatcher:dispatchEvent(Tree.Event.gameBet,bodyData)
end

function SlwhController:onMsgGameBetContinue(bodyData)
    if bodyData.cbRet == Tree.JettonRetType.RetType_Success then
        local playerId = Hero:getWChairID()
        local userId = bodyData.wChairID

        if playerId == userId then
            self:_onMsgGameBetContinue(bodyData)
        else
            self.netJettonRemand[ #self.netJettonRemand + 1 ] = bodyData
        end
        local all_user_bet = 0
        for index_j = 1,15 do
            all_user_bet = all_user_bet + bodyData.lBet[index_j]
        end
        self.model:setAllUserBetNumber(self.model:getAllUserBetNumber() + all_user_bet)
        --更新所有的押注面板
        self.model:setAreaTotalBetArray(bodyData.lTotalJetton)
        --print("--jetton-1->",bodyData.lTotalJetton[1])
        TreeEventDispatcher:dispatchEvent(Tree.Event.gameBetContinue,bodyData)
    end
end
function SlwhController:_onMsgGameBetContinue(bodyData)
    --print("SlwhController:onMsgGameBet->")
    if bodyData.cbRet == Tree.JettonRetType.RetType_Success then

        local playerId = Hero:getWChairID()
        local userId = bodyData.wChairID

        if playerId == userId then
            self.model:setAreaUserBetArray(bodyData.lBet)
            self.model:setCurAreaUserBetOrder(bodyData.lBet)
        end
        --self.model:setAreaTotalBetArray(bodyData.lTotalJetton)
        --TreeEventDispatcher:dispatchEvent(Tree.Event.gameBetContinue,bodyData)
    end
end
--游戏刷新状态
function SlwhController:onMsgRefreshStatus(bodyData)
    self.model:setUserGameStatus(bodyData.cbStatus)
    self.model:setRemindTime(bodyData.cbTimeLeave)

    TreeEventDispatcher:dispatchEvent(Tree.Event.gameStatusRefresh,bodyData)

    if bodyData.cbStatus == Tree.Status.Wait or bodyData.cbStatus == Tree.Status.Over then
        local t = {}
        for k = 1, 15, 1 do 
            t[k] = 0
        end
        self.model:setAreaTotalBetArray(t)
        TreeEventDispatcher:dispatchEvent(Tree.Event.closeJettonView,bodyData)
    end
    --如果是空闲状态
    if bodyData.cbStatus == Tree.Status.Wait then
            --清空状态
        self.model:setIsJettonContinue(false)
        self.model:setUserScoreOnStrat(Hero:getUserScore())
        self.model:setAllUserBetNumber(0)--clear
        Hero:setUserFakeScore(0,false,true)
        TreeEventDispatcher:dispatchEvent(Tree.Event.gameWait,bodyData)
    end
    --print("onMsgRefreshStatus---->",bodyData.cbStatus)
end
--下注失败/撤销押注
function SlwhController:onMsgGameFailed(bodyData)
    --print("SlwhController:onMsgGameFailed->")
    if bodyData.wChairID == Hero:getWChairID() then
        local user_jetton = self.model:getAreaUserBetArray()
        for index = 1, 15 do
            user_jetton[index] = 0
        end
        self.model:setAreaUserBetArray(user_jetton)
        --self.model:setAreaUserBetArray(bodyData.lJettonScore)--自己的都是0
        self.model:setCurAreaUserBetOrder({})
        self.model:setCanJettonContinue(true)
        self.model:setUserTotalJetton(0)
        Hero:setUserFakeScore( 0, false, true )
        --撤销后,将玩家下注的分数增加上
        local player_bets = 0
        for index_j = 1,15 do
            player_bets = player_bets + bodyData.lJettonScore[index_j]
        end
        local user_score = Hero:getUserScore()

        Hero:setUserScore(user_score, true)
    end
    self.model:setAreaTotalBetArray(bodyData.lPlayerJettoned)
    --当前的所有玩家的下注总额,
    local all_user_bet = 0
    for index_j = 1,15 do
        all_user_bet = all_user_bet + bodyData.lPlayerJettoned[index_j]
    end
    self.model:setAllUserBetNumber(all_user_bet)
    TreeEventDispatcher:dispatchEvent(Tree.Event.cancelAllBets,bodyData)

    --print("-------------cancel---jetton----------->",bodyData)
    --print("f--jetton-1->",bodyData.lPlayerJettoned[1])
end

function SlwhController:onGameSceneByServer(bodyStr)

    self.netJetton = {}
    self.netJettonRemand = {}
    --dump("Reconnected !!!!!")

    local bodyProtocol = ffiMgr:castStruct2TableByLuaStr(bodyStr, "SLWH_CMD_S_GameScene")
    --玩家可下注的筹码数组
    self.model:setCellScoreArray(bodyProtocol.lJettonConfig)
    self:dynamicGlobalConfig()
    --玩家的状态
    self.model:setUserGameStatus(bodyProtocol.cbStatus)
    --剩余时间
    self.model:setRemindTime(bodyProtocol.cbTimeLeave)
    --玩家自己各个区域的下注综合
    self.model:setAreaUserBetArray(bodyProtocol.lPlayerJettoned)
    --下注区域的倍数
    self.model:setAreaBetMultiplyArray(bodyProtocol.nJettonAreaTimes)
    --各个区域所有玩家的下注总和
    self.model:setAreaTotalBetArray(bodyProtocol.lJettoned)
    --玩家获取的奖励
    self.model:setUserReward(bodyProtocol.tAward)
    --玩家获奖历史记录
    self.model:setHistoryRewards(bodyProtocol.tAwardRecord)
    --玩家的总的下注分数
    local user_total_jetton = 0
    for idx = 1,15 do
        user_total_jetton = user_total_jetton + bodyProtocol.lJettoned[idx]
    end
    self.model:setAllUserBetNumber(user_total_jetton)
    if(false == SLWH_AFTER_WITHDRAWAL_CAN_BET) then 
        self.model:setSelfBetStartMoney(Hero:getUserScore())
        self.model:setSelfBetStartMoneyTemp(Hero:getUserScore())
    end
    --user score -- player bet score
    local player_bets = 0
    for index_j = 1, 15 do
        player_bets = player_bets + bodyProtocol.lPlayerJettoned[index_j]
    end
    self.model:setUserTotalJetton(player_bets)
    self.model:setUserRealyScore(Hero:getUserScore())
    --从玩家身上减掉已经下注的分数
    -- local user_score = Hero:getUserScore()
    -- Hero:setUserScore(user_score - player_bets)

    --dump( self.model:getUserGameStatus() )

    if not (self.model:getUserGameStatus() == Tree.Status.Play) then
        Hero:setUserFakeScore(0,true)
    end

    self.model:setUserScoreOnStrat(Hero:getUserScore())
    TreeEventDispatcher:dispatchEvent(Tree.Event.loadScene,bodyProtocol)

end

function SlwhController:onUserStatus(userData, oldUserData)
    local bodyStatus = userData
end

function SlwhController:onUserEnter(bodyData)
--    local hero_chairID = Hero:getWChairID() 
--    if bodyData.wChairID == hero_chairID then
--        --这里处理开奖阶段断线重连玩家分数的同步问题
--        if self.model:getUserGameStatus() == Tree.Status.Over and self.model:getUserTotalJetton() > 0 then
--            Hero:setUserScore(self.model:getUserRealyScore())
--        end
--    end
end

function SlwhController:onSystemMessage(data)
	if bit.band(data.wType, SMT_CLOSE_GAME) ~= 0 then
        if self._isEnterScene then
		    self.isFromCloseGame = true
		    self:gotoBankOrCharge(data.szString)
        else
            self:setWentToBank(true,data.szString)
        end
	elseif bit.band(data.wType, SMT_EJECT) ~= 0 then
		popupMgr:showConfirm(data.szString)
	elseif bit.band(data.wType, SMT_PROMPT) ~= 0 then
		tweenMsgMgr:showMsg(data.szString)
	end
end
--消息处理
function SlwhController:onGameMessage(binaryMsg, subCmdId)
    local protocol = self._protocol[subCmdId]
    local need_dispatch = true
    if self._isEnterForeground then
        need_dispatch = false
        if subCmdId == SLWH_SUB_S_REFRESH_STATUS then
            need_dispatch = true
        end
        --记录上一次的协议
        self._gameProtocolLast = {
            protocol = protocol,
            subCmdId = subCmdId,
            binaryMsg = binaryMsg,
        }
    end
    --print("process protocol-->",subCmdId)
    --需要再游戏刚进入前台后过滤某些协议,否则游戏跟卡死了一样
    if protocol and need_dispatch then
        local msgBody = binaryMsg
         if protocol.messageName and ffiMgr:isSizeEqual(binaryMsg, protocol.messageName) then 
             msgBody = ffiMgr:castStruct2TableByLuaStr(binaryMsg,protocol.messageName)
             protocol.func(self,msgBody)
             --print(protocol.messageName)
        end 
    end
end

--退出游戏
function SlwhController:resetBattle()
    self._currentIndex = 1
    self._preIndex = 1
    self._isEnterForeground = false
    self._gameProtocolLast = nil
    --停止当前的背景音乐
    --audioMgr:playMainMusic()
    --如果是正式服上,有可能只有一个房间,此时退出函数的调用顺序就会错乱
    local gameKind = self.model:getGameKind()
    local serverVos = gameMgr:getServerVosDicEx()
    local num = serverVos[gameKind] and table.nums(serverVos[gameKind]) or 0
    if num > 1 then
        self:playMusic(Tree.Sound.roomBgSound)
    else
        audioMgr:playMainMusic()
    end
    --停止所有的音效
    audioMgr:stopAllEffects()
    --self.model:setIsGameInit(false)
    --TreeEventDispatcher:dispatchEvent(Tree.Event.battleReset)
    --self.model:setBroadcastAwardData({})
    self.model:setIsShowingExit(false)
    self.model:setIsShowingJetton(false, true)
    self.model:setPreAreaUserBetOrder({})
    self.model:setUserTotalJetton(0)
    self.model:setAllUserBetNumber(0)
    Hero:setUserFakeScore(0, true)
    if( false == SLWH_AFTER_WITHDRAWAL_CAN_BET ) then 
        self.model:setSelfBetStartMoney(0)
        self.model:setSelfBetStartMoneyTemp(0)
    end
    local t = {}
    for k = 1, 15, 1 do 
        t[k] = 0
    end
    self.model:setAreaTotalBetArray(t)
    --取消自动续押
    self.model:setIsAutoJetton(false)
    self.model:setIsJettonContinue(false)
    TreeEventDispatcher:dispatchEvent(Tree.Event.closeGame)
end
--退出房间
function SlwhController:exitGame(callback)
    BaseGameController.exitGame(self,callback)
    --删除粒子系统缓存
    if cc.ParticleSystemCache then
        cc.ParticleSystemCache:getInstance():removeAllParticles()
    end
    --删除骨骼动画缓
    if sp.SkeletonAnimation.removeAllSkeletonData  then 
        sp.SkeletonAnimation:removeAllSkeletonData()
    end
    audioMgr:playMainMusic()
    --恢复引擎中被关闭的功能
    mainMgr:onRestartTick2Gc()
    TreeCacheManager:onDestroy()
    --ProxySlwh:hide(callback)
    self._preIndex = 1
    self._currentIndex = 1
    self._isEnterForeground = false
    self._gameProtocolLast = nil
    cc.Director:getInstance():setDisplayStats(false)
end

function SlwhController:destroy()
    self.model = nil;
end

function SlwhController:setWentToBank(b,string_display)
    --GameEvent.whNd_Main_Sub_CM_System
    self._isWentToToBank = b
    self._showBankString = string_display
end

function SlwhController:isWentToBank()
    return self._isWentToToBank
end

function SlwhController:doWentToBank()
    if self._isWentToToBank then
        self.isFromCloseGame = true
	    self:gotoBankOrCharge(self._showBankString)
        self._isWentToToBank = nil
    end
end

function SlwhController:processAssets(isEnterBattle)

	local isUseCommonHall = self.model:getIsUseCommonHall()
	
	local function doEnterBattle()
		if isUseCommonHall or isEnterBattle then
			self.model:setCurShowingViewType(VIEW_TYPE_BATTLE)	
			self:recoverServerMsgs()
        else
            --清空gamescene信息,以下两步必须得有,否则会产生服务器发过来的消息一直缓存着的bug
	        gameMgr:setGameStackMsgs({})
	        gameMgr:setNeedStoreGameStackMsg(false)
		end
        self:registerListeners()
        --print("---enter--->register")
	end

	if isUseCommonHall then
		--公用大厅，没有loading
		doEnterBattle()
	else
		self:updateLoading(100, self.model:getLoadingDuration(), isEnterBattle, nil, doEnterBattle);
	end
    mainMgr:onStopTick2Gc()
	self:processResource(nil)
end
--登陆房间完毕
function SlwhController:onRoomLoginFinish()
    gameMgr:setGameStackMsgs({})
	gameMgr:setNeedStoreGameStackMsg(false)
end

function SlwhController:onNetMessageCabcelCache()
    --清空gamescene信息,以下两步必须得有,否则会产生服务器发过来的消息一直缓存着的bug
	gameMgr:setGameStackMsgs({})
	gameMgr:setNeedStoreGameStackMsg(false)
end
--获取上一局下注
function SlwhController:getOrCreateJettonMap(roomKind)
    return TableUtil.copyDataDep(self.model:getPreAreaUserBetOrder())
end

function SlwhController:savePreJettonMap()
    for k, v in pairs( self.model:getCurAreaUserBetOrder() or {} ) do 
        if( v and 0 < v ) then 
            self.model:setPreAreaUserBetOrder(self.model:getCurAreaUserBetOrder())
            self.model:setCurAreaUserBetOrder({})
            return
        end
    end
    -- self.model:setPreAreaUserBetOrder(self.model:getCurAreaUserBetOrder())
    -- self.model:setCurAreaUserBetOrder({})
end

function SlwhController:onEnterBackground()
    BaseGameController.onEnterBackground(self)
    TreeEventDispatcher:dispatchEvent(Tree.Event.enterBackghround)
end

function SlwhController:onEnterForeground()
    BaseGameController.onEnterForeground(self)
    self._isEnterForeground = true
    TreeEventDispatcher:dispatchEvent(Tree.Event.enterForeground)
end

function SlwhController:dynamicGlobalConfig()
    Tree.BetScoreBaseConfig = self.model:getCellScoreArray()
    SLWH_FLY_BET_SP_CONFIG = 
    {
        [ Tree.BetScoreBaseConfig[1]*SLWH_BET_SCORE_RATE_DATA ] = "slwh_jetton_small_bet_1.png",
        [ Tree.BetScoreBaseConfig[2]*SLWH_BET_SCORE_RATE_DATA ] = "slwh_jetton_small_bet_2.png",
        [ Tree.BetScoreBaseConfig[3]*SLWH_BET_SCORE_RATE_DATA ] = "slwh_jetton_small_bet_3.png",
        [ Tree.BetScoreBaseConfig[4]*SLWH_BET_SCORE_RATE_DATA ] = "slwh_jetton_small_bet_4.png",
        [ Tree.BetScoreBaseConfig[5]*SLWH_BET_SCORE_RATE_DATA ] = "slwh_jetton_small_bet_5.png",
    }
    SLWH_FLY_BET_SCORE_CONFIG = 
    {
        [ Tree.BetScoreBaseConfig[1]*SLWH_BET_SCORE_RATE_DATA ] = "#slwh_jetton_bet_small_1_%s.png",
        [ Tree.BetScoreBaseConfig[2]*SLWH_BET_SCORE_RATE_DATA ] = "#slwh_jetton_bet_small_2_%s.png",
        [ Tree.BetScoreBaseConfig[3]*SLWH_BET_SCORE_RATE_DATA ] = "#slwh_jetton_bet_small_3_%s.png",
        [ Tree.BetScoreBaseConfig[4]*SLWH_BET_SCORE_RATE_DATA ] = "#slwh_jetton_bet_small_4_%s.png",
        [ Tree.BetScoreBaseConfig[5]*SLWH_BET_SCORE_RATE_DATA ] = "#slwh_jetton_bet_small_5_%s.png",
    }
    SLWH_BET_BTN_IDX = 
    {
        [ Tree.BetScoreBaseConfig[1]*SLWH_BET_SCORE_RATE_DATA ] = 1,
        [ Tree.BetScoreBaseConfig[2]*SLWH_BET_SCORE_RATE_DATA ] = 2,
        [ Tree.BetScoreBaseConfig[3]*SLWH_BET_SCORE_RATE_DATA ] = 3,
        [ Tree.BetScoreBaseConfig[4]*SLWH_BET_SCORE_RATE_DATA ] = 4,
        [ Tree.BetScoreBaseConfig[5]*SLWH_BET_SCORE_RATE_DATA ] = 5,
    }
end