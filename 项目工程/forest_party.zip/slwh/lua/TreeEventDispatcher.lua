--
-- Author: xiaoxiong
-- Date: 2017年11月21日 11:32:08
--
TreeEventDispatcher = TreeEventDispatcher or {}

local echoError = print
function TreeEventDispatcher:init()
    self._eventListenerArr = {}
    self._objectEvent = {}
end
--侦听一个消息						消息名称, 侦听函数	 
--[[	
	obj 如果有obj表示侦听的是实例方法  否则就是静态方法 到时清除侦听的依据就会依据这个obj

	prior 优先级，数越大优先级越高, 优先级相同先注册的大于后注册的 eg: prior = 4 先于 prior = 2 执行 默认值是0
	isSwallowEvent 是否拦截这个事件，优先级在它之下的注册将收不到事件 默认是fase不拦截
]]
function TreeEventDispatcher:addEventListener(eventName, listener, obj, prior, isSwallowEvent)
	isSwallowEvent = isSwallowEvent or false;
	prior = prior or 0;

	if not eventName then
		echoError("注册的是空事件")
		return
	end
    --如果没有相关的事件队列,创建队列
	if not self._eventListenerArr[eventName] then
		self._eventListenerArr[eventName] = {}
	end
	if not obj then
		echoError("没有注入对象")
		return
	end
	if not listener then
		echoError("没有注入函数")
		return
	end
	local arr =  self._eventListenerArr[eventName]
    local index = 1
    --检测是否重复了,顺便检测应该插入的顺序
	for i=1,#arr do
		if arr[i][1] == listener and arr[i][2] == obj then
			return
		end
        if prior >= arr[i][3] then
            index = i
        end
	end
    --在没有重复的情况下将事件监听器插入到相关的队列中s
	table.insert(arr, index,{listener, obj, prior, isSwallowEvent});
    --建立快速查找表,方便快速删除对象的监听器
    if not self._objectEvent[obj] then
        self._objectEvent[obj] = {}
    end
    self._objectEvent[obj][eventName] = true
end

--发送一个消息eventName消息名称	params消息参数(任意类型,消息参数 返回在event.param里面)
function TreeEventDispatcher:dispatchEvent(eventName,param)
	--检测是否有相关的事件队列
	local eventArr = self._eventListenerArr[eventName]
	if not eventArr or #eventArr == 0 then
		return
	end
	local info 
	for i=#eventArr,1,-1 do
		info = eventArr[i]
		--这里可能会出现 在回调函数里面 移除了另外的对象注册的 这个事件,然后 就会报错
		if info then
			if type(info[2])=="userdata" and tolua.isnull(info[2]) then --obj
				echo("target is null so clear Event,uiname:",eventName)
				table.remove(eventArr,i)
			else
				info[1](info[2],param,eventName)
			end
            --如果事件被吞噬了
			if info[4] == true then 
				break;
			end 
		end
	end
end

--如果带obj表示清除的是 实例方法 否则清除的是 静态方法 区分标准就是是否  侦听事件的时候 会传入self
function TreeEventDispatcher:removeEventListener( eventName,listener,obj )
    --检测是否有对象的事件监听器
    if not self._objectEvent[obj] or not self._objectEvent[obj][eventName] then
        return
    end
	local eventArr = self._eventListenerArr[eventName]
	if not eventArr or #eventArr ==0 then
		return
	end
	local info
	for i=#eventArr,1,-1 do
		info = eventArr[i]
		if info[2] ==  obj and info[1] == listener then
			table.remove(eventArr,i)
		end
	end
    --如果相关的事件队列为空,移除掉这个事件队列
    if #eventArr <= 0 then
        self._eventListenerArr[eventName] = nil
    end
end

--清除某个对象 在 EventDispatcher注册的侦听
function TreeEventDispatcher:clearOneObjEvent( obj )
    --检测是否存在有关对象的事件监听器
    local objectEvent = self._objectEvent[obj]
    if not objectEvent then return end
	for k,v in pairs(objectEvent) do
		local eventArr = self._eventListenerArr[ k ]
        if eventArr then
		    for i=#eventArr,1,-1 do
			    local info = eventArr[i]
			    if info[2] == obj then
				    table.remove(eventArr,i)
			    end
		    end
        end
        --删除事件队列,如果该队列为空
        if eventArr and #eventArr <= 0 then
            self._eventListenerArr[k] = nil
        end
	end
    self._objectEvent[obj] = nil
end

--清除某一种类型的事件
function TreeEventDispatcher:clearEvent( eventName )
	self._eventListenerArr[eventName] = nil
end
--初始化注册一个事件 这里既可以采用全局侦听 也可以给某个对象自己注册侦听
function TreeEventDispatcher:initEvent( )
	self._eventListenerArr = {}
end
--清除所有事件
function TreeEventDispatcher:clearAllEvent(  )
	self._eventListenerArr = {}
end
