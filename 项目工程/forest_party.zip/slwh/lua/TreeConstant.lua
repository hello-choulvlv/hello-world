--森林舞会数值/字符串常量
--2018年11月23日
--@author:xiaoxiong
Tree = Tree or {}
Tree.root = "res/gameres/module/slwh/"
--场景中的模型的摄像机标志
Tree.CameraFlag = 4
--场景中摆放的模型的数目
Tree.ModelNumber = 24
--位置/角度常量
Tree.ZeroPosition = {x=0,y=0,z=0}
--旋转动作的tag
Tree.TagGameOverStart = 0x66
Tree.TagColorSequenceChanged = 0x67
Tree.TagStopSound = 0x68
Tree.TagLightColorChanged = 0x69
Tree.TagNodeBrick = 0x71
Tree.TagStagePointer = 0x72
Tree.TagActNode = 0x73
Tree.TagActNodeSound = 0x74
Tree.TagAnimalModel = 0x75
Tree.TagLightModelChanged = 0x76
Tree.TagNodeSceneReward = 0x77
Tree.TagSceneRotateContinue = 0x78
Tree.TagCamera = 0x79
Tree.TagTV = 0x81
Tree.TagOther = 0x84
Tree.TagSongDengTV = 0x87
--跳跃动作Tag,编号在此基础上依次 +1
Tree.TagJumpBase = 0x90

SLWH_EACH_AREA_BET_MAX_COUNT = 10
SLWH_AFTER_WITHDRAWAL_CAN_BET = true              -- 当局取款后，是否继续下注
SLWH_LOAD_SCENE_MODEL_ONE_BY_ONE = true
SLWH_HIDE_MODELS_WHILE_JETTON = true
SLWH_BET_SHOW_WHITE_POINT = true
SLWH_MODEL_ONE_BY_ONE = 
{
    StaticModel = Tree.root .. "modelNew/slwh_sence.c3b",
    Plant1Model = Tree.root .. "modelNew/t_plant1_model.c3b",
    Plant2Model = Tree.root .. "modelNew/t_plant2_model.c3b",
    Plant3Model = Tree.root .. "modelNew/t_plant3_model.c3b",
    Plant4Model = Tree.root .. "modelNew/t_plant4_model.c3b",
    Plant5Model = Tree.root .. "modelNew/t_plant5_model.c3b",
    Plant1Mat = Tree.root .. "material/plant1.material",
    Plant2Mat = Tree.root .. "material/plant2.material",
    Plant3Mat = Tree.root .. "material/plant3.material",
    Plant4Mat = Tree.root .. "material/plant4.material",
    Plant5Mat = Tree.root .. "material/plant5.material",
}

--[[ ================ 下注面板配置  ================ ]]
SLWH_BET_SPRITE_CACHE_MAX = 500
SLWH_BET_SCORE_RATE_DATA  = 1                      --- 游戏金币数据汇率，方便移植
SLWH_BET_SCORE_RATE_VIEW  = 1                      --- 游戏金币界面汇率，方便移植
SLWH_MULTI_FONT = 
{
    "#slwh_jetton_red_multi_%s.png",
    "#slwh_jetton_red_multi_%s.png",
    "#slwh_jetton_red_multi_%s.png",
    "#slwh_jetton_red_multi_%s.png",
    "#slwh_jetton_yellow_multi_%s.png",
    "#slwh_jetton_yellow_multi_%s.png",
    "#slwh_jetton_yellow_multi_%s.png",
    "#slwh_jetton_yellow_multi_%s.png",
    "#slwh_jetton_green_multi_%s.png",
    "#slwh_jetton_green_multi_%s.png",
    "#slwh_jetton_green_multi_%s.png",
    "#slwh_jetton_green_multi_%s.png",
    "#slwh_jetton_blue_multi_%s.png",
    "#slwh_jetton_blue_multi_%s.png",
    "#slwh_jetton_blue_multi_%s.png",
}
SLWH_SELF_BET_FONT = 
{
    "#slwh_jetton_red_bet_%s.png",
    "#slwh_jetton_red_bet_%s.png",
    "#slwh_jetton_red_bet_%s.png",
    "#slwh_jetton_red_bet_%s.png",
    "#slwh_jetton_yellow_bet_%s.png",
    "#slwh_jetton_yellow_bet_%s.png",
    "#slwh_jetton_yellow_bet_%s.png",
    "#slwh_jetton_yellow_bet_%s.png",
    "#slwh_jetton_green_bet_%s.png",
    "#slwh_jetton_green_bet_%s.png",
    "#slwh_jetton_green_bet_%s.png",
    "#slwh_jetton_green_bet_%s.png",
    "#slwh_jetton_blue_bet_%s.png",
    "#slwh_jetton_blue_bet_%s.png",
    "#slwh_jetton_blue_bet_%s.png",
}
SLWH_OTHER_BET_FONT = 
{
    "#slwh_jetton_red_bet_other_%s.png",
    "#slwh_jetton_red_bet_other_%s.png",
    "#slwh_jetton_red_bet_other_%s.png",
    "#slwh_jetton_red_bet_other_%s.png",
    "#slwh_jetton_yellow_bet_other_%s.png",
    "#slwh_jetton_yellow_bet_other_%s.png",
    "#slwh_jetton_yellow_bet_other_%s.png",
    "#slwh_jetton_yellow_bet_other_%s.png",
    "#slwh_jetton_green_bet_other_%s.png",
    "#slwh_jetton_green_bet_other_%s.png",
    "#slwh_jetton_green_bet_other_%s.png",
    "#slwh_jetton_green_bet_other_%s.png",
    "#slwh_jetton_blue_bet_other_%s.png",
    "#slwh_jetton_blue_bet_other_%s.png",
    "#slwh_jetton_blue_bet_other_%s.png",
}
--ActionType
Tree.ActionType = {
    ActionType_Base = 0,
    ActionType_Jump = 1,
    ActionType_Callback = 2,
    ActionType_DelayTime = 3,
    ActionType_MoveBy = 4,
    ActionType_Sequence = 5,
    ActionType_Speed = 6,
    ActionType_SineOut = 7,
}
--loading时加载的资源类型
Tree.LoadingType = {
    LoadingType_Animation3D = 1,--3d模型动画
    LoadingType_Spine = 2,--Spine资源
    LoadingType_Sprite = 3,--Sprite对象
}
--游戏状态
Tree.Status = {
    Wait = 0,--等待开始
    Play = 100,--下注状态
    Over = 101,--结束
}
--下注返回数值类型
Tree.JettonRetType =
{
    RetType_Success = 0,--成功
    RetType_ReachAreaLimit = 1,--失败,达到该区域下注的上限
    RetType_ReachPersonalLimit = 2,--失败达到个人的下注上限
    RetType_ZhuangXianOnlyOne = 3,--庄闲不能同时下注
}
--奖励的类型
Tree.RewardType = {
    RewardType_None = 0,--无效的奖励
    RewardType_Normal = 1,--普通奖励
    RewardType_DaSanYuan = 2,--大三元
    RewardType_DaSiXi = 3,--大四喜
    RewardType_SongDeng = 4,--送灯
    RewardType_ShanDian = 5,--闪电
    RewardType_CaiJin = 6,--彩金
    RewardType_Max = 7,--类型总和
}
--牌的类型
Tree.CardType = {
    CardType_LionRed = 0,--红色的狮子
    CardType_PandaRed = 1,--红色的熊猫
    CardType_Monkey = 2, --红色的猴子
    CardType_Rabbit = 3,--红色的兔子

    CardType_LionYellow = 4,--黄色的狮子
    CardType_PandaYellow = 5,--黄色的熊猫
    CardType_MonkeyYellow = 6,--黄色的猴子
    CardType_RabbitYellow = 7,--黄色的兔子

    CardType_LionGreen = 8,--绿色的狮子
    CardType_PandaGreen = 9,--绿色的熊猫
    CardType_MonkeyGreen = 10,--绿色的猴子
    CardType_Rabbit = 11,--绿色的兔子

    CardType_Zhuang = 12, --庄
    CardType_He = 13,--和
    CardType_Xian = 14,--闲
    CardType_Max = 15,--牌类型总和
}
--模型的类型
Tree.ModelType = {
    ModelType_Lion = 1,--狮子
    ModelType_Panda = 2,--熊猫
    ModelType_Monkey = 3,--猴子
    ModelType_Rabbit = 4,--兔子
    ModelType_Multi2 = 5,
    ModelType_Multi3 = 6,
    ModelType_Caijin = 7,
    ModelType_SongDeng = 8,
    ModelType_DaSanYuan = 9,
    ModelType_DaSiXi = 10,
}
--模型的路径
Tree.ModelPath = {
    [Tree.ModelType.ModelType_Lion] = Tree.root .. "model/shizi/shizi_moxing.c3b",
    [Tree.ModelType.ModelType_Panda] = Tree.root .. "model/xiongmao/xiongmao_moxing.c3b",
    [Tree.ModelType.ModelType_Monkey] = Tree.root .. "model/houzi/houzi_moxing.c3b",
    [Tree.ModelType.ModelType_Rabbit] = Tree.root .. "model/tuzi/tuzi_moxing.c3b",
    [Tree.ModelType.ModelType_Multi2] = Tree.root .. "model/slwh_beishu2.c3b",
    [Tree.ModelType.ModelType_Multi3] = Tree.root .. "model/slwh_beishu3.c3b",
    [Tree.ModelType.ModelType_Caijin] = Tree.root .. "model/slwh_caijin.c3b",
    [Tree.ModelType.ModelType_SongDeng] = Tree.root .. "model/slwh_songdeng.c3b",
}
--模型动画的路径,常态动画
Tree.ModelActivityPath = {
    [Tree.ModelType.ModelType_Lion] = Tree.root .. "model/shizi/shizi_daiji.c3b",
    [Tree.ModelType.ModelType_Panda] = Tree.root .. "model/xiongmao/xiongmao_daiji.c3b",
    [Tree.ModelType.ModelType_Monkey] = Tree.root .. "model/houzi/houzi_daiji.c3b",
    [Tree.ModelType.ModelType_Rabbit] = Tree.root .. "model/tuzi/tuzi_daiji.c3b",
}
--跳跃动画
Tree.ModelJumpPath = {
    [Tree.ModelType.ModelType_Lion] = Tree.root .. "model/shizi/shizi_tiaoyue.c3b",
    [Tree.ModelType.ModelType_Panda] = Tree.root .. "model/xiongmao/xiongmao_tiaoyue.c3b",
    [Tree.ModelType.ModelType_Monkey] = Tree.root .. "model/houzi/houzi_tiaoyue.c3b",
    [Tree.ModelType.ModelType_Rabbit] = Tree.root .. "model/tuzi/tuzi_tiaoyue.c3b",
}
--获奖动画
Tree.ModelRewardPath = {
    [Tree.ModelType.ModelType_Lion] = Tree.root .. "model/shizi/shizi_zhongjiang.c3b",
    [Tree.ModelType.ModelType_Panda] = Tree.root .. "model/xiongmao/xiongmao_zhongjiang.c3b",
    [Tree.ModelType.ModelType_Monkey] = Tree.root .. "model/houzi/houzi_zhongjiang.c3b",
    [Tree.ModelType.ModelType_Rabbit] = Tree.root .. "model/tuzi/tuzi_zhongjiang.c3b",
}
--模型对应的金色效果的纹理路径
Tree.ModelTexture = {
    [Tree.ModelType.ModelType_Lion] = {--狮子
        [1] = Tree.root .. "model/shizi/shizi_D.png",--常规贴图
        [2] = Tree.root .. "model/gold/shizi.png",--金色狮子
    },
    [Tree.ModelType.ModelType_Panda] = {--熊猫
        [1] = Tree.root .. "model/xiongmao/xiongmao_D.png",--常规贴图
        [2] = Tree.root .. "model/gold/xiongmao.png",--金色
    },
    [Tree.ModelType.ModelType_Monkey] = {--猴子
        [1] = Tree.root .. "model/houzi/houzi.png",--常规贴图
        [2] = Tree.root .. "model/gold/houzi.png",--金色
    },
    [Tree.ModelType.ModelType_Rabbit] = {--兔子
        [1] = Tree.root .. "model/tuzi/tuzi.png",--常规贴图
        [2] = Tree.root .. "model/gold/tuzi.png",--金色
    },
}
--舞台的模型路径
Tree.PartyModelPath = {
    [Tree.RewardType.RewardType_Normal] = {--常态
        pointerModel = Tree.root .. "model/slwh_yuanshipoint.c3b",
        partyModel = Tree.root .. "model/slwh_yuanshistage.c3b",
    },
    [Tree.RewardType.RewardType_DaSanYuan] = {--大三元
        pointerModel = Tree.root .. "model/dasanyuan/slwh_dsystagepoint.c3b",
        partyModel = Tree.root .. "model/dasanyuan/slwh_dsystage.c3b",
    },
    [Tree.RewardType.RewardType_DaSiXi] = {--大四喜
        pointerModel = Tree.root .. "model/dasixi/slwh_dsxstagepoint.c3b",
        partyModel = Tree.root .. "model/dasixi/slwh_dsxstage.c3b",
    },
    [Tree.RewardType.RewardType_CaiJin] ={--彩金
        pointerModel = Tree.root .. "model/caijin/slwh_cjstagepoint.c3b",
        partyModel = Tree.root .."model/caijin/slwh_cjstage.c3b",
    },
}
--舞台动画的类型
Tree.PartyAnimationType = {
    AnimationType_Up = 1,--上升
    AnimationType_Normal = 2,--常态
    AnimationType_Down = 3,--下降
}
--舞台模型动画的信息
Tree.PartyModelAnimation = {
    --普通,彩金,闪电,送灯
    [Tree.RewardType.RewardType_Normal] = {
        [Tree.PartyAnimationType.AnimationType_Up] = {
            from = 0,to = 30,
        },
        [Tree.PartyAnimationType.AnimationType_Normal] = {
            from = 30,to = 60,
        },
        [Tree.PartyAnimationType.AnimationType_Down] = {
            from = 60,to = 90,
        },
    },
    --大三元
    [Tree.RewardType.RewardType_DaSanYuan] = {
        [Tree.PartyAnimationType.AnimationType_Up] = {
            from = 0, to = 16,
        },
        [Tree.PartyAnimationType.AnimationType_Normal] = {
            from = 16, to = 32,
        },
        [Tree.PartyAnimationType.AnimationType_Down] = {
            from = 32, to = 48,
        },
    },
    --大四喜
    [Tree.RewardType.RewardType_DaSiXi] ={
        [Tree.PartyAnimationType.AnimationType_Up] = {
            from = 0, to = 36,
        },
        [Tree.PartyAnimationType.AnimationType_Normal] = {
            from = 36, to = 52,
        },
        [Tree.PartyAnimationType.AnimationType_Down] = {
            from = 52, to = 64,
        },
    },
    --彩金
    [Tree.RewardType.RewardType_CaiJin] = {
        [Tree.PartyAnimationType.AnimationType_Up] = {
            from = 0, to = 20,
        },
        [Tree.PartyAnimationType.AnimationType_Normal] = {
            from = 120, to = 240,
        },
        [Tree.PartyAnimationType.AnimationType_Down] = {
            from = 20, to = 35,
        },
    },
}
--动画的类型
Tree.AnimationType = {
    AnimationType_Activity = 1,--活跃状态
    AnimationType_Jump = 2,--跳跃状态
    AnimationType_Reward = 3,--中奖状态
}
--滚动数字的对齐方式
Tree.AlignType = {
    AlignType_None = 0,--无类型
    AlignType_Left = 1,--左对齐
    AlignType_Right = 2,--右对齐
    AlignType_Center = 3,--居中对齐
}
--
Tree.Sound = {
    roomBgSound = "roomBg.mp3",--选房阶段背景音乐
    battleWaitBg = "battle_wait.mp3",--战斗,等待阶段音乐
    battleZhuanpan = "battle_zhuanpan.mp3",--转盘转动阶段
    --中奖时,某一个动物被选中时播放的背景音乐
    AwardSound = {
        [Tree.RewardType.RewardType_Normal] = {
            [Tree.ModelType.ModelType_Lion] = "zj_shizi_sound.mp3",--狮子
            [Tree.ModelType.ModelType_Panda] = "zj_xiongmao_sound.mp3",--熊猫
            [Tree.ModelType.ModelType_Monkey] = "zj_houzi_sound.mp3",--猴子
            [Tree.ModelType.ModelType_Rabbit] = "zj_tuzi_sound.mp3",--兔子
        },
        [Tree.RewardType.RewardType_DaSanYuan] = "zj_teshu_sound.mp3",--大三元
        [Tree.RewardType.RewardType_DaSiXi] = "zj_teshu_sound.mp3",--大四喜
        [Tree.RewardType.RewardType_SongDeng] = "zj_teshu_sound.mp3",--送灯
        [Tree.RewardType.RewardType_ShanDian] = "zj_teshu_sound.mp3",--闪电
        [Tree.RewardType.RewardType_CaiJin] = "zj_teshu_sound.mp3",--彩金
    },
    --动物播放获奖动画时的欢呼声
    AnimalPlayRewardEffect = {
        [Tree.ModelType.ModelType_Lion] = "hh_shizi_effect.mp3",--狮子
        [Tree.ModelType.ModelType_Panda] = "hh_xiongmao_effect.mp3",--熊猫
        [Tree.ModelType.ModelType_Monkey] = "hh_houzi_effect.mp3",--猴子
        [Tree.ModelType.ModelType_Rabbit] = "hh_tuzi_effect.mp3",--兔子
    },
    --动物被选中时的音效
    AnimalSelectEffect = {
        [Tree.ModelType.ModelType_Lion] = "xz_shizi_effect.mp3",--狮子
        [Tree.ModelType.ModelType_Panda] = "xz_xiongmao_effect.mp3",--熊猫
        [Tree.ModelType.ModelType_Monkey] = "xz_houzi_effect.mp3",--猴子
        [Tree.ModelType.ModelType_Rabbit] = "xz_tuzi_effect.mp3",--兔子
    },
    --庄闲和
    ZXHEffect = {
        [Tree.CardType.CardType_Zhuang] = "r3_zhuang_effect.mp3",--庄
        [Tree.CardType.CardType_He] = "r3_he_effect.mp3",--和
        [Tree.CardType.CardType_Xian] = "r3_xian_effect.mp3",--闲
    },
    --相关的颜色被选中时播放的音效
    ColorSelectEffect = {
        [1] = "color_hong_effect.mp3",--红色
        [2] = "color_huang_effect.mp3",--黄色
        [3] = "color_lv_effect.mp3",--绿色
    },
    --特殊奖励出现时播放的音效
    SpecialRewardEffect = {
        [Tree.RewardType.RewardType_DaSanYuan] = "r_dasanyuan_effect.mp3",--大三元
        [Tree.RewardType.RewardType_DaSiXi] = "r_dasixi_effect.mp3",--大四喜
        [Tree.RewardType.RewardType_SongDeng] = "r_songdeng_effect.mp3",--送灯
        [Tree.RewardType.RewardType_ShanDian] = "r_shandian_effect.mp3",--闪电
        [Tree.RewardType.RewardType_CaiJin] = "r_caijin_effect.mp3",--彩金
    },
    --下注面板自动弹出时音效
    XiaZhuMianBanEffect = "xiazhu_auto.mp3",
    --闪电劈下时播放的音效
    ShanDianEffect = "shandian_pixia_effect.mp3",
    --宝物破土而出时,此音效用在特殊玩法文字出现时
    RewardBreakOutEffect = "reward_breakout_effect.mp3",
    --旋转场景时,轮盘开始转动时播放的音效
    RotateSceneEffect = "rotate_scene_effect.mp3",
    --旋转场景结束时,播放的音效
    RotateSceneOverEffect = "rotate_scene_over_effect.mp3",

    BetScoreEffect1 = "betScoreEffect1.mp3",
    BetScoreEffect2 = "betScoreEffect2.mp3",
}
--Tree.AnimationInterval = 1.0/30
--模型动画的动作帧
Tree.ModelAnimation = {
    [Tree.ModelType.ModelType_Lion] = {--狮子
        [Tree.AnimationType.AnimationType_Activity] = {
            from = 0,to = 45,
        },
        [Tree.AnimationType.AnimationType_Jump] = {
            from = 0,to = 60,
        },
        [Tree.AnimationType.AnimationType_Reward] = {
            from = 0,to = 120,
        },
    },
    [Tree.ModelType.ModelType_Panda] = {--熊猫
        [Tree.AnimationType.AnimationType_Activity] = {
            from = 0,to = 45,
        },
        [Tree.AnimationType.AnimationType_Jump] = {
            from = 0,to = 60,
        },
        [Tree.AnimationType.AnimationType_Reward] = {
            from = 0,to = 120,
        },
    },
    [Tree.ModelType.ModelType_Monkey] = {--猴子
        [Tree.AnimationType.AnimationType_Activity] = {
            from = 0,to = 45,
        },
        [Tree.AnimationType.AnimationType_Jump] = {
            from = 0,to = 60,
        },
        [Tree.AnimationType.AnimationType_Reward] = {
            from = 0,to = 120,
        },
    },
    [Tree.ModelType.ModelType_Rabbit] = {--兔子
        [Tree.AnimationType.AnimationType_Activity] = {
            from = 0,to = 45,
        },
        [Tree.AnimationType.AnimationType_Jump] = {
            from = 0,to = 60,
        },
        [Tree.AnimationType.AnimationType_Reward] = {
            from = 0,to = 140,
        },
    },
}
--房间的入口动画
Tree.Room = {
    --体验场
    [1] = {
        [1] = {
            json = Tree.root .. "animation/slwh_tyc/slwh_tyxcbg.json",
            atlas = Tree.root .. "animation/slwh_tyc/slwh_tyxcbg.atlas",
        },
        [2] = {
            json = Tree.root .. "animation/slwh_tyc/slwh_tyxc.json",
            atlas = Tree.root .. "animation/slwh_tyc/slwh_tyxc.atlas",
        },
        [3] = {
            json = Tree.root .. "animation/slwh_tyc/slwh_tycgx.json",
            atlas = Tree.root .. "animation/slwh_tyc/slwh_tycgx.atlas",
        },
    },
    --初级场
    [2] = {
        [1] = {
            json = Tree.root .. "animation/slwh_cjc/slwh_cjxcbg.json",
            atlas = Tree.root .. "animation/slwh_cjc/slwh_cjxcbg.atlas",
        },
        [2] = {
            json = Tree.root .. "animation/slwh_cjc/slwh_cjxc.json",
            atlas = Tree.root .. "animation/slwh_cjc/slwh_cjxc.atlas",
        },
        [3] = {
            json = Tree.root .. "animation/slwh_cjc/slwh_cjxcgx.json",
            atlas = Tree.root .. "animation/slwh_cjc/slwh_cjxcgx.atlas",
        },
    },
    --普通场
    [3] = {
        [1] = {
            json = Tree.root .. "animation/slwh_ptc/slwh_ptxcbg.json",
            atlas = Tree.root .. "animation/slwh_ptc/slwh_ptxcbg.atlas",
        },
        [2] = {
            json = Tree.root .. "animation/slwh_ptc/slwh_ptxc.json",
            atlas = Tree.root .. "animation/slwh_ptc/slwh_ptxc.atlas",
        },
        [3] = {
            json = Tree.root .. "animation/slwh_ptc/slwh_ptxcgx.json",
            atlas = Tree.root .. "animation/slwh_ptc/slwh_ptxcgx.atlas",
        },
    },
    --中级场
    [4] = {
        [1] = {
            json = Tree.root .. "animation/slwh_zjc/slwh_zjxcbg.json",
            atlas = Tree.root .. "animation/slwh_zjc/slwh_zjxcbg.atlas",
        },
        [2] = {
            json = Tree.root .. "animation/slwh_zjc/slwh_zjxc.json",
            atlas = Tree.root .. "animation/slwh_zjc/slwh_zjxc.atlas",
        },
        [3] = {
            json = Tree.root .. "animation/slwh_zjc/slwh_zjxcgx.json",
            atlas = Tree.root .. "animation/slwh_zjc/slwh_zjxcgx.atlas",
        },
    },
    --高级场
    [5] = {
        [1] = {
            json = Tree.root .. "animation/slwh_gjc/slwh_gjxcbg.json",
            atlas = Tree.root .. "animation/slwh_gjc/slwh_gjxcbg.atlas",
        },
        [2] = {
            json = Tree.root .. "animation/slwh_gjc/slwh_gjxc.json",
            atlas = Tree.root .. "animation/slwh_gjc/slwh_gjxc.atlas",
        },
        [3] = {
            json = Tree.root .. "animation/slwh_gjc/slwh_gjxcgx.json",
            atlas = Tree.root .. "animation/slwh_gjc/slwh_gjxcgx.atlas",
        },
    },
}
--色块的纹理资源
Tree.BrickTexture = {
    [1] = {
        [1] = Tree.root .. "model/light/02_basecolor_01.png",
        [2] = Tree.root .. "model/light/02_basecolor_0_09.png",
    },
    [2] = {
        [1] = Tree.root .. "model/light/02_basecolor_03.png",
        [2] = Tree.root .. "model/light/02_basecolor_0_03.png",
    },
    [3] = {
        [1] = Tree.root .. "model/light/02_basecolor_02.png",
        [2] = Tree.root .. "model/light/02_basecolor_0_06.png",
    },
}
--砖块的黑色纹理
Tree.BrickBlackTexture = Tree.root .. "model/light/02_basecolor_04.png"
--森林舞会游戏中的事件
Tree.Event = {
    loadScene = "tree_event_load_scene",--加载场景
    gameWait = "tree_event_game_wait",--游戏进入空闲状态
    gameStart = "tree_event_game_start",--游戏开始
    gameOver = "tree_event_game_over",--游戏结束
    gameOverFromBack = "tree_event_game_over_from_back",--从游戏后台返回后,派发开奖协议事件
    gameBet = "tree_event_game_bet",--玩家下注结果返回
    gameBetContinue = "tree_event_game_bet_continue",--玩家下注结果返回
    gameStatusRefresh = "tree_event_game_status_refresh",--玩家游戏状态刷新
    jettonFailed = "tree_event_jetton_failed",--下注失败
    jettonCancel = "tree_event_jetton_cancel",--下注取消
    closeJettonView = "tree_event_close_jetton_view",--关闭下注面板
    cancelAllBets = "tree_event_cancel_all_bets",--下注取消
    closeGame = "tree_event_close_game",--退出游戏
    enterBackghround = "tree_event_enter_background",--切换入后台
    enterForeground = "tree_event_enter_foreground",--切换到前台
    queryGameStatus = "tree_event_query_game_status",--查询游戏的状态
    startJetton = "tree_event_start_jetton",--提示开始下注
    soundVolumChanged = "tree_event_sound_volum_changed",--背景音乐的音量发生变化
    userScoreChanged = "tree_event_user_score_changed",--玩家的分数发生变化
    showAllModels = "tree_event_show_all_models",
}
--开奖阶段各个阶段的基本时间与加成时间
Tree.RewardTime = {
    [Tree.RewardType.RewardType_Normal] = 19,
    [Tree.RewardType.RewardType_DaSanYuan] = 30,
    [Tree.RewardType.RewardType_DaSiXi] = 35,
    [Tree.RewardType.RewardType_SongDeng] = 15,
    [Tree.RewardType.RewardType_ShanDian] = 19,
    [Tree.RewardType.RewardType_CaiJin] = 19,
}
--送灯需要加上额外的时间
Tree.RewardSongDengTime = 3.2
--下注面板中数字的模板分类
Tree.JettonFrames= {
    [1] = {--红色
        [1] = "red_1_number_%s",
        [2] = "red_2_number_%s",
        [3] = "red_3_number_%s",
    },
    [2] = {--黄色
        [1] = "yellow_1_number_%s",
        [2] = "yellow_2_number_%s",
        [3] = "yellow_3_number_%s",
    },
    [3] = {--绿色
        [1] = "green_1_number_%s",
        [2] = "green_2_number_%s",
        [3] = "green_3_number_%s",
    },
}
--每一个数字对应的颜色
Tree.JettonColorMap = {
    [1] = "red",
    [2] = "red",
    [3] = "red",
    [4] = "red",

    [5] = "yellow",
    [6] = "yellow",
    [7] = "yellow",
    [8] = "yellow",

    [9] = "green",
    [10] = "green",
    [11] = "green",
    [12] = "green",

    [13] = "blue",
    [14] = "blue",
    [15] = "blue",
}
--下注面板中按钮使用的数字frame_name映射表
Tree.JettonNumbers = {
    --红色数字
    [1] = Tree.JettonFrames[1],
    [2] = Tree.JettonFrames[1],
    [3] = Tree.JettonFrames[1],
    [4] = Tree.JettonFrames[1],
    --黄色数字
    [5] = Tree.JettonFrames[2],
    [6] = Tree.JettonFrames[2],
    [7] = Tree.JettonFrames[2],
    [8] = Tree.JettonFrames[2],
    --绿色数字
    [9] = Tree.JettonFrames[3],
    [10] = Tree.JettonFrames[3],
    [11] = Tree.JettonFrames[3],
    [12] = Tree.JettonFrames[3],
    --庄闲和比较特殊
    [13] = Tree.JettonFrames[1],
    [14] = Tree.JettonFrames[2],
    [15] = Tree.JettonFrames[3],
}
Tree.CameraScale = display.height/CONFIG_DESIGN_HEIGHT
--场景模型坐标位置信息
Tree.SceneLocation = {
    Camera = {
		eyePosition = {x = 0.0,y = 226.2 * Tree.CameraScale,z = 314.2 * Tree.CameraScale,},
		startAngle = -39.2,
		finalPosition = {x = 0.0,y = 101.7 * Tree.CameraScale,z = 180.2 * Tree.CameraScale,},
		finalAngle = -28.7,
    },
    --送灯专用摄像机,位置上没有任何的变化
    Camera2 = {
		eyePosition = {x = 0.0,y = 226.2 * Tree.CameraScale,z = 314.2 * Tree.CameraScale,},
		startAngle = -39.2,
		finalPosition = {x = 0.0,y = 138.0 * Tree.CameraScale,z = 206.0 * Tree.CameraScale,},
		finalAngle = -33.0,
    },
    --中间位置,大三元,大四喜,送灯
    CameraBetween = {
        middlePosition = {x =0.0,y = 299.2 * Tree.CameraScale,z=255.7 * Tree.CameraScale,},
        middleAngle = {x=-54.6, y=0,z=0},
    },
    --舞台粒子,辉光的位置
    ParticleLocation = {
        [Tree.RewardType.RewardType_Normal] = {x = 0.0,y = -18.0,z = 0.0,},
        [Tree.RewardType.RewardType_DaSanYuan] = {x=0,y=1,z=0},
        [Tree.RewardType.RewardType_DaSiXi] = {x=0,y=0,z=0},
        [Tree.RewardType.RewardType_SongDeng] = {x = 0.0,y = -18.0,z = 0.0},
        [Tree.RewardType.RewardType_ShanDian] = {x = 0.0,y = -18.0,z = 0.0,},
        [Tree.RewardType.RewardType_CaiJin] = {x = 0.0,y = 1.0,z = 0.0,},
    },
    --庄和闲Model的位置
    TVModel = {x = 0.0,y = 108.0,z = -184.0,},
    --最终模型的站立位置
    Location = {
        --普通获奖类型
	    [Tree.RewardType.RewardType_Normal]= {
		    [1] = {x = 0.0,y = -18.0,z = 0.0,},
	    },
        --大三元
	    [Tree.RewardType.RewardType_DaSanYuan] = {
		    [1] = {x = 0.0,y = -18.0,z = 0.0,},
		    [2] = {x = 60.0,y = -18.0,z = 0.0,},
		    [3] = {x = -60.0,y = -18.0,z = 0.0,},
	    },
        --大四喜
	    [Tree.RewardType.RewardType_DaSiXi] = {
		    [1] = {x = -32.0,y = -18.0,z = 0.0,},
		    [2] = {x = -84.0,y = -18.0,z = 0.0,},
		    [3] = {x = 32.0,y = -18.0,z = 0.0,},
		    [4] = {x = 84.0,y = -18.0,z = 0.0,},
	    },
        --闪电
        [Tree.RewardType.RewardType_ShanDian] = {
            [1] = {x = 0.0,y = -18.0,z = 0.0,},
        },
        --彩金
        [Tree.RewardType.RewardType_CaiJin] = {
            [1] = {x = 0.0,y = 1.0,z = 0.0,},
        },
        --送灯,与上面的配置不同,送灯包含了多种选项
        [Tree.RewardType.RewardType_SongDeng] = {
            [1] = {
                [1] = {x = 0.0,y = -18.0,z = 0.0,},
            },
            [2] = {
		        [1] = {x = -30.0,y = -18.0,z = -3.3,},
		        [2] = {x = 30.0,y = -18.0,z = -3.3,},
            },
            [3] = {
		        [1] = {x = 0.0,y = -18.0,z = 0.0,},
		        [2] = {x = 60.0,y = -18.0,z = 0.0,},
		        [3] = {x = -60.0,y = -18.0,z = 0.0,},
            },
            [4] = {
		        [1] = {x = -32.0,y = -18.0,z = 0.0,},
		        [2] = {x = -84.0,y = -18.0,z = 0.0,},
		        [3] = {x = 32.0,y = -18.0,z = 0.0,},
		        [4] = {x = 84.0,y = -18.0,z = 0.0,},
            },
            [5] = {
		        [1] = {x = -33.0,y = -18.0,z = 66.0,},
		        [2] = {x = 0.0,y = -18.0,z = -40.0,},
		        [3] = {x = -70.0,y = -18.0,z = 0.0,},
		        [4] = {x = 70.0,y = -18.0,z = 0.0,},
		        [5] = {x = 33.0,y = -18.0,z = 66.0,},
            },
            [6] = {
		        [1] = {x = -25.6,y = -18.0,z = 57.8,},
		        [2] = {x = -28.2,y = -18.0,z = -41.4,},
		        [3] = {x = 27.9,y = -18.0,z = -43.4,},
		        [4] = {x = -58.6,y = -18.0,z = 4.0,},
		        [5] = {x = 57.7,y = -18.0,z = 7.5,},
		        [6] = {x = 25.4,y = -18.0,z = 56.8,},
            },
            [7] = {
		        [1] = {x = -39.4,y = -18.0,z = -53.7,},
		        [2] = {x = 39.4,y = -18.0,z = -53.7,},
		        [3] = {x = -80.5,y = -18.0,z = 0.5,},
		        [4] = {x = 80.5,y = -18.0,z = 0.5,},
		        [5] = {x = 61.1,y = -18.0,z = 60.9,},
		        [6] = {x = -61.1,y = -18.0,z = 60.9,},
		        [7] = {x = 0.3,y = -18.0,z = 68.0,},
            },
            [8] = {
		        [1] = {x = -51.7,y = -18.0,z = -43.5,},
		        [2] = {x = 0.0,y = -18.0,z = -68.5,},
		        [3] = {x = 51.7,y = -18.0,z = -43.5,},
		        [4] = {x = -58.3,y = -18.0,z = 65.4,},
		        [5] = {x = -84.4,y = -18.0,z = 11.5,},
		        [6] = {x = 58.0,y = -18.0,z = 65.3,},
		        [7] = {x = 84.4,y = -18.0,z = 11.5,},
		        [8] = {x = 0.1,y = -18.0,z = 70.0,},
            },
            [9] = {
		        [1] = {x = -54.4,y = -18.0,z = 65.2,},
		        [2] = {x = 54.4,y = -18.0,z = 65.2,},
		        [3] = {x = 44.9,y = -18.0,z = -60.5,},
		        [4] = {x = -44.9,y = -18.0,z = -60.8,},
		        [5] = {x = -80.7,y = -18.0,z = 0.0,},
		        [6] = {x = 80.6,y = -18.0,z = 0.0,},
		        [7] = {x = 31.3,y = -18.0,z = 0.0,},
		        [8] = {x = 0.0,y = -18.0,z = 60.9,},
		        [9] = {x = -31.3,y = -18.0,z = 0.0,},
            },
            [10] = {
		        [1] = {x = -46.9,y = -18.0,z = 57.8,},
		        [2] = {x = 52.1,y = -19.0,z = -51.8,},
		        [3] = {x = -52.3,y = -18.0,z = -52.2,},
		        [4] = {x = -82.9,y = -18.0,z = 0.4,},
		        [5] = {x = 80.1,y = -18.0,z = 0.2,},
		        [6] = {x = 48.5,y = -18.0,z = 57.9,},
		        [7] = {x = -39.6,y = -18.0,z = 0.9,},
		        [8] = {x = 37.0,y = -18.0,z = 0.2,},
		        [9] = {x = 0.6,y = -18.0,z = -19.8,},
		        [10] = {x = 0.3,y = -18.0,z = 31.1,},
            },
            [11] = {
		        [1] = {x = -48.6,y = -18.0,z = 48.5,},
		        [2] = {x = 52.1,y = -19.0,z = -51.8,},
		        [3] = {x = -52.3,y = -18.0,z = -52.2,},
		        [4] = {x = -82.9,y = -18.0,z = 0.4,},
		        [5] = {x = 80.1,y = -18.0,z = 0.2,},
		        [6] = {x = -0.7,y = -18.0,z = 81.7,},
		        [7] = {x = 48.9,y = -18.0,z = 48.1,},
		        [8] = {x = -39.6,y = -18.0,z = 0.9,},
		        [9] = {x = 37.0,y = -18.0,z = 0.2,},
		        [10] = {x = 0.2,y = -18.0,z = -13.4,},
		        [11] = {x = -0.1,y = -18.0,z = 35.6,},
            },
            [12] = {
		        [1] = {x = -55.8,y = -18.0,z = 48.9,},
		        [2] = {x = 55.6,y = -19.0,z = -48.4,},
		        [3] = {x = 0.3,y = -18.0,z = -83.2,},
		        [4] = {x = -55.5,y = -18.0,z = -48.5,},
		        [5] = {x = -82.9,y = -18.0,z = 0.4,},
		        [6] = {x = 80.1,y = -18.0,z = 0.2,},
		        [7] = {x = -0.7,y = -18.0,z = 81.7,},
		        [8] = {x = 54.7,y = -18.0,z = 49.8,},
		        [9] = {x = -39.6,y = -18.0,z = 0.9,},
		        [10] = {x = 37.0,y = -18.0,z = 0.2,},
		        [11] = {x = 0.1,y = -18.0,z = -37.4,},
		        [12] = {x = -0.1,y = -18.0,z = 35.6,},
            },
        },
    }
}
--下注面板中,15个筹码的目标中心点集合
Tree.JettonAreaPoints = {
    [1] = {x = -425.36,y = 144.73},
    [2] = {x= -195.38,y = 144.73},
    [3] = {x = 34.59,y = 144.73},
    [4] = {x = 264.56,y = 144.73},

    [5] = {x = -428.47,y = 4.91},
    [6] = {x = -198.50,y = 4.91},
    [7] = {x = 31.47,y = 4.91},
    [8] = {x = 261.45,y = 4.91},

    [9] = {x = -427.65,y = -136.22},
    [10] = {x = -197.68,y = -136.22},
    [11] = {x= 32.29,y = -136.22},
    [12] = {x = 262.27,y = -136.22},

    [13] = {x = 494.53,y = 144.73},
    [14] = {x = 491.42,y = 4.91},
    [15] = {x = 492.24,y = -136.22},
}
--下注面板中下方筹码的坐标
Tree.JettonBetPoints = {
    [1] = {x=-504.37,y = -247.79},
    [2] = {x = -353.01, y = -247.79},
    [3] = {x = -206.65,y = -247.79},
    [4] = {x = -58.29,y = -247.79},
    [5] = {x = 89.07,y = -247.79},
}
--下注面板上方头像的坐标
Tree.JettonHeadPoints = {
    [1] = {x = -412.73,y = 305.66},
    [3] = {x = -176.39,y = 306.44},
    [4] = {x = 46.59,y = 305.44},
    [2] = {x = 271.57,y = 306.44},
}
-----------------缓存结构中资源的信息----------------
--缓存对象的类型
Tree.ObjectType = {
    ObjectType_Cocos2dx = 1,--Cocos2dx-C++对象
    ObjectType_Lua = 2,--lua对象
}
Tree.CacheType = {
    CacheType_Spine     = 1,--Spine动画
    CacheType_Particle = 2,--Particle动画
    CacheType_Sprite     = 3,--Sprite
    CacheType_SpriteFrame = 4,--Sprite,create with sprite frame
    --
    CacheType_RollingText = 4, --作为一种lua对象使用
}
--森林舞會
Tree.CacheTemplate = {
    --奖励界面中的Spine
    ["spine_award_result"] = {--开奖结果
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_kjjg.json",
        atlas = Tree.root .. "effect/slwh_kjjg.atlas",
        cache = Tree.root .. "effect/slwh_kjjg",
        max_count = 2,
    },
    --大三元Spine
    ["spine_award_dasanyuan"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_dsy.json",
        atlas = Tree.root .. "effect/slwh_dsy.atlas",
        cache = Tree.root .. "effect/slwh_dsy",
        max_count = 2,
    },
    --大四喜Spine
    ["spine_award_dasixi"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_dsx.json",
        atlas = Tree.root .. "effect/slwh_dsx.atlas",
        cache = Tree.root .. "effect/slwh_dsx",
        max_count = 2,
    },
    --烟花
    ["spine_fire"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_yanhuaeffect.json",
        atlas = Tree.root .. "effect/slwh_yanhuaeffect.atlas",
        cache = Tree.root .. "effect/slwh_yanhuaeffect",
        max_count = 6,
    },
     --下注按钮spine
     ["spine_bet_btn"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_xzgd.json",
        atlas = Tree.root .. "effect/slwh_xzgd.atlas",
        cache = Tree.root .. "effect/slwh_xzgd",
        max_count = 5,
    },
    --战斗场景UI中,左侧的列表中出现的Spine动画
    ["spine_menuitem_show"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_xztxlg.json",
        atlas = Tree.root .. "effect/slwh_xztxlg.atlas",
        cache = Tree.root .. "effect/slwh_xztxlg",
        max_count = 2,
    },
    ["beishu_effect"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_beishueffect.json",
        atlas = Tree.root .. "effect/slwh_beishueffect.atlas",
        cache = Tree.root .. "effect/slwh_beishueffect",
        max_count = 1,
    },
    ["caijin_effect"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_caijineffect.json",
        atlas = Tree.root .. "effect/slwh_caijineffect.atlas",
        cache = Tree.root .. "effect/slwh_caijineffect",
        max_count = 1,
    },
    --动物模型跳舞
    ["slwh_dancing"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_dancinggs.json",
        atlas = Tree.root .. "effect/slwh_dancinggs.atlas",
        cache = Tree.root .. "effect/slwh_dancinggs",
        max_count = 2,
    },
    --动物模型脚下,舞台上的光效动画
    ["slwh_stagegs"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_stagegs.json",
        atlas = Tree.root .. "effect/slwh_stagegs.atlas",
        cache = Tree.root .. "effect/slwh_stagegs",
        max_count = 2,
    },
    --动物脚下的烟雾
    ["slwh_jumpsmoke"] = {
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_jumpsmoke.json",
        atlas = Tree.root .. "effect/slwh_jumpsmoke.atlas",
        cache = Tree.root .. "effect/slwh_jumpsmoke",
        max_count = 2,
    },
    --动物模型的获奖动作轨迹
    ["slwh_animal_1"] = {--狮子
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_shizigx.json",
        atlas = Tree.root .. "effect/slwh_shizigx.atlas",
        cache = Tree.root .. "effect/slwh_shizigx",
        max_count = 4,
    },
    ["slwh_animal_2"] = {--熊猫
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_xiongmaogx.json",
        atlas = Tree.root .. "effect/slwh_xiongmaogx.atlas",
        cache = Tree.root .. "effect/slwh_xiongmaogx",
        max_count = 4,
    },
    ["slwh_animal_3"] = {--猴子
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_houzigx.json",
        atlas = Tree.root .. "effect/slwh_houzigx.atlas",
        cache = Tree.root .. "effect/slwh_houzigx",
        max_count = 4,
    },
    ["slwh_animal_4"] = {--兔子
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_tuzigx.json",
        atlas = Tree.root .. "effect/slwh_tuzigx.atlas",
        cache = Tree.root .. "effect/slwh_tuzigx",
        max_count = 4,
    },
    ["slwh_daojishi"] = {--倒计时
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_daojishi.json",
        atlas = Tree.root .. "effect/slwh_daojishi.atlas",
        cache = Tree.root .. "effect/slwh_daojishi",
        max_count = 2,
    },
    ["slwh_xiazhutips"] = {--下注提示
        type = Tree.CacheType.CacheType_Spine,
        type = Tree.CacheType.CacheType_Spine,
        json = Tree.root .. "effect/slwh_xiazhutips.json",
        atlas = Tree.root .. "effect/slwh_xiazhutips.atlas",
        cache = Tree.root .. "effect/slwh_xiazhutips",
        max_count = 2,
    },
    --Particle
    ["particle_reward_l"] = {--普通开奖左侧的烟花
        type = Tree.CacheType.CacheType_Particle,
        particle = Tree.root .. "particle/slwh_wincaidai1.plist",
        scale = 1.0,
        max_count = 2,
    },
    ["particle_reward_r"] = {--普通开奖右侧的烟花
        type = Tree.CacheType.CacheType_Particle,
        particle = Tree.root .. "particle/slwh_wincaidai1f.plist",
        scale = 1.0,
        max_count = 2,
    },
    ["particle_bet_btn"] = {--普通开奖左侧的烟花
        type = Tree.CacheType.CacheType_Particle,
        particle = Tree.root .. "particle/slwh_cmlightlizi.plist",
        scale = 1.0,
        max_count = 5,
    },
    --舞台的粒子特效
    ["slwh_stagedclizi"] = {
        type = Tree.CacheType.CacheType_Particle,
        particle = Tree.root .. "particle/slwh_stagedclizi.plist",
        scale = 1.0,
        max_count = 4,
    },
    ----------------------开奖时间--------------------------
    --------------------押注面板按钮上的数字--------------55555---------------
    ["time_number_0"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_0.png",
    	max_count = 4,
    },
    ["time_number_1"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_1.png",
    	max_count = 4,
    },
    ["time_number_2"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_2.png",
    	max_count = 4,
    },
    ["time_number_3"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_3.png",
    	max_count = 4,
    },
    ["time_number_4"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_4.png",
    	max_count = 4,
    },
    ["time_number_5"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_5.png",
    	max_count = 4,
    },
    ["time_number_6"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_6.png",
    	max_count = 4,
    },
    ["time_number_7"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_7.png",
    	max_count = 4,
    },
    ["time_number_8"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_8.png",
    	max_count = 4,
    },
    ["time_number_9"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_time_n_9.png",
    	max_count = 4,
    },
    -------------------------玩家分数/当前玩家下注-------------------------
    ["battle_money_n_0"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money0.png",
    	max_count = 14,
    },
    ["battle_money_n_1"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money1.png",
    	max_count = 14,
    },
    ["battle_money_n_2"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money2.png",
    	max_count = 14,
    },
    ["battle_money_n_3"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money3.png",
    	max_count = 14,
    },
    ["battle_money_n_4"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money4.png",
    	max_count = 14,
    },
    ["battle_money_n_5"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money5.png",
    	max_count = 14,
    },
    ["battle_money_n_6"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money6.png",
    	max_count = 14,
    },
    ["battle_money_n_7"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money7.png",
    	max_count = 14,
    },
    ["battle_money_n_8"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money8.png",
    	max_count = 14,
    },
    ["battle_money_n_9"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_money9.png",
    	max_count = 14,
    },
    ["battle_money_n_w"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_moneyw.png",
    	max_count = 14,
    },
    ["battle_money_n_d"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_moneyd.png",
    	max_count = 14,
    },
    ["battle_money_n_f"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_moneyf.png",
    	max_count = 14,
    },
    ["battle_money_n_y"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_moneyy.png",
    	max_count = 14,
    },
    -------------------------彩金数字--------------------------------
    ["jetton_money_n_0"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_0.png",
    	max_count = 14,
    },
    ["jetton_money_n_1"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_1.png",
    	max_count = 14,
    },
    ["jetton_money_n_2"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_2.png",
    	max_count = 14,
    },
    ["jetton_money_n_3"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_3.png",
    	max_count = 14,
    },
    ["jetton_money_n_4"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_4.png",
    	max_count = 14,
    },
    ["jetton_money_n_5"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_5.png",
    	max_count = 14,
    },
    ["jetton_money_n_6"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_6.png",
    	max_count = 14,
    },
    ["jetton_money_n_7"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_7.png",
    	max_count = 14,
    },
    ["jetton_money_n_8"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_8.png",
    	max_count = 14,
    },
    ["jetton_money_n_9"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_9.png",
    	max_count = 14,
    },
    ["jetton_money_n_d"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_d.png",
    	max_count = 14,
    },
    ["jetton_money_n_f"] = {
    	type = Tree.CacheType.CacheType_SpriteFrame,
    	frame_name = "slwh_battle_jack_f.png",
    	max_count = 14,
    },
}
-----下注面板中的缓存对象-----全部都是Sprite对象,并且创建方式都是cc.Sprite:createWithSpriteFrameName
Tree.JettonCache = {
    --红色的下注面板中倍率数字表示
    ["slwh_red_m_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_0.png",
        max_count = 8,
    },
    ["slwh_red_m_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_1.png",
        max_count = 8,
    },
    ["slwh_red_m_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_2.png",
        max_count = 8,
    },
    ["slwh_red_m_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_3.png",
        max_count = 8,
    },
    ["slwh_red_m_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_4.png",
        max_count = 8,
    },
    ["slwh_red_m_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_5.png",
        max_count = 8,
    },
    ["slwh_red_m_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_6.png",
        max_count = 8,
    },
    ["slwh_red_m_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_7.png",
        max_count = 8,
    },
    ["slwh_red_m_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_8.png",
        max_count = 8,
    },
    ["slwh_red_m_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_9.png",
        max_count = 8,
    },
    ["slwh_red_m_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_multi_d.png",
        max_count = 8,
    },
    ---------------------------黄色下注面板的倍率-------------------
    ["slwh_yellow_m_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_0.png",
        max_count = 8,
    },
    ["slwh_yellow_m_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_1.png",
        max_count = 8,
    },
    ["slwh_yellow_m_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_2.png",
        max_count = 8,
    },
    ["slwh_yellow_m_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_3.png",
        max_count = 8,
    },
    ["slwh_yellow_m_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_4.png",
        max_count = 8,
    },
    ["slwh_yellow_m_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_5.png",
        max_count = 8,
    },
    ["slwh_yellow_m_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_6.png",
        max_count = 8,
    },
    ["slwh_yellow_m_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_7.png",
        max_count = 8,
    },
    ["slwh_yellow_m_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_8.png",
        max_count = 8,
    },
    ["slwh_yellow_m_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_9.png",
        max_count = 8,
    },
    ["slwh_yellow_m_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_multi_d.png",
        max_count = 8,
    },
    -------绿色的下注面板倍率数字------------------
    ["slwh_green_m_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_0.png",
        max_count = 8,
    },
    ["slwh_green_m_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_1.png",
        max_count = 8,
    },
    ["slwh_green_m_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_2.png",
        max_count = 8,
    },
    ["slwh_green_m_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_3.png",
        max_count = 8,
    },
    ["slwh_green_m_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_4.png",
        max_count = 8,
    },
    ["slwh_green_m_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_5.png",
        max_count = 8,
    },
    ["slwh_green_m_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_6.png",
        max_count = 8,
    },
    ["slwh_green_m_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_7.png",
        max_count = 8,
    },
    ["slwh_green_m_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_8.png",
        max_count = 8,
    },
    ["slwh_greenm_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_9.png",
        max_count = 8,
    },
    ["slwh_green_m_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_multi_d.png",
        max_count = 8,
    },
    -------蓝色倍率表示------------------
    ["slwh_blue_m_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_0.png",
        max_count = 8,
    },
    ["slwh_blue_m_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_1.png",
        max_count = 8,
    },
    ["slwh_blue_m_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_2.png",
        max_count = 8,
    },
    ["slwh_blue_m_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_3.png",
        max_count = 8,
    },
    ["slwh_blue_m_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_4.png",
        max_count = 8,
    },
    ["slwh_blue_m_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_5.png",
        max_count = 8,
    },
    ["slwh_blue_m_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_6.png",
        max_count = 8,
    },
    ["slwh_blue_m_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_7.png",
        max_count = 8,
    },
    ["slwh_blue_m_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_8.png",
        max_count = 8,
    },
    ["slwh_bluem_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_9.png",
        max_count = 8,
    },
    ["slwh_blue_m_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_multi_d.png",
        max_count = 8,
    },
    ---------红色该区域所有玩家的下注数字--------------------
    ["slwh_red_jt_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_0.png",
        max_count = 64,
    },
    ["slwh_red_jt_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_1.png",
        max_count = 64,
    },
    ["slwh_red_jt_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_2.png",
        max_count = 64,
    },
    ["slwh_red_jt_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_3.png",
        max_count = 64,
    },
    ["slwh_red_jt_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_4.png",
        max_count = 64,
    },
    ["slwh_red_jt_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_5.png",
        max_count = 64,
    },
    ["slwh_red_jt_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_6.png",
        max_count = 64,
    },
    ["slwh_red_jt_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_7.png",
        max_count = 64,
    },
    ["slwh_red_jt_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_8.png",
        max_count = 64,
    },
    ["slwh_red_jt_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_9.png",
        max_count = 64,
    },
    ["slwh_red_jt_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_d.png",
        max_count = 16,
    },
    ["slwh_red_jt_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_y.png",
        max_count = 4,
    },
    ["slwh_red_jt_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_other_f.png",
        max_count = 4,
    },
    ----黄色的该区域所有玩家的下注之和----------------------
    ["slwh_yellow_jt_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_0.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_1.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_2.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_3.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_4.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_5.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_6.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_7.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_8.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_9.png",
        max_count = 64,
    },
    ["slwh_yellow_jt_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_d.png",
        max_count = 16,
    },
    ["slwh_yellow_jt_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_y.png",
        max_count = 4,
    },
    ["slwh_yellow_jt_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_other_f.png",
        max_count = 4,
    },
    -------绿色该区域区域所有玩家数字之和数字--------------
    ["slwh_green_jt_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_0.png",
        max_count = 64,
    },
    ["slwh_green_jt_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_1.png",
        max_count = 64,
    },
    ["slwh_green_jt_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_2.png",
        max_count = 64,
    },
    ["slwh_green_jt_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_3.png",
        max_count = 64,
    },
    ["slwh_green_jt_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_4.png",
        max_count = 64,
    },
    ["slwh_green_jt_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_5.png",
        max_count = 64,
    },
    ["slwh_green_jt_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_6.png",
        max_count = 64,
    },
    ["slwh_green_jt_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_7.png",
        max_count = 64,
    },
    ["slwh_green_jt_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_8.png",
        max_count = 64,
    },
    ["slwh_green_jt_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_9.png",
        max_count = 64,
    },
    ["slwh_green_jt_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_d.png",
        max_count = 16,
    },
    ["slwh_green_jt_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_y.png",
        max_count = 4,
    },
    ["slwh_green_jt_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_other_f.png",
        max_count = 4,
    },
    --------蓝色区域该区域所有玩家数字之和-------------
    ["slwh_blue_jt_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_0.png",
        max_count = 64,
    },
    ["slwh_blue_jt_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_1.png",
        max_count = 64,
    },
    ["slwh_blue_jt_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_2.png",
        max_count = 64,
    },
    ["slwh_blue_jt_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_3.png",
        max_count = 64,
    },
    ["slwh_blue_jt_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_4.png",
        max_count = 64,
    },
    ["slwh_blue_jt_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_5.png",
        max_count = 64,
    },
    ["slwh_blue_jt_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_6.png",
        max_count = 64,
    },
    ["slwh_blue_jt_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_7.png",
        max_count = 64,
    },
    ["slwh_blue_jt_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_8.png",
        max_count = 64,
    },
    ["slwh_blue_jt_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_9.png",
        max_count = 64,
    },
    ["slwh_blue_jt_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_d.png",
        max_count = 16,
    },
    ["slwh_blue_jt_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_y.png",
        max_count = 4,
    },
    ["slwh_blue_jt_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_other_f.png",
        max_count = 4,
    },
    ---------------------------------------红色区域个人下注之和数字-------------------------------
    ["slwh_red_j_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_0.png",
        max_count = 64,
    },
    ["slwh_red_j_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_1.png",
        max_count = 64,
    },
    ["slwh_red_j_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_2.png",
        max_count = 64,
    },
    ["slwh_red_j_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_3.png",
        max_count = 64,
    },
    ["slwh_red_j_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_4.png",
        max_count = 64,
    },
    ["slwh_red_j_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_5.png",
        max_count = 64,
    },
    ["slwh_red_j_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_6.png",
        max_count = 64,
    },
    ["slwh_red_j_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_7.png",
        max_count = 64,
    },
    ["slwh_red_j_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_8.png",
        max_count = 64,
    },
    ["slwh_red_j_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_9.png",
        max_count = 64,
    },
    ["slwh_red_j_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_d.png",
        max_count = 16,
    },
    ["slwh_red_j_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_y.png",
        max_count = 4,
    },
    ["slwh_red_j_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_red_bet_f.png",
        max_count = 4,
    },
    ---------黄色区域玩家个人分数之和数字-------------
    ["slwh_yellow_j_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_0.png",
        max_count = 64,
    },
    ["slwh_yellow_j_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_1.png",
        max_count = 64,
    },
    ["slwh_yellow_j_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_2.png",
        max_count = 64,
    },
    ["slwh_yellow_j_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_3.png",
        max_count = 64,
    },
    ["slwh_yellow_j_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_4.png",
        max_count = 64,
    },
    ["slwh_yellow_j_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_5.png",
        max_count = 64,
    },
    ["slwh_yellow_j_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_6.png",
        max_count = 64,
    },
    ["slwh_yellow_j_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_7.png",
        max_count = 64,
    },
    ["slwh_yellow_j_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_8.png",
        max_count = 64,
    },
    ["slwh_yellow_j_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_9.png",
        max_count = 64,
    },
    ["slwh_yellow_j_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_d.png",
        max_count = 16,
    },
    ["slwh_yellow_j_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_y.png",
        max_count = 4,
    },
    ["slwh_yellow_j_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_yellow_bet_f.png",
        max_count = 4,
    },
    -----------绿色区域玩家个人在该区域的分数之和数字-----------
    ["slwh_green_j_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_0.png",
        max_count = 64,
    },
    ["slwh_green_j_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_1.png",
        max_count = 64,
    },
    ["slwh_green_j_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_2.png",
        max_count = 64,
    },
    ["slwh_green_j_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_3.png",
        max_count = 64,
    },
    ["slwh_green_j_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_4.png",
        max_count = 64,
    },
    ["slwh_green_j_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_5.png",
        max_count = 64,
    },
    ["slwh_green_j_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_6.png",
        max_count = 64,
    },
    ["slwh_green_j_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_7.png",
        max_count = 64,
    },
    ["slwh_green_j_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_8.png",
        max_count = 64,
    },
    ["slwh_green_j_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_9.png",
        max_count = 64,
    },
    ["slwh_green_j_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_d.png",
        max_count = 16,
    },
    ["slwh_green_j_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_y.png",
        max_count = 4,
    },
    ["slwh_green_j_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_green_bet_f.png",
        max_count = 4,
    },
    ----------蓝色区域,该区域玩家个人的分数之和数字------------
    ["slwh_blue_j_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_0.png",
        max_count = 64,
    },
    ["slwh_blue_j_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_1.png",
        max_count = 64,
    },
    ["slwh_blue_j_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_2.png",
        max_count = 64,
    },
    ["slwh_blue_j_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_3.png",
        max_count = 64,
    },
    ["slwh_blue_j_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_4.png",
        max_count = 64,
    },
    ["slwh_blue_j_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_5.png",
        max_count = 64,
    },
    ["slwh_blue_j_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_6.png",
        max_count = 64,
    },
    ["slwh_blue_j_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_7.png",
        max_count = 64,
    },
    ["slwh_blue_j_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_8.png",
        max_count = 64,
    },
    ["slwh_blue_j_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_9.png",
        max_count = 64,
    },
    ["slwh_blue_j_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_d.png",
        max_count = 16,
    },
    ["slwh_blue_j_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_y.png",
        max_count = 4,
    },
    ["slwh_blue_j_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_blue_bet_f.png",
        max_count = 4,
    },
    --------------------下注用的筹码数字---------------
    ["slwh_chouma_1000"] = {--1000
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_chouma_1000.png",
        max_count = 660,
    },
    --1w
    ["slwh_chouma_10000"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_chouma_10000.png",
        max_count = 460,
    },
    --10w
    ["slwh_chouma_100000"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_chouma_100000.png",
        max_count = 460,
    },
    --100w
    ["slwh_chouma_1000000"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_chouma_1000000.png",
        max_count = 460,
    },
    --500w
    ["slwh_chouma_5000000"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_chouma_5000000.png",
        max_count = 460,
    },
    ---------玩家的个人分数------------------------
    ["slwh_slef_gold_0"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_0.png",
        max_count = 16,
    },
    ["slwh_slef_gold_1"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_1.png",
        max_count = 16,
    },
    ["slwh_slef_gold_2"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_2.png",
        max_count = 16,
    },
    ["slwh_slef_gold_3"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_3.png",
        max_count = 16,
    },
    ["slwh_slef_gold_4"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_4.png",
        max_count = 16,
    },
    ["slwh_slef_gold_5"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_5.png",
        max_count = 16,
    },
    ["slwh_slef_gold_6"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_6.png",
        max_count = 16,
    },
    ["slwh_slef_gold_7"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_7.png",
        max_count = 16,
    },
    ["slwh_slef_gold_8"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_8.png",
        max_count = 16,
    },
    ["slwh_slef_gold_9"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_9.png",
        max_count = 16,
    },
    ["slwh_slef_gold_d"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_d.png",
        max_count = 6,
    },
    ["slwh_slef_gold_f"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_f.png",
        max_count = 2,
    },
    ["slwh_slef_gold_w"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_w.png",
        max_count = 2,
    },
    ["slwh_slef_gold_y"] = {
        type = Tree.CacheType.CacheType_SpriteFrame,
        frame_name = "slwh_jetton_gold_y.png",
        max_count = 2,
    },
}