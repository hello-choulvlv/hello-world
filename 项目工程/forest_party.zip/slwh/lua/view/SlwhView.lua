--森林舞会的主场景入口
--2018年11月23日
--@author:xiaoxiong
SlwhView = class("SlwhView")
--require游戏中需要用到的组件\
requireLuaFromModule("slwh.view.ccs.SlwhLoadingCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhRoomCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhBankCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhBattleCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhMenuItemCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhNoticeCcsPane")
requireLuaFromModule("slwh.view.ccs.SlwhJettonCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhRewardCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhRuleCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhOnlineCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhJettonNewCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhSettingCcsView")
requireLuaFromModule("slwh.view.ccs.SlwhMenuCcsView")

--register ccs
ccs["SlwhRoomView"] = SlwhRoomCcsView
ccs["SlwhBankCcsView"] = SlwhBankCcsView
ccs["SlwhBattleCcsView"] = SlwhBattleCcsView
ccs["SlwhJettonCcsView"]  = SlwhJettonCcsView
ccs["SlwhNoticeCcsPane"] = SlwhNoticeCcsPane
ccs["SlwhMenuItemCcsView"] = SlwhMenuItemCcsView
ccs["SlwhRuleCcsView"] = SlwhRuleCcsView
ccs["SlwhLoadingCcsView"] = SlwhLoadingCcsView
ccs["SlwhJettonNewCcsView"] = SlwhJettonNewCcsView
ccs["SlwhOnlineCcsView"] = SlwhOnlineCcsView
ccs["SlwhSettingCcsView"] = SlwhSettingCcsView
ccs["SlwhMenuCcsView"] = SlwhMenuCcsView

function SlwhView:ctor(model, controller)
    self.model = model
    self.controller = controller
    ClassUtil.extends(self, BaseModuleUIView, true, "module/slwh/csb/layer/Slwh.csb")
    self._maskOpacity = 0;
	self:setRootClickable(false)
end
--UI显示时调用
function SlwhView:onShow()
    BaseModuleUIView.onShow(self)
end

function SlwhView:onHide()
    BaseModuleUIView.onHide(self)
end
--绑定子组件
function SlwhView:bindChildrenViews()
    --parent, csbPath, modelTabProperty, viewTabIndex, hideNotDestroy, addChildFunc, removeChildFunc, zorder
    local parentLayer = self:getRootView().layerView
    local loadingLayer = self:getRootView().layerLoading
    local layer_tips = self:getRootView().layer_tips
    local modelTabProperty = "curShowingViewType"

    self:bindTabView(parentLayer,"module/slwh/csb/layer/SlwhRoom.csb",modelTabProperty,VIEW_TYPE_ROOM,true)
    --目前还没有战斗UI,暂时屏蔽掉
    self:bindTabView(parentLayer,"module/slwh/csb/layer/SlwhBattle.csb",modelTabProperty,VIEW_TYPE_BATTLE,true)
    self:bindTabView(layer_tips, "module/slwh/csb/layer/SlwhJettonNew.csb", "isShowingJetton",true,false)
    self:bindTabView(loadingLayer,"module/slwh/csb/layer/SlwhLoading.csb","isShowingLoading",true,false)
    --menu
    self:bindTabView(self:getRootView().layerMenu,"module/slwh/csb/layer/SlwhMenu.csb","isShowingMenu",true,false)
    --弹出式UI,需要绑定self.model里面的属性
    self:bindPopUpChildView("rule",    "module/slwh/csb/layer/SlwhRule.csb","isShowingRule")--规则
    self:bindPopUpChildView("setting","module/slwh/csb/layer/SlwhSetting.csb","isShowingSetting")--设置
    self:bindPopUpChildView("bank"    ,"module/slwh/csb/layer/SlwhBank.csb","isShowingBank")--银行
    -- self:bindPopUpChildView( "jetton_panel", "module/slwh/csb/layer/SlwhJettonNew.csb", "isShowingJetton",true,layer_tips)
    self:bindPopUpChildView("online", "module/slwh/csb/layer/SlwhOnline.csb","isShowingOnline",true,layer_tips)
    --self:bindPopUpChildView("reward","module/slwh/csb/layer/SlwhRewardNormal.csb","isShowingRewardNormal",true)
    
    local layerNotice = self:getRootView().layerGameNotice
    self.model.noticeControl = layerNotice
    self.model._layerTips = self:getRootView().layer_tips
    self.model._layerTips:setVisible(false)
end

function SlwhView:hide(onHide, onHideMid,noAnimation)
    BaseModuleUIView.hide(self,onHide,onHideMid,noAnimation)
    audioMgr:playMainMusic()
end

function SlwhView:destroy()
    BaseModuleUIView.destroy(self)
    self.model = nil
    self.controller = nil
end