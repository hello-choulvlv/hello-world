--
-- Author: xiaoxiong
-- Date: 2019-2-21
--

SlwhSettingCcsView = class("SlwhSettingCcsView")

function SlwhSettingCcsView:onCreationComplete()
	ClassUtil.extends(self, BaseSettingPopupCcsView);
    BaseSettingPopupCcsView.onCreationComplete(self)
end

function SlwhSettingCcsView:onMusicPlayChanged(value)
	audioMgr:setMusicCanPlay(value)
	self:checkSwitchersState()
    TreeEventDispatcher:dispatchEvent(Tree.Event.soundVolumChanged,audioMgr:getMusicVolume())
end
