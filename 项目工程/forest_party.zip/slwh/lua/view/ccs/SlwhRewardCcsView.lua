--森林舞会结算
--2018年11月29日
--@author:xiaoxiong
SlwhRewardCcsView = class("SlwhRewardCcsView",function()
                                            return cc.CSLoader:createNode(Tree.root .. "csb/layer/SlwhReward.csb")
                                        end)

local countDownTxtColorMap = {
    [Tree.RewardType.RewardType_Normal] = "green",
    [Tree.RewardType.RewardType_DaSanYuan] = "red",
    [Tree.RewardType.RewardType_DaSiXi] = "violet",
    [Tree.RewardType.RewardType_SongDeng] = "green",
    [Tree.RewardType.RewardType_ShanDian] = "green",
    [Tree.RewardType.RewardType_CaiJin] = "green",
}

local countDownImageColorMap = {
    [Tree.RewardType.RewardType_Normal] = "slwh_reward_neon_green.png",
    [Tree.RewardType.RewardType_DaSanYuan] = "slwh_reward_neon_red.png",
    [Tree.RewardType.RewardType_DaSiXi] = "slwh_reward_neon_violet.png",
    [Tree.RewardType.RewardType_SongDeng] = "slwh_reward_neon_green.png",
    [Tree.RewardType.RewardType_ShanDian] = "slwh_reward_neon_green.png",
    [Tree.RewardType.RewardType_CaiJin] = "slwh_reward_neon_green.png",
}

local countDownParticleColorMap = {
    [Tree.RewardType.RewardType_Normal] = "res/gameres/module/slwh/particle/slwh_reward_particle_green.plist",
    [Tree.RewardType.RewardType_DaSanYuan] = "res/gameres/module/slwh/particle/slwh_reward_particle_red.plist",
    [Tree.RewardType.RewardType_DaSiXi] = "res/gameres/module/slwh/particle/slwh_reward_particle_violet.plist",
    [Tree.RewardType.RewardType_SongDeng] = "res/gameres/module/slwh/particle/slwh_reward_particle_green.plist",
    [Tree.RewardType.RewardType_ShanDian] = "res/gameres/module/slwh/particle/slwh_reward_particle_green.plist",
    [Tree.RewardType.RewardType_CaiJin] = "res/gameres/module/slwh/particle/slwh_reward_particle_green.plist",
}

function SlwhRewardCcsView:ctor(model)
    self.model = model
    self._rewardType = Tree.RewardType.RewardType_Normal
    --播放特效的位置
    self._effect_target_x = 0
    self._effect_target_y = 0

    self._root = self:getChildByName("root")
    self._center = self._root:getChildByName("center")
    self._center:setLocalZOrder(3)
    self._mask = self._root:getChildByName("sprite_mask")
    self.layer_normal = self._center:getChildByName("layer_normal")
    self.layer_dasanyuan = self._center:getChildByName("layer_dasanyuan")
    self.layer_dasixi = self._center:getChildByName("layer_dasixi")
    self.layer_lighting = self._center:getChildByName("layer_lighting")
    self.layer_deng = self._center:getChildByName("layer_deng")
    self.sprite_mask = self._root:getChildByName("sprite_mask")
    self.sprite_mask:setScaleY(1.01)

    self:loadChildCascade()
    --适配屏幕,目前暂时不做适配,到后期时再做

    self._touchListener = cc.EventListenerTouchOneByOne:create()
    self._touchListener:registerScriptHandler(function() return true end,cc.Handler.EVENT_TOUCH_BEGAN)
    self._touchListener:registerScriptHandler(function()end,cc.Handler.EVENT_TOUCH_MOVED)
    self._touchListener:registerScriptHandler(function() self:runExitAnimation() end,cc.Handler.EVENT_TOUCH_ENDED)
    self._touchListener:setSwallowTouches(true)
    self._touchListener:retain()

     self:getEventDispatcher():addEventListenerWithSceneGraphPriority(self._touchListener, self._root:getChildByName("sprite_mask"))
     TreeEventDispatcher:addEventListener(Tree.Event.gameWait,self.runExitAnimation,self)

     self._rewardCallback = {
        [Tree.RewardType.RewardType_Normal] = self.showNormalType,
        [Tree.RewardType.RewardType_DaSanYuan] = self.showDaSanYuanType,
        [Tree.RewardType.RewardType_DaSiXi] = self.showDaSiXiType,
        [Tree.RewardType.RewardType_SongDeng] = self.showLightingType,
        [Tree.RewardType.RewardType_ShanDian] = self.showThunderCaiJinType,
        [Tree.RewardType.RewardType_CaiJin] = self.showThunderCaiJinType,
      }
      --变更各个layer的localZorder
      self.layer_deng:setLocalZOrder(7)
      self.layer_lighting:setLocalZOrder(6)
      self.layer_dasixi:setLocalZOrder(5)
      self.layer_dasanyuan:setLocalZOrder(4)
      self.layer_normal:setLocalZOrder(3)
      self.sprite_mask:setLocalZOrder(0)

      self.layer_deng.ccsChildren = {}
      self.layer_lighting.ccsChildren = {}
      self.layer_dasixi.ccsChildren = {}
      self.layer_dasanyuan.ccsChildren = {}
      self.layer_normal.ccsChildren = {}

      self.layer_deng.skip_tf = CCSUtil.changeUILabelWithTextField(self.layer_deng:getChildByName("skip_tf"))
      self.layer_lighting.skip_tf = CCSUtil.changeUILabelWithTextField(self.layer_lighting:getChildByName("skip_tf"))
      self.layer_dasixi.skip_tf = CCSUtil.changeUILabelWithTextField(self.layer_dasixi:getChildByName("skip_tf"))
      self.layer_dasanyuan.skip_tf = CCSUtil.changeUILabelWithTextField(self.layer_dasanyuan:getChildByName("skip_tf"))
      self.layer_normal.skip_tf = CCSUtil.changeUILabelWithTextField(self.layer_normal:getChildByName("skip_tf"))

      local particle = cc.ParticleSystemQuad:create(countDownParticleColorMap[Tree.RewardType.RewardType_SongDeng]);
      particle:setPosition(cc.p(180, 80))
      self.layer_deng.image_press:addChild(particle)

      local particle = cc.ParticleSystemQuad:create(countDownParticleColorMap[Tree.RewardType.RewardType_Normal]);
      particle:setPosition(cc.p(180, 80))
      self.layer_lighting.image_press:addChild(particle)

      local particle = cc.ParticleSystemQuad:create(countDownParticleColorMap[Tree.RewardType.RewardType_DaSiXi]);
      particle:setPosition(cc.p(180, 80))
      self.layer_dasixi.image_press:addChild(particle)

      local particle = cc.ParticleSystemQuad:create(countDownParticleColorMap[Tree.RewardType.RewardType_DaSanYuan]);
      particle:setPosition(cc.p(180, 80))
      self.layer_dasanyuan.image_press:addChild(particle)

      local particle = cc.ParticleSystemQuad:create(countDownParticleColorMap[Tree.RewardType.RewardType_Normal]);
      particle:setPosition(cc.p(180, 80))
      self.layer_normal.image_press:addChild(particle)

end

function SlwhRewardCcsView:setEffectTargetLocation(x,y)
    self._effect_target_x = x
    self._effect_target_y = y
end
--加载节点命名
function SlwhRewardCcsView:loadChildCascade()
    TreeFunc.loadChildCascade(self.layer_normal,true)
    TreeFunc.loadChildCascade(self.layer_dasanyuan,true)
    TreeFunc.loadChildCascade(self.layer_dasixi,true)
    TreeFunc.loadChildCascade(self.layer_lighting,true)
    TreeFunc.loadChildCascade(self.layer_deng,true)
end
--显示相关的奖励类型
function SlwhRewardCcsView:showRewardType(reward_data,time_scale)
    -- reward_data.lScore = 99999
    self._exit = false
    self._mask:setOpacity(255)
    self._center:setScale(1)

    self.layer_normal:setVisible(false)
    self.layer_dasanyuan:setVisible(false)
    self.layer_dasixi:setVisible(false)
    self.layer_lighting:setVisible(false)
    self.layer_deng:setVisible(false)
    self.reward_type = reward_data.tAward.nType
    time_scale = time_scale or 1
    local callback = self._rewardCallback[self.reward_type]
    if callback then
        callback(self,reward_data,time_scale)
    else
        self:onExit()
    end

    self.score = reward_data.lScore + reward_data.lJettoned
    self._jettonedScore = reward_data.lScore
    self._finalScore = reward_data.lEndScore
end

function SlwhRewardCcsView:showSkipTxt(countdown)

    local colorTxt = countDownTxtColorMap[self.reward_type]
    local htmlTxt = ""
    htmlTxt = htmlTxt .. HtmlUtil.createImg(string.format("#time/slwh_result_time_%s.png", colorTxt))
    htmlTxt = htmlTxt .. HtmlUtil.createImg(string.format("#time/%s/slwh_result_time_%s_left.png", colorTxt,colorTxt))
    htmlTxt = htmlTxt .. HtmlUtil.createArtNum(countdown, string.format("#time/%s/slwh_result_time_%s_%%s.png", colorTxt,colorTxt))
    htmlTxt = htmlTxt .. HtmlUtil.createImg(string.format("#time/%s/slwh_result_time_%s_right.png", colorTxt,colorTxt))

    self.currentLayer.skip_tf:setHtmlText(htmlTxt)
    self.currentLayer.image_press:loadTexture(countDownImageColorMap[self.reward_type],1)
    self.currentLayer.image_press:setOpacity(255)
    self.currentLayer.image_press:setScale(1)
    self.currentLayer.image_press:setContentSize(cc.size(359, 154))

end

function SlwhRewardCcsView:skipCountdownHandler()

    self.currentCountdown = self.currentCountdown - 1

    if self.currentCountdown == 0 then
        self:runExitAnimation()
    else
        self:showSkipTxt(self.currentCountdown)
    end

end

function SlwhRewardCcsView:runSkipTimer(currentLayer)

    self.currentLayer = currentLayer
    self.currentCountdown = self.model:getRemindTime()

    self.layer_normal.skip_tf:setTouchEnabled(false)

    self:stopSkipTimer()
    self.skipTimer = tickMgr:delayedCall(handler(self, self.skipCountdownHandler), 1000, -1)

    self:showSkipTxt(self.currentCountdown)

end

function SlwhRewardCcsView:stopSkipTimer()

    if self.skipTimer then
        self.skipTimer:stop()
        self.skipTimer:destroy()
        self.skipTimer = nil
    end

end

--普通奖励
function SlwhRewardCcsView:showNormalType(reward_data)
    self.layer_normal:setVisible(true)
    --俩测的散落粒子
    self:showNormalAnimation(self.layer_normal)
    --暂时隐藏待现实的组件,稍后延时
    self:setComponentVisible(self.layer_normal,2,false)
    self.layer_normal:runAction(cc.Sequence:create(cc.DelayTime:create(16/30),cc.CallFunc:create(c_func(self.showNormalType_Continue,self,reward_data))))

end
function SlwhRewardCcsView:showNormalType_Continue(reward_data)
    self:setComponentVisible(self.layer_normal,2,true)
    --获得的动物图标
    local reward_index_table = TreeFunc.checkAllIndex(reward_data.tAward.nAwardIndex,1)
    --显示当前下注,当前获得
    self:setJettonAchieveScore(self.layer_normal.node_xiazhuhuode,reward_data.lJettoned,reward_data.lScore + reward_data.lJettoned)
    --设置显示面板1
    local type_1 = reward_index_table[1]
    self:setLayerIconScore(self.layer_normal.layer_panel_1,type_1,reward_data.tAward.nJettonAreaTimes[type_1])

    --设置面2
    local type_2 = reward_index_table[2]
    self:setLayerIconScore(self.layer_normal.layer_panel_2,type_2,reward_data.tAward.nJettonAreaTimes[type_2])

    --注册按钮事件
    self.layer_normal.image_press:setTouchEnabled(true)
    self.layer_normal.image_press:addTouchEventListener(c_func(self.onButtonClick,self))

    self:runSkipTimer(self.layer_normal)

end
--大三元
function SlwhRewardCcsView:showDaSanYuanType(reward_data,time_scale)
    self.layer_dasanyuan:setVisible(true)
    --spine skeleton
    local skeleton = TreeCacheManager:getCacheObject("spine_award_dasanyuan")
    skeleton:setAnimation(0,"start",false)
    skeleton:addAnimation(0,"idle",true)
    skeleton:setTimeScale(time_scale)
    -- skeleton:setPosition(CONFIG_CUR_WIDTH * 0.5,CONFIG_CUR_HEIGHT * 0.5)
    skeleton:setName("spine_reward")
    self._center:addChild(skeleton,2)

    self:setComponentVisible(self.layer_dasanyuan,4,false)
    --分帧加载烟花动画
--    local count_l = 3 + math.random(0,3)
--    local base_delay = 32/30
--    local effect_width = CONFIG_CUR_WIDTH - 300
--    local effect_height = CONFIG_CUR_HEIGHT - 200
--    for index_j = 1,count_l do
--        local function delayCall()
--            local skeleton = TreeCacheManager:getCacheObject("spine_fire")
--            skeleton:setAnimation(0,"animation",false)
--            skeleton:setName("spine_fire")
--            --随机分布在这个layer上
--            local p_x = 60 + math.random() * effect_width
--            local p_y = 40 + math.random() * effect_height
--            skeleton:setPosition(p_x,p_y)
--            self.layer_dasanyuan:addChild(skeleton,2)
--        end
--        self.layer_dasanyuan:runAction(cc.Sequence:create(cc.DelayTime:create(base_delay + index_j * 0.033 + math.random() * 0.25),cc.CallFunc:create(delayCall)))
--    end

    self.layer_dasanyuan:runAction(cc.Sequence:create(cc.DelayTime:create(60/30 * time_scale),cc.CallFunc:create(c_func(self.showDaSanYuanType_Continue,self,reward_data))))
end
function SlwhRewardCcsView:showDaSanYuanType_Continue(reward_data)
    self:setComponentVisible(self.layer_dasanyuan,4,true)
    --获取大三元中四个中奖类型
    local reward_index_table = TreeFunc.checkAllIndex(reward_data.tAward.nAwardIndex,1)
    --显示当前下注,当前获得
    self:setJettonAchieveScore(self.layer_dasanyuan.node_xiazhuhuode,reward_data.lJettoned,reward_data.lScore + reward_data.lJettoned)

    for idx = 1, #reward_index_table do
        local type_idx = reward_index_table[idx]
        self:setLayerIconScore(self.layer_dasanyuan["layer_panel_" .. idx],type_idx,reward_data.tAward.nJettonAreaTimes[type_idx])
    end
    --注册按钮事件
    self.layer_dasanyuan.image_press:setTouchEnabled(true)
    self.layer_dasanyuan.image_press:addTouchEventListener(c_func(self.onButtonClick,self))

    self:runSkipTimer(self.layer_dasanyuan)

end
--大四喜
function SlwhRewardCcsView:showDaSiXiType(reward_data,time_scale)
    self.layer_dasixi:setVisible(true)
    --spine skeleton
    local skeleton = TreeCacheManager:getCacheObject("spine_award_dasixi")
    skeleton:setAnimation(0,"start",false)
    skeleton:addAnimation(0,"idle",true)
    skeleton:setTimeScale(time_scale)
    -- skeleton:setPosition(CONFIG_CUR_WIDTH * 0.5,CONFIG_CUR_HEIGHT * 0.5)
    skeleton:setName("spine_reward")
    self._center:addChild(skeleton,2)
    --
    self:setComponentVisible(self.layer_dasixi,5,false)
    --分帧加载烟花动画
--    local count_l = 3 + math.random(0,3)
--    local base_delay = 32/30
--    local effect_width = CONFIG_CUR_WIDTH - 300
--    local effect_height = CONFIG_CUR_HEIGHT - 200
--    for index_j = 1,count_l do
--        local function delayCall()
--            local skeleton = TreeCacheManager:getCacheObject("spine_fire")
--            skeleton:setName("spine_fire")
--            skeleton:setAnimation(0,"animation",false)
--            --随机分布在这个layer上
--            local p_x = 60 + math.random() * effect_width
--            local p_y = 40 + math.random() * effect_height
--            skeleton:setPosition(p_x,p_y)
--            self.layer_dasixi:addChild(skeleton,2)
--        end
--        self.layer_dasixi:runAction(cc.Sequence:create(cc.DelayTime:create(base_delay + index_j * 0.033 + math.random() * 0.25),cc.CallFunc:create(delayCall)))
--    end
    self.layer_dasixi:runAction(cc.Sequence:create(cc.DelayTime:create(60/30 * time_scale),cc.CallFunc:create(c_func(self.showDaSiXiType_Continue,self,reward_data))))
end
function SlwhRewardCcsView:showDaSiXiType_Continue(reward_data)
    self:setComponentVisible(self.layer_dasixi,5,true)
    --获取大四喜中四个中奖类型
    local reward_index_table = TreeFunc.checkAllIndex(reward_data.tAward.nAwardIndex,1)
    --显示当前下注,当前获得
    self:setJettonAchieveScore(self.layer_dasixi.node_xiazhuhuode,reward_data.lJettoned,reward_data.lScore + reward_data.lJettoned)

    for idx = 1, #reward_index_table do
        local type_idx = reward_index_table[idx]
        self:setLayerIconScore(self.layer_dasixi["layer_panel_" .. idx],type_idx,reward_data.tAward.nJettonAreaTimes[type_idx])
    end
    --注册按钮事件
    self.layer_dasixi.image_press:setTouchEnabled(true)
    self.layer_dasixi.image_press:addTouchEventListener(c_func(self.onButtonClick,self))

    self:runSkipTimer(self.layer_dasixi)

end
--送灯,其背景特效与普通的奖励一样
function SlwhRewardCcsView:showLightingType(reward_data)
    --在送灯界面中,我们会将所有的单元格进行重新排布,自适应的排列在容器中
    self.layer_deng:setVisible(true)
    --目前先暂时删除所有的节点,后面优化的时候会对所有的子节点进行复用
    self.layer_deng.layer_lv:removeAllChildren()
    self:showNormalAnimation(self.layer_deng)
    self.layer_deng.layer_panel:setVisible(false)
    self:setComponentVisible(self.layer_deng,0,false)

    self.layer_deng:runAction(cc.Sequence:create(cc.DelayTime:create(16/30),cc.CallFunc:create(c_func(self.showLightingType_Continue,self,reward_data))))
end
function SlwhRewardCcsView:showLightingType_Continue(reward_data)
    self:setComponentVisible(self.layer_deng,0,true)
    local temp_layer = self.layer_deng.layer_panel
    temp_layer:setVisible(false)
    --模板layer的大小
    local layer_size = temp_layer:getContentSize()
    --容器的大小
    local container_size = self.layer_deng.layer_lv:getContentSize()
    local icon_x,icon_y = temp_layer.sprite_demo:getPosition()
    local m_x,m_y = temp_layer.sprite_xpanel:getPosition()
    local interval_y = 3--排列的竖直上的间隔
    --获取子节点的数目
    local table_animal = TreeFunc.checkAllIndex(reward_data.tAward.nAwardIndex,1)
    self:setJettonAchieveScore(self.layer_deng.node_xiazhuhuode,reward_data.lJettoned,reward_data.lScore + reward_data.lJettoned)

    local count_t = #table_animal
    --自适应排列
    local max_column = 7
    local column_width = container_size.width/max_column
    local max_row = math.floor(count_t/max_column)
    local start_y = container_size.height
    --
    local layer_lv = self.layer_deng.layer_lv
    local index = 0
    local index_s = 1
    while count_t > max_column and index < max_row do    --需要大于一行
        local start_x = (container_size.width - max_column * column_width) * 0.5 + (column_width - layer_size.width) * 0.5
        for idx = 1,max_column do
            local animal_type = table_animal[index_s]
            local multiply = reward_data.tAward.nJettonAreaTimes[animal_type]
            --
            local layer = cc.Node:create()
            layer:setPosition(start_x,start_y - layer_size.height)
            layer_lv:addChild(layer,1)

            layer.sprite_demo = cc.Sprite:create()
            layer:addChild(layer.sprite_demo)
            layer.sprite_demo:setPosition(icon_x,icon_y)

            layer.sprite_xpanel = cc.Sprite:createWithSpriteFrameName("slwh_result_sprite_xpanel.png")--cc.Sprite:create(Tree.root .. "result/sprite_xpanel.png")
            layer:addChild(layer.sprite_xpanel)
            layer.sprite_xpanel:setPosition(m_x,m_y)

            self:setLayerIconScore(layer,animal_type,multiply)

            layer_lv["layer_panel_" .. index_s] = layer
            start_x = start_x + column_width
            index_s = index_s + 1
        end
        index = index + 1
        start_y = start_y - layer_size.height - interval_y
    end
    --对于剩下的节点单元,计算其是否需要均分网格,如果不足,则需要将其居中划分
    local count_remind = count_t - max_column * index
    start_y = count_t > max_column and start_y or (container_size.height - layer_size.height) * 0.5 + layer_size.height + 20
    local start_x = (container_size.width - column_width * count_remind) * 0.5 + (column_width - layer_size.width) * 0.5
    for idx = 1,count_remind do
        local animal_type = table_animal[index_s]
        local multiply = reward_data.tAward.nJettonAreaTimes[animal_type]
        --create layer
        local layer = cc.Node:create()
        layer:setPosition(start_x,start_y - layer_size.height)
        layer_lv:addChild(layer,1)

        layer.sprite_demo = cc.Sprite:create()
        layer:addChild(layer.sprite_demo)
        layer.sprite_demo:setPosition(icon_x,icon_y)

        layer.sprite_xpanel = cc.Sprite:createWithSpriteFrameName("slwh_result_sprite_xpanel.png")
        layer:addChild(layer.sprite_xpanel)
        layer.sprite_xpanel:setPosition(m_x,m_y)

        self:setLayerIconScore(layer,animal_type,multiply)

        layer_lv["layer_panel_" .. index_s] = layer

        start_x = start_x + column_width
        index_s = index_s + 1
    end
    --press imag
    --注册按钮事件
    self.layer_deng.image_press:setTouchEnabled(true)
    self.layer_deng.image_press:addTouchEventListener(c_func(self.onButtonClick,self))

    self:runSkipTimer(self.layer_deng)

end
--彩金/闪电
function SlwhRewardCcsView:showThunderCaiJinType(reward_data)
    --对齐下注/获得分数
    self.layer_lighting:setVisible(true)
    self:showNormalAnimation(self.layer_lighting)
    self:setComponentVisible(self.layer_lighting,3,false)

    self.layer_lighting:runAction(cc.Sequence:create(cc.DelayTime:create(16/30),cc.CallFunc:create(c_func(self.showThunderCaiJinType_Continue,self,reward_data))))
end
function SlwhRewardCcsView:showThunderCaiJinType_Continue(reward_data)
    self:setComponentVisible(self.layer_lighting,3,true)
    --获取的是闪电还是彩金
    local multiply = -1
    local animal_type = 17
    if reward_data.tAward.nType == Tree.RewardType.RewardType_ShanDian then
        multiply = reward_data.tAward.nTimes
        animal_type = 16
    end
    --如果是闪电,会有倍率的显示,彩金则没有
    self:setLayerIconScore(self.layer_lighting.layer_panel_1,animal_type,multiply)
    -- --检查获取的动物
    local reward_index_table = TreeFunc.checkAllIndex(reward_data.tAward.nAwardIndex,1)
    self:setJettonAchieveScore(self.layer_lighting.node_xiazhuhuode,reward_data.lJettoned,reward_data.lScore + reward_data.lJettoned)-- + reward_data.lCaijin)

    local type_1 = reward_index_table[1]
    self:setLayerIconScore(self.layer_lighting.layer_panel_2,type_1,reward_data.tAward.nJettonAreaTimes[type_1])

    local type_2 = reward_index_table[2]
    self:setLayerIconScore(self.layer_lighting.layer_panel_3,type_2,reward_data.tAward.nJettonAreaTimes[type_2])

    --注册按钮事件
    self.layer_lighting.image_press:setTouchEnabled(true)
    self.layer_lighting.image_press:addTouchEventListener(c_func(self.onButtonClick,self))

    self:runSkipTimer(self.layer_lighting)

end
--展示普通SpineAnimation
function SlwhRewardCcsView:showNormalAnimation(layer)
    --俩测的散落粒子
    local particle_l = TreeCacheManager:getCacheObject("particle_reward_l")
    particle_l:setPosition(CONFIG_CUR_WIDTH * 0.5 - 20,CONFIG_CUR_HEIGHT * 0.5 + 135)
    particle_l:setName("particle_reward_l")
    self._root:addChild(particle_l,1)
    --右侧
    local particle_r = TreeCacheManager:getCacheObject("particle_reward_r")
    particle_r:setPosition(CONFIG_CUR_WIDTH * 0.5 + 20,CONFIG_CUR_HEIGHT * 0.5 + 135)
    particle_r:setName("particle_reward_r")
    self._root:addChild(particle_r,1)
    --添加Spine
    local skeleton = TreeCacheManager:getCacheObject("spine_award_result")
    skeleton:setAnimation(0,"start",false)
    skeleton:addAnimation(0,"idle",true)
    -- skeleton:setPosition(CONFIG_CUR_WIDTH * 0.5,CONFIG_CUR_HEIGHT * 0.5)
    skeleton:setName("spine_reward")
    self._center:addChild(skeleton,2)
end
--设置下注/赢取分数,并对齐
function SlwhRewardCcsView:setJettonAchieveScore(node,jetton,achieve)
    node:removeAllChildren()

    local sprite_xiazhu = cc.Sprite:createWithSpriteFrameName("win/slwh_result_win_xizzhu.png")
    node:addChild(sprite_xiazhu)
    local size_xiazhu = sprite_xiazhu:getContentSize()

    local sprite_huode = cc.Sprite:createWithSpriteFrameName("win/slwh_result_win_huode.png")
    node:addChild(sprite_huode)
    local size_huode = sprite_huode:getContentSize()

    local dimension_xiazhu = {}
    local sprite_jetton = TreeFunc.createSpriteNumber(jetton,"#win/slwh_result_win_%s.png",dimension_xiazhu)
    node:addChild(sprite_jetton)

    local total = achieve
    local step = math.floor(total / 40)
    local temp = step

    self.__total = total
    self.__scoreNode = cc.Sprite:create()
    node:addChild(self.__scoreNode)

    local dimension_score = {}
    local sprite_score = TreeFunc.createSpriteNumber(temp,"#win/slwh_result_win_%s.png",dimension_score)
    self.__scoreNode:addChild(sprite_score)

    self.__scoreNode:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.DelayTime:create(0.025), cc.CallFunc:create(function()

        temp = temp + step

        if temp >= total then
            temp = total
            self.__scoreNode:stopAllActions()
        end

        self.__scoreNode:removeAllChildren()
        self.__scoreNode:addChild(TreeFunc.createSpriteNumber(temp,"#win/slwh_result_win_%s.png",dimension_xiazhu))

    end))))

    --计算最佳位置
    local max_width = size_xiazhu.width + size_huode.width + dimension_xiazhu.width + dimension_score.width + 50 + 2 + 2
    local offset_x = -max_width * 0.5 
    local offset_y = 0

    sprite_xiazhu:setPosition(offset_x + size_huode.width * 0.5,offset_y)
    offset_x = offset_x + size_xiazhu.width + 2

    sprite_jetton:setPosition(offset_x,offset_y)
    offset_x = offset_x + dimension_xiazhu.width + 50

    sprite_huode:setPosition(offset_x + size_huode.width * 0.5,offset_y)
    offset_x = offset_x + size_huode.width + 2
    
    self.__scoreNode:setPosition(offset_x,offset_y)
end
--设置面板中图标,倍率
function SlwhRewardCcsView:setLayerIconScore(layer,animal_type,multiply)
    local index_2 = animal_type
    layer.sprite_demo:setSpriteFrame( string.format("slwh_result_animal_%d.png",animal_type))
    if multiply < 0 then
        layer.sprite_xpanel:setVisible(false)
        return
    end
    layer.sprite_xpanel:setVisible(true)
    --倍率
    layer.sprite_xpanel:removeAllChildren()
    local panel_size = layer.sprite_xpanel:getContentSize()
    --sprite x
    local sprite_x = cc.Sprite:createWithSpriteFrameName("multiply/slwh_result_multiply_x.png")
    local size_x = sprite_x:getContentSize()
    layer.sprite_xpanel:addChild(sprite_x)

    local dimension_map = {}
    local sprite_score = TreeFunc.createSpriteNumber(multiply,"#multiply/slwh_result_multiply_%s.png",dimension_map)
    layer.sprite_xpanel:addChild(sprite_score)

    local offset_x = panel_size.width * 0.5 - (size_x.width + dimension_map.width) * 0.5
    local offset_y =  panel_size.height * 0.5

    sprite_x:setPosition(offset_x + size_x.width * 0.5,offset_y)
    offset_x = offset_x + size_x.width
    sprite_score:setPosition(offset_x,offset_y)
    --debug
end
--show or hide
function SlwhRewardCcsView:setComponentVisible(layer,panel_count,visible)
    layer.node_xiazhuhuode:setVisible(visible)
    layer.image_press:setOpacity(0)
    layer.skip_tf:setVisible(visible)
    for idx = 1,panel_count do
        layer["layer_panel_" .. idx]:setVisible(visible)
    end
end
--按钮回调
function SlwhRewardCcsView:onButtonClick(sender,event_type)
    if event_type == ccui.TouchEventType.ended then
        self:runExitAnimation()
    end
end
--退出场景
function SlwhRewardCcsView:onExit()
-- assert(false)

    --回收相关的Spine资源
    local skeleton = self._center:getChildByName("spine_reward")
    if skeleton then
        TreeCacheManager:recycleCocos2dxObject(skeleton)
    end
    --particle
    local particle_1 = self._root:getChildByName("particle_reward_l")
    if particle_1 then
        TreeCacheManager:recycleCocos2dxObject(particle_1)
    end
    local particle_2 = self._root:getChildByName("particle_reward_r")
    if particle_2 then
        TreeCacheManager:recycleCocos2dxObject(particle_2)
    end
--    --大三元烟花
--    local skeleton_fire = self.layer_dasanyuan:getChildByName("spine_fire")
--    while skeleton_fire do
--        TreeCacheManager:recycleCocos2dxObject(skeleton_fire)
--        skeleton_fire = self.layer_dasanyuan:getChildByName("spine_fire")
--    end
--    --大四喜烟花
--    local skeleton_fire = self.layer_dasixi:getChildByName("spine_fire")
--    while skeleton_fire do
--        TreeCacheManager:recycleCocos2dxObject(skeleton_fire)
--        skeleton_fire = self.layer_dasixi:getChildByName("spine_fire")
--    end

    self:stopSkipTimer()

    self:removeFromParent()

end

function SlwhRewardCcsView:runExitAnimation()
-- dump("=========================== EXIT ANIMATION ==========================")

    if self:getParent() and not self._exit then
    
        self._exit = true
        self._mask:runAction(cc.FadeTo:create(0.15, 0))
        self._center:runAction(cc.EaseSineIn:create(cc.ScaleTo:create(0.15, 0)))
        self:runAction(cc.Sequence:create(cc.DelayTime:create(0.15), cc.CallFunc:create(function() self:onExit() end)))

        if self.__scoreNode and self.score > 0 then

            self.__scoreNode:removeAllChildren()
            self.__scoreNode:stopAllActions()
            
            local visibleSize = cc.Director:getInstance():getVisibleSize()
            local offset = visibleSize.width > 1334 and 0 or 66
            local dimension_score = {}
            local total = self.__total
            local sprite_score = TreeFunc.createSpriteNumber(self.__total,"#multiply/slwh_result_multiply_%s.png",dimension_score)
            self.__scoreNode:addChild(sprite_score)

            local numberNode = self.__scoreNode:getChildren()[1]

            local newParent = self:getParent()
            local parent = self.__scoreNode
            local position = parent:convertToWorldSpace(cc.p(numberNode:getPosition()))
            numberNode:retain()
            numberNode:removeFromParent()
    
            position = self:getParent():convertToNodeSpace(position)
            newParent:addChild(numberNode)
            numberNode:setPosition(position)
            numberNode:release()
    
            numberNode:setCascadeOpacityEnabled(true)
            numberNode:setLocalZOrder(999999)
            local final_score = self._finalScore
            numberNode:runAction(cc.EaseSineIn:create(cc.Sequence:create(cc.Spawn:create(cc.MoveTo:create(0.3, cc.p(250 + offset, 44)), cc.FadeTo:create(0.3, 50)), cc.CallFunc:create(function()

                local jsonFile = "res/gameres/module/slwh/effect/slwh_userhkeffect.json"
                local atlasFile = "res/gameres/module/slwh/effect/slwh_userhkeffect.atlas"

                local skeleton_1 = sp.SkeletonAnimation:create(jsonFile,atlasFile)
                skeleton_1:setAnimation(0,"animation",false)
                skeleton_1:runAction(cc.Sequence:create(cc.DelayTime:create(1.5), cc.RemoveSelf:create()))
                skeleton_1:setPosition(newParent:convertToNodeSpace(cc.p(self._effect_target_x + 20,self._effect_target_y + 44)))--(230 + offset, 44)
                newParent:addChild(skeleton_1)

                --local tempTable = {}
                local node = TreeFunc.createSpriteNumber(total,"#reward/slwh_result_battle_%s.png")
                node:setAnchorPoint(0.5, 0.5)
                node:setPosition(300 + offset, 76)
                -- node:setScale(0.7)
                newParent:addChild(node)
                node:runAction(cc.Sequence:create(cc.Spawn:create(cc.FadeTo:create(0.3, 255), cc.MoveBy:create(0.4, cc.p(0, 12))), cc.Spawn:create(cc.FadeTo:create(0.3, 0), cc.MoveBy:create(0.3, cc.p(0, 9))), cc.RemoveSelf:create()))

                local sprite = cc.Sprite:createWithSpriteFrameName("reward/slwh_result_battle_plus.png")
                sprite:setAnchorPoint(1.0, 0.5)
                sprite:setPosition(-5, 0)
                node:addChild(sprite)

                --local hero_score = parseInt(Hero:getUserScore())
                Hero:setUserScore(final_score,true)--hero_score + total - self._jettonedScore)
                --TreeEventDispatcher:dispatchEvent(Tree.Event.userScoreChanged)

            end), cc.RemoveSelf:create())))

            local particle = cc.ParticleSystemQuad:create("res/gameres/module/slwh/particle/slwh_jsfenlizi.plist")
            particle:setPosition(position)
            particle:setLocalZOrder(999998)
            newParent:addChild(particle)
            particle:runAction(cc.EaseSineIn:create(cc.Sequence:create(cc.MoveTo:create(0.3, newParent:convertToNodeSpace(cc.p(self._effect_target_x + 30,self._effect_target_y + 44))), cc.CallFunc:create(function()

                particle:setAutoRemoveOnFinish(true)
                particle:setDuration(0)


            end))))
    
            self.__scoreNode = nil
    
        end


    else
        -- assert(false)
    end

end

function SlwhRewardCcsView:onDestroy()
    self:getEventDispatcher():removeEventListener(self._touchListener)
    self._touchListener:release()
end