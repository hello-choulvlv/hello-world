--森林舞会下注面板
--@author:liuliu
--@modify:xiaoxiong
--2019年3月16日
SlwhJettonNewCcsView = class("SlwhJettonNewCcsView")

function SlwhJettonNewCcsView:onCreationComplete()
    ClassUtil.extends( self, ZoomPopUpChildView, true, self, self.bg, self.view )
    self:initLazy()
    self:initEventListener()
    --下注面板父组件
    self._jettonLayer = self.view.bottomNode
    --统计玩家自己的下注分数节点,所有玩家的下注分数节点
    self._nodeSelfScores = {}
    self._nodePlayerScores = {}--玩家自己的下注分数
    self._nodeMultiplys = {}--赔率节点
    self._optimal = cc.LabelFrameAtlas ~= nil
    self._optimal_jetton = cc.SpriteBatchInstance ~= nil and cc.SpriteInstance.setVisible
    for index_l =1,15 do
        local object_key = string.format("btnBetArea%d",index_l)
        local area_object = self._jettonLayer[object_key]
        if not self._optimal then
            self._nodeSelfScores[index_l] = cc.Node:create()
            self._nodePlayerScores[index_l] = cc.Node:create()
            self._nodeMultiplys[index_l] = cc.Node:create()
        else
            self._nodeSelfScores[index_l] = cc.LabelFrameAtlas:create(string.format("slwh_jetton_%s_bet_%%s.png",Tree.JettonColorMap[index_l]))
            self._nodeSelfScores[index_l]:setAnchorPoint(0.0,0.5)
            
            self._nodePlayerScores[index_l] = cc.LabelFrameAtlas:create(string.format("slwh_jetton_%s_bet_other_%%s.png",Tree.JettonColorMap[index_l]))
            self._nodePlayerScores[index_l]:setAnchorPoint(0,0.5)
            
            self._nodeMultiplys[index_l] = cc.LabelFrameAtlas:create(string.format("slwh_jetton_%s_multi_%%s.png",Tree.JettonColorMap[index_l]))
            self._nodeMultiplys[index_l]:setAnchorPoint(0.5,0.5)
            
        end

        area_object:addChild(self._nodeSelfScores[index_l])
        area_object:addChild(self._nodePlayerScores[index_l])
        area_object:addChild(self._nodeMultiplys[index_l])

        self._nodeSelfScores[index_l]:setPosition(89.64,113.45)
        self._nodePlayerScores[index_l]:setPosition(89.64,89.75)
        self._nodeMultiplys[index_l]:setPosition(54,31)

        self._nodeSelfScores[index_l]:setTag(-1)
        self._nodeSelfScores[index_l]._last_num = -1
        self._nodePlayerScores[index_l]._last_num = -1
        self._nodeMultiplys[index_l]._last_num = -1

    end
    --所有玩家的下注分数,名字起的有歧义
    if not self._optimal then
        self._node_self_gold = cc.Node:create()--self.view.bottomNode.totalBet
        self._node_self_gold:setPosition(342,30.5)
    else
        self._node_self_gold = cc.LabelFrameAtlas:create("slwh_jetton_gold_%s.png")
        self._node_self_gold:setAnchorPoint(1,0.5)
        self._node_self_gold:setPosition(342,30.5-2)
    end

    if self._optimal_jetton then
        self._dynamic_node = cc.SpriteBatchInstance:create({width = 52,height = 52},128)
        self.view.bottomNode.dynamicBetNode:addChild(self._dynamic_node)
        self._dynamic_map = {
            [1000] = {},[10000] = {},[100000] = {},[1000000] = {},[5000000] = {},
        }
    end
    --白色筹码
    self._whiteSprite = {}

    self._btnAnimation = sp.SkeletonAnimation:create(Tree.root .. "effect/slwh_xzgd.json", Tree.root .. "effect/slwh_xzgd.atlas")
    self._btnAnimation:setAnimation(0,"animation",true)
    self._btnAnimation:retain()

    self._btnParticle = cc.ParticleSystemQuad:create(Tree.root .. "particle/slwh_cmlightlizi.plist")
    self._btnParticle:retain()
    
    self.view.bottomNode.totalBet:addChild(self._node_self_gold)
    self._node_self_gold._last_num = -1
    --玩家的个人分数
    self._layer_user_score = self.view.bottomNode.layer_user_score
    if not self._optimal then
        self._node_gold = cc.Node:create()
    else
        self._node_gold = cc.LabelFrameAtlas:create("slwh_jetton_gold_%s.png")
        self._node_gold:setAnchorPoint(0,0.5)
    end
    self._node_gold:setPosition(55,28)
    self._layer_user_score:addChild(self._node_gold)
    self._node_gold._last_num = -1
    --按钮上的高亮度遮罩
    self._spriteHightMask = cc.Sprite:createWithSpriteFrameName("slwh_bet_light.png")
    self._spriteHightMask:setPosition(110,67)
    self._spriteHightMask:retain()
    --在线玩家位置
    self._onlinePosition = {x = -550.12,y = 308.73}
    --筹码信息的列表,分帧创建
    self._choumaCreateInfo = {}
    self._isInChoumaAnimation = false
    self._tagChoumaAction = 0x778899
    self._white_object_idx = 1
end
--长按续押按钮
function SlwhJettonNewCcsView:onButtonPressedLong()
    --立即触发续押功能
    if self:requestBetContinue() then
        self.view.bottomNode.btnContinue:setVisible(false)
        self.view.bottomNode.btnAutoCancel:setVisible(true)
        self.model:setIsAutoJetton(true)
    end
end
--续押功能
function SlwhJettonNewCcsView:requestBetContinue()
    --计算是否可以续押成功,在自动续押之前,有的人手速比较快,可能进行了很多的下注导致金钱不够,此时需要做出判断
    local betRemand = self.model:getPreAreaUserBetOrder()
    local remandBet = self.controller:getOrCreateJettonMap()
    local sumary = TreeFunc.checkSumary(remandBet)

    if 0 < sumary and sumary <= self.gameStartGold and self.model:getCanJettonContinue() then
        for k = 1, 15, 1 do
            if( nil == betRemand[k] ) then
                betRemand[k] = 0
            end
        end
        reqSlwhJettonContinue(betRemand)
        return true
    end
    return false
end

function SlwhJettonNewCcsView:initLazy()
    self.btnRemand       = self.view.bottomNode.btnContinue
    self.btnCancelRemand = self.view.bottomNode.btnCancel
    self.btnClose        = self.view.bottomNode.btnClose
    self.selfName        = self.view.bottomNode.selfName
    self.btnOnline       = self.view.upNode.btnOnline
    --self.selfScore       = self.view.bottomNode.userScore
    self.onlineNumTf     = self.view.upNode.btnOnline.onlineCount_tf
    --self.onlinePoint     = self.view.bottomNode.dynamicBetNode.onlinePoint
    self.totalBet        = self.view.bottomNode.totalBet
    self.historyLv       = self.view.bottomNode.layer_menu.lvNode.list_lv
    self.onlineIcon      = self.view.upNode.btnOnline.img_online_2
    self.onlineIconPos   = cc.p( self.view.upNode.btnOnline.img_online_2:getPosition() )
    self.upNode          = self.view.upNode
    self.bottomNode      = self.view.bottomNode
    self.upNodePos       = cc.p( self.view.upNode:getPosition() )
    self.bottomNodePos   = cc.p( self.view.bottomNode:getPosition() )

    --显示特效的位置
    self._effectLocationArray = {
        [1] = {x = -501.0,y = -310.63},
        [2] = {x = -351.90,y = -310.63},
        [3] = {x = -205.90,y = -310.63},
        [4] = {x = -58.90,y = -310.63},
        [5] = {x = 89.26,y = -310.63},
    }

    self.historyLv:setItemResCcsFileName("module/slwh/csb/layer/SlwhMenuItem.csb")
    self.historyLv:setGap(0)

    --- 筹码按钮
    self.btnBets = {}
    for k = 1, 5, 1 do 
        self.btnBets[k] = self.view.bottomNode["btnBet" .. k]
    end

    self.btnBetsPositionY = {}
    for k = 1, 5, 1 do 
        self.btnBetsPositionY[k] = self.btnBets[k]:getPositionY()
    end

    --- 下注区域
    self.btnBetAreas = {}
    for k = 1, 15, 1 do 
        self.btnBetAreas[k] = self.view.bottomNode["btnBetArea" .. k]
        self.btnBetAreas[k]:setIsIgnoreSound( true )
    end

    --- 玩家
    self.playersInfo = {}
    for k = 1, 4, 1 do 
        self.playersInfo[k] = { head = self.view.upNode["head" .. k],
                                name = self.view.upNode["playerName" .. k],
                                gold = self.view.upNode["playerGold" .. k .. "_tf"], 
                                freeTip = self.view.upNode["freeTip" .. k],
                                headCircle = self.view.upNode["headCircle" .. k],
                                headPosition = cc.p( self.view.upNode["head" .. k]:getPosition() ),
                                headCirclePosition = cc.p( self.view.upNode["headCircle" .. k]:getPosition() ) }
    end
   
    --- 自己单区域下注
    self.txtSelfBetted = {}
     --- 区域总下注
     self.txtTotalBetted = {}

    --- 位置点
    self.betSpStartPoint = {}
    self.betSpStartPoint.playerHead = {}
    self.betSpStartPoint.btnBet = {}
    self.betSpStartPoint.betArea = {}
    for k = 1, 4, 1 do 
        self.betSpStartPoint.playerHead[k] = Tree.JettonHeadPoints[k]--cc.p( self.view.bottomNode.dynamicBetNode["playerHeadPoint" .. k]:getPositionX(),self.view.bottomNode.dynamicBetNode["playerHeadPoint" .. k]:getPositionY() )
    end
    for k = 1, 5, 1 do 
        self.betSpStartPoint.btnBet[k] = Tree.JettonBetPoints[k]--cc.p( self.view.bottomNode.dynamicBetNode["betBtnPoint" .. k]:getPositionX(), self.view.bottomNode.dynamicBetNode["betBtnPoint" .. k]:getPositionY() )
    end
    for k = 1, 15, 1 do 
        self.betSpStartPoint.betArea[k] = Tree.JettonAreaPoints[k]--cc.p( self.view.bottomNode.dynamicBetNode["areaMidPoint" .. k]:getPositionX(),  self.view.bottomNode.dynamicBetNode["areaMidPoint" .. k]:getPositionY() )
    end

    --- 筹码精灵缓存
    self.betSpCache = {}
    self.othersBetSp = {}
    self.selfBetSp = {}
    self.whitePoints = {}
    self.betSpLocalZOrder = 0

    self.randomFuckerHead = 
    {
        [1] = {1},
        [2] = {1, 3},
        [3] = {1, 3, 4},
        [4] = {1, 3, 4},
    }

end

function SlwhJettonNewCcsView:onShow()
    self:startBetTimer()
    self:playPanelAnimation( true )
    if( false == SLWH_AFTER_WITHDRAWAL_CAN_BET ) then 
        self.gameStartGold = self.model:getSelfBetStartMoneyTemp()
    else
        self.gameStartGold = Hero:getUserScore()
    end
    self.currSelectedBtnBetIdx = -1

    self.historyLv:jumpToPercent( 0, 0 )
    self:dynamicBetScore()
    self:initEventListener()
    self:onUserScoreChanged()
    self:onNickNameChanged()
    self:evtUserData()
    self:checkLights(-1)

    --self:checkRemandStatus()
    self:checkContinueOnShow()
    --注册事件监听
    self.btnRemand:setCanLongClick(true)
    self.btnRemand:setLongClickBeginIntervalMs(1000)
    self.btnRemand:getLongClickSignal():add(self.onButtonPressedLong,self)
    --self:checkCancelRemandStatus()

    self:updateMulti()
    self:updateBetted( true )
    if( self.gameStartGold >= Tree.BetScoreBaseConfig[1] ) then 
        self:updateBetBtnPosition(1)
    else
        self:updateBetBtnPosition(-1)
    end
    self:updateBetBtnEnable()
    for _, value in pairs( self.othersBetSp) do
        for _, v in pairs( value ) do 
            if( v ) then
                if not self._optimal_jetton then
                    v:stopAllActions()
                end
                v:setPosition(v.slwhEndPosition.x,v.slwhEndPosition.y)
            end
        end
    end
    for k, value in pairs(self.selfBetSp) do
        for _, v in pairs( value ) do 
            if not self._optimal_jetton then
                v:stopAllActions()
            end
            v:setPosition(v.slwhEndPosition.x,v.slwhEndPosition.y)
        end
    end
    for k, value in pairs(self.whitePoints) do
        value:stopAllActions()
        value:removeFromParent()
        self.whitePoints[k] = nil
        table.insert(self._whiteSprite,value)
    end

    self:evtRefreshHistory( {tAwardRecord = self.model:getHistoryRewards()} )
end

function SlwhJettonNewCcsView:onHide()
    self:removeEventListener()
    self.historyLv:jumpToPercent( 0, 0 )
    self:evtCloseView()
    TreeEventDispatcher:dispatchEvent(Tree.Event.showAllModels)
    self._spriteHightMask:removeFromParent()
    self.btnRemand:getLongClickSignal():remove(self.onButtonPressedLong,self)
    --
    self:stopActionByTag(self._tagChoumaAction)
    self._isInChoumaAnimation = false
    self._choumaCreateInfo = {}
end

------------------------------------------------------------------------------------------------------------

function SlwhJettonNewCcsView:initEventListener()
    gameMgr.sortedUsersChangedSignal:add(self.evtUserData, self)
    Hero.userScoreChangedSignal:add(self.onUserScoreChanged,self)
    Hero.pNickNameChangedSignal:add(self.onNickNameChanged, self)
    TreeEventDispatcher:addEventListener( Tree.Event.loadScene, self.evtRefreshHistory, self )
    TreeEventDispatcher:addEventListener( Tree.Event.gameOver, self.evtGameOver, self )
    TreeEventDispatcher:addEventListener( Tree.Event.gameBet, self.evtJetton, self )
    TreeEventDispatcher:addEventListener( Tree.Event.gameBetContinue, self.evtRemand, self )
    TreeEventDispatcher:addEventListener( Tree.Event.closeJettonView, self.closeJettonView, self )
    TreeEventDispatcher:addEventListener( Tree.Event.cancelAllBets, self.evtCancelBet, self )
    TreeEventDispatcher:addEventListener( Tree.Event.closeGame, self.evtExitGame, self )
end

function SlwhJettonNewCcsView:removeEventListener()
    gameMgr.sortedUsersChangedSignal:remove(self.evtUserData, self)
    Hero.userScoreChangedSignal:remove( self.onUserScoreChanged, self )
    Hero.pNickNameChangedSignal:remove( self.onNickNameChanged, self )
    TreeEventDispatcher:removeEventListener( Tree.Event.loadScene, self.evtRefreshHistory, self )
    TreeEventDispatcher:removeEventListener( Tree.Event.gameOver, self.evtGameOver, self )
    TreeEventDispatcher:removeEventListener( Tree.Event.gameBet, self.evtJetton, self )
    TreeEventDispatcher:removeEventListener( Tree.Event.gameBetContinue, self.evtRemand, self )
    TreeEventDispatcher:removeEventListener( Tree.Event.closeJettonView, self.closeJettonView, self )
    TreeEventDispatcher:removeEventListener( Tree.Event.cancelAllBets, self.evtCancelBet, self )
    TreeEventDispatcher:removeEventListener( Tree.Event.closeGame, self.evtExitGame, self )
end

function SlwhJettonNewCcsView:onUserScoreChanged()
    --开奖阶段,玩家的数字不更新----
    if self.model:getUserGameStatus() ~= Tree.Status.Over then
        local user_score = Hero:getUserScore()
        local score_width = 0
        if self._node_gold._last_num ~= user_score then
            self._node_gold._last_num = user_score
            if not self._optimal then
                if user_score >= 10000 then
                    user_score = user_score + 0.25
                end
            --self.selfScore:setStrTxt( HtmlUtil.createArtNumWithHansUnits(user_score,"#slwh_jetton_gold_%s.png"))
            --设置分数加上和对齐
                SlwhJettonCache:sampleCacheObject(self._node_gold)
            --创建Sprite Number
                local dimension = {}
                SlwhJettonCache:createSpriteNumberWith1WY(user_score,"slwh_slef_gold_%s",dimension,{x=0,y=0.5},self._node_gold)
                score_width = dimension.width
            else
                self._node_gold:setString(TreeFunc.formatNumberWY(user_score))
                score_width = self._node_gold:getContentSize().width
            end
            self._layer_user_score.bg:setContentSize(cc.size(score_width + 86,46))
        end
    end
end

function SlwhJettonNewCcsView:onNickNameChanged()
    local name = Hero:getPNickName()
    name = StringUtil.truncate(name, 10, nil, 2)
    self.selfName:setString(name)
end

function SlwhJettonNewCcsView:doShowCustomPopupEffect( onComplete )
    self:playPanelAnimation( true, onComplete )
    --print("----on show--->")
end

function SlwhJettonNewCcsView:doHideCustomPopupEffect( onComplete )
	self:playPanelAnimation( false, onComplete )
    --print("----on hide--->")
end

------------------------------------------------------------------------------------------------------------

function SlwhJettonNewCcsView:onBtnClick( target, event )
--    if target == self.btnCancelRemand then
--        reqSlwhCancelJetton()
--    else
    if target == self.btnOnline then
		self.model:setIsShowingOnline(true)
    elseif target == self.view.bottomNode.btnAutoCancel then--取消了自动
        local remandBet = self.controller:getOrCreateJettonMap()
        local sumary = TreeFunc.checkSumary(remandBet)

        local touch_enabled = 0 < sumary and sumary <= self.gameStartGold and self.model:getCanJettonContinue()
        self.btnRemand:setCanTouch(touch_enabled)
        self.model:setIsAutoJetton(false)
        self.view.bottomNode.btnAutoCancel:stopActionByTag(0x778899)
        self.btnRemand:setVisible(true)
        self.btnRemand:setBackGroundImage(touch_enabled and "slwh_jetton_continue_auto.png" or "slwh_jetton_continue_auto_disable.png",1)
        self.view.bottomNode.btnAutoCancel:setVisible(false)
    elseif target == self.btnRemand then
        --self.btnRemand:setEnabled(false)
        local betRemand = self.model:getPreAreaUserBetOrder()
        for k = 1, 15, 1 do
            if( nil == betRemand[k] ) then
                betRemand[k] = 0
            end
        end
        reqSlwhJettonContinue(betRemand)
    elseif target == self.btnClose then
        self:closeJettonView()
    else
        local button_tag = target:getTag()
        if button_tag >= 1 and button_tag <= 15 or button_tag >= 101 and button_tag <= 105 then
            if button_tag >= 101 and button_tag <= 105 then
                self.currSelectedBtnBetIdx = button_tag - 100
                self:updateBetBtnPosition(button_tag - 100)
                return
            end
            ---------------------------------------
--            for k, v in pairs( self.btnBets) do
--                if( v == target ) then 
--                    self.currSelectedBtnBetIdx = k
--                    self:updateBetBtnPosition( k )
--                    return
--                end
--            end
            -----------------------------------------
            local target_button_index = button_tag
            if( -1 ~= self.currSelectedBtnBetIdx ) then 
                self:checkLights(target_button_index)
                reqSlwhJetton({nJettonArea=target_button_index - 1, lBet=Tree.BetScoreBaseConfig[self.currSelectedBtnBetIdx]})
            else
                --如果玩家的金钱不小于最低的筹码
                if self.gameStartGold < Tree.BetScoreBaseConfig[1] then
                    tweenMsgMgr:showRedMsg("金额不足，无法下注")
                else
                    tweenMsgMgr:showRedMsg("请选择下注筹码")
                end
            end
        end
    end
end

------------------------------------------------------------------------------------------------------------

function SlwhJettonNewCcsView:evtRefreshHistory( evtData )
    local rewardList = TreeFunc.trunk( evtData.tAwardRecord, 20 )
    local index = #rewardList
    while index > 0 do
        if rewardList[index].cbType == Tree.RewardType.RewardType_None then
            table.remove( rewardList, index )
        end
        index = index - 1
    end
    TreeFunc.assignIndex(rewardList)
    self.historyLv:setDatas( rewardList, true )
end

function SlwhJettonNewCcsView:evtGameOver( evtData )
    --self:evtRefreshHistory( evtData )
end

function SlwhJettonNewCcsView:evtUserData()
    self.userDatas = TableUtil.copyData( TableUtil.toArray(gameMgr:getUserDatasDic()) )
	local userNum = #self.userDatas
    self.onlineNumTf:setHtmlText( HtmlUtil.createArtNum( userNum, "#slwh_jetton_online_%s.png" ), true )

    local exceptUserIDs = {}
    table.insert( exceptUserIDs, Hero:getDwUserID() )
    self.userDatas = gameMgr:getSortedUsers( exceptUserIDs, 4 )
    self:updatePlayerHead()
end

function SlwhJettonNewCcsView:startBetTimer()
    if( not self.betTimer ) then 
        self.betTimer = cc.Node:create()
        self:addChild( self.betTimer )
        local function showingBet()
            local netJetton = self.controller:getNetJetton()
            if( netJetton ) then 
                self.controller:_onMsgGameBet( netJetton )
            end
        end
        self.betTimer:runAction( cc.RepeatForever:create( cc.Sequence:create( cc.CallFunc:create( showingBet ), cc.DelayTime:create(0.1) ) ) )
    end
    if( not self.betRemandTimer ) then 
        self.betRemandTimer = cc.Node:create()
        self:addChild( self.betRemandTimer )
        local function showingBet()
            local netJettonRemand = self.controller:getNetRemand()
            if( netJettonRemand ) then 
                self.controller:_onMsgGameBetContinue( netJettonRemand )
            end
        end
        self.betRemandTimer:runAction( cc.RepeatForever:create( cc.Sequence:create( cc.DelayTime:create(1.5), cc.CallFunc:create( showingBet ) ) ) )
    end
end

function SlwhJettonNewCcsView:updateChoumaAnimation()
    if not self._isInChoumaAnimation then
        self._isInChoumaAnimation = true
        self:changeChoumaAnimation()
    end
end

function SlwhJettonNewCcsView:changeChoumaAnimation()
    if #self._choumaCreateInfo > 0 then
        local create_info = table.remove(self._choumaCreateInfo,1)
        local sprite = self:playBetSp2Area(create_info.head_idx,create_info.area_idx,create_info.score,create_info.head_pos,create_info.move_duration)
        if not self.othersBetSp[create_info.area_idx]then 
            self.othersBetSp[create_info.area_idx] = {}
        end
        if sprite then 
            table.insert(self.othersBetSp[create_info.area_idx],sprite)
        end
        local action = cc.Sequence:create(cc.DelayTime:create(0.03),
                                cc.CallFunc:create(function()
                                    self:changeChoumaAnimation()
                                end))
        action:setTag(self._tagChoumaAction)
        self:runAction(action)
     else
        self._isInChoumaAnimation = false
    end
end

function SlwhJettonNewCcsView:evtJetton( evtData )
    if( evtData.cbRet == Tree.JettonRetType.RetType_Success ) then
        if( Hero:getWChairID() == evtData.wChairID ) then 
            Hero:addUserFakeScore( evtData.lScore * -1 )
            if( false == SLWH_AFTER_WITHDRAWAL_CAN_BET ) then 
                -- Hero:setUserScore(self.gameStartGold - evtData.lScore)
                -- Hero:addUserFakeScore( evtData.lScore * -1 )
                self.gameStartGold = self.gameStartGold - evtData.lScore
                self.model:setSelfBetStartMoneyTemp(self.gameStartGold)
            else
                -- Hero:setUserScore(Hero:getUserScore() - evtData.lScore)
                self.gameStartGold = Hero:getUserScore()
            end
            self.model:setUserTotalJetton(self.model:getUserTotalJetton() + evtData.lScore)
            self.model:setIsAutoJetton(false)--取消自动续押
            --设置位已经续押完毕标志
            self.model:setIsJettonContinue(true)
            self:checkRemandStatus()
            --
            self:updateBetBtnStatusAfterJetton()
            local sp = self:playBetSp2Area( nil, evtData.nArea + 1, evtData.lScore, self.betSpStartPoint.btnBet[SLWH_BET_BTN_IDX[evtData.lScore]], 0.15 )
            if( not self.selfBetSp[evtData.nArea+1] ) then self.selfBetSp[evtData.nArea+1] = {} end
            if( sp ) then table.insert( self.selfBetSp[evtData.nArea+1], sp ) end
            self:updateBetted()
        else
            -- self.netJetton[ #self.netJetton + 1 ] = evtData 
            local onlineUsers = self.userDatas 
            if( nil == onlineUsers ) then 
                self.userDatas = TableUtil.copyData( TableUtil.toArray(gameMgr:getUserDatasDic()) )
                local exceptUserIDs = {}
                table.insert( exceptUserIDs, Hero:getDwUserID() )
                self.userDatas = gameMgr:getSortedUsers( exceptUserIDs, 4 )
                onlineUsers = self.userDatas
            end
            if( nil == onlineUsers ) then return end
            for k = 1, 4, 1 do 
                if( nil ~= onlineUsers[k] and evtData.wChairID == onlineUsers[k].wChairID ) then 
                    table.insert(self._choumaCreateInfo,{
                        head_idx = k,
                        area_idx = evtData.nArea + 1,
                        score = evtData.lScore,
                        head_pos = self.betSpStartPoint.playerHead[k],
                        move_duration = 0.3,
                    })
                    self:updateChoumaAnimation()
                    self:updateBetted()
                    return
                end
            end
            table.insert(self._choumaCreateInfo,{
                head_idx = 5,
                area_idx = evtData.nArea + 1,
                score = evtData.lScore,
                head_pos = self._onlinePosition,
                move_duration = 0.3,
            })
            self:updateChoumaAnimation()
            self:updateBetted()
        end
    elseif( evtData.cbRet == Tree.JettonRetType.RetType_ReachAreaLimit ) then
        tweenMsgMgr:showRedMsg("下注失败,已达区域投注上限")
    elseif( evtData.cbRet == Tree.JettonRetType.RetType_ReachPersonalLimit ) then
        tweenMsgMgr:showRedMsg("下注失败,已达个人区域投注上限")
    elseif( evtData.cbRet == Tree.JettonRetType.RetType_ZhuangXianOnlyOne ) then
        tweenMsgMgr:showRedMsg("您不能同时下注庄、闲")
    end
end

function SlwhJettonNewCcsView:evtRemand( evtData )
    if( evtData.cbRet == Tree.JettonRetType.RetType_Success ) then
        if(evtData.wChairID == Hero:getWChairID()) then
            self.model:setCanJettonContinue(false)
            self.model:setIsJettonContinue(true)
        end
        for k, v in pairs( evtData.lBet or {} ) do 
            if( 0 < v ) then 
                if( evtData.wChairID == Hero:getWChairID() ) then 
                    Hero:addUserFakeScore( v * -1 )
                    if( false == SLWH_AFTER_WITHDRAWAL_CAN_BET ) then 
                        -- Hero:setUserScore((self.gameStartGold) - v)
                        self.gameStartGold = self.gameStartGold - v
                        self.model:setSelfBetStartMoneyTemp(self.gameStartGold)
                    else
                        -- Hero:setUserScore(Hero:getUserScore() - v)
                        self.gameStartGold = Hero:getUserScore()
                    end
                    self.model:setUserTotalJetton(self.model:getUserTotalJetton() + v)
                end
                local reduceScore = self:score2BetSpCount(v)
                for _, subScore in pairs( reduceScore or {} ) do 
                    if( evtData.wChairID == Hero:getWChairID() ) then
                        local sp = self:playBetSp2Area( nil, k, subScore, self.betSpStartPoint.btnBet[SLWH_BET_BTN_IDX[subScore]], 0.15 )
                        if( not self.selfBetSp[k] ) then self.selfBetSp[k] = {} end
                        if( sp ) then table.insert( self.selfBetSp[k], sp ) end
                    else
                        local onlineUsers = self.userDatas
                        if( nil == onlineUsers ) then 
                            self.userDatas = TableUtil.copyData( TableUtil.toArray(gameMgr:getUserDatasDic()) )
                            local exceptUserIDs = {}
                            table.insert( exceptUserIDs, Hero:getDwUserID() )
                            self.userDatas = gameMgr:getSortedUsers( exceptUserIDs, 4 )
                            onlineUsers = self.userDatas
                        end
                        if( nil == onlineUsers ) then return end
                        local isFour = false
                        for kk = 1, 4, 1 do 
                            if( nil ~= onlineUsers[kk] and evtData.wChairID == onlineUsers[kk].wChairID ) then
                                table.insert(self._choumaCreateInfo,{
                                    head_idx = kk,
                                    area_idx = k,
                                    score = subScore,
                                    head_pos = self.betSpStartPoint.playerHead[kk],
                                    move_duration = 0.3,
                                })
                                self:updateChoumaAnimation()
                                isFour = true
                                break
                            end
                        end
                        if( false == isFour ) then
                            table.insert(self._choumaCreateInfo,{
                                head_idx = 5,
                                area_idx = k,
                                score = subScore,
                                head_pos = self._onlinePosition,
                                move_duration = 0.3,
                            })
                            self:updateChoumaAnimation()
                        end
                    end
                end
            end
        end
        if( evtData.wChairID == Hero:getWChairID() ) then
            self:checkRemandStatusContinue()--added
            self:updateBetBtnStatusAfterJetton()
        end
        self:updateBetted()
    elseif( evtData.cbRet == Tree.JettonRetType.RetType_ReachAreaLimit ) then
        tweenMsgMgr:showRedMsg("下注失败,已达区域投注上限")
    elseif( evtData.cbRet == Tree.JettonRetType.RetType_ReachPersonalLimit ) then
        tweenMsgMgr:showRedMsg("下注失败,已达个人区域投注上限")
    elseif( evtData.cbRet == Tree.JettonRetType.RetType_ZhuangXianOnlyOne ) then
        tweenMsgMgr:showRedMsg("您不能同时下注庄、闲")
    end
end

--回收所有的已经分配的资源
function SlwhJettonNewCcsView:evtCloseView(evtData)
    if( self.betTimer ) then 
        self.betTimer:stopAllActions()
        self.betTimer:removeFromParent()
        self.betTimer = nil
    end
    if( self.betRemandTimer ) then 
        self.betRemandTimer:stopAllActions()
        self.betRemandTimer:removeFromParent()
        self.betRemandTimer = nil
    end
    self:checkRemandStatus()
    --local cacheNum = #self.selfBetSp + #self.othersBetSp 
    for k, value in pairs(self.othersBetSp) do
        for _, v in pairs( value ) do
            if not self._optimal_jetton then
                v:stopAllActions()
                SlwhJettonCache:recycleObject(v)
            else
                --self._dynamic_node:removeInstance(v)
                v:removeFromParent()
                table.insert(self._dynamic_map[v.__score_num], v)
            end
        end
    end
    for k, value in pairs(self.selfBetSp) do
        for _, v in pairs( value ) do
            if not self._optimal_jetton then
                v:stopAllActions()
                SlwhJettonCache:recycleObject(v)
            else
                --self._dynamic_node:removeInstance(v)
                v:removeFromParent()
                table.insert(self._dynamic_map[v.__score_num], v)
            end
        end
    end
    for k, value in pairs(self.whitePoints) do
        value:stopAllActions()
        value:removeFromParent()
        self.whitePoints[k] = nil
        table.insert(self._whiteSprite,value)
    end

    -- for object_idx,sprite in pairs(self.whitePoints) do
    --     sprite:removeFromParent()
    --     table.insert(self._whiteSprite,sprite)
    -- end

    self.othersBetSp = {}
    self.selfBetSp = {}
    self.whitePoints = {}
    self.betSpLocalZOrder = 0

    for k, v in pairs( self.playersInfo or {} ) do 
        v.head:stopAllActions()
        v.headCircle:stopAllActions()
        v.head:setPosition( v.headPosition )
        v.headCircle:setPosition( v.headCirclePosition )
    end

    if( self.gameEffectTick ) then 
        self.gameEffectTick:destroy()
        self.gameEffectTick = nil
    end
end

function SlwhJettonNewCcsView:evtCancelBet( evtData )
    -- if( Hero:getWChairID() == evtData.wChairID ) then 
    --     if( false == SLWH_AFTER_WITHDRAWAL_CAN_BET ) then 
    --         self.gameStartGold = self.model:getSelfBetStartMoney()
    --         self.model:setSelfBetStartMoneyTemp(self.gameStartGold)
    --     else
    --         self.gameStartGold = Hero:getUserScore()
    --     end
    --     self:checkRemandStatus()
    --     self:checkCancelRemandStatus()
    --     self:checkLights(-1)
    --     self:updateBetBtnPosition( self.currSelectedBtnBetIdx )
    --     self:updateBetBtnEnable()
    -- end
    -- for k, value in pairs( self.selfBetSp or {} ) do 
    --     for _, v in pairs( value ) do
    --         if( v ) then v:removeFromParent() end
    --     end
    -- end
    -- self.selfBetSp = {}
    -- for k, value in pairs( self.othersBetSp or {} ) do 
    --     for _, v in pairs( value ) do
    --         if( v ) then v:removeFromParent() end
    --     end
    -- end
    -- self.othersBetSp = {}
    -- self:updateBetted( true )
end

function SlwhJettonNewCcsView:evtExitGame( evtData )
    if( self.betTimer ) then 
        self.betTimer:stopAllActions()
        self.betTimer:removeFromParent()
        self.betTimer = nil
    end
    if( self.betRemandTimer ) then 
        self.betRemandTimer:stopAllActions()
        self.betRemandTimer:removeFromParent()
        self.betRemandTimer = nil
    end
    self:removeEventListener()
end

------------------------------------------------------------------------------------------------------------

function SlwhJettonNewCcsView:playPanelAnimation( isOpen, onComplete )
    if( true == isOpen ) then
        self.shadowBg:setVisible(true)
        TweenLite.to(self.bg111, 0.2, { autoAlpha = 1 })
        self.upNode:stopAllActions()
        self.bottomNode:stopAllActions()
        self.upNode:setPosition( self.upNodePos.x, self.upNodePos.y + 652.4 )
        self.bottomNode:setPosition( self.bottomNodePos.x, self.bottomNodePos.y - 652.4 )

        local function onCompleteUpNode()
            self.upNode:setPosition( self.upNodePos )
        end
        local function onCompleteBottomNode()
            self.bottomNode:setPosition( self.upNodePos )
            if( onComplete ) then onComplete() end
        end

        local moveTo1 = cc.EaseCubicActionOut:create( cc.MoveTo:create( 9/60, cc.p( self.upNodePos.x, self.upNodePos.y - 1.93 ) ) )
        local moveTo2 = cc.EaseCubicActionOut:create( cc.MoveTo:create( 9/60, cc.p( self.bottomNodePos.x, self.bottomNodePos.y + 1.93 ) ) )
        local moveTo12 = cc.EaseCubicActionInOut:create( cc.MoveTo:create( 4/30, cc.p( self.upNodePos.x, self.upNodePos.y + 1.146 ) ) )
        local moveTo22 = cc.EaseCubicActionInOut:create( cc.MoveTo:create( 4/30, cc.p( self.bottomNodePos.x, self.bottomNodePos.y - 1.146 ) ) )
        local moveTo13 = cc.EaseCubicActionInOut:create( cc.MoveTo:create( 5/30, cc.p( self.upNodePos.x, self.upNodePos.y ) ) )
        local moveTo23 = cc.EaseCubicActionInOut:create( cc.MoveTo:create( 5/30, cc.p( self.bottomNodePos.x, self.bottomNodePos.y ) ) )
        local action1 = cc.Sequence:create( moveTo1, moveTo12, moveTo13, cc.CallFunc:create( onCompleteUpNode ) )
        local action2 = cc.Sequence:create( moveTo2, moveTo22, moveTo23, cc.CallFunc:create( onCompleteBottomNode ) )
        self.upNode:runAction( action1 )
        self.bottomNode:runAction( action2 )

    else
        TreeEventDispatcher:dispatchEvent(Tree.Event.showAllModels)
        self.shadowBg:setVisible(false)
        TweenLite.to(self.bg111, 0.2, { autoAlpha = 0 })
        self.upNode:stopAllActions()
        self.bottomNode:stopAllActions()
        self.upNode:setPosition( self.upNodePos.x, self.upNodePos.y )
        self.bottomNode:setPosition( self.bottomNodePos.x, self.bottomNodePos.y )
        self.upNode:runAction(  cc.Sequence:create( cc.MoveTo:create(0.2, cc.p( self.upNodePos.x, self.upNodePos.y + 500 ) ), cc.CallFunc:create(
            function()
                self.upNode:setPosition( cc.p( self.upNodePos.x, self.upNodePos.y + 500 ) )
            end
        )))
        self.bottomNode:runAction( cc.Sequence:create( cc.MoveTo:create(0.2, cc.p( self.bottomNodePos.x, self.bottomNodePos.y - 1000 ) ), cc.CallFunc:create(
            function()
                self.bottomNode:setPosition( cc.p( self.bottomNodePos.x, self.bottomNodePos.y - 1000 ) )
                self.model:setIsShowingJetton(false)
                if( onComplete ) then onComplete() end
            end
        )))
    end
end

function SlwhJettonNewCcsView:dynamicBetScore()
    --for k = 1, 5, 1 do 
    --    local splitString = StringUtil.splitNumWithString( Tree.BetScoreBaseConfig[k], false, true )
     --   self.btnBets[k].betBtnScore_tf:setHtmlText( HtmlUtil.createNum( splitString, "#slwh_jetton_bet_big_" .. tostring(k) .. "_%s.png" ), true )
    --end
end

function SlwhJettonNewCcsView:closeJettonView()
    self:evtCloseView()
    self:playPanelAnimation(false)
end

function SlwhJettonNewCcsView:checkLights( idx )
    --for k = 1, 15, 1 do 
    --    self.betLights[k]:setVisible(idx == k)
    --end
    self._spriteHightMask:removeFromParent()
    if idx ~= -1 then
        self.btnBetAreas[idx]:addChild(self._spriteHightMask)
    end
end
--取消自动续押,由玩家手动下注引发
function SlwhJettonNewCcsView:cancelJettonAutoContinue()
    self.btnRemand:setCanTouch(false)
    self.model:setIsAutoJetton(false)
    self.view.bottomNode.btnAutoCancel:stopActionByTag(0x778899)
    self.btnRemand:setVisible(true)
    self.btnRemand:setBackGroundImage("slwh_jetton_continue_auto_disable.png",1)
    self.view.bottomNode.btnAutoCancel:setVisible(false)
end
--只用在刚开始加载界面的时候调用
function SlwhJettonNewCcsView:checkContinueOnShow()
    local remandBet = self.controller:getOrCreateJettonMap()
    local sumary = TreeFunc.checkSumary(remandBet)
    --modify
    if 0 < sumary and sumary <= self.gameStartGold then
        --此时需要判断是否已经设置了长按标志
        if self.model:getIsAutoJetton() then
            self.btnRemand:setVisible(false)
            self.view.bottomNode.btnAutoCancel:setVisible(true)
            --加载动作,如果还没有续押的话
            if not self.model:getIsJettonContinue() then
                local request_action = cc.Sequence:create(cc.DelayTime:create(2.5 + math.random() * 1.5),
                        cc.CallFunc:create(function()
                            self:requestBetContinue()
                        end))
                request_action:setTag(0x778899)
                self.view.bottomNode.btnAutoCancel:runAction(request_action)
            end
        else
            self.btnRemand:setCanTouch(not self.model:getIsJettonContinue())
            self.btnRemand:setBackGroundImage(not self.model:getIsJettonContinue() and "slwh_jetton_continue_auto.png" or "slwh_jetton_continue_auto_disable.png",1)
            self.btnRemand:setVisible(true)
            self.view.bottomNode.btnAutoCancel:setVisible(false)
        end
    else
        --如果玩家开局的时候,金钱足够,但是现在不够了,并且现在处于自动续押中,则继续显示续押
        if sumary > 0 and sumary <=self.model:getUserScoreOnStrat() and self.model:getIsAutoJetton() then
            self.btnRemand:setVisible(false)
            self.view.bottomNode.btnAutoCancel:setVisible(true)
        else
            self.btnRemand:setCanTouch(false)
            self.btnRemand:setBackGroundImage("slwh_jetton_continue_auto_disable.png",1)
            self.btnRemand:setVisible(true)
            self.view.bottomNode.btnAutoCancel:setVisible(false)
            --取消自动续押
            self.model:setIsAutoJetton(false)
        end
    end
end

function SlwhJettonNewCcsView:checkRemandStatusContinue()
    local remandBet = self.controller:getOrCreateJettonMap()
    local sumary = TreeFunc.checkSumary(remandBet)
    --modify
    if 0 < sumary and sumary <= self.gameStartGold then-- and true == self.model:getCanJettonContinue() then 
        --此时需要判断是否已经长按了续押按钮
        if not self.model:getIsAutoJetton() then--如果不是自动的状态下,需要判断是否可以继续点击续押按钮
            self.view.bottomNode.btnAutoCancel:setVisible(false)
            self.btnRemand:setVisible(true)
            self.btnRemand:setCanTouch(not self.model:getIsJettonContinue())
            self.btnRemand:setBackGroundImage(not self.model:getIsJettonContinue() and "slwh_jetton_continue_auto.png" or "slwh_jetton_continue_auto_disable.png",1)
        else
            self.btnRemand:setVisible(false)
            self.view.bottomNode.btnAutoCancel:setVisible(true)
        end
    else
        --如果处于自动续押中,则不进行变化
        if not self.model:getIsAutoJetton() then
            self.btnRemand:setVisible(true)
            self.btnRemand:setCanTouch(false)
            self.btnRemand:setBackGroundImage("slwh_jetton_continue_auto_disable.png",1)
            self.view.bottomNode.btnAutoCancel:setVisible(false)
        else
            self.btnRemand:setVisible(false)
            self.view.bottomNode.btnAutoCancel:setVisible(true)
        end
    end
end
--续押按钮点击返回数据后的回调函数
function SlwhJettonNewCcsView:checkRemandStatus()
    local remandBet = self.controller:getOrCreateJettonMap()
    local sumary = TreeFunc.checkSumary(remandBet)
    --modify
    if 0 < sumary and sumary <= self.gameStartGold then-- and true == self.model:getCanJettonContinue() then 
        --此时需要判断是否已经长按了续押按钮
        if not self.model:getIsAutoJetton() then--如果不是自动的状态下,需要判断是否可以继续点击续押按钮
            self.view.bottomNode.btnAutoCancel:setVisible(false)
            self.btnRemand:setVisible(true)
            self.btnRemand:setCanTouch(false)
            self.btnRemand:setBackGroundImage("slwh_jetton_continue_auto_disable.png",1)
            self.view.bottomNode.btnAutoCancel:stopActionByTag(0x778899)
        else
            self.btnRemand:setVisible(false)
            self.view.bottomNode.btnAutoCancel:setVisible(true)
        end
    else
        --如果处于自动续押中,则不进行变化
        if not self.model:getIsAutoJetton() then
            self.btnRemand:setVisible(true)
            self.btnRemand:setCanTouch(false)
            self.btnRemand:setBackGroundImage("slwh_jetton_continue_auto_disable.png",1)
            self.view.bottomNode.btnAutoCancel:stopActionByTag(0x778899)
            self.view.bottomNode.btnAutoCancel:setVisible(false)
        else
            self.btnRemand:setVisible(false)
            self.view.bottomNode.btnAutoCancel:setVisible(true)
        end
    end
end
--因为干掉了撤销按钮,因此此函数也就没有什么作用了
function SlwhJettonNewCcsView:checkCancelRemandStatus()
    local areaBetted = self.model:getAreaUserBetArray()
    for k = 1, 15, 1 do 
        if( 0 < areaBetted[k] ) then 
            return
        end
    end
end

function SlwhJettonNewCcsView:updateMulti()
    local areaMulti = self.model:getAreaBetMultiplyArray()
    --缓存二元模板
    local object_format = "slwh_%s_m_%%s"
    local anchor_point = {x=0.5,y= 0.5}
    for k = 1, 15, 1 do 
        --self.txtMulti[k]:setHtmlText( HtmlUtil.createArtNum( areaMulti[k], SLWH_MULTI_FONT[k] ), true )
        --比较相等于否
        if self._nodeMultiplys[k]._last_num ~= areaMulti[k] then
            self._nodeMultiplys[k]._last_num = areaMulti[k]
            if not self._optimal then
                --计算模板
                local object_key = string.format(object_format,Tree.JettonColorMap[k])
                --抽取出缓存对象
                SlwhJettonCache:sampleCacheObject(self._nodeMultiplys[k])
                SlwhJettonCache:createSpriteNumber(areaMulti[k],object_key,nil,anchor_point,self._nodeMultiplys[k])
            else
                self._nodeMultiplys[k]:setString(tostring(areaMulti[k]))
            end
        end
    end
end

function SlwhJettonNewCcsView:updateBetted(syncBetSp)
    local areaBetted = self.model:getAreaUserBetArray()
    local anchor_point = {x = 0.0,y = 0.5}
    for k = 1, 15, 1 do 
        local node_self_score = self._nodeSelfScores[k]
        if node_self_score._last_num ~= areaBetted[k] then
            node_self_score._last_num = areaBetted[k]
            if not self._optimal then
                --提取出缓存对象
                SlwhJettonCache:sampleCacheObject(node_self_score)
                --设置Sprite Number
                local object_key = string.format("slwh_%s_j_%%s",Tree.JettonColorMap[k])
                SlwhJettonCache:createSpriteNumberWith1Y(areaBetted[k],object_key,nil,anchor_point,node_self_score)
            else
                node_self_score:setString(TreeFunc.formatNumber(areaBetted[k]))
            end
        end

        if( areaBetted[k] > 0 ) then 
            if( true == syncBetSp ) then 
                local reduceScore = self:score2BetSpCount(areaBetted[k])
                for _, subScore in pairs( reduceScore or {} ) do 
                    local sp = self:playBetSp2Area( nil, k, subScore, nil, nil, false )
                    if( not self.selfBetSp[k] ) then self.selfBetSp[k] = {} end
                    if( sp ) then table.insert( self.selfBetSp[k], sp ) end
                end
            end
        end
    end

    local areaTotalBetted = self.model:getAreaTotalBetArray()
    --二元缓存模板
    local object_secondary_key = "slwh_%s_jt_%%s"
    local anchor_point = {x=0.0,y=0.5}
    for k = 1, 15, 1 do 
        --检测并抽取出缓存对象
        local node_total_score = self._nodePlayerScores[k]
        if node_total_score._last_num ~= areaTotalBetted[k] then
            node_total_score._last_num = areaTotalBetted[k]
            if not self._optimal then
                local object_key = string.format(object_secondary_key,Tree.JettonColorMap[k])
                SlwhJettonCache:sampleCacheObject(node_total_score)
                --创建Sprite Number
                SlwhJettonCache:createSpriteNumberWith1Y(areaTotalBetted[k],object_key,nil,anchor_point,node_total_score)
            else
                node_total_score:setString(TreeFunc.formatNumber(areaTotalBetted[k]))
            end
        end
        if( true == syncBetSp ) then 
            local totalBet = areaTotalBetted[k]
            if( areaBetted[k] and 0 < areaBetted[k] ) then totalBet = totalBet - areaBetted[k] end
            local reduceScore = self:score2BetSpCount(totalBet)
            for _, subScore in pairs( reduceScore or {} ) do 
                local sp = self:playBetSp2Area( nil, k, subScore, nil, nil, false )
                if( not self.othersBetSp[k] ) then self.othersBetSp[k] = {} end
                if( sp ) then table.insert( self.othersBetSp[k], sp ) end
            end
        end
    end
    --
    if self._node_self_gold._last_num ~= self.model:getAllUserBetNumber() then
        self._node_self_gold._last_num = self.model:getAllUserBetNumber()
        local width = 0
        if not self._optimal then
            --抽取出缓存对象
            SlwhJettonCache:sampleCacheObject(self._node_self_gold)
            local dimention = {}
            --创建Sprite Number
            SlwhJettonCache:createSpriteNumberWithDot(self._node_self_gold._last_num,"slwh_slef_gold_%s",dimention,{x = 1,y = 0.5},self._node_self_gold)
            --对齐
            width = dimention.width
        else
            self._node_self_gold:setString(TreeFunc.formatNumberDot(self._node_self_gold._last_num))
            width = self._node_self_gold:getContentSize().width
        end
        local totalWidth = self.totalBet.icon:getContentSize().width + width + 55 
        self.totalBet.bg:setContentSize(cc.size(totalWidth, self.totalBet.bg:getContentSize().height))
        self.totalBet.icon:setPositionX(342.69 - width - 10)
    end
end

function SlwhJettonNewCcsView:hideBet(areaIdx)
    for area, areaBets in pairs(self.selfBetSp) do  
        if( area == areaIdx ) then 
            if( SLWH_EACH_AREA_BET_MAX_COUNT >= #areaBets ) then 
                for _, v in pairs(areaBets) do
                    v:setVisible(true)
                end
            else
                for k = #areaBets, #areaBets - SLWH_EACH_AREA_BET_MAX_COUNT, -1 do 
                    if areaBets[k] then 
                        areaBets[k]:setVisible(true)
                    end
                end
                for k = #areaBets - SLWH_EACH_AREA_BET_MAX_COUNT - 1, 1, -1 do 
                    if areaBets[k] then
                        areaBets[k]:setVisible(false)
                    end
                end
            end
        end
    end

    for area, areaBets in pairs(self.othersBetSp) do  
        if( area == areaIdx ) then 
            if( SLWH_EACH_AREA_BET_MAX_COUNT >= #areaBets ) then 
                for _, v in pairs(areaBets) do
                    v:setVisible(true)
                end
            else
                for k = #areaBets, #areaBets - SLWH_EACH_AREA_BET_MAX_COUNT, -1 do 
                    if areaBets[k] then
                        areaBets[k]:setVisible(true)
                    end
                end
                for k = #areaBets - SLWH_EACH_AREA_BET_MAX_COUNT - 1, 1, -1 do 
                    if areaBets[k] then
                        areaBets[k]:setVisible(false)
                    end
                end
            end
        end
    end
end

function SlwhJettonNewCcsView:updatePlayerHead()
    local activeUsers = self.userDatas 
    for k = 1, 4, 1 do 
        if( nil ~= activeUsers[k] and next(activeUsers[k]) ) then 
            self.playersInfo[k].head:setVisible(true)
            local frame = "gameres/module/slwh/jettonNew/slwh_jetton_head_bg5.png"
            self.playersInfo[k].head:changeHeadBG(frame)
            self.playersInfo[k].head:setUserData(activeUsers[k])
            if not B_HEADCLIPPING then 
                self.playersInfo[k].head:checkMask2(self.playersInfo[k].head.mask)
            else
                self.playersInfo[k].head.mask.mask:setVisible(false)
            end
            if( self.playersInfo[k].gold ) then 
                self.playersInfo[k].gold:setVisible(true)
                self.playersInfo[k].gold:setHtmlText( HtmlUtil.createArtNumWithHansUnits( activeUsers[k].lScore, "#slwh_jetton_player_gold_%s.png" ), true )
            end
            self.playersInfo[k].name:setVisible(true)
            self.playersInfo[k].name:setString( StringUtil.truncate(activeUsers[k].szNickName, 6, nil, 2) ) 
            self.playersInfo[k].freeTip:setVisible(false)
            self.playersInfo[k].headCircle:setVisible(true)
        else
            if( self.playersInfo[k].gold ) then self.playersInfo[k].gold:setVisible(false) end
            self.playersInfo[k].head:setVisible(false)
            self.playersInfo[k].name:setVisible(false)
            self.playersInfo[k].freeTip:setVisible(true) 
            self.playersInfo[k].headCircle:setVisible(false) 
        end
    end
end

function SlwhJettonNewCcsView:updateBetBtnPosition(selectedIdx, isChangePosition)
    self.currSelectedBtnBetIdx = selectedIdx
    self._btnAnimation:removeFromParent()
    self._btnParticle:removeFromParent()
    self._btnParticle:resetSystem()
    if( -1 == selectedIdx ) then
        for k, v in pairs(self.btnBets) do 
            v:setPositionY(self.btnBetsPositionY[k])
        end
    else
        for k, v in ipairs(self.btnBets) do 
            if( k ~= selectedIdx ) then 
                if v:getPositionY() ~= self.btnBetsPositionY[k] then 
                    v:stopAllActions()
                    v:runAction(cc.MoveTo:create(0.1,cc.p( v:getPositionX(),self.btnBetsPositionY[k])))
                end
            else
                if v:getPositionY() == self.btnBetsPositionY[k] then 
                    v:stopAllActions()
                    v:runAction(cc.MoveTo:create(0.1,cc.p(v:getPositionX(),self.btnBetsPositionY[k] + 10)))
                end
                local location = self._effectLocationArray[k]
                self._btnAnimation:setPosition(location.x,location.y + 70)
                self._btnParticle:setPosition(location.x,location.y)

                local parent_object = self.view.bottomNode
                parent_object:addChild(self._btnAnimation,0x778800)
                parent_object:addChild(self._btnParticle,0x778900)
            end
        end
    end
end

function SlwhJettonNewCcsView:updateBetBtnEnable()
    for k, v in pairs( self.btnBets or {} ) do 
        if( v ) then
            local splitString = StringUtil.splitNumWithString( Tree.BetScoreBaseConfig[k], false, true )
            if( self.gameStartGold >= Tree.BetScoreBaseConfig[k] ) then 
                -- v:setTouchEnabled( true )
                -- v:setBright( true )
                v:setCanTouch(true)
                --v.betBtnScore_tf:setHtmlText( HtmlUtil.createNum( splitString,
                 --                               "#slwh_jetton_bet_big_" .. tostring(k) .. "_%s.png" ) )
            else
                -- v:setTouchEnabled( false )
                -- v:setBright( false )
                v:setCanTouch(false)
                --v.betBtnScore_tf:setHtmlText( HtmlUtil.createNum( splitString,
                 --                               "#slwh_jetton_bet_big_un_" .. tostring(k) .. "_%s.png" ) )
            end
        end
    end
end

function SlwhJettonNewCcsView:updateBetBtnStatusAfterJetton()
    --- 若需要下注后限制最小值，需要服务器配置
    if( -1 ~= self.currSelectedBtnBetIdx ) then 
        for k = 5, 1, -1 do  
            if( self.gameStartGold >= Tree.BetScoreBaseConfig[k] ) then 
                if( k < self.currSelectedBtnBetIdx ) then
                    self:updateBetBtnPosition(k)
                end
                break
            end
            if( 1 == k ) then 
                self:updateBetBtnPosition(-1)
            end
        end
        self:updateBetBtnEnable()
    else
        self:updateBetBtnPosition(-1)
    end
end

function SlwhJettonNewCcsView:playBetSp2Area( headIdx, areaIdx, betScore, startPos, moveDuration, isPlayAnimation )
    if( 15 < areaIdx or 1 > areaIdx ) then return end

    local betSp = self:createBetSp(betScore)
    if( nil == betSp ) then return end
    if( false ) then 
        if( headIdx ) then 
            local count = #self.userDatas
            if( count > 4 ) then count = 4 end
            local t = self.randomFuckerHead[count]
            if( t ) then 
                local randomIdx = math.random( 1, #t )
                if( not self.userDatas[randomIdx] ) then return betSp end
                headIdx = self.randomFuckerHead[count][randomIdx] 
                startPos = self.betSpStartPoint.playerHead[headIdx]
            else
                headIdx = nil
            end
        end
    else
        if( headIdx ) then 
            headIdx = 5
            startPos = self._onlinePosition
        end
    end

    local whitePoint = nil
    if( SLWH_BET_SHOW_WHITE_POINT ) then 
        if( false ~= isPlayAnimation ) then  
            betSp:setPosition(startPos.x,startPos.y)
            if #self._whiteSprite > 0 then
                whitePoint = table.remove(self._whiteSprite)
            else
                whitePoint = cc.Sprite:createWithSpriteFrameName("slwh_jetton_white_point.png")
                whitePoint:retain()
            end
            self.view.bottomNode.dynamicBetNode:addChild(whitePoint, 999)
            whitePoint:setVisible(true)
            whitePoint:setPosition(startPos.x,startPos.y)
            --table.insert(self.whitePoints,whitePoint)
            whitePoint:setTag(self._white_object_idx)
            self.whitePoints[self._white_object_idx] = whitePoint
            self._white_object_idx = self._white_object_idx + 1
        end
    else
        if( false ~= isPlayAnimation ) then 
            betSp:setPosition(startPos.x,startPos.y)
        end
    end

    local endPos = self:randomAreaPos( areaIdx )   
    betSp.slwhEndPosition = endPos
    if( false == isPlayAnimation ) then 
        betSp:setPosition(endPos.x,endPos.y)
        betSp:setVisible(true)
        self:hideBet(areaIdx)
        if( whitePoint ) then whitePoint:setVisible(false) end
    else
        if( SLWH_BET_SHOW_WHITE_POINT and whitePoint ) then 
            whitePoint:runAction(cc.Sequence:create(cc.EaseSineOut:create(cc.MoveTo:create(moveDuration,endPos)),cc.CallFunc:create(function()
                betSp:setPosition(endPos.x,endPos.y)
                whitePoint:setVisible(false)
                betSp:setVisible(true)

                self.whitePoints[whitePoint:getTag()] = nil
                table.insert(self._whiteSprite,whitePoint)
                whitePoint:removeFromParent()
                --[[self:hideBet( areaIdx )]] -- 尝试不开启隐藏下面筹码
                end)))
        else
            assert(not self._optimal_jetton)
            betSp:runAction( cc.Sequence:create( cc.EaseSineOut:create( cc.MoveTo:create( moveDuration, endPos ) ), cc.CallFunc:create(function() self:hideBet( areaIdx ) end) ) )
        end
        
        if( nil ~= headIdx ) then 
            if( 5 == headIdx ) then 
                self.onlineIcon:stopAllActions()
                self.onlineIcon:setPosition( self.onlineIconPos )
                self.onlineIcon:runAction( cc.Sequence:create( cc.MoveTo:create( 0.05, cc.p( self.onlineIconPos.x, self.onlineIconPos.y - 10 )), cc.CallFunc:create(
                    function()
                        self.onlineIcon:setPosition( self.onlineIconPos )
                    end
                )))
            else
                local headNode = self.playersInfo[headIdx].head
                local headCircleNode = self.playersInfo[headIdx].headCircle
                local headNodePos = self.playersInfo[headIdx].headPosition
                local headCirclePos = self.playersInfo[headIdx].headCirclePosition
                headNode:stopAllActions()
                headCircleNode:stopAllActions()
                headNode:setPosition( headNodePos )
                headCircleNode:setPosition( headCirclePos )
                headNode:runAction( cc.Sequence:create( cc.MoveTo:create( 0.05, cc.p( headNodePos.x, headNodePos.y - 10 )), cc.CallFunc:create(
                    function()
                        headNode:setPosition( headNodePos )
                    end
                )))
                headCircleNode:runAction( cc.Sequence:create( cc.MoveTo:create( 0.05, cc.p( headCirclePos.x, headCirclePos.y - 10 )), cc.CallFunc:create(
                    function()
                        headCircleNode:setPosition( headCirclePos )
                    end
                )))
            end
        else
        end
    end
    if( false ~= isPlayAnimation ) then 
        if( betScore >= 1000000 ) then 
            self:playBettingSound( Tree.Sound.BetScoreEffect2 )
        else
            self:playBettingSound( Tree.Sound.BetScoreEffect1 )
        end
    end
    return betSp
end

function SlwhJettonNewCcsView:createBetSp(betScore)
    local betSp = nil
    if not self._optimal_jetton then
        local object_key = string.format("slwh_chouma_%d",betScore)
        betSp = SlwhJettonCache:getCacheObject(object_key)
        betSp:setVisible(false)
        self.view.bottomNode.dynamicBetNode:addChild(betSp)
        betSp:setLocalZOrder(self.betSpLocalZOrder)
        self.betSpLocalZOrder = self.betSpLocalZOrder + 1
    else
        --print("-----betScore----->",betScore)
        local cache_map = self._dynamic_map[betScore]
        if #cache_map > 0 then
            betSp = table.remove(cache_map)
            self._dynamic_node:removeInstance(betSp)
        else
            betSp = cc.SpriteInstance:create(string.format("slwh_jetton_chouma_%s.png",betScore))
            betSp.__score_num = betScore
        end
        betSp:setZOrder(self.betSpLocalZOrder)
        self._dynamic_node:addInstance(betSp)
        betSp:setVisible(false)
    end
	return betSp
end

function SlwhJettonNewCcsView:randomAreaPos( areaIdx )
    return cc.p( self.betSpStartPoint.betArea[areaIdx].x +  math.random( -30, 30 ), self.betSpStartPoint.betArea[areaIdx].y +  math.random( -5, 5 ) )
end

function SlwhJettonNewCcsView:score2BetSpCount( score )
    if( nil == score ) then 
        return
    end

    score = ( 0 > score ) and ( 0 ) or ( score )

    local betScoreConfig = Tree.BetScoreBaseConfig
    local betSpNum = {}
    local curScore = score 

    for i = #betScoreConfig, 1, -1 do 
        local interg = math.modf( curScore / betScoreConfig[i] )
        if( 0 < interg ) then 
            for k = 1, interg, 1 do 
                table.insert( betSpNum, betScoreConfig[i] )
            end
        end
        curScore = curScore % betScoreConfig[i]
        if( 1 == i and 0 < curScore ) then 
            table.insert( betSpNum, curScore )
        end
    end

    return betSpNum
end

function SlwhJettonNewCcsView:playBettingSound( effectFile )
    if( nil == effectFile ) then return end
	if( not self.bPlayBettingSound ) then 
		self.controller:playGameEffect( effectFile )
        -- self.bPlayBettingSound = false
        if( nil ~= self.gameEffectTick ) then 
            self.gameEffectTick:destroy()
            self.gameEffectTick = nil
        end
        self.gameEffectTick = tickMgr:delayedCall( function()
			self.bPlayBettingSound = false
		 end, 0.2 )
	end
end

------------------------------------------------------------------------------------------------------------

function SlwhJettonNewCcsView:destroy()
    if( self.betTimer ) then 
        self.betTimer:stopAllActions()
        self.betTimer:removeFromParent()
        self.betTimer = nil
    end
    if( self.betRemandTimer ) then 
        self.betRemandTimer:stopAllActions()
        self.betRemandTimer:removeFromParent()
        self.betRemandTimer = nil
    end

    if self._dynamic_map then
        for _, value in ipairs(self._dynamic_map) do
            for _, v in pairs(value) do 
                v:release()
            end
        end
    end

    if self._whiteSprite then
        for tag,sprite in pairs(self._whiteSprite)do
            sprite:release()
            self._whiteSprite[tag] = nil
        end
    end 

    for tag,sprite in pairs(self.whitePoints)do
        sprite:release()
        self._whiteSprite[tag] = nil
    end
    TreeEventDispatcher:clearOneObjEvent(self)
end
----下注面板缓存代码
function SlwhJettonNewCcsView:initCacheMap()
end