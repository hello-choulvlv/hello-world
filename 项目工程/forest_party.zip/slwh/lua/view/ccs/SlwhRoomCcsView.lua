--连森林舞会房间列表
--2018年12月21日
--@author:xiaoxiong
SlwhRoomCcsView = class("SlwhRoomCcsView")
function SlwhRoomCcsView:onCreationComplete()
    --调整滚动面板中组件的层级关系
    local layoutContent = self.layerRoomList.layerContent;
    local scrollView = self.layerRoomList.content_sv;
    local size = cc.size(display.width, scrollView:getContentSize().height)
    
    scrollView:setContentSize(size)
    scrollView:setInnerContainerSize(layoutContent:getContentSize());
    scrollView:setClippingEnabled(false);--不做裁剪，因为全屏scrollview，而且渐出效果时的回弹不希望裁剪
    scrollView:setIsCenterWhileNeed(true)
    scrollView:addContentChild(layoutContent);
   
    DisplayUtil.setAllCascadeOpacityEnabled(scrollView)

    --目前只是5个房间
    local room_count = 5
    self._roomBtnInitPoses = {}
    self._roomBtns = {}
    for idx =1, room_count do
        local button = layoutContent["btn" .. idx]
        if( nil ~= button ) then 
            table.insert(self._roomBtns,button)
            button._index  = idx
            button._kind = idx
            self._roomBtnInitPoses[idx] = DisplayUtil.ccpCopy(button:getPosition())
            if device.platform ~= "windows" then
                scrollView:addBtn2HandleTouchOperate(button)
            end
        end
    end
    self:initRoomSpine()
    --设置分数
    --记录下最初的偏移量,以便以后的跨度计算更容易
    self:alignComponent()
    self._originX,self._originY = layoutContent:getPosition()
    self._layerTopX,self._layerTopY = self.layerTop:getPosition()
    self._layerBottomX,self._layerBottomY = self.layerBottom:getPosition()

    self._lastOffset = 0
    --可移动的Spine动画,左右可以移动的最大幅度
    local max_width = CONFIG_CUR_WIDTH + 176 * 2
    self._maxOffsetX = 10--(max_width - display.width) * 0.5
    --记录玩家分数面板中,欢乐豆图标与增加欢乐豆按钮相对底板的左右偏移量
    self._leftIconOffset = self.layerBottom.layer_score.icon:getPositionX()
    self._rightButtonOffset = self.layerBottom.layer_score.btnAdd:getPositionX() - self.layerBottom.layer_score.bg:getContentSize().width
    self:onUserScoreChanged()
end
--align
function SlwhRoomCcsView:alignComponent()
	self.controller:adjustSlimWidth(self.layerTop.btnBack, UIConfig.ALIGN_LEFT,80)
	self.controller:adjustSlimWidth(self.layerTop.btnQuestion, UIConfig.ALIGN_LEFT, 80)
	self.controller:adjustSlimWidth(self.layerBottom.btnFastBegin,UIConfig.ALIGN_RIGHT,-80)
	self.controller:adjustSlimWidth(self.imageLogo,UIConfig.ALIGN_RIGHT,-80)
    --左下角的人物头像
    local com = {
        [1] = self.layerBottom.head,
        [2] = self.layerBottom.sprite_head_frame,
        [3] = self.layerBottom.text_name,
        [4] = self.layerBottom.imag_hero_panel,
        [5] = self.layerBottom.layer_score,
    }
    for idx = 1, #com do
        self.controller:adjustSlimWidth(com[idx],UIConfig.ALIGN_LEFT,80)
    end
end
--房间Spine动画
function SlwhRoomCcsView:initRoomSpine()
    local spine_count = 5
    for idx=1,spine_count do
        local button = self._roomBtns[idx]
        local spineEntry = Tree.Room[idx]
        local skeleton_1 = sp.SkeletonAnimation:create(spineEntry[1].json,spineEntry[1].atlas)
        skeleton_1:setAnimation(0,"animation",true)
        button.node_spine:addChild(skeleton_1)

        local skeleton_2 = sp.SkeletonAnimation:create(spineEntry[2].json,spineEntry[2].atlas)
        skeleton_2:setAnimation(0,"animation",true)
        button.node_spine:addChild(skeleton_2)

        local skeleton_3 = sp.SkeletonAnimation:create(spineEntry[3].json,spineEntry[3].atlas)
        skeleton_3:setAnimation(0,"animation",true)
        button.node_spine:addChild(skeleton_3)
    end
    --快速开始
    local skeleton = sp.SkeletonAnimation:create(Tree.root .. "animation/quickstart/slwh_quickstart.json",Tree.root .. "animation/quickstart/slwh_quickstart.atlas")
    --skeleton:setAnchorPoint(0.5,0.5)
    local size = self.layerBottom.btnFastBegin:getContentSize()
    skeleton:setPosition(size.width*0.5,size.height * 0.5)
    skeleton:setAnimation(0,"animation",true)
    self.layerBottom.btnFastBegin:addChild(skeleton)
    --房间背景
    local skeleton_1 = sp.SkeletonAnimation:create(Tree.root .. "animation/room/slwh_xcbg.json",Tree.root .. "animation/room/slwh_xcbg.atlas")
    skeleton_1:setAnimation(0,"animation",true)
    --skeleton_1:setPosition(CONFIG_CUR_WIDTH*0.5,CONFIG_CUR_HEIGHT * 0.5)
    self.node_animation:addChild(skeleton_1)
    self._skeleton1 = skeleton_1
    --两侧的粒子
    local particle_l1 = cc.ParticleSystemQuad:create(Tree.root .. "particle/slwh_xcbg1.plist")
    particle_l1:setPosition(-467,-300)
    self.node_animation:addChild(particle_l1)

    local particle_l2 = cc.ParticleSystemQuad:create(Tree.root .. "particle/slwh_xcbg2.plist")
    particle_l2:setPosition(-467,-300)
    self.node_animation:addChild(particle_l2)

    local particle_r1 = cc.ParticleSystemQuad:create(Tree.root .. "particle/slwh_xcbg3.plist")
    particle_r1:setPosition(467,-300)
    self.node_animation:addChild(particle_r1)

    local particle_r2 = cc.ParticleSystemQuad:create(Tree.root .. "particle/slwh_xcbg4.plist")
    particle_r2:setPosition(467,-300)
    self.node_animation:addChild(particle_r2)
end
--更新按钮的状态
function SlwhRoomCcsView:updateButtonState()
    local gameKind = self.model:getGameKind()
    local serverVos = gameMgr:getServerVosDicEx()
    local roomDic = serverVos[gameKind] or {}
    self._cellScore = {}
    local button_count = 5 
    local showingLen = 0
    local curShowingBtns = {}
    for index=1,button_count do
        local button = self._roomBtns[index]
        --依据给定的基数的不同,呈现出的结果不同
        local   roomEntry = roomDic[button._kind]
        if roomEntry then
            --- 显示房间按钮
            DisplayUtil.setVisible( button, true )
            showingLen = showingLen + 1
            curShowingBtns[showingLen] = button
            button:setEnabled(true)
            button:setPosition(self._roomBtnInitPoses[showingLen])
            self._cellScore[index] = roomEntry._dwCellScore
            local entry_cost = roomEntry._miniNeed
            --对于免费的房间,不需要做任何的变动
            --if entry_cost > 0 then
                if button.costImage  then 
                    button.costImage:setVisible(false)
                end
                --local text = HtmlUtil.createImg(Tree.root .. "room/entry/zhunru.png")
                if( nil ~= button.txtEntry_tf ) then 
                    local text = HtmlUtil.createArtNumWithHansUnits(entry_cost,Tree.root .. "room/entry/number_%s.png")
                    button.txtEntry_tf:setHtmlText(text)
                    button.txtEntry_tf:setSkewY(5)
                end
            --end
            --是否是空闲/拥挤/爆满
            --local free_state = cc.Sprite:create(Serial.Room.FreeState[1])
            --button.node_tag:addChild(free_state)
        else--房间没有开启
            --- 隐藏房间按钮
            DisplayUtil.setVisible( button, false )
            if button.txtEntry_tf then
                button.txtEntry_tf:setVisible(false)
            end
            --需要测试一下,按钮中的子组件并不一致
            if button.costImage then
                button.costImage:setVisible(false)
            end
            button:setCanTouch(false)
            --是否是空闲/拥挤/爆满
            --local free_state = cc.Sprite:create(Serial.Room.FreeState[1])
            --button.node_tag:addChild(free_state)
        end
    end

    --计算滚动区域
    local svContent = self.layerRoomList.layerContent
    local sv = self.layerRoomList.content_sv
    local maxWidth  = 0
    self._roomCount = showingLen
    if showingLen > 0 then
        local lastBtn = curShowingBtns[showingLen]
        local rightMargin = 50
        maxWidth = math.max( maxWidth, rightMargin + lastBtn:getPositionX() + lastBtn:getScaleX() * lastBtn:getContentSize().width * lastBtn:getAnchorPoint().x )
    end
    sv:setInnerContainerSize(cc.size( maxWidth + 100, svContent:getContentSize().height ))
    --如果房间的列表总长度大于等于可显示区域,左对齐,并且保留一定的空袭
    if maxWidth >= display.width then
        local interpolation = (display.width - CUR_SELECTED_WIDTH) * 0.5
        local offset_x = 80
        if math.abs(interpolation) < 10 then
            offset_x = 0;
        end
        if display.width <= CONFIG_CUR_WIDTH then
            offset_x = offset_x + 20
        end
        sv:setPositionX(-interpolation + offset_x)
    else
        --居中，兼容ix,对于分辨率为1334 * 750的不做调整,一直保持和上方的按钮对齐
        local offsetX2Center = math.max(40, (display.width - maxWidth) * 0.5);
        sv:setPositionX((CONFIG_DESIGN_WIDTH - display.width) * 0.5 + offsetX2Center)
    end
    --如果是ix,并且房间为5个
--    if display.width == 1624 and self._roomCount >= 5 then
--        sv:setPositionX(-(display.width - CONFIG_CUR_WIDTH) *0.5 + 80)
--    end
    self._roomsWidth = maxWidth
    self._curShowingBtns = curShowingBtns
end

function SlwhRoomCcsView:onHide()
    Hero.pNickNameChangedSignal:remove(self.onUserNameChanged,self)
    Hero.userScoreChangedSignal:remove(self.onUserScoreChanged,self)

    --self.layerRoomList.content_sv._viewTouchSignal:remove(self.onTouchOpation,self)
    --self:unscheduleUpdate()
end

function SlwhRoomCcsView:onShow()

    self.model:setIsShowingJetton(false, true)
     --用户名字
    Hero.pNickNameChangedSignal:add(self.onUserNameChanged,self)
    --用户分数
    Hero.userScoreChangedSignal:add(self.onUserScoreChanged,self)
    --更新按钮的状态
    self.layerRoomList.content_sv:jumpTo(0)
    self:updateButtonState()
    --更新玩家分数/名字
    self:onUserNameChanged()
    self:onUserScoreChanged()
    --如果房间全开
    self:playEntryAnimation()
end
--入场动画
function SlwhRoomCcsView:playEntryAnimation()
	self.layerRoomList:setCascadeOpacityEnabled(true)
	self.layerTop:setCascadeOpacityEnabled(true)
	self.layerBottom:setCascadeOpacityEnabled(true)

    if self._roomCount >= 5 then
        --记录下当前的坐标
        local x,y = self._originX,self._originY--self.layerRoomList.layerContent:getPosition()
        local origin_x,origin_y = self.layerRoomList.content_sv:getPosition()
        --计算需要行进的距离
        local offset_x =  display.width - self._roomsWidth - (display.width - CONFIG_DESIGN_WIDTH) * 0.5 - origin_x
        self.layerRoomList.layerContent:setPosition(offset_x,y)
        --run action
        local scroll = self.layerRoomList.layerContent;
	    scroll:setOpacity(0)
	    scroll:runAction(cc.Sequence:create(cc.DelayTime:create(0.2),cc.FadeTo:create(0.1, 255)))
	    scroll:runAction(cc.Sequence:create(cc.DelayTime:create(0.3),cc.EaseBackOut:create(cc.MoveTo:create(1, cc.p(x,y)))))
    else
	    local scroll = self.layerRoomList.layerContent;
	    local originalPos = cc.p(self._originX,self._originY)--cc.p(scroll:getPosition())
	    scroll:setOpacity(0)
	    scroll:setPosition(originalPos.x + 100, originalPos.y)
	    scroll:runAction(cc.FadeTo:create(0.3, 255))
	    scroll:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.4, originalPos)))
    end

	local topLayer = self.layerTop;
	local originalPos = cc.p(self._layerTopX,self._layerTopY)
	topLayer:setOpacity(0)
	topLayer:setPosition(originalPos.x, originalPos.y + 60)
	topLayer:runAction(cc.FadeTo:create(0.3, 255))
	topLayer:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.4, originalPos)))

	local bottomLayer = self.layerBottom;
	local originalPos = cc.p(self._layerBottomX,self._layerBottomY)
	bottomLayer:setOpacity(0)
	bottomLayer:setPosition(originalPos.x, originalPos.y - 60)
	bottomLayer:runAction(cc.FadeTo:create(0.3, 255))
	bottomLayer:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.4, originalPos)))
end
--用户的名字发生变化
function SlwhRoomCcsView:onUserNameChanged()
    local name = Hero:getPNickName()
    name = StringUtil.truncate(name, 9, nil, 2)
	self.layerBottom.text_name:setString(name);
    local name_size = self.layerBottom.text_name:getVirtualRendererSize()

    local s2_width = name_size.width + 62
    self.layerBottom.imag_hero_panel:setContentSize(cc.size(s2_width,50))
    local layer_score = self.layerBottom.layer_score
    self.layerBottom.layer_score:setPositionX(self.layerBottom.imag_hero_panel:getPositionX() + s2_width + 24)
end
--用户的分数发生变化
function SlwhRoomCcsView:onUserScoreChanged()
    local scoreNumber = parseInt(Hero:getUserScore())
    local layer_score = self.layerBottom.layer_score
    local node_score = layer_score.node_score
    node_score:removeAllChildren()
    local dimension = {}
    local sprite_score = TreeFunc.createSpriteNumberWithDot(scoreNumber,"#slwh_room_number_%s.png",dimension,{x=0.5,y=0.5},node_score)
    --检测是否需要自适应,需要大于等于10000000
    if scoreNumber >= 10000000 then
        local panel_width = dimension.width + 100
        local x = panel_width + self._rightButtonOffset
        layer_score.bg:setContentSize(cc.size(panel_width,50))
        layer_score.btnAdd:setPositionX(panel_width + self._rightButtonOffset)
        node_score:setPositionX((self._leftIconOffset + x) * 0.5)
    else
        layer_score.bg:setContentSize(cc.size(256,50))
        layer_score.btnAdd:setPositionX(233)
        node_score:setPositionX(125)
    end

    self.controller:setHeadBg(self.layerBottom.head, GAME_STATE.ROOM)
    --- 特殊圆头像
    if not  B_HEADCLIPPING then 
    	self.layerBottom.head:checkMask2(self.layerBottom.head.mask)
    else
    	self.layerBottom.head.mask.mask:setVisible(false)
	end
end

function SlwhRoomCcsView:onBtnClick(target, event)
    --print("--------onButtonEvent----")
    if target == self.layerTop.btnBack then--返回
        self.controller:exitGame()
    elseif target == self.layerTop.btnQuestion then--关于游戏的说明
        self.model:setIsShowingRule(true)
    elseif target == self.layerBottom.layer_score.btnAdd then --银行
        self.controller:try2OpenBank()
    elseif target == self.layerBottom.btnFastBegin then
        self.controller:quickStartGame()
    else --以下将是房间按钮
        self.controller:requestEnterRoom(target._kind)
		--self.controller:clearMessageCache()
        --self.model:setCellScore(self._cellScore[target._kind])
        --取消网络消息存储
        self.controller:onNetMessageCabcelCache()
    end
end

function SlwhRoomCcsView:onTouchOpation(touchPoint,event)
    if event == ccs.TOUCH_EVENT_BEGAN then
        self._touchOffsetX = touchPoint.x
        self._lastOffset = 0--立即停止当前的缓动
    elseif event == ccs.TOUCH_EVENT_MOVED then
        local interpolation_x = (touchPoint.x - self._touchOffsetX) * 0.5
        local x = self._skeleton3:getPositionX()

        if x + interpolation_x * 0.35 > self._maxOffsetX then
            interpolation_x = self._maxOffsetX - x
        elseif x + interpolation_x * 0.35 < - self._maxOffsetX then
            interpolation_x = -self._maxOffsetX - x
        end

        self._skeleton3:setPositionX(x + interpolation_x * 0.35)

        x = self._skeleton2:getPositionX()
        self._skeleton2:setPositionX(x + interpolation_x * 0.06)

        x = self._skeleton1:getPositionX()
        self._skeleton1:setPositionX(x + interpolation_x * 0.03)

        self._touchOffsetX = touchPoint.x
        self._lastOffsetT = interpolation_x
    elseif event == ccs.TOUCH_EVENT_ENDED then
        self._lastOffset = self._lastOffsetT or 0
    end
end

function SlwhRoomCcsView:destroy()
    print("--destroy serial_room_view--")
    local parentNode = self.layerRoomList
    parentNode.layerContent.btn1:destroy()
    parentNode.layerContent.btn2:destroy()
    parentNode.layerContent.btn3:destroy()
    parentNode.layerContent.btn4:destroy()
    parentNode.layerContent.btn5:destroy()

    --destroySomeObj()

    self.layerTop.btnBack:destroy()
    self.layerTop.btnQuestion:destroy()

    self.layerRoomList.content_sv:destroy()

    self.layerBottom.btnFastBegin:destroy()
end