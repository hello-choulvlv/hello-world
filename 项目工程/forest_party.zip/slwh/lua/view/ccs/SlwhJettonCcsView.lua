--场景中下注面板
--2018年11月26日
--author:xiaoxiong
SlwhJettonCcsView = class("SlwhJettonCcsView")

function SlwhJettonCcsView:onCreationComplete()
    ClassUtil.extends(self,ZoomPopUpChildView,true,self,self.bg, self.view)
    --注册事件监听
    self._layerView = self.view
    self._layerJetton = self.view.layer_jetton
    self.layerAnimal = self.view.layer_animal
    --押注按钮的基准线
    self._baseBetButtonIndex = 100
    self._upperBetButtonIndex = 106
    --面板组件的基准线
    self._baseAreaButtonIndex = 0
    self._upperAreaButtonIndex = 16
    --需要针对15个组件,以及下注按钮进行优化
    self._areaComponent = {}
    -- self._nowJettonMap = {}
    for idx =1, 15 do
        table.insert(self._areaComponent,{
            rewardTimes = -1,--奖励倍数
            playerBet = -1,--玩家的投注
            totalBet = -1,--总的投注
        })

        -- self._nowJettonMap[idx] = {}
    end
    self._buttonComponent = {}
    for idx = 1,5 do
        table.insert(self._buttonComponent,-1)
    end
    --当前选中的按钮
    self._currentSelectButton = -1
    self._layerJettonChild = {
        [1] = self._layerJetton.btnJetton_1,
        [2] = self._layerJetton.btnJetton_2,
        [3] = self._layerJetton.btnJetton_3,
        [4] = self._layerJetton.btnJetton_4,
        [5] = self._layerJetton.btnJetton_5,
    }
    for k, v in pairs( self._layerJettonChild or {} ) do 
        if( v ) then 
            if( not v.betBtnSpine ) then 
                v.betBtnSpine = sp.SkeletonAnimation:create(Tree.root .. "effect/slwh_xzgd.json", Tree.root .. "effect/slwh_xzgd.atlas")
                v.betBtnSpine:setAnimation(0,"animation", true)
                v.betBtnSpine:setPosition( 0, 16 )
                self._layerJetton["betBtnEffect_" .. k ]:addChild(v.betBtnSpine)
                v.betBtnSpine:setVisible(false)
            end
            if( not v.betBtnParticle ) then 
                v.betBtnParticle = cc.ParticleSystemQuad:create(Tree.root .. "particle/slwh_cmlightlizi.plist") 
                v.betBtnParticle:setPosition( 0, 16 )
                self._layerJetton["betBtnEffect_" .. k ]:addChild(v.betBtnParticle)
                v.betBtnParticle:setVisible(false)
            end
        end
    end

    self._layerJettonChildPositionY = 
    {
        [1] = self._layerJetton.btnJetton_1:getPositionY(),
        [2] = self._layerJetton.btnJetton_2:getPositionY(),
        [3] = self._layerJetton.btnJetton_3:getPositionY(),
        [4] = self._layerJetton.btnJetton_4:getPositionY(),
        [5] = self._layerJetton.btnJetton_5:getPositionY(),
    }
    --
    TreeEventDispatcher:addEventListener(Tree.Event.gameOver,self.notifyGameOver,self)
    TreeEventDispatcher:addEventListener(Tree.Event.gameBet,self.notifyJetton,self)
    TreeEventDispatcher:addEventListener(Tree.Event.gameBetContinue,self.notifyJettonContinue,self)
    TreeEventDispatcher:addEventListener(Tree.Event.closeJettonView,self.notifyCloseView,self)
    TreeEventDispatcher:addEventListener(Tree.Event.cancelAllBets,self.onCancelAllBets,self)
    TreeEventDispatcher:addEventListener(Tree.Event.closeGame,self.exitGame,self)
    --TreeEventDispatcher:addEventListener(Tree.Event.gameStart)
    --self:replaceJettonPanel()
end
--更新面板组件的texture,使用大图
function SlwhJettonCcsView:replaceJettonPanel()
    --按钮
    for index = 1, 5 do
        local frame_name = string.format("slwh_jetton_%d_n.png",index)
        self._layerView.layer_jetton["btnJetton_" .. index]:loadTexture(frame_name,1)
    end
    --续押,撤销按钮
    self._layerView.btnCancel:loadTexture("button_cancel.png",1)
    self._layerView.btnContinue:loadTexture("button_continue.png",1)
    self._layerView.btnClose:loadTexture("button_close.png",1)
    --15个按钮
    local layer_animal = self._layerView.layer_animal
    for index = 1,15 do
        local frame_name = string.format("slwh_bet_frame_%d.png",index)
        layer_animal["btnBet_" .. index]:loadTexture(frame_name,1)
    end
end

function SlwhJettonCcsView:onCancelAllBets()
    self:updateView()
end

function SlwhJettonCcsView:notifyButtonStatus(buttonObj,enabled)
    local index_t = buttonObj:getTag() - self._baseBetButtonIndex
    local button_key = string.format("slwh_jetton_%d_%s.png",index_t,state_f)
end
--更新押注按钮
function SlwhJettonCcsView:updateJettonButton()
    local user_score = parseInt(Hero:getUserScore())
    --print("user_score->",user_score)
    local cell_score_array = self.model:getCellScoreArray()

    for idx =1, 5 do
        local cell_score = cell_score_array[idx]
        local buttonObj = self._layerJettonChild[idx]
        
        local state_f = "n"
        if user_score < cell_score then
            state_f = "d"
        end
        local button_key = string.format("slwh_jetton_%d_%s.png",idx,state_f)
        buttonObj:loadTexture(button_key,1)
    end
    --检测是否当前的按钮受到了影响
    if self._currentSelectButton > 0 and user_score < cell_score_array[self._currentSelectButton] then
        --向前遍历,直到找到一个合适的或者直接结束
        local select_index = self._currentSelectButton
        for idx = self._currentSelectButton -1 ,1 -1 do
            if user_score > cell_score_array[idx] then
                self._currentSelectButton = idx
                break
            end
        end
        if select_index == self._currentSelectButton then
            self._currentSelectButton = -1
        end
    end
    if self._currentSelectButton > 0 then
        local button_key = string.format("slwh_jetton_%d_s.png",self._currentSelectButton)
        local buttonObj = self._layerJettonChild[self._currentSelectButton]
        buttonObj:loadTexture(button_key,1)
    end
    --续押按钮
    local sumary = TreeFunc.checkSumary(self._jettonMap)
    if sumary > 0 and sumary <= parseInt(Hero:getUserScore()) and true == self.model:getCanJettonContinue() then
        self._layerView.btnContinue:setEnabled(true)
        self._layerView.btnContinue:loadTexture("button_continue.png",1)
    else
        self._layerView.btnContinue:setEnabled(false)
        self._layerView.btnContinue:loadTexture("button_continue_d.png",1)
    end
end

function SlwhJettonCcsView:updateBetBtnPosition()
    if( self._currentSelectButton == -1 ) then 
        for k, v in pairs( self._layerJettonChild or {} ) do 
            if( v ) then 
                v:setPositionY( self._layerJettonChildPositionY[k] )
                v.betBtnParticle:setVisible(false)
                v.betBtnSpine:setVisible(false)
            end
        end
    else
        for k = 1, 5, 1 do 
            if( self._currentSelectButton == k ) then 
                if( self._layerJettonChild[k]:getPositionY() == self._layerJettonChildPositionY[k] ) then 
                    self._layerJettonChild[k]:stopAllActions()
                    self._layerJettonChild[k]:runAction( cc.MoveTo:create( 0.1, cc.p( self._layerJettonChild[k]:getPositionX(), self._layerJettonChildPositionY[k] + 10 ) ) )
                    self._layerJettonChild[k].betBtnParticle:resetSystem()
                    self._layerJettonChild[k].betBtnParticle:setVisible(true)
                    self._layerJettonChild[k].betBtnSpine:setVisible(true)
                end
            else
                if( self._layerJettonChild[k]:getPositionY() ~= self._layerJettonChildPositionY[k] ) then 
                    self._layerJettonChild[k]:stopAllActions()
                    self._layerJettonChild[k]:runAction( cc.MoveTo:create( 0.1, cc.p( self._layerJettonChild[k]:getPositionX(), self._layerJettonChildPositionY[k] ) ) )
                    self._layerJettonChild[k].betBtnParticle:setVisible(false)
                    self._layerJettonChild[k].betBtnSpine:setVisible(false)
                end
            end
        end
    end
end

function SlwhJettonCcsView:updateView()
    --更新五个按钮显示
    local cell_score_array = self.model:getCellScoreArray()
    for idx = 1, 5 do
        local button = self._layerJettonChild[idx]
        local cell_score = cell_score_array[idx]
        if self._buttonComponent[idx] ~= cell_score then
            self._buttonComponent[idx] = cell_score
            --
            TreeFunc.extractCacheWithNode(button.node_jetton)
            local money_key = string.format("jetton_%d_money_%%s",idx)
            TreeFunc.createSpriteNumberWithShort(cell_score,money_key,nil,{x=0.5,y = 0.5},button.node_jetton,true)
        end
    end
    --获取上一局的押注信息
    local jetton_map = self.controller:getOrCreateJettonMap(self.model:getRoomKind())
    local sumary = TreeFunc.checkSumary(jetton_map)
    if sumary > 0 and sumary <= parseInt(Hero:getUserScore()) and true == self.model:getCanJettonContinue() then
        self._layerView.btnContinue:setEnabled(true)
        self._layerView.btnContinue:loadTexture("button_continue.png",1)
    else
        self._layerView.btnContinue:setEnabled(false)
        self._layerView.btnContinue:loadTexture("button_continue_d.png",1)
    end
    self._jettonMap = jetton_map
    --更新15个面板显示
    --1->12
    local layer_animal = self._layerView.layer_animal
    local areaUserBetArray = self.model:getAreaUserBetArray()--玩家自己下注总和
    local areaTotalBetArray = self.model:getAreaTotalBetArray()--所有玩家的下注总和
    local areaBetMutilplyArray = self.model:getAreaBetMultiplyArray()--玩家区域倍率
    --所有的数字更新,节点中的所有子节点,必须先经过一次资源的回收,然后才能设置新的数字
    for idx = 1, 15 do
        local areaComponent = self._areaComponent[idx]
        local button = layer_animal["btnBet_" .. idx]
        local number_map = Tree.JettonNumbers[idx]
        --倍率
        if areaComponent.rewardTimes ~= areaBetMutilplyArray[idx] then
            areaComponent.rewardTimes = areaBetMutilplyArray[idx]

            --倍率,居中对齐
            TreeFunc.extractCacheWithNode(button.node_multiplier)
            local number_key = number_map[2]
            TreeFunc.createSpriteNumber(areaComponent.rewardTimes,number_key,nil,{x=0.5,y = 0.5},0,button.node_multiplier,true)
        end
        --玩家自己的下注总额
        if areaComponent.playerBet ~= areaUserBetArray[idx] then
            areaComponent.playerBet = areaUserBetArray[idx]

            --左对齐
            TreeFunc.extractCacheWithNode(button.node_self)
            local number_key = number_map[1]
            TreeFunc.createSpriteNumberWithShortW(areaComponent.playerBet,number_key,nil,nil,button.node_self,true)
        end
        --所有玩家的下注总额
        if areaComponent.totalBet ~= areaTotalBetArray[idx] then
            areaComponent.totalBet = areaTotalBetArray[idx]

            --左对齐
            TreeFunc.extractCacheWithNode(button.node_total)
            local number_key = number_map[3]
            TreeFunc.createSpriteNumberWithShortW(areaComponent.totalBet,number_key,nil,nil,button.node_total,true)
        end
    end
end

function SlwhJettonCcsView:hide(noTween, callback)
    ZoomPopUpChildView.hide(self,noTween, callback)
end

function SlwhJettonCcsView:show(noTween, callback)
    ZoomPopUpChildView.show(self,noTween, callback)
    self._currentSelectButton = -1
    self:updateBetBtnPosition()
    self:updateView()

    self._layerView.btnCancel:setEnabled(false)
    self._layerView.btnCancel:loadTexture("button_cancel_d.png",1)
end

function SlwhJettonCcsView:notifyCloseView()
    self.model:setIsShowingJetton(false)
end

function SlwhJettonCcsView:onBtnClick(target,event)
    local tag = target:getTag()
    if target == self._layerView.btnCancel then
        self._layerView.btnCancel:setEnabled(false)
        reqSlwhCancelJetton()
        self._layerView.btnCancel:loadTexture("button_cancel_d.png",1)
    elseif target == self._layerView.btnContinue then--续押
        self._layerView.btnContinue:setEnabled(false)
        self._layerView.btnContinue:loadTexture("button_continue_d.png",1)
        self:jettonContinue()
        self.model:setCanJettonContinue(false)
    elseif tag < self._upperAreaButtonIndex then--押注面板组建
        self:putJettonAnimal(target)
    elseif tag < self._upperBetButtonIndex then--押注按钮
        local select_index = tag - self._baseBetButtonIndex
        -- if select_index ~= self._currentSelectButton then
            self._currentSelectButton = select_index
            self:updateBetBtnPosition()
            self:updateJettonButton()
        -- end
    elseif target == self._layerView.btnClose then
        self:notifyCloseView()
    end
end
--选中某一个下注金额,然后投注
--target_button:代表下主面板中动物组件
function SlwhJettonCcsView:putJettonAnimal(target_button)
    local button_idx = target_button:getTag()
    assert(button_idx > self._baseAreaButtonIndex and button_idx < self._upperAreaButtonIndex)
    button_idx = button_idx - self._baseAreaButtonIndex
    --如果没有选中任何按钮,直接返回
    if self._currentSelectButton > 0 then
        --计算该按钮代表的下注金额
        local cell_score_array = self.model:getCellScoreArray()
        local cell_score = cell_score_array[self._currentSelectButton]
        self:requestJetton(button_idx,cell_score)
        -- self._nowJettonMap[button_idx] = self._nowJettonMap[button_idx] + cell_score
    end
end
--发送协议
function SlwhJettonCcsView:requestJetton(area_index,bet_money)
    local data = {
        nJettonArea = area_index - 1,
        lBet = bet_money,
    }
    self.model:setCurSelectdGold(bet_money)
    print("area->",area_index - 1,"bet->",bet_money)
    reqSlwhJetton(data)

end
--监听,下注后服务端返回(不一定成功)
function SlwhJettonCcsView:notifyJetton(bodyData)
    --如果返回成功,则相关的区域上更新数值
    local hero_userid = Hero:getWChairID()
    if bodyData.cbRet == Tree.JettonRetType.RetType_Success then
        local button_idx = bodyData.nArea + 1
        local area_component = self._areaComponent[button_idx]
        local button = self._layerView.layer_animal["btnBet_" .. button_idx]
        local number_map = Tree.JettonNumbers[button_idx]
        --玩家自己的下注总额
        if hero_userid == bodyData.wChairID then
            if area_component.playerBet ~= bodyData.lJetton then
                area_component.playerBet = bodyData.lJetton

                TreeFunc.extractCacheWithNode(button.node_self)
                local number_key = number_map[1]
                TreeFunc.createSpriteNumber(area_component.playerBet,number_key,nil,nil,0,button.node_self,true)
            end
            --扣掉自己下注的金额
            local user_score = parseInt(Hero:getUserScore())
            Hero:setUserScore(user_score - bodyData.lScore)
            self.model:setUserTotalJetton(self.model:getUserTotalJetton() + bodyData.lScore)

            --更新一下所有按钮的状态
            self:updateJettonButton()

            self._layerView.btnCancel:setEnabled(true)
            self._layerView.btnCancel:loadTexture("button_cancel.png",1)
        end
        --所有玩家的下注总额
        if area_component.totalBet ~= bodyData.lTotalJetton then
            area_component.totalBet = bodyData.lTotalJetton

            TreeFunc.extractCacheWithNode(button.node_total)
            local number_key = number_map[3]
            TreeFunc.createSpriteNumberWithShortW(area_component.totalBet,number_key,nil,nil,button.node_total,true)
        end
    elseif bodyData.cbRet == Tree.JettonRetType.RetType_ReachAreaLimit then

        tweenMsgMgr:showRedMsg("下注失败,已达区域投注上限")
    elseif bodyData.cbRet == Tree.JettonRetType.RetType_ReachPersonalLimit then

        tweenMsgMgr:showRedMsg("下注失败,已达个人区域投注上限")
    elseif bodyData.cbRet == Tree.JettonRetType.RetType_ZhuangXianOnlyOne then

        tweenMsgMgr:showRedMsg("您不能同时下注庄、闲")
    end
end
function SlwhJettonCcsView:notifyJettonContinue(bodyData)
    dump(bodyData)
    local hero_userid = Hero:getWChairID()
    if bodyData.cbRet == Tree.JettonRetType.RetType_Success then
        for fuckIndex = 1, 15, 1 do 
            local button_idx = fuckIndex
            local area_component = self._areaComponent[button_idx]
            local button = self._layerView.layer_animal["btnBet_" .. button_idx]
            local number_map = Tree.JettonNumbers[button_idx]
            --玩家自己的下注总额
            if hero_userid == bodyData.wChairID then
                if area_component.playerBet ~= bodyData.lBet[fuckIndex] then
                    area_component.playerBet = bodyData.lBet[fuckIndex]

                    TreeFunc.extractCacheWithNode(button.node_self)
                    local number_key = number_map[1]
                    TreeFunc.createSpriteNumber(area_component.playerBet,number_key,nil,nil,0,button.node_self,true)
                end
                --扣掉自己下注的金额
                local user_score = parseInt(Hero:getUserScore())
                Hero:setUserScore(user_score - bodyData.lBet[fuckIndex])
                self.model:setUserTotalJetton(self.model:getUserTotalJetton() + bodyData.lBet[fuckIndex])

                --更新一下所有按钮的状态
                self:updateJettonButton()

                self._layerView.btnCancel:setEnabled(true)
                self._layerView.btnCancel:loadTexture("button_cancel.png",1)
            end
            --所有玩家的下注总额
            if area_component.totalBet ~= bodyData.lTotalJetton[fuckIndex] then
                area_component.totalBet = bodyData.lTotalJetton[fuckIndex]

                TreeFunc.extractCacheWithNode(button.node_total)
                local number_key = number_map[3]
                TreeFunc.createSpriteNumberWithShortW(area_component.totalBet,number_key,nil,nil,button.node_total,true)
            end
        end
        self.model:setCurAreaUserBetOrder(bodyData.lBet)
    elseif bodyData.cbRet == Tree.JettonRetType.RetType_ReachAreaLimit then

        tweenMsgMgr:showRedMsg("下注失败,已达区域投注上限")
    elseif bodyData.cbRet == Tree.JettonRetType.RetType_ReachPersonalLimit then

        tweenMsgMgr:showRedMsg("下注失败,已达个人区域投注上限")
    elseif bodyData.cbRet == Tree.JettonRetType.RetType_ZhuangXianOnlyOne then

        tweenMsgMgr:showRedMsg("您不能同时下注庄、闲")
    end
end

--续押
function SlwhJettonCcsView:jettonContinue()
    local jettonContinueMap = self.model:getPreAreaUserBetOrder()
    for k = 1, 15, 1 do 
        if( nil == jettonContinueMap[k] ) then 
            jettonContinueMap[k] = 0
        end
    end
    reqSlwhJettonContinue(jettonContinueMap)
end
--监听事件,重置下注按钮
function SlwhJettonCcsView:notifyGameOver(bodyData)
    self.controller:savePreJettonMap()
end

function SlwhJettonCcsView:exitGame()
    for idx =1, 15 do
        self._areaComponent[idx].rewardTimes = -1
        self._areaComponent[idx].playerBet = -1
        self._areaComponent[idx].totalBet = -1
    end
    
    for idx = 1,5 do
        self._buttonComponent[idx] = -1
    end
end

function SlwhJettonCcsView:destroy()
    -- for k, v in pairs( self._layerJettonChild or {} ) do 
    --     if( v ) then 
    --         if( v.betBtnSpine ) then 
    --             TreeCacheManager:recycleCocos2dxObject(v.betBtnSpine)
    --         end
    --         if( v.betBtnParticle ) then 
    --             TreeCacheManager:recycleCocos2dxObject(v.betBtnParticle)
    --         end
    --     end
    -- end
    TreeEventDispatcher:clearOneObjEvent(self)
end