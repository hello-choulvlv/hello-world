--森林舞会
--菜单管理实现
--2019年2月25日
SlwhMenuCcsView = class("SlwhMenuCcsView")

function SlwhMenuCcsView:onCreationComplete()
	ClassUtil.extends(self, BaseMenuCcsView)
	BaseMenuCcsView.onCreationComplete(self)
end

function SlwhMenuCcsView:onBtnClick(target, event)
	self.model:setIsShowingMenu(false)--隐藏menu菜单
	if target == self.btnBank then
        --开奖阶段不能打开银行
        if self.model:getUserGameStatus() ~= Tree.Status.Over then
		    self.controller:try2OpenBank()
        else
            tweenMsgMgr:showRedMsg("您不能在开奖阶段进入银行")
        end
	elseif target == self.btnClose then
		self.model:setIsShowingMenu(false)
	elseif target == self.btnRule then
		self.model:setIsShowingRule(true)
	elseif target == self.btnSetting then
		self.model:setIsShowingSetting(true)
	elseif target == self.btnBack then
		self.controller:try2ExitBattle()
	elseif target == self.btnChange then
		self.controller:onBtnChangedClick()
	end
end