SlwhLoadingCcsView = class("SlwhLoadingCcsView")

function SlwhLoadingCcsView:onCreationComplete()
    ClassUtil.extends(self, BaseGameLoadingCcsView)
    BaseGameLoadingCcsView.onCreationComplete(self)
end

function SlwhLoadingCcsView:createSpineLogo()
	if not self._spineLogo then
		local spineKey = self.model.spineLogoKeyInLoading;
		if StringUtil.isStringValid(spineKey) then
			self._spineLogo = self.controller:createSpine(spineKey)
			self._spineLogo:retain()
		end
	end
    --Spine Animation 2
    if not self._spineLogo_2 then
        local spineKey = self.model.spineLogoKeyInLoading2
        if StringUtil.isStringValid(spineKey) then
            --local json, atlas = self:getSpineResByName(name)
            self._spineLogo2 = self.controller:createSpine(spineKey)
            self._spineLogo2:retain()
        end
    end
end

function SlwhLoadingCcsView:onShow()
	if self._bBattle == true then return end
	self:setLoadingViewShowing(true)
	self:createSpineLogo()
	self:createSpinePoint()

	if self._spineLogo then
		DisplayUtil.setAddOrRemoveChild(self._spineLogo, self._loadingView.layerSpine, true)
		self._spineLogo:setAnimation(0, "start", false);
		self._spineLogo:addAnimation(0, "idle", true);
	end

    if self._spineLogo2 then
		DisplayUtil.setAddOrRemoveChild(self._spineLogo2, self._loadingView.layerSpine, true)
		self._spineLogo2:setAnimation(0, "start", false);
		self._spineLogo2:addAnimation(0, "idle", true);
    end

	if self._spinePoint then
		DisplayUtil.setAddOrRemoveChild(self._spinePoint, self._loadingView.point, true)
	end

	self._pointIndex = 0
end

function SlwhLoadingCcsView:onHide()
	local function onHideComplete()
		applyFunction(self._try2Put2PoolFuc);
		self._try2Put2PoolFuc = nil;
		if self._spineLogo then
			self._spineLogo:clearTracks()
			spPoolMgr:put(self._spineLogo)
			self._spineLogo:removeFromParent()
			self._spineLogo:release()
			self._spineLogo = nil;
		end

        applyFunction(self._try2Put2PoolFuc);
		self._try2Put2PoolFuc = nil;
		if self._spineLogo2 then
			self._spineLogo2:clearTracks()
			spPoolMgr:put(self._spineLogo)
			self._spineLogo2:removeFromParent()
			self._spineLogo2:release()
			self._spineLogo2 = nil;
		end
	end
	self:setLoadingViewShowing(false, onHideComplete)
end

function SlwhLoadingCcsView:destroy()
	if self._spineLogo2 then
		self._spineLogo2:clearTracks()
		spPoolMgr:put(self._spineLogo2)
		self._spineLogo2 = nil;
	end
    BaseGameLoadingCcsView.destroy(self)
end
