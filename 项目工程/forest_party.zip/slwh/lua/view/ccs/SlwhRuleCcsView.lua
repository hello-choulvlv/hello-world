SlwhRuleCcsView = class("SlwhRuleCcsView")

function SlwhRuleCcsView:onCreationComplete()
    ClassUtil.extends( self, BaseRulePopupCcsView )
    BaseRulePopupCcsView.onCreationComplete(self)
    self:initRule()
end

function SlwhRuleCcsView:initRule()
    if( self.view.slwh_rule_shadow ) then 
        self.view.slwh_rule_shadow:setLocalZOrder(999)
    end
end