--游戏左侧图标列表
--2018年11月27日
--author:xiaoxiong
SlwhMenuItemCcsView = class("SlwhMenuItemCcsView")

function SlwhMenuItemCcsView:onCreationComplete()
    ClassUtil.extends( self, CcsListViewItem )
    --记录当前的哈希值
    self._hashValue = -1
    --Optimal
    self._rewardType = -1
    self._zhxType = -1
    self._animalIndex = -1
    --load sprite frame
end

function SlwhMenuItemCcsView:updateView()
    local data = self._data
    if not data then return end
    --my need spine
    local skeleton = self:getChildByName("spine_menuitem_show")
    if skeleton then
        TreeCacheManager:recycleCocos2dxObject(skeleton)
    end
    --
    if data._index == 1 then
        local skeleton = TreeCacheManager:getCacheObject("spine_menuitem_show")
        skeleton:setName("spine_menuitem_show")
        local x,y = self.bg:getPosition()
        skeleton:setPosition(x,y)
        skeleton:setAnimation(0,"animation",true)
        self:addChild(skeleton)
    end
    --Optimal
    local hash_value = data.cbType * 1000 + data.cbZHX * 100 + data.cbAwardIndex * 10
    if self._hashValue == hash_value then
        return
    end
    self._hashValue = hash_value
    --出现的图标并不一致
    local item_type = data.cbType
    local texture_format = "slwh_animal_%d.png"
    if item_type == Tree.RewardType.RewardType_Normal then--普通奖励
        local texture_path = string.format(texture_format,data.cbAwardIndex)
        self.bg:setSpriteFrame(texture_path)
    else
        local texture_path = string.format(texture_format,item_type + Tree.CardType.CardType_Max - 1)
        self.bg:setSpriteFrame(texture_path)
    end
    --庄和闲
    local texture_path = string.format(texture_format,data.cbZHX)
    self.sprite_zxh:setSpriteFrame(texture_path)
end

function SlwhMenuItemCcsView:onClick()
    local skeleton = self:getChildByName("spine_menuitem_show")
    if skeleton then
        TreeCacheManager:recycleCocos2dxObject(skeleton)
    end
end

function SlwhMenuItemCcsView:destroy()
    
    CcsScrollViewItem.destroy(self)
end
