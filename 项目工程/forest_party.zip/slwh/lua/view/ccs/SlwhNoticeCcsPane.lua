--
-- Author: senji
-- Date: 2018年6月6日
--modify :xiaoxiong
--
SlwhNoticeCcsPane = class("SlwhNoticeCcsPane")

function SlwhNoticeCcsPane:onCreationComplete()

	self._msg = {}
	self._msgGap = 100;
	self._curShowingTfs = {}
	self.contentClipLayer:setClippingEnabled(true)
	self.contentClipLayer:setLocalZOrder(102)
	self._readyToAdd = false
	self._showCounter = 0

	local size = self:getContentSize()
	local x = size.width / 2
	local y = size.height / 2
	 
	local spine = sp.SkeletonAnimation:createWithJsonFile(Tree.root .. "notice/jxlw_firetioskuangeffecta.json",Tree.root .. "notice/jxlw_firetioskuangeffecta.atlas")
	spine:setPosition(cc.p(x, y))
	spine:setVisible(true)
	spine:setCascadeOpacityEnabled(true)
	spine:setAnimation(0, "end", false)
	self:addChild(spine, 103)

	self.fire = spine;

	local spine = sp.SkeletonAnimation:createWithJsonFile(Tree.root .. "notice/jxlw_firetioskuangeffectb.json",Tree.root .. "notice/jxlw_firetioskuangeffectb.atlas")
	spine:setPosition(cc.p(x, y))
	spine:setVisible(true)
	spine:setCascadeOpacityEnabled(true)
	spine:setAnimation(0, "end", false)
	self:addChild(spine, 101)

	self.bg = spine;

	local particle = cc.ParticleSystemQuad:create(Tree.root .. "notice/serial_firetipskuanglizi.plist")
	particle:setPosition(cc.p(x, y - 20))
	particle:setCascadeOpacityEnabled(true)
	particle:stopSystem()
	self:addChild(particle, 104)

	self.effect = particle;

	self:registerScriptHandler(handler(self, self.onEnterExit))
	self:setCascadeOpacityEnabled(true)
	self:setVisible(false)

end

function SlwhNoticeCcsPane:onEnterExit(state)

	if state == "enter" then
		self:reset()
    	self:scheduleUpdateWithPriorityLua(function(dt) self:update(dt) end, 1)
    elseif state == "exit" then
		self:unscheduleUpdate()
	end
	
end

function SlwhNoticeCcsPane:reset()

	self:setVisible(false)
	self:stopAllActions()
	self._msg = {}
	self._state = "hided"
	self._readyToAdd = false
	self._showCounter = 0
	self.contentClipLayer:removeAllChildren()
	self.bg:setAnimation(0, "end", false)
	self.fire:setAnimation(0, "end", false)

end

function SlwhNoticeCcsPane:addMessage(msg)
	self._msg[#self._msg + 1] = msg
end

function SlwhNoticeCcsPane:getMessageNumber()
    return #self._msg
end

function SlwhNoticeCcsPane:update(dt)

	if self._state == "hided" and #self._msg > 0 then
		self:start()
	end

	if self._state == "showing" then

		if #self._msg > 0 and self._readyToAdd then
			self:showText()
		end

		if #self._msg == 0 and self._showCounter == 0 then
			self:hide()
		end

	end

end

function SlwhNoticeCcsPane:start()

	if self._state == "hided" then

		self._state = "showing"

		self:setVisible(true)
		self:setOpacity(255)

		self.bg:setAnimation(0, "start", false)
		self.bg:addAnimation(0, "idle", true)

		self.fire:setAnimation(0, "start", false)
		self.fire:addAnimation(0, "idle", true)

		self.effect:resetSystem();
		self:runAction(cc.Sequence:create(cc.DelayTime:create(1.5), cc.CallFunc:create(function() self._readyToAdd = true end)))

	end

end

function SlwhNoticeCcsPane:hide()

	self._state = "hiding"

	self.bg:setAnimation(0, "end", false)
	self.fire:setAnimation(0, "end", false)

	self:runAction(cc.Sequence:create(cc.FadeTo:create(0.5, 0), cc.CallFunc:create(function()
		self._state = "hided"
		self._readyToAdd = false
		self:setVisible(false)
	end)))

	self.effect:stopSystem()

end

function SlwhNoticeCcsPane:check()

	if #self._msg > 0 then
		start()
	else
		stop()
	end

end

function SlwhNoticeCcsPane:stop()

	self._state = "hided";
	self:setVisible(false)

end

function SlwhNoticeCcsPane:showText()

	local msg = table.remove(self._msg, 1);
    --检测是否是奖池/高倍奖
    local score = msg.lJackpot
    local body_msg = ""

	local contentHtml = "";
    if msg.lWinScore > 0 then
	    contentHtml = contentHtml .. HtmlUtil.createColorTxt("发大财啦！ ", "#e9d265")
	    contentHtml = contentHtml .. HtmlUtil.createColorTxt(msg.szNickName .. " ", "#ef5cab")
	    contentHtml = contentHtml .. HtmlUtil.createColorTxt("在连环夺宝 ", "#e9d265")
        contentHtml = contentHtml .. HtmlUtil.createColorTxt(msg.szServerName .. " ","#ef5cab")
        contentHtml = contentHtml .. HtmlUtil.createColorTxt("中一举赢得","#e9d265")
        contentHtml = contentHtml .. HtmlUtil.createArtNumDot(msg.lWinScore, "#serial_notice_%s.png", nil, nil, nil, -5)
	    contentHtml = contentHtml .. HtmlUtil.createImg(Tree.root .. "notice/image_coin.png", nil, nil, nil, 2, nil, nil, 15, nil)
        contentHtml = contentHtml .. HtmlUtil.createColorTxt("!大家快来围观啊!","#e9d265")
    else
        contentHtml = contentHtml .. HtmlUtil.createColorTxt("天降横财！", "#e9d265")
	    contentHtml = contentHtml .. HtmlUtil.createColorTxt(msg.szNickName .. " ", "#ef5cab")
	    contentHtml = contentHtml .. HtmlUtil.createColorTxt("在连环夺宝 ", "#e9d265")
        contentHtml = contentHtml .. HtmlUtil.createColorTxt(msg.szServerName .. " ","#ef5cab")
        contentHtml = contentHtml .. HtmlUtil.createColorTxt("中赢得累积奖","#e9d265")
        contentHtml = contentHtml .. HtmlUtil.createArtNumDot(msg.lJackpot, "#serial_notice_%s.png", nil, nil, nil, -5)
	    contentHtml = contentHtml .. HtmlUtil.createImg(Tree.root .. "notice/image_coin.png", nil, nil, nil, 2, nil, nil, 15, nil)
        contentHtml = contentHtml .. HtmlUtil.createColorTxt("，一举暴富！","#e9d265")
    end
	local tf = TextField.new(CCSKitchen.defaultFontFamily, 30, nil, 20000, nil, TextField.H_LEFT);
	tf:setHtmlText(contentHtml)
	tf:setAnchorPoint(0.5, 0.5)
	local tfWidth = tf:getTextWidth()
	local v = 200

	local clipWidth = self.contentClipLayer:getContentSize().width
	local sThis = tfWidth + self._msgGap
	local tOut = (clipWidth - self._msgGap) / v 
	local tFull = sThis / v 
	tf:setPosition(cc.p(clipWidth, 23))
	
	self.contentClipLayer:addChild(tf)

	self._readyToAdd = false;
	self._showCounter = self._showCounter + 1;	

	tf:runAction(cc.Sequence:create(cc.MoveTo:create(tFull, cc.p(clipWidth - sThis, 23)), 
		cc.CallFunc:create(function() self._readyToAdd = true end), 
		cc.MoveTo:create(tOut, cc.p(-tfWidth, 23)), 
		cc.CallFunc:create(function() self._showCounter = self._showCounter - 1  end), 
		cc.RemoveSelf:create()))

end