--连环夺宝,数字滚动效果实现
--2018年7月2日
--@author:xiaoxiong
--传入参数的格式
--local roll_map = {
--    rect = {x = 0,y=0,width=90,height = 100},
--    texturePath = "",
--    commaTexturePath = "",
--    slotNumber = 8,
--    interval = 0.2,
--    alignType = 0
--}
local SlwhRollingText = class("SlwhRollingText", function(roll_map)
                                                        return cc.ClippingRectangleNode:create(roll_map.rect)
                                             end)

function SlwhRollingText:ctor(roll_map)
    self._step = 1
    self._lastNumber = 0  --上一次的数字
    self._inRolling = false --是否处于滚动之中
    self._numberSequence = {} --待变化的数字序列
    self._lastBitSequence = {} --上一次的数字分解后的数字序列
    self._commaSprites = {}   --逗号分隔符

    self._texturePath = roll_map.texturePath--Tree.Serial_Root .. "ingame/rolling_shuzi.png"
    self._commaTexturePath = roll_map.commaTexturePath--Tree.Serial_Root .. "ingame/rolling_douhao.png"
    self._rollTime = roll_map.interval --每一次的滚动时间
    self._slotNumber = roll_map.slotNumber --当前有多少个槽位
    self._alignType = roll_map.alignType
    self._rectWidth = roll_map.rect.width --裁剪区域
    self._rectHeight = roll_map.rect.height
    --缓存的数字的数目
    self._cacheNumber = 7
    --回调函数,启动前/启动后调用
    self._beforeCallFunc = nil
    self._afterCallFunc = nil
    --时间缩放比例
    self._timeScale = 1
end
--
function SlwhRollingText:setTimeScale(time_scale)
    self._timeScale = time_scale
end
--
function SlwhRollingText:getTimeScale()
    return self._timeScale
end
--init,0
function SlwhRollingText:init()
    self._slotSprites = {}
    self._rootNode = cc.Node:create()
    self._rootNode:setCascadeOpacityEnabled(true)
    self._rootNode:setPosition(0,0)

    self:addChild(self._rootNode)
    for idx =1, self._slotNumber do
        self._slotSprites[idx] = {
            [1] = cc.Sprite:create(self._texturePath),
            [2] = cc.Sprite:create(self._texturePath),
        }
        self._slotSprites[idx][1]:setAnchorPoint(0.5,0)
        self._slotSprites[idx][2]:setAnchorPoint(0.5,0)
        self._rootNode:addChild(self._slotSprites[idx][1])
        self._rootNode:addChild(self._slotSprites[idx][2])
        if idx % 3 == 0 then
            local split_sprite = cc.Sprite:create(self._commaTexturePath)
            split_sprite:setAnchorPoint(0.5,0)
            self._rootNode:addChild(split_sprite)
            table.insert(self._commaSprites,split_sprite)
        end
    end
    local slotSize = self._slotSprites[1][1]:getContentSize()
    self._everyWidth = slotSize.width
    self._everyHeight = slotSize.height/10
    local split_size = self._commaSprites[1]:getContentSize()
    self._everyCommaWidth = split_size.width
    self._width = slotSize.width * self._slotNumber + #self._commaSprites * self._everyCommaWidth
    self._height = slotSize.height
    --设置坐标,因为初始值为0的原因,因此只显示一个数字
    local offset_x = self._slotNumber * self._everyWidth + #self._commaSprites * self._everyCommaWidth
    local comma_index = 1
    for idx = 1,self._slotNumber do
        self._slotSprites[idx][1]:setPosition(offset_x - self._everyWidth * 0.5, - self._height)
        self._slotSprites[idx][2]:setPosition(offset_x - self._everyWidth * 0.5, - self._height)

        self._slotSprites[idx][1]:setVisible(false)
        self._slotSprites[idx][2]:setVisible(false)

       offset_x = offset_x - self._everyWidth
        --逗号分隔符
        if idx % 3 == 0 then
            self._commaSprites[comma_index]:setPosition(offset_x - self._everyCommaWidth * 0.5,0)
            self._commaSprites[comma_index]:setVisible(false)

            offset_x = offset_x - self._everyCommaWidth
            comma_index = comma_index + 1
        end
    end

    self._slotSprites[1][1]:setPositionY(-self._height + self._everyHeight)
    self._slotSprites[1][1]:setVisible(true)
    self._lastBitSequence = {[1] = 0}
    --依据对齐方式
    if self._alignType == Tree.AlignType.AlignType_Left then
        self._rootNode:setPositionX(-self._width + self._everyWidth)
    elseif self._alignType == Tree.AlignType.AlignType_Right then
        self._rootNode:setPositionX(0)
    elseif self._alignType == Tree.AlignType.AlignType_Center then
        self._rootNode:setPositionX(-(self._width - self._everyWidth) *0.5)
    end
end
--
function SlwhRollingText:setBeforeAfterCallFunc(beforeCallFunc,afterCallFunc)
    self._beforeCallFunc = beforeCallFunc
    self._afterCallFunc = afterCallFunc
end
--重置
function SlwhRollingText:changeNormal()
    self._inRolling = false
    self._lastNumber = 0
    self._numberSequence = {}
    self._delaySequence = {}
    self._lastBitSequence = {[1] = 0}

    for idx = 1,self._slotNumber do
        self._slotSprites[idx][1]:setPositionY(- self._height)
        self._slotSprites[idx][2]:setPositionY(- self._height)

        self._slotSprites[idx][1]:stopAllActions()
        self._slotSprites[idx][2]:stopAllActions()

        self._slotSprites[idx][1]:setVisible(false)
        self._slotSprites[idx][2]:setVisible(false)
    end

    self._rootNode:stopAllActions()
    self._slotSprites[1][1]:setPositionY(-self._height + self._everyHeight)
    self._slotSprites[1][1]:setVisible(true)
    if self._alignType == Tree.AlignType.AlignType_Left then
        self._rootNode:setPosition(-self._width + self._everyWidth,0)
    elseif self._alignType == Tree.AlignType.AlignType_Center then
        self._rootNode:setPosition(-(self._width - self._everyWidth) *0.5,0)
    end
    for idx =1,#self._commaSprites do
        self._commaSprites[idx]:setVisible(false)
    end
    if self._afterCallFunc then
        self._afterCallFunc(self)
    end
end

function SlwhRollingText:setSlotNumber(slot_number)
    self._slotNumber = slot_number
end

function SlwhRollingText:getSequenceNumber()
    return #self._numberSequence
end

function SlwhRollingText:addNumber(number,userId,delay_time)
    delay_time = delay_time or 0
    table.insert(self._numberSequence,{
        number = number,
        userID = userId,
        delayTime = delay_time * self._timeScale,
    })
    if not self._inRolling then
        self:performSequence()
    end
end

function SlwhRollingText:performSequence()
    if #self._numberSequence > 0 and not self._inRolling then
        self._inRolling = true
        local head = self._numberSequence[1]
        if head.delayTime > 0 and #self._numberSequence < 6 then
            self:runAction(cc.Sequence:create(cc.DelayTime:create(head.delayTime),
                                        cc.CallFunc:create(function()
                                            self:startRolling()
                                        end)))
        else
            self:startRolling()
        end
    end
end

function SlwhRollingText:setNumber(number)
    --if self._lastNumber == number then
    --    return
    --end
    self._inRolling = true
    local bitSequence = TreeFunc.splitNumber2(number)
    --停止的动作
    self._rootNode:stopAllActions()
    for idx = 1,self._slotNumber do
        self._slotSprites[idx][1]:stopAllActions()
        self._slotSprites[idx][2]:stopAllActions()

        self._slotSprites[idx][1]:setVisible(false)
        self._slotSprites[idx][2]:setVisible(false)
        if idx <= #bitSequence then
            self._slotSprites[idx][1]:setVisible(true)
            self._slotSprites[idx][1]:setPositionY(-(9-bitSequence[idx]) * self._everyHeight)
        end
    end
    --逗号
    local count_t = math.ceil(#bitSequence/3) - 1
    for idx = 1,#self._commaSprites do
        self._commaSprites[idx]:setVisible(idx<=count_t)
    end
    --最后对齐
    if self._alignType == Tree.AlignType.AlignType_Left then
        self._rootNode:setPositionX(-self._width + #bitSequence * self._everyWidth + count_t * self._everyCommaWidth)
    elseif self._alignType == Tree.AlignType.AlignType_Right then
        self._rootNode:setPositionX(0)
    elseif self._alignType == Tree.AlignType.AlignType_Center then
        self._rootNode:setPositionX(-(self._width - #bitSequence * self._everyWidth - count_t * self._everyCommaWidth)*0.5)
    end
    self._lastNumber = number
    self._lastBitSequence = bitSequence
    self._inRolling = false
    if self._afterCallFunc then
        self._afterCallFunc(self)
    end
end

function SlwhRollingText:startRolling()
    local numMap = table.remove(self._numberSequence,1)
    local now_number = numMap.number
    --数字相同,没有任何的效果
    if now_number == self._lastNumber then
        self._inRolling = false
        return
    end
    --调用外部传递的函数
    if self._beforeCallFunc then
        self._beforeCallFunc(self,numMap.userID)
    end
    local max_time = 0
    --计算差值,并计算新数字的各个数字序列
    local sign = TreeFunc.sign(now_number - self._lastNumber)
    local bitSequence = TreeFunc.splitNumber2(now_number)
    local roll_time = self._rollTime * self._timeScale
    --计算各个槽位上的动作
    --需要记住的是,索引1永远为当前可视的序列,2为需要交替的序列
    --如果上一次的数字的位数比这一次的大,则大出的位数需要逐渐滚动到0然后消失
    if #self._lastBitSequence > #bitSequence then
        --从最高位开始滚动
        local delay_time_t= 0
        local count_t = 1
        local last_bit_count = #self._lastBitSequence
        for idx = last_bit_count,#bitSequence + 1,-1 do
            local bit_number = self._lastBitSequence[idx] + 1
            local index_i = count_t
            local delay_time = idx * 0.033
            local index_t = idx
            --计算是否在左侧邻接着逗号,以及相关的索引,逗号的数目
            local index_comma = index_t % 3 == 1 and math.floor((index_t-1)/3) or 0
            local count_comma = math.ceil((index_t-1)/3) - 1
            self._slotSprites[idx][1]:runAction(cc.Sequence:create(cc.DelayTime:create(delay_time_t + delay_time),
                                                        cc.EaseSineInOut:create(cc.MoveBy:create(roll_time * bit_number,cc.p(0,-bit_number* self._everyHeight))),
                                                        cc.CallFunc:create(function()
                                                            if index_comma > 0 then
                                                                self._commaSprites[index_comma]:setVisible(false)
                                                            end
                                                            self._slotSprites[index_t][1]:setVisible(false)
                                                            if self._alignType == Tree.AlignType.AlignType_Left then
                                                                self._rootNode:setPositionX(-self._width + (last_bit_count-index_i)*self._everyWidth + count_comma * self._everyCommaWidth)
                                                            elseif self._alignType == Tree.AlignType.AlignType_Center then
                                                                self._rootNode:setPositionX(-(self._width - (last_bit_count-index_i)*self._everyWidth - count_comma * self._everyCommaWidth)*0.5)
                                                            end
                                                        end)))
            delay_time_t = delay_time_t +delay_time + roll_time * bit_number
            count_t = count_t + 1
        end
        max_time = math.max(max_time,delay_time_t)
    end
    --调整拥有共同位数的slot_sprite
    local common_number = math.min(#self._lastBitSequence,#bitSequence)
    local loops = 0
    for idx =1,common_number do
        local last_bit_number = self._lastBitSequence[idx]
        local now_bit_number = bitSequence[idx]
        local index = idx
        loops = math.max(loops, math.abs(now_bit_number - last_bit_number))
        --计算是否有跨越
        if sign > 0 then--数字变大
            if now_bit_number > last_bit_number then
                self._slotSprites[index][1]:runAction(cc.Sequence:create(cc.DelayTime:create(index * 0.033),
                                                            cc.EaseSineInOut:create(cc.MoveBy:create(roll_time * (now_bit_number - last_bit_number),cc.p(0,(now_bit_number - last_bit_number) * self._everyHeight)))))
            elseif now_bit_number < last_bit_number then
                self._slotSprites[index][2]:setPositionY(-(9 - last_bit_number) * self._everyHeight - self._height)
                self._slotSprites[index][2]:setVisible(true)
                local column_t = 9 - last_bit_number + now_bit_number + 1
                loops = math.max(column_t,loops)
                self._slotSprites[idx][1]:runAction(cc.Sequence:create(cc.DelayTime:create(index * 0.033),
                                                            cc.EaseSineInOut:create(cc.MoveBy:create(roll_time * column_t,cc.p(0,column_t * self._everyHeight)))))
                self._slotSprites[idx][2]:runAction(cc.Sequence:create(cc.DelayTime:create(index *0.033),
                                                            cc.EaseSineInOut:create(cc.MoveBy:create(roll_time *column_t,cc.p(0,column_t * self._everyHeight))),
                                                            cc.CallFunc:create(function()
                                                                local ts = self._slotSprites[index][2]
                                                                self._slotSprites[index][2] = self._slotSprites[index][1]
                                                                self._slotSprites[index][1] = ts
                                                                self._slotSprites[index][2]:setVisible(false)
                                                            end)))
            end
        elseif sign < 0 then
            if now_bit_number < last_bit_number then
                self._slotSprites[index][1]:runAction(cc.Sequence:create(cc.DelayTime:create(index*0.033),
                                                                cc.EaseSineInOut:create(cc.MoveBy:create(roll_time *(last_bit_number-now_bit_number),cc.p(0,(now_bit_number - last_bit_number)*self._everyHeight)))))
            elseif now_bit_number > last_bit_number then
                local column_t = 9-now_bit_number+1 + last_bit_number
                loops = math.max(column_t,loops)
                self._slotSprites[index][2]:setVisible(true)
                self._slotSprites[index][2]:setPositionY((1 + last_bit_number) * self._everyHeight)
                self._slotSprites[index][1]:runAction(cc.Sequence:create(cc.DelayTime:create(index*0.033),
                                                                cc.EaseSineInOut:create(cc.MoveBy:create(roll_time * column_t,cc.p(0,-column_t * self._everyHeight)))))
                self._slotSprites[index][2]:runAction(cc.Sequence:create(cc.DelayTime:create(index*0.033),
                                                                cc.EaseSineInOut:create(cc.MoveBy:create(roll_time*column_t,cc.p(0,-column_t*self._everyHeight))),
                                                                cc.CallFunc:create(function()
                                                                    local ts = self._slotSprites[index][2]
                                                                    self._slotSprites[index][2] = self._slotSprites[index][1]
                                                                    self._slotSprites[index][1] = ts
                                                                    self._slotSprites[index][2]:setVisible(false)
                                                                end)))
            end
        end
    end
    max_time = math.max(max_time,common_number*0.033+loops * roll_time)
    --如果有出现原来没有的高位
    if #bitSequence > #self._lastBitSequence then
        local delay_time = 0
        for idx = #self._lastBitSequence + 1, #bitSequence do
            local index_i = idx
            local now_number = bitSequence[idx] + 1
            --检查左侧是否应该出现逗号分隔符
            local index_comma = index_i%3 == 1 and (index_i-1)/3 or 0
            local count_comma = math.ceil(index_i/3) - 1
            self._slotSprites[idx][1]:setPositionY(-self._height)
            self._slotSprites[idx][1]:setVisible(true)
            self._slotSprites[idx][1]:runAction(cc.Sequence:create(cc.DelayTime:create(delay_time + index_i * 0.033),
                                                        cc.CallFunc:create(function()
                                                            if index_comma > 0 then
                                                                self._commaSprites[index_comma]:setVisible(true)
                                                            end
                                                            --从数字开始滚动前旧将位置腾出,此顺序与数字从大到小滚动的顺序相逆
                                                            if self._alignType == Tree.AlignType.AlignType_Left then
                                                                self._rootNode:setPositionX(-self._width + index_i*self._everyWidth + count_comma * self._everyCommaWidth)
                                                            elseif self._alignType == Tree.AlignType.AlignType_Center then
                                                                self._rootNode:setPositionX(-(self._width - index_i*self._everyWidth - count_comma * self._everyCommaWidth)*0.5)
                                                            end
                                                        end),
                                                        cc.EaseSineInOut:create(cc.MoveBy:create(roll_time * now_number,cc.p(0,now_number * self._everyHeight)))
                                                        ))
            delay_time = delay_time + index_i * 0.033 + roll_time * now_number
        end
        max_time = math.max(max_time,delay_time)
    end
    --设置结束整个滚动过程标志
    self._lastBitSequence = bitSequence
    self._lastNumber = now_number
    --
    local count_t = math.ceil(#bitSequence/3) - 1
    self._rootNode:runAction(cc.Sequence:create(cc.DelayTime:create(max_time+0.1),
                cc.CallFunc:create(function()
                    --对齐数字
                    if self._alignType == Tree.AlignType.AlignType_Left then
                        self._rootNode:setPositionX(-self._width + #bitSequence * self._everyWidth + count_t * self._everyCommaWidth)
                    elseif self._alignType == Tree.AlignType.AlignType_Center then
                        self._rootNode:setPositionX(-(self._width - #bitSequence * self._everyWidth - count_t * self._everyCommaWidth) * 0.5)
                    end
                end),
                cc.DelayTime:create(0.12),
                cc.CallFunc:create(function()
                    if self._afterCallFunc then
                        self._afterCallFunc(self,numMap.userID)
                    end
                    self._inRolling = false
                    self:performSequence()
                end)))
end
--此函数不能与addNumber一起调用,并且只能调用一次
function SlwhRollingText:addNumber2u(number,userId)
    table.insert(self._numberSequence,{
        number = number,
        userID = userId,
    })
    if not self._inRolling then
        self:startRolling2u()
    end
end
--滚动,滚动的过程有严格的要求,数字的位数必须严格一致
function SlwhRollingText:startRolling2u()
    if #self._numberSequence > 0 and not self._inRolling then
        local numMap = table.remove(self._numberSequence,1)
        local now_number = numMap.number
        --数字相同,没有任何的效果
        if now_number == self._lastNumber then
            return
        end
        self._inRolling = true
        local max_time = 0
        --计算差值,并计算新数字的各个数字序列
        local sign = TreeFunc.sign(now_number - self._lastNumber)
        local bitSequence = TreeFunc.splitNumber2(now_number)
        assert(#self._lastBitSequence == #bitSequence,"number of bit sequence")
        local roll_time = self._rollTime * self._timeScale
        --计算各个槽位上的动作
        --需要记住的是,索引1永远为当前可视的序列,2为需要交替的序列
        --调整拥有共同位数的slot_sprite
        local common_number = #bitSequence
        local loops = 0
        for idx =1,common_number do
            local last_bit_number = self._lastBitSequence[idx]
            local now_bit_number = bitSequence[idx]
            local index = idx
            loops = math.max(loops, math.abs(now_bit_number - last_bit_number))
            local base_time = roll_time * ( math.random()*0.5 + 0.5*idx/common_number)
            --向上滚动
            if now_bit_number > last_bit_number then
                self._slotSprites[index][1]:runAction(cc.Sequence:create(cc.DelayTime:create(index * 0.01),
                                                            cc.EaseSineInOut:create(cc.MoveBy:create(base_time * (now_bit_number - last_bit_number),cc.p(0,(now_bit_number - last_bit_number) * self._everyHeight)))))
            elseif now_bit_number < last_bit_number then
                self._slotSprites[index][2]:setPositionY(-(9 - last_bit_number) * self._everyHeight - self._height)
                self._slotSprites[index][2]:setVisible(true)
                local column_t = 9 - last_bit_number + now_bit_number + 1
                loops = math.max(column_t,loops)
                self._slotSprites[idx][1]:runAction(cc.Sequence:create(cc.DelayTime:create(index * 0.01),
                                                            cc.EaseSineInOut:create(cc.MoveBy:create(base_time * column_t,cc.p(0,column_t * self._everyHeight)))))
                self._slotSprites[idx][2]:runAction(cc.Sequence:create(cc.DelayTime:create(index *0.01),
                                                            cc.EaseSineInOut:create(cc.MoveBy:create(base_time *column_t,cc.p(0,column_t * self._everyHeight))),
                                                            cc.CallFunc:create(function()
                                                                local ts = self._slotSprites[index][2]
                                                                self._slotSprites[index][2] = self._slotSprites[index][1]
                                                                self._slotSprites[index][1] = ts
                                                                self._slotSprites[index][2]:setVisible(false)
                                                            end)))
            end
        end
        max_time = math.max(max_time,common_number*0.01+loops * roll_time)
        --设置结束整个滚动过程标志
        self._lastBitSequence = bitSequence
        self._lastNumber = now_number
        --
        local count_t = math.ceil(#bitSequence/3) - 1
        self._rootNode:runAction(cc.Sequence:create(cc.DelayTime:create(max_time+0.2),
                    cc.DelayTime:create(0.12),
                    cc.CallFunc:create(function()
                        self._inRolling = false
                        self:startRolling2u()
                    end)))
    end
end
--
function SlwhRollingText:onDestroy()

end

return SlwhRollingText