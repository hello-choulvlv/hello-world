SlwhOnlineCcsView = class("SlwhOnlineCcsView")

function SlwhOnlineCcsView:onCreationComplete()
    ClassUtil.extends( self, BaseOnlineCcsView )
    BaseOnlineCcsView.onCreationComplete(self)
    self:initRule()
end

function SlwhOnlineCcsView:initRule()
    if( self.view.imgShadow ) then 
        self.view.imgShadow:setLocalZOrder(999)
    end
end