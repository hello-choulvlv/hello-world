--森林舞会,庄和闲3d滚动功能实现
--2019年1月5日
--@author:xiaoxiong
--使用方法如下
--rolling_map = {
--timeInterval = 0.6,--滚动一个单元格的时间间隔
--unitNumber = 3,--图片上有多少个单元
--tagAction = 88,--动作的名称
--depthTest = true,--是否开启深度测试
--cameraMask = 4,--Camera Mask
--alphaThreshold = 0.1--裁剪的alpha临界值
--rollingScale = 0.5,--滚动纹理的缩放尺寸
--maskTexturePath = "",--遮罩的路径
--rollingTexturePath = "",--滚动纹理的路径
--useSpriteFrame = true,--是否使用SpriteFrame
--}
local SlwhClippingRolling = class("SlwhClippingRolling",function()
                                                    return cc.ClippingNode:create()
                                                end)
function SlwhClippingRolling:ctor(rolling_map)
    --滚动一个单元格的时间间隔
    self._timeInterval = rolling_map.timeInterval
    self._tagAction = rolling_map.tagAction
    self._maskSprite = rolling_map.useSpriteFrame and cc.Sprite:createWithSpriteFrameName(rolling_map.maskTexturePath) or cc.Sprite:create(rolling_map.maskTexturePath)
    self._maskSprite:setCameraMask(rolling_map.cameraMask)
    self._maskSprite:setAnchorPoint(0.5,0)

    self:setStencil(self._maskSprite)
    self:setAlphaThreshold(rolling_map.alphaThreshold)
    --最终显示的一定是self._rollingSprite1,而self._rollingSprite2则是一个打酱油的角色
    self._rollingSprite1 = rolling_map.useSpriteFrame and cc.Sprite:createWithSpriteFrameName(rolling_map.rollingTexturePath) or cc.Sprite:create(rolling_map.rollingTexturePath)
    self._rollingSprite1:setAnchorPoint(0.5,0)
    self._rollingSprite1:setScale(rolling_map.rollingScale)
    self._rollingSprite1:setCameraMask(rolling_map.cameraMask)
    self:addChild(self._rollingSprite1)

    --打酱油
    self._rollingSprite2 = rolling_map.useSpriteFrame and cc.Sprite:createWithSpriteFrameName(rolling_map.rollingTexturePath) or cc.Sprite:create(rolling_map.rollingTexturePath)
    self._rollingSprite2:setScale(rolling_map.rollingScale)
    self._rollingSprite2:setAnchorPoint(0.5,0)
    self._rollingSprite2:setCameraMask(rolling_map.cameraMask)
    self:addChild(self._rollingSprite2)
    --每一个单元的高度
    local size_rolling = self._rollingSprite1:getContentSize()
    self._unitNumber = rolling_map.unitNumber
    self._everyHeight = size_rolling.height * rolling_map.rollingScale/self._unitNumber
    self._maxHeight = size_rolling.height * rolling_map.rollingScale
    --当前的结果序列
    self._resultSequence = {}
    --当前的结果
    self._currentNumber = 0
    --当前是否处于转动中
    self._inAction = false
    --动作的整体速度
    --self._rollingSpeed = 1
    --default 0
    self._rollingSprite1:setPositionY(0)
    self._rollingSprite2:setPositionY(self._maxHeight)
    self:setCameraMask(rolling_map.cameraMask)
    --depth test
    if self._rollingSprite1.setDepthTest then
        self._maskSprite:setDepthTest(rolling_map.depthTest)
        self._rollingSprite1:setDepthTest(rolling_map.depthTest)
        self._rollingSprite2:setDepthTest(rolling_map.depthTest)
    end
    --滚动完毕之后的回调函数
    self._afterCallback = nil
end
--settting callback
function SlwhClippingRolling:setAfterCallback(callback)
    self._afterCallback = callback
end
--设置时间间隔
function SlwhClippingRolling:setTimeInterval(time_interval)
    self._timeInterval = time_interval
end
--setSpeed
function SlwhClippingRolling:setRollingSpeed(speed)
    local action_1 = self._rollingSprite1:getActionByTag(self._tagAction)
    if action_1 then
        action_1:setSpeed(speed)
    end
    --
    local action_2 = self._rollingSprite2:getActionByTag(self._tagAction + 1)
    if action_2 then
        action_2:setSpeed(speed)
    end
    --
    local action_s = self:getActionByTag(self._tagAction + 2)
    if action_s then
        action_s:setSpeed(speed)
    end
end
--设置当前的结果,当前的结果必须是[0-self._unitNumber]之间的值
function SlwhClippingRolling:setNumber(grid_y)
    self._rollingSprite1:stopAllActions()
    self._rollingSprite2:stopAllActions()

    self._rollingSprite1:setPositionY(-grid_y * self._everyHeight)
    self._rollingSprite2:setPositionY(-grid_y * self._everyHeight + self._maxHeight)
    self._currentNumber = grid_y

    self._inAction = false
    self._resultSequence = {}
end
--滚动,经过多少圈之后
function SlwhClippingRolling:addNumber(grid_y,cycle_num)
    assert(grid_y >=0 and grid_y <self._unitNumber and cycle_num >=0,"SlwhClippingRolling:addNum invalid param.")
    table.insert(self._resultSequence,{
        grid_y = grid_y,
        cycle = cycle_num,
    })
    if not self._inAction then
        self:perform()
    end
end
--开始执行
function SlwhClippingRolling:perform()
    local result_table = table.remove(self._resultSequence,1)
    self._inAction = true
    --计算需要转动的时间,以及相关的总长度,分批处理的循环次数
    local max_grid = self._unitNumber * 2
    local need_unit = self._unitNumber - self._currentNumber + self._unitNumber + result_table.grid_y + max_grid * result_table.cycle
    local cycle_i2 = result_table.cycle--math.floor(result_table.cycle *0.5)--偶数倍的周期

    local sprite_1 = self._rollingSprite1
    local sprite_2 = self._rollingSprite2
    --第一个滚动纹理的动作
    local remind_grid = self._unitNumber - self._currentNumber
    local table_action1 = {}
    table.insert(table_action1,cc.EaseSineOut:create(cc.MoveBy:create(remind_grid * self._timeInterval,cc.p(0,-remind_grid * self._everyHeight))))
    table.insert(table_action1,cc.CallFunc:create(function()
        sprite_1:setPositionY(self._maxHeight)
    end))
    --偶数倍的周期运动
    if cycle_i2 > 0 then
        table.insert(table_action1,cc.Repeat:create(cc.Sequence:create(
                                                                    cc.EaseSineOut:create(cc.MoveBy:create(max_grid * self._timeInterval,cc.p(0,-max_grid * self._everyHeight))),
                                                                    cc.CallFunc:create(function()
                                                                        sprite_1:setPositionY(self._maxHeight)
                                                                    end)),cycle_i2))
    end
    --第一个rolling sprite的收尾动作
    local y = self._unitNumber + result_table.grid_y
    table.insert(table_action1,cc.EaseSineOut:create(cc.MoveBy:create(y * self._timeInterval,cc.p(0,-y * self._everyHeight))))
    local speed_action = cc.Speed:create(cc.Sequence:create(table_action1),1)
    speed_action:setTag(self._tagAction)
    sprite_1:runAction(speed_action)
    
    ------------------------第二个滚动纹理的动作---------------------------------
    local l = self._unitNumber + self._unitNumber - self._currentNumber
    local table_action2 = {}

    table.insert(table_action2,cc.EaseSineOut:create(cc.MoveBy:create(l * self._timeInterval,cc.p(0,-l * self._everyHeight))))
    table.insert(table_action2,cc.CallFunc:create(function()
                            sprite_2:setPositionY(self._maxHeight)
                        end))
    --cycle 2
    if cycle_i2 > 0 then
        table.insert(table_action2,cc.Repeat:create(cc.Sequence:create(
                            cc.EaseSineOut:create(cc.MoveBy:create(max_grid * self._timeInterval,cc.p(0,-max_grid * self._everyHeight))),
                            cc.CallFunc:create(function()
                                sprite_2:setPositionY(self._maxHeight)
                            end)),cycle_i2))
    end
    --收尾
    local ry = result_table.grid_y
    if ry > 0 then
        table.insert(table_action2,cc.EaseSineOut:create(cc.MoveBy:create(ry * self._timeInterval,cc.p(0,-ry * self._everyHeight))))
    end
    local speed_action = cc.Speed:create(cc.Sequence:create(table_action2),1)
    speed_action:setTag(self._tagAction + 1)
    sprite_2:runAction(speed_action)
    --记录当前的结果
    self._currentNumber = result_table.grid_y
    --判断在最后是否需要调整self._rollingSprite2的位置
    local max_time = need_unit * self._timeInterval + 0.1
    local speed_action = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create(max_time),
                            cc.CallFunc:create(function()
                                self._inAction = false
                                if self._afterCallback then
                                    self._afterCallback(self,result_table.grid_y)
                                end
                            end)),1)
    speed_action:setTag(self._tagAction + 2)
    self:runAction(speed_action)

    self:runAction(cc.Sequence:create(cc.DelayTime:create(max_time - 0 * 0.033), cc.CallFunc:create(function()

        if self._stopCallback then
            self._stopCallback()
        end

    end)))

end

function SlwhClippingRolling:setStopCallback(callback)
    self._stopCallback = callback
end

--乱序滚动纹理,以下函数只用来在送灯滚动纹理动画中使用
--最终显示的数字num_y
--经过多少周期cycle_y,一个周期是一个纹理从低端到达上端
function SlwhClippingRolling:startWithSequence(num_y,cycle_y)
    --设置初始位置
    self._rollingSprite1:setPositionY(0)
    self._rollingSprite1:stopAllActions()
    self._rollingSprite2:setPositionY(self._maxHeight)
    self._rollingSprite2:setVisible(false)

    local sprite_1 = self._rollingSprite1
    --local sprite_2 = self._rollingSprite2

    sprite_1:runAction(cc.EaseSineOut:create(cc.MoveBy:create(num_y * self._timeInterval,cc.p(0,-self._everyHeight * num_y))))
    self._currentNumber = num_y
end
--同一个周期之内
function SlwhClippingRolling:decreaseTo(num_y)
    local dec_num = -num_y + self._currentNumber

    self._rollingSprite1:runAction(cc.EaseSineInOut:create(cc.MoveBy:create(self._timeInterval * math.abs(dec_num),cc.p(0,dec_num * self._everyHeight))))
    self._currentNumber = num_y
end

return SlwhClippingRolling