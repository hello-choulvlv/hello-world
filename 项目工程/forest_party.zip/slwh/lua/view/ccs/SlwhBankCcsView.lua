--连环夺宝银行
--2018年5月21日
--@author:xiaoxiong
SlwhBankCcsView = class("SlwhBankCcsView")
function SlwhBankCcsView:onCreationComplete()
    ClassUtil.extends(self, BaseBankTakePopupCcsView);
	BaseBankTakePopupCcsView.onCreationComplete(self)
    self._originPlaceHolder = self._inputPwd._placeHolder
	--对相关的组件的颜色进行设置
    --self._inputPwd:setPlaceHolderColor(cc.c4b(0x88,0x73,0x62,0xff))
    --self._inputPwd:setPlaceHolder("haha_test")
end
--修正iOS/MAC平台的bug
function SlwhBankCcsView:onZoomShowTweenComplete()
    BaseBankTakePopupCcsView.onZoomShowTweenComplete(self)
    local edit_box = self._inputPwd._editBox
    if edit_box then
        local children = edit_box:getChildren()
        for idx =1, #children do
            local child = children[idx]
            --判断是否是Placeholder-label
            if child.getString and child:getString() == self._originPlaceHolder then
                child:setColor(cc.WHITE)
                --child:setString(self._originPlaceHolder)
                break
            end
        end
    end
end

function SlwhBankCcsView:onUserInsureChanged()
	local userInsure = Hero:getUserInsure()
	self.view.sliderControl:setMaxValue(userInsure)
	self.view.txtDeposit_tf:setHtmlText(HtmlUtil.createArtNumDot(userInsure,"#slwh_bank_%s.png"))
	-- self.view.txtDeposit_tf:setText(StringUtil.numberStr2FormatNumberStr(userInsure))
	-- self.view.txtDX:setText(StringUtil.numberStr2ZhHant(userInsure))
end

function SlwhBankCcsView:onUserScoreChanged()
	local userScore = parseInt(Hero:getUserScore())
	self.view.txtCash_tf:setHtmlText(HtmlUtil.createArtNumDot(userScore,"#slwh_bank_%s.png"))
	-- self.view.txtCash_tf:setText(StringUtil.numberStr2FormatNumberStr(userScore))
    --向下派发事件,用户的分数发生了变化
	-- self.model.myScoreChangedSignal:emit()
    -- EventController:dispatchEvent(Serial.Event.userScoreChanged,userScore)
end

function SlwhBankCcsView:destroy()
	destroySomeObj(self.view.txtDeposit_tf)
	destroySomeObj(self.view.txtCash_tf)
	BaseBankTakePopupCcsView.destroy(self)
end