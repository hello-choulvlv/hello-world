--森林舞会场景实现
--2018年11月24日
--author:xiaoxiong
--@versioin:2.0,target->使用cc.Jump3DBy,Jump3DBy优化场景中的跳跃动作
SlwhBattleCcsView = class("SlwhBattleCcsView")

local textures = {
    Tree.root .. "model/tiny_light_Pink2.png",
    Tree.root .. "model/tiny_light_Pink1.png"
}

function SlwhBattleCcsView:onCreationComplete()
    ClassUtil.extends(self, BaseGameBattleView)
    local controller = self.controller
    controller.battleView = self

    self._animalRadius = 184
    self._animalHeight = -28
    self._timeInterval = 0.5--事件间隔为0.5秒
    self._debug = false --是否调试应用程序
    self._angleAverage = 360/Tree.ModelNumber
    self._lastTime = 0--记录上一帧的本地时间
    self._isSceneRotated = false--场景是否正在转动中

    self._gameOverTime = 0--收到游戏结束的协议时的时间,此数据用来校对场景旋转动作的速度
    self._gameOverDelay = 0--受到场景结束协议时,服务端给客户端留的时间
    self._gameStageSpeed = 1--当前阶段游戏的整体速度,该数值只对一个阶段有效,每一阶段都必须重置
    --sound effect
    self._rotateEffectHandler = -1--场景旋转时的音效播放
    self._rotateStopEffectHandler = -1--场景停止旋转时的音效
    self._originAudioVolum = -1--当前的音量
    self._rewardEffectHandler = -1

    self._animalSelectSet = {}--当前被选中的模型的集合
    self._placeholder = {}--已经被选中的模型占据的位置
    self._selectLightModels = {}--被选中的色块
    --jackpot
    self._shouldChangeJackpot = true--是否可以更改彩金数字

    self.model.isShowingMenuChangedSignal:add(self.onMenuShowChanged, self)
    --动作缓存,用于存储3d模型动画
    self._animationActionActivity = {}
    self._animationActionJump = {}
    self._animationActionReward = {}
    --跳跃动画
    if not cc.Jump3DBy then
        self._actionManager = TreeActionManager.new()
        self._actionTickManager = nil
    end

    --场景 + 指针的搭配
    self._forestPartyMap = {}
    --舞台模型动画
    self._partyAnimation = {
        [Tree.RewardType.RewardType_Normal] = {},
        [Tree.RewardType.RewardType_DaSanYuan] = {},
        [Tree.RewardType.RewardType_DaSiXi] = {},
        [Tree.RewardType.RewardType_CaiJin] = {},
    }
    --animal animation
    self._animalActivityAnimation = {}
    self._animalJumpAnimation = {}
    self._animalRewardAnimation = {}

    self:initCamera()
    self:buildScene()

    self.layer_menu.lvNode.list_lv:setItemResCcsFileName("module/slwh/csb/layer/SlwhMenuItem.csb")
    self.layer_menu.lvNode.list_lv:setGap(0)
    self.layer_money:setStrBaseWidth(155)
    --self.layer_bet:setStrBaseWidth(13)

    self:loadSpineAnimation()
    --对齐场景
    self:alignComponent()
    self:loadGLProgram()

    self.__switch1 = false
    self.__switch2 = false
    self.sprite_mask:setScaleY(1.02)
    --舞台中央的底盘集合
    self._stageColorWheels = {}
    --是否需要手工弹出奖励界面,手工触发需要满足三个条件,参见notifyTimer函数
    self._shouldShowRewardUI = false
    --当前场景动画进行的阶段
    self._sceneAnimationOrder = 0
    --背景音乐的实际音量
    self._originBackSoundVolum = 0
    --当前游戏的阶段,空闲阶段1->下注阶段2->开奖阶段3
    self._gameStageOrder = -1
    --当前是否可以修改玩家的分数
    self._couldPlayerScoreModify = true

    -- 年兽活动
    if Hero:getIsShowingNshd() then
        -- 开启年兽活动
        local node = ResConfig.loadCsLayout(Hero:getActivityResConfig(), self)
        node:setPosition(170, 130)
        node:showStorage(true)
        node:setAnchorPoint(cc.p(0.5, 0.5))
        node:setStorage(0)
        node:setVisible(false)
        self:addChild(node)
        self.activityNode = node
        self.model.monsterInfoChangedSignal:add(self.onMonsterInfoChanged, self)
        self:onMonsterInfoChanged()
        self.controller:adjustSlimWidth(node, UIConfig.ALIGN_LEFT, 80)
    else
        --粽子
        self.model.selfRedPacketDataChangedSignal:add(self.onRedPacketDataChanged, self)
        local node = ResConfig.loadCsLayout(Hero:getActivityResConfig(), self)
        node:setPosition(170, 130)
        node:showStorage(true)
        node:setAnchorPoint(cc.p(0.5, 0.5))
        node:setStorage(0)
        node:setVisible(false)
        self:addChild(node)
        self.redPacket = node
        self:onRedPacketDataChanged()
        self.controller:adjustSlimWidth(node, UIConfig.ALIGN_LEFT, 80)
    end

    self.layer_money:setBankOpenCallback(handler(self,self.openBankCallback))

    self._optimal = cc.LabelFrameAtlas ~= nil
    if not self._optimal then
        self.layer_bet.node_allbets = cc.Node:create()
    else
        self.layer_bet.node_allbets = cc.LabelFrameAtlas:create("slwh_battle_money%s.png")
        self.layer_bet.node_allbets:setAnchorPoint(0,0.5)
    end
    self.layer_bet.node_allbets:setPosition(131,45)
    self.layer_bet:addChild(self.layer_bet.node_allbets)
end

-- 年兽活动
function SlwhBattleCcsView:onMonsterInfoChanged()
    local data = self.model:getMonsterInfo()
    -- 判断是否显示年兽活动
    if self.activityNode and data then
        local nianshouGames = Hero:getNshdGameLists()
        local gameKind = self.model:getGameKind()
        self.activityNode:setVisible(TableUtil.IsInTable(tostring(gameKind), nianshouGames))
        self.activityNode:setActivityMode(data)
    end

    if self.activityNode then
        if self.model:getRoomKind() == 1 then
            -- 体验房 屏蔽年兽图标显示
            self.activityNode:setVisible(false)
        end
        -- 清理动画，避免前一次spine尚未播放完毕时退出房间重新进入游戏spine依旧显示的问题
        self.activityNode:showStorage(true)
    end
end

function SlwhBattleCcsView:onRedPacketDataChanged()
    local data = self.model:getSelfRedPacketData()
    if self.redPacket and data then
        self.redPacket:setVisible(data.cbIsActiviting == 1)
        if data.isReconnect then --重连数据，无动画
            self.redPacket:setStorage(data.total, data.lCount)
        else
            data.needPlayAnim = true
        end
    end
end

--适配ix
function SlwhBattleCcsView:alignComponent()
    local offset_x = self.btnOpen:getPositionX()
    self.controller:adjustSlimWidth(self.btnOpen, UIConfig.ALIGN_LEFT, 80)
    self.controller:adjustSlimWidth(self.btnClose, UIConfig.ALIGN_LEFT, 80)
    self.controller:adjustSlimWidth(self.layer_menu, UIConfig.ALIGN_LEFT, 80)
    self.controller:adjustSlimWidth(self.layer_jackpot, UIConfig.ALIGN_LEFT, 80)
    self.controller:adjustSlimWidth(self.layer_hero, UIConfig.ALIGN_LEFT, 80)
    self.controller:adjustSlimWidth(self.layer_money, UIConfig.ALIGN_LEFT, 80)
    self.controller:adjustSlimWidth(self.layer_bet, UIConfig.ALIGN_LEFT, 80)

	self.controller:adjustSlimWidth(self.btnBet,UIConfig.ALIGN_RIGHT,-80)
    self.controller:adjustSlimWidth(self.layer_time,UIConfig.ALIGN_RIGHT,-80)
    --场景根节点变化,并且需要保证一定是处于世界坐标点中心
    self.node_scene:setPosition(-(display.width - CONFIG_DESIGN_WIDTH) * 0.5,-(display.height - CONFIG_DESIGN_HEIGHT) * 0.5)
    self._screenOffsetX = self.btnOpen:getPositionX() - offset_x
end
--打开银行的回调函数
function SlwhBattleCcsView:openBankCallback(component)
    if self.model:getUserGameStatus() == Tree.Status.Over then
        tweenMsgMgr:showRedMsg("您不能在开奖阶段进入银行")
        return false
    end
    return true
end
--加载shader
function SlwhBattleCcsView:loadGLProgram()
    --彩金金黄色shader
    self._goldGLProgram = cc.GLProgram:createWithFilenames(Tree.root .. "shader/cook_torrance_vs.glsl",Tree.root .. "shader/cook_torrance_fs.glsl")
    self._goldGLProgram:retain()

    self._goldStates = {}
    self._goldStates[1] = cc.GLProgramState:create(self._goldGLProgram)
    --self._goldStates[2] = cc.GLProgramState:create(self._goldGLProgram)

    self._goldStates[1]:retain()
    --self._goldStates[2]:retain()
    --设置相关的数值
    local model_color = {x = 0xda / 255.0, y = 0xae / 255.0, z = 0x39 / 255.0, w = 1.0}
    local light_position = {x = 50,y = 450,z = 460}
    for index_j = 1, 1 do
        local gl_state = self._goldStates[index_j]
        gl_state:setUniformVec4("g_Color", model_color)
        gl_state:setUniformVec3("g_LightPosition", light_position)

        gl_state:setUniformFloat("g_M",0.30)
        gl_state:setUniformFloat("g_RI",0.95)
        gl_state:setUniformFloat("g_Ambient",0.8)
        gl_state:setUniformFloat("g_Diffuse",0.6)
        gl_state:setUniformFloat("g_Specular",0.12)
        gl_state:setUniformFloat("g_Scale",0.8)
    end
    --在实际使用的过程中,需要加上眼睛的实际位置
    self._originGLProgramState = {}--作为原模型shader备份的数据结构
end
--加载Spine
function SlwhBattleCcsView:loadSpineAnimation()
    --累积奖金特效
    self.layer_jackpot.node_jackpot:setLocalZOrder(2)
    self.layer_jackpot.node_jackpot:setPosition(cc.p(120, 26))
    self.layer_jackpot:setVisible(false)
    --倒计时
    --下注按钮
    local skeleton = sp.SkeletonAnimation:create(Tree.root .. "effect/slwh_xiazhumenu.json",Tree.root .. "effect/slwh_xiazhumenu.atlas")
    skeleton:setAnimation(0,"animation",true)
    skeleton:setPosition(157,60)
    self.btnBet:addChild(skeleton)
    self.btnBet.spine_enable = skeleton
    TreeFunc.createWrapFunc(self.btnBet,"setEnabled",c_func(self.onButtonWrap,self))

    local water_sprite = cc.Sprite:create(Tree.root .. "battle/slwh_stagewater.png")
    water_sprite:setPosition3D({x=0,y=-60,z=0})
    water_sprite:setRotation3D({x=-90,y=0,z=0})
    water_sprite:setCameraMask(Tree.CameraFlag)
    water_sprite:setScale(1.35)
    if water_sprite.setDepthTest then
        water_sprite:setDepthTest(true)
    end
    self.node_scene:addChild(water_sprite)
end
--按钮的包装函数,用来化简函数调用,避免重复的代码过度膨胀
function SlwhBattleCcsView:onButtonWrap(obj,enable)
    if obj == self.btnBet then
        self.btnBet.sprite_disable:setVisible(not enable)
        self.btnBet.spine_enable:setVisible(enable)
    end
end
--初始化摄像机
function SlwhBattleCcsView:initCamera()
    local zeye = display.height/1.1566
    local eye_position = Tree.SceneLocation.Camera.eyePosition--{x = 0,y = display.height * 0.85,z = display.height * 0.70}
    local target_position = {x = 0,y = 0,z = 0}

    self._originEyePosition = eye_position
    self._finalEyePosition = Tree.SceneLocation.Camera.finalPosition--{x = 0,y = display.height * 0.50,z = display.height * 0.4}
    --self._lookPosition = target_position

    --摄像机的近平面与远平面尽可能地隔开,并且近平面尽可能地设置较大的数值,这样可以减轻像素深度冲突
    self._camera = cc.Camera:createPerspective(60,display.width/display.height,100,2000)
    self._camera:setCameraFlag(Tree.CameraFlag)
    self._camera:retain()
    self._camera:setPosition3D(eye_position)
    self._camera:setRotation3D({x = Tree.SceneLocation.Camera.startAngle,y=0,z=0})
end

---------------------------------------------------------------
function SlwhBattleCcsView:createStaticScene()
    self.staticModel = cc.Sprite3D:create( SLWH_MODEL_ONE_BY_ONE.StaticModel )
    self.staticModel:setPosition3D( cc.vec3(0,0,0) )
    self.staticModel:setCameraMask( Tree.CameraFlag )
    self.node_scene:addChild( self.staticModel )

    self.plant1 = cc.Sprite3D:create( SLWH_MODEL_ONE_BY_ONE.Plant1Model )
    self.plant1:setPosition3D( cc.vec3(0,0,0) )
    self.plant1:setCameraMask( Tree.CameraFlag )
    self.node_scene:addChild( self.plant1 )
    -- self.plant1Mat = cc.Material:createWithFilename( SLWH_MODEL_ONE_BY_ONE.Plant1Mat )
    -- self.plant1:setMaterial( self.plant1Mat )
    -- self.plant1:getMaterial(0):setTechnique("normal")

    self.plant2 = cc.Sprite3D:create( SLWH_MODEL_ONE_BY_ONE.Plant2Model )
    self.plant2:setPosition3D( cc.vec3(0,0,0) )
    self.plant2:setCameraMask( Tree.CameraFlag )
    self.node_scene:addChild( self.plant2 )
    -- self.plant2Mat = cc.Material:createWithFilename( SLWH_MODEL_ONE_BY_ONE.Plant2Mat )
    -- self.plant2:setMaterial( self.plant2Mat )
    -- self.plant2:getMaterial(0):setTechnique("normal")

    self.plant3 = cc.Sprite3D:create( SLWH_MODEL_ONE_BY_ONE.Plant3Model )
    self.plant3:setPosition3D( cc.vec3(0,0,0) )
    self.plant3:setCameraMask( Tree.CameraFlag )
    self.node_scene:addChild( self.plant3 )
    self.plant3Mat = cc.Material:createWithFilename( SLWH_MODEL_ONE_BY_ONE.Plant3Mat )
    self.plant3:setMaterial( self.plant3Mat )
    self.plant3:getMaterial(0):setTechnique("normal")

    self.plant4 = cc.Sprite3D:create( SLWH_MODEL_ONE_BY_ONE.Plant4Model )
    self.plant4:setPosition3D( cc.vec3(0,0,0) )
    self.plant4:setCameraMask( Tree.CameraFlag )
    self.node_scene:addChild( self.plant4 )
    self.plant4Mat = cc.Material:createWithFilename( SLWH_MODEL_ONE_BY_ONE.Plant4Mat )
    self.plant4:setMaterial( self.plant4Mat )
    self.plant4:getMaterial(0):setTechnique("normal")

    self.plant5 = cc.Sprite3D:create( SLWH_MODEL_ONE_BY_ONE.Plant5Model )
    self.plant5:setPosition3D( cc.vec3(0,0,0) )
    self.plant5:setCameraMask( Tree.CameraFlag )
    self.node_scene:addChild( self.plant5 )
    self.plant5Mat = cc.Material:createWithFilename( SLWH_MODEL_ONE_BY_ONE.Plant5Mat )
    self.plant5:setMaterial( self.plant5Mat )
    self.plant5:getMaterial(0):setTechnique("normal")
end
---------------------------------------------------------------

--建立场景
function SlwhBattleCcsView:buildScene()
    self._sceneModelMain = cc.Sprite3D:create(Tree.root .. "model/slwh_sence.c3b")
    self._sceneModelMain:setPosition3D(Tree.ZeroPosition)
    self._sceneModelMain:setCameraMask(Tree.CameraFlag)
    self.node_scene:addChild(self._sceneModelMain)
    --shader for plant
    self._plantGLProgram = cc.GLProgram:createWithFilenames(Tree.root .. "shader/plant.vert",Tree.root .. "shader/plant.frag")
    self._plantGLProgram:retain()

    for index_j = 1,5 do
        local model_path = string.format("model/t_plant%d_model.c3b",index_j)
        local model_secondary = cc.Sprite3D:create(Tree.root .. model_path)
        model_secondary:setPosition3D(Tree.ZeroPosition)
        model_secondary:setCameraMask(Tree.CameraFlag)
        --model_secondary:setOpacity(250)
        local glState = cc.GLProgramState:create(self._plantGLProgram)
        model_secondary:setGLProgramState(glState)
        self.node_scene:addChild(model_secondary)
    end
    --摆放转盘,指针,盖子
    self._stagePartyModel = cc.Sprite3D:create(Tree.root .. "model/slwh_yuanshistage.c3b")
    self._stagePartyModel:setCameraMask(Tree.CameraFlag)
    self._stagePartyModel:setTag(Tree.RewardType.RewardType_Normal)
    self._stagePartyModel:setRotation3D(Tree.ZeroPosition)
    self.node_scene:addChild(self._stagePartyModel)

    self._stagePointerModel = cc.Sprite3D:create(Tree.root .. "model/slwh_yuanshipoint.c3b")
    self._stagePointerModel:setCameraMask(Tree.CameraFlag)
    self._stagePointerModel:setTag(Tree.RewardType.RewardType_Normal)
    self._stagePointerRotation = self._stagePointerModel:getRotation3D()
    self.node_scene:addChild(self._stagePointerModel)
    --首先记录下常态情况下的舞台情况
    self._forestPartyMap[Tree.RewardType.RewardType_Normal] = {
        pointerModel = self._stagePointerModel,
        partyModel = self._stagePartyModel,
    }
    local animation = cc.Animation3D:create(Tree.root .. "model/slwh_yuanshistage.c3b")
    self._stagePartyOriginAnimate = cc.Animate3D:createWithFrames(animation,0,2,30)
    self._stagePartyOriginAnimate:retain()

    --所有的明灯,摆放的顺序为以+Z轴位基准,以右手法则,顺时针均分2π弧度角摆放,
    self._lightNode = cc.Node:create()
    self._lightNode:setCameraMask(Tree.CameraFlag)
    self.node_scene:addChild(self._lightNode)

    --动物模型的站台
    self._brickNode = cc.Node:create()
    self._brickNode:setCameraMask(Tree.CameraFlag)
    self.node_scene:addChild(self._brickNode,5)
    --此节点用于装载从self._brickNode中删除的动物模型
    self._actNode = cc.Node:create()
    self._actNode:setCameraMask(Tree.CameraFlag)
    self.node_scene:addChild(self._actNode,6)
    --安卓平台比较特殊,暂时不处理,现在加上去了,要稍微复杂一些
    local should_create = cc.Sprite3DBatch and (cc.Sprite3DBatch:checkSupportOpenGL3() or cc.Sprite3DBatch:checkSupportDrawInstanced())
    if should_create then
        --安卓平台无法使用纹理数组,因此可以直接略过
        local configuration = cc.Configuration and cc.Configuration:getInstance()
        local b4_shader5 = configuration and configuration:getGLVersion() >= 3.0
        --dump(b4_shader5)
        if not isAndroid or b4_shader5 then
            self._brickBatch = cc.Sprite3DBatch:create(nil)
            self._brickBatch:setCameraMask(Tree.CameraFlag)
            self._brickNode:addChild(self._brickBatch)
        end

        if isAndroid then
            if b4_shader5 then
                local texture_array = {
                    Tree.root .. "model/light/02_basecolor_01.png",
                    Tree.root .. "model/light/02_basecolor_0_09.png",
                    Tree.root .. "model/light/02_basecolor_03.png",
                    Tree.root .. "model/light/02_basecolor_0_03.png",
                    Tree.root .. "model/light/02_basecolor_02.png",
                    Tree.root .. "model/light/02_basecolor_0_06.png",
                    Tree.root .. "model/light/02_basecolor_04.png",
                }
                local texture_2d_array = cc.Texture2DArray:create(texture_array)
                self._lightBatch = cc.Sprite3DBatch:createWithTextureArray(nil,texture_2d_array)
                self._lightBatch:setCameraMask(Tree.CameraFlag)
                self.node_scene:addChild(self._lightBatch)
            end
        else
            self._lightBatch = cc.Sprite3DBatch:create(nil)
            self._lightBatch:setCameraMask(Tree.CameraFlag)
            self.node_scene:addChild(self._lightBatch)
        end

        local platform = cc.Application:getInstance():getTargetPlatform()
        local mac_header = "#extension GL_ARB_draw_instanced : enable\n#extension GL_EXT_texture_array : enable\n#define gl_InstanceID gl_InstanceIDARB\n"
        local ios_header = 	"#extension GL_EXT_draw_instanced : enable\nprecision mediump float;\nprecision mediump int;\n#define gl_InstanceID gl_InstanceIDEXT\n"
        local android_normal = "#version 120 es\n#extension GL_EXT_draw_instanced : enable\nprecision mediump float;\nprecision mediump int;\n#define gl_InstanceID gl_InstanceIDEXT\n"
        local android_v3 = "#version 300 es\nprecision mediump float;\nprecision mediump int;\n"

        local shader_header = ios_header
        if platform == cc.PLATFORM_OS_MAC then
            shader_header = mac_header
        elseif platform == cc.PLATFORM_OS_ANDROID then
            shader_header = android_v3
        end
        --安卓平台中,glsl driver的实现跟iOS/MAC,Win32有很大的不同,他不能使用sampler2D数组,因此色块不能使用实例化渲染
        if platform ~= cc.PLATFORM_OS_WINDOWS then
            local filename_vs = "shader/sample.vs"
            local filename_fs = "shader/sample.fs"
            --以前的C++代码在获取GL3.0 API地址时存在一些问题,该问题在现有版本中已经解决,标志就是configuration对象是否存在,因此有必要做一些兼容
            if isAndroid and b4_shader5 then
                filename_vs = "shader/sample_v3.vs"
                filename_fs = "shader/sample_v3.fs"
            end
            --如果非安卓平台,或者是安卓平台但是GL版本低于3.0切支持instanced draw扩展,或者是安卓平台且是C++最新代码并且支持shader5
            if not isAndroid or b4_shader5 then
                local vertex_shader_source = cc.FileUtils:getInstance():getStringFromFile(Tree.root .. filename_vs)
                local frag_shader_source = cc.FileUtils:getInstance():getStringFromFile(Tree.root .. filename_fs)
                self._brickGLProgram = cc.GLProgram:createWithByteArrays(vertex_shader_source,frag_shader_source,shader_header,"")
            end

            local sample_texture_vs = "shader/sample_texture.vs"
            local sample_texture_fs = "shader/sample_texture.fs"
            local sample_texture_header = shader_header
            if isAndroid and b4_shader5 then
                sample_texture_header = "#version 300 es\nprecision highp float;\nprecision highp int;\n"
                sample_texture_vs = "shader/sample_texture_array_v3.vs"
                sample_texture_fs = "shader/sample_texture_array_v3.fs"
            end

            if not isAndroid or b4_shader5 then
                local vs_source = cc.FileUtils:getInstance():getStringFromFile(Tree.root .. sample_texture_vs)
                local fs_source = cc.FileUtils:getInstance():getStringFromFile(Tree.root .. sample_texture_fs)
                self._lightGLProgram = cc.GLProgram:createWithByteArrays(vs_source,fs_source,sample_texture_header,"")
            end
        else
            self._brickGLProgram = cc.GLProgram:createWithFilenames(Tree.root .. "shader/sample.vs",Tree.root .. "shader/sample.fs")
            self._lightGLProgram = cc.GLProgram:createWithFilenames(Tree.root .. "shader/sample_texture.vs",Tree.root .. "shader/sample_texture.fs")
        end
    end

    self._lightModels = {}
    for idx = 1,Tree.ModelNumber do
        local lightModel = cc.Sprite3D:create(Tree.root .. "model/light/slwh_dwdzlight.c3b")
        local r_3d = lightModel:getRotation3D()
        lightModel:setRotation3D({x = r_3d.x ,y = r_3d.y - (idx-1) * 360/Tree.ModelNumber,z = r_3d.z})
        lightModel:setCameraMask(Tree.CameraFlag)
        --随机设置砖块的颜色
        local texture_idx = math.random(1,#Tree.BrickTexture)
        lightModel:setTag(texture_idx)
        lightModel._textureIndex = 0
        lightModel:setTexture(Tree.BrickTexture[texture_idx][1])
        lightModel._sequence = idx

        if self._lightBatch then
            if idx == 1 then
                lightModel:setGLProgram(self._lightGLProgram)
                self._lightBatch:setBatchMesh(lightModel:getMesh())
            end
            self._lightBatch:addChild(lightModel)
        else
            self._lightNode:addChild(lightModel)
        end
        table.insert(self._lightModels,lightModel)
    end

    self._brickModels = {}
    for idx = 1, Tree.ModelNumber do
        local brickModel = cc.Sprite3D:create(Tree.root .. "model/slwh_dwdz.c3b")
        local r_3d = brickModel:getRotation3D()
        brickModel:setRotation3D({x = r_3d.x,y = r_3d.y + (idx-1)*360/Tree.ModelNumber,z = r_3d.z})
        local p_3d = brickModel:getPosition3D()
        brickModel:setCameraMask(Tree.CameraFlag)

        if not self._brickBatch then
            self._brickNode:addChild(brickModel)
        else
            self._brickBatch:addChild(brickModel)
            if idx == 1 then
                brickModel:setGLProgram(self._brickGLProgram)
                self._brickBatch:setBatchMesh(brickModel:getMesh())
            end
        end

        table.insert(self._brickModels,brickModel)
    end

    --动物模型
    self._animalModels= {}
    self._shadowSprites = {}
    --从+Z轴方向开始,顺时针摆放动物模型,动物的起始旋转角度是朝向+Z轴
    for idx = 1, Tree.ModelNumber do
        local model_type = (idx-1) % 4 + 1
        local model_path = Tree.ModelPath[model_type]
        local animalModel = cc.Sprite3D:create(model_path)
        animalModel:setTag(idx)
        animalModel:setRotation3D({x =0, y = 180 - (idx - 1) * 360/Tree.ModelNumber,z = 0})

        local radius = 2 * math.pi * (idx - 1)/24
        local x = - math.sin(radius) * self._animalRadius
        local y = self._animalHeight
        local z = math.cos(radius) * self._animalRadius

        animalModel:setPosition3D({ x = x,y= y,z = z})
        animalModel:setCameraMask(Tree.CameraFlag)

        self._brickNode:addChild(animalModel,model_type)
        table.insert(self._animalModels,animalModel)

        if self._debug then
            local label = cc.Label:createWithSystemFont(tostring(idx),"Arial",16)
            label:setPosition(0,100)
            animalModel:addChild(label)
            label:setCameraMask(Tree.CameraFlag)
        end
        --shadow
        local shadow = cc.Sprite:createWithSpriteFrameName("slwh_battle_shadow.png")
        shadow:setPosition3D({x =x,y = y + 0.5,z = z})
        shadow:setRotation3D({x=-90,y=0,z=0})
        shadow:setCameraMask(Tree.CameraFlag)
        shadow:setTag(idx)
        if shadow.setDepthTest then
            shadow:setDepthTest(true)
        end
        self._brickNode:addChild(shadow,10)--batch draw
        table.insert(self._shadowSprites,shadow)
    end
    --庄和闲-TV
    self._nodeTV = cc.Node:create()
    self._nodeTV:setPosition3D(Tree.SceneLocation.TVModel)

    self._tvZXH = cc.Sprite3D:create(Tree.root .. "model/slwh_zxhtv.c3b")
    self._tvZXH:setCameraMask(Tree.CameraFlag)
    self._tvZXH:setRotation3D({x = 0, y = 0, z = 0})
    self._tvZXH:setPosition3D({x = 0, y = -50, z = 0})
    self._nodeTV:addChild(self._tvZXH)

    self._tvZXHLight1 = cc.Sprite3D:create(Tree.root .. "model/slwh_zxhtvlight1.c3b")
    self._tvZXHLight1:setCameraMask(Tree.CameraFlag)
    self._tvZXHLight1:setRotation3D({x = 0, y = 0, z = 0})
    self._tvZXHLight1:setPosition3D({x = 0, y = -50, z = 0})
    self._tvZXHLight1:setVisible(true)
    self._tvZXHLight1:setTexture(Tree.root .. "model/tiny_light_Pink1.png")
    self._nodeTV:addChild(self._tvZXHLight1)

    self._tvZXHLight2 = cc.Sprite3D:create(Tree.root .. "model/slwh_zxhtvlight2.c3b")
    self._tvZXHLight2:setCameraMask(Tree.CameraFlag)
    self._tvZXHLight2:setRotation3D({x = 0, y = 0, z = 0})
    self._tvZXHLight2:setPosition3D({x = 0, y = -50, z = 0})
    self._tvZXHLight2:setVisible(true)
    self._tvZXHLight2:setTexture(Tree.root .. "model/tiny_light_Pink1.png")
    self._nodeTV:addChild(self._tvZXHLight2)


    local rolling_map = {
        timeInterval = 0.12,--滚动一个单元格的时间间隔
        unitNumber = 3,--图片上有多少个单元
        tagAction = Tree.TagTV,--动作的名称
        alphaThreshold = 0.1,--裁剪的alpha临界值
        depthTest = true, --是否开启深度测试
        cameraMask = Tree.CameraFlag,
        rollingScale = 0.5,--滚动纹理的缩放尺寸
        maskTexturePath = "slwh_tv_mask.png",--遮罩的路径
        rollingTexturePath = "slwh_rolling_zhx.png",--滚动纹理的路径
        useSpriteFrame = true,--使用SpriteFrame
    }
    local rolling_class = requireLuaFromModule("slwh.view.ccs.SlwhClippingRolling")
    self._rollingClipping = rolling_class.new(rolling_map)
    self._rollingClipping:setPosition3D({x = 0,y = -34,z = 32})
    self._rollingClipping:setAfterCallback(handler(self,self.playSoudEffectZXH))
    self._rollingClipping:setStopCallback(function()

        self._tvZXH:stopAllActions()
        local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtv.c3b")
        self._tvZXH:runAction(cc.Animate3D:createWithFrames(animation,8,24,30))

        self._tvZXHLight1:stopAllActions()
        self._tvZXHLight1:setTexture(Tree.root .. "model/tiny_light_Pink2.png")
        local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtvlight1.c3b")
        self._tvZXHLight1:runAction(cc.Sequence:create(cc.Animate3D:createWithFrames(animation,8,24,30), cc.CallFunc:create(function()
            self._tvZXHLight1:stopAllActions()
            self._tvZXHLight1:setTexture(Tree.root .. "model/tiny_light_Pink1.png")

        end)))

        self._tvZXHLight2:stopAllActions()
        self._tvZXHLight2:setTexture(Tree.root .. "model/tiny_light_Pink2.png")
        local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtvlight2.c3b")
        self._tvZXHLight2:runAction(cc.Sequence:create(cc.Animate3D:createWithFrames(animation,8,24,30), cc.CallFunc:create(function()
            self._tvZXHLight2:stopAllActions()
            self._tvZXHLight2:setTexture(Tree.root .. "model/tiny_light_Pink1.png")

        end)))

    end)
    self._nodeTV:addChild(self._rollingClipping)
    --屏幕外的遮罩
    local sprite_mask = cc.Sprite:createWithSpriteFrameName("slwh_tv_screen_mask.png")
    sprite_mask:setAnchorPoint(0.5,0)
    sprite_mask:setPosition3D({x = 0,y = -35,z = 32})
    sprite_mask:setScale(0.16)
    sprite_mask:setCameraMask(Tree.CameraFlag)
    if sprite_mask.setDepthTest then
        sprite_mask:setDepthTest(true)
    end
    self._nodeTV:addChild(sprite_mask)

    self._nodeTV:setCameraMask(Tree.CameraFlag)
    self._actNode:addChild(self._nodeTV)
end
--加载模型动画
function SlwhBattleCcsView:loadAnimations()
    for idx = 1,Tree.ModelNumber do
        local model = self._animalModels[idx]
        local model_tag = model:getTag()
        local model_type = (model_tag -1) % 4 + 1
        local index_t = idx

        --model:stopAllActions()
        model:retain()
        model:removeFromParent()
        self._brickNode:addChild(model,model_type)
        model:release()
        --需要分帧加载,否则会很卡
        if self._animationActionActivity[index_t] then
            model:runAction(cc.RepeatForever:create(self._animationActionActivity[index_t]))
        else
            self.node_scene:runAction(cc.Sequence:create(cc.DelayTime:create(0.12 * index_t),
                                cc.CallFunc:create(function()
                                    self:loadOneActivityAnimate(model_tag)
                                    --在稍后的代码中,需要判断该模型是否被选中了,如果是,则不执行该代码,在现在的版本中暂时不做此处理
                                    model:runAction(cc.RepeatForever:create(self._animationActionActivity[index_t]))
                                end)))
        end
    end
end
--退出场景时清理模型
function SlwhBattleCcsView:clearAllModels()
    for idx = 1, Tree.ModelNumber do
        local animalModel = self._animalModels[idx]
        animalModel:stopAllActions()
        --恢复原来的动作/位置
        animalModel:setRotation3D({x =0, y = 180 - (idx - 1) * 360/Tree.ModelNumber,z = 0})
        local radius = 2 * math.pi * (idx - 1)/24
        animalModel:setPosition3D({ x = - math.sin(radius) * self._animalRadius,y= self._animalHeight,z = math.cos(radius) * self._animalRadius})
    end
end
--恢复模型的初始位置
function SlwhBattleCcsView:resumeModel()
    --self._lightNode:setRotation3D(Tree.ZeroPosition)
    self._brickNode:setRotation3D(Tree.ZeroPosition)
    self._stagePointerModel:setRotation3D(self._stagePointerRotation)
end

function SlwhBattleCcsView:notifyShowAllModelsChanged()
    self:isShowAllModels(true)
end

function SlwhBattleCcsView:onShow()

    TreeEventDispatcher:addEventListener(Tree.Event.loadScene,self.notifyLoadingScene,self)
    TreeEventDispatcher:addEventListener(Tree.Event.gameStart,self.notifySessionStart,self)
    TreeEventDispatcher:addEventListener(Tree.Event.gameOver,self.notifySessionOver,self)
    TreeEventDispatcher:addEventListener(Tree.Event.gameOverFromBack,self.notifySessionOverFromBack,self)
    TreeEventDispatcher:addEventListener(Tree.Event.gameStatusRefresh,self.notifySessionStatusChanged,self)
    TreeEventDispatcher:addEventListener(Tree.Event.enterBackghround,self.onEnterBackground,self)
    TreeEventDispatcher:addEventListener(Tree.Event.enterForeground,self.onEnterForeground,self)
    TreeEventDispatcher:addEventListener(Tree.Event.queryGameStatus,self.notifyQueryGameStatus,self)
    TreeEventDispatcher:addEventListener(Tree.Event.soundVolumChanged,self.notifyBackSoundVolumChanged,self)
    TreeEventDispatcher:addEventListener(Tree.Event.userScoreChanged,self.notifyUserScoreChanged,self)
    TreeEventDispatcher:addEventListener(Tree.Event.showAllModels,self.notifyShowAllModelsChanged,self)

    Hero.userScoreChangedSignal:add(self.notifyUserScoreChanged,self)
    Hero.pNickNameChangedSignal:add(self.notifyUserNameChanged,self)
    self.model.userTotalJettonChangedSignal:add(self.notifyUserSessionJetton,self)
    --self.model.allUserBetNumberChangedSignal:add(self.notifyUserSessionJetton,self)

    --self:notifyUserScoreChanged()
    self:notifyUserNameChanged()
    self:isShowAllModels(true)

    self.btnClose:setVisible(false)
    self.btnClose:setTouchEnabled(false)
    self.btnOpen:setVisible(true)
    self.btnOpen:setTouchEnabled(true)
    self.btnBet:setEnabled(false)

    if not cc.Jump3DBy then
        self._actionTickManager = tickMgr:delayedCall(handler(self,self.onActionSequence),1000/60,-1)
        self._actionManager:start()
    end

    self:loadAnimations()

    self._rollingClipping:setNumber(0)
    --Cocos2dx好尼玛奇怪,直接设置根节点坐标后,不能立即起作用,加上一个动作后就行了,费解
    if self.node_scene:getCameraMask() ~= Tree.CameraFlag then
        self.node_scene:runAction(cc.Sequence:create(cc.DelayTime:create(0),
                cc.CallFunc:create(function()
                    self.node_scene:setCameraMask(Tree.CameraFlag)
                end)))
    end
    local scene = cc.Director:getInstance():getRunningScene()
    scene:addChild(self._camera)
    --重置指针
    self._stagePointerModel = self._forestPartyMap[Tree.RewardType.RewardType_Normal].pointerModel
    self._stagePartyModel = self._forestPartyMap[Tree.RewardType.RewardType_Normal].partyModel
    self._stagePointerModel:setVisible(true)
    self._stagePartyModel:setVisible(true)
    self._stagePartyModel:runAction(self._stagePartyOriginAnimate)
    self._stagePointerModel:setRotation3D(self._stagePointerRotation)

    ---self:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.DelayTime:create(3), cc.CallFunc:create(function()

        --local vs = cc.Director:getInstance():getVisibleSize()
        -- self:ShowBossGoldEx(cc.p(1334 / 2, 750 / 2), 9999999)

    --end))))

    if( nil ~= self.model._layerTips and nil ~= self.layer_time ) then 
        self.layer_time:retain()
        self.layer_time:removeFromParent()
        self.model._layerTips:addChild( self.layer_time, 600 )
        -- self.layer_time:setZOrder()
        self.layer_time:release()
        self.layer_time:setVisible(true)
    end
    self._rollingClipping:setNumber(0)
    --self._shadowSkeleton:setScale(1.2)
    local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtv.c3b")
    local action = cc.Animate3D:createWithFrames(animation,8,24,30)
    self._tvZXH:runAction(action)

    local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtvlight1.c3b")
    local action = cc.Animate3D:createWithFrames(animation,8,24,30)
    self._tvZXHLight1:runAction(action)

    local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtvlight1.c3b")
    local action = cc.Animate3D:createWithFrames(animation,8,24,30)
    self._tvZXHLight2:runAction(action)

    self:clearBonusEffect()

    self.model._layerTips:setVisible(true)
    self._originBackSoundVolum = audioMgr:getMusicVolume()
    self.controller:setEnterScene(true)
    self._couldPlayerScoreModify = true
end
--监听背景音乐的音量
function SlwhBattleCcsView:notifyBackSoundVolumChanged(sound_volum)
    self._originBackSoundVolum = sound_volum
    --print("notifyBackSoundVolumChanged")
end

function SlwhBattleCcsView:onActionSequence(delta_time)
    self._actionManager:visit()
end

function SlwhBattleCcsView:onHide()
    if self.redPacket then
        self.redPacket:reset()
    end
    if self.activityNode then
        self.activityNode:reset()
    end
    --清理事件通知/接收
    self.model._layerTips:setVisible(false)
    TreeEventDispatcher:clearOneObjEvent(self)
    Hero.userScoreChangedSignal:remove(self.notifyUserScoreChanged,self)
    Hero.pNickNameChangedSignal:remove(self.notifyUserNameChanged,self)
    self.model.userTotalJettonChangedSignal:remove(self.notifyUserSessionJetton,self)
    --self.model.allUserBetNumberChangedSignal:remove(self.notifyUserSessionJetton,self)
    --销毁计时器
    if self._scheduleTimer then
        self._scheduleTimer:destroy()
        self._scheduleTimer = nil
    end
    if(self.layer_time)then 
        self.layer_time:setVisible(false)
    end
    --清理动作事件队列
    if not cc.Jump3DBy then
        self._actionManager:clear()
        self._actionTickManager:destroy()
    end

    --模型恢复原来的位置
    self:clearAllModels()
    self:resumeModel()

    if self._rewardCcsView then
        self._rewardCcsView:onExit()
    end

    if #self._animalSelectSet > 0 then
        local index_j = #self._animalSelectSet
        while index_j > 0 do
            local animal_model = self._animalSelectSet[index_j]
            self:showActivityAnimation(animal_model)
            self:restoreOriginGLProgramState(animal_model)

            table.remove(self._animalSelectSet)
            index_j = index_j - 1
        end
    end
    --删除舞台上的color影子
    for model_tag,color_wheel in pairs(self._stageColorWheels)do
        color_wheel:removeFromParent()
        self._stageColorWheels[model_tag] = nil
    end
    --动物模型即将恢复时,快速退出游戏会出现某一些比较特殊的bug
    if self._selectAnimalModel then
        self:restoreOriginGLProgramState(self._selectAnimalModel)
        self._selectAnimalModel = nil
    end

    local parent = self.model._layerTips
    local sprite_tip_panel = parent:getChildByName("sprite_tip_panel")
    if sprite_tip_panel then
        sprite_tip_panel:removeFromParent()
    end

    self._camera:setPosition3D(self._originEyePosition)
    self._camera:setRotation3D({x=Tree.SceneLocation.Camera.startAngle,y=0,z=0})

    if self._lampNode then
        self._lampNode:setVisible(false)
    end
    
    audioMgr:setMusicVolume(self._originBackSoundVolum,nil,nil,nil,true)
    --色块恢复原样
    for index = 1,Tree.ModelNumber do
        local light_model = self._lightModels[index]
        local color_type = light_model:getTag()
        if color_type ~= 0 then
            light_model:setTexture(Tree.BrickTexture[color_type][1])
            light_model:setTag(0)
        end
    end

    self.layer_jackpot.node_jackpot:stopAllActions()
    if self.multiModel then
        for k, v in pairs(self.multiModel) do 
            if( v ) then 
                if( v.model ) then 
                    v.model:stopAllActions()
                    v.model:setVisible(false)
                end
                if(v.spine) then 
                    v.spine:setVisible(false)
                end
            end
        end
    end
    self._isSceneRotated = false

    self._camera:removeFromParent()

    self._stagePartyModel:stopAllActions()
    self._stagePartyModel:setVisible(false)
    self._stagePointerModel:setVisible(false)
    self.layer_time.node_time:setTag(-1)


    if self.__tipsAnimation then
        TreeCacheManager:recycleCocos2dxObject(self.__tipsAnimation)
        self.__tipsAnimation = nil
    end

    if self.__waitTipsAnimation then
        self.__waitTipsAnimation:removeFromParent()
        self.__waitTipsAnimation = nil
    end

    if self._rewardEffectHandler ~= -1 then
        self.controller:stopGameEffect(self._rewardEffectHandler)
        self._rewardEffectHandler = -1
    end

    self:clearBonusEffect()
    self._sceneAnimationOrder = 0
    self._randomArrayMap = nil
    self.controller:setEnterScene(false)

    TreeCacheManager:onExit()
end
--切换到后台
function SlwhBattleCcsView:onEnterBackground()
    --记录当前剩余的时间,以及当前的状态
    self._currentStatus = self.model:getUserGameStatus()
    self._currentLeftTime = self.model:getRemindTime()
    self._currentSystemTime = socket.gettime()
end
--从后台进入到前台
function SlwhBattleCcsView:onEnterForeground()
    --判断返回来之后剩余的时间,以及状态
    --self:notifyTimer()
    local now_system_time = socket.gettime()
    -- self.model:setIsShowingJetton( self._currentStatus == Tree.Status.Play )
    if self._currentStatus == Tree.Status.Over then--如果是开奖阶段,则需要矫正场景动画的播放速度
        local past_time = now_system_time - self._currentSystemTime
        local time_remind = self._currentLeftTime - past_time
        if time_remind > 0 then--开奖阶段的时间还没有过去
            self._gameStageSpeed = self._gameStageSpeed * (self._currentLeftTime + 2)/time_remind
            --如果有相关的动作,则加速
            self:accelerateAnimation(self._gameStageSpeed)
            self._rollingClipping:setRollingSpeed(self._gameStageSpeed)
            --next,lua action
        end
    end
    self._currentStatus = nil
    self._currentLeftTime = nil
    --持续时间0.15s
    self._actNode:runAction(cc.Sequence:create(cc.DelayTime:create(0.15),
            cc.CallFunc:create(function()
                self.controller._isEnterForeground = false
                self.controller:requestQueryStatus()
            end)))
end
--加速动画
function SlwhBattleCcsView:accelerateAnimation(speed)
    local action_speed = self._brickNode:getActionByTag(Tree.TagNodeBrick)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    --
    local action_speed = self._stagePointerModel:getActionByTag(Tree.TagStagePointer)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    action_speed = self._stagePointerModel:getActionByTag(Tree.TagLightModelChanged)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    --
    local action_speed = self._actNode:getActionByTag(Tree.TagActNode)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    action_speed = self._actNode:getActionByTag(Tree.TagActNodeSound)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    --Camera
    action_speed = self._camera:getActionByTag(Tree.TagCamera)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    --Reward UI
    action_speed = self.node_scene:getActionByTag(Tree.TagNodeSceneReward)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    --scene action
    action_speed = self.node_scene:getActionByTag(Tree.TagLightColorChanged)
    if action_speed then
        action_speed:setSpeed(speed)
    end
    --animal model
    if #self._animalSelectSet > 0 then
        for index_j = 1,#self._animalSelectSet do
            local animal_model = self._animalSelectSet[index_j]
            local action = animal_model:getActionByTag(Tree.TagAnimalModel)
            if action then
                action:setSpeed(speed)
            end

            local model_tag = animal_model:getTag()
            action = animal_model:getActionByTag(Tree.TagJumpBase + model_tag)
            if action then
                action:setSpeed(speed)
            end
        end
         --------------------lua action--------------------
        if not cc.Jump3DBy then
            local lua_actions = self._actionManager:getTargetAction()
            if lua_actions and #lua_actions > 0 then
                for it_f = 1, #lua_actions do
                    local action = lua_actions[it_f]
                    if action:getType() == Tree.ActionType.ActionType_Speed then
                        action:setSpeed(speed)
                    end
                end
            end
        end
        ----------------------------------------------------------
    end
end
--查询游戏的状态
function SlwhBattleCcsView:notifyQueryGameStatus(bodyData)
    self.model:setRemindTime(bodyData.cbTimeLeave)
    self.model:setUserGameStatus(bodyData.cbStatus)
    self:updateLayerTime()
    self._lastTime = socket.gettime()
    self:notifyTimer(0)
end
--初始化场景中的色块,指针旋转的角度
--seed:随机化种子,
--此函数调用时机为场景协议中/断线重连.
function SlwhBattleCcsView:unifySceneColorPointerModel(seed,bodyData)
    TreeFunc.setRandomSeed(seed)
    ---获取当前的信息
    self._indexAnimalAbsolution = math.floor(TreeFunc.random() * 16) + 1
    --然后随机更改颜色,
    self._random_array = {}
    self._randomArrayMap = TreeFunc.shuffle3(self._random_array,self._indexAnimalAbsolution,24)
    self:changeColorModelDirect()
    --被选中的动物模型table
    local brick_rotate = -self._indexAnimalAbsolution * self._angleAverage
    self._brickNode:setRotation3D({x = 0,y = brick_rotate,z=0})
end
--客户端初始化
function SlwhBattleCcsView:notifyLoadingScene(bodyData)
    --显示列表,只显示前8个
    local table_reward = TreeFunc.trunk(bodyData.tAwardRecord,20)
    local index = #table_reward
    while index > 0 do
        if table_reward[index].cbType == Tree.RewardType.RewardType_None then
            table.remove(table_reward,index)
        end
        index = index - 1
    end
    self._couldPlayerScoreModify  = true
    self:notifyUserScoreChanged()
    TreeFunc.assignIndex(table_reward)
    self.layer_menu.lvNode.list_lv:setDatas(table_reward,true)
    --玩家已经下注总和
    self:notifyUserSessionJetton()
    --更新计时器
    if self._scheduleTimer then
        self._scheduleTimer:destroy()
    end
    self._lastTime = socket.gettime()
    self._sceneAnimationOrder = 0
    self:notifyTimer()
    self._scheduleTimer = tickMgr:delayedCall(handler(self,self.notifyTimer),100,-1)
    self:updateLayerTime()

    if not cc.Jump3DBy and self._actionManager then
        self._actionManager:clear()
    end
    --断线重连时矫正现场
    self:correctSceneOnStatus(bodyData.cbStatus,true)
    self:isShowAllModels(true)
    self.model:setIsShowingJetton(false)
    audioMgr:setMusicVolume(self._originBackSoundVolum,nil,nil,nil,true)
    self:unifySceneColorPointerModel(bodyData.nSeed,bodyData.tAward)
    self._randomArrayMap = nil
    --播放背景音乐
    if bodyData.cbStatus == Tree.Status.Wait or bodyData.cbStatus == Tree.Status.Play then
        self.controller:playMusic(Tree.Sound.battleWaitBg)
    else
        self.controller:playMusic(Tree.Sound.battleZhuanpan)
    end
    --彩金
    --self:notifyJackpotChanged(math.floor(10000 +  math.random() * (9999999 - 10000)))
    --self.layer_jackpot.node_jackpot:stopAllActions()
    --self:startJackpotRolling()
    self.layer_time.node_time:setTag(-1)
    --设置当前的中奖庄和闲信息
    --庄闲和动画
    local zxh_array = bodyData.tAward.nAwardIndex
    local zxh_type = 0 + zxh_array[14] + zxh_array[15] * 2
    if bodyData.cbStatus ~= Tree.Status.Over and #table_reward > 0 then--此时需要从历史纪录里面获取
        zxh_type = table_reward[1].cbZHX - 12
    end
    self._rollingClipping:setNumber(2 - zxh_type)

    if bodyData.cbStatus == Tree.Status.Over then

        if not self.__waitTipsAnimation then
            local parent = self.model._layerTips
            local node = cc.Sprite:create()
            node:setPosition(CONFIG_DESIGN_WIDTH * 0.5,CONFIG_DESIGN_HEIGHT * 0.5)
            node:setCascadeOpacityEnabled(true)
            parent:addChild(node)
    
            local jsonFile = "res/gameres/module/slwh/effect/slwh_xiazhutips.json"
            local atlasFile = "res/gameres/module/slwh/effect/slwh_xiazhutips.atlas"

            local skeleton_1 = sp.SkeletonAnimation:create(jsonFile,atlasFile)
            skeleton_1:setSkin("2")
            skeleton_1:setAnimation(0,"animation2",false)
            --skeleton_1:setPosition(cc.p(667, 375))
            node:addChild(skeleton_1, 1000)

            local jsonFile = "res/gameres/module/slwh/effect/slwh_pointtips.json"
            local atlasFile = "res/gameres/module/slwh/effect/slwh_pointtips.atlas"

            local skeleton_1 = sp.SkeletonAnimation:create(jsonFile,atlasFile)
            skeleton_1:setAnimation(0,"animation2",false)
            skeleton_1:addAnimation(0,"animation3",true)
            --skeleton_1:setPosition(667, 375)
            node:addChild(skeleton_1, 1000)
            
            self.__waitTipsAnimation = node
        end
    end
    self._gameStageOrder = -1
    --如果非安卓平台
    if not isAndroid and not self.controller:isWentToBank() and bodyData.cbStatus == Tree.Status.Play and self.model:getRemindTime() > 2 then
        self.model:setIsShowingJetton(true)
        self:isShowAllModels(false)
    end
    --如果需要去银行
    if self.controller:isWentToBank() then
        self.controller:doWentToBank()
    end
end

function SlwhBattleCcsView:isShowAllModels( b )
    if( false == SLWH_HIDE_MODELS_WHILE_JETTON ) then return end
    self.node_scene:setVisible(b)
    -- for k, v in pairs( self._animalModels or {} ) do 
    --     if( v ) then v:setVisible(b) end
    -- end
end
--更新彩金数字
function SlwhBattleCcsView:startJackpotRolling()
    local function update_jackpot()
        if self._shouldChangeJackpot then
            local num_j = 10000 +  math.random() * (9999999 - 10000)
            num_j = math.floor(num_j)
            self:notifyJackpotChanged(num_j)
        end
        self:startJackpotRolling()
    end
    self.layer_jackpot.node_jackpot:runAction(cc.Sequence:create(cc.DelayTime:create(2.0 + math.random()),cc.CallFunc:create(update_jackpot)))
end
--更新按钮
function SlwhBattleCcsView:updateLayerTime()
    local status = self.model:getUserGameStatus()
    --检测游戏的状态
    if status == Tree.Status.Wait then--等待下注状态,此时游戏空闲
        self.layer_time.font_time_start:setSpriteFrame("slwh_time_wait.png")
        self.btnBet:setEnabled(false)
    elseif status == Tree.Status.Play then--下注状态
        self.layer_time.font_time_start:setSpriteFrame("slwh_time_start.png")
        self.btnBet:setEnabled(true)
    elseif status == Tree.Status.Over then--开奖阶段
        self.layer_time.font_time_start:setSpriteFrame("slwh_time_over.png")
        self.btnBet:setEnabled(false)
    end
end
--更新定时器
function SlwhBattleCcsView:notifyTimer(dt)
    local now_time = socket.gettime()
    local delta_time = now_time - self._lastTime
    local remind_time = self.model:getRemindTime()
    if remind_time < 0 then remind_time = 0 end
    --当一个状态结束并进入到另一个状态时,函数将会触发一个回调函数
    local time_j = remind_time > delta_time and remind_time - delta_time or 0
    local time_v = math.floor(time_j)
    self._lastTime = now_time

    local tag = self.layer_time.node_time:getTag()
    if tag ~= time_v then

        --self.layer_time:removeChildByTag(9876)
        local timer_spine = self.layer_time:getChildByTag(9876)
        if timer_spine then
            TreeCacheManager:recycleCocos2dxObject(timer_spine)
        end

        TreeFunc.extractCacheWithNode(self.layer_time.node_time)
        TreeFunc.extractCacheWithNode(self.layer_time.node_time_zoomin)
        self.layer_time.node_time_zoomin:setVisible(false)
        local sprite_time = TreeFunc.createSpriteNumber(time_v,"time_number_%s",nil,{x=0.5,y=0.5},2,self.layer_time.node_time,true)
        if time_v <= 5 then 
            local skeleton = TreeCacheManager:getCacheObject("slwh_daojishi")
            skeleton:setPosition(102,37)
            skeleton:setAnimation(0,"animation",false)
            skeleton:setSkin(tostring(time_v))
            skeleton:runAction(cc.Sequence:create(cc.DelayTime:create(1),
                                                cc.CallFunc:create(function()
                                                    self.layer_time.node_time:setVisible(true)
                                                    TreeCacheManager:recycleCocos2dxObject(skeleton)
                                                end)))
            skeleton:setTag(9876)
            self.layer_time:addChild(skeleton)
            self.layer_time.node_time:setVisible(false)
        else
            self.layer_time.node_time:setVisible(true)
        end
        self.layer_time.node_time:setTag(time_v)
    end
    --remind_time = remind_time - 1
    self.model:setRemindTime(time_j)
    --判断是否应该弹出奖励界面
    if self.model:getUserGameStatus() == Tree.Status.Over and time_j < 3.15 and self._sceneAnimationOrder > 0 and self._sceneAnimationOrder < 7 then
        if not self._rewardCcsView then
            self._rewardCcsView = SlwhRewardCcsView.new(self.model)
            self._rewardCcsView:retain()
        end
        self:showRewardUI(self.model:getGameRewardData(),true,0.6)
    end
end
--更新本局下注
function SlwhBattleCcsView:notifyUserSessionJetton()
    local total_jetton = self.model:getUserTotalJetton()--self.model:getUserTotalJetton()
    local sw_width = 0
    if not self._optimal then
        --需要使用缓存对象
        local dimension = {}
        TreeFunc.extractCacheWithNode(self.layer_bet.node_allbets)
        TreeFunc.createSpriteNumberWithDot(total_jetton,"battle_money_n_%s",dimension,nil,self.layer_bet.node_allbets,true)
        sw_width = dimension.width
    else
        self.layer_bet.node_allbets:setString(TreeFunc.formatNumberDot(total_jetton))
        sw_width = self.layer_bet.node_allbets:getContentSize().width
    end
    self.layer_bet.bg:setContentSize(cc.size(150 + sw_width,50))
end
--更新彩金数目
function SlwhBattleCcsView:notifyJackpotChanged(jackpot_score)
    --回收节点上的sprite
    TreeFunc.extractCacheWithNode(self.layer_jackpot.node_jackpot)
    TreeFunc.createSpriteNumberWithDot(jackpot_score,"jetton_money_n_%s",nil,{x=0.5,y=0.5},self.layer_jackpot.node_jackpot,true)
end
--玩家的金钱发生变化
function SlwhBattleCcsView:notifyUserScoreChanged()
    if self._couldPlayerScoreModify  then
        local user_score = Hero:getUserScore()
        if user_score >= 10000 then
            user_score = user_score + 0.5
        end
        local scoreTxt = HtmlUtil.createArtNumWithHansUnits(user_score,"#slwh_battle_money%s.png", nil, nil, nil, nil, nil, nil, nil, 0, nil)
        self.layer_money:setStrTxt(scoreTxt)

        local base_x = self.layer_hero:getPositionX() + self.layer_hero.txt_name:getPositionX() + self.layer_hero.txt_name:getContentSize().width
        local bg_width= self.layer_money.bg:getContentSize().width
        local offset_x = base_x + 32 + bg_width * 0.5
        self.layer_money:setPositionX(offset_x)
        self.layer_bet:setPositionX(offset_x + bg_width * 0.5 + 24)
    end

    self.controller:setHeadBg(self.layer_hero.head, GAME_STATE.ROOM)
    if not  B_HEADCLIPPING then
    	self.layer_hero.head:checkMask2(self.layer_hero.head.mask)
    else
    	self.layer_hero.head.mask.mask:setVisible(false)
	end
end
--玩家的名字
function SlwhBattleCcsView:notifyUserNameChanged()
    local name = Hero:getPNickName()
    name = StringUtil.truncate(name, 9, nil, 2)
	self.layer_hero.txt_name:setString(name)
    local name_dimension = self.layer_hero.txt_name:getVirtualRendererSize()
    self.layer_hero.image_hero_panel:setContentSize(cc.size(name_dimension.width + 64,50))
    --增加玩家总分数/已经下注分数面板组建自适应功能
    local base_x = self.layer_hero:getPositionX() + self.layer_hero.txt_name:getPositionX() + self.layer_hero.txt_name:getContentSize().width
    --self.layer_money面板比较特殊,其中心点在中间,因此计算要稍微复杂一点
    local bg_width= self.layer_money.bg:getContentSize().width
    local offset_x = base_x + 32 + bg_width * 0.5
    self.layer_money:setPositionX(offset_x)
    self.layer_bet:setPositionX(offset_x + bg_width * 0.5 + 24)
end
--本局游戏开始
function SlwhBattleCcsView:notifySessionStart(bodyData)
    --rint("SlwhBattleCcsView:notifySessionStart")
    --self.model:setRemindTime(bodyData.cbTimeLeave)
    --主动弹出押注面板,并播放相关的音效
    self.model:setIsShowingJetton(true)
    self:isShowAllModels(false)
    --self.node_scene:runAction(cc.Sequence:create(cc.DelayTime:create(0.6),cc.CallFunc:create(c_func(self.playStartAnimation,self))))
    self:playStartAnimation()
    self.controller:playGameEffect(Tree.Sound.XiaZhuMianBanEffect)
    --检测是否初始化了色块
    if not self._randomArrayMap then
        self:changeColorModelWithoutAction(bodyData.nSeed)
    elseif self._actionColorChanged then
        self.node_scene:stopActionByTag(Tree.TagColorSequenceChanged)
        self:changeColorModelDirect()
    end
end
--提示,现在开始
function SlwhBattleCcsView:playStartAnimation()
    if self.__tipsAnimation then
        TreeCacheManager:recycleCocos2dxObject(self.__tipsAnimation)
    end

    local parent = self.model._layerTips
    local skeleton_1 = TreeCacheManager:getCacheObject("slwh_xiazhutips")
    skeleton_1:setSkin("1")
    skeleton_1:setAnimation(0,"animation",false)
    skeleton_1:runAction(cc.Sequence:create(cc.DelayTime:create(1.5), cc.CallFunc:create(function()
        TreeCacheManager:recycleCocos2dxObject(self.__tipsAnimation)
        self.__tipsAnimation = nil
    end)))

    skeleton_1:setPosition(cc.p(667, 375))
    parent:addChild(skeleton_1, 1000)

    self.__tipsAnimation = skeleton_1
end
--更换指针/舞台模型
function SlwhBattleCcsView:changePartyModel(reward_type)
    self:loadPartyStage(reward_type)
    --送灯/大三元/大四喜/闪电比较特殊
    local secondary_type = reward_type
    if reward_type == Tree.RewardType.RewardType_DaSanYuan or reward_type == Tree.RewardType.RewardType_DaSiXi or reward_type == Tree.RewardType.RewardType_SongDeng or reward_type == Tree.RewardType.RewardType_ShanDian then
        secondary_type = Tree.RewardType.RewardType_Normal
    end

    local party_map = self._forestPartyMap[secondary_type]
    if party_map.pointerModel ~= self._stagePointerModel then
        local r3d = self._stagePointerModel:getRotation3D()
        self._stagePointerModel:setVisible(false)
        self._stagePartyModel:setVisible(false)

        self._stagePointerModel = party_map.pointerModel
        self._stagePointerModel:setRotation3D(r3d)
        self._stagePartyModel = party_map.partyModel

        self._stagePointerModel:setVisible(true)
        self._stagePartyModel:setVisible(true)
    end
    self._stagePointerModel.reward_type = reward_type
    --送灯,大三元,大四喜,彩金需要播放另一种动画
    if reward_type == Tree.RewardType.RewardType_SongDeng or reward_type == Tree.RewardType.RewardType_DaSanYuan or reward_type == Tree.RewardType.RewardType_DaSiXi or reward_type == Tree.RewardType.RewardType_CaiJin then
        local animation_up = self:loadPartyAnimation(secondary_type,Tree.PartyAnimationType.AnimationType_Up)
        local animation_normal = self:loadPartyAnimation(secondary_type,Tree.PartyAnimationType.AnimationType_Normal)
        local sequence_action = cc.Sequence:create(animation_up,cc.Repeat:create(animation_normal,12000))

        self._stagePartyModel:runAction(sequence_action)
    end
end
--播放庄和闲声音
function SlwhBattleCcsView:playSoudEffectZXH(rolling_object,effect_y)
    self.controller:playGameEffect(Tree.Sound.ZXHEffect[Tree.CardType.CardType_Zhuang + 2 - effect_y])
end
--游戏开奖阶段
function SlwhBattleCcsView:notifySessionOver(bodyData)
    if self.__tipsAnimation then
        TreeCacheManager:recycleCocos2dxObject(self.__tipsAnimation)
        self.__tipsAnimation = nil
    end
    self._gameStageSpeed = 1--该数值
    local parent = self.model._layerTips
    local skeleton_1 = TreeCacheManager:getCacheObject("slwh_xiazhutips")
    skeleton_1:setSkin("3")
    skeleton_1:setAnimation(0,"animation",false)
    local game_continue_action =cc.Sequence:create(cc.DelayTime:create(1.5),
                                            cc.CallFunc:create(function()
                                                TreeCacheManager:recycleCocos2dxObject(self.__tipsAnimation)
                                                self.__tipsAnimation = nil
                                                self:notifySessionOver_Continue(bodyData)
                                            end))
    game_continue_action:setTag(Tree.TagGameOverStart)
    skeleton_1:runAction(game_continue_action)
    
    skeleton_1:setPosition(cc.p(667, 375))
    parent:addChild(skeleton_1, 1000)
    self.__tipsAnimation = skeleton_1
    self._sceneAnimationOrder = 0
end
--另一种方式衔接开奖动画
function SlwhBattleCcsView:notifySessionOverFromBack(bodyData)
    --计算游戏的加速比
    local reward_type = bodyData.tAward.nType
    local total_time = Tree.RewardTime[reward_type]
    if reward_type == Tree.RewardType.RewardType_SongDeng then
        local animal_count = 0
        local animalIndex = bodyData.tAward.nAwardIndex
        for index_j = 1,12 do
            if animalIndex[index_j] > 0 then
                animal_count =  animal_count + 1
            end
        end
        total_time = total_time + Tree.RewardSongDengTime * animal_count
    end
    --加速比计算
    self._gameStageSpeed = total_time/(bodyData.cbTimeLeave - 2)
    --print("accelerate->",self._gameStageSpeed)
    self:notifySessionOver_Continue(bodyData)
end
--计算当前的转盘偏移量
function SlwhBattleCcsView:computeRotateSceneOffset()
    --local  rotate_cy1 = self._brickNode:getRotation3D()
    --local y_1 = rotate_cy1.y - math.floor(rotate_cy1.y/360) * 360
   -- local index_offset = math.floor(y_1/self._angleAverage + 0.5) --计算镜像位置
    --index_offset = (24 - index_offset) % 24 + 1
    --需要计算当前的绝对位置,保证每一局在开始之后不同的玩家看到的结果都相同
    local index_inc = math.floor(TreeFunc.random() * 16) + 1
    --local index_start = (index_offset + index_inc - 1) % 24 + 1

    return index_inc
end
function SlwhBattleCcsView:checkRandomColorMap(random_array,color_map,animal_start)
    local other_random_array = {}
    for color_type = 1, 3 do
        local color_animal_array = color_map[color_type]
        for animal_type = 1,4 do
            local animal_array = color_animal_array[animal_type]
            for index_j,animal_index in pairs(animal_array)do
                local color_index = animal_index + animal_start - 1
                color_index = (color_index - 1) % 24 + 1
                --color_index = color_index - math.floor(color_index/24) * 24 + 1
                other_random_array[color_index] = color_type
            end
        end
    end
    --compare
    for index_j = 1,#random_array do
        local color_type = other_random_array[index_j]
        if color_type ~= random_array[index_j] then
            assert(new_index == random_array[index_j],"invalid color map .")
            print("rrrri")
        end
    end
end
--色块变化,从开奖流程中摘录出来
function SlwhBattleCcsView:changeColorModel(seed)
    TreeFunc.setRandomSeed(seed)
    --色块先变为黑色
    local table_action = {}
    for idx = 1,Tree.ModelNumber do
        local light_model = self._lightModels[idx]
        light_model:stopAllActions()
        light_model._textureIndex = 0
        local function delay_call1()
            light_model:setTexture(Tree.BrickBlackTexture)
            light_model:setTag(0)
        end
        if idx > 1 then
            table.insert(table_action,cc.DelayTime:create(1/24))
        end
        table.insert(table_action,cc.CallFunc:create(delay_call1))
    end
    self._indexAnimalAbsolution = self:computeRotateSceneOffset()
    --然后随机更改颜色,
    self._random_array = {}
    self._randomArrayMap = TreeFunc.shuffle3(self._random_array,self._indexAnimalAbsolution,24)
    --self:checkRandomColorMap(self._random_array,self._randomArrayMap,self._indexAnimalAbsolution)
    --动作的开始
    self._actionColorChanged = true
    for idx = 1,Tree.ModelNumber do
        local random_idx = self._random_array[idx]
        local light_model = self._lightModels[idx]

        local function delay_call1()
            light_model:setTexture(Tree.BrickTexture[random_idx][1])
            light_model:setTag(random_idx)
        end

        table.insert(table_action,cc.DelayTime:create(1/24))
        table.insert(table_action,cc.CallFunc:create(delay_call1))
    end
    table.insert(table_action,cc.CallFunc:create(function()
        self._actionColorChanged = nil
    end))
    local sequence_action = cc.Sequence:create(table_action)
    sequence_action:setTag(Tree.TagColorSequenceChanged)
    self.node_scene:runAction(sequence_action)
end
--改变色块
function SlwhBattleCcsView:changeColorModelWithoutAction(seed)
    TreeFunc.setRandomSeed(seed)
    ---获取当前的信息
    self._indexAnimalAbsolution = self:computeRotateSceneOffset()
    --然后随机更改颜色,
    self._random_array = {}
    self._randomArrayMap = TreeFunc.shuffle3(self._random_array,self._indexAnimalAbsolution,24)
    --self:checkRandomColorMap(self._random_array,self._randomArrayMap,self._indexAnimalAbsolution)

    self:changeColorModelDirect()
end
--
function SlwhBattleCcsView:changeColorModelDirect()
    for idx = 1,Tree.ModelNumber do
        local random_idx = self._random_array[idx]
        local light_model = self._lightModels[idx]

        light_model:setTexture(Tree.BrickTexture[random_idx][1])
        light_model:setTag(random_idx)
    end
end
--本局游戏结束
function SlwhBattleCcsView:notifySessionOver_Continue(bodyData)
    --print("notifySessionOver--->")
    self._sceneAnimationOrder = 1--首阶段
    --self.model:setRemindTime(bodyData.cbTimeLeave)
    --如果场景正处于旋转状态中,表明上次的旋转还没有进行完毕
    local reward_type = bodyData.tAward.nType
    if( reward_type == Tree.RewardType.RewardType_CaiJin ) then 
        self:showMultiEffect(Tree.ModelType.ModelType_Caijin)
    elseif( reward_type == Tree.RewardType.RewardType_ShanDian ) then 
        if( 2 == bodyData.tAward.nTimes ) then 
            self:showMultiEffect(Tree.ModelType.ModelType_Multi2)
        elseif( 3 == bodyData.tAward.nTimes ) then 
            self:showMultiEffect(Tree.ModelType.ModelType_Multi3)
        end
        --播放闪电音效
        self.controller:playGameEffect(Tree.Sound.ShanDianEffect)
    elseif ( reward_type == Tree.RewardType.RewardType_SongDeng ) then
        self:showMultiEffect(Tree.ModelType.ModelType_SongDeng)
    elseif ( reward_type == Tree.RewardType.RewardType_DaSanYuan ) then
        self:showMultiEffect(Tree.ModelType.ModelType_DaSanYuan)
    elseif ( reward_type == Tree.RewardType.RewardType_DaSiXi ) then
        self:showMultiEffect(Tree.ModelType.ModelType_DaSiXi)
    end
    --如果是特殊玩法,则需要播放相关的音效
    if reward_type ~= Tree.RewardType.RewardType_Normal then
        self.controller:playGameEffect(Tree.Sound.SpecialRewardEffect[reward_type])
    end
    --如果有彩金,则屏蔽更新彩金,该阶段不会出现彩金的更改
    if reward_type == Tree.RewardType.RewardType_CaiJin then
        --self:notifyJackpotChanged(bodyData.lCaijin)
        self._shouldChangeJackpot = false
    end
    --判断是否色块已经初始化完毕
    if not self._randomArrayMap then--还没有初始化,需要初始化一次
        self:changeColorModelWithoutAction(bodyData.nSeed)
    elseif self._actionColorChanged then
        self.node_scene:stopActionByTag(Tree.TagColorSequenceChanged)
        self:changeColorModelDirect()
    end

    local body_data_map = bodyData
    body_data_map.indexOffset = self._indexAnimalOffset
    --按此增量进行色块颜色的计算,index_start指代第一个动物模型偏离原位置的单位
    local table_animal = TreeFunc.checkAllIndex(bodyData.tAward.nAwardIndex,1,12)
    --打印输出索引
    --记录场景正在旋转中
    self._isSceneRotated = true

    self:notifyUserSessionJetton()
    --展示获奖UI
    if not self._rewardCcsView then
        self._rewardCcsView = SlwhRewardCcsView.new(self.model)
        self._rewardCcsView:retain()
    end
    --加载相关的舞台与指针,并进行交换,如果需要的话
    self:changePartyModel(reward_type)
    --如果是送灯,则需要创建相关的模型
    if reward_type == Tree.RewardType.RewardType_SongDeng then
        self._lampCountNum = #table_animal
        self:newSongDengTV(bodyData)
    end
    --将选中的动物模型存放到表中
    local other_animal_table = {}
    TreeFunc.shuffle(table_animal,12)
    for index = 1,#table_animal do
        local animal_type = table_animal[index]
        local color_type = math.ceil(animal_type/4)
        local model_type = (animal_type - 1) % 4 + 1--模型的类型
        local random_index = table.remove(self._randomArrayMap[color_type][model_type],1)

        if self._debug then
            print("animal_type",animal_type,"model_type:",model_type,"color_type",color_type)
        end
        assert(random_index ~= nil,"self._randomArrayMap could not contain nil.")
        if not random_index then
            --dump(table_animal,"table_animal")
            print("--------------------------------")
            --dump(self._randomArrayMap,"self._randomArrayMap")
        end
        self._animalModels[random_index].color_type = color_type

        table.insert(self._animalSelectSet,self._animalModels[random_index])
        table.insert(other_animal_table,random_index)
    end
    local target_index = table.remove(other_animal_table,1)
    assert(target_index,"notifySessionOver_Continue error,target_index")

    local body_map = bodyData
    body_map.loops = 0

    self:afterShowBrickAnimation(target_index,other_animal_table,bodyData)

    --庄闲和动画
    local zxh_array = bodyData.tAward.nAwardIndex
    local zxh_type = 0 + zxh_array[14] + zxh_array[15] * 2
    local time_interval = 0.12
    if reward_type == Tree.RewardType.RewardType_DaSanYuan or reward_type == Tree.RewardType.RewardType_DaSiXi or reward_type == Tree.RewardType.RewardType_SongDeng then
        time_interval = 0.052
    end
    self._rollingClipping:setTimeInterval(time_interval)
    self._rollingClipping:addNumber(2 - zxh_type,3)

    local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtv.c3b")
    self._tvZXH:runAction(cc.RepeatForever:create(cc.Animate3D:createWithFrames(animation,0,6,30)))

    self.__switch1 = false
    self.__switch2 = false

    self._tvZXHLight1:setVisible(true)
    self._tvZXHLight1:stopAllActions()
    local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtvlight1.c3b")

    local action = cc.RepeatForever:create(cc.Animate3D:createWithFrames(animation,0,6,30))
    action:setTag(9987)

    self._tvZXHLight1:runAction(action)
    self._tvZXHLight1:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.DelayTime:create(0.066), cc.CallFunc:create(function()

        self.__switch1 = not self.__switch1

        local texture = self.__switch1 and textures[1] or textures[2]

        self._tvZXHLight1:setTexture(texture)

    end))))

    self._tvZXHLight2:setVisible(true)
    self._tvZXHLight2:stopAllActions()
    local animation = cc.Animation3D:create(Tree.root .. "model/slwh_zxhtvlight2.c3b")

    local action = cc.RepeatForever:create(cc.Animate3D:createWithFrames(animation,0,6,30))
    action:setTag(9987)

    self._tvZXHLight2:runAction(action)
    self._tvZXHLight2:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.DelayTime:create(0.066), cc.CallFunc:create(function()

        self.__switch2 = not self.__switch2

        local texture = self.__switch2 and textures[2] or textures[1]

        self._tvZXHLight2:setTexture(texture)

    end))))
    --屏蔽掉背景音乐
    audioMgr:setMusicVolume(0,nil,nil,nil,true)

    --如果是 大三元/大四喜/送灯/则摄像机将会有一个中间动作
    if reward_type == Tree.RewardType.RewardType_DaSanYuan or reward_type == Tree.RewardType.RewardType_DaSiXi or reward_type == Tree.RewardType.RewardType_SongDeng then
        self._camera:runAction(cc.Spawn:create(cc.EaseSineInOut:create(cc.RotateTo:create(2,Tree.SceneLocation.CameraBetween.middleAngle)),cc.EaseSineInOut:create(cc.MoveTo:create(2,Tree.SceneLocation.CameraBetween.middlePosition))))
    end
    self._randomArrayMap = nil
end
--创建送灯奖励场景中心的TV
function SlwhBattleCcsView:newSongDengTV(bodyData)
    if not self._lampNode then
        self._lampNode = cc.Node:create()
        self._lampNode:setPosition3D({x=0,y=-18,z=0})
        self._lampNode:setCameraMask(Tree.CameraFlag)
        self._actNode:addChild(self._lampNode)

        self._tvModel = cc.Sprite3D:create(Tree.root .. "model/songdeng/slwh_daojishitv.c3b")
        self._tvModel:setRotation3D(Tree.ZeroPosition)
        self._tvModel:setCameraMask(Tree.CameraFlag)
        self._lampNode:addChild(self._tvModel)
        --电视机前方的屏幕
        local rolling_map = {
            timeInterval = 0.15,--滚动一个单元格的时间间隔
            unitNumber = 13,--图片上有多少个单元
            tagAction = Tree.TagSongDengTV,--动作的名称
            alphaThreshold = 0.1,--裁剪的alpha临界值
            depthTest = true, --是否开启深度测试
            cameraMask = Tree.CameraFlag,
            rollingScale = 0.5,--滚动纹理的缩放尺寸
            maskTexturePath = Tree.root .. "battle/tv_mask.png",--遮罩的路径
            rollingTexturePath = Tree.root .. "model/songdeng/tv_sequence.png",--滚动纹理的路径
        }
        local rolling_class = requireLuaFromModule("slwh.view.ccs.SlwhClippingRolling")
        self._rollingSongDeng = rolling_class.new(rolling_map)
        self._rollingSongDeng:setPosition3D({x=-5,y = 13,z = 28})
        self._lampNode:addChild(self._rollingSongDeng)
        --送灯屏幕上的遮罩
        local sprite_mask = cc.Sprite:createWithSpriteFrameName("slwh_sdtvtext.png")
        sprite_mask:setAnchorPoint(0.5,0)
        sprite_mask:setPosition3D({x=-5,y = 10,z = 28})
        sprite_mask:setScale(0.20)
        sprite_mask:setCameraMask(Tree.CameraFlag)
        if sprite_mask.setDepthTest then
            sprite_mask:setDepthTest(true)
        end
        self._lampNode:addChild(sprite_mask)

        local animation = cc.Animation3D:create(Tree.root .. "model/songdeng/slwh_daojishitv.c3b")
        self._tvModelAnimation = cc.Animate3D:createWithFrames(animation,0,30,30)
        self._tvModelAnimation:setQuality(cc.Animate3DQuality.QUALITY_LOW)
        self._tvModelAnimation:retain()
    end
    self._rollingSongDeng:setVisible(false)
    self._rollingSongDeng:setTimeInterval(0.15)
    --加载送灯TV入场动画
    self._tvModel:runAction(cc.Sequence:create(self._tvModelAnimation,
                                                cc.CallFunc:create(function()
                                                    self._rollingSongDeng:setVisible(true)
                                                    self._rollingSongDeng:startWithSequence(self._lampCountNum,0)
                                                    self._rollingSongDeng:setTimeInterval(0.35)
                                                end)))
    self._lampNode:setVisible(true)
end
--这里处理各种不同类型的显示动画
--普通类型的动画显示方式与其他的有着很大的区别
--因此在动画的中间处理过程中,需要特别的区分
function SlwhBattleCcsView:afterShowBrickAnimation(target_index,table_animal,bodyData)
    --self._rewardCcsView:showRewardType(bodyData)
    --print("afterShowBrickAnimation")
    assert(target_index,"after brick target_index")
    assert(table_animal,"after brick table_animal")
    assert(bodyData and bodyData.tAward,"after brick bodyData bodyData.tAward")
    --不同类的转动角度不同,并且转动持续时间也不同
    local target_time = 5
    local rotate_ay = 4 * 360
    local rotate_by = 3 * 360
    --print("remove target index->",target_index)
    local body_map = bodyData
    local reward_type = bodyData.tAward.nType
    if reward_type ~= Tree.RewardType.RewardType_Normal and reward_type ~= Tree.RewardType.RewardType_ShanDian and reward_type ~= Tree.RewardType.RewardType_CaiJin then
        target_time = 3
        rotate_ay = 3 * 360
        rotate_by = 2 * 360
        if reward_type ==Tree.RewardType.RewardType_SongDeng then
            --target_time = 2.5
        end
    end
    body_map.rotate_time = target_time
    self:showNormalAnimation(target_index,target_time,rotate_ay,rotate_by,table_animal,bodyData)
    --停止播放当前的背景音乐
    --加载音效
    self._rotateEffectHandler = self.controller:playGameEffect(Tree.Sound.RotateSceneEffect,false,true)
    self._sceneAnimationOrder = 2
end
--回收动物模型获奖运动轨迹的Spine动画
function SlwhBattleCcsView:recycleAnimalMotionTrack()
    local animal_j = 4
    while animal_j > 0 do
        local index_j = 3
        local animal_key = string.format("slwh_animal_%d",animal_j)
        local spine_animate = self.node_scene:getChildByName(animal_key)

        while index_j > 0 and spine_animate do
            TreeCacheManager:recycleCocos2dxObject(spine_animate)

            spine_animate = self.node_scene:getChildByName(animal_key)
            index_j = index_j - 1
        end
        animal_j = animal_j - 1
    end
end
--展示获奖动画
--illegal_over:是否是非正常结束
function SlwhBattleCcsView:showRewardUI(bodyData,illegal_over,time_scale)
    --回收资源
    local dance_skeleton = self.node_scene:getChildByName("slwh_dancing")
    if dance_skeleton then
        dance_skeleton:runAction(cc.Sequence:create(cc.FadeOut:create(0.25),
        cc.CallFunc:create(function()
            TreeCacheManager:recycleCocos2dxObject(dance_skeleton)
        end)))
    end
    local stage_skeleton = self.node_scene:getChildByName("slwh_stagegs")
    if stage_skeleton then
        stage_skeleton:runAction(cc.Sequence:create(cc.FadeOut:create(0.25),
        cc.CallFunc:create(function()
            TreeCacheManager:recycleCocos2dxObject(stage_skeleton)
        end)))
    end
    --print("reward_type->",bodyData.tAward.nType)
    self._couldPlayerScoreModify  = true
    if self._sceneAnimationOrder >= 7 then
        --self._isSceneRotated = false--表示整个场景已经运作完毕
        return
    end
    self._sceneAnimationOrder = 7
    --显示获奖记录
    local histroy_reward = bodyData.tAwardRecord--self.model:getHistoryRewards()
    local table_reward = TreeFunc.trunk(histroy_reward,20)
    --对上面的记录进行筛选
    local index = #table_reward
    while index > 0 do
        if table_reward[index].cbType == Tree.RewardType.RewardType_None then
            table.remove(table_reward,index)
        end
        index = index - 1
    end
    TreeFunc.assignIndex(table_reward)
    self.layer_menu.lvNode.list_lv:setDatas(table_reward,true)
    self._rewardCcsView:onExit()
    local word_location = self.layer_money:convertToWorldSpace(cc.p(0,0))
    self._rewardCcsView:setEffectTargetLocation(word_location.x,word_location.y)
    --如果当前不是等待奖励阶段,则不需要再弹出奖励界面
    if self.model:getUserGameStatus() == Tree.Status.Over then
        self.model._layerTips:addChild(self._rewardCcsView,10000)
        self._rewardCcsView:showRewardType(bodyData,time_scale)
    end
    if not illegal_over then
        self._isSceneRotated = false
    end
end

function SlwhBattleCcsView:stopResultSound()
    if self._rotateEffectHandler ~= -1 then
        self.controller:stopGameEffect(self._rotateEffectHandler)
        self._rotateEffectHandler = -1
    end
end
--展示普通获奖动画
function SlwhBattleCcsView:showNormalAnimation(target_index,target_time,rotate_ay,rotate_by,table_animal,bodyData)
    --print("showNormalAnimation")
    assert(target_index,"target_index should not be nil")
    assert(target_time,"target_time should not be nil")
    assert(rotate_ay,"rotate_ay should not be nil")
    assert(rotate_by,"rotate_by should not be nil.")
    assert(table_animal,"showNormalA table_animal")
    assert(bodyData,"showNormalAnimation bodyData.")
    --首先动物与砖块保持整体的旋转,并且指向目标动物
    --需要叠加上的旋转角度
    local  rotate_cy1 = self._brickNode:getRotation3D()
    local  rotate_cy2 = self._stagePointerModel:getRotation3D()
    local average_angle = 360/Tree.ModelNumber
    --计算转盘自身的偏离索引,原本应该指向索引1,现在位置1出指向的动物需要重新计算
    local y_1 = rotate_cy1.y - math.floor(rotate_cy1.y/360) * 360
    local index_offset = math.floor(y_1/average_angle + 0.5) + 1 --计算镜像位置
    local mirror_index = (Tree.ModelNumber - (index_offset - 1))%Tree.ModelNumber + 1
    --print("index_offset",index_offset)
    --计算当前指针指向的动物模型
    local y = rotate_cy2.y - math.floor(rotate_cy2.y/360) * 360  --计算旋转角度的自然角度
    local index_animal = (Tree.ModelNumber -  math.floor(y/average_angle + 0.5)) % Tree.ModelNumber + 1 --因为动物是顺时针排列的缘故
    local light_indexf = index_animal--记录下色块的索引
    --print("index_animal_1->",index_animal)
    index_animal = (index_animal + index_offset - 1) % Tree.ModelNumber
    --计算目标动物的索引
    local select_index = bodyData.loops + 1
    assert(select_index > 0 and select_index <= #self._animalSelectSet,"wawawa in valide index.")
    local model = self._animalSelectSet[bodyData.loops + 1]
    assert(model,string.format("find animal model error,in valide index %d",select_index))
    --print("target_index",target_index, math.ceil(((target_index - 1)%12 + 1)/4), (target_index - 1)%4 + 1)
    --计算角度差,按照右手法则顺时针为负计算,计算出的角度为顺时针差值
    local angle_interpolation = (target_index - index_animal) * average_angle
    angle_interpolation = angle_interpolation - math.floor(angle_interpolation/360) * 360
    --外侧转盘随机旋转的额外角度,此随机过程具有一定的约束性,如果不是普通模式上次停留的位置这次不可以重复
    local interpolation = self._indexAnimalAbsolution - mirror_index
    interpolation = interpolation - math.floor(interpolation/24) * 24
    local other_angle = interpolation * average_angle --bodyData.indexOffset * average_angle
    --开始就高速旋转,后来逐渐减速
    --如果被選中的動物只有一個,那麽只旋轉一次
    if bodyData.loops < 1 then--EaseExponentialInOut
        local speed_action = cc.Speed:create(cc.EaseSineOut:create(cc.RotateBy:create(target_time + 2,{x=0,y=-rotate_ay - other_angle,z=0})),self._gameStageSpeed)
        speed_action:setTag(Tree.TagNodeBrick)
        self._brickNode:runAction(speed_action)
    else
        other_angle = 0--此時動物不再旋轉,因此增量為0
        --此时需要卡旋转时的音效时间
        local seq_action = cc.Sequence:create(cc.DelayTime:create(bodyData.rotate_time - 1),
                                        cc.CallFunc:create(function()
                                            self:stopResultSound()
                                            self._rotateStopEffectHandler = self.controller:playGameEffect(Tree.Sound.RotateSceneOverEffect)
                                        end))
        local speed_action = cc.Speed:create(seq_action,self._gameStageSpeed)
        speed_action:setTag(Tree.TagActNode)
        self._actNode:runAction(speed_action)
    end
    local rotatation = {x = 0,y = rotate_by - angle_interpolation + 360 - other_angle,z=0}
    local seq_action = cc.Sequence:create(cc.EaseSineOut:create(cc.RotateBy:create(target_time - 1.5,rotatation)),cc.CallFunc:create(c_func(self.blinkLightModel,self,model)),cc.DelayTime:create(1.5 + (bodyData.loops < 1 and 2 or 0)),cc.CallFunc:create(c_func(self.showJumpAnimation_Before,self,model,table_animal,bodyData)))
    local action_speed = cc.Speed:create(seq_action,self._gameStageSpeed)
    action_speed:setTag(Tree.TagStagePointer)
    self._stagePointerModel:runAction(action_speed)
    --计算动物模型对应的色块,送灯时需要用到,现在修改为每一种奖励都需要
    local y_r = rotate_cy1.y - (model:getTag() - 1) * self._angleAverage - other_angle - rotate_ay
    local mod_f = y_r - math.floor(y_r/360) * 360
    local light_index = math.floor(mod_f/self._angleAverage + 0.5) + 1
    --镜像
    light_index = (Tree.ModelNumber - (light_index - 1)) % Tree.ModelNumber + 1
    model.light_model = self._lightModels[light_index]
    
    local body_map = bodyData
    body_map.loops = body_map.loops + 1
    --计算扫过的色块,当前指针指向的色块的索引为 light_index
    local repeat_count = math.floor(0.5 + math.abs(rotatation.y)/self._angleAverage)
    local frame_time = 0--1/cc.Director:getInstance():getFrameRate()
    self._lightIndex = light_indexf
    local accelerate_action = cc.Speed:create(cc.EaseSineOut:create(cc.Repeat:create(
                            cc.Sequence:create(
                            cc.CallFunc:create(function()
                                local light_model = self._lightModels[self._lightIndex]
                                local texture_index = light_model:getTag()
                                light_model:setTexture(Tree.BrickTexture[texture_index][2])
                                --持续一段时间后变为原来的纹理
                                light_model._textureIndex = 2
                                light_model:runAction(cc.Sequence:create(cc.DelayTime:create(0.05/self._gameStageSpeed),
                                                                            cc.CallFunc:create(function()
                                                                                light_model:setTexture(Tree.BrickTexture[texture_index][1])
                                                                                light_model._textureIndex = 1
                                                                            end)))
                                self._lightIndex = self._lightIndex - 1
                                self._lightIndex = self._lightIndex < 1 and 24 or self._lightIndex--实际上也可以用一句算术表达式表示出来,然而可读性很差
                            end),cc.DelayTime:create((target_time-1.5)/repeat_count- frame_time)),repeat_count)),self._gameStageSpeed)
    accelerate_action:setTag(Tree.TagLightModelChanged)
    self._stagePointerModel:runAction(accelerate_action)--计算时间间隔的时候需要将帧率考虑上去
    self._sceneAnimationOrder = 3
end
--色块的闪烁
function SlwhBattleCcsView:blinkLightModel(model)
    --色块的闪烁
    local light_model = model.light_model
    local light_tag = light_model:getTag()
    light_model:runAction(cc.Repeat:create(cc.Sequence:create(
                                                cc.CallFunc:create(function()
                                                    local index_j= light_model._textureIndex +1
                                                    light_model._textureIndex = (index_j -1)%2 + 1
                                                    light_model:setTexture(Tree.BrickTexture[light_tag][light_model._textureIndex])
                                                end),cc.DelayTime:create(0.4)),3000))
    table.insert(self._selectLightModels,light_model)
end
--如果是送灯,则需要走不同的逻辑
function SlwhBattleCcsView:showJumpAnimation_Before(model,table_animal,bodyData)
    --print("showJumpAnimation_Before")
    --如果是送灯,则需要在场景的中央显示电视机模型,并播放数字动画
    if bodyData.tAward.nType == Tree.RewardType.RewardType_SongDeng then
        --切换场景中心电视机屏幕的纹理
        self._lampCountNum = self._lampCountNum - 1
        if self._lampCountNum > 0 then 
            self._rollingSongDeng:decreaseTo(self._lampCountNum)
        end
        --判断是否需要继续旋转场景
        if #table_animal > 0 then
            local target_index = table.remove(table_animal,1)
            model:runAction(cc.Sequence:create(cc.DelayTime:create(0.45/self._gameStageSpeed),cc.CallFunc:create(c_func(self.afterShowBrickAnimation,self,target_index,table_animal,bodyData))))
        else--否则展示结算界面,目前策划让修改为先一起跳到上面,然后弹出结算界面
            --背景音乐
            --self.controller:playMusic(Tree.Sound.AwardSound[Tree.RewardType.RewardType_SongDeng])
            --播放中奖音效
            self._rewardEffectHandler = self.controller:playGameEffect(Tree.Sound.AwardSound[Tree.RewardType.RewardType_SongDeng],false,true)
            local speed_action = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create(9.5),
                        cc.CallFunc:create(function()
                            audioMgr:setMusicVolume(self._originBackSoundVolum,nil,nil,nil,true)
                            self.controller:playMusic(Tree.Sound.battleWaitBg)
                        end)),self._gameStageSpeed)
            speed_action:setTag(Tree.TagActNodeSound)
            self._actNode:runAction(speed_action)
            self:showSongDengStageAnimation(bodyData)
        end
    else
        self:showJumpAnimation(model,table_animal,bodyData)
        --如果是彩金奖励,则显示彩金
        if bodyData.tAward.nType == Tree.RewardType.RewardType_CaiJin then
            self:notifyJackpotChanged(bodyData.lCaijin)
        end
    end
    --色块的闪烁
    --播放相关的动物音效,以及相关的色块
    local animal_tag = model:getTag()
    local model_type = (animal_tag - 1) % 4 + 1
    local model_color = model.color_type--=>math.ceil(animal_tag/12)%2 *(math.ceil(animal_tag /4)) + math.floor(animal_tag/13) * (animal_tag - 12)

    self.controller:playGameEffect(Tree.Sound.ColorSelectEffect[model_color])
    self._actNode:runAction(cc.Sequence:create(cc.DelayTime:create(0.95/self._gameStageSpeed),
                                cc.CallFunc:create(function()
                                    self.controller:playGameEffect(Tree.Sound.AnimalSelectEffect[model_type])--被选中的动物
                                end)))
    self._sceneAnimationOrder = 4
end
--送灯完毕之后,所有的被选中的动物都会跳到舞台上,并且一起播放跳舞动画
function SlwhBattleCcsView:showSongDengStageAnimation(bodyData)
    --print("showSongDengStageAnimation")
    --Camera
    local c_3d = self._camera:getPosition3D()
    local r_3d = self._camera:getRotation3D()
    local eye_z = display.height/1.1566
    --场景中心的TV消失
    -- self._lampNode:setVisible(false)
    self._lampNode:runAction(cc.Sequence:create(cc.EaseSineOut:create(cc.ScaleTo:create(0.1, 1.1)), cc.EaseSineIn:create(cc.ScaleTo:create(0.25, 0)), cc.CallFunc:create(function()

        self._lampNode:setScale(1)
        self._lampNode:setVisible(false)

    end)))
    --一起播放弹跳动画与跳舞动画
    local max_time = 0
    local max_delay = 0
    local model_array = self._animalSelectSet
    local s_3d = self._brickNode:getRotation3D()
    local pos_array = Tree.SceneLocation.Location[Tree.RewardType.RewardType_SongDeng][#model_array]

    for index = 1,#model_array do
        local model = model_array[index]
        local model_tag = model:getTag()
        local model_type = (model_tag - 1) % 4 + 1
        --计算动物模型在另一个坐标系中坐标
        local r_3d = model:getRotation3D()
        local r = r_3d.y + s_3d.y
        local r_s = {x =0,y = r - math.floor(r/360) * 360,z = 0}--旋转的部分

        local y = s_3d.y - (model_tag - 1)/Tree.ModelNumber * 360
        local radius = math.rad(y)
        local local_x = math.sin(radius) * self._animalRadius
        local local_z = math.cos(radius) * self._animalRadius
        local p_c = {x = local_x,y = self._animalHeight,z = local_z}
        --移动的目标
        local target_location = pos_array[index]
        --加载弹跳动画,需要分帧加载,否则一起加载有可能会很卡
        local jump_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Jump]
        self:loadOneJumpAnimate(model_tag)
        --加载获奖动作
        local reward_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Reward]
        self:loadOneRewardAnimate(model_tag)
        --转身动作
        local rotate_action = cc.RotateBy:create(0.35/self._gameStageSpeed,{x=0,y = -r_s.y,z=0})

        model:setPosition3D(p_c)
        model:setRotation3D(r_s)

        model:retain()
        model:removeFromParent()
        self._actNode:addChild(model)
        model:release()
        --run jump action
        local seq = cc.Sequence:create(self._animationActionJump[model_tag],
                                                                rotate_action,
                                                                self._animationActionReward[model_tag],
                                                                cc.DelayTime:create(0.2),
                                                                cc.CallFunc:create(function()
                                                                    model:runAction(cc.Repeat:create(self._animationActionActivity[model_tag],3000))
                                                                end))
        local speed_action = cc.Speed:create(seq,self._gameStageSpeed)
        speed_action:setTag(Tree.TagAnimalModel)
        model:runAction(speed_action)
        --run lua action
        local height = 40
        local time = (jump_map.to - jump_map.from) /30
        local jump_time = time - 41/30
        if not cc.Jump3DBy then
            local seq_luaaction = TreeSequence.new({
                TreeDelayTime.new(13/30),
                TreeCallFunc.new(c_func(self.processStageShadow,self,model,target_location)),
                TreeEaseSineOut.new(TreeJump3DBy.new(jump_time,target_location,height)),
                TreeDelayTime.new(28/30),
            })
            local action = TreeSpeed.new(seq_luaaction,self._gameStageSpeed)
            self._actionManager:addAction(model,action)
        else--使用C++动作对象
            local jump_sequence_action = cc.Sequence:create(cc.DelayTime:create(13/30),cc.CallFunc:create(c_func(self.processStageShadow,self,model,target_location)),cc.EaseSineOut:create(cc.Jump3DBy:create(jump_time,{x = target_location.x - p_c.x,y = target_location.y - p_c.y,z = target_location.z - p_c.z},height,1)),cc.DelayTime:create(28/30))
            local speed_action = cc.Speed:create(jump_sequence_action,self._gameStageSpeed)
            speed_action:setTag(Tree.TagJumpBase + model_tag)
            model:runAction(speed_action)
        end

        max_time = math.max(max_time,time + 0.35)
        max_delay = math.max(max_delay,time + 0.35 +(reward_map.to - reward_map.from)/30)
        --处理动物身上的影子
        local shadow = self._shadowSprites[model_tag]
        shadow:runAction(cc.Sequence:create(cc.DelayTime:create(13/30),cc.Spawn:create(cc.ScaleTo:create(jump_time * 0.33,0.1),cc.FadeOut:create(jump_time * 0.33))))
    end
    --摄像机走另一种路径
    local speed_action = cc.Speed:create(cc.Spawn:create(cc.EaseSineOut:create(cc.MoveTo:create(2,Tree.SceneLocation.Camera2.finalPosition)),cc.EaseSineOut:create(cc.RotateTo:create(2,{x = Tree.SceneLocation.Camera2.finalAngle,y=0,z=0})))
                                                                        ,self._gameStageSpeed)
    speed_action:setTag(Tree.TagCamera)
    self._camera:runAction(speed_action)

    local action_2 = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create(0.15 + max_delay),
                                        cc.CallFunc:create(function()
                                            self:showRewardUI(bodyData)
                                            self._isSceneRotated = false
                                        end),
                                        cc.DelayTime:create(0.15),
                                        cc.CallFunc:create(function()
                                            --Camera restore
                                            local camera_speed = cc.Speed:create(cc.Spawn:create(cc.RotateTo:create(2,{x=Tree.SceneLocation.Camera2.startAngle,y=0,z=0}),cc.MoveTo:create(2,self._originEyePosition)),self._gameStageSpeed)
                                            camera_speed:setTag(Tree.TagCamera)
                                            self._camera:runAction(camera_speed)
                                        end)),self._gameStageSpeed)
    action_2:setTag(Tree.TagNodeSceneReward)
    self.node_scene:runAction(action_2)
    --加载舞台粒子动画
    --加载辉光
    self._actNode:runAction(cc.Sequence:create(cc.DelayTime:create((max_time - 0.35)/self._gameStageSpeed),
                                                cc.CallFunc:create(function()
                                                    self:loadGlowAnimation(Tree.SceneLocation.ParticleLocation[Tree.RewardType.RewardType_SongDeng],2.2)
                                                end)))
    self._sceneAnimationOrder = 6

    local data = self.model:getSelfRedPacketData()
    if self.redPacket and data then
        if data.needPlayAnim then
            local wCurrentType = nil
            if data.wCurrentType then
                wCurrentType = data.wCurrentType+1
            end
            self.redPacket:playReceiveAnimation(cc.p(display.cx,display.cy), data.total, nil, wCurrentType, data.lCount)

            data.needPlayAnim = nil
        end
    end

    -- 播放年兽
    local data = self.model:getOnMonsterHit()
    if self.activityNode and self.activityNode:isVisible() and data then
        self.model:setOnMonsterHit(nil)
        -- 只关心自己的 判断dwUserID是否相同
        if data.dwUserID == Hero:getDwUserID() then
            -- dwHit 伤害值 -- 播放伤害效果 -1000
            -- cbIsLucky 是否幸运一击 -- 播放获得奖励分数 “幸运一击 + 200(lLuckyScore)”
            local visibleSize = cc.Director:getInstance():getVisibleSize()
            self.activityNode:playReceiveAnimation(cc.p(visibleSize.width / 2, visibleSize.height / 2 + 20), data.dwHit, data.cbIsLucky, data.lLuckyScore)
        end
    end
end
--处理动物身上的影子,舞台上
function SlwhBattleCcsView:processStageShadow(model,location,come_to_stage)
    local model_tag = model:getTag()
    --动物模型对应的颜色
    local color_type = model.color_type
    local wheel_path = string.format("slwh_wheel_%d.png",color_type)
    local sprite_wheel = cc.Sprite:createWithSpriteFrameName(wheel_path)
    sprite_wheel:setPosition3D({ x= location.x,y = location.y + 0.5,z=location.z})
    sprite_wheel:setRotation3D({x = -90,y=0,z=0})
    sprite_wheel:setCameraMask(Tree.CameraFlag)
    if sprite_wheel.setDepthTest then
        sprite_wheel:setDepthTest(true)
    end
    sprite_wheel:setOpacity(0)
    self._actNode:addChild(sprite_wheel)
    self._stageColorWheels[model_tag] = sprite_wheel
    --
    local time = 28/(40 * self._gameStageSpeed)
    local base_scale = TreeFunc.computeFrustumScale(self._camera:getPosition3D(),self._camera:getRotation3D(),location,display.height/1.1566)
    sprite_wheel:setScale(0.1 * base_scale)
    sprite_wheel:runAction(cc.Spawn:create(cc.ScaleTo:create(time,base_scale),cc.FadeIn:create(time)))
end
--处理动物身上的影子前奏
function SlwhBattleCcsView:precessBrickShadow_Before(model,time)
    local model_tag = model:getTag()
    local sprite_wheel = self._stageColorWheels[model_tag]--self._shadowSprites[model_tag]
    if sprite_wheel then
        sprite_wheel:runAction(cc.Sequence:create(cc.Spawn:create(cc.ScaleTo:create(time,0.1),cc.FadeOut:create(time)),
                        cc.CallFunc:create(function()
                            sprite_wheel:removeFromParent()
                            self._stageColorWheels[model_tag] = nil
                        end)))
    end
end
--处理动物身上的影子,在砖块上后续
function SlwhBattleCcsView:processBrickShadow_After(model,location)
    local model_tag = model:getTag()
    local shadow = self._shadowSprites[model_tag]
    shadow:setVisible(true)
    shadow:setPosition3D({ x= location.x,y = location.y + 0.5,z=location.z})

    local time = 28/40
    shadow:runAction(cc.Spawn:create(cc.ScaleTo:create(time,1),cc.FadeIn:create(time)))
end
--针对所有模型播放弹跳动作
function SlwhBattleCcsView:showJumpAnimation(model,table_animal,bodyData)
    --print("showJumpAnimation")
    local model_tag = model:getTag()
    local model_type = (model_tag - 1) % 4 + 1

    local jump_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Jump]
    self:loadOneJumpAnimate(model_tag)

    model:retain()
    model:removeFromParent()
    self._actNode:addChild(model)
    model:release()

    local speed_action = cc.Speed:create(self._animationActionJump[model_tag],self._gameStageSpeed)
    speed_action:setTag(Tree.TagAnimalModel)
    model:runAction(speed_action)
    --重新设置model的3d坐标,新的坐标与原来的坐标在视觉上相同
    local r_3d = model:getRotation3D()
    local n_3d = self._brickNode:getRotation3D()
    local r = r_3d.y + n_3d.y
    r = r - math.floor(r/360) * 360
    model:setRotation3D({x = 0,y = r,z = 0})--只有绕Y轴旋转的部分

    local y = n_3d.y - (model_tag - 1)/Tree.ModelNumber * 360
    local radius = math.rad(y)
    local local_x = math.sin(radius) * self._animalRadius
    local local_z = math.cos(radius) * self._animalRadius
    local local_y = self._animalHeight

    model:setPosition3D({x = local_x,y = local_y,z = local_z})
    --查找与获奖类型相对应的模型坐标位置
    local location = Tree.SceneLocation.Location[bodyData.tAward.nType][bodyData.loops]

    local reward_type = bodyData.tAward.nType
    --shadow fade out
    local shadow = self._shadowSprites[model_tag]
    shadow:runAction(cc.Spawn:create(cc.ScaleTo:create(13/30,0.1),cc.FadeOut:create(13/30)))
    --跳跃动作,使用lua-action实现
    local height = 40
    local time = (jump_map.to - jump_map.from) /30
    local jump_time = time - 41/30

    local action
    if not cc.Jump3DBy then
        local seq_luaction = TreeSequence.new({
            TreeDelayTime.new(13/30),
            TreeCallFunc.new(function()
                --处理影子
                self:processStageShadow(model,location)
            end),
            TreeEaseSineOut.new(TreeJump3DBy.new(jump_time,location,height)),
            TreeDelayTime.new(28/30),
        })
        action = seq_luaction
    else
        action = cc.Sequence:create(cc.DelayTime:create(13/30),cc.CallFunc:create(c_func(self.processStageShadow,self,model,location)),
                        cc.EaseSineOut:create(cc.Jump3DBy:create(jump_time,{ x = location.x - local_x,y = location.y - local_y,z = location.z - local_z},height,1)),cc.DelayTime:create(28/30))
    end

    local function delay_call1()--跳跃动画完毕就是获奖
        --使动物朝向观察者
        local r_3d = model:getRotation3D()
        local r = -r_3d.y
        r = r - math.floor(r/360) * 360--计算最小旋转角度
        model:runAction(cc.Sequence:create(cc.RotateBy:create(0.35 /self._gameStageSpeed,{x = 0,y = r,z = 0}),cc.DelayTime:create(0.15 / self._gameStageSpeed),cc.CallFunc:create(c_func(self.showRewardAnimation,self,model,bodyData))))
    end
    --从场景中移除,并且保持原来的旋转方向
    local function keep_rotation_call1()
        model:runAction(cc.RepeatForever:create(self._animationActionActivity[model_tag]))
        local target_index = table.remove(table_animal,1)
        self:afterShowBrickAnimation(target_index,table_animal,bodyData)
    end
    local function keep_rotation_call2()--跳到舞台上,一起播放动画
        local speed_action = cc.Speed:create(self._animationActionActivity[model_tag],self._gameStageSpeed)
        speed_action:setTag(Tree.TagAnimalModel)
        model:runAction(speed_action)
        self:showStageAnimation(bodyData)
    end
    --另一种旋转,始终朝向指针的外侧,旋转完毕之后,重新开始场景动画
    local function delay_call2()
        local r_3d = model:getRotation3D()
        local r =  -r_3d.y
        r = r - math.floor(r/360) * 360--计算最小旋转角度
        model:runAction(cc.Sequence:create(cc.RotateBy:create(0.35 /self._gameStageSpeed,{x = 0,y = r,z = 0}),cc.DelayTime:create(0.40 / self._gameStageSpeed),cc.CallFunc:create(keep_rotation_call1)))
    end
    local function delay_call3()
        local r_3d = model:getRotation3D()
        local r =  - r_3d.y
        r = r - math.floor(r/360) * 360--计算最小旋转角度
        model:runAction(cc.Sequence:create(cc.RotateBy:create(0.35 / self._gameStageSpeed,{x = 0,y = r,z = 0}),cc.DelayTime:create(0.15/self._gameStageSpeed),cc.CallFunc:create(keep_rotation_call2)))
    end
    --区分,是否是普通获奖类型
    local action_call
    if reward_type == Tree.RewardType.RewardType_Normal or reward_type == Tree.RewardType.RewardType_ShanDian or reward_type == Tree.RewardType.RewardType_CaiJin then
        action_call = cc.CallFunc:create(delay_call1)--TreeCallFunc.new(delay_call1)
        --针对镜头播放移动动作
        local speed_action = cc.Speed:create(cc.Spawn:create(cc.EaseSineOut:create(cc.MoveTo:create(2,Tree.SceneLocation.Camera.finalPosition)),cc.EaseSineOut:create(cc.RotateTo:create(2,{x = Tree.SceneLocation.Camera.finalAngle,y= 0,z=0}))),self._gameStageSpeed)
        speed_action:setTag(Tree.TagCamera)
        self._camera:runAction(speed_action)
    else
        --检测是否到达动作的尽头
        if #table_animal > 0  then--需要接着旋转场景
            action_call = cc.CallFunc:create(delay_call2)--TreeCallFunc.new(delay_call2)
        else--否则,将获取的动物模型一起播放舞台动画
            action_call = cc.CallFunc:create(delay_call3)--TreeCallFunc.new(delay_call3)
            --针对镜头播放移动动作
            local speed_action = cc.Speed:create(cc.Spawn:create(cc.EaseSineOut:create(cc.MoveTo:create(2,Tree.SceneLocation.Camera2.finalPosition)),cc.EaseSineOut:create(cc.RotateTo:create(2,{x = Tree.SceneLocation.Camera2.finalAngle,y= 0,z=0}))),self._gameStageSpeed)
            speed_action:setTag(Tree.TagCamera)
            self._camera:runAction(speed_action)
        end
    end

    if not cc.Jump3DBy then
        local action_sequence = TreeSpeed.new(action,self._gameStageSpeed)
        self._actionManager:addAction(model,action_sequence)
    else
        local speed_action = cc.Speed:create(action,self._gameStageSpeed)
        speed_action:setTag(Tree.TagJumpBase + model_tag)
        model:runAction(speed_action)
    end

    local action_accelerate = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create(time),action_call),self._gameStageSpeed)
    action_accelerate:setTag(Tree.TagSceneRotateContinue)
    self.node_scene:runAction(action_accelerate)
    self._sceneAnimationOrder = 5
end
--播放模型舞台跳舞动画
function SlwhBattleCcsView:showStageAnimation(bodyData)
    --print("showStageAnimation")
    --获取摄像机的基本信息
    local c_3d = self._camera:getPosition3D()
    local r_3d = self._camera:getRotation3D()
    local rad = math.rad(r_3d.x)
    local d_z = - math.cos(rad)
    local d_y = math.sin(rad)
    local d_x = 0
    local eye_z = display.height/1.1566
    --所有的被选中的模型,同时播放reward动画
    local time_max = 0
    local model_select_set = self._animalSelectSet
    for idx = 1,#model_select_set do
        local model = model_select_set[idx]
        local model_tag = model:getTag()
        local model_type = (model_tag-1) % 4 + 1

        local reward_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Reward]
        self:loadOneRewardAnimate(model_tag)
        time_max = math.max(time_max,(reward_map.to - reward_map.from)/30)

        local animate = self._animationActionReward[model_tag]
        model:stopAllActions()
        local action = cc.Speed:create(cc.Sequence:create(animate,
                                                                cc.DelayTime:create(0.2),
                                                                cc.CallFunc:create(function()
                                                                    model:runAction(cc.Repeat:create(self._animationActionActivity[model_tag],3000))
                                                                end)),self._gameStageSpeed)
        action:setTag(Tree.TagAnimalModel)
        model:runAction(action)
        --加载与模型相对应的Spine轨迹动画,并调整相关的缩放比例
    end

    local function delay_call()
        local camera_speed = cc.Speed:create(cc.Spawn:create(cc.RotateTo:create(2,{x=Tree.SceneLocation.Camera.startAngle,y=0,z=0}),cc.MoveTo:create(2,self._originEyePosition)),self._gameStageSpeed)
        camera_speed:setTag(Tree.TagCamera)
        self._camera:runAction(camera_speed)
    end
    local action_2 = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create(0.15 + time_max),
                                        cc.CallFunc:create(function()
                                            self:showRewardUI(bodyData)
                                            self._isSceneRotated = false
                                        end),
                                        cc.DelayTime:create(0.15),
                                        cc.CallFunc:create(delay_call)),self._gameStageSpeed)
    action_2:setTag(Tree.TagNodeSceneReward)
    self.node_scene:runAction(action_2)
    --加载舞台粒子特效
    self._rewardEffectHandler = self.controller:playGameEffect(Tree.Sound.AwardSound[bodyData.tAward.nType],false,true)
    local speed_action = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create(9.5),
                                    cc.CallFunc:create(function()
                                        if self._rewardEffectHandler ~= -1 then
                                            self.controller:stopGameEffect(self._rewardEffectHandler)
                                            self._rewardEffectHandler = -1
                                        end
                                        audioMgr:setMusicVolume(self._originBackSoundVolum,nil,nil,nil,true)
                                        self.controller:playMusic(Tree.Sound.battleWaitBg)
                                    end)),self._gameStageSpeed)
    speed_action:setTag(Tree.TagActNodeSound)
    self._actNode:runAction(speed_action)
    --加载辉光
    self:loadGlowAnimation(Tree.SceneLocation.ParticleLocation[bodyData.tAward.nType],2)
    self._sceneAnimationOrder = 6

    local data = self.model:getSelfRedPacketData()
    if self.redPacket and data then
        if data.needPlayAnim then
            local wCurrentType = nil
            if data.wCurrentType then
                wCurrentType = data.wCurrentType+1
            end
            self.redPacket:playReceiveAnimation(cc.p(display.cx,display.cy), data.total, nil, wCurrentType, data.lCount)

            data.needPlayAnim = nil
        end
    end

    -- 播放年兽
    local data = self.model:getOnMonsterHit()
    if self.activityNode and data then
        self.model:setOnMonsterHit(nil)
        -- 只关心自己的 判断dwUserID是否相同
        if data.dwUserID == Hero:getDwUserID() then
            -- dwHit 伤害值 -- 播放伤害效果 -1000
            -- cbIsLucky 是否幸运一击 -- 播放获得奖励分数 “幸运一击 + 200(lLuckyScore)”
            local visibleSize = cc.Director:getInstance():getVisibleSize()
            self.activityNode:playReceiveAnimation(cc.p(visibleSize.width / 2, visibleSize.height / 2 + 20), data.dwHit, data.cbIsLucky, data.lLuckyScore)
        end
    end
end
--恢复常态动作
function SlwhBattleCcsView:showActivityAnimation(model)
    local model_tag = model:getTag()
    local model_type = (model_tag - 1) % 4 + 1

    self:loadOneActivityAnimate(model_tag)
    --分帧加载
    model:retain()
    model:removeFromParent()
    self._brickNode:addChild(model,model_type)
    model:release()

    local delay_time = 0.16 + math.random() * 0.175
    local function delay_call()
        model:runAction(cc.RepeatForever:create(self._animationActionActivity[model_tag]))
    end
    --设置位置,以及相关的旋转角度
    model:setRotation3D({x =0, y = 180 - (model_tag - 1) * 360/Tree.ModelNumber,z = 0})
    local radius = 2 * math.pi * (model_tag - 1)/24
    local x= - math.sin(radius) * self._animalRadius
    local y = self._animalHeight
    local z = math.cos(radius) * self._animalRadius

    model:setPosition3D({ x = x,y= y,z = z})
    model:runAction(cc.Sequence:create(cc.DelayTime:create(delay_time),cc.CallFunc:create(delay_call)))
    --相关的影子
    local shadow = self._shadowSprites[model_tag]
    shadow:setOpacity(255)
    shadow:setVisible(true)
    shadow:setPosition3D({x = x,y=y+0.3,z=z})
    --删除舞台上的颜色底盘,如果有的话
    if self._stageColorWheels[model_tag] then
        self._stageColorWheels[model_tag]:removeFromParent()
        self._stageColorWheels[model_tag] = nil
    end
end
--加载动物模型头上的Spine光效动画
function SlwhBattleCcsView:loadGlowAnimation(origin_p,base_scale)
    local r3d = self._camera:getRotation3D()
    local eye_z = display.height/1.1566

    local c_r = math.rad(r3d.x)
    local c_x = 0
    local c_y = math.sin(c_r)
    local c_z = - math.cos(c_r)
    --计算当前的摄像机的上边缘,已知fov为60度,且摄像机的视线方向平面经过动物模型
    local p3d = self._camera:getPosition3D()
    --考虑屏幕的适配
    local half_fov = math.atan2(CONFIG_DESIGN_HEIGHT * 0.5,display.height * 0.5 * math.sqrt(3))
    --视锥体的上侧沿着旋转half_fov角度
    local r_x = c_r + half_fov
    --所得到的方向向量为
    local d_x = 0
    local d_y = math.sin(r_x)
    local d_z = - math.cos(r_x)
    --摄像机与模型的连线在视域上侧的投影长度
    local distance_x = origin_p.x - p3d.x
    local distance_y = origin_p.y - p3d.y
    local distance_z = origin_p.z - p3d.z
    local distance = math.sqrt(distance_x * distance_x + distance_y * distance_y + distance_z * distance_z)

    local v_x = distance_x/distance
    local v_y = distance_y/distance
    local v_z = distance_z/distance
    --摄像机到给定模型所在的平面的距离
    local g = distance * (v_x * c_x + v_y * c_y + v_z * c_z)
    --计算最终的坐标
    local base_x = p3d.x + g * c_x
    local base_y = p3d.y + g * c_y
    local base_z = p3d.z + g * c_z
    --倾斜着的方向向量,视角沿着+X旋转90度形成,因此其三角函数为上述的变形
    --(0,c_y,c_z) ==>(0,c_z,-c_y)->注意c_y = -math.sin(c_r),c_z本身为负值
    local d_p = g/eye_z * CONFIG_DESIGN_HEIGHT * 0.5
    local p_x = base_x + c_x * d_p
    local p_y = base_y - c_z * d_p
    local p_z = base_z + c_y * d_p

    local skeleton = TreeCacheManager:getCacheObject("slwh_dancing")
    skeleton:setAnimation(0,"animation",true)
    skeleton:setPosition3D({x = p_x,y = p_y,z=p_z})
    skeleton:setRotation3D(r3d)
    skeleton:setCameraMask(Tree.CameraFlag)
    skeleton:setScale(g/eye_z)
    skeleton:setOpacity(0)
    skeleton:setName("slwh_dancing")
    self.node_scene:addChild(skeleton)
    skeleton:runAction(cc.FadeIn:create(0.25))
    --舞台上的光效粒子,需要计算缩放比例
end
--加载舞台的粒子
function SlwhBattleCcsView:loadPartyParticle(reffer_pos,base_scale)
    local particle = TreeCacheManager:getCacheObject("slwh_stagedclizi")
    particle:setName("slwh_stagedclizi")
    particle:setCameraMask(Tree.CameraFlag)
    self.node_scene:addChild(particle)
    --计算缩放比例,标准视线的距离
    local r_3d = self._camera:getRotation3D()
    local p_3d = self._camera:getPosition3D()
    particle:setPosition3D(reffer_pos)
    particle:setRotation3D(r_3d)
    local scale = TreeFunc.computeFrustumScale(p_3d,r_3d,reffer_pos,display.height/1.1566)
    particle:setScale(scale * base_scale)
end
--加载舞台上与动物模型相关联的动作轨迹动画
function SlwhBattleCcsView:loadMotionTrackAnimation(model_type,reffer_pos,base_scale)
    local object_key = string.format("slwh_animal_%d",model_type)
    local track_skeleton = TreeCacheManager:getCacheObject(object_key)
    track_skeleton:setName(object_key)
    track_skeleton:setAnimation(0,"animation",false)
    track_skeleton:setPosition3D(reffer_pos)
    track_skeleton:setCameraMask(Tree.CameraFlag)
    track_skeleton:setTimeScale(1/self._gameStageSpeed)
    self.node_scene:addChild(track_skeleton)

    local c_3d = self._camera:getPosition3D()
    local r_3d = self._camera:getRotation3D()
    local scale = TreeFunc.computeFrustumScale(c_3d,r_3d,reffer_pos,display.height/1.1566)
    track_skeleton:setScale(scale * base_scale)
end
--选中的动物在基本动画播放完毕之后播放弹跳动画与奖励动画
function SlwhBattleCcsView:showRewardAnimation(model,bodyData)
    --print("showRewardAnimation")
    local model_tag = model:getTag()
    local model_type = (model_tag-1) % 4 + 1

    local reward_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Reward]
    self:loadOneRewardAnimate(model_tag)
    --加载辉光
    self:loadGlowAnimation(model:getPosition3D(),1)
    ------------
    local animate = self._animationActionReward[model_tag]
    local action_1 = cc.Speed:create(cc.Sequence:create(animate,cc.DelayTime:create(0.2),
                                                                cc.CallFunc:create(function()
                                                                    model:runAction(cc.Repeat:create(self._animationActionActivity[model_tag],3000))
                                                                end)),self._gameStageSpeed)
    action_1:setTag(Tree.TagAnimalModel)
    model:stopAllActions()
    model:runAction(action_1)
    --加载轨迹动画

    local speed_action = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create((reward_map.to - reward_map.from)/30 +0.15),
                                    cc.CallFunc:create(function()
                                        self:showRewardUI(bodyData)
                                        self._isSceneRotated = false
                                    end),
                                    cc.DelayTime:create(0.15),
                                    cc.CallFunc:create(function()
                                            --Camera restore
                                            local camera_speed = cc.Speed:create(cc.Spawn:create(cc.RotateTo:create(2,{x=Tree.SceneLocation.Camera.startAngle,y=0,z=0}),cc.MoveTo:create(2,self._originEyePosition)),self._gameStageSpeed)
                                            camera_speed:setTag(Tree.TagCamera)
                                            self._camera:runAction(camera_speed)
                                    end)),self._gameStageSpeed)
    speed_action:setTag(Tree.TagNodeSceneReward)
    self.node_scene:runAction(speed_action)
    --普通获奖,播放动物跳舞背景音乐,播放完毕之后继续播放<等待背景音乐>,持续时间为8秒
    local speed_action = cc.Speed:create(cc.Sequence:create(cc.DelayTime:create(7.7),
                                            cc.CallFunc:create(function()
                                                if self._rewardEffectHandler ~= -1 then
                                                    self.controller:stopGameEffect(self._rewardEffectHandler)
                                                    self._rewardEffectHandler = -1
                                                end
                                                audioMgr:setMusicVolume(self._originBackSoundVolum,nil,nil,nil,true)
                                                self.controller:playMusic(Tree.Sound.battleWaitBg)
                                            end)),self._gameStageSpeed)
    speed_action:setTag(Tree.TagActNodeSound)
    self._actNode:runAction(speed_action)
    --self.controller:playMusic(Tree.Sound.AwardSound[Tree.RewardType.RewardType_Normal][model_type])
    self._rewardEffectHandler = self.controller:playGameEffect(Tree.Sound.AwardSound[Tree.RewardType.RewardType_Normal][model_type],false,true)
    --如果是彩金,需要特殊处理效果
    if bodyData.tAward.nType == Tree.RewardType.RewardType_CaiJin then
        --保存原模型的GLProgramState并加载gold shader
        local meshes = model:getMeshes()
        --对原来的mesh,设置新的GLProgramState
        local eye_position = self._camera:getPosition3D()
        for index_j = 1,1 do
            local material = meshes[index_j]:getMaterial()
            local technique = material:getTechniqueByIndex(0)
            local pass = technique:getPassByIndex(0)
            self._originGLProgramState[index_j] = pass:getGLProgramState()
            self._originGLProgramState[index_j]:retain()
            --设置眼睛的坐标
            self._goldStates[index_j]:setUniformVec3("g_ViewPosition",eye_position)
            meshes[index_j]:setGLProgramState(self._goldStates[index_j])
        end
        model:setTexture(Tree.ModelTexture[model_type][2])--更换成金色纹理
        self._selectAnimalModel = model
    end

    local data = self.model:getSelfRedPacketData()
    if self.redPacket and data then
        if data.needPlayAnim then
            local wCurrentType = nil
            if data.wCurrentType then
                wCurrentType = data.wCurrentType+1
            end
            self.redPacket:playReceiveAnimation(cc.p(display.cx,display.cy), data.total, nil, wCurrentType, data.lCount)

            data.needPlayAnim = nil
        end
    end

    -- 播放年兽
    local data = self.model:getOnMonsterHit()
    if self.activityNode and data then
        self.model:setOnMonsterHit(nil)
        -- 只关心自己的 判断dwUserID是否相同
        if data.dwUserID == Hero:getDwUserID() then
            -- dwHit 伤害值 -- 播放伤害效果 -1000
            -- cbIsLucky 是否幸运一击 -- 播放获得奖励分数 “幸运一击 + 200(lLuckyScore)”
            local visibleSize = cc.Director:getInstance():getVisibleSize()
            self.activityNode:playReceiveAnimation(cc.p(visibleSize.width / 2, visibleSize.height / 2 + 20), data.dwHit, data.cbIsLucky, data.lLuckyScore)
        end
    end
end
--动画结束之后恢复模型的位置
function SlwhBattleCcsView:resumeModelPosition(model)
    local model_tag = model:getTag()

    model:setRotation3D({x =0, y = 180 - (model_tag - 1) * 360/Tree.ModelNumber,z = 0})
    local radius = 2 * math.pi * (model_tag - 1)/24
    model:setPosition3D({ x = - math.sin(radius) * self._animalRadius,y= self._animalHeight,z = math.cos(radius) * self._animalRadius})
end
--加载舞台
function SlwhBattleCcsView:loadPartyStage(reward_type)
    --送灯,闪电/大三元/大四喜/与普通类型共用一套
    local secondary_type = reward_type
    if reward_type == Tree.RewardType.RewardType_SongDeng or reward_type == Tree.RewardType.RewardType_ShanDian or reward_type == Tree.RewardType.RewardType_DaSanYuan or reward_type == Tree.RewardType.RewardType_DaSiXi then
        secondary_type = Tree.RewardType.RewardType_Normal
    end
    --
    if not self._forestPartyMap[secondary_type] then
        local model_path_map = Tree.PartyModelPath[secondary_type]
        local pointerModel = cc.Sprite3D:create(model_path_map.pointerModel)
        pointerModel:setCameraMask(Tree.CameraFlag)
        pointerModel:setTag(secondary_type)
        pointerModel:setVisible(false)
        self.node_scene:addChild(pointerModel)

        local partyModel = cc.Sprite3D:create(model_path_map.partyModel)
        partyModel:setCameraMask(Tree.CameraFlag)
        partyModel:setRotation3D(Tree.ZeroPosition)
        partyModel:setTag(secondary_type)
        partyModel:setVisible(false)
        --大四喜舞台比较特殊
        if secondary_type == Tree.RewardType.RewardType_DaSiXi then
            partyModel:setForce2DQueue(true)
        end
        self.node_scene:addChild(partyModel)

        self._forestPartyMap[secondary_type] = {
            pointerModel = pointerModel,
            partyModel = partyModel,
        }
    end
end
--加载某一个activity动画
function SlwhBattleCcsView:loadOneActivityAnimate(model_tag)
    if not self._animationActionActivity[model_tag] then
        local model_type = (model_tag - 1) % 4 + 1
        --加载模型animation
        if not self._animalActivityAnimation[model_type] then
            local animation = cc.Animation3D:create(Tree.ModelActivityPath[model_type])
            animation:retain()
            self._animalActivityAnimation[model_type] = animation
        end
        local jump_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Activity]
        local animate = cc.Animate3D:createWithFrames(self._animalActivityAnimation[model_type],jump_map.from,jump_map.to)
        animate:setQuality( cc.Animate3DQuality.QUALITY_LOW)
        animate:retain()
        self._animationActionActivity[model_tag] = animate
    end
end
--加载某一个jump动画
function SlwhBattleCcsView:loadOneJumpAnimate(model_tag)
    if not self._animationActionJump[model_tag] then
        local model_type = (model_tag - 1) % 4 + 1
        if not self._animalJumpAnimation[model_type] then
            local animation = cc.Animation3D:create(Tree.ModelJumpPath[model_type])
            animation:retain()
            self._animalJumpAnimation[model_type] = animation
        end
        local jump_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Jump]
        local animate = cc.Animate3D:createWithFrames(self._animalJumpAnimation[model_type],jump_map.from,jump_map.to)
        animate:setQuality( cc.Animate3DQuality.QUALITY_LOW)
        animate:retain()
        self._animationActionJump[model_tag] = animate
    end
end
--加载某一个reward动画
function SlwhBattleCcsView:loadOneRewardAnimate(model_tag)
    if not self._animationActionReward[model_tag] then
        local model_type = (model_tag - 1) % 4 + 1
        if not self._animalRewardAnimation[model_type] then
            local animation = cc.Animation3D:create(Tree.ModelRewardPath[model_type])
            animation:retain()
            self._animalRewardAnimation[model_type] = animation
        end
        local reward_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Reward]
        local animate = cc.Animate3D:createWithFrames(self._animalRewardAnimation[model_type],reward_map.from,reward_map.to,30)
        animate:setQuality( cc.Animate3DQuality.QUALITY_LOW)
        animate:retain()
        self._animationActionReward[model_tag] = animate
    end
end
--加载舞台模型的动画
function SlwhBattleCcsView:loadPartyAnimation(reward_type,animation_type)
    local animation_table = self._partyAnimation[reward_type]
    if not animation_table[animation_type] then
        local animationMap = Tree.PartyModelAnimation[reward_type][animation_type]
        local animation = cc.Animation3D:create(Tree.PartyModelPath[reward_type].partyModel)
        local animate = cc.Animate3D:createWithFrames(animation,animationMap.from,animationMap.to,30)
        animate:retain()
        animation_table[animation_type] = animate
    end
    return animation_table[animation_type]
end
--游戏的状态切换
function SlwhBattleCcsView:notifySessionStatusChanged(bodyData)
    --print("----->notifySessionStatusChanged--->status:",bodyData.cbStatus)

    if self.__waitTipsAnimation then
        self.__waitTipsAnimation:runAction(cc.Sequence:create(cc.FadeTo:create(0.3, 0),cc.RemoveSelf:create()))
        self.__waitTipsAnimation = nil
    end
    self._sceneAnimationOrder = 0
    self:updateLayerTime()
    --检测是否需要禁止下注按钮
    if bodyData.cbStatus == Tree.Status.Wait or bodyData.cbStatus == Tree.Status.Play then
        --if self._originAudioVolum ~= -1 then
        --    audioMgr:setMusicVolume(self._originBackSoundVolum,nil,nil,nil,true)
        --end
        self.controller:playMusic(Tree.Sound.battleWaitBg)
        --检测是否需要还原现场
        self._shouldChangeJackpot = true
    else
        self.controller:playMusic(Tree.Sound.battleZhuanpan)
    end
    --if self._originAudioVolum ~= -1 then
        audioMgr:setMusicVolume(self._originBackSoundVolum,nil,nil,nil,true)
    --end
    self:correctSceneOnStatus(bodyData.cbStatus,false)

    if bodyData.cbStatus == Tree.Status.Wait or bodyData.cbStatus == Tree.Status.Over then
        self:stopResultSound()
    end
    --如果是空闲状态,则需要进行舞台的更换
    if bodyData.cbStatus == Tree.Status.Wait then
        self.model:setUserTotalJetton(0)
        --[[if self._shadowSkeleton:getTag() > 0 and self._shadowSkeleton:getScale() > 1.2 then
            self._shadowSkeleton:runAction(cc.Sequence:create(cc.DelayTime:create(2),cc.ScaleTo:create(1,1.2)))
            self._shadowSkeleton:setTag(0)
        end]]
        --此时需要重置色块的状态
        --如果由于切后台导致的同时收到多个协议,则需要先停掉原来的动作
        if self._actionColorChanged then
            self.node_scene:stopActionByTag(Tree.TagColorSequenceChanged)
        end
        self:changeColorModel(bodyData.nSeed)
    end
    --银行
    if bodyData.cbStatus == Tree.Status.Over then
        self.model:setIsShowingBank(false)
        self._couldPlayerScoreModify  = false
    else
        self._couldPlayerScoreModify = true
    end
    --print("----->notifySessionStatusChanged--->end:",bodyData.cbStatus)
end
--矫正现场,有时为玩家再某一个阶段切入了后台,然后经过一小段时间又切了回来,此时动作仍在正常进行,
--但是因为临近下一阶段,所以为了能让下一阶段正常进行,需要进行现场矫正
function SlwhBattleCcsView:correctSceneOnStatus(status,force)
    if self._rewardCcsView then
        self._rewardCcsView:runExitAnimation()
    end
    --开奖阶段开始弹出的提示
    if self.__tipsAnimation then
        TreeCacheManager:recycleCocos2dxObject(self.__tipsAnimation)
        self.__tipsAnimation = nil
    end
    --回收资源
    local dance_skeleton = self.node_scene:getChildByName("slwh_dancing")
    if dance_skeleton then
        TreeCacheManager:recycleCocos2dxObject(dance_skeleton)
    end
    local stage_skeleton = self.node_scene:getChildByName("slwh_stagegs")
    if stage_skeleton then
        TreeCacheManager:recycleCocos2dxObject(stage_skeleton)
    end
    --self:recycleAnimalMotionTrack()
    --如果目前还有模型没有处理完,此时可以肯定,玩家切入了后台,错过了某一个阶段
    --色块
    if force then
        local index_j = #self._lightModels
        while index_j > 0 do
            local light_model = self._lightModels[index_j]
            local tag = light_model:getTag()
            light_model:stopAllActions()
            if tag ~= 0 then
                light_model:setTexture(Tree.BrickTexture[tag][1])
            end

            table.remove(self._selectLightModels)
            index_j = index_j - 1
        end
    else
        if #self._selectLightModels > 0 then
            local index_j = #self._selectLightModels
            while index_j > 0 do
                local light_model = self._selectLightModels[index_j]
                local tag = light_model:getTag()
                light_model:stopAllActions()
                if tag ~= 0 then
                    light_model:setTexture(Tree.BrickTexture[tag][1])
                end

                table.remove(self._selectLightModels)
                index_j = index_j - 1
            end
        end
    end
    --被选中的动物模型恢复原位
    if #self._animalSelectSet > 0 then
        local index_j = #self._animalSelectSet
        local brick_3d = self._brickNode:getRotation3D()
        local origin_y = brick_3d.y - math.floor(brick_3d.y/360) * 360
        --预计算相关的三角函数
        local r = - math.rad(origin_y)
        local cos_v = math.cos(r)
        local sin_v = math.sin(r)

        --记录下当前的动物模型,如果出现彩金效果,并且当前快速登出,就会出现问题
        --self._selectAnimalModel = index_j ~= 1 and nil or self._animalSelectSet[1]
        local max_time = 0
        while index_j > 0 do
            local animal_model = self._animalSelectSet[index_j]
            local model_tag = animal_model:getTag()
            local model_type = (model_tag -1) % 4 + 1
            --如果是空闲状态,需要有整个的过程,否则需要直接归位
            --停止掉所有模型的lua动作
            if not cc.Jump3DBy then
                self._actionManager:removeTargetAction(animal_model)
            else
                animal_model:stopActionByTag(Tree.TagJumpBase + model_tag)
            end
            if status ~= Tree.Status.Wait or force then
                self:showActivityAnimation(animal_model)
                self:restoreOriginGLProgramState(animal_model)
                self._selectAnimalModel = nil
            else
                --换算到self._brickNode的坐标系
                animal_model:retain()
                animal_model:removeFromParent()
                self._brickNode:addChild(animal_model)
                animal_model:release()

                animal_model:setRotation3D({x = 0,y = -origin_y,z = 0})
                --计算另一个坐标系中的位置,绕+Y轴旋转r弧度
                local origin_location = animal_model:getPosition3D()
                local now_location = {
                    x = origin_location.x * cos_v + origin_location.z * sin_v,
                    y = origin_location.y,
                    z = -origin_location.x * sin_v + origin_location.z * cos_v,
                }
                animal_model:setPosition3D(now_location)
                --计算需要转动的角度
                local need_y = -(model_tag - 1) * 360/Tree.ModelNumber
                --最终的角度
                local need_f = 180 - (model_tag - 1) * 360/Tree.ModelNumber
                local jump_map = Tree.ModelAnimation[model_type][Tree.AnimationType.AnimationType_Jump]
                local time = (jump_map.to - jump_map.from) /30
                animal_model:runAction(cc.Sequence:create(cc.RotateTo:create(0.2,{x = 0,y = need_y,z=0}),
                                        cc.CallFunc:create(function()
                                            local height = 40
                                            local radius = 2 * math.pi * (model_tag - 1)/24
                                            local location = { x = - math.sin(radius) * self._animalRadius,y= self._animalHeight,z = math.cos(radius) * self._animalRadius}
                                            if not cc.Jump3DBy then
                                                local seq_luaction = TreeSequence.new({
                                                    TreeDelayTime.new(13/30),
                                                    TreeCallFunc.new(c_func(self.precessBrickShadow_Before,self,animal_model,(time - 41/30) * 0.33)),
                                                    TreeEaseSineOut.new(TreeJump3DBy.new(time - 41/30,location,height)),
                                                    TreeCallFunc.new(c_func(self.processBrickShadow_After,self,animal_model,location)),
                                                    TreeDelayTime.new(28/30),
                                                })
                                                self._actionManager:addAction(animal_model,seq_luaction)
                                            else
                                                animal_model:runAction(cc.Sequence:create(cc.DelayTime:create(13/30),cc.CallFunc:create(c_func(self.precessBrickShadow_Before,self,animal_model,(time - 41/30) * 0.33)),
                                                        cc.EaseSineOut:create(cc.Jump3DBy:create(time - 41/30,{x = location.x - now_location.x,y = location.y - now_location.y,z = location.z - now_location.z},height,1)),cc.CallFunc:create(c_func(self.processBrickShadow_After,self,animal_model,location)),cc.DelayTime:create(28/30)))
                                            end
                                        end),self._animationActionJump[model_tag],
                                        cc.CallFunc:create(function()
                                            self:restoreOriginGLProgramState(animal_model)
                                            self._selectAnimalModel = nil
                                        end),
                                        cc.RotateTo:create(0.2,{x=0,y = need_f,z=0}),cc.CallFunc:create(c_func(self.showActivityAnimation,self,animal_model))))
                max_time = math.max(max_time,0.2 + time)
            end

            table.remove(self._animalSelectSet)
            index_j = index_j - 1
        end
        --收缩舞台
        if status ~= Tree.Status.Wait or force then--直接收缩
            self:shrunkPartyModel(status)
        else
            self._actNode:runAction(cc.Sequence:create(cc.DelayTime:create(max_time),cc.CallFunc:create(c_func(self.shrunkPartyModel,self,status))))
        end
    end
    --是否正在旋转中,有时游戏锁屏之后由于不能正确的同步,此时导致很多动画仍在正常的播放,因此需要强行停止
    if self._isSceneRotated then
        self._isSceneRotated = false
        self.node_scene:stopActionByTag(Tree.TagStopSound)
        self.node_scene:stopActionByTag(Tree.TagNodeSceneReward)
        self.node_scene:stopActionByTag(Tree.TagLightColorChanged)
        self.node_scene:stopActionByTag(Tree.TagSceneRotateContinue)
        self._brickNode:stopAllActions()
        self._stagePointerModel:stopAllActions()
        self._stagePartyModel:stopAllActions()
        self._camera:stopAllActions()
        self:resumeModel()
        if not cc.Jump3DBy then
            self._actionManager:clear()
        end
        --self._shadowSkeleton:setScale(1.2)
        --
        self._stagePointerModel:setVisible(false)
        self._stagePartyModel:setVisible(false)
        if self._lampNode then
            self._lampNode:setVisible(false)
        end

        self._stagePointerModel = self._forestPartyMap[Tree.RewardType.RewardType_Normal].pointerModel
        self._stagePartyModel = self._forestPartyMap[Tree.RewardType.RewardType_Normal].partyModel

        self._stagePointerModel:setVisible(true)
        self._stagePartyModel:setVisible(true)

        self._stagePointerModel:stopAllActions()
        self._stagePartyModel:stopAllActions()
        --对指针位置进行矫正
        self._brickNode:setRotation3D({x=0,y=0,z=0})
        self._stagePointerModel:setRotation3D(self._stagePointerRotation)
        self._stagePartyModel:runAction(self._stagePartyOriginAnimate)

        self._camera:stopAllActions()
        self._camera:setPosition3D(Tree.SceneLocation.Camera.eyePosition)
        self._camera:setRotation3D({x = Tree.SceneLocation.Camera.startAngle,y=0,z=0})
    end
    --是否需要关闭下注面板
    if status == Tree.Status.Over or status == Tree.Status.Wait then
        -- self.model:setIsShowingJetton(false)
        TreeEventDispatcher:dispatchEvent(Tree.Event.closeJettonView)
    end
    --yinxiao
    if self._rewardEffectHandler ~= -1 then
        self.controller:stopGameEffect(self._rewardEffectHandler)
        self._rewardEffectHandler = -1
    end
end
--恢复模型的GLProgramState
function SlwhBattleCcsView:restoreOriginGLProgramState(animal_model)
    if #self._originGLProgramState > 0 then
        local meshes = animal_model:getMeshes()
        local index_j = 1
        while index_j > 0 do
            meshes[index_j]:setGLProgramState(self._originGLProgramState[index_j])
            self._originGLProgramState[index_j]:release()
            table.remove(self._originGLProgramState)

            index_j = index_j - 1
        end
        --还原原来的纹理
        local model_tag = animal_model:getTag()
        local model_type = (model_tag -1) % 4 + 1
        animal_model:setTexture(Tree.ModelTexture[model_type][1])
    end
end
--缩小舞台的范围
function SlwhBattleCcsView:shrunkPartyModel(status)
    --也有可能游戏切入后台返回后,一下子接收到连续的几个协议
    --为了使动作不会出现二重进入,所以需要判断一下
    if self._stagePointerModel:getTag() ~= Tree.RewardType.RewardType_Normal then
        self._stagePartyModel:stopAllActions()
        self._stagePointerModel:stopActionByTag(Tree.TagStagePointer)
        self._stagePointerModel:stopActionByTag(Tree.TagLightModelChanged)
        local party_model = self._stagePartyModel
        local pointer_model = self._stagePointerModel
        local r3d = self._stagePointerModel:getRotation3D()

        self._stagePartyModel = self._forestPartyMap[Tree.RewardType.RewardType_Normal].partyModel
        self._stagePointerModel = self._forestPartyMap[Tree.RewardType.RewardType_Normal].pointerModel

        self._stagePartyModel:setVisible(true)
        self._stagePointerModel:setRotation3D(r3d)
        local animation_down = self:loadPartyAnimation(party_model:getTag(),Tree.PartyAnimationType.AnimationType_Down)
        party_model:runAction(cc.Sequence:create(animation_down,
                                                    cc.CallFunc:create(function()
                                                        party_model:setVisible(false)
                                                        pointer_model:setVisible(false)
                                                        self._stagePointerModel:setVisible(true)
                                                    end)))
    else--if self._stagePointerModel.reward_type == Tree.RewardType.RewardType_SongDeng or self._stagePointerModel.reward_type == Tree.RewardType.RewardType_DaSanYuan or reward_type == Tree.RewardType.RewardType_DaSiXi then
        self._stagePartyModel:stopAllActions()
        self._stagePointerModel:stopActionByTag(Tree.TagStagePointer)
        self._stagePointerModel:stopActionByTag(Tree.TagLightModelChanged)
        --普通类型,闪电类型,不要要收缩舞台
        if self._stagePointerModel.reward_type ~= Tree.RewardType.RewardType_Normal and self._stagePointerModel.reward_type ~= Tree.RewardType.RewardType_ShanDian then
            local animation_down = self:loadPartyAnimation(Tree.RewardType.RewardType_Normal,Tree.PartyAnimationType.AnimationType_Down)
            self._stagePartyModel:runAction(animation_down)
        end
        self._stagePointerModel.reward_type = nil
    end
end

function SlwhBattleCcsView:showMultiEffect(multi)
    --multi = Tree.ModelType.ModelType_Caijin
    if( nil == self.multiModel ) then self.multiModel = {} end
    if( nil == self.multiModel[multi] ) then 
        self.multiModel[multi] = {}
    end
    if( nil == self.multiModel[multi].model ) and (multi ~= Tree.ModelType.ModelType_DaSanYuan and multi ~= Tree.ModelType.ModelType_DaSiXi) then 
        self.multiModel[multi].model = cc.Sprite3D:create( Tree.ModelPath[multi] )
        --self.multiModel[multi].model:setCameraMask(cc.Camera:getDefaultCamera():getCameraFlag())
        self.multiModel[multi].model:setPosition3D(cc.vec3(CONFIG_DESIGN_WIDTH*0.5,CONFIG_DESIGN_HEIGHT*0.5-150 + 100,0))
        self.multiModel[multi].model:setRotation3D(cc.vec3(0,0,0))
        self.multiModel[multi].model:setForce2DQueue(true)
        self.multiModel[multi].model:setScale(10)
        self.multiModel[multi].model:setLocalZOrder(2)
        self:addChild(self.multiModel[multi].model)
        local animation = cc.Animation3D:create(Tree.ModelPath[multi])

        if multi == Tree.ModelType.ModelType_Caijin then
            self.multiModel[multi].animate = cc.Animate3D:createWithFrames(animation,1,75,30)
        else
            self.multiModel[multi].animate = cc.Animate3D:createWithFrames(animation,1,60,30)
        end

        self.multiModel[multi].animate:retain()
    end
    if( nil == self.multiModel[multi].spine ) then
        local str = "effect/slwh_beishueffect"
        if( multi == Tree.ModelType.ModelType_Caijin ) then 
            str = "effect/slwh_caijineffect"
        elseif ( multi == Tree.ModelType.ModelType_SongDeng ) then
            str = "effect/slwh_getlighteffect"
        elseif (multi == Tree.ModelType.ModelType_DaSanYuan) then
            str = "effect/slwh_dsytips"
        elseif (multi == Tree.ModelType.ModelType_DaSiXi) then
            str = "effect/slwh_dsxtips"
        end 
        self.multiModel[multi].spine = sp.SkeletonAnimation:create(Tree.root .. str .. ".json", Tree.root .. str .. ".atlas")
        self.multiModel[multi].spine:setPosition(cc.p(CONFIG_DESIGN_WIDTH*0.5,display.height*0.5))
        self.multiModel[multi].spine:setAnimation(0,"animation", false)
        self.multiModel[multi].spine:setLocalZOrder(3)
        local function c2h()
			self.multiModel[multi].spine:setVisible(false)
		end
		self.multiModel[multi].spine:registerSpineEventHandler( c2h, sp.EventType.ANIMATION_COMPLETE )
        self:addChild(self.multiModel[multi].spine)
    end

    if multi == Tree.ModelType.ModelType_Caijin then

        local winNumber = self.model:getUserSessionCaiJin()
        winNumber = (winNumber == 0) and 10000 +  math.random() * (9999999 - 10000) or winNumber

        self:runAction(cc.Sequence:create(cc.DelayTime:create(22 * 0.033), cc.CallFunc:create(function() self:ShowBossGoldEx(cc.p(CONFIG_DESIGN_WIDTH*0.5,display.height*0.5 + 50), 1) end)))
        self:runAction(cc.Sequence:create(cc.DelayTime:create(70 * 0.033), cc.CallFunc:create(function() self:showGetBonusEffect(winNumber, 3, 9) end)))
    end
    -- self.model:getUserSessionCaiJin()
    self.multiModel[multi].spine:setVisible(true)
    self.multiModel[multi].spine:setAnimation(0,"animation", false)

    if self.multiModel[multi].model then
        self.multiModel[multi].model:setVisible(true)
        self.multiModel[multi].model:stopAllActions()
        self.multiModel[multi].model:runAction(cc.Sequence:create(self.multiModel[multi].animate, 
                                                                                            cc.CallFunc:create(function()
                                                                                            self.multiModel[multi].model:setVisible(false)
                                                                                            end)))
    end

    self.controller:playGameEffect(Tree.Sound.RewardBreakOutEffect)
end

function SlwhBattleCcsView:onMenuShowChanged()
    local flag = self.model:getIsShowingMenu()
	self.btnOpen:setVisible(not flag)
	self.btnOpen:setTouchEnabled(not flag)
	self.btnClose:setVisible(flag)
	self.btnClose:setTouchEnabled(flag)
end

function SlwhBattleCcsView:onBtnClick(sender)
    if sender == self.btnBet then
        self.model:setIsShowingJetton(true)
        self:isShowAllModels(false)
        --print("show jetton")
    elseif sender == self.btnOpen or sender == self.btnClose then
        self.controller:onMenuBtnClick()
    end
end

function SlwhBattleCcsView:destroy()
    self.btnOpen:destroy()
    self.btnClose:destroy()
    self.btnBet:destroy()

    --释放缓存的3d模型动画
    for index = 1,#self._animationActionActivity do
        self._animationActionActivity[index]:release()
    end

    for key,animation in pairs(self._animationActionJump) do
        animation:release()
    end
    self._animationActionJump = {}

    for key,animation in pairs(self._animationActionReward) do
        animation:release()
    end
    self._animationActionReward = {}
    --动物自身的模型
    for model_type,animation in pairs(self._animalActivityAnimation) do
        animation:release()
    end
    self._animalActivityAnimation = {}
    --jump animation
    for model_type,animation in pairs(self._animalJumpAnimation) do
        animation:release()
    end
    self._animalJumpAnimation = {}
    --reward
    for model_type,animation in pairs(self._animalRewardAnimation) do
        animation:release()
    end
    self._animalRewardAnimation = {}
    --舞台模型动画
    for k_l ,animationMap in pairs(self._partyAnimation) do
        for aniType,animation in pairs(animationMap) do
            AnimationPlayer:release()
        end
        self._partyAnimation[k_l] = {}
    end
    --舞台模型动画
    self._stagePartyOriginAnimate:release()
    for key_j,animation in pairs(self._partyAnimation) do
        animation:release()
    end
    self._partyAnimation = {}

    for key, animation in pairs( self.multiModel or {} ) do 
        if( animation.animate ) then 
            animation.animate:release()
        end
        if( animation.model ) then 
            animation.model:stopAllActions()
            animation.model:removeFromParent()
        end
        if( animation.spine ) then 
            animation.spine:removeFromParent()
        end
    end
    self.multiModel = {}

    if self._rewardCcsView then
        self._rewardCcsView:onDestroy()
        self._rewardCcsView:release()
    end

    self._camera:removeFromParent()
    self._camera:release()
    --shader
    self._goldStates[1]:release()
    --self._goldStates[2]:release()
    self._goldGLProgram:release()
    self._plantGLProgram:release()
end

-- 3D爆金币效果
function SlwhBattleCcsView.getObjects(plistPath, key, frameNumber, frameName)
    cc.SpriteFrameCache:getInstance():addSpriteFrames(plistPath);
    local animation = cc.AnimationCache:getInstance():animationByName(key)

    -- 金色银色都是6帧动画 frameNumber:6 frameName: fish_jinbi4 / fish_yinse_jinbi4
    if not animation then
        local frames = {}
        for i = 0, frameNumber - 1 do
            local name = string.format("%s%d.png", frameName, i)
            frames[i] = cc.SpriteFrameCache:getInstance():spriteFrameByName(name)
        end
        animation = cc.Animation:createWithSpriteFrames(frames, 0.040)
        animation:setLoops(100)
        cc.AnimationCache:getInstance():addAnimation(animation, key)
    end
    object = cc.Animate:create(animation)
    -- object:retain()

    return object
end

function SlwhBattleCcsView:createBossGoldAnimation()

    local scale = 2
    local coin_count = 120

    local node = cc.Node:create()
    node:retain()
    node.coin_count = coin_count
    node.coins = {}

    local maxDuration = 0

    for i = 1, coin_count do

        local dcc = 850
        local speed = 550 + 250 * (math.random() * 2.0 - 1.0) * scale * 1.2
        local duration = 36 * 0.033
        local distance = 700 * math.random() + 50
        local angle = math.pi * 2 * math.random()
        local startScale = 0.15 + 0.3 * math.random()

        local radius = 80 * math.random()
        local startOffset = cc.p(radius * math.sin(angle), radius * math.cos(angle))

        local fameName = math.random(1, 2) == 1 and "slwh_jbc" or "slwh_jbz"
        local filePath = "res/gameres/module/slwh/spritesheet/"
        local animate = SlwhBattleCcsView.getObjects(filePath .. "slwh_gold.plist", fameName, 6, fameName)
        local coin = cc.Sprite:create()
        local speed = cc.Speed:create(animate, 1 + 0.5 * math.random())
        speed:retain()

        coin.animate = speed
        coin:setPosition(startOffset)
        coin:setScale(startScale)
        coin:setRotation(360 * math.random())
        coin:setOpacity(35)
        coin:setBlendFunc({src = gl.ONE, dst = gl.ONE_MINUS_SRC_ALPHA})

        node:addChild(coin)
        
        coin.spreadAction = cc.Sequence:create(cc.EaseExponentialOut:create(cc.Spawn:create(cc.ScaleTo:create(36 * 0.033, startScale * 2), cc.MoveBy:create(36 * 0.033, cc.p(distance * math.sin(angle), distance * math.cos(angle))))))
        coin.fadeAction = cc.Sequence:create(cc.DelayTime:create((4 + 15 * math.random()) * 0.033), cc.FadeTo:create(0.3, 0))

        -- coin.spreadAction:retain()
        -- coin.fadeAction:retain()

        coin.startScale = startScale
        coin.startOffset = startOffset

        node.coins[i] = coin

        if duration > maxDuration then
            maxDuration = duration
        end

    end

    node.startAction = cc.Sequence:create(cc.CallFunc:create(function()

        for i = 1, node.coin_count, 1 do

            local coin = node.coins[i]

            coin:setVisible(true)
            coin:setOpacity(255)
            coin:setScale(coin.startScale)
            coin:setPosition(coin.startOffset)
            coin:runAction(coin.spreadAction)
            coin:runAction(coin.fadeAction)
            coin:runAction(coin.animate)

        end

    end), cc.DelayTime:create(maxDuration + 0.1), cc.CallFunc:create(function()

        node:removeFromParent()

    end))

    -- node.startAction:retain()

    return node

end

function SlwhBattleCcsView:ShowBossGoldEx(position, zOrder)

    local node = self:createBossGoldAnimation()
    node:setPosition(position)
    node:setLocalZOrder(zOrder)
    node:runAction(node.startAction)

    self:addChild(node)

end

function SlwhBattleCcsView:showGetBonusEffect(amount, duration, delay)

    self:clearBonusEffect()

    local jsonFile = "res/gameres/module/slwh/effect/slwh_cjtips.json"
    local atlasFile = "res/gameres/module/slwh/effect/slwh_cjtips.atlas"

    self.bonusSpine = sp.SkeletonAnimation:create(jsonFile, atlasFile)
    self.bonusSpine:setPosition(cc.p(CONFIG_DESIGN_WIDTH*0.5, CONFIG_DESIGN_HEIGHT*0.5))
    self.bonusSpine:setAnimation(0, "start", false)
    
    self:getParent():addChild(self.bonusSpine, 99999999)

    self.labelNode = cc.Sprite:create()
    self.labelNode.ccsChildren = {}
    self.bonusSpine:addChild(self.labelNode)

    self.labelTitle = cc.Sprite:createWithSpriteFrameName("slwh_battle_bonus_title.png")
    self.labelTitle:setPosition(cc.p(-160, 0))
    self.labelNode:addChild(self.labelTitle)

    self.bonusLabel = ccui.Text:create("", "", 32)
    self.labelNode:addChild(self.bonusLabel, 100000)

    self.bonusLabel:setTextAreaSize(cc.size(3000, 100))
    self.bonusLabel:setText("99999999999999999999999999999999999999999999999999999999999999999999999999")
    self.bonusLabel:setPosition(cc.p(-80, -35))
    self.bonusLabel:setAnchorPoint(0.0, 0.0)

    self.bonusLabel = CCSUtil.changeUILabelWithTextField(self.bonusLabel)
    self.bonusLabel:setVisible(false)

    local txt = ""
    -- txt = txt .. HtmlUtil.createImg("#slwh_battle_bonus_title.png")
    txt = txt .. HtmlUtil.createSpacer(20)
    txt = txt .. HtmlUtil.createArtNumDot(math.floor(amount * 0.3), "#slwh_battle_bonus_%s.png")
    self.bonusLabel:setHtmlText(txt)

    local startTime = TimeApi.getSystemTime()

    self.bonusLabel:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.DelayTime:create(0.033), cc.CallFunc:create(function()

        local currentTime = TimeApi.getSystemTime()
        local percentage = (currentTime - startTime) / 1000 / duration
        local number = amount * 0.3

        if percentage > 1 then
            number = amount
        else
            number = number + math.floor(amount * 0.7 * percentage)
        end
-- number = 9999999999
        local txt = ""
        -- txt = txt .. HtmlUtil.createImg("#slwh_battle_bonus_title.png")
        txt = txt .. HtmlUtil.createSpacer(20)
        txt = txt .. HtmlUtil.createArtNumDot(number, "#slwh_battle_bonus_%s.png")
        self.bonusLabel:setHtmlText(txt)
        self.bonusLabel:setVisible(true)

        local boneData = self.bonusSpine:getBoneData("slwh_cjtipstext")
        self.labelNode:setPosition(cc.p(boneData.x, boneData.y))
        self.labelNode:setScaleX(boneData.scaleX)
        self.labelNode:setScaleY(boneData.scaleY)

    end))))

    local remove = cc.Sequence:create(cc.DelayTime:create(duration + delay), cc.CallFunc:create(function()

        self.bonusSpine:setAnimation(0, "end", false)
        self.labelNode:setCascadeOpacityEnabled(true)
        self.labelNode:runAction(cc.FadeTo:create(0.2, 0))

    end), cc.DelayTime:create(0.5), cc.CallFunc:create(function()

        self:clearBonusEffect()

    end))

    self.bonusSpine:runAction(remove)

    self:playBeanAnimation()

end

function SlwhBattleCcsView:playBeanAnimation(offsetX)

    local addCoins = function()

        for i = 1, 8 do

            local animate = SlwhBattleCcsView.getObjects("res/gameres/module/slwh/spritesheet/slwh_gold.plist", "slwh_jb", 6, "slwh_jbz")
            local coin = cc.Sprite:create()
            coin:setPosition(cc.p(-40 + math.random() * 80, -410))
            coin:setScale(0.35 + math.random() * 0.3)
            coin:setLocalZOrder(-1)
            self.bonusSpine:addChild(coin)
            coin:runAction(cc.Speed:create(animate, 1 + 0.5 * math.random()))

            local distance = -800 + 1600 * math.random()
            coin:runAction(cc.MoveBy:create(0.8, cc.p(distance, 0.0)))

            local height = 250 + math.random() * 150
            local time = 0.2 + math.random() * 0.1
            local sequence = cc.Sequence:create(cc.EaseSineOut:create(cc.MoveBy:create(time, cc.p(0, height))), cc.EaseSineIn:create(cc.MoveBy:create(time + 0.3, cc.p(0, -height - 250))), cc.RemoveSelf:create())

            coin:runAction(sequence)
            -- assert(false)
        end

    end

    self.bonusSpine:runAction(cc.Repeat:create(cc.Sequence:create(cc.DelayTime:create(0.066), cc.CallFunc:create(function()

        addCoins()

    end)), 8))

end

function SlwhBattleCcsView:clearBonusEffect()

    if self.bonusSpine then
        self.bonusSpine:removeFromParent()
        self.bonusSpine = nil
    end

end