--
-- Author: Your Name
-- Date: 2014-12-23 10:51:36
--

local packageName = "game.battle."

GameLuaLoader:loadGameBattleTools()
GameLuaLoader:loadGameBattleDatas()
GameLuaLoader:loadGameBattleControlers()
GameLuaLoader:loadGameBattleModels()
GameLuaLoader:loadGameBattleObjects()
GameLuaLoader:loadGameBattleViews()
GameLuaLoader:loadGameBattleExpands()


