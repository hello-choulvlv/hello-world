--登录相关事件
local LogEvent = {}

--日志发生变更
LogEvent.LOGEVENT_LOG_CHANGE = "LOGEVENT_LOG_CHANGE"

return LogEvent