--
-- Author: xd
-- Date: 2016-01-18 11:47:23
--

local DefenderEvent = {}

-- DefenderEvent.DefenderEvent_MODEL_UPDATE = "DefenderEvent_MODEL_UPDATE" 


return DefenderEvent
