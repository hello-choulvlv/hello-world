--版本管理事件
local VersionEvent = {}

--检查版本
VersionEvent.VERSIONEVENT_CHECK_VERSION = "VERSIONEVENT_CHECK_VERSION"

--下载更新包
VersionEvent.VERSIONEVENT_UPDATE_PACKAGE = "VERSIONEVENT_UPDATE_PACKAGE"


return VersionEvent