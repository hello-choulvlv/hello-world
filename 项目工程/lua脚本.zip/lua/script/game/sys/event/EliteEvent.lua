
local EliteEvent = EliteEvent or {}

EliteEvent.ELITE_CHALLENGE_SUCCEED = "ELITE_CHALLENGE_SUCCEED"
EliteEvent.ELITE_UNIT_TONGGUAN = "ELITE_UNIT_TONGGUAN"
EliteEvent.ELITE_UNIT_SHUAXIN = "ELITE_UNIT_SHUAXIN"

return EliteEvent


