
--充值相关事件
local ChargeEvent = {}

ChargeEvent.GET_FIRST_CHARGE_REWARD_EVENT = "GET_FIRST_CHARGE_REWARD_EVENT";
ChargeEvent.CHARGE_EVENT = "CHARGE_EVENT";

return ChargeEvent


