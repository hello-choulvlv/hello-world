--主角系统相关事件
local CharEvent = {}

--天赋发生了变化
CharEvent.CHAREVENT_TALENT_CHANGE = "CHAREVENT_TALENT_CHANGE"


return CharEvent