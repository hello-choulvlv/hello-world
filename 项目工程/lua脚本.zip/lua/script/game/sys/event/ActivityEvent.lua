local ActivityEvent = {}

ActivityEvent.ACTEVENT_FINISH_TASK_OK = "ACTEVENT_FINISH_TASK_OK"

return ActivityEvent
