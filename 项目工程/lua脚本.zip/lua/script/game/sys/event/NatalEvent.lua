--//本命法宝事件
local   NatalEvent=NatalEvent or {};

NatalEvent.NATAL_TRUESURE_CHANGLED="NATAL_TRUESURE_CHANGED"--本命法宝的数目发生了变化
NatalEvent.TALENT_NUMBER_CHANGED="TALENT_NUMBER_CHANGED"--天赋数目发生了变化

return  NatalEvent;