--//好友事件
--//2016-5-4
--author xiaohuaxiong
local    FriendEvent=FriendEvent or {};

FriendEvent.FRIEND_SEND_SP_UPDATE="friend_send_sp_update";--//好友体力赠送
FriendEvent.FRIEND_APPLY_REQUEST="friend_apply_request";--//好友申请请求

FriendEvent.FRIEND_REMOVE_SOME_PLAYER = "friend_remove_some_player"
return  FriendEvent;