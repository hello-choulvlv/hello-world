--用户扩展系统相关事件
local UserExtEvent = {}

--更新了UserExtModel的数据
UserExtEvent.USEREXTEVENT_MODEL_UPDATE = "USEREXTEVENT_MODEL_UPDATE"

return UserExtEvent

