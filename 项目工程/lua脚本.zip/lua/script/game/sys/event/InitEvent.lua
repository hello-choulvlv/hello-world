local InitEvent = {}

InitEvent.INITEVENT_FUNC_INIT = "INITEVENT_FUNC_INIT"

return InitEvent
