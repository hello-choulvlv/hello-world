local YongAnGambleEvent = {}

YongAnGambleEvent.GET_NEW_BONUS_OK = "GET_NEW_BONUS_OK"
YongAnGambleEvent.YONGANGAMBLEEVENT_LEFT_PLAY_COUNT_CHANGE = "YONGANGAMBLEEVENT_LEFT_PLAY_COUNT_CHANGE" --剩余次数变化

return YongAnGambleEvent
