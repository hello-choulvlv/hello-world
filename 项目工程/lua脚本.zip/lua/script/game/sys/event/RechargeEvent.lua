
local RechargeEvent = {}

RechargeEvent.FINISH_RECHARGE_EVENT = "FINISH_RECHARGE_EVENT";

return RechargeEvent


