--
-- Author: xd
-- Date: 2016-01-18 11:47:23
--

local CountEvent = {}

CountEvent.COUNTEVENT_MODEL_UPDATE = "COUNTEVENT_MODEL_UPDATE" 


return CountEvent
