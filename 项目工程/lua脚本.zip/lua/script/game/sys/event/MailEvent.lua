--
-- Author: xd
-- Date: 2016-01-14 17:54:25
--
local MailEvent = MailEvent or {}

--收到邮件 -- 参数邮件列表 
MailEvent.MAILEVENT_UPDATEMAIL = "MAILEVENT_UPDATEMAIL"
MailEvent.MAILEVENT_DELMAIL = "MAILEVENT_DELMAIL"
MailEvent.MAILEVENT_NEWMAIL = "MAILEVENT_NEWMAIL"


return MailEvent 

