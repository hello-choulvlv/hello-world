--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
local StarlightEvent = {} 

StarlightEvent.STARLIGHT_EVENT_UPDATE = "STARLIGHT_EVENT_UPDATE"

return StarlightEvent
--endregion
