
local HappySignEvent = {}

HappySignEvent.RED_POINT_EVENT = "RED_POINT_EVENT";
HappySignEvent.FINISH_ALL_SIGN_EVENT = "FINISH_ALL_SIGN_EVENT";

return HappySignEvent


