--//聊天事件
--//2016-5-10
--//author:xiaohuaxiong
local   ChatEvent=ChatEvent or {};

ChatEvent.WORLD_CHAT_CONTENT_UPDATE="world_chat_content_update"--世界聊天内容更新
ChatEvent.LEAGUE_CHAT_CONTENT_UPDATE="league_chat_content_update"--联盟聊天内容更新
ChatEvent.PRIVATE_CHAT_CONTENT_UPDATE="private_chat_content_update"--私人聊天 内容更新

return  ChatEvent;