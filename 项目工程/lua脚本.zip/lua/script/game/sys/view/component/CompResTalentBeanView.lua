-- Author: ZhangYanguang
-- Date: 2017-01-13
-- 主角天赋点

local CompResTalentBeanView = class("CompResTalentBeanView", UIBase);

function CompResTalentBeanView:ctor(winName)
    CompResTalentBeanView.super.ctor(self, winName);

end

function CompResTalentBeanView:loadUIComplete()
	
end 

function CompResTalentBeanView:registerEvent()

end


function CompResTalentBeanView:initData(playerData)

end

function CompResTalentBeanView:initView(playerData)

end

return CompResTalentBeanView