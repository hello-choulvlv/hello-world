--
-- Author: xd
-- Date: 2016-02-11 18:44:41
--动态背景框21
local  DynamicBgView = class("DynamicBgView",BackGroundBase)

return DynamicBgView