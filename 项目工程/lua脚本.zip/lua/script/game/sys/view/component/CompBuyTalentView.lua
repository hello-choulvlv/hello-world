--//购买天赋
--//2016-6-2 10:35:05
--//小花熊
local  CompBuyTalentView=class("CompBuyTalentView",UIBase);

function CompBuyTalentView:ctor(_name)
   
end
--//
function CompBuyTalentView:loadUIComplete()

end

return CompBuyTalentView;