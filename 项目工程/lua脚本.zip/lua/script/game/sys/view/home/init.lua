FriendPlayer = require("game.sys.view.home.FriendPlayer");
HomeMapLayer = require("game.sys.view.home.HomeMapLayer");
Player = require("game.sys.view.home.Player");
FriendPlayerStrollAI = require("game.sys.view.home.OtherPlayerAI");


