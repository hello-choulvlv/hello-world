local packageName = "game.sys.view.base."

UIBase=require(packageName.."UIBase")
ItemBase=require(packageName.."ItemBase")
BackGroundBase=require(packageName.."BackGroundBase")

MultiScrollBaseView=require(packageName.."MultiScrollBaseView")
InfoTipsBase=require(packageName.."InfoTipsBase")
