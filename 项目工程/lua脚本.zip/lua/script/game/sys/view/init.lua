local packageName = "game.sys.view."
require(packageName.."WindowsCfgs")
require(packageName.."BattleMapCfgs")
require(packageName.."base.init")
require(packageName.."common.init")
