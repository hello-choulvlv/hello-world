-- region *.lua
-- Date
-- 此文件由[BabeLua]插件自动生成
local TowerControl = class("TowerControl")


function TowerControl:ctor()
end 

function TowerControl:initData()
	self.battleID = 0
end 



return TowerControl.new()

