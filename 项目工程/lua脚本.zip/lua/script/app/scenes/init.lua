require("app.scenes.SceneSwitch")
require("app.scenes.SceneBase")

SceneBase = require("app.scenes.SceneBase")
SceneMain = require("app.scenes.SceneMain")