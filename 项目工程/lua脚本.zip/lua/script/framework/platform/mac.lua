
if cc.bPlugin_ then
	luaoc = require("framework.luaoc")
else
	-- luaoc = require(cc.PACKAGE_NAME .. ".luaoc")
end
