/*
  *3d模型批处理渲染命令实现
 */
#include "renderer/CCMeshBatchCommand.h"
#include "base/ccMacros.h"
#include "base/CCConfiguration.h"
#include "base/CCDirector.h"
#include "base/CCEventCustom.h"
#include "base/CCEventListenerCustom.h"
#include "base/CCEventDispatcher.h"
#include "base/CCEventType.h"
#include "2d/CCLight.h"
#include "renderer/ccGLStateCache.h"
#include "renderer/CCGLProgramState.h"
#include "renderer/CCRenderer.h"
#include "renderer/CCTextureAtlas.h"
#include "renderer/CCTexture2D.h"
#include "renderer/CCTechnique.h"
#include "renderer/CCMaterial.h"
#include "renderer/CCPass.h"
#include "xxhash/xxhash.h"
#include "math/MathUtil.h"

NS_CC_BEGIN

//static void mesh_mat4_multiply_mat4(Mat4  &src1,const Mat4 &src2, Mat4 &dst);

MeshBatchCommand::MeshBatchCommand()
	: _textureID(0)
    ,_texture2DArrayID(0)
	, _glProgramState(nullptr)
	, _displayColor(1.0f, 1.0f, 1.0f, 1.0f)
	, _matrixPalette(nullptr)
	, _matrixPaletteSize(0)
	, _materialID(0)
	, _vao(0)
	, _material(nullptr)
	, _stateBlock(nullptr)
	,_supportTextureArray(false)
	, _textureIDArraySize(0)
	,_textureArrayLoc(-1)
    ,_texture2DArrayLoc(-1)
	, _supportMVPMatrix(false)
	,_modelViewProjLoc(-1)
{
	_type = RenderCommand::Type::MESH_BATCH_COMMAND;

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	// listen the event that renderer was recreated on Android/WP8
	_rendererRecreatedListener = EventListenerCustom::create(EVENT_RENDERER_RECREATED, CC_CALLBACK_1(MeshBatchCommand::listenRendererRecreated, this));
	Director::getInstance()->getEventDispatcher()->addEventListenerWithFixedPriority(_rendererRecreatedListener, -1);
#endif
}

void MeshBatchCommand::init(float globalZOrder,
	Material* material,
	GLuint vertexBuffer,
	GLuint indexBuffer,
	GLenum primitive,
	GLenum indexFormat,
    int32_t indexCount,
	cocos2d::Mat4 *mv,
	int  mvCount,
	uint32_t flags)
{
	CCASSERT(material, "material cannot be null");

	RenderCommand::init(globalZOrder, *mv, flags);

	_globalOrder = globalZOrder;
	_material = material;

	_vertexBuffer = vertexBuffer;
	_indexBuffer = indexBuffer;
	_primitive = primitive;
	_indexFormat = indexFormat;
	_indexCount = indexCount;
	//_mv.set(mv);
	_modelViewProj = mv;
	_mvpMatCount = mvCount;

	_skipBatching = true;
	_is3D = true;
}

void MeshBatchCommand::init(float globalZOrder,
	GLuint textureID,
	GLProgramState* glProgramState,
	RenderState::StateBlock* stateBlock,
	GLuint vertexBuffer,
	GLuint indexBuffer,
	GLenum primitive,
	GLenum indexFormat,
	int32_t indexCount,
	cocos2d::Mat4 *mv,
	int  mvCount,
	uint32_t flags)
{
	CCASSERT(glProgramState, "GLProgramState cannot be null");
	CCASSERT(stateBlock, "StateBlock cannot be null");
	CCASSERT(!_material, "cannot init with GLProgramState if previously inited without GLProgramState");

	RenderCommand::init(globalZOrder, *mv, flags);

	_globalOrder = globalZOrder;
	_textureID = textureID;

	// weak ref
	_glProgramState = glProgramState;
	_stateBlock = stateBlock;

	_vertexBuffer = vertexBuffer;
	_indexBuffer = indexBuffer;
	_primitive = primitive;
	_indexFormat = indexFormat;
	_indexCount = indexCount;
	//_mv.set(*mv);

	_is3D = true;
	_skipBatching = true;
}


void MeshBatchCommand::setDisplayColor(const Vec4& color)
{
	CCASSERT(!_material, "If using material, you should set the color as a uniform: use u_color");

	_displayColor = color;
}

void MeshBatchCommand::setMatrixPalette(const Vec4* matrixPalette)
{
	CCASSERT(!_material, "If using material, you should set the color as a uniform: use u_matrixPalette");

	_matrixPalette = matrixPalette;
}

void MeshBatchCommand::setMatrixPaletteSize(int size)
{
	CCASSERT(!_material, "If using material, you should set the color as a uniform: use u_matrixPalette with its size");

	_matrixPaletteSize = size;
}

MeshBatchCommand::~MeshBatchCommand()
{
	releaseVAO();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	Director::getInstance()->getEventDispatcher()->removeEventListener(_rendererRecreatedListener);
#endif
}

void MeshBatchCommand::applyRenderState()
{
	CCASSERT(!_material, "Must not be called when using materials");
	CCASSERT(_stateBlock, "StateBlock must be non null");

	// blend and texture
	GL::bindTexture2D(_textureID);

	_stateBlock->bind();
}

void  MeshBatchCommand::setTextureArray(const std::map<int,int> &texture_array)
{
	_textureIDArraySize = (int32_t)texture_array.size();
	for (auto it = texture_array.cbegin(); it != texture_array.cend(); ++it)
	{
		_textureIDArray[it->second] = it->first;
	}
}

void MeshBatchCommand::preBatchDraw()
{
	// Do nothing if using material since each pass needs to bind its own VAO
	if (!_material)
	{
		if (Configuration::getInstance()->supportsShareableVAO() && _vao == 0)
			buildVAO();
		if (_vao)
		{
			GL::bindVAO(_vao);
		}
		else
		{
			glBindBuffer(GL_ARRAY_BUFFER, _vertexBuffer);

			// FIXME: Assumes that all the passes in the Material share the same Vertex Attribs
			GLProgramState* programState = _material? _material->_currentTechnique->_passes.at(0)->getGLProgramState() : _glProgramState;
			programState->applyAttributes();
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBuffer);
		}
	}
}

void MeshBatchCommand::batchDraw()
{
	if (_material)
	{
		const Mat4  &matProj = Director::getInstance()->getMatrix(MATRIX_STACK_TYPE::MATRIX_STACK_PROJECTION);
		Pass  *pass = _material->_currentTechnique->_passes.at(0);

		pass->bind(_mv);
		//如果支持MVP矩阵
		if (_supportMVPMatrix)
		{
			for (int k = 0; k < _mvpMatCount; ++k)
                MathUtil::multiplyMatrix(matProj.m, _modelViewProj[k].m, _modelViewProj[k].m);
		}
		glUniformMatrix4fv(_modelViewProjLoc, _mvpMatCount, GL_FALSE, (float*)_modelViewProj);
		/*
		  *如果支持纹理单元
		 */
		if (_supportTextureArray)
		{
            if(_textureArrayLoc != -1){
                int  texture_location[16];
                for (int k = 0; k < _textureIDArraySize; ++k)
                {
                    GL::bindTexture2DN(k, _textureIDArray[k]);
                    texture_location[k] = k;
                }
                glUniform1iv(_textureArrayLoc, _textureIDArraySize, texture_location);
            }
            else{
                GL::bindTextureN(0, _texture2DArrayID,GL_TEXTURE_2D_ARRAY);
                glUniform1i(_texture2DArrayLoc,0);
            }
			if(_textureIndexArrayLoc != -1)
                glUniform1iv(_textureIndexArrayLoc,_mvpMatCount,_textureIndexArray);
		}
		glDrawElementsInstanced(_primitive, _indexCount, _indexFormat, nullptr,_mvpMatCount);
		CC_INCREMENT_GL_DRAWN_BATCHES_AND_VERTICES(1, _indexCount * _mvpMatCount);

		pass->unbind();

		GL::setDepthTest(false);
		//glDisable(GL_DEPTH_TEST);
		RenderState::StateBlock::_defaultState->setDepthTest(false);
	}
}
void MeshBatchCommand::postBatchDraw()
{
	// when using material, unbind is after draw
	if (!_material)
	{
		if (_vao)
		{
			GL::bindVAO(0);
		}
		else
		{
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
		}

		// restore the default state since we don't know
		// if the next command will need the default state or not
		RenderState::StateBlock::restore(0);
	}
}

void MeshBatchCommand::buildVAO()
{
	// FIXME: Assumes that all the passes in the Material share the same Vertex Attribs
	GLProgramState* programState = _material ? _material->_currentTechnique->_passes.at(0)->getGLProgramState(): _glProgramState;

	releaseVAO();
	glGenVertexArrays(1, &_vao);
	GL::bindVAO(_vao);
	glBindBuffer(GL_ARRAY_BUFFER, _vertexBuffer);
	auto flags = programState->getVertexAttribsFlags();
	for (int i = 0; flags > 0; i++) {
		int flag = 1 << i;
		if (flag & flags)
			glEnableVertexAttribArray(i);
		flags &= ~flag;
	}
	programState->applyAttributes(false);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _indexBuffer);

	GL::bindVAO(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}
void MeshBatchCommand::releaseVAO()
{
	if (_vao)
	{
		glDeleteVertexArrays(1, &_vao);
		_vao = 0;
		GL::bindVAO(0);
	}
}

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
void MeshBatchCommand::listenRendererRecreated(EventCustom* event)
{
	_vao = 0;
}

#endif

NS_CC_END
