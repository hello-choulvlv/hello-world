/*
  *3D模型批处理渲染命令
  *2019年1月3日
  *@author:xiaoxiong
 */
#ifndef _CC_MESH_BATCH_COMMAND_H_
#define _CC_MESH_BATCH_COMMAND_H_
#include <unordered_map>
#include "renderer/CCRenderCommand.h"
#include "renderer/CCGLProgram.h"
#include "renderer/CCRenderState.h"
#include "math/CCMath.h"
#include<map>
NS_CC_BEGIN

class GLProgramState;
class EventListenerCustom;
class EventCustom;
class Material;

//it is a common mesh
class CC_DLL MeshBatchCommand : public RenderCommand
{
public:

	MeshBatchCommand();
	virtual ~MeshBatchCommand();

	void init(float globalZOrder, Material* material, GLuint vertexBuffer, GLuint indexBuffer, GLenum primitive, GLenum indexFormat, int32_t indexCount, Mat4 *mv, int matCount,uint32_t flags);

	void init(float globalZOrder, GLuint textureID, GLProgramState* glProgramState, RenderState::StateBlock* stateBlock, GLuint vertexBuffer, GLuint indexBuffer, GLenum primitive, GLenum indexFormat, int32_t indexCount, Mat4 *mv, int  mvCount,uint32_t flags);

	void setDisplayColor(const Vec4& color);
	void setMatrixPalette(const Vec4* matrixPalette);
	void setMatrixPaletteSize(int size);
	void setLightMask(unsigned int lightmask);

	//设置是否使用MVP矩阵
	void setSupportMVPMatrix(bool b) { _supportMVPMatrix = b; };
	//设置MVP矩阵的位置,如果不支持MVP矩阵,则为模型矩阵的位置
	void setMVPMatrixLoc(int  location) { _modelViewProjLoc = location; };

	//是否支持纹理数组
	void setSupportTextureArray(bool b) { _supportTextureArray = b; };
	//设置纹理数组的位置
	void setTextureArrayLoc(int location) { _textureArrayLoc = location; };
    void setTexture2DArrayLoc(int location){_texture2DArrayLoc = location;};
	/*纹理数组的索引序列*/
	void setTextureIndexArrayLoc(int location) { _textureIndexArrayLoc = location; };
	/*设置使用的纹理数组*/
	void setTextureArray(const std::map<int,int> &texture_array);
    //使用纹理阵列
    void setTexture2DArray(GLuint texture2D_array){_texture2DArrayID = texture2D_array;};

	/*设置纹理索引的层*/
    void setTextureIndexArray(int  *texture_indexArray, int  texture_size,bool texture_array = true) { _textureIndexArray = texture_indexArray; _textureIndexCount = texture_size; _isTextureArray = texture_array;};

	//used for batch
	void preBatchDraw();
	void batchDraw();
	void postBatchDraw();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	void listenRendererRecreated(EventCustom* event);
#endif

protected:
	//build & release vao
	void buildVAO();
	void releaseVAO();

	// apply renderstate, not used when using material
	void applyRenderState();


	Vec4 _displayColor; // in order to support tint and fade in fade out

						// used for skin
	const Vec4* _matrixPalette;
	int   _matrixPaletteSize;

	uint32_t _materialID; //material ID

	GLuint   _vao; //use vao if possible

	GLuint _vertexBuffer;
	GLuint _indexBuffer;
	GLenum _primitive;
	GLenum _indexFormat;
	int32_t _indexCount;

	// States, default value all false


	// ModelView transform
	Mat4 _mv;

	// Mode A: Material
	// weak ref
	Material* _material;

	// Mode B: StateBlock
	// weak ref
	GLProgramState* _glProgramState;
	RenderState::StateBlock* _stateBlock;
	GLuint _textureID,_texture2DArrayID;
	/*
	  *选择的textureId
	 */
	GLuint   _textureIDArray[16];
	int           _textureIDArraySize;
	int           _textureArrayLoc;
    int          _texture2DArrayLoc;
	int           _textureIndexArrayLoc;
	bool        _supportTextureArray,_isTextureArray;
	/*
	  *纹理的层索引数组
	 */
	int           *_textureIndexArray;
	int           _textureIndexCount;
	/*
	  *模型视图投影矩阵数组序列
	 */
	Mat4      *_modelViewProj;
	int           _mvpMatCount;

	//  *是否直接使用MVP矩阵
	bool        _supportMVPMatrix;
	int           _modelViewProjLoc;

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID || CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	EventListenerCustom* _rendererRecreatedListener;
#endif
};
NS_CC_END
#endif
