Auto install: 
#1. Just double click install.bat script to install this patch for BabeLua.

V1.06: fix try Get Lua modules, prompt when use static link with lua script engine!
V1.05: Add 1K install script.
V1.04: Optimize LUA-symbols load strategy, Load cached symbols --> Load LUA-symbols by specific lua modules(lua51.dll,lua52.dll,lua53.dll,slua.dll,ulua.dll,liblua51.dll,liblua52.dll,liblua53.dll) -->  analyze all dependent moduels
V1.01: Add capture log support.

@Good Luck.
