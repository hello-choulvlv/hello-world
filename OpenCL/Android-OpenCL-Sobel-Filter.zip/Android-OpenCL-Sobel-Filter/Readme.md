<h3>Android OpenCL Sobel Filter:</h3>
	This is a sobel filter on Android using OpenCL to accelerate.
	To compile this project,you should using Android NDK and OpenCV-Android.
	To run this application on your device,you should install OpenCV Manager first.
	This code is written by Zhangxi Yan,Shuai Wang and Tong Zhou from Xidian University.
	If you have any question,please contact me by e-mail:	whiteIsClose@gmail.com.
	Enjoy!