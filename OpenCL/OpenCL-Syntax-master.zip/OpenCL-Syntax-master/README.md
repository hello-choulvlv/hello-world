#Syntax file for OpenCL 1.2

Place the OpenCL dir in ~/Library/Application Support/Sublime Text 2/Packages/

This has only been tested in Sublime 2 but could work in TextMate as well.
