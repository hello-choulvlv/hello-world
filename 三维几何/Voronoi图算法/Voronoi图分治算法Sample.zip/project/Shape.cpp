#include "StdAfx.h"
#include "Shape.h"

extern void DPtoVP(float x, float y, int *X, int *Y);
extern void VPtoDP(int x, int y, float *X, float *Y);
//CGraphPara *p_GraphPara = m_pGraphPara;
//////////////////////////////////////////////////////////////////////////////////
//Draw��
//////////////////////////////////////////////////////////////////////////////////
CGraphPara::CGraphPara()
{
	m_iColorNumbAll = 100;  //������100����ɫ
	m_lColorList = new long[m_iColorNumbAll];
	m_iColorNumb = 6;
	//��ʼ����ɫ
	m_lColorList[0] = RGB(0, 0, 0);  //��ɫ
	m_lColorList[1] = RGB(255, 255, 255);  //��ɫ
	m_lColorList[2] = RGB(255, 0, 0);  //����ߵ���ɫ����ɫ
	m_lColorList[3] = RGB(0, 255, 0);  //�ұ��ߵ���ɫ����ɫ
	m_lColorList[4] = RGB(0, 0, 255);  //�����ߵ���ɫ����ɫ
	m_lColorList[5] = RGB(120, 200, 20);
}

COLORREF CGraphPara::GetColor(int n)
{
	return m_lColorList[n];
}

void CDraw::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_bDelete << m_sColorPen << m_sColorBrush << m_sLineWide <<
			  m_sLineType << m_iID;
	} 
	else
	{
        ar >> m_bDelete >> m_sColorPen >> m_sColorBrush >> m_sLineWide >>
			  m_sLineType >> m_iID;
	}
}

COLORREF CDraw::GetColor(int n)
{
	return m_lColorList[n];
}

IMPLEMENT_SERIAL(CPt, CObject, 1)
void CPt::Draw(CDC *pDC, int DrawModel, short Color)
{
	int x, y;

	if (m_bDelete)
	{
		return;
	}
	short ColorPen = m_sColorPen;
	if (DrawModel == 2)
    {
		ColorPen = Color;
	}

	CPen *pen;
	if (DrawModel == 0)
	{
		pen = new CPen(PS_SOLID, (int)(m_sLineWide + 2), RGB(180,0,0));
	} 
	else if (DrawModel == 1)
	{
		pen = new CPen(PS_SOLID, (int)(m_sLineWide + 4), RGB(0, 100, 100));
	}
	
	CPen *pOldPen = pDC->SelectObject(pen);
    DPtoVP(m_fX, m_fY, &x, &y);
	pDC->MoveTo(x, y);
	pDC->LineTo(x, y);
	pDC->SelectObject(pOldPen);
}

CPt* CPt::operator = (CPt *rPT)
{
    m_sColorPen = rPT->m_sColorPen;
	m_sColorPen = rPT->m_sColorBrush;
	m_sLineWide = rPT->m_sLineWide;
	m_sLineType = rPT->m_sLineType;
	m_iID = rPT->m_iID;
	m_bDelete = rPT->m_bDelete;
	m_fX = rPT->m_fX;
	m_fY = rPT->m_fY;
	return this;
}

void CPt::Serialize(CArchive& ar)
{
	CDraw::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_fX << m_fY;
	} 
	else
	{
		ar >> m_fX >> m_fY;
	}
}

IMPLEMENT_SERIAL(CLine, CObject, 1)
void CLine::Draw(CDC *pDC, int DrawModel, short Color)
{
	int x1, y1, x2, y2;
	
	short LineType = PS_SOLID;
	short ColorPen = m_sColorPen;
	
	if (m_bDelete)
	{
		return;
	}

    
	CPen pen((int)LineType, (int)m_sLineWide, GetColor(Color-1));
	CPen *pOldPen = pDC->SelectObject(&pen);
	DPtoVP(m_fX1, m_fY1, &x1, &y1);
	DPtoVP(m_fX2, m_fY2, &x2, &y2);
	pDC->MoveTo(x1, y1);
	pDC->LineTo(x2, y2);
	pDC->SelectObject(pOldPen);
} 

void CLine::Serialize(CArchive& ar)
{
	CDraw::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_fX1 << m_fY1 << m_fX2 << m_fY2;
	} 
	else
	{
		ar >> m_fX1 >> m_fY1 >> m_fX2 >> m_fY2;
	}
}
