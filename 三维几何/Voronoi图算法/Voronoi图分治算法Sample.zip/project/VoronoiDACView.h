// VoronoiDACView.h : interface of the CVoronoiDACView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_VORONOIDACVIEW_H__A131A9ED_06ED_4A15_9E51_0D5F4ABFB0B8__INCLUDED_)
#define AFX_VORONOIDACVIEW_H__A131A9ED_06ED_4A15_9E51_0D5F4ABFB0B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WM_DRAWLINEMSG (WM_USER + 101)
//վ��ṹ
/*typedef struct tagSite{
    int id;
	float x;
	float y;
}site;*/

class Site //: public CPoint
{
public:
	Site()
	{
		m_iID = 0;
		m_fX = 0.0;
		m_fY = 0.0;
	}

	int m_iID;
	float m_fX;
	float m_fY;
};

class CVoronoiDACView : public CView
{
protected: // create from serialization only
	CVoronoiDACView();
	DECLARE_DYNCREATE(CVoronoiDACView)

// Attributes
public:
	CVoronoiDACDoc* GetDocument();
    
// Operations
public:
	void AddPoint(CPoint point);
	void DrawLineDynamic(CPoint sPT, CPoint ePT);
	void FlashLine(CPoint sPT, CPoint ePT);
	void DrawCross(CPoint pt);
	void DrawLine(CPoint sPT, CPoint ePT);
	void CutLine(CPoint sPT, CPoint ePT);

	void RedrawGraph();  //�ػ��ӿ�

	void DPtoVP(float x, float y, int *X, int *Y);  //ʵ������->�߼�����
	void VPtoDP(int x, int y, float *X, float *Y);  //�߼�����->ʵ������

	void Init();
	
	CArray<Site, Site> m_pointArray;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVoronoiDACView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CVoronoiDACView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	int m_iPrevX;
	int m_iPrevY;
	CPen *m_pRedPen, *m_pBluePen, *m_pGreenPen, *m_pWhitePen, *m_pBlackPen;
	int m_iSiteID;
	BOOL m_bPaintPt;

private:
	float m_fXStart, m_fYStart;  //�洢��Ļ���½ǵ�ʵ������
	float m_fBLC;  //ת��������
	int m_iWScreen, m_iHScreen;  //��ͼ��Ļ��ʵ�ʿ��Ⱥ͸߶�(�߼�����)
	int m_iMapMode;  //��ǰӳ��ģʽ

	short m_sBKColor;  //��ɫ
	short m_sPColor;  //��ǰ������ɫ���
	short m_sBColor;  //��ǰ��ˢ��ɫ���
	short m_sLineWide;
	short m_sLineType;

	BOOL m_bIsStep;  //�Ƿ�����ʾ
	
// Generated message map functions
protected:
	//{{AFX_MSG(CVoronoiDACView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg LRESULT OnDrawLineMsg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnOperationReset();
	afx_msg void OnUpdateOperationReset(CCmdUI* pCmdUI);
	afx_msg void OnOperationStart();
	afx_msg void OnUpdateOperationStart(CCmdUI* pCmdUI);
	afx_msg void OnOperationClear();
	afx_msg void OnUpdateOperationClear(CCmdUI* pCmdUI);
	afx_msg void OnOperationBack();
	afx_msg void OnUpdateOperationBack(CCmdUI* pCmdUI);
	afx_msg void OnOperationStep();
	afx_msg void OnUpdateOperationStep(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in VoronoiDACView.cpp
inline CVoronoiDACDoc* CVoronoiDACView::GetDocument()
   { return (CVoronoiDACDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VORONOIDACVIEW_H__A131A9ED_06ED_4A15_9E51_0D5F4ABFB0B8__INCLUDED_)
