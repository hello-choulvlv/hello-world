#include "StdAfx.h"
#include "iostream"
#include "stdio.h"
#include "conio.h"
#include "malloc.h"
#include "ConvexHull.h"


//struct edge;
//struct site;
//struct vertex;
//struct face ;




//�ж�(x3,y3)�ǲ�����(x1,y1)(x2,y2)���ߵ����.��(x1,y1)Ϊ������.
int ToLeft(double x1 , double y1, double x2, double y2, double x3, double y3)
{
/*
 (
			a.x * b.y - a.y * b.x
		+	b.x * c.y - b.y * c.x
		+	c.x * a.y - c.y * a.x);
 */
		double itemp =	   x1 * y2 - y1 * x2 
					+  x2 * y3 - y2 * x3
					+  x3 * y1 - y3 * x1;
		return itemp <= 0 ;
}

int side_to_left(const site *a, const site *b, const site *c) 
{
	double x1 = a->x;
	double y1 = a->y;

	double x2 = b->x;
	double y2 = b->y;

	double x3 = c->x;
	double y3 = c->y;

	double itemp = x1 * y2 - y1 * x2
		+ x2 * y3 - y2 * x3
		+ x3 * y1 - y3 * x1;
	return itemp <= 0;
}

float dot(const Vec2 &a, Vec2 &b)
{
	return a.x * b.x + a.y * b.y;
}

float length2(const Vec2 &a)
{
	return a.x * a.x + a.y * a.y;
}

float  length2(const Vec2 &a, const Vec2 &b)
{
	float d_x = b.x - a.x;
	float d_y = b.y - a.y;
	return d_x * d_x + d_y * d_y;
}

float length(const Vec2 &a, const Vec2 &b)
{
	float d_x = b.x - a.x;
	float d_y = b.y - a.y;
	return sqrtf(d_x * d_x + d_y * d_y);
}

float length(const Vec2 &a)
{
	return sqrtf(a.x * a.x + a.y * a.y);
}

float cross(const Vec2 &a, const Vec2 &b)
{
	return a.x * b.y - a.y * b.x;
}

float cross(const Vec2 &base, const Vec2 &fc1, const Vec2 &fc2)
{
	return	(fc1.x - base.x) * (fc2.y - base.y) - (fc1.y - base.y) * (fc2.x - base.x);
}

float sign_area(const Vec2 &db, const Vec2 &dc)
{
	return db.x * dc.y - db.y * dc.x;
}

convex::convex()
{
	m_pFirstPoint		= NULL;
	m_iCount = 0;
	m_pLeftMostPoint	= NULL;
	m_pRightMostPoint	= NULL;

}

convex::convex( int iCount)
{
	//Ϊ�����ռ�
	m_pFirstPoint = (point_chain *)malloc(iCount * sizeof(point_chain));
	m_iCount = 0;
	//��ʼ��,���ұߺ�����ߵĵ�Ϊ��
	m_pLeftMostPoint	= NULL;
	m_pRightMostPoint	= NULL;
}

//�������㹹��һ��͹��
convex::convex( site * pFirstSite ,   site * pSecondSite ,  site * pThirdSite)
{
	//��������Ԫ��
	point_chain * pFirstChain  = new point_chain;
	point_chain * pSecondChain = new point_chain;
	point_chain * pThirdChain  = new point_chain;

//	 site * pLeftSite ;
//	 site * pMidSite	 ;
//	 site * pRightSite;

	pFirstChain->pSite  = pFirstSite;
	pSecondChain->pSite = pSecondSite;
	pThirdChain->pSite  = pThirdSite;

	//���pThirdSite�ڵ�һ�����ڶ��������ߵ���࣬��ʱ�������㽫����ʱ������.
	//�����Ľ����,�����˳ʱ������
	if (ToLeft(pFirstSite->x,pFirstSite->y,pSecondSite->x,pSecondSite->y,pThirdSite->x,pThirdSite->y) > 0)
	{
		pThirdChain->next	= pSecondChain;
		pSecondChain->next	= pFirstChain;
		pFirstChain->next	= pThirdChain;
	

		pFirstChain->previous	 = pSecondChain;
		pSecondChain->previous	 = pThirdChain;
		pThirdChain->previous	 = pFirstChain;
	}
	else
	{
		pThirdChain->next	= pFirstChain;
		pSecondChain->next	= pThirdChain;
		pFirstChain->next	= pSecondChain;
	

		pFirstChain->previous	 = pThirdChain;
		pSecondChain->previous	 = pFirstChain;
		pThirdChain->previous	 = pSecondChain;
	}
	
	
	
	if (pFirstSite->x < pSecondSite->x ||( pFirstSite->x == pSecondSite->x && pFirstSite->y < pSecondSite->y))
	{
		m_pLeftMostPoint	=	pFirstChain;
	}
	else
	{
		m_pLeftMostPoint	=	pSecondChain;
	}
	
	if (m_pLeftMostPoint->pSite->x > pThirdSite->x || (m_pLeftMostPoint->pSite->x == pThirdSite->x) && m_pLeftMostPoint->pSite->y > pThirdSite->y)
	{
		m_pLeftMostPoint	=	pThirdChain;
	}



	//���ұ�
	if (pFirstSite->x > pSecondSite->x ||( pFirstSite->x == pSecondSite->x && pFirstSite->y > pSecondSite->y))
	{
		m_pRightMostPoint	=	pFirstChain;
	}
	else
	{
		m_pRightMostPoint	=	pSecondChain;
	}
	
	if (m_pRightMostPoint->pSite->x < pThirdSite->x || (m_pRightMostPoint->pSite->x == pThirdSite->x) && m_pRightMostPoint->pSite->y < pThirdSite->y)
	{
		m_pRightMostPoint	=	pThirdChain;
	}

	m_pFirstPoint		= pFirstChain;
	m_iCount = 3;//����Ԫ��
}

//�������㹹��һ��͹��
convex::convex( site * pFirstSite ,  site * pSecondSite)
{
	point_chain * pFirstChain = new point_chain;
	point_chain * pSecondChain = new point_chain;

	if(pFirstSite->x == pSecondSite->x && pFirstSite->y == pSecondSite->y)
	{
		printf("wrong input ,the two Sites are the same.\n\n");
		return;

	}

	//ѡȡλ������ߵĵ���Ϊ��һ����,���x����һ��,ѡ�����꿿�ϵĵ�Ϊ��һ����.
	if  ( (pFirstSite->x < pSecondSite->x)		||
		  (pFirstSite->x == pSecondSite->x && pFirstSite->y < pSecondSite->y)
		)
	{
		pFirstChain->pSite		= pFirstSite;
		pSecondChain->pSite		= pSecondSite;
	}
	else
	{
		pFirstChain->pSite		= pSecondSite;
		pSecondChain->pSite		= pFirstSite;
	}	
	
	//�γ�����
	pFirstChain->next		= pSecondChain;
	pFirstChain->previous	= pSecondChain;

	pSecondChain->next		= pFirstChain;
	pSecondChain->previous	= pFirstChain;

	m_pFirstPoint		= pFirstChain;
	m_pLeftMostPoint	= pFirstChain;
	m_pRightMostPoint	= pSecondChain;

	m_iCount = 2;//����Ԫ��


}
//���ص���
int convex::GetCount()
{
	return m_iCount;	
}

void convex::GetFirstPoint(point_chain * * pstruFirstPoint)
{
	* pstruFirstPoint = m_pFirstPoint;
}

void convex::GetLeftMostPoint(point_chain * * pLeftMostPoint)
{
	* pLeftMostPoint = m_pLeftMostPoint;
}

void convex::GetRightMostPoint(point_chain * * pRightMostPoint)
{
	* pRightMostPoint = m_pRightMostPoint;
}

void convex::GetFourMergePoint(const convex * pRightConvex , point_chain * * ppLeftUpSite , point_chain * * ppLeftDownSite , point_chain  * * ppRightUpSite , point_chain * * ppRightDownSite)
{
	//point_chain * pLeftUpSite =  new point_chain;
	//point_chain * pLeftDownSite	=	new point_chain;
	//point_chain * pRightDownSite	= new point_chain;
	//point_chain * pRightUpSite		= new point_chain;
	
	//��ֵ
	point_chain *pLeftUpSite			= m_pRightMostPoint;
	point_chain *pLeftDownSite			= m_pRightMostPoint;
	point_chain *pRightUpSite			= pRightConvex->m_pLeftMostPoint;
	point_chain *pRightDownSite			= pRightConvex->m_pLeftMostPoint;
	
	
	bool bBreakTag          =	true;
	bool bInsideBreakTag1	=	true;
	bool bInsideBreakTag2	=	true;

	////////////////////���µĴ�������Ϊ��͹����ε������⹫����//////////////////////////
	//������
	while(bBreakTag)
	{
		while(bInsideBreakTag1)
		{
			//int j =	 ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y,pLeftUpSite->pSite->x,pLeftUpSite->pSite->y,pLeftUpSite->next->pSite->x,pLeftUpSite->next->pSite->y);
			//�����ƶ���ߵĵ�,֪����ߵıհ��Ѿ��������ߵ�(���),Ҳ��������
			//pRightUpSite->pSite,pLeftUpSite->pSite-->pLeftUpSite->next->pSite
			//if ((!ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y,pLeftUpSite->pSite->x,pLeftUpSite->pSite->y,pLeftUpSite->next->pSite->x,pLeftUpSite->next->pSite->y)) 
			//	|| (!ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y,pLeftUpSite->pSite->x,pLeftUpSite->pSite->y,pLeftUpSite->previous->pSite->x,pLeftUpSite->previous->pSite->y))
			 //  )
			if(!side_to_left(pRightUpSite->pSite, pLeftUpSite->pSite, pLeftUpSite->next->pSite) || !side_to_left(pRightUpSite->pSite, pLeftUpSite->pSite, pLeftUpSite->previous->pSite))
			{
					pLeftUpSite = pLeftUpSite->next;
			}
			//��������,�����ƶ�
			else
			{
				bInsideBreakTag1 = false;
			}
		}//while(bInsideBreakTag1)
		
		while(bInsideBreakTag2)
		{
			//�����ƶ��ұߵĵ�,֪���ұߵıհ����������ߵ�����
			if (  (ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y, pLeftUpSite->pSite->x, pLeftUpSite->pSite->y,pRightUpSite->next->pSite->x, pRightUpSite->next->pSite->y)!=1)
				||(ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y, pLeftUpSite->pSite->x, pLeftUpSite->pSite->y,pRightUpSite->previous->pSite->x, pRightUpSite->previous->pSite->y)!=1)
			   )
			{
				pRightUpSite = pRightUpSite->previous;
			}

			else
			{
				bInsideBreakTag2 = false;
			}
			
		}//while(bInsideBreakTag2)

		//�Ƿ��Ѿ������������հ����������ߵ�����?���ǵĻ�����ѭ��
		if(    (ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y,pLeftUpSite->pSite->x,pLeftUpSite->pSite->y,pLeftUpSite->next->pSite->x,pLeftUpSite->next->pSite->y) != 1) 
			|| (ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y,pLeftUpSite->pSite->x,pLeftUpSite->pSite->y,pLeftUpSite->previous->pSite->x,pLeftUpSite->previous->pSite->y) != 1)
			|| (ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y, pLeftUpSite->pSite->x, pLeftUpSite->pSite->y,pRightUpSite->next->pSite->x, pRightUpSite->next->pSite->y)!=1)
			|| (ToLeft(pRightUpSite->pSite->x, pRightUpSite->pSite->y, pLeftUpSite->pSite->x, pLeftUpSite->pSite->y,pRightUpSite->previous->pSite->x, pRightUpSite->previous->pSite->y)!=1)
		  )
		{
			bInsideBreakTag1 = true;
			bInsideBreakTag2 = true;
		}
		//�Ѿ��ҵ���������.
		else	
		{
			bBreakTag = false;
		}

	}//while(bBreakTag)




	bBreakTag =true;
	//������
	while(bBreakTag)
	{
		while(bInsideBreakTag1)
		{
			//�����ƶ���ߵĵ�,֪����ߵıհ��Ѿ��������ߵ�(���),Ҳ��������
			if ((  ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y,pRightDownSite->pSite->x,pRightDownSite->pSite->y,pLeftDownSite->next->pSite->x,pLeftDownSite->next->pSite->y) != 1) 
				|| (ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y,pRightDownSite->pSite->x,pRightDownSite->pSite->y,pLeftDownSite->previous->pSite->x,pLeftDownSite->previous->pSite->y) != 1)
			   )
				
			{
					pLeftDownSite = pLeftDownSite->previous;
			}
			//��������,�����ƶ�
			else
			{
				bInsideBreakTag1 = false;
			}
		}//while(bInsideBreakTag1)
		
		while(bInsideBreakTag2)
		{
			//�����ƶ��ұߵĵ�,֪���ұߵıհ����������ߵ�����
			if (  (ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y, pRightDownSite->pSite->x, pRightDownSite->pSite->y,pRightDownSite->next->pSite->x, pRightDownSite->next->pSite->y)!=1)
				||(ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y, pRightDownSite->pSite->x, pRightDownSite->pSite->y,pRightDownSite->previous->pSite->x, pRightDownSite->previous->pSite->y)!=1)
			   )
			{
				pRightDownSite = pRightDownSite->next;
			}

			else
			{
				bInsideBreakTag2 = false;
			}
			
		}//while(bInsideBreakTag2)

		//�Ƿ��Ѿ������������հ����������ߵ�����?���ǵĻ�����ѭ��
		if(    (ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y,pRightDownSite->pSite->x, pRightDownSite->pSite->y,pLeftDownSite->next->pSite->x,pLeftDownSite->next->pSite->y) != 1) 
			|| (ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y,pRightDownSite->pSite->x, pRightDownSite->pSite->y,pLeftDownSite->previous->pSite->x,pLeftDownSite->previous->pSite->y) != 1)
			|| (ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y, pRightDownSite->pSite->x, pRightDownSite->pSite->y,pRightDownSite->next->pSite->x, pRightDownSite->next->pSite->y)!=1)
			|| (ToLeft(pLeftDownSite->pSite->x, pLeftDownSite->pSite->y, pRightDownSite->pSite->x, pRightDownSite->pSite->y,pRightDownSite->previous->pSite->x, pRightDownSite->previous->pSite->y)!=1)
		  )
		{
			bInsideBreakTag1 = true;
			bInsideBreakTag2 = true;
		}
		//�Ѿ��ҵ���������.
		else	
		{
			bBreakTag = false;
			* ppLeftDownSite = pLeftDownSite;
			* ppLeftUpSite	 = pLeftUpSite;
			* ppRightUpSite	 = pRightUpSite;
			* ppRightDownSite= pRightDownSite;
		}

	}//while(bBreakTag)

}

// NewConvex ��ʼΪ�յ�,�����Ԫ�ض���Ĭ��ֵ
void convex::MergeWithRightConvex(convex * pRightConvex ,convex * NewConvex)
{
	point_chain * pLeftUpPoint ;
	point_chain * pLeftDownPoint;
	point_chain * pRightDownPoint;
	point_chain * pRightUpPoint;
	GetFourMergePoint(pRightConvex,&pLeftUpPoint,&pLeftDownPoint,&pRightUpPoint,&pRightDownPoint);

	point_chain * ptmpChain;
/*	point_chain * ptmpToBeDeletedChain;

	ptmpChain = pLeftUpPoint;
	while (ptmpChain!=pLeftDownPoint)
	{
		ptmpToBeDeletedChain = ptmpChain->next;
		free(ptmpToBeDeletedChain);
	}

	ptmpChain = pRightDownPoint;
	while (ptmpChain!=pRightUpPoint)
	{
		ptmpToBeDeletedChain = ptmpChain->next;
		free(ptmpToBeDeletedChain);
	}

*/
	pLeftUpPoint->next			=	pRightUpPoint;
	pRightUpPoint->previous		=	pLeftUpPoint;

	pRightDownPoint->next		=	pLeftDownPoint;
	pLeftDownPoint->previous	=	pRightDownPoint;
	
	
	int iNewCount = 0;
	ptmpChain = m_pFirstPoint->next;
	iNewCount = 1;//�Ѿ���һ��ȷ����Ԫ��,��ǰָ���Ԫ�ػ�û�м����ǲ����ظ���.
	while(ptmpChain!=m_pFirstPoint)
	{
		iNewCount++;
		ptmpChain = ptmpChain->next;
		
	}
	NewConvex->m_iCount = iNewCount;
	NewConvex->m_pRightMostPoint	=	pRightConvex->m_pRightMostPoint;
	NewConvex->m_pLeftMostPoint		=	m_pLeftMostPoint;
	NewConvex->SetFirstPoint(m_pFirstPoint);


}

void convex::PrintAllSites()
{
	point_chain * tmpPointChain = m_pFirstPoint;
	for( int i=0; i<m_iCount; i++)
	{
		printf("X:%f , Y:%f\n" ,tmpPointChain->pSite->x,tmpPointChain->pSite->y);	
		tmpPointChain = tmpPointChain->next;
	}
	printf("\n");
}

void convex::SetFirstPoint(point_chain * pFirstPoint)
{

	m_pFirstPoint = pFirstPoint;
}


/*
void main()
{
	site * psite1 = new site;
	site * psite2 = new site;
	site * psite3 = new site;
	site * psite4 = new site;
	site * psite5 = new site;
	site * psite6 = new site;


	psite1->id =1;
	psite1->x = 11;
	psite1->y = 13;
	//psite1->type = 

	psite2->id =2;
	psite2->x = 14;
	psite2->y = 33;

	psite3->id =3;
	psite3->x = 17;
	psite3->y = 21;

	psite4->id =4;
	psite4->x = 21;
	psite4->y = 17;

	psite5->id =5;
	psite5->x = 31;
	psite5->y = 23;

	psite6->id =6;
	psite6->x = 33;
	psite6->y = 15;


	convex aConvex = convex(psite1,psite2,psite3);
	convex bConvex = convex(psite4,psite5,psite6);
	convex cConvex = convex();

	point_chain * pChain1 = new point_chain;
	point_chain * pChain2 = new point_chain;
	point_chain * pChain3 = new point_chain;
	point_chain * pChain4 = new point_chain;

	//aConvex.GetFourMergePoint(&bConvex, &pChain1, &pChain2 , &pChain3 , &pChain4);

	aConvex.MergeWithRightConvex(&bConvex ,&cConvex);
	aConvex.PrintAllSites();
	cConvex.PrintAllSites();

	


}
*/