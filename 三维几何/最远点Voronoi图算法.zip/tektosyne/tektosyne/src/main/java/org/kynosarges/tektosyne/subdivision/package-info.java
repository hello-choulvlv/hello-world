/**
 * Contains planar subdivision structures and algorithms.
 */
package org.kynosarges.tektosyne.subdivision;
