/**
 * Contains general utilities and collections.
 */
package org.kynosarges.tektosyne;
