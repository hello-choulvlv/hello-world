/**
 * Contains geometric primitives, structures, and algorithms.
 */
package org.kynosarges.tektosyne.geometry;
