/**
 * Contains graph interfaces and algorithms.
 */
package org.kynosarges.tektosyne.graph;
