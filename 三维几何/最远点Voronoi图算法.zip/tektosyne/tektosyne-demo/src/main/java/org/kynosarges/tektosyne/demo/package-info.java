/**
 * Contains the Tektosyne Demo application.
 */
package org.kynosarges.tektosyne.demo;
