# Metal 着色语言指南 V2.1

 [第一章 介绍](ch01.md)

 [第二章 数据类型](ch02.md)

 [第三章 运算符](ch03.md)

 [第四章 函数和变量申明](ch04.md)

 [第五章 Metal标准库](ch05.md)

 [第六章 编译器和预处理器](ch06.md)

 [第七章 数值合规性](ch07.md)

 [Metal Shading Language Specification](https://developer.apple.com/metal/Metal-Shading-Language-Specification.pdf)